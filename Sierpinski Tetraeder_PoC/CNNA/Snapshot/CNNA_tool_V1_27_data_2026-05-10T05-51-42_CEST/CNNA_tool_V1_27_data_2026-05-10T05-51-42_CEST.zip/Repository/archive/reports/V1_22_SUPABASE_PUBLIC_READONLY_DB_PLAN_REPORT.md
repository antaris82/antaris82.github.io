# V1.22 Supabase/Postgres public read-only DB mirror planning report

## Scope

V1.22 records the Supabase/Postgres and cnna-project.net architecture as a future non-blocking DB/tooling sidechain. It is not a live database implementation.

## Architecture decision

Lean and the Master YAML remain the internal truth/versioned planning sources. Supabase/Postgres may become a public read-only query mirror. A web frontend on a domain such as cnna-project.net may visualize and navigate this public mirror.

## New phases

- 20.15 DB mirror feasibility and Supabase/Postgres schema design
- 20.16 YAML/exports to Postgres import and roundtrip contract
- 20.17 append-only snapshot and checksum model
- 20.18 public read-only API views and RLS policies
- 20.19 cnna-project.net web-frontend data contract
- 20.20 reviewer annotation and future admin-write model

## New objects

- DBR15 Supabase/Postgres mirror feasibility and schema design
- DBR16 YAML/exports to Postgres import and roundtrip contract
- DBR17 append-only snapshot and checksum model
- DBR18 public read-only API views and RLS policies
- DBR19 cnna-project.net web-frontend data contract
- DBR20 reviewer annotation and future admin-write model

## Guardrail

GNG34: no Supabase row is a CNNA truth source; no public writes; no browser service_role key; no DB update without snapshot_id, source hash and import report; every public row must be traceable to a Lean/YAML snapshot.

## Non-actions in V1.22

- no live Supabase connection
- no DB write
- no .env or secret added
- no frontend deployment
- no Lean source change
- no Lean build claimed

## Recommended future activation order

1. Stabilize Lean/YAML identifiers and generated exports.
2. Design normalized schema and import contract.
3. Implement local importer with snapshot/hash report.
4. Define public read-only api.* views and RLS/grants.
5. Build cnna-project.net frontend against read-only views.
6. Add reviewer/authenticated annotations only after read-only mirror is secure.
