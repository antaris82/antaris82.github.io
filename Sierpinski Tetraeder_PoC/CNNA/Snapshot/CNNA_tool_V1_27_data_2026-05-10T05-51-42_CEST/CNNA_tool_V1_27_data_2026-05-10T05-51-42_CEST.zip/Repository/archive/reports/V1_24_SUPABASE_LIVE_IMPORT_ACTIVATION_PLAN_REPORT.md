# V1.24 Supabase live import activation plan report

## Existing-phase check

Before adding new DB phases, the current plan was checked for existing Supabase/Postgres/database/web-frontend records. The relevant existing phases are:

- 20.15 Supabase/Postgres mirror feasibility and schema design
- 20.16 YAML/exports to Postgres import and roundtrip contract
- 20.17 Append-only snapshot and checksum model
- 20.18 Public read-only API views and RLS policies
- 20.19 cnna-project.net web-frontend data contract
- 20.20 Reviewer annotation and future admin-write model

These phases are retained as broad architecture contracts. They are not duplicated. V1.24 adds a concrete activation chain only because the Supabase connector is now live and a project baseline can be recorded.

## Read-only Supabase baseline

- Organization: CNNA Project
- Project: ComplemeNt Net Architectur (CNNA)
- Project ref: aiekahdewadrejrrdajn
- Region: eu-north-1
- Status: ACTIVE_HEALTHY
- Postgres engine: 17
- Initial checked schemas: public, internal, api, review, admin
- Tables found before migration/import: none

No schema write, no data import and no migration was executed.

## New concrete activation chain

- 20.22 Supabase live project discovery and empty-schema baseline audit
- 20.23 Supabase initial schema migration package and RLS/read-only policy design
- 20.24 Supabase snapshot import package from YAML/generated exports
- 20.25 Explicitly authorized live Supabase schema migration and first snapshot import
- 20.26 Post-import read-only/RLS/advisor verification and web-frontend handoff

## Hard boundaries

- Supabase is generated-secondary publication/query infrastructure only.
- No Supabase row is a CNNA truth source.
- No public writes.
- No service_role key in browser, repository or chat.
- No live apply_migration/execute_sql write without explicit current-step user authorization.
- Live DB writes must affect only Supabase schema/data and never Lean files.
- Every import must produce snapshot_id, source hashes and import report evidence.

## Status

V1.24 is a planning/tooling update. It prepares concrete DB activation phases but performs no DB write and no Lean source change.
