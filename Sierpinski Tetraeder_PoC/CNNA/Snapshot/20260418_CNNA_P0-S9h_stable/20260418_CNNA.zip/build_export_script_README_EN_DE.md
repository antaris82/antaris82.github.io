# Lean-Modul- und Import-Export / Lean Module and Import Export

## EN

### Purpose

This build tool extracts the **exact module list** and the **direct import relations** from a Lean codebase by reading the `.lean` source files.
It is intended for architecture audits, reviewer documentation, import-chain control, and discipline-oriented audit slices.

The tool is deliberately based on **robust source-level analysis**:

- Module names are derived **from file paths** relative to `repo_root`.
- Imports are read **directly from Lean source files**.
- Line comments `-- ...` and nested block comments `/- ... -/` are stripped before import parsing.
- The tool distinguishes between
  - **internal imports**,
  - **external imports**,
  - **missing internal imports**.

The script is intentionally **source-based**. It does **not** inspect an elaborated Lean environment and is **not** a semantic usage analyzer. It answers

> “Which modules exist, and which direct imports are declared?”

rather than

> “Which definitions, notations, or theorems are semantically consumed?”

---

### File location

The main script lives in the build directory:

```text
build/export_lean_module_import_graph.py
```

A default CNNA discipline configuration can be written or reused via:

```text
build/default_discipline_config.json
```

By default, export files are written to:

```text
build/module_import_export/
```

unless a custom `--output-dir` is provided.

---

### Main features

#### 1. Exact module list

The script recursively scans all `.lean` files below `source_root` and derives Lean module names from their paths.

Example:

```text
CNNA/PillarA/Foundation/SubstrateClass.lean
```

becomes

```text
CNNA.PillarA.Foundation.SubstrateClass
```

The module list also stores metadata such as:

- file path
- direct imports
- internal / external / missing imports
- reverse edges (`imported_by`)
- transitive internal imports
- `prelude`
- `BuildAll` / `Notation` markers
- group assignment

#### 2. Direct import classification

For each module, the script reads the direct `import` lines at the top of the file.

Results are classified as:

- **internal_imports**: imported modules that exist as `.lean` files inside the scanned project tree
- **external_imports**: imports outside the internal module set
- **missing_internal_imports**: imports with an internal prefix but without a matching project file

The third case is especially useful during refactors, since it often indicates:

- renamed or moved files
- stale imports
- wrong `repo_root` or `source_root`
- an overly broad or overly narrow scan scope

#### 3. Graph export

The direct import graph is exported as:

- `import_graph.dot` for Graphviz
- `import_edges.json`
- `import_edges.csv`

External imports are rendered as separate external nodes in the DOT graph. Missing internal imports are shown in red.

#### 4. Topological order

Based on internal import edges, the script computes a **dependency-respecting topological order**.

This means:

- dependencies come **before** modules that import them
- cycles are reported explicitly if they exist

Exports:

- `dependency_order.json`
- `dependency_order.txt`

#### 5. Group / area summaries

Modules are grouped by path depth relative to `source_root`, with `--group-depth 2` by default.

CNNA examples:

- `PillarA/Foundation`
- `PillarA/ToC`
- `PillarA/Handoff`

Exports:

- `group_summary.json`
- `group_subgraphs/*.dot`

This layer is useful for first-pass architectural or domain-cluster summaries.

#### 6. Hotspot analysis

The script computes several hotspot rankings, for example:

- highest internal out-degree
- highest internal in-degree
- highest total internal connectivity
- largest transitive internal dependency set

Export:

- `hotspots.json`

These hotspots are often strong candidates for:

- review focus
- refactoring
- documentation priority
- import-chain control

#### 7. Discipline audit exports

Optionally, the script can export **discipline-oriented audit slices**. Membership is controlled by a JSON configuration.

Important properties:

- A module may belong to **multiple disciplines**.
- Each discipline gets its own module set, internal edges, entry modules, terminal modules, and bridges to other disciplines.
- Cross-discipline bridges are exported explicitly, so interdisciplinary dependencies remain visible.

Exports:

- `discipline_summary.json`
- `disciplines/summary.json`
- `disciplines/bridge_summary.json`
- `disciplines/<slug>/summary.json`
- `disciplines/<slug>/graph.dot`
- `disciplines/<slug>/README.md`

#### 8. Validation warnings

The script automatically detects some common failure signatures, such as:

- implausibly large module counts
- `internal edges = 0` despite internal prefixes
- `source_root = .`
- many discovered modules outside the declared internal prefixes

These warnings are especially useful when `repo_root` or `source_root` are misaligned.

---

### Command-line usage

#### Standard CNNA call

Run from the repository root:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA
```

This is the recommended default call for the CNNA repository.

#### With an explicit internal prefix

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --internal-prefix CNNA
```

This is usually redundant for CNNA, but can be useful as an explicit safeguard.

#### With a custom output directory

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --output-dir build/my_custom_export
```

#### With a different grouping depth

Coarser grouping:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --group-depth 1
```

Finer grouping:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --group-depth 3
```

#### With more hotspot rows

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --hotspot-count 25
```

#### With a custom discipline config

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --discipline-config build/default_discipline_config.json
```

#### Write the built-in default discipline config

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --write-default-discipline-config build/default_discipline_config.json
```

This writes the built-in configuration to an editable JSON file and then continues with the export.

#### Show help

```bash
python3 build/export_lean_module_import_graph.py --help
```

---

### CLI parameters

#### Positional argument

```text
repo_root
```

Project root containing the `source_root`, typically the repository root.

#### Options

```text
--source-root SOURCE_ROOT
```

Lean source root relative to `repo_root`. Default: `CNNA`

```text
--output-dir OUTPUT_DIR
```

Target directory for all exports. Default:

```text
<repo_root>/build/module_import_export
```

```text
--internal-prefix INTERNAL_PREFIXES
```

Internal module prefix. May be repeated.
Default: the first path component of `source_root`.

```text
--group-depth GROUP_DEPTH
```

Path depth after `source_root` used for grouping. Default: `2`

```text
--hotspot-count HOTSPOT_COUNT
```

Number of rows to emit per hotspot ranking. Default: `20`

```text
--discipline-config DISCIPLINE_CONFIG
```

Optional JSON file for discipline-oriented audit exports.

```text
--write-default-discipline-config WRITE_DEFAULT_DISCIPLINE_CONFIG
```

Writes the built-in default configuration to the given path.

---

### Output files

#### Core exports

- `modules.json`
- `modules.csv`
- `import_edges.json`
- `import_edges.csv`
- `import_graph.dot`
- `stats.json`
- `README.md` (auto-generated export summary)

#### Dependency exports

- `dependency_order.json`
- `dependency_order.txt`

#### Group exports

- `group_summary.json`
- `group_subgraphs/*.dot`

#### Hotspots

- `hotspots.json`

#### Discipline exports

- `discipline_summary.json`
- `disciplines/summary.json`
- `disciplines/bridge_summary.json`
- `disciplines/<slug>/summary.json`
- `disciplines/<slug>/graph.dot`
- `disciplines/<slug>/README.md`

---

### Structure of the key JSON files

#### `modules.json`

Contains:

- global export metadata
- full list of modules and their detailed fields

Important per-module fields:

- `module`
- `path`
- `imports`
- `internal_imports`
- `external_imports`
- `missing_internal_imports`
- `imported_by`
- `internal_imported_by`
- `external_imported_by`
- `transitive_internal_imports`
- `prelude`
- `is_build_module`
- `is_notation_module`
- `group`
- `path_after_source_root`

#### `import_edges.json`

Contains separate lists for:

- `internal_edges`
- `external_edges`
- `missing_internal_edges`

#### `stats.json`

Contains:

- module counts
- edge counts
- acyclicity status
- cycle components
- topological order
- validation warnings

#### `group_summary.json`

Contains, per group:

- module count
- internal edges
- incoming edges from other groups
- outgoing edges to other groups

#### `hotspots.json`

Contains ranked lists for:

- `top_internal_out_degree`
- `top_internal_in_degree`
- `top_total_internal_degree`
- `top_transitive_internal_imports`

#### `discipline_summary.json`

Contains the discipline-level overview:

- discipline config origin
- number of disciplines
- modules per discipline
- module memberships
- unassigned modules
- overlapping memberships
- bridges between disciplines

---

### Discipline configuration format

A discipline entry consists of:

- `name`
- `description`
- `include_modules`
- `include_prefixes`
- `include_regexes`
- `exclude_modules`
- `exclude_prefixes`
- `exclude_regexes`

A module belongs to a discipline if it matches at least one `include_*` criterion and none of the `exclude_*` criteria.

#### Example

```json
{
  "disciplines": [
    {
      "name": "dirichlet_dtn_schur_network",
      "description": "Dirichlet, DtN, closure regularization, Schur coupling and network-facing transport.",
      "include_modules": [],
      "include_prefixes": [
        "CNNA.PillarA.Finite.DirichletLaplacian",
        "CNNA.PillarA.DtN",
        "CNNA.PillarA.Closure",
        "CNNA.PillarA.Coupling",
        "CNNA.PillarA.Network",
        "CNNA.PillarA.Sectors"
      ],
      "include_regexes": [],
      "exclude_modules": [],
      "exclude_prefixes": [],
      "exclude_regexes": []
    }
  ]
}
```

---

### Typical failure signatures

#### Case 1: Far too many modules, no internal edges

Example:

```text
modules: 9135
internal edges: 0
external edges: 2457
missing internal edges: 243
```

This almost always means that

- the wrong `repo_root` was used,
- `--source-root .` was used,
- or the scan accidentally included `.lake/packages` or other external trees.

**Fix:**

Run from the repository root:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA
```

#### Case 2: Missing internal imports

If `missing_internal_edges > 0`, the project contains import names that look internal but do not match any discovered project file.

That may indicate a real problem or a mis-scoped scan.

#### Case 3: Many foreign module names

If many discovered modules lie outside the declared internal prefixes, the source root is usually too broad.

---

### Limits of the tool

This tool provides **exact direct import data**, but not full Lean semantics.

In particular, it does **not** provide:

- elaboration analysis
- definition or theorem usage analysis
- notation usage analysis
- typeclass resolution analysis
- proof-structure reconstruction

It is therefore strongest as an:

- architecture export tool
- module/import audit tool
- preprocessing layer for reviewer documentation
- preprocessing layer for future documentation automation
- preprocessing layer for discipline-oriented audit slices

---

### Practical recommendation for CNNA

For the CNNA repository, the recommended baseline command is:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --internal-prefix CNNA
```

After that, the following files are especially useful as inputs for further documentation and audit work:

- `stats.json`
- `dependency_order.txt`
- `group_summary.json`
- `hotspots.json`
- `discipline_summary.json`
- `disciplines/bridge_summary.json`

These exports are a strong basis for:

- first Pillar-A reviewer documents
- discipline-based audit slices
- handoff documentation
- later JSON- or database-driven documentation pipelines







## DE

### Zweck

Dieses Build-Werkzeug extrahiert aus einer Lean-Codebasis die **exakte Modulliste** und die **direkten Importrelationen** auf Basis der `.lean`-Quelldateien. Es ist fuer Architektur-Audits, Reviewer-Dokumentation, Importkettenkontrolle und die Vorbereitung disziplinaerer Audit-Schnitte gedacht.

Der Schwerpunkt liegt auf einer **robusten, transparenten Quelltextauswertung**:

- Modulnamen werden **aus den Dateipfaden** relativ zum `repo_root` bestimmt.
- Imports werden **direkt aus den Lean-Dateien** gelesen.
- Zeilenkommentare `-- ...` und verschachtelte Blockkommentare `/- ... -/` werden vor dem Import-Parsing entfernt.
- Das Werkzeug unterscheidet zwischen
  - **internen Imports**,
  - **externen Imports**,
  - **fehlenden internen Imports**.

Das Skript ist bewusst **quelltextbasiert**. Es wertet **keine elaborierten Lean-Umgebungen** aus und ist **kein semantischer Nutzungsanalysator**. Es beantwortet also die Frage

> „Welche Module existieren und welche direkten Imports werden deklariert?“

und nicht die Frage

> „Welche Definitionen, Notationen oder Theoreme werden semantisch wirklich konsumiert?“

---

### Dateistandort

Das Hauptskript liegt im Build-Ordner:

```text
build/export_lean_module_import_graph.py
```

Eine Standard-Disziplinkonfiguration fuer CNNA kann bei Bedarf geschrieben oder genutzt werden:

```text
build/default_discipline_config.json
```

Die Standard-Ausgaben werden nach

```text
build/module_import_export/
```

geschrieben, sofern kein anderer `--output-dir` angegeben wird.

---

### Hauptfunktionen

#### 1. Exakte Modulliste

Das Skript sucht rekursiv alle `.lean`-Dateien unter dem angegebenen `source_root` und bildet daraus Modulnamen.

Beispiel:

```text
CNNA/PillarA/Foundation/SubstrateClass.lean
```

wird zu

```text
CNNA.PillarA.Foundation.SubstrateClass
```

Die Modulliste enthaelt zusaetzlich Metadaten, darunter:

- Dateipfad
- direkte Imports
- interne/externe/missing Imports
- reverse edges (`imported_by`)
- transitive interne Imports
- `prelude`
- Kennzeichnung als `BuildAll`- oder `Notation`-Modul
- Gruppenzuordnung

#### 2. Direkte Importklassifikation

Fuer jedes Modul werden die direkten `import`-Zeilen am Dateianfang gelesen.

Die Ergebnisse werden klassifiziert als:

- **internal_imports**: Importierte Module, fuer die im gescannten Projekt eine passende `.lean`-Datei existiert
- **external_imports**: Imports ausserhalb der internen Modulmenge
- **missing_internal_imports**: Imports mit internem Praefix, fuer die aber keine passende Projektdatei gefunden wurde

Gerade der dritte Fall ist fuer Refactorings wichtig, weil er oft auf einen der folgenden Zustaende hinweist:

- Datei verschoben oder umbenannt
- Import veraltet
- falscher `repo_root` oder `source_root`
- versehentlich zu breit oder zu schmal gescannter Baum

#### 3. Graph-Export

Das Skript exportiert den direkten Importgraphen als:

- `import_graph.dot` fuer Graphviz
- `import_edges.json`
- `import_edges.csv`

Externe Imports werden im DOT-Graphen als eigene externe Knoten dargestellt. Fehlende interne Imports werden im DOT-Graphen rot markiert.

#### 4. Topologische Ordnung

Auf Basis der internen Importkanten wird eine **abhaengigkeitsrespektierende topologische Ordnung** berechnet.

Das bedeutet:

- Abhaengigkeiten kommen **vor** den Modulen, die sie importieren.
- Wenn Zyklen vorliegen, werden diese explizit ausgewiesen.

Exporte:

- `dependency_order.json`
- `dependency_order.txt`

#### 5. Gruppen-/Bereichsauswertung

Module werden nach Pfadtiefe relativ zum `source_root` gruppiert, standardmaessig mit `--group-depth 2`.

Beispiele fuer CNNA:

- `PillarA/Foundation`
- `PillarA/ToC`
- `PillarA/Handoff`

Exporte:

- `group_summary.json`
- `group_subgraphs/*.dot`

Diese Schicht ist nuetzlich fuer erste fachliche oder architektonische Cluster-Auswertungen.

#### 6. Hotspot-Analyse

Das Skript berechnet mehrere Import-Hotspot-Rankings, z. B.:

- hoechste interne Out-Degree
- hoechste interne In-Degree
- hoechste Gesamt-Konnektivitaet
- groesste transitive interne Abhaengigkeitsmenge

Export:

- `hotspots.json`

Diese Hotspots sind oft Kandidaten fuer:

- Review-Schwerpunkt
- Refactoring
- Dokumentationspriorisierung
- Importkettenkontrolle

#### 7. Disziplin-Audit-Exporte

Optional kann das Skript **disziplinaere Audit-Schnitte** exportieren. Die Zuordnung erfolgt ueber eine JSON-Konfiguration.

Wichtige Eigenschaften:

- Ein Modul kann **mehreren Disziplinen** angehoeren.
- Fuer jede Disziplin werden eigene Module, interne Kanten, Entry-Module, Terminal-Module und Bruecken zu anderen Disziplinen exportiert.
- Disziplinbruecken werden explizit ausgewiesen, damit fachuebergreifende Abhaengigkeiten sichtbar bleiben.

Exporte:

- `discipline_summary.json`
- `disciplines/summary.json`
- `disciplines/bridge_summary.json`
- `disciplines/<slug>/summary.json`
- `disciplines/<slug>/graph.dot`
- `disciplines/<slug>/README.md`

#### 8. Validierungswarnungen

Das Skript erkennt einige typische Fehlersignaturen automatisch, etwa:

- viel zu grosse Modulzahl
- `internal edges = 0` trotz interner Praefixe
- `source_root = .`
- viele Module ausserhalb der deklarierten internen Praefixe

Diese Warnungen helfen besonders bei falsch gewaehltem `repo_root` oder `source_root`.

---

### Kommandozeilenaufrufe

#### Standardaufruf fuer CNNA

Im Repo-Root ausfuehren:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA
```

Das ist der empfohlene Normalfall fuer das CNNA-Repo.

#### Mit explizitem internem Praefix

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --internal-prefix CNNA
```

Das ist fuer CNNA meist redundant, kann aber als Absicherung sinnvoll sein.

#### Mit anderem Ausgabeordner

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --output-dir build/my_custom_export
```

#### Mit anderer Gruppierungstiefe

Grobere Gruppierung:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --group-depth 1
```

Feinere Gruppierung:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --group-depth 3
```

#### Mit mehr Hotspot-Zeilen

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --hotspot-count 25
```

#### Mit eigener Disziplinkonfiguration

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --discipline-config build/default_discipline_config.json
```

#### Default-Disziplinkonfiguration ausschreiben

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --write-default-discipline-config build/default_discipline_config.json
```

Das schreibt die eingebaute Konfiguration in eine bearbeitbare JSON-Datei und fuehrt den Export anschliessend weiter aus.

#### Hilfe anzeigen

```bash
python3 build/export_lean_module_import_graph.py --help
```

---

### CLI-Parameter

#### Positional argument

```text
repo_root
```

Projektwurzel, die den `source_root` enthaelt. Typischerweise das Repository-Root.

#### Optionen

```text
--source-root SOURCE_ROOT
```

Lean-Quellwurzel relativ zu `repo_root`. Standard: `CNNA`

```text
--output-dir OUTPUT_DIR
```

Zielordner fuer den Export. Standard:

```text
<repo_root>/build/module_import_export
```

```text
--internal-prefix INTERNAL_PREFIXES
```

Interner Modul-Praefix. Kann mehrfach angegeben werden.
Standard: erste Pfadkomponente von `source_root`.

```text
--group-depth GROUP_DEPTH
```

Pfadtiefe nach `source_root` fuer Gruppenbildung. Standard: `2`

```text
--hotspot-count HOTSPOT_COUNT
```

Anzahl der Eintraege je Hotspot-Ranking. Standard: `20`

```text
--discipline-config DISCIPLINE_CONFIG
```

Optionale JSON-Datei fuer disziplinaere Audit-Schnitte.

```text
--write-default-discipline-config WRITE_DEFAULT_DISCIPLINE_CONFIG
```

Schreibt die eingebaute Standardkonfiguration an den angegebenen Pfad.

---

### Ausgabe-Dateien

#### Kernexporte

- `modules.json`
- `modules.csv`
- `import_edges.json`
- `import_edges.csv`
- `import_graph.dot`
- `stats.json`
- `README.md` (auto-generierte Exportzusammenfassung)

#### Abhaengigkeiten

- `dependency_order.json`
- `dependency_order.txt`

#### Gruppen

- `group_summary.json`
- `group_subgraphs/*.dot`

#### Hotspots

- `hotspots.json`

#### Disziplinen

- `discipline_summary.json`
- `disciplines/summary.json`
- `disciplines/bridge_summary.json`
- `disciplines/<slug>/summary.json`
- `disciplines/<slug>/graph.dot`
- `disciplines/<slug>/README.md`

---

### Struktur der wichtigsten JSON-Dateien

#### `modules.json`

Enthaelt:

- globale Export-Metadaten
- Liste aller Module mit ihren Detailfeldern

Wichtige Felder pro Modul:

- `module`
- `path`
- `imports`
- `internal_imports`
- `external_imports`
- `missing_internal_imports`
- `imported_by`
- `internal_imported_by`
- `external_imported_by`
- `transitive_internal_imports`
- `prelude`
- `is_build_module`
- `is_notation_module`
- `group`
- `path_after_source_root`

#### `import_edges.json`

Enthaelt getrennt:

- `internal_edges`
- `external_edges`
- `missing_internal_edges`

#### `stats.json`

Enthaelt:

- Modulanzahl
- Kantenzahlen
- Azyklizitaet
- Zykluskomponenten
- topologische Ordnung
- Validierungswarnungen

#### `group_summary.json`

Enthaelt pro Gruppe:

- Modulanzahl
- interne Kanten
- eingehende Kanten aus anderen Gruppen
- ausgehende Kanten in andere Gruppen

#### `hotspots.json`

Enthaelt Ranglisten nach:

- `top_internal_out_degree`
- `top_internal_in_degree`
- `top_total_internal_degree`
- `top_transitive_internal_imports`

#### `discipline_summary.json`

Enthaelt den disziplinaeren Gesamtueberblick:

- Herkunft der Disziplinkonfiguration
- Anzahl der Disziplinen
- Module pro Disziplin
- Modulmitgliedschaften
- unzugeordnete Module
- Mehrfachzuordnungen
- Bruecken zwischen Disziplinen

---

### Format der Disziplinkonfiguration

Eine Disziplin besteht aus:

- `name`
- `description`
- `include_modules`
- `include_prefixes`
- `include_regexes`
- `exclude_modules`
- `exclude_prefixes`
- `exclude_regexes`

Ein Modul gehoert zu einer Disziplin, wenn es mindestens eines der `include_*`-Kriterien erfuellt und keines der `exclude_*`-Kriterien verletzt.

#### Beispiel

```json
{
  "disciplines": [
    {
      "name": "dirichlet_dtn_schur_network",
      "description": "Dirichlet, DtN, closure regularization, Schur coupling and network-facing transport.",
      "include_modules": [],
      "include_prefixes": [
        "CNNA.PillarA.Finite.DirichletLaplacian",
        "CNNA.PillarA.DtN",
        "CNNA.PillarA.Closure",
        "CNNA.PillarA.Coupling",
        "CNNA.PillarA.Network",
        "CNNA.PillarA.Sectors"
      ],
      "include_regexes": [],
      "exclude_modules": [],
      "exclude_prefixes": [],
      "exclude_regexes": []
    }
  ]
}
```

---

### Typische Fehlersignaturen

#### Fall 1: Viel zu viele Module, keine internen Kanten

Beispiel:

```text
modules: 9135
internal edges: 0
external edges: 2457
missing internal edges: 243
```

Das deutet fast immer darauf hin, dass

- der falsche `repo_root` gewaehlt wurde,
- `--source-root .` verwendet wurde,
- oder der Scan `.lake/packages` bzw. andere externe Baeume mit erfasst hat.

**Abhilfe:**

Im Repo-Root ausfuehren:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA
```

#### Fall 2: Fehlende interne Imports

Wenn `missing_internal_edges > 0`, dann gibt es interne Importnamen mit passendem internen Praefix, aber ohne passende Projektdatei.

Das kann auf reale Probleme oder auf einen falsch gesetzten Scanbereich hinweisen.

#### Fall 3: Viele fremde Modulnamen

Wenn viele erkannte Module nicht unter den internen Praefixen liegen, wurde meist ein zu breiter Source-Root gewaehlt.

---

### Grenzen des Werkzeugs

Dieses Werkzeug liefert **exakte direkte Importdaten**, aber keine volle Lean-Semantik.

Es leistet insbesondere **nicht**:

- keine Elaborationsanalyse
- keine Definition- oder Theorem-Konsumierungsanalyse
- keine Notationsnutzungsanalyse
- keine Typklassenauflosung
- keine Beweisstrukturrekonstruktion

Es ist daher am staerksten als:

- Architektur-Export
- Modul-/Import-Audit
- Vorstufe fuer Reviewer-Dokumentation
- Vorstufe fuer spaetere Doku-Automatisierung
- Vorstufe fuer disziplinaere Audit-Schnitte

---

### Praktische Empfehlung fuer CNNA

Fuer das CNNA-Repo ist der empfohlene Basisaufruf:

```bash
python3 build/export_lean_module_import_graph.py . --source-root CNNA --internal-prefix CNNA
```

Danach lassen sich insbesondere diese Dateien gut weiterverwenden:

- `stats.json`
- `dependency_order.txt`
- `group_summary.json`
- `hotspots.json`
- `discipline_summary.json`
- `disciplines/bridge_summary.json`

Diese Exporte sind eine gute Grundlage fuer:

- erste Pillar-A-Reviewer-Dokumente
- disziplinaere Audit-Schnitte
- Handoff-Dokumentation
- spaetere JSON-/Datenbank-basierte Doku-Pipelines
