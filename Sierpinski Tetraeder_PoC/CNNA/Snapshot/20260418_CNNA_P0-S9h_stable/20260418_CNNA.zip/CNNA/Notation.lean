import CNNA.PillarA.Notation
