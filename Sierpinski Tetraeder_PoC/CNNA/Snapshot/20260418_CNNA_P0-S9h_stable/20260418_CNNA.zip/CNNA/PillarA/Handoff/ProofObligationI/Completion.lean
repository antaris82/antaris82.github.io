import CNNA.Structural.CayleyDickson.S6ProofDutyGroups

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

section DutyI

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

abbrev ProofObligationISeed
    (X : PillarAStep1Closed Cell T) :=
  HurwitzStopSeed X

abbrev ProofObligationIClosed
    (X : PillarAStep1Closed Cell T)
    (seed : ProofObligationISeed (Cell := Cell) (T := T) X) : Prop :=
  CanonicalIdealAlgebraizationDuty seed

abbrev ProofObligationIThreeDutyClosure
    (X : PillarAStep1Closed Cell T)
    (seed : ProofObligationISeed (Cell := Cell) (T := T) X) : Prop :=
  ThreeProofDutiesClosed seed

theorem proofObligationIClosed_of_hurwitzStopClosed
    {X : PillarAStep1Closed Cell T}
    {seed : ProofObligationISeed (Cell := Cell) (T := T) X}
    (h : HurwitzStopClosed seed) :
    ProofObligationIClosed (Cell := Cell) (T := T) X seed :=
  hurwitzStopClosed_implies_canonicalIdealAlgebraizationDuty h

theorem proofObligationIThreeDutyClosure_of_hurwitzStopClosed
    {X : PillarAStep1Closed Cell T}
    {seed : ProofObligationISeed (Cell := Cell) (T := T) X}
    (h : HurwitzStopClosed seed) :
    ProofObligationIThreeDutyClosure (Cell := Cell) (T := T) X seed :=
  hurwitzStopClosed_implies_threeProofDutiesClosed h

end DutyI

end CNNA.PillarA.Handoff
