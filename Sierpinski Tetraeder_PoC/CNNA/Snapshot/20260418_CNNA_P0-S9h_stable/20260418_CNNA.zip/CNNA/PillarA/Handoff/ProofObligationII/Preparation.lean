import CNNA.Structural.CayleyDickson.S6StatusLayer

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

section DutyII

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

variable {X : PillarAStep1Closed Cell T}

structure ProofObligationIIPreparation
    (X : PillarAStep1Closed Cell T) where
  approximantsExposeProjectiveSubregimes : PillarAStep1Closed Cell T → Prop

abbrev ProofObligationIIReady
    (prep : ProofObligationIIPreparation (Cell := Cell) (T := T) X) : Prop :=
  FunctorialApproximantCompatibilityObligation
    prep.approximantsExposeProjectiveSubregimes X

end DutyII

end CNNA.PillarA.Handoff
