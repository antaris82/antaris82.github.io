import CNNA.PillarC.BuildAll
