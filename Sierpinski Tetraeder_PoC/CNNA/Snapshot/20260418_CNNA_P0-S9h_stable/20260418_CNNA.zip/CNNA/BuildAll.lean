import CNNA.Notation
import CNNA.PillarA.BuildAll
import CNNA.Structural.BuildAll
