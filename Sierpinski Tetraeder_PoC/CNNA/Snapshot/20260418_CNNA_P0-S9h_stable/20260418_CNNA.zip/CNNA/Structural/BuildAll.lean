import CNNA.Structural.CayleyDickson.BuildAll
