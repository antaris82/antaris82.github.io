#!/usr/bin/env python3
"""Run or combine the branching-shift measurement.

The lightest reliable workflow is chunked:
  1. run birth-relative current for the desired branching/mode chunks,
  2. pass their birth_relative_mode_branching_comparison.csv files here with --input-mode-branching-csv.

If no input CSV is given, this runner computes birth-relative rows directly first.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities import (
    level_models,
    backreaction_current_rows,
    birth_relative_backreaction_rows,
    birth_relative_zero_crossing_rows,
    birth_relative_mode_branching_rows,
    branching_shift_curve_rows,
    branching_shift_summary_rows,
    read_csv_rows,
    write_branching_zero_crossing_shift_report,
)
from cnna.io.csv_writer import write_csv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA branching-shift measurement for birth-relative backreaction current")
    p.add_argument("--input-mode-branching-csv", nargs="*", type=Path, default=[])
    p.add_argument("--branching", nargs="+", type=int, default=[3, 4, 5, 6])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear"])
    p.add_argument("--max-regions", type=int, default=1)
    # b=6, L=6, sibling-cone terminal boundary is larger than the older 600 default.
    p.add_argument("--max-boundary", type=int, default=3500)
    p.add_argument("--max-interior", type=int, default=6000)
    p.add_argument("--directed-frontier-cap", type=int, default=6)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/branching_zero_crossing_branching_shift"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    if args.input_mode_branching_csv:
        mb = []
        for path in args.input_mode_branching_csv:
            mb.extend(read_csv_rows(path))
    else:
        models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
        base = backreaction_current_rows(models, args)
        birth = birth_relative_backreaction_rows(base)
        zero = birth_relative_zero_crossing_rows(birth)
        mb = birth_relative_mode_branching_rows(zero)
        write_csv(outdir / "branching_zero_crossing_source_mode_branching_comparison.csv", mb)

    curve = branching_shift_curve_rows(mb)
    summary = branching_shift_summary_rows(curve)
    write_csv(outdir / "branching_zero_crossing_branching_shift_curve.csv", curve)
    write_csv(outdir / "branching_zero_crossing_branching_shift_summary.csv", summary)
    write_branching_zero_crossing_shift_report(outdir, curve, summary)

    reference = next((r for r in summary if int(r.get("reference_model", 0)) == 1), summary[0] if summary else {})
    print(json.dumps({
        "condition": "branching_zero_crossing_branching_shift_measurement",
        "computed_status": reference.get("computed_status", "missing_summary"),
        "unmet_conditions": reference.get("unmet_conditions", "missing_summary"),
        "branching_values": reference.get("branching_values", "missing_summary"),
        "linear_zero_crossing_age_values": reference.get("linear_zero_crossing_age_values", "missing_summary"),
        "linear_zero_crossing_slope_per_branching": reference.get("linear_zero_crossing_slope_per_branching", "missing_summary"),
        "nearest_zero_age_all_three": reference.get("nearest_zero_age_all_three", "missing_summary"),
        "first_nonnegative_age_mode_stable": reference.get("first_nonnegative_age_mode_stable", "missing_summary"),
        "condition_note": "branching-shift is finite birth-relative measurement; live-record only; coarse-frontier rows excluded upstream; no vN/KMS/TypeIII statement",
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
