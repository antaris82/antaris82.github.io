# Row file routes

The documented source surface produces CSV row files through the root commands below. The ancillary package contains source and documentation files, not generated CSV outputs. Reproduction commands in the root article source `../../cnna_core_derived_documentation.tex` generate the row files in a user-selected output directory.

| Root command | Row surface |
|---|---|
| `run_cnna.py` | integrated growth, carrier, F1/F2, Schur, directed response, algebra/GNS, transport, and aggregation rows |
| `run_local_operator_property_checks.py` | local support, isotony, commutation, additivity, cyclicity, faithful state, Tomita, commutant, split, refined-basis, and entropy rows |
| `run_live_record_backreaction_current.py` | live-record backreaction current and its transport rows |
| `run_birth_relative_backreaction_current.py` | birth-relative current and skew-norm-difference crossing, mode/branching, and region-family rows |
| `run_branching_zero_crossing_shift.py` | branching comparison rows derived from birth-relative rows |
| `run_j_orientation_projectivity.py` | A/J orientation snapshots, transport, composition, and summary rows |
| `run_local_global_j_sign_relation.py` | global-boundary and local/global J-sign comparison rows |
| `package_consistency/check_finite_structure_theorems.py --write-csv ...` | six finite structural theorem/control rows |
| `run_nested_multiscale_handoff.py --output-dir ...` | nested carrier, corner handoff, composition, common-ambient Schur, and summary rows |

## Row files read by the document

### Integrated command

- `emptyset_genesis_measurement.csv`
- `level_count_measurement.csv`
- `eventlog_hashes.csv`
- `projection_grammar.csv`
- `carrier_projectivity.csv`
- `terminal_diagonal_state_measurement.csv`
- `terminal_diagonal_state_projectivity.csv`
- `birth_linearization_invariance.csv`
- `f1f2_skew_orientation_measurement.csv`
- `live_record_history_delta.csv`
- `regional_schur_dtn_response_measurement.csv`
- `directed_response_construction.csv`
- `directed_SA_decomposition.csv`
- `directed_skew_survival.csv`
- `directed_J_finite_object_comparison.csv`
- `response_algebra_measurement.csv`
- `finite_gns_pre_representation_measurement.csv`
- `finite_gns_cyclicity_controls.csv`
- `compressed_carrier_state_projectivity.csv`
- `gns_generator_transport_maps.csv`
- `algebra_projection_morphism_measurement.csv`
- `conditional_expectation_commuting_square.csv`
- `operator_stack_residuals_classification.csv`

### Local-operator command

- `local_operator_isotony.csv`
- `local_operator_commutation.csv`
- `local_operator_additivity.csv`
- `local_vacuum_cyclicity.csv`
- `faithful_state.csv`
- `commutant_duality.csv`
- `tomita_standard_form_compatibility.csv`
- `split_factorization.csv`
- `refined_port_basis_resolution.csv`
- `collared_split_refined_basis.csv`
- `record_live_relative_entropy.csv`
- `tomita_entropy_flow_alignment.csv`
- `multiscale_port_entropy_resolution.csv`

### A/J orientation command

- `A_J_orientation_snapshot.csv`
- `A_J_orientation_transport.csv`
- `A_J_orientation_composition.csv`

### Local/global sign command

- `j_sign_global_boundary_sign_relation.csv`
- `local_global_J_sign_comparison.csv`
- `J_sign_sign_relation_summary.csv`

### Backreaction commands

- `live_record_backreaction_current.csv`
- `backreaction_growth_profile.csv`
- `backreaction_transport.csv`
- `backreaction_current_summary.csv`
- `birth_relative_relative_backreaction_current.csv`
- `birth_relative_zero_crossing_by_region.csv`
- `birth_relative_mode_branching_comparison.csv`
- `birth_relative_backreaction_law_summary.csv`
- `branching_zero_crossing_branching_shift_curve.csv`
- `branching_zero_crossing_branching_shift_summary.csv`

### Finite structural theorem/control command

- `docs/FINITE_STRUCTURE_THEOREM_CONTROLS.csv`

### Nested multiscale handoff command

- `NESTED_MULTISCALE_CARRIER.csv`
- `NESTED_MULTISCALE_HANDOFF.csv`
- `NESTED_MULTISCALE_COMPOSITION.csv`
- `NESTED_MULTISCALE_COMMON_AMBIENT_SCHUR.csv`
- `NESTED_MULTISCALE_SUMMARY.csv`
