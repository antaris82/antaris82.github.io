# Finite data route

This file describes one finite route through the documented source surface.

```text
EmptySetGrowthModel(b, L, mode, growth_schedule)
-> live_edges / record_edges / sym readout
-> terminal carrier and prefix push-forward
-> F1/F2 whole-network current
-> Schur-DtN response on a finite boundary/interior cut
-> directed response and S/A split
-> finite J comparison on the S/A support
-> finite response algebra and full-basis GNS quotient audit
-> positive/negative GNS cyclicity controls
-> six finite structural theorem/control checks
-> nested first-order address-contrast carriers and nonunital corner handoff
-> common-ambient Schur associativity and independent-level drift separation
-> local support rows from object_checks
-> interlevel transport rows
-> live-record backreaction rows
-> birth-relative row transforms
```

A minimal constructor example is produced by:

```bash
PYTHONPATH=src python3 run_cnna.py   --branching 3   --levels 2   --modes linear   --states live record sym   --max-regions 1   --max-boundary 120   --max-interior 180   --directed-frontier-cap 4   --algebra-tol 1e-10   --algebra-max-iter 4   --gns-tol 1e-10   --growth-schedule layer_batch   --outdir outputs/minimal_finite_route
```

The produced CSV files are finite row surfaces. They are measurements or residual records for the selected input tuple.

The GNS audit computes the explicit rank of the full algebra action on the
identity class, checks every stored basis element, and emits independent proper-
subalgebra negative controls. Entropy support is resolved at the declared
scale-aware tolerance; backreaction zero-crossing rows concern the scalar
skew-norm difference, not a zero of the matrix current.

## Exact finite proof boundary

The script `package_consistency/check_finite_structure_theorems.py` checks the
implementation hypotheses used by the article's finite well-definedness,
symmetric Schur-positivity, finite GNS, orientation-reversal, backreaction
separation, and prefix-handoff statements. It can regenerate
`docs/FINITE_STRUCTURE_THEOREM_CONTROLS.csv`. The legacy label-span map is not promoted to a homomorphism. The separate script `package_consistency/check_nested_multiscale_handoff.py` proves and tests an exact nonunital carrier/corner handoff on a growing multiscale role family, while retaining non-zero response, independently reconstructed state, GNS, and finite-`J` naturality residuals as distinct finite observations.
