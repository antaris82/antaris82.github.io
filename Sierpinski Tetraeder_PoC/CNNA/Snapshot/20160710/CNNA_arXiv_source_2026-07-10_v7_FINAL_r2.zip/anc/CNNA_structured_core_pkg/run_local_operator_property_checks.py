#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable, Sequence

from cnna.io.csv_writer import write_csv
from cnna.core.operator_test_config import OperatorTestConfig
from cnna.object_checks.finite_property_inventory import finite_finite_property_inventory_rows, previous_reproduction_measurement_rows, finite_property_inventory_report
from cnna.object_checks.finite_region_net import region_grammar_rows, region_inclusion_rows, region_poset_summary, region_net_report
from cnna.object_checks.local_operator_isotony import local_operator_isotony_rows, isotony_report
from cnna.object_checks.local_operator_commutation import local_operator_commutator_rows, commutation_report
from cnna.object_checks.local_operator_additivity import local_operator_additivity_rows, additivity_report
from cnna.object_checks.local_vacuum_cyclicity import local_vacuum_cyclicity_rows, cyclicity_report
from cnna.object_checks.faithful_state import faithful_state_rows, faithful_state_report
from cnna.object_checks.support_state_summary import support_state_summary_rows, support_state_summary_report
from cnna.object_checks.tomita_standard_form import tomita_standard_form_rows, tomita_report
from cnna.object_checks.commutant_duality import commutant_duality_rows, commutant_report
from cnna.object_checks.split_factorization import split_factorization_rows, split_report
from cnna.object_checks.genealogical_corridor_commutation import genealogical_corridor_commutator_rows, genealogical_corridor_commutation_report
from cnna.object_checks.genealogical_corridor_split import genealogical_corridor_split_rows, genealogical_corridor_split_report
from cnna.object_checks.modular_spectrum_trajectory import modular_spectrum_trajectory_rows, modular_spectrum_trajectory_report
from cnna.object_checks.cyclicity_dimension_rank_bound import cyclicity_dimension_rank_bound_rows, cyclicity_dimension_rank_bound_report
from cnna.object_checks.relative_common_ambient_schur_isotony import relative_common_ambient_schur_isotony_rows, relative_common_ambient_schur_isotony_report
from cnna.object_checks.commutator_decay_by_genealogical_distance import commutator_decay_by_genealogical_distance_rows, commutator_decay_by_genealogical_distance_report
from cnna.object_checks.split_residual_by_collar_width import split_residual_by_collar_width_rows, split_residual_by_collar_width_report
from cnna.object_checks.modular_ratio_trajectory_by_level import modular_ratio_trajectory_by_level_rows, modular_ratio_trajectory_by_level_report
from cnna.object_checks.support_rank_trajectory import support_rank_trajectory_rows, support_rank_trajectory_report
from cnna.object_checks.observable_state_rows import observable_state_rows_rows, observable_state_rows_report
from cnna.object_checks.record_anchor_consistency import record_anchor_consistency_rows, record_anchor_consistency_report
from cnna.object_checks.backreaction_current_localization import backreaction_current_localization_rows, backreaction_current_localization_report
from cnna.object_checks.live_current_property_summary import live_current_property_summary_rows, live_current_property_summary_report
from cnna.object_checks.record_live_relative_entropy import record_live_relative_entropy_rows, record_live_relative_entropy_report
from cnna.object_checks.history_live_common_measure import history_live_common_measure_rows, history_live_common_measure_report
from cnna.object_checks.live_current_cluster_scaling import live_current_cluster_scaling_rows, live_current_cluster_scaling_report
from cnna.object_checks.finite_complement_relations import finite_complement_relations_rows, finite_complement_relations_report
from cnna.object_checks.refined_port_basis_resolution import refined_port_basis_resolution_rows, refined_port_basis_resolution_report
from cnna.object_checks.collared_split_refined_basis import collared_split_refined_basis_rows, collared_split_refined_basis_report
from cnna.object_checks.tomita_entropy_flow_alignment import tomita_entropy_flow_alignment_rows, tomita_entropy_flow_alignment_report

from cnna.object_checks.entropy_ordered_locality import entropy_ordered_locality_rows, entropy_ordered_locality_report
from cnna.object_checks.entropy_ordered_split import entropy_ordered_split_rows, entropy_ordered_split_report
from cnna.object_checks.entropy_ordered_complement import entropy_ordered_complement_rows, entropy_ordered_complement_report
from cnna.object_checks.modular_entropy_backreaction_direction import modular_entropy_backreaction_direction_rows, modular_entropy_backreaction_direction_report
from cnna.object_checks.multiscale_port_entropy_resolution import multiscale_port_entropy_resolution_rows, multiscale_port_entropy_resolution_report
from cnna.object_checks.extended_entropy_level_trajectory import extended_entropy_level_trajectory_rows, extended_entropy_level_trajectory_report
from cnna.object_checks.entropy_measure_parameter_sensitivity import entropy_measure_parameter_sensitivity_rows, entropy_measure_parameter_sensitivity_report
from cnna.object_checks.f1_f2_oriented_history_measure import f1_f2_oriented_history_measure_rows, f1_f2_oriented_history_measure_report
from cnna.object_checks.entropy_gradient_current import entropy_gradient_current_rows, entropy_gradient_current_report
from cnna.object_checks.entropy_normalized_geometry import entropy_normalized_geometry_rows, entropy_normalized_geometry_report
from cnna.object_checks.refined_port_coarse_consistency import refined_port_coarse_consistency_rows, refined_port_coarse_consistency_report
from cnna.object_checks.f1_f2_orientation_resolution import f1_f2_orientation_resolution_rows, f1_f2_orientation_resolution_report
from cnna.object_checks.two_component_history_measure import two_component_history_measure_rows, two_component_history_measure_report
from cnna.object_checks.oriented_history_geometry import oriented_history_geometry_rows, oriented_history_geometry_report
from cnna.object_checks.oriented_history_measure_geometry_summary import oriented_history_measure_geometry_summary_rows, oriented_history_measure_geometry_summary_report

from cnna.object_checks.fixed_oriented_history_measure import fixed_oriented_history_measure_rows, fixed_oriented_history_measure_report
from cnna.object_checks.destroyed_history_oriented_geometry import destroyed_history_oriented_geometry_rows, destroyed_history_oriented_geometry_report
from cnna.object_checks.fixed_measure_ratio_summary import fixed_measure_ratio_summary_rows, fixed_measure_ratio_summary_report
from cnna.object_checks.history_measure_level_mode_dependence import history_measure_level_mode_dependence_rows, history_measure_level_mode_dependence_report
from cnna.object_checks.oriented_geometry_level_mode_dependence import oriented_geometry_level_mode_dependence_rows, oriented_geometry_level_mode_dependence_report
from cnna.object_checks.level_mode_dependence_summary import level_mode_dependence_summary_rows, level_mode_dependence_summary_report
from cnna.object_checks.mode_ablation_signature import mode_ablation_signature_rows, mode_ablation_signature_report
from cnna.object_checks.mode_ablated_measure_summary import mode_ablated_measure_summary_rows, mode_ablated_measure_summary_report
from cnna.object_checks.f1f2_signature_mode_comparison import f1f2_signature_mode_comparison_rows, f1f2_signature_mode_comparison_report, mode_mode_stable_f1f2_signature_summary_rows, mode_mode_stable_f1f2_signature_summary_report
from cnna.object_checks.signature_strength_decomposed_measure import signature_strength_decomposed_measure_rows, signature_strength_decomposed_measure_report
from cnna.object_checks.decomposed_geometry_quantities import decomposed_geometry_quantities_rows, decomposed_geometry_quantities_report
from cnna.object_checks.decomposed_entropy_flow import decomposed_entropy_flow_rows, decomposed_entropy_flow_report
from cnna.object_checks.signature_strength_geometry_summary import signature_strength_geometry_summary_rows, signature_strength_geometry_summary_report
from cnna.object_checks.f1f2_oriented_geometry_replacement import f1f2_oriented_geometry_replacement_rows, f1f2_oriented_geometry_replacement_summary_rows, f1f2_oriented_geometry_replacement_report
from cnna.object_checks.four_path_transition_matrix import four_path_transition_matrix_rows, four_path_dependency_table_priority_rows, four_path_literature_bridge_rows, closed_finite_results_rows, external_measurement_assessment_rows, consistency_prerequisite_rows, presentation_selection_rows, four_path_transition_report, closed_results_report
from cnna.object_checks.deformed_fractal_bridge import deformed_fractal_bridge_rows, deformed_fractal_bridge_report
from cnna.object_checks.core_construction_dependencies import core_theory_construction_rows, presentation_mainline_rows, core_theory_construction_report, presentation_mainline_report

from cnna.object_checks.fock_aqft_bridge import fock_aqft_bridge_comparison_register_rows, fock_aqft_one_particle_comparison_rows, fock_aqft_bridge_report
from cnna.object_checks.bianconi_simplicial_statistics_bridge import bianconi_statistics_bridge_condition_rows, bianconi_branching_sector_expectation_rows, bianconi_statistics_bridge_report
from cnna.object_checks.stack_dependency_conditions import topology_precedence_rows, stack_layer_rows, stack_transition_rows, condition_register_rows, cfs_cross_axis_rows, input_exclusion_rule_rows, stack_architecture_report, condition_register_report


def _ints(xs: Sequence[str]) -> tuple[int, ...]:
    return tuple(int(x) for x in xs)


def _strings(xs: Sequence[str]) -> tuple[str, ...]:
    return tuple(str(x) for x in xs)


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="finite CNNA local-operator property comparison runner")
    ap.add_argument("--branching", nargs="+", default=["3"], help="branching arities b")
    ap.add_argument("--levels", nargs="+", default=["4"], help="finite terminal levels L")
    ap.add_argument("--modes", nargs="+", default=["linear"], choices=["linear", "log", "saturating"])
    ap.add_argument("--states", nargs="+", default=["live", "record", "sym"], choices=["live", "record", "sym"])
    ap.add_argument("--max-regions", type=int, default=1)
    ap.add_argument("--max-boundary", type=int, default=600)
    ap.add_argument("--max-interior", type=int, default=900)
    ap.add_argument("--directed-frontier-cap", type=int, default=6)
    ap.add_argument("--algebra-tol", type=float, default=1.0e-10)
    ap.add_argument("--rank-tol", type=float, default=1.0e-9)
    ap.add_argument("--max-algebra-iter", type=int, default=8)
    ap.add_argument("--tomita-matrix-sign_relations", nargs="+", default=["out_degree"], choices=["out_degree", "in_degree"], help="matrix sign_relations swept only by the Tomita/CNNA compatibility surface")
    ap.add_argument("--growth-schedule", default="layer_batch", choices=["slot_step", "layer_batch"], help="growth schedule used by EmptySetGrowthModel")
    ap.add_argument("--outdir", default="outputs/local_operator_property_tests")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    config = OperatorTestConfig(
        branching=_ints(args.branching),
        levels=_ints(args.levels),
        modes=_strings(args.modes),
        states=_strings(args.states),
        max_regions=int(args.max_regions),
        max_boundary=int(args.max_boundary),
        max_interior=int(args.max_interior),
        directed_frontier_cap=int(args.directed_frontier_cap),
        algebra_tol=float(args.algebra_tol),
        rank_tol=float(args.rank_tol),
        max_algebra_iter=int(args.max_algebra_iter),
        tomita_matrix_sign_relations=_strings(args.tomita_matrix_sign_relations),
        growth_schedule=str(args.growth_schedule),
    )
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    inventory = finite_finite_property_inventory_rows()
    reproduction = previous_reproduction_measurement_rows()
    write_csv(out / "finite_finite_property_inventory.csv", inventory)
    write_csv(out / "previous_reproduction_measurement.csv", reproduction)
    (out / "FINITE_PROPERTY_INVENTORY_REPORT.md").write_text(finite_property_inventory_report(), encoding="utf-8")

    grammar = region_grammar_rows(config)
    inclusion = region_inclusion_rows(config)
    poset = region_poset_summary(inclusion)
    write_csv(out / "finite_region_net_grammar.csv", grammar)
    write_csv(out / "finite_region_inclusion_poset.csv", inclusion)
    write_csv(out / "finite_region_poset_summary.csv", poset)
    (out / "FINITE_REGION_NET_GRAMMAR_REPORT.md").write_text(region_net_report(poset), encoding="utf-8")

    observable_state_rows = observable_state_rows_rows(config)
    write_csv(out / "observable_state_relations.csv", observable_state_rows)
    (out / "OBSERVABLE_STATE_RELATIONS_REPORT.md").write_text(observable_state_rows_report(observable_state_rows), encoding="utf-8")

    isotony = local_operator_isotony_rows(config)
    write_csv(out / "local_operator_isotony.csv", isotony)
    (out / "LOCAL_OPERATOR_ISOTONY_REPORT.md").write_text(isotony_report(isotony), encoding="utf-8")

    commutation = local_operator_commutator_rows(config)
    write_csv(out / "local_operator_commutation.csv", commutation)
    (out / "LOCAL_OPERATOR_COMMUTATION_REPORT.md").write_text(commutation_report(commutation), encoding="utf-8")

    additivity = local_operator_additivity_rows(config)
    write_csv(out / "local_operator_additivity.csv", additivity)
    (out / "LOCAL_OPERATOR_ADDITIVITY_REPORT.md").write_text(additivity_report(additivity), encoding="utf-8")

    cyclicity = local_vacuum_cyclicity_rows(config)
    write_csv(out / "local_vacuum_cyclicity.csv", cyclicity)
    (out / "LOCAL_VACUUM_CYCLICITY_REPORT.md").write_text(cyclicity_report(cyclicity), encoding="utf-8")

    faithfulness = faithful_state_rows(config)
    write_csv(out / "faithful_state.csv", faithfulness)
    (out / "FAITHFUL_STATE_REPORT.md").write_text(faithful_state_report(faithfulness), encoding="utf-8")

    support_summary = support_state_summary_rows(config)
    write_csv(out / "support_vs_full_state_summary.csv", support_summary)
    (out / "SUPPORT_VS_FULL_STATE_SUMMARY_REPORT.md").write_text(support_state_summary_report(support_summary), encoding="utf-8")

    tomita = tomita_standard_form_rows(config)
    write_csv(out / "tomita_standard_form_compatibility.csv", tomita)
    (out / "TOMITA_STANDARD_FORM_COMPATIBILITY_REPORT.md").write_text(tomita_report(tomita), encoding="utf-8")

    commutant = commutant_duality_rows(config)
    write_csv(out / "commutant_duality.csv", commutant)
    (out / "COMMUTANT_DUALITY_REPORT.md").write_text(commutant_report(commutant), encoding="utf-8")

    split = split_factorization_rows(config)
    write_csv(out / "split_factorization.csv", split)
    (out / "SPLIT_FACTORIZATION_REPORT.md").write_text(split_report(split), encoding="utf-8")

    corridor_commutation = genealogical_corridor_commutator_rows(config)
    write_csv(out / "genealogical_corridor_commutation.csv", corridor_commutation)
    (out / "GENEALOGICAL_CORRIDOR_COMMUTATION_REPORT.md").write_text(genealogical_corridor_commutation_report(corridor_commutation), encoding="utf-8")

    corridor_split = genealogical_corridor_split_rows(config)
    write_csv(out / "genealogical_corridor_split.csv", corridor_split)
    (out / "GENEALOGICAL_CORRIDOR_SPLIT_REPORT.md").write_text(genealogical_corridor_split_report(corridor_split), encoding="utf-8")

    modular_trajectory = modular_spectrum_trajectory_rows(config)
    write_csv(out / "modular_spectrum_trajectory.csv", modular_trajectory)
    (out / "MODULAR_SPECTRUM_TRAJECTORY_REPORT.md").write_text(modular_spectrum_trajectory_report(modular_trajectory), encoding="utf-8")

    cyclicity_dimension = cyclicity_dimension_rank_bound_rows(config)
    write_csv(out / "cyclicity_dimension_rank_bound.csv", cyclicity_dimension)
    (out / "FINITE_CYCLICITY_DIMENSION_OBSTRUCTION_REPORT.md").write_text(cyclicity_dimension_rank_bound_report(cyclicity_dimension), encoding="utf-8")

    relative_common_ambient = relative_common_ambient_schur_isotony_rows(config)
    write_csv(out / "relative_common_ambient_schur_isotony.csv", relative_common_ambient)
    (out / "RELATIVE_COMMON_AMBIENT_SCHUR_ISOTONY_REPORT.md").write_text(relative_common_ambient_schur_isotony_report(relative_common_ambient), encoding="utf-8")

    commutator_decay = commutator_decay_by_genealogical_distance_rows(config)
    write_csv(out / "commutator_decay_by_genealogical_distance.csv", commutator_decay)
    (out / "COMMUTATOR_DECAY_BY_GENEALOGICAL_DISTANCE_REPORT.md").write_text(commutator_decay_by_genealogical_distance_report(commutator_decay), encoding="utf-8")

    split_residual_scaling = split_residual_by_collar_width_rows(config)
    write_csv(out / "split_residual_by_collar_width.csv", split_residual_scaling)
    (out / "SPLIT_DEFECT_BY_COLLAR_WIDTH_REPORT.md").write_text(split_residual_by_collar_width_report(split_residual_scaling), encoding="utf-8")

    modular_ratio_levels = modular_ratio_trajectory_by_level_rows(config)
    write_csv(out / "modular_ratio_trajectory_by_level.csv", modular_ratio_levels)
    (out / "MODULAR_RATIO_TRAJECTORY_BY_LEVEL_REPORT.md").write_text(modular_ratio_trajectory_by_level_report(modular_ratio_levels), encoding="utf-8")

    support_rank_levels = support_rank_trajectory_rows(config)
    write_csv(out / "support_rank_trajectory.csv", support_rank_levels)
    (out / "SUPPORT_RANK_TRAJECTORY_REPORT.md").write_text(support_rank_trajectory_report(support_rank_levels), encoding="utf-8")

    record_anchor = record_anchor_consistency_rows(config)
    write_csv(out / "record_anchor_consistency.csv", record_anchor)
    (out / "RECORD_ANCHOR_CONSISTENCY_REPORT.md").write_text(record_anchor_consistency_report(record_anchor), encoding="utf-8")

    backreaction_current = backreaction_current_localization_rows(config)
    write_csv(out / "backreaction_current_localization.csv", backreaction_current)
    (out / "BACKREACTION_CURRENT_LOCALIZATION_REPORT.md").write_text(backreaction_current_localization_report(backreaction_current), encoding="utf-8")

    record_live_entropy = record_live_relative_entropy_rows(config)
    write_csv(out / "record_live_relative_entropy.csv", record_live_entropy)
    (out / "RECORD_LIVE_RELATIVE_ENTROPY_REPORT.md").write_text(record_live_relative_entropy_report(record_live_entropy), encoding="utf-8")

    history_live_measure = history_live_common_measure_rows(config)
    write_csv(out / "history_live_common_measure.csv", history_live_measure)
    (out / "HISTORY_LIVE_COMMON_MEASURE_REPORT.md").write_text(history_live_common_measure_report(history_live_measure), encoding="utf-8")

    live_cluster_scaling = live_current_cluster_scaling_rows(config)
    write_csv(out / "live_current_cluster_scaling.csv", live_cluster_scaling)
    (out / "LIVE_CURRENT_CLUSTER_SCALING_REPORT.md").write_text(live_current_cluster_scaling_report(live_cluster_scaling), encoding="utf-8")

    finite_complements = finite_complement_relations_rows(config)
    write_csv(out / "finite_complement_relations.csv", finite_complements)
    (out / "FINITE_COMPLEMENT_RELATIONS_REPORT.md").write_text(finite_complement_relations_report(finite_complements), encoding="utf-8")

    refined_basis = refined_port_basis_resolution_rows(config)
    write_csv(out / "refined_port_basis_resolution.csv", refined_basis)
    (out / "REFINED_PORT_BASIS_RESOLUTION_REPORT.md").write_text(refined_port_basis_resolution_report(refined_basis), encoding="utf-8")

    refined_split = collared_split_refined_basis_rows(config)
    write_csv(out / "collared_split_refined_basis.csv", refined_split)
    (out / "COLLARED_SPLIT_REFINED_BASIS_REPORT.md").write_text(collared_split_refined_basis_report(refined_split), encoding="utf-8")

    tomita_entropy_flow = tomita_entropy_flow_alignment_rows(config)
    write_csv(out / "tomita_entropy_flow_alignment.csv", tomita_entropy_flow)
    (out / "TOMITA_ENTROPY_FLOW_ALIGNMENT_REPORT.md").write_text(tomita_entropy_flow_alignment_report(tomita_entropy_flow), encoding="utf-8")

    entropy_locality = entropy_ordered_locality_rows(history_live_measure, live_cluster_scaling, tol=config.algebra_tol)
    write_csv(out / "entropy_ordered_locality.csv", entropy_locality)
    (out / "ENTROPY_ORDERED_LOCALITY_REPORT.md").write_text(entropy_ordered_locality_report(entropy_locality), encoding="utf-8")

    entropy_split = entropy_ordered_split_rows(history_live_measure, refined_split, tol=config.algebra_tol)
    write_csv(out / "entropy_ordered_split.csv", entropy_split)
    (out / "ENTROPY_ORDERED_SPLIT_REPORT.md").write_text(entropy_ordered_split_report(entropy_split), encoding="utf-8")

    entropy_complement = entropy_ordered_complement_rows(history_live_measure, finite_complements, tol=config.algebra_tol)
    write_csv(out / "entropy_ordered_complement.csv", entropy_complement)
    (out / "ENTROPY_ORDERED_COMPLEMENT_REPORT.md").write_text(entropy_ordered_complement_report(entropy_complement), encoding="utf-8")

    modular_entropy_backreaction = modular_entropy_backreaction_direction_rows(history_live_measure, tomita, tol=config.algebra_tol)
    write_csv(out / "modular_entropy_backreaction_direction.csv", modular_entropy_backreaction)
    (out / "MODULAR_ENTROPY_BACKREACTION_DIRECTION_REPORT.md").write_text(modular_entropy_backreaction_direction_report(modular_entropy_backreaction), encoding="utf-8")

    multiscale_entropy_resolution = multiscale_port_entropy_resolution_rows(config)
    write_csv(out / "multiscale_port_entropy_resolution.csv", multiscale_entropy_resolution)
    (out / "MULTISCALE_PORT_ENTROPY_RESOLUTION_REPORT.md").write_text(multiscale_port_entropy_resolution_report(multiscale_entropy_resolution), encoding="utf-8")

    extended_entropy_trajectory = extended_entropy_level_trajectory_rows(history_live_measure, tol=config.algebra_tol)
    write_csv(out / "extended_entropy_level_trajectory.csv", extended_entropy_trajectory)
    (out / "EXTENDED_ENTROPY_LEVEL_TRAJECTORY_REPORT.md").write_text(extended_entropy_level_trajectory_report(extended_entropy_trajectory), encoding="utf-8")

    entropy_measure_parameter_sensitivity = entropy_measure_parameter_sensitivity_rows(config)
    write_csv(out / "entropy_measure_parameter_sensitivity.csv", entropy_measure_parameter_sensitivity)
    (out / "ENTROPY_MEASURE_PARAMETER_SENSITIVITY_REPORT.md").write_text(entropy_measure_parameter_sensitivity_report(entropy_measure_parameter_sensitivity), encoding="utf-8")

    f1f2_oriented_measure = f1_f2_oriented_history_measure_rows(config)
    write_csv(out / "f1_f2_oriented_history_measure.csv", f1f2_oriented_measure)
    (out / "F1_F2_ORIENTED_HISTORY_MEASURE_REPORT.md").write_text(f1_f2_oriented_history_measure_report(f1f2_oriented_measure), encoding="utf-8")

    entropy_gradient_current = entropy_gradient_current_rows(history_live_measure, tol=config.algebra_tol)
    write_csv(out / "entropy_gradient_current.csv", entropy_gradient_current)
    (out / "ENTROPY_GRADIENT_CURRENT_REPORT.md").write_text(entropy_gradient_current_report(entropy_gradient_current), encoding="utf-8")

    entropy_normalized_geometry = entropy_normalized_geometry_rows(history_live_measure, live_cluster_scaling, refined_split, finite_complements, tol=config.algebra_tol)
    write_csv(out / "entropy_normalized_geometry.csv", entropy_normalized_geometry)
    (out / "ENTROPY_NORMALIZED_GEOMETRY_REPORT.md").write_text(entropy_normalized_geometry_report(entropy_normalized_geometry), encoding="utf-8")

    refined_coarse_consistency = refined_port_coarse_consistency_rows(config)
    write_csv(out / "refined_port_coarse_consistency.csv", refined_coarse_consistency)
    (out / "REFINED_PORT_COARSE_CONSISTENCY_REPORT.md").write_text(refined_port_coarse_consistency_report(refined_coarse_consistency), encoding="utf-8")

    f1f2_orientation_resolution = f1_f2_orientation_resolution_rows(config)
    write_csv(out / "f1_f2_orientation_resolution.csv", f1f2_orientation_resolution)
    (out / "F1_F2_ORIENTATION_RESOLUTION_REPORT.md").write_text(f1_f2_orientation_resolution_report(f1f2_orientation_resolution), encoding="utf-8")

    two_component_measure = two_component_history_measure_rows(history_live_measure, f1f2_orientation_resolution, tol=config.algebra_tol)
    write_csv(out / "two_component_history_measure.csv", two_component_measure)
    (out / "TWO_COMPONENT_HISTORY_MEASURE_REPORT.md").write_text(two_component_history_measure_report(two_component_measure), encoding="utf-8")

    oriented_history_geometry = oriented_history_geometry_rows(two_component_measure, live_cluster_scaling, refined_split, finite_complements, tol=config.algebra_tol)
    write_csv(out / "oriented_history_geometry.csv", oriented_history_geometry)
    (out / "ORIENTED_HISTORY_GEOMETRY_REPORT.md").write_text(oriented_history_geometry_report(oriented_history_geometry), encoding="utf-8")

    oriented_history_summary = oriented_history_measure_geometry_summary_rows(two_component_measure, oriented_history_geometry)
    write_csv(out / "oriented_history_measure_geometry_summary.csv", oriented_history_summary)
    (out / "ORIENTED_HISTORY_MEASURE_GEOMETRY_SUMMARY_REPORT.md").write_text(oriented_history_measure_geometry_summary_report(oriented_history_summary), encoding="utf-8")

    fixed_oriented_measure = fixed_oriented_history_measure_rows(two_component_measure, tol=config.algebra_tol)
    write_csv(out / "fixed_oriented_history_measure.csv", fixed_oriented_measure)
    (out / "FIXED_ORIENTED_HISTORY_MEASURE_REPORT.md").write_text(fixed_oriented_history_measure_report(fixed_oriented_measure), encoding="utf-8")

    destroyed_history_geometry = destroyed_history_oriented_geometry_rows(fixed_oriented_measure, f1f2_orientation_resolution, oriented_history_geometry, tol=config.algebra_tol)
    write_csv(out / "destroyed_history_oriented_geometry.csv", destroyed_history_geometry)
    (out / "DESTROYED_HISTORY_ORIENTED_GEOMETRY_REPORT.md").write_text(destroyed_history_oriented_geometry_report(destroyed_history_geometry), encoding="utf-8")

    fixed_ratio_summary = fixed_measure_ratio_summary_rows(fixed_oriented_measure, destroyed_history_geometry)
    write_csv(out / "fixed_measure_ratio_summary.csv", fixed_ratio_summary)
    (out / "FIXED_MEASURE_RATIO_SUMMARY_REPORT.md").write_text(fixed_measure_ratio_summary_report(fixed_ratio_summary), encoding="utf-8")

    level_mode_parameter_dependence = history_measure_level_mode_dependence_rows(config)
    write_csv(out / "history_measure_level_mode_dependence.csv", level_mode_parameter_dependence)
    (out / "LEVEL_MODE_HISTORY_PARAMETER_DEPENDENCE_REPORT.md").write_text(history_measure_level_mode_dependence_report(level_mode_parameter_dependence), encoding="utf-8")

    level_mode_geometry_parameter_dependence = oriented_geometry_level_mode_dependence_rows(level_mode_parameter_dependence, oriented_history_geometry, tol=config.algebra_tol)
    write_csv(out / "oriented_geometry_level_mode_dependence.csv", level_mode_geometry_parameter_dependence)
    (out / "LEVEL_MODE_ORIENTED_GEOMETRY_PARAMETER_DEPENDENCE_REPORT.md").write_text(oriented_geometry_level_mode_dependence_report(level_mode_geometry_parameter_dependence), encoding="utf-8")

    level_mode_summary = level_mode_dependence_summary_rows(level_mode_parameter_dependence, level_mode_geometry_parameter_dependence)
    write_csv(out / "level_mode_dependence_summary.csv", level_mode_summary)
    (out / "LEVEL_MODE_PARAMETER_DEPENDENCE_SUMMARY_REPORT.md").write_text(level_mode_dependence_summary_report(level_mode_summary), encoding="utf-8")

    mode_ablation_signature = mode_ablation_signature_rows(config)
    write_csv(out / "mode_ablation_signature.csv", mode_ablation_signature)
    (out / "MODE_ABLATION_SIGNATURE_REPORT.md").write_text(mode_ablation_signature_report(mode_ablation_signature), encoding="utf-8")

    mode_ablated_summary = mode_ablated_measure_summary_rows(mode_ablation_signature, level_mode_parameter_dependence)
    write_csv(out / "mode_ablated_measure_summary.csv", mode_ablated_summary)
    (out / "MODE_ABLATED_MEASURE_SUMMARY_REPORT.md").write_text(mode_ablated_measure_summary_report(mode_ablated_summary), encoding="utf-8")

    mode_mode_stable_signature = f1f2_signature_mode_comparison_rows(config)
    write_csv(out / "f1f2_signature_mode_comparison.csv", mode_mode_stable_signature)
    (out / "MODE_MODE_STABLE_F1F2_SIGNATURE_COMPARISON_RUN_REPORT.md").write_text(f1f2_signature_mode_comparison_report(mode_mode_stable_signature), encoding="utf-8")

    mode_mode_stable_signature_summary = mode_mode_stable_f1f2_signature_summary_rows(mode_mode_stable_signature)
    write_csv(out / "mode_mode_stable_f1f2_signature_summary.csv", mode_mode_stable_signature_summary)
    (out / "MODE_MODE_STABLE_F1F2_SIGNATURE_SUMMARY_REPORT.md").write_text(mode_mode_stable_f1f2_signature_summary_report(mode_mode_stable_signature_summary), encoding="utf-8")

    signature_strength_decomposed = signature_strength_decomposed_measure_rows(history_live_measure, f1f2_orientation_resolution, mode_ablation_signature, tol=config.algebra_tol)
    write_csv(out / "signature_strength_decomposed_measure.csv", signature_strength_decomposed)
    (out / "SIGNATURE_STRENGTH_DECOMPOSED_MEASURE_REPORT.md").write_text(signature_strength_decomposed_measure_report(signature_strength_decomposed), encoding="utf-8")

    decomposed_geometry = decomposed_geometry_quantities_rows(signature_strength_decomposed, live_cluster_scaling, refined_split, finite_complements, tol=config.algebra_tol)
    write_csv(out / "decomposed_geometry_quantities.csv", decomposed_geometry)
    (out / "DECOMPOSED_GEOMETRY_DIAGNOSTICS_REPORT.md").write_text(decomposed_geometry_quantities_report(decomposed_geometry), encoding="utf-8")

    decomposed_flow = decomposed_entropy_flow_rows(signature_strength_decomposed, tol=config.algebra_tol)
    write_csv(out / "decomposed_entropy_flow.csv", decomposed_flow)
    (out / "DECOMPOSED_ENTROPY_FLOW_REPORT.md").write_text(decomposed_entropy_flow_report(decomposed_flow), encoding="utf-8")

    signature_strength_summary = signature_strength_geometry_summary_rows(signature_strength_decomposed, decomposed_geometry, decomposed_flow)
    write_csv(out / "signature_strength_geometry_summary.csv", signature_strength_summary)
    (out / "SIGNATURE_STRENGTH_GEOMETRY_SUMMARY_REPORT.md").write_text(signature_strength_geometry_summary_report(signature_strength_summary), encoding="utf-8")

    f1f2_geometry_replacement = f1f2_oriented_geometry_replacement_rows(signature_strength_decomposed, decomposed_geometry, f1f2_orientation_resolution, tol=config.algebra_tol)
    f1f2_geometry_replacement_summary = f1f2_oriented_geometry_replacement_summary_rows(f1f2_geometry_replacement)
    write_csv(out / "f1f2_oriented_geometry_replacement.csv", f1f2_geometry_replacement)
    write_csv(out / "f1f2_oriented_geometry_replacement_summary.csv", f1f2_geometry_replacement_summary)
    (out / "F1F2_ORIENTED_GEOMETRY_REPLACEMENT_REPORT.md").write_text(f1f2_oriented_geometry_replacement_report(f1f2_geometry_replacement, f1f2_geometry_replacement_summary), encoding="utf-8")

    four_path_transition = four_path_transition_matrix_rows()
    four_path_priorities = four_path_dependency_table_priority_rows()
    four_path_literature = four_path_literature_bridge_rows()
    fock_bridge_register = fock_aqft_bridge_comparison_register_rows()
    fock_one_particle_comparisons = fock_aqft_one_particle_comparison_rows(config)
    bianconi_conditions = bianconi_statistics_bridge_condition_rows()
    bianconi_branching_expectations = bianconi_branching_sector_expectation_rows(config)
    closed_finite_results = closed_finite_results_rows()
    external_measurement = external_measurement_assessment_rows()
    prerequisites = consistency_prerequisite_rows()
    presentation_selection = presentation_selection_rows()
    deformed_fractal_bridge = deformed_fractal_bridge_rows()
    core_theory_construction = core_theory_construction_rows()
    presentation_mainline = presentation_mainline_rows()
    topology_precedence = topology_precedence_rows()
    stack_layers = stack_layer_rows()
    stack_transitions = stack_transition_rows()
    condition_register = condition_register_rows()
    cfs_cross_axis = cfs_cross_axis_rows()
    input_exclusion_rules = input_exclusion_rule_rows()
    write_csv(out / "four_path_transition_matrix.csv", four_path_transition)
    write_csv(out / "four_path_dependency_table_priorities.csv", four_path_priorities)
    write_csv(out / "four_path_literature_bridge.csv", four_path_literature)
    write_csv(out / "aqft_form_layer_comparison_register.csv", fock_bridge_register)
    write_csv(out / "aqft_one_particle_form_comparisons.csv", fock_one_particle_comparisons)
    write_csv(out / "bianconi_statistics_bridge_conditions.csv", bianconi_conditions)
    write_csv(out / "bianconi_branching_sector_expectations.csv", bianconi_branching_expectations)
    write_csv(out / "closed_finite_results_finite_results.csv", closed_finite_results)
    write_csv(out / "external_measurement_assessment.csv", external_measurement)
    write_csv(out / "consistency_prerequisites.csv", prerequisites)
    write_csv(out / "presentation_selection_manifest.csv", presentation_selection)
    write_csv(out / "deformed_fractal_bridge.csv", deformed_fractal_bridge)
    write_csv(out / "core_construction_dependencies.csv", core_theory_construction)
    write_csv(out / "presentation_mainline_manifest.csv", presentation_mainline)
    write_csv(out / "topology_precedence.csv", topology_precedence)
    write_csv(out / "stack_layers.csv", stack_layers)
    write_csv(out / "stack_transitions.csv", stack_transitions)
    write_csv(out / "stack_dependency_conditions.csv", condition_register)
    write_csv(out / "cfs_cross_axis_measure_register.csv", cfs_cross_axis)
    write_csv(out / "input_exclusion_rules.csv", input_exclusion_rules)
    (out / "FOUR_PATH_TRANSITION_MATRIX_REPORT.md").write_text(four_path_transition_report(), encoding="utf-8")
    (out / "AQFT_FORM_LAYER_BRIDGE_DEPENDENCY_TABLE_REPORT.md").write_text(fock_aqft_bridge_report(fock_bridge_register, fock_one_particle_comparisons), encoding="utf-8")
    (out / "BIANCONI_STATISTICS_BRIDGE_DEPENDENCY_TABLE_REPORT.md").write_text(bianconi_statistics_bridge_report(bianconi_conditions, bianconi_branching_expectations), encoding="utf-8")
    (out / "CLOSING_REPORT.md").write_text(closed_results_report(), encoding="utf-8")
    (out / "DEFORMED_FRACTAL_BRIDGE_DEPENDENCY_TABLE_REPORT.md").write_text(deformed_fractal_bridge_report(), encoding="utf-8")
    (out / "CORE_THEORY_CONSTRUCTION_DEPENDENCY_TABLE_REPORT.md").write_text(core_theory_construction_report(), encoding="utf-8")
    (out / "EXTERNALATION_MAINLINE_MANIFEST_REPORT.md").write_text(presentation_mainline_report(), encoding="utf-8")
    (out / "STACK_ARCHITECTURE_DEPENDENCY_TABLE_REPORT.md").write_text(stack_architecture_report(), encoding="utf-8")
    (out / "DERIVED_STACK_CONDITION_REGISTER_REPORT.md").write_text(condition_register_report(), encoding="utf-8")

    live_reference_summary = live_current_property_summary_rows(
        relative_common_ambient=relative_common_ambient,
        commutator_decay=commutator_decay,
        split_residual_scaling=split_residual_scaling,
        modular_ratio_levels=modular_ratio_levels,
        support_rank_levels=support_rank_levels,
        tomita_rows=tomita,
        record_anchor_rows=record_anchor,
        backreaction_current_rows=backreaction_current,
    )
    write_csv(out / "live_current_property_summary.csv", live_reference_summary)
    (out / "LIVE_REFERENCE_PROPERTY_SUMMARY_REPORT.md").write_text(live_current_property_summary_report(live_reference_summary), encoding="utf-8")

    summary_rows = [
        {"surface": "finite property inventory", "rows": len(inventory), "output": "finite_finite_property_inventory.csv"},
        {"surface": "previous reproduction measurement", "rows": len(reproduction), "output": "previous_reproduction_measurement.csv"},
        {"surface": "finite region grammar", "rows": len(grammar), "output": "finite_region_net_grammar.csv"},
        {"surface": "finite region inclusion poset", "rows": len(inclusion), "output": "finite_region_inclusion_poset.csv"},
        {"surface": "local operator isotony", "rows": len(isotony), "output": "local_operator_isotony.csv"},
        {"surface": "local operator commutation", "rows": len(commutation), "output": "local_operator_commutation.csv"},
        {"surface": "local operator additivity", "rows": len(additivity), "output": "local_operator_additivity.csv"},
        {"surface": "local vacuum cyclicity", "rows": len(cyclicity), "output": "local_vacuum_cyclicity.csv"},
        {"surface": "faithful state", "rows": len(faithfulness), "output": "faithful_state.csv"},
        {"surface": "support-vs-full-state summary", "rows": len(support_summary), "output": "support_vs_full_state_summary.csv"},
        {"surface": "Tomita standard-form compatibility", "rows": len(tomita), "output": "tomita_standard_form_compatibility.csv"},
        {"surface": "commutant duality", "rows": len(commutant), "output": "commutant_duality.csv"},
        {"surface": "split factorization", "rows": len(split), "output": "split_factorization.csv"},
        {"surface": "genealogical-corridor commutation", "rows": len(corridor_commutation), "output": "genealogical_corridor_commutation.csv"},
        {"surface": "genealogical-corridor split", "rows": len(corridor_split), "output": "genealogical_corridor_split.csv"},
        {"surface": "modular spectrum trajectory", "rows": len(modular_trajectory), "output": "modular_spectrum_trajectory.csv"},
        {"surface": "finite cyclicity dimension rank_bound", "rows": len(cyclicity_dimension), "output": "cyclicity_dimension_rank_bound.csv"},
        {"surface": "relative common-ambient Schur isotony", "rows": len(relative_common_ambient), "output": "relative_common_ambient_schur_isotony.csv"},
        {"surface": "commutator decay by genealogical distance", "rows": len(commutator_decay), "output": "commutator_decay_by_genealogical_distance.csv"},
        {"surface": "split residual by collar width", "rows": len(split_residual_scaling), "output": "split_residual_by_collar_width.csv"},
        {"surface": "modular ratio trajectory by level", "rows": len(modular_ratio_levels), "output": "modular_ratio_trajectory_by_level.csv"},
        {"surface": "support-rank trajectory", "rows": len(support_rank_levels), "output": "support_rank_trajectory.csv"},
        {"surface": "observable state relations", "rows": len(observable_state_rows), "output": "observable_state_relations.csv"},
        {"surface": "record-anchor consistency", "rows": len(record_anchor), "output": "record_anchor_consistency.csv"},
        {"surface": "backreaction-current localization", "rows": len(backreaction_current), "output": "backreaction_current_localization.csv"},
        {"surface": "record-live relative entropy", "rows": len(record_live_entropy), "output": "record_live_relative_entropy.csv"},
        {"surface": "history-live common measure measurement", "rows": len(history_live_measure), "output": "history_live_common_measure.csv"},
        {"surface": "live-current cluster scaling", "rows": len(live_cluster_scaling), "output": "live_current_cluster_scaling.csv"},
        {"surface": "finite complement relations", "rows": len(finite_complements), "output": "finite_complement_relations.csv"},
        {"surface": "refined port-basis resolution", "rows": len(refined_basis), "output": "refined_port_basis_resolution.csv"},
        {"surface": "collared split in refined basis", "rows": len(refined_split), "output": "collared_split_refined_basis.csv"},
        {"surface": "Tomita entropy-flow alignment", "rows": len(tomita_entropy_flow), "output": "tomita_entropy_flow_alignment.csv"},
        {"surface": "entropy-ordered locality", "rows": len(entropy_locality), "output": "entropy_ordered_locality.csv"},
        {"surface": "entropy-ordered split", "rows": len(entropy_split), "output": "entropy_ordered_split.csv"},
        {"surface": "entropy-ordered complement", "rows": len(entropy_complement), "output": "entropy_ordered_complement.csv"},
        {"surface": "modular entropy/backreaction direction", "rows": len(modular_entropy_backreaction), "output": "modular_entropy_backreaction_direction.csv"},
        {"surface": "multiscale port entropy resolution", "rows": len(multiscale_entropy_resolution), "output": "multiscale_port_entropy_resolution.csv"},
        {"surface": "extended entropy level trajectory", "rows": len(extended_entropy_trajectory), "output": "extended_entropy_level_trajectory.csv"},
        {"surface": "entropy measure parameter_sensitivity", "rows": len(entropy_measure_parameter_sensitivity), "output": "entropy_measure_parameter_sensitivity.csv"},
        {"surface": "F1/F2 oriented history measure", "rows": len(f1f2_oriented_measure), "output": "f1_f2_oriented_history_measure.csv"},
        {"surface": "entropy-gradient current", "rows": len(entropy_gradient_current), "output": "entropy_gradient_current.csv"},
        {"surface": "entropy-normalized geometry", "rows": len(entropy_normalized_geometry), "output": "entropy_normalized_geometry.csv"},
        {"surface": "refined-port coarse consistency", "rows": len(refined_coarse_consistency), "output": "refined_port_coarse_consistency.csv"},
        {"surface": "F1/F2 orientation resolution", "rows": len(f1f2_orientation_resolution), "output": "f1_f2_orientation_resolution.csv"},
        {"surface": "two-component HistoryMeasure", "rows": len(two_component_measure), "output": "two_component_history_measure.csv"},
        {"surface": "oriented HistoryMeasure geometry", "rows": len(oriented_history_geometry), "output": "oriented_history_geometry.csv"},
        {"surface": "oriented HistoryMeasure geometry summary", "rows": len(oriented_history_summary), "output": "oriented_history_measure_geometry_summary.csv"},
        {"surface": "fixed oriented HistoryMeasure", "rows": len(fixed_oriented_measure), "output": "fixed_oriented_history_measure.csv"},
        {"surface": "destroyed-history oriented geometry", "rows": len(destroyed_history_geometry), "output": "destroyed_history_oriented_geometry.csv"},
        {"surface": "fixed measure ratio summary", "rows": len(fixed_ratio_summary), "output": "fixed_measure_ratio_summary.csv"},
        {"surface": "level/mode history parameter_dependence", "rows": len(level_mode_parameter_dependence), "output": "history_measure_level_mode_dependence.csv"},
        {"surface": "level/mode oriented geometry parameter_dependence", "rows": len(level_mode_geometry_parameter_dependence), "output": "oriented_geometry_level_mode_dependence.csv"},
        {"surface": "level/mode parameter_dependence summary", "rows": len(level_mode_summary), "output": "level_mode_dependence_summary.csv"},
        {"surface": "mode-ablation F1/F2 signature", "rows": len(mode_ablation_signature), "output": "mode_ablation_signature.csv"},
        {"surface": "mode-ablated measure summary", "rows": len(mode_ablated_summary), "output": "mode_ablated_measure_summary.csv"},
        {"surface": "mode-mode_stable F1/F2 signature comparison", "rows": len(mode_mode_stable_signature), "output": "f1f2_signature_mode_comparison.csv"},
        {"surface": "mode-mode_stable F1/F2 signature summary", "rows": len(mode_mode_stable_signature_summary), "output": "mode_mode_stable_f1f2_signature_summary.csv"},
        {"surface": "signature-vs-strength decomposed measure", "rows": len(signature_strength_decomposed), "output": "signature_strength_decomposed_measure.csv"},
        {"surface": "decomposed geometry derived_quantity rows", "rows": len(decomposed_geometry), "output": "decomposed_geometry_quantities.csv"},
        {"surface": "decomposed entropy flow", "rows": len(decomposed_flow), "output": "decomposed_entropy_flow.csv"},
        {"surface": "signature-vs-strength geometry summary", "rows": len(signature_strength_summary), "output": "signature_strength_geometry_summary.csv"},
        {"surface": "F1/F2-oriented geometry replacement", "rows": len(f1f2_geometry_replacement), "output": "f1f2_oriented_geometry_replacement.csv"},
        {"surface": "F1/F2-oriented geometry replacement summary", "rows": len(f1f2_geometry_replacement_summary), "output": "f1f2_oriented_geometry_replacement_summary.csv"},
        {"surface": "four-path transition matrix", "rows": len(four_path_transition), "output": "four_path_transition_matrix.csv"},
        {"surface": "four-path dependency_table priorities", "rows": len(four_path_priorities), "output": "four_path_dependency_table_priorities.csv"},
        {"surface": "four-path literature bridge", "rows": len(four_path_literature), "output": "four_path_literature_bridge.csv"},
        {"surface": "AQFT internal form-layer comparison register", "rows": len(fock_bridge_register), "output": "aqft_form_layer_comparison_register.csv"},
        {"surface": "AQFT one-particle form comparisons", "rows": len(fock_one_particle_comparisons), "output": "aqft_one_particle_form_comparisons.csv"},
        {"surface": "Bianconi statistics bridge conditions", "rows": len(bianconi_conditions), "output": "bianconi_statistics_bridge_conditions.csv"},
        {"surface": "Bianconi branching-sector expectations", "rows": len(bianconi_branching_expectations), "output": "bianconi_branching_sector_expectations.csv"},
        {"surface": "closed finite results", "rows": len(closed_finite_results), "output": "closed_finite_results_finite_results.csv"},
        {"surface": "external measurement assessment", "rows": len(external_measurement), "output": "external_measurement_assessment.csv"},
        {"surface": "finite_core consistency prerequisites", "rows": len(prerequisites), "output": "consistency_prerequisites.csv"},
        {"surface": "presentation selection manifest", "rows": len(presentation_selection), "output": "presentation_selection_manifest.csv"},
        {"surface": "deformed Sierpinski-like fractal bridge dependency_table", "rows": len(deformed_fractal_bridge), "output": "deformed_fractal_bridge.csv"},
        {"surface": "core theory construction dependency_table", "rows": len(core_theory_construction), "output": "core_construction_dependencies.csv"},
        {"surface": "presentation mainline manifest", "rows": len(presentation_mainline), "output": "presentation_mainline_manifest.csv"},
        {"surface": "finite_core topology precedence", "rows": len(topology_precedence), "output": "topology_precedence.csv"},
        {"surface": "finite_core stack layers", "rows": len(stack_layers), "output": "stack_layers.csv"},
        {"surface": "finite_core stack transitions", "rows": len(stack_transitions), "output": "stack_transitions.csv"},
        {"surface": "finite_core derived stack condition register", "rows": len(condition_register), "output": "stack_dependency_conditions.csv"},
        {"surface": "CFS cross-axis measure register", "rows": len(cfs_cross_axis), "output": "cfs_cross_axis_measure_register.csv"},
        {"surface": "finite_core input-exclusion rules", "rows": len(input_exclusion_rules), "output": "input_exclusion_rules.csv"},
        {"surface": "live-reference property summary", "rows": len(live_reference_summary), "output": "live_current_property_summary.csv"},
    ]
    write_csv(out / "local_operator_property_check_run_summary.csv", summary_rows)
    report = "# Local operator property-check run summary\n\n" + "\n".join(f"- {r['surface']}: {r['rows']} rows -> `{r['output']}`" for r in summary_rows) + "\n\nAll surfaces are finite comparisons.  No C*-completion, von Neumann closure, KMS property, full Tomita-Takesaki property, full Reeh-Schlieder property, AQFT Haag-Kastler net, or split property is stated.\n"
    (out / "LOCAL_OPERATOR_PROPERTY_CHECK_RUN_SUMMARY.md").write_text(report, encoding="utf-8")
    print({"outdir": str(out), "surfaces": len(summary_rows)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
