#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN_PATH_PARTS = {"__pycache__", "condition_note_reference"}
FORBIDDEN_SUFFIXES = {".pyc"}
FORBIDDEN_GENERAL_ENTRYPOINT_PATTERNS = ["test_", "tmp_", "scratch_"]

def main() -> int:
    errors = []
    for p in ROOT.rglob("*"):
        rel = p.relative_to(ROOT).as_posix()
        parts = set(rel.split("/"))
        if parts & FORBIDDEN_PATH_PARTS:
            errors.append(f"forbidden path component: {rel}")
        if p.suffix in FORBIDDEN_SUFFIXES:
            errors.append(f"forbidden bytecode file: {rel}")
    entry = ROOT / "run_cnna.py"
    if not entry.exists():
        errors.append("missing neutral entrypoint: run_cnna.py")
    for p in ROOT.glob("*.py"):
        name = p.name.lower()
        if p.name != "run_cnna.py" and any(x in name for x in FORBIDDEN_GENERAL_ENTRYPOINT_PATTERNS):
            errors.append(f"non-neutral top-level python file: {p.name}")
    if errors:
        print("package_structure_condition_false")
        for e in errors:
            print(e)
        return 1
    print("package_structure_conditions_met")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
