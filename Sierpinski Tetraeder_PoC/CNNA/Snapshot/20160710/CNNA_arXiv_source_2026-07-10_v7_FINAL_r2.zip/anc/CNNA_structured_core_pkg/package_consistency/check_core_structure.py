#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "docs" / "FINITE_CORE_FILE_HASHES.json"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()

def main() -> int:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    errors = []
    for item in data.get("core_files", []):
        path = ROOT / item["path"]
        if not path.exists():
            errors.append(f"missing core file: {item['path']}")
            continue
        got = sha256(path)
        if got != item.get("sha256"):
            errors.append(f"hash mismatch: {item['path']}")
    if errors:
        print("core_file_hash_condition_false")
        for e in errors:
            print(e)
        return 1
    print("core_file_hashes_match")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
