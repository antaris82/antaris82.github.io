#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from cnna.derived_quantities.finite_structure_theorem_controls import finite_structure_theorem_control_rows


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Check the six finite structural theorem/control boundaries documented in the article.")
    parser.add_argument("--write-csv", type=Path, default=None, help="optional output path for the generated control rows")
    args = parser.parse_args()

    rows = finite_structure_theorem_control_rows()
    if args.write_csv is not None:
        _write_csv(args.write_csv, rows)

    failures = [row for row in rows if int(row.get("pass", 0) or 0) != 1]
    if failures:
        print("finite_structure_theorem_conditions_false")
        for row in failures:
            print(f"{row.get('control', 'unknown')}: {row}")
        return 1

    print("finite_structure_theorem_conditions_met")
    for row in rows:
        print(f"{row['control']}=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
