#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from cnna.derived_quantities.nested_multiscale_handoff import nested_multiscale_all_rows


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Check the nested multiscale role carrier and nonunital corner handoff.")
    parser.add_argument("--output-dir", type=Path, default=None)
    args = parser.parse_args()

    groups = nested_multiscale_all_rows()
    if args.output_dir is not None:
        names = {
            "carrier": "NESTED_MULTISCALE_CARRIER.csv",
            "handoff": "NESTED_MULTISCALE_HANDOFF.csv",
            "composition": "NESTED_MULTISCALE_COMPOSITION.csv",
            "common_ambient_schur": "NESTED_MULTISCALE_COMMON_AMBIENT_SCHUR.csv",
            "summary": "NESTED_MULTISCALE_SUMMARY.csv",
        }
        for key, filename in names.items():
            write_csv(args.output_dir / filename, groups[key])

    summary = groups["summary"]
    failures = [row for row in summary if int(row.get("pass", 0)) != 1]
    if failures:
        print("nested_multiscale_handoff_conditions_false")
        for row in failures:
            print(row)
        return 1

    print("nested_multiscale_handoff_conditions_met")
    for key in (
        "nested_carrier_exact",
        "strict_role_dimension_growth",
        "resolved_response_algebra_full_condition",
        "nonunital_corner_handoff_exact",
        "corner_composition_exact",
        "common_ambient_Schur_associativity_exact",
        "independent_response_or_state_drift_detected",
        "common_ambient_vs_independent_drift_detected",
        "J_naturality_failure_observed",
    ):
        print(f"{key}={summary[0][key]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
