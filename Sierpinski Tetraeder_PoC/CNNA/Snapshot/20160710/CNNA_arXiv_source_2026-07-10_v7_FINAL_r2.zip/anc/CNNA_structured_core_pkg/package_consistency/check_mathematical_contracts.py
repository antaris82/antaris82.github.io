#!/usr/bin/env python3
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from cnna.core.directed_dtn import j_finite_object_from_SA
from cnna.core.entropy_quantities import von_neumann_entropy_no_epsilon
from cnna.core.math_utils import normalize_dict, normalize_distribution
from cnna.core.projective_maps import push_forward
from cnna.core.response_algebra import AlgebraBasis, algebra_closure, measurement_gns
from cnna.derived_quantities.gns_cyclicity_controls import finite_gns_cyclicity_control_rows


def _close(x: float, y: float, tol: float = 1.0e-12) -> bool:
    return math.isfinite(x) and abs(float(x) - float(y)) <= tol


def main() -> int:
    errors: list[str] = []

    zero_dict = normalize_dict({(0,): 0.0, (1,): 0.0})
    if not (_close(zero_dict[(0,)], 0.5) and _close(zero_dict[(1,)], 0.5)):
        errors.append("zero dictionary normalization is not uniform")

    clipped = normalize_distribution([math.nan, -1.0, 2.0])
    if clipped.shape != (3,) or not np.allclose(clipped, np.array([0.0, 0.0, 1.0]), atol=1.0e-12, rtol=0.0):
        errors.append("finite/nonnegative clipping normalization contract failed")

    pushed = push_forward({(0, 0): 2.0, (0, 1): 1.0, (1, 0): 1.0}, 1)
    if not (_close(sum(pushed.values()), 1.0) and _close(pushed[(0,)], 0.75) and _close(pushed[(1,)], 0.25)):
        errors.append("push_forward normalization contract failed")

    controls = finite_gns_cyclicity_control_rows()
    if not controls or any(int(row.get("control_pass", 0)) != 1 for row in controls):
        errors.append("finite GNS cyclicity positive/negative controls failed")

    # Basis-change and nonfaithful-state controls for the explicit quotient audit.
    I2 = np.eye(2, dtype=float)
    E12 = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=float)
    full = algebra_closure("full_M2R_contract", [I2, E12], tol=1.0e-10, max_iter=8)
    pure = np.diag([1.0, 0.0])
    base_gns = measurement_gns(full, pure, 1.0e-10)
    q_seed = np.array(
        [[1.0, 2.0, 0.0, 1.0], [0.0, 1.0, 2.0, -1.0], [1.0, 0.0, 1.0, 2.0], [2.0, -1.0, 0.0, 1.0]],
        dtype=float,
    )
    Q, _ = np.linalg.qr(q_seed)
    rotated_basis = [sum(float(Q[j, i]) * full.basis[j] for j in range(len(full.basis))) for i in range(len(full.basis))]
    rotated_gns = measurement_gns(AlgebraBasis("full_M2R_rotated", rotated_basis, full.generator_count, full.iterations, full.saturated), pure, 1.0e-10)
    if not (
        base_gns.rank == rotated_gns.rank == 2
        and base_gns.nullity == rotated_gns.nullity == 2
        and base_gns.cyclic_ok
        and rotated_gns.cyclic_ok
        and base_gns.representation_ok
        and rotated_gns.representation_ok
        and base_gns.max_null_left_stability <= 1.0e-9
        and rotated_gns.max_null_left_stability <= 1.0e-9
    ):
        errors.append("GNS basis-change/nonfaithful-state quotient control failed")

    S = np.eye(3, dtype=float)
    A = np.array([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 0.0]], dtype=float)
    J, meta = j_finite_object_from_SA(S, A)
    if J is None or int(meta.get("available", 0)) != 1:
        errors.append("finite J partial-isometry control unavailable")
    elif int(meta.get("skew_rank", 0)) != 2 or float(meta.get("J_square_minus_negative_projector_error", math.inf)) > 1.0e-10:
        errors.append("finite J partial-isometry control failed")

    D = np.diag([1.0 - 1.0e-12, 1.0e-12])
    entropy = von_neumann_entropy_no_epsilon(D, tol=1.0e-10)
    if abs(entropy) > 1.0e-9:
        errors.append("entropy support cutoff control failed")

    if errors:
        print("mathematical_contract_conditions_false")
        for error in errors:
            print(error)
        return 1
    print("mathematical_contract_conditions_met")
    print(f"gns_cyclicity_control_rows={len(controls)}")
    print("gns_basis_change_nonfaithful_control=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
