# Tested numerical environment

The documented snapshot was tested with:

- Ubuntu 26.04 LTS
- Linux kernel `7.0.0-27-generic`, x86_64, glibc 2.43
- CPython 3.14.4, built with GCC 15.2.0
- NumPy 2.3.5
- NumPy `dtype=float`, resolving to `numpy.float64` (IEEE 754 binary64)
- `threadpoolctl` 3.6.0 for runtime inspection
- Ubuntu/Debian reference BLAS 3.12.1 from `libblas3` 3.12.1-7ubuntu1
- Ubuntu/Debian reference LAPACK 3.12.1 from `liblapack3` 3.12.1-7ubuntu1

The backend identification is based on three mutually consistent checks in
`ENVIRONMENT.txt`:

1. `/proc/self/maps` shows the mapped libraries
   `/usr/lib/x86_64-linux-gnu/blas/libblas.so.3.12.1` and
   `/usr/lib/x86_64-linux-gnu/lapack/liblapack.so.3.12.1` after representative
   matrix multiplication, linear solve, symmetric eigenvalue, and SVD calls.
2. `ldd` on NumPy's `_multiarray_umath`, `_umath_linalg`, and `lapack_lite`
   extension modules resolves their BLAS/LAPACK dependencies through the same
   system links.
3. `dpkg-query` and `update-alternatives` identify `libblas3` and `liblapack3`
   as the configured providers.

`threadpoolctl` reports no thread-pool-managed native library. This is
consistent with the configured serial reference BLAS/LAPACK providers and is
not evidence of a missing numerical backend.

The complete captured runtime, linker, package-provider, and NumPy build
information is preserved in `ENVIRONMENT.txt`. The package does not claim
bitwise identity on systems using a different BLAS/LAPACK provider, compiler,
processor feature set, or library version.
