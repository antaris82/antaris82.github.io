# CNNA structured core reproducibility package

This directory is the ancillary Python package accompanying
`cnna_core_derived_documentation.tex` in the root of the arXiv source bundle.
The article is compiled independently of the Python package; the package is
included to expose the documented finite source surface and reproduce the row
families named in the article.

## Documented source surface

The mathematical source boundary consists of:

- root `run_*.py` entrypoints;
- `src/cnna/__init__.py` and `src/cnna/config.py`;
- `src/cnna/io/*.py`;
- `src/cnna/analysis_entrypoints/*.py`;
- `src/cnna/core/*.py`;
- `src/cnna/derived_quantities/*.py`;
- `src/cnna/object_checks/*.py`.

The SHA-256 digest of the line-sorted source-surface manifest is:

```text
2612012d5149bedca71dbdbe60d0cbd075bbda6171ca008e989482787a002044
```

The manifest is `docs/SOURCE_SURFACE_MANIFEST.txt`; its digest is stored in
`docs/SOURCE_SURFACE_SHA256.txt`. The manifest is regenerated after every source change. The digest printed
here and in the article identifies the exact documented Python source surface
of this ancillary version.

## Tested environment

The documented snapshot was tested on Ubuntu 26.04 LTS with CPython 3.14.4,
GCC 15.2.0, NumPy 2.3.5, and the Ubuntu/Debian reference BLAS and LAPACK
implementations 3.12.1 (`libblas3` and `liblapack3`, package version
3.12.1-7ubuntu1). See `ENVIRONMENT.md` for the concise statement and
`ENVIRONMENT.txt` for the captured runtime, linker, provider, and NumPy build
information.

Install the Python dependency in a suitable environment with:

```bash
python3 -m pip install -r requirements.txt
```

The supplied Ubuntu system NumPy build and a PyPI wheel can use different
BLAS/LAPACK implementations. Therefore, identical package versions do not by
themselves guarantee bitwise-identical floating-point output.

## Execution

From the extracted arXiv source root:

```bash
cd anc/CNNA_structured_core_pkg
PYTHONPATH=src python3 run_cnna.py --help
```

The complete integrated and focused reproduction commands, including the
finite caps and tolerances, are stated in the article.

## Package checks

Run:

```bash
python3 package_consistency/check_package_structure.py
python3 package_consistency/check_core_structure.py
python3 package_consistency/check_mathematical_contracts.py
python3 package_consistency/check_finite_structure_theorems.py
python3 package_consistency/check_nested_multiscale_handoff.py
sha256sum -c CHECKSUMS.txt
```

`CHECKSUMS.txt` covers every file in this ancillary package except the
checksum file itself. It is distinct from the documented Python
source-surface digest, which intentionally covers only the article's declared
Python source boundary.

## License

The Python software and software documentation in this ancillary package are
licensed under the MIT License; see `LICENSE`. The research article is not
licensed by this file. Distribution of the article is governed by the license
selected on its arXiv record.

## Mathematical contract controls

`check_mathematical_contracts.py` verifies the documented normalization and
normalized push-forward semantics, positive and negative GNS cyclicity
controls, a deterministic basis-change/nonfaithful-state GNS quotient control,
the support-restricted finite-J partial-isometry identity, and the
scale-aware entropy cutoff. The integrated command additionally emits
`finite_gns_cyclicity_controls.csv`.

`check_finite_structure_theorems.py` adds deterministic growth replay,
symmetric Schur-positivity, finite GNS, finite-J sign-reversal, backreaction
non-implication, and exact prefix/carrier handoff controls. With `--write-csv`
it regenerates `docs/FINITE_STRUCTURE_THEOREM_CONTROLS.csv`. The legacy label-span response, algebra, state, and GNS maps remain residual-bearing comparisons.

`check_nested_multiscale_handoff.py` constructs the growing first-order address-contrast carriers, verifies their exact `fiber_sqrt` nesting and nonunital corner embeddings, checks common-ambient Schur associativity, and separates those exact carrier statements from the measured live-response, independently reconstructed state, GNS, and finite-`J` drift. With `--output-dir docs` it regenerates the five `NESTED_MULTISCALE_*.csv` files.
