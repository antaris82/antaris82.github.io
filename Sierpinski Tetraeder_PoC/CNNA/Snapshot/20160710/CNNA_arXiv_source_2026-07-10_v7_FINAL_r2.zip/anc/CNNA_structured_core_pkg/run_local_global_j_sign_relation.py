#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities.baseline import level_models
from cnna.io.csv_writer import write_csv
from cnna.derived_quantities.local_global_j_sign_relation import (
    global_j_boundary_sign_relation_rows,
    local_global_j_sign_comparison_rows,
    local_global_j_sign_summary_rows,
    write_local_global_j_sign_relation_report,
)


def parse_args():
    p = argparse.ArgumentParser(description="local/global J-sign sign_relation measurement")
    p.add_argument("--branching", nargs="+", type=int, default=[4])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear"])
    p.add_argument("--max-regions", type=int, default=3)
    p.add_argument("--max-boundary", type=int, default=3500)
    p.add_argument("--max-interior", type=int, default=6000)
    p.add_argument("--directed-frontier-cap", type=int, default=6)
    p.add_argument("--gns-tol", type=float, default=1.0e-10)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/J_sign_sign_relation"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    global_rows = global_j_boundary_sign_relation_rows(models, args)
    comparison_rows = local_global_j_sign_comparison_rows(models, args, global_rows)
    summary_rows = local_global_j_sign_summary_rows(global_rows, comparison_rows)
    write_csv(args.outdir / "j_sign_global_boundary_sign_relation.csv", global_rows)
    write_csv(args.outdir / "local_global_J_sign_comparison.csv", comparison_rows)
    write_csv(args.outdir / "J_sign_sign_relation_summary.csv", summary_rows)
    write_local_global_j_sign_relation_report(args.outdir, global_rows, comparison_rows, summary_rows)
    final = summary_rows[0] if summary_rows else {"computed_status": "local_global_J_sign_no_summary_rows", "unmet_conditions": "missing"}
    print(json.dumps(final, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
