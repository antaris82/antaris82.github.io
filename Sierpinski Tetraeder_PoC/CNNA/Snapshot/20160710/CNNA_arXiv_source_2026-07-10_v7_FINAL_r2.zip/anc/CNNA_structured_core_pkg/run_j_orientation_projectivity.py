#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities.baseline import level_models
from cnna.io.csv_writer import write_csv
from cnna.derived_quantities.j_orientation_projectivity import (
    j_orientation_snapshot_rows,
    j_orientation_transport_rows,
    j_orientation_composition_rows,
    j_orientation_sign_scope_rows,
    j_orientation_projectivity_summary_rows,
    a_j_orientation_snapshot_rows,
    a_j_orientation_transport_rows,
    a_j_orientation_composition_rows,
    a_j_orientation_projectivity_summary_rows,
    write_b_j_orientation_projectivity_report,
    write_j_orientation_a_orientation_projectivity_report,
)


def parse_args():
    p = argparse.ArgumentParser(description='B/J orientation projectivity measurement')
    p.add_argument('--branching', nargs='+', type=int, default=[4])
    p.add_argument('--levels', nargs='+', type=int, default=[4,5,6])
    p.add_argument('--modes', nargs='+', choices=['linear','log','saturating'], default=['linear'])
    p.add_argument('--max-regions', type=int, default=3)
    p.add_argument('--max-boundary', type=int, default=3500)
    p.add_argument('--max-interior', type=int, default=6000)
    p.add_argument('--directed-frontier-cap', type=int, default=6)
    p.add_argument('--gns-tol', type=float, default=1e-10)
    p.add_argument('--include-b-derived_quantity', action='store_true', help='also write optional B/J derived_quantity rows; B changes sign near the zero crossing and is not the reference J object')
    p.add_argument('--growth-schedule', choices=['slot_step', 'layer_batch'], default='slot_step')
    p.add_argument('--outdir', type=Path, default=Path('outputs/A_J_orientation_projectivity'))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    outdir = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    b_summary = []
    a_snapshot = a_j_orientation_snapshot_rows(models, args)
    a_transport = a_j_orientation_transport_rows(models, args)
    a_comp = a_j_orientation_composition_rows(models, args)
    summary = a_j_orientation_projectivity_summary_rows(a_snapshot, a_transport, a_comp, b_summary)
    write_csv(outdir / 'A_J_orientation_snapshot.csv', a_snapshot)
    write_csv(outdir / 'A_J_orientation_transport.csv', a_transport)
    write_csv(outdir / 'A_J_orientation_composition.csv', a_comp)
    write_csv(outdir / 'A_J_orientation_projectivity_summary.csv', summary)
    write_j_orientation_a_orientation_projectivity_report(outdir, a_snapshot, a_transport, a_comp, summary)
    if args.include_b_derived_quantity:
        b_snapshot = j_orientation_snapshot_rows(models, args)
        b_transport = j_orientation_transport_rows(models, args)
        b_comp = j_orientation_composition_rows(models, args)
        signs = j_orientation_sign_scope_rows(b_snapshot)
        b_summary = j_orientation_projectivity_summary_rows(b_snapshot, b_transport, b_comp, signs)
        write_csv(outdir / 'J_B_orientation_snapshot.csv', b_snapshot)
        write_csv(outdir / 'J_B_orientation_transport.csv', b_transport)
        write_csv(outdir / 'J_B_orientation_composition.csv', b_comp)
        write_csv(outdir / 'J_B_local_global_sign_scope.csv', signs)
        write_csv(outdir / 'J_B_orientation_projectivity_summary.csv', b_summary)
        write_b_j_orientation_projectivity_report(outdir, b_snapshot, b_transport, b_comp, signs, b_summary)
    final = summary[0] if summary else {'computed_status':'J_orientation_no_summary_rows','unmet_conditions':'missing'}
    print(json.dumps(final, indent=2, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
