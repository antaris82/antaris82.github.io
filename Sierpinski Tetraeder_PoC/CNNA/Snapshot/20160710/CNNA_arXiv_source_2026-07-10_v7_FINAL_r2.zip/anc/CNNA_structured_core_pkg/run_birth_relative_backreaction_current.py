#!/usr/bin/env python3
"""Run only the birth-relative live/record backreaction law measurement.

This runner first computes the 4 physical current rows

    B_L = A_live,L - A_record,L

and then re-indexes the full-terminal rows by region age rather than absolute
level.  `sym` is not part of the physical path.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities import (
    level_models,
    backreaction_current_rows,
    birth_relative_backreaction_rows,
    birth_relative_zero_crossing_rows,
    birth_relative_mode_branching_rows,
    birth_relative_region_family_rows,
    birth_relative_summary_rows,
    write_birth_relative_backreaction_current_report,
)
from cnna.io.csv_writer import write_csv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA birth-relative backreaction current law measurement only")
    p.add_argument("--branching", nargs="+", type=int, default=[4])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6, 7, 8])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear"])
    p.add_argument("--max-regions", type=int, default=3)
    p.add_argument("--max-boundary", type=int, default=600)
    p.add_argument("--max-interior", type=int, default=900)
    p.add_argument("--directed-frontier-cap", type=int, default=6)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/birth_relative_relative_backreaction"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    base = backreaction_current_rows(models, args)
    birth = birth_relative_backreaction_rows(base)
    zero = birth_relative_zero_crossing_rows(birth)
    mb = birth_relative_mode_branching_rows(zero)
    rf = birth_relative_region_family_rows(birth, zero)
    summary = birth_relative_summary_rows(birth, zero, mb, rf)

    write_csv(outdir / "birth_relative_relative_backreaction_current.csv", birth)
    write_csv(outdir / "birth_relative_zero_crossing_by_region.csv", zero)
    write_csv(outdir / "birth_relative_mode_branching_comparison.csv", mb)
    write_csv(outdir / "birth_relative_region_family_comparison.csv", rf)
    write_csv(outdir / "birth_relative_backreaction_law_summary.csv", summary)
    write_birth_relative_backreaction_current_report(outdir, birth, zero, mb, rf, summary)

    reference = next((r for r in summary if int(r.get("reference_model", 0)) == 1), summary[0] if summary else {})
    print(json.dumps({
        "condition": "birth_relative_relative_backreaction_current_only",
        "computed_status": reference.get("computed_status", "missing_summary"),
        "unmet_conditions": reference.get("unmet_conditions", "missing_summary"),
        "reference_terminal_ages": reference.get("reference_terminal_ages", "missing_summary"),
        "reference_terminal_values": reference.get("reference_terminal_values", "missing_summary"),
        "first_nonnegative_age": reference.get("reference_first_nonnegative_age", "missing_summary"),
        "nearest_zero_age": reference.get("reference_nearest_zero_age", "missing_summary"),
        "linear_zero_crossing_age": reference.get("reference_linear_zero_crossing_age", "missing_summary"),
        "condition_note": "birth-relative current uses live-record only; sym is a symmetric-tree control; coarse-frontier rows excluded from law fit; no vN/KMS/TypeIII statement",
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
