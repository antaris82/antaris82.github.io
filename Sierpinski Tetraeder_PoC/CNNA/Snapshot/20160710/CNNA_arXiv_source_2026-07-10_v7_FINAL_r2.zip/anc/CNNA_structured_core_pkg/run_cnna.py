#!/usr/bin/env python3
"""Run the CNNA construction analysis."""

from cnna.analysis_entrypoints.run_cnna_analysis import main

if __name__ == "__main__":
    raise SystemExit(main())
