#!/usr/bin/env python3
"""Run only the live/record backreaction current measurement.

This intentionally ignores `sym` for physical classification.  `sym` remains a
symmetric-tree control in earlier measurements, but 4 measures
B_L = A_live,L - A_record,L.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities import (
    level_models,
    backreaction_current_rows,
    backreaction_growth_profile_rows,
    backreaction_region_parameter_sensitivity_rows,
    backreaction_transport_rows,
    backreaction_current_summary_rows,
    write_live_record_backreaction_current_report,
)
from cnna.io.csv_writer import write_csv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA live/record backreaction current measurement only")
    p.add_argument("--branching", nargs="+", type=int, default=[4])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6, 7, 8])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear"])
    p.add_argument("--max-regions", type=int, default=2)
    p.add_argument("--max-boundary", type=int, default=600)
    p.add_argument("--max-interior", type=int, default=900)
    p.add_argument("--directed-frontier-cap", type=int, default=6)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/backreaction_current"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    rows = backreaction_current_rows(models, args)
    growth = backreaction_growth_profile_rows(rows)
    parameter_sensitivity = backreaction_region_parameter_sensitivity_rows(rows)
    transport = backreaction_transport_rows(models, args)
    summary = backreaction_current_summary_rows(rows, growth, parameter_sensitivity, transport)

    write_csv(outdir / "live_record_backreaction_current.csv", rows)
    write_csv(outdir / "backreaction_growth_profile.csv", growth)
    write_csv(outdir / "backreaction_region_parameter_sensitivity.csv", parameter_sensitivity)
    write_csv(outdir / "backreaction_transport.csv", transport)
    write_csv(outdir / "backreaction_current_summary.csv", summary)
    write_live_record_backreaction_current_report(outdir, rows, growth, parameter_sensitivity, transport, summary)

    reference = next((r for r in summary if int(r.get("reference_model", 0)) == 1), summary[0] if summary else {})
    print(json.dumps({
        "condition": "live_record_backreaction_current_only",
        "computed_status": reference.get("computed_status", "missing_summary"),
        "unmet_conditions": reference.get("unmet_conditions", "missing_summary"),
        "physical_path": reference.get("physical_path", "live_record_only_sym_is_control"),
        "latest_full_terminal_level": reference.get("latest_full_terminal_level", "missing_summary"),
        "latest_full_terminal_B_skew_norm": reference.get("latest_full_terminal_B_skew_norm", "missing_summary"),
        "latest_full_terminal_live_minus_record_skew_norm": reference.get("latest_full_terminal_live_minus_record_skew_norm", "missing_summary"),
        "condition_note": "4 uses live-record only; sym is a symmetric-tree control, not the physical comparison path; no vN/KMS/TypeIII statement",
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
