#!/usr/bin/env python3
"""Run only the 3c directed/skew-DtN large-L coverage measurement.

This intentionally skips the previous positive GNS/algebra/CE/modular measurements.
Use it when L>=7 coverage is the question and the full `run_cnna.py` stack is
unnecessarily heavy.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cnna.derived_quantities import (
    level_models,
    directed_current_transport_rows,
    directed_current_composition_rows,
    directed_j_orientation_summary_rows,
    directed_large_L_region_coverage_rows,
    directed_large_L_coverage_summary_rows,
    write_directed_current_transport_report,
    write_directed_region_coverage_report,
)
from cnna.io.csv_writer import write_csv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA 3c directed/skew-DtN large-L coverage measurement only")
    p.add_argument("--branching", nargs="+", type=int, default=[4])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6, 7, 8])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear"])
    p.add_argument("--states", nargs="+", choices=["live", "record", "sym"], default=["live", "sym"])
    p.add_argument("--max-regions", type=int, default=1)
    p.add_argument("--max-boundary", type=int, default=600)
    p.add_argument("--max-interior", type=int, default=900)
    p.add_argument("--gns-tol", type=float, default=1e-10)
    p.add_argument("--directed-frontier-cap", type=int, default=6)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/directed_region_coverage_directed_coverage"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    transport_rows = directed_current_transport_rows(models, args.states, args)
    composition_rows = directed_current_composition_rows(models, args.states, args)
    transport_summary_rows = directed_j_orientation_summary_rows(transport_rows, composition_rows)
    coverage_rows = directed_large_L_region_coverage_rows(models, args.states, args)
    coverage_summary_rows = directed_large_L_coverage_summary_rows(coverage_rows, transport_rows)

    write_csv(outdir / "directed_current_transport.csv", transport_rows)
    write_csv(outdir / "directed_current_composition.csv", composition_rows)
    write_csv(outdir / "J_orientation_transport_summary.csv", transport_summary_rows)
    write_csv(outdir / "directed_large_L_directed_region_coverage.csv", coverage_rows)
    write_csv(outdir / "directed_large_L_directed_region_coverage_summary.csv", coverage_summary_rows)
    write_directed_current_transport_report(outdir, transport_rows, composition_rows, transport_summary_rows)
    write_directed_region_coverage_report(outdir, coverage_rows, coverage_summary_rows)

    reference = next((r for r in coverage_summary_rows if int(r.get("reference_model", 0)) == 1), coverage_summary_rows[0] if coverage_summary_rows else {})
    print(json.dumps({
        "condition": "directed_region_coverage_only",
        "computed_status": reference.get("computed_status", "missing_summary"),
        "unmet_conditions": reference.get("unmet_conditions", "missing_summary"),
        "full_terminal_levels": reference.get("full_terminal_levels", "missing_summary"),
        "coarse_frontier_levels": reference.get("coarse_frontier_levels", "missing_summary"),
        "unavailable_levels": reference.get("unavailable_levels", "missing_summary"),
        "condition_note": "directed/skew-DtN coverage only; skips previous positive GNS/algebra/CE/modular measurements; no vN/KMS/TypeIII statement",
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
