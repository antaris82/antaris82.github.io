"""Finite local-operator property comparisons for the CNNA dependency_table core.

The package name is intentionally a neutral test surface.  Individual modules
are named by the mathematical/physical object they measurement, not by historical
construction_step labels.
"""

__all__ = []
