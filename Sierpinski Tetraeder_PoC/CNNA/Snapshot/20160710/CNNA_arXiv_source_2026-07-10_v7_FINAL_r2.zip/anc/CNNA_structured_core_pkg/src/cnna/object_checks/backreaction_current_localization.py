from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

import numpy as np

from cnna.core.math_utils import fro
from cnna.core.schur_dtn import boundary_role_basis
from cnna.core.directed_dtn import directed_schur_response_from_model, split_symmetric_skew

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import region_size_meta


def _projectors(d: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ps = []
    for i in range(3):
        P = np.zeros((d, d), dtype=float)
        if i < d:
            P[i, i] = 1.0
        ps.append(P)
    return ps[0], ps[1], ps[2]


def _row_computed_status(B_norm: float, cross_fraction: float, tol: float) -> str:
    if B_norm <= tol:
        return "backreaction_current_absent_control"
    if cross_fraction <= 0.1:
        return "backreaction_current_birth_cone_localized_finite_object"
    if cross_fraction <= 0.5:
        return "backreaction_current_mixed_localization_observed"
    return "backreaction_current_cross_coupling_dominant_observed"


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"))


def _summarize_track(rows: List[dict]) -> dict:
    by_c: Dict[int, List[float]] = defaultdict(list)
    by_x: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        if c < 0:
            continue
        by_c[c].append(float(r.get("backreaction_current_norm", math.nan)))
        by_x[c].append(float(r.get("backreaction_cross_fraction", math.nan)))
    corridors = sorted(by_c)
    if len(corridors) < 2:
        return {
            "backreaction_current_corridor_track_count": int(len(corridors)),
            "backreaction_current_norm_corridor_trend": "backreaction_current_insufficient_corridor_trajectory",
            "backreaction_cross_fraction_corridor_trend": "backreaction_current_insufficient_corridor_trajectory",
        }
    med_norm = {c: sorted(v)[len(v)//2] for c, v in by_c.items() if v}
    med_cross = {c: sorted(v)[len(v)//2] for c, v in by_x.items() if v}
    first, last = corridors[0], corridors[-1]
    n0, n1 = med_norm.get(first, math.nan), med_norm.get(last, math.nan)
    x0, x1 = med_cross.get(first, math.nan), med_cross.get(last, math.nan)
    condition_n = 1.0e-12 * max(1.0, abs(n0), abs(n1)) if math.isfinite(n0) and math.isfinite(n1) else math.inf
    condition_x = 1.0e-12 * max(1.0, abs(x0), abs(x1)) if math.isfinite(x0) and math.isfinite(x1) else math.inf
    if math.isfinite(n0) and math.isfinite(n1) and n1 < n0 - condition_n:
        ntrend = "backreaction_current_norm_decreases_with_corridor"
    elif math.isfinite(n0) and math.isfinite(n1) and n1 > n0 + condition_n:
        ntrend = "backreaction_current_norm_increases_with_corridor"
    elif math.isfinite(n0) and math.isfinite(n1):
        ntrend = "backreaction_current_norm_corridor_stable_finite_object"
    else:
        ntrend = "backreaction_current_norm_corridor_trend_unavailable"
    if math.isfinite(x0) and math.isfinite(x1) and x1 < x0 - condition_x:
        xtrend = "backreaction_cross_fraction_decreases_with_corridor"
    elif math.isfinite(x0) and math.isfinite(x1) and x1 > x0 + condition_x:
        xtrend = "backreaction_cross_fraction_increases_with_corridor"
    elif math.isfinite(x0) and math.isfinite(x1):
        xtrend = "backreaction_cross_fraction_corridor_stable_finite_object"
    else:
        xtrend = "backreaction_cross_fraction_corridor_trend_unavailable"
    return {
        "backreaction_current_corridor_track_count": int(len(corridors)),
        "backreaction_current_min_corridor": int(first),
        "backreaction_current_max_corridor": int(last),
        "backreaction_current_first_median_norm": float(n0) if math.isfinite(n0) else math.nan,
        "backreaction_current_last_median_norm": float(n1) if math.isfinite(n1) else math.nan,
        "backreaction_current_norm_last_over_first": float(n1 / max(n0, 1.0e-300)) if math.isfinite(n0) and math.isfinite(n1) and n0 > 0 else math.nan,
        "backreaction_cross_first_median_fraction": float(x0) if math.isfinite(x0) else math.nan,
        "backreaction_cross_last_median_fraction": float(x1) if math.isfinite(x1) else math.nan,
        "backreaction_current_norm_corridor_trend": ntrend,
        "backreaction_cross_fraction_corridor_trend": xtrend,
    }


def backreaction_current_localization_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            live = directed_schur_response_from_model(model, "live", spec.boundary, spec.interior, include_external_degrees=True)
            record = directed_schur_response_from_model(model, "record", spec.boundary, spec.interior, include_external_degrees=True)
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            if not live.ok or live.Lambda is None or not record.ok or record.Lambda is None:
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "current_relations": "B_is_backreaction_history_current_not_local_operator_property_algebra",
                    "backreaction_current_localization_computed_status": "response_unavailable",
                })
                continue
            Q, qnames = boundary_role_basis(model, spec)
            Ll = Q.T @ live.Lambda @ Q
            Lr = Q.T @ record.Lambda @ Q
            _Sl, Al = split_symmetric_skew(Ll)
            _Sr, Ar = split_symmetric_skew(Lr)
            B = Al - Ar
            d = int(B.shape[0])
            P0, P1, P2 = _projectors(d)
            PL = P0 + P1
            PR = P0 + P2
            B_left = PL @ B @ PL
            B_right = PR @ B @ PR
            B_cross = P1 @ B @ P2 + P2 @ B @ P1
            nB = float(fro(B))
            nL = float(fro(B_left))
            nR = float(fro(B_right))
            nX = float(fro(B_cross))
            rows.append({
                "branching": b,
                "level": L,
                "mode": mode,
                **meta,
                "role_names": "|".join(str(x) for x in qnames),
                "current_relations": "B_is_backreaction_history_current_not_local_operator_property_algebra",
                "backreaction_state_pair": "live_minus_record",
                "backreaction_current_norm": nB,
                "backreaction_left_birth_cone_norm": nL,
                "backreaction_right_birth_cone_norm": nR,
                "backreaction_cross_norm": nX,
                "backreaction_left_fraction": float(nL / max(nB, 1.0e-300)) if nB > 0 else 0.0,
                "backreaction_right_fraction": float(nR / max(nB, 1.0e-300)) if nB > 0 else 0.0,
                "backreaction_cross_fraction": float(nX / max(nB, 1.0e-300)) if nB > 0 else 0.0,
                "B_test_scope": "current_localization_derived_quantity_not_HK_locality_statement",
                "backreaction_current_localization_computed_status": _row_computed_status(nB, float(nX / max(nB, 1.0e-300)) if nB > 0 else 0.0, config.algebra_tol),
            })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        if "backreaction_current_norm" in r:
            tracks[_track_key(r)].append(r)
    summaries = {k: _summarize_track(v) for k, v in tracks.items()}
    for r in rows:
        r.update(summaries.get(_track_key(r), {}))
    return rows


def backreaction_current_localization_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("backreaction_current_localization_computed_status", "unknown")) for r in rows})
    trends = sorted({str(r.get("backreaction_current_norm_corridor_trend", "unknown")) for r in rows if "backreaction_current_norm_corridor_trend" in r})
    return (
        "# Backreaction-current localization\n\n"
        "This surface treats `B = live - record` as a backreaction/history current, not as a local Haag-Kastler algebra.  "
        "It tracks where the current sits in the compressed LCA/left/right role carrier and how its norm changes with genealogical corridor length.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Corridor trends: `" + "`, `".join(trends) + "`.\n"
    )
