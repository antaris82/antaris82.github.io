from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _hist_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    idx: Dict[Tuple[object, ...], dict] = {}
    for r in history_rows:
        if r.get("measure_surface") != "history_live_measure_finite_object":
            continue
        key = (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))
        idx[key] = r
    return idx


def _base_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))


def _normed(value: float, js: float) -> float:
    return float(value / max(js, 1.0e-300)) if math.isfinite(value) and math.isfinite(js) and js > 0.0 else math.nan


def entropy_normalized_geometry_rows(
    history_rows: List[dict],
    locality_rows: List[dict],
    split_rows: List[dict],
    complement_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Unified entropy-normalized finite geometry derived_quantity rows.

    This is the integration layer for geometry rank_bounds: commutators,
    split residuals, and complement/commutant errors are read relative to the
    measured history/live distance JS(live,record), not as raw property statements.
    """
    hidx = _hist_index(history_rows)
    rows: List[dict] = []

    for r in locality_rows:
        key = _base_key(r)
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        raw = _finite(r.get("cluster_rank_bound_norm"))
        per = _normed(raw, js)
        if not math.isfinite(js):
            computed_status = "entropy_measure_unavailable_for_commutator_geometry"
        elif raw <= tol:
            computed_status = "entropy_normalized_commutator_zero_control"
        elif per < 10.0 and gain > tol:
            computed_status = "commutator_within_history_measure_scale_finite_object"
        else:
            computed_status = "commutator_exceeds_history_measure_scale_observed"
        rows.append({
            "geometry_surface": "commutator_per_JS",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "geometry_layer": r.get("live_cluster_layer"),
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_JS": per,
            "source_computed_status": r.get("live_cluster_track_computed_status", r.get("entropy_ordered_locality_track_computed_status")),
            "entropy_normalized_geometry_computed_status": computed_status,
        })

    for r in split_rows:
        key = _base_key(r)
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        raw = _finite(r.get("split_residual_raw", r.get("split_dimension_residual", r.get("identity_overlap_corrected_residual", math.nan))))
        if not math.isfinite(raw):
            raw = _finite(r.get("split_residual_per_history_js"))
        per = _normed(raw, js)
        if not math.isfinite(js):
            computed_status = "entropy_measure_unavailable_for_split_geometry"
        elif raw <= tol:
            computed_status = "entropy_normalized_split_zero_residual_finite_object"
        elif per < 10.0 and gain > tol:
            computed_status = "split_residual_within_history_measure_scale_control"
        else:
            computed_status = "split_residual_exceeds_history_measure_scale_observed"
        rows.append({
            "geometry_surface": "split_residual_per_JS",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "collar_width": r.get("collar_width", r.get("genealogical_corridor_length")),
            "geometry_layer": r.get("split_layer", r.get("refined_split_layer", "split")),
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_JS": per,
            "source_computed_status": r.get("refined_split_track_computed_status", r.get("entropy_ordered_split_track_computed_status", r.get("collared_split_refined_basis_computed_status"))),
            "entropy_normalized_geometry_computed_status": computed_status,
        })

    for r in complement_rows:
        key = _base_key(r)
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        raw = max(
            _finite(r.get("one_sided_inclusion_residual", math.nan)),
            _finite(r.get("double_commutant_closure_error", math.nan)),
            _finite(r.get("common_ambient_conditioning_error", math.nan)),
            _finite(r.get("finite_complement_error", math.nan)),
            _finite(r.get("complement_error_per_history_js", math.nan)),
        )
        per = _normed(raw, js)
        if not math.isfinite(js):
            computed_status = "entropy_measure_unavailable_for_complement_geometry"
        elif raw <= tol:
            computed_status = "entropy_normalized_complement_exact_finite_object"
        elif per < 10.0 and gain > tol:
            computed_status = "complement_error_within_history_measure_scale_control"
        else:
            computed_status = "complement_error_exceeds_history_measure_scale_observed"
        rows.append({
            "geometry_surface": "complement_error_per_JS",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "complement_type": r.get("complement_type", "unknown"),
            "geometry_layer": "finite_complement_relations",
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_JS": per,
            "source_computed_status": r.get("finite_complement_relations_computed_status", r.get("entropy_ordered_complement_row_computed_status")),
            "entropy_normalized_geometry_computed_status": computed_status,
        })

    return rows


def entropy_normalized_geometry_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("entropy_normalized_geometry_computed_status", "unknown")) for r in rows})
    surfaces = sorted({str(r.get("geometry_surface", "unknown")) for r in rows})
    return (
        "# Entropy-normalized finite geometry\n\n"
        "This surface merges commutator, split, and complement rank_bound magnitudes after normalizing by the 7 history/live measure `JS(live,record)`.  It does not turn those rank_bounds into property passes; it asks whether they are small or large relative to the measured backreaction/history scale.\n\n"
        "Surfaces: `" + "`, `".join(surfaces) + "`.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
