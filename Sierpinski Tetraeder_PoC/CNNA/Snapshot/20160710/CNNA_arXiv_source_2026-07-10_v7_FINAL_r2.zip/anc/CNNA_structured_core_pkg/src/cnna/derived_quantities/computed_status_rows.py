from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.core.math_utils import _float_field, _max_metric
from cnna.derived_quantities.baseline import *
from cnna.derived_quantities.structural_ledgers import *
from cnna.derived_quantities.rank_kernel_conditions import *
from cnna.derived_quantities.operator_stack_residuals import *
from cnna.derived_quantities.compressed_state_projection_consistency import *

def operator_stack_residuals_classification_rows(gns_maps: Sequence[dict], alg_maps: Sequence[dict], ce_rows: Sequence[dict], mod_rows: Sequence[dict], comp_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", "")), str(r.get("state", ""))) for seq in [gns_maps, alg_maps, ce_rows, mod_rows, comp_rows] for r in seq if r.get("branching", "") != ""})
    for b, mode, st in keys:
        filt = lambda r, b=b, mode=mode, st=st: int(r.get("branching", -1)) == b and str(r.get("mode")) == mode and str(r.get("state")) == st and int(float(r.get("available", 1))) != 0
        reference = int(is_reference_model(mode, st))
        max_gns = _max_metric(gns_maps, "GNS_generator_Gram_relative_error", filt)
        max_cyc = _max_metric(gns_maps, "cyclic_vector_error", filt)
        max_prod = _max_metric(alg_maps, "product_morphism_residual", filt)
        max_star = _max_metric(alg_maps, "star_compatibility_error", filt)
        max_center = _max_metric(alg_maps, "center_preservation_error", filt)
        max_ce = _max_metric(ce_rows, "CE_commuting_square_error", filt)
        max_ce_state = _max_metric(ce_rows, "CE_state_preservation_drift", filt)
        max_mod = _max_metric(mod_rows, "finite_preflow_delta_commuting_square_error", filt)
        max_mod_K = _max_metric(mod_rows, "K_intertwining_relative_error", filt)
        comp_filt = lambda r, b=b, mode=mode, st=st: int(r.get("branching", -1)) == b and str(r.get("mode")) == mode and str(r.get("state")) == st
        max_comp = _max_metric(comp_rows, "direct_vs_composed_residual", comp_filt)
        max_obj = _max_metric(comp_rows, "object_drift_4_vs_6", comp_filt)
        unavailable = sum(1 for seq in [gns_maps, alg_maps, ce_rows, mod_rows] for r in seq if int(r.get("branching", -1)) == b and str(r.get("mode")) == mode and str(r.get("state")) == st and int(float(r.get("available", 1))) == 0)
        strict_star_hom_residual_le_tolerance = int(math.isfinite(max_prod) and max_prod <= 1e-6 and math.isfinite(max_star) and max_star <= 1e-8 and math.isfinite(max_center) and max_center <= 1e-6)
        product_condition_not_met = int((math.isfinite(max_prod) and max_prod > 1e-1) or (math.isfinite(max_center) and max_center > 1e-1))
        gns_condition_not_met = int(math.isfinite(max_gns) and max_gns > 2.5e-1)
        ce_condition_not_met = int((math.isfinite(max_ce) and max_ce > 5e-2) or (math.isfinite(max_ce_state) and max_ce_state > 5e-2))
        modular_condition_not_met = int((math.isfinite(max_mod) and max_mod > 1e-1) or (math.isfinite(max_mod_K) and max_mod_K > 1e-1))
        composition_condition_not_met = int((math.isfinite(max_comp) and max_comp > 1e-2) or (math.isfinite(max_obj) and max_obj > 2.5e-1))
        record_gns_composition_finite_object = int(st == "record" and unavailable == 0 and not gns_condition_not_met and math.isfinite(max_comp) and max_comp <= 1e-2)
        if unavailable:
            computed_status = "operator_stack_unavailable_unmet_condition"
        elif record_gns_composition_finite_object and product_condition_not_met:
            computed_status = "record_GNS_composition_finite_object_but_not_star_hom_and_not_modular_residual_le_tolerance"
        elif st == "record":
            computed_status = "record_operator_stack_residuals_measurement_active"
        elif st == "live" and (gns_condition_not_met or product_condition_not_met or modular_condition_not_met or composition_condition_not_met):
            computed_status = "live_backreaction_projection_residual_visible"
        elif st == "sym":
            computed_status = "sym_reference_operator_stack_residuals_control"
        elif strict_star_hom_residual_le_tolerance:
            computed_status = "strict_star_hom_finite_object_residual_le_tolerance"
        else:
            computed_status = "operator_stack_residuals_measurement_active"
        rows.append({
            "branching": b,
            "mode": mode,
            "state": st,
            "reference_model": reference,
            "unavailable_rows": unavailable,
            "max_GNS_generator_Gram_relative_error": max_gns,
            "max_cyclic_vector_error": max_cyc,
            "max_product_morphism_residual": max_prod,
            "max_star_compatibility_error": max_star,
            "max_center_preservation_error": max_center,
            "max_CE_commuting_square_error": max_ce,
            "max_CE_state_preservation_drift": max_ce_state,
            "max_modular_delta_error": max_mod,
            "max_K_intertwining_relative_error": max_mod_K,
            "max_direct_vs_composed_residual": max_comp,
            "max_object_drift_4_vs_6": max_obj,
            "strict_star_hom_residual_le_tolerance": strict_star_hom_residual_le_tolerance,
            "record_GNS_composition_finite_object": record_gns_composition_finite_object,
            "product_morphism_residual_condition_not_met": product_condition_not_met,
            "GNS_Gram_drift_condition_not_met": gns_condition_not_met,
            "CE_condition_not_met": ce_condition_not_met,
            "modular_preflow_condition_not_met": modular_condition_not_met,
            "composition_coherence_condition_not_met": composition_condition_not_met,
            "computed_status": computed_status,
            "condition_note": "operator_stack_rows_are_real_residual_measurements; only carrier_state_is_residual_le_tolerance_at_cnna_analysis; no_full_GNS_algebra_inverse_system_statement",
        })
    return rows


def final_computed_status_rows_full(genesis: Sequence[dict], parameter_rows: Sequence[dict], projection: Sequence[dict], orientation: Sequence[dict], carrier: Sequence[dict], state_rows: Sequence[dict], region_rows: Sequence[dict], gns_rows0: Sequence[dict], gns_maps: Sequence[dict], alg_maps: Sequence[dict], ce_rows: Sequence[dict], mod_rows: Sequence[dict], comp_rows: Sequence[dict], measure_condition_note_rows: Sequence[dict], operator_class_rows: Sequence[dict]) -> List[dict]:
    reference_param = all(r.get("computed_status") == "b_L_only_reference_path_residual_le_tolerance" for r in parameter_rows)
    genesis_residual_le_tolerance = all(r.get("computed_status") == "emptyset_genesis_residual_le_tolerance" for r in genesis if r.get("mode") == REFERENCE_MODE)
    projection_residual_le_tolerance = all(r.get("computed_status") == "projection_grammar_residual_le_tolerance" for r in projection if r.get("mode") == REFERENCE_MODE)
    orient_residual_le_tolerance = any(r.get("computed_status") == "F1F2_skew_axis_residual_le_tolerance" and r.get("mode") == REFERENCE_MODE and r.get("state") == REFERENCE_STATE for r in orientation)
    carrier_residual_le_tolerance = all("residual_le_tolerance" in str(r.get("computed_status")) or "condition_not_met" in str(r.get("computed_status")) for r in carrier if r.get("mode") == REFERENCE_MODE)
    state_residual_le_tolerance = all(_float_field(r, "TV", 1.0) <= 5.0e-2 for r in state_rows if r.get("mode") == REFERENCE_MODE and r.get("state") in {"live", "record"})
    region_ok = any(r.get("computed_status") == "regional_DtN_response_residual_le_tolerance" and r.get("mode") == REFERENCE_MODE and r.get("state") == REFERENCE_STATE for r in region_rows)
    gns_ok = any("finite_GNS_pre_representation" in str(r.get("computed_status")) and r.get("mode") == REFERENCE_MODE and r.get("state") == REFERENCE_STATE for r in gns_rows0)
    reference_unavailable = [r for r in list(gns_maps) + list(alg_maps) + list(ce_rows) + list(mod_rows) if r.get("reference_model") == 1 and int(float(r.get("available", 1))) == 0]
    maps_available = (not reference_unavailable) and any(r.get("available") == 1 and r.get("reference_model") == 1 for r in gns_maps) and any(r.get("available") == 1 and r.get("reference_model") == 1 for r in alg_maps) and any(r.get("available") == 1 and r.get("reference_model") == 1 for r in ce_rows) and any(r.get("available") == 1 and r.get("reference_model") == 1 for r in mod_rows)
    measure_rank_bound_visible = all(str(r.get("status")) in {"residual_le_tolerance", "rank_bound_visible", "control_visible", "reference_baseline"} for r in measure_condition_note_rows if r.get("mode") == REFERENCE_MODE)
    reference_operator_rows = [r for r in operator_class_rows if r.get("reference_model") == 1]
    reference_class = reference_operator_rows[0] if reference_operator_rows else {}
    strict_star_hom_residual_le_tolerance = int(reference_class.get("strict_star_hom_residual_le_tolerance", 0) or 0)
    live_backreaction_projection_residual_visible = int(any(r.get("state") == REFERENCE_STATE and r.get("mode") == REFERENCE_MODE and str(r.get("computed_status")) == "live_backreaction_projection_residual_visible" for r in operator_class_rows))
    record_operator_projective_finite_object = int(any(r.get("state") == "record" and r.get("mode") == REFERENCE_MODE and "record_GNS_composition_finite_object" in str(r.get("computed_status")) for r in operator_class_rows))
    algebra_star_hom_failed = int(any(r.get("reference_model") == 1 and int(r.get("product_morphism_residual_condition_not_met", 0)) == 1 for r in operator_class_rows))
    ce_condition_not_met = int(any(r.get("reference_model") == 1 and int(r.get("CE_condition_not_met", 0)) == 1 for r in operator_class_rows))
    modular_condition_not_met = int(any(r.get("reference_model") == 1 and int(r.get("modular_preflow_condition_not_met", 0)) == 1 for r in operator_class_rows))
    composition_condition_not_met = int(any(r.get("reference_model") == 1 and int(r.get("composition_coherence_condition_not_met", 0)) == 1 for r in operator_class_rows))
    carrier_state_residual_le_tolerance = reference_param and genesis_residual_le_tolerance and projection_residual_le_tolerance and orient_residual_le_tolerance and carrier_residual_le_tolerance and state_residual_le_tolerance and region_ok and gns_ok and measure_rank_bound_visible
    all_foundational_ok = carrier_state_residual_le_tolerance and maps_available
    if not all_foundational_ok:
        computed_status = "cnna_has_foundational_unmet_conditions_review_ledgers"
    elif strict_star_hom_residual_le_tolerance and not live_backreaction_projection_residual_visible and not ce_condition_not_met and not modular_condition_not_met and not composition_condition_not_met:
        computed_status = "cnna_full_operator_inverse_system_finite_object_residual_le_tolerance"
    else:
        computed_status = "cnna_carrier_state_inverse_system_residual_le_tolerance_operator_stack_residuals_measurement_active"
    return [{
        "condition": "cnna_dependency_state_full_start_script",
        "b_L_only_reference_path_residual_le_tolerance": int(reference_param),
        "emptyset_genesis_residual_le_tolerance": int(genesis_residual_le_tolerance),
        "projection_grammar_residual_le_tolerance": int(projection_residual_le_tolerance),
        "F1F2_skew_current_residual_le_tolerance": int(orient_residual_le_tolerance),
        "carrier_inverse_system_residual_le_tolerance": int(carrier_residual_le_tolerance),
        "state_inverse_system_residual_le_tolerance": int(state_residual_le_tolerance),
        "regional_DtN_available": int(region_ok),
        "finite_GNS_pre_representation_available": int(gns_ok),
        "GNS_Algebra_CE_Modular_interlevel_maps_available": int(maps_available),
        "reference_operator_rows_unavailable": len(reference_unavailable),
        "measure_rank_bounds_visible": int(measure_rank_bound_visible),
        "record_operator_projective_finite_object": record_operator_projective_finite_object,
        "live_backreaction_projection_residual_visible": live_backreaction_projection_residual_visible,
        "algebra_star_hom_failed": algebra_star_hom_failed,
        "strict_star_hom_residual_le_tolerance": strict_star_hom_residual_le_tolerance,
        "CE_commuting_square_condition_not_met": ce_condition_not_met,
        "modular_preflow_condition_not_met": modular_condition_not_met,
        "composition_coherence_condition_not_met": composition_condition_not_met,
        "operator_stack_result_status": "residual_measurement_not_inverse_system_residual_le_tolerance" if not strict_star_hom_residual_le_tolerance else "operator_inverse_system_finite_object",
        "state_projectivity_conditions_not_met_present": int(any("condition_not_met" in str(r.get("computed_status")) for r in state_rows)),
        "final_computed_status": computed_status,
        "condition_note": "Carrier/State inverse-system start may be residual_le_tolerance while GNS/Algebra/CE/Modular remains residual measurement; live and record are structural layers; sym is the only state control; no_von_Neumann_no_KMS_no_TypeIII_no_split",
    }]


def write_markdown_full(outdir: Path, args, finals: Sequence[dict]) -> None:
    final = finals[0] if finals else {}
    text = f"""# CNNA construction analysis — strict-status empty-set start with live/record operator-stack measurement

## Computed status

`{final.get('final_computed_status', 'no_final_computed_status')}`

## Scope

This is the CNNA construction-analysis harness. It reconstructs the finite derivation chain from the empty set up to the compressed carrier/GNS construction condition_notes and exposes first inter-level maps, but it separates Carrier/State residual_le_tolerance results from residual-bearing GNS/Algebra/CE/Modular measurements.

Reference model path:

```text
CNNA(b,L)
```

The columns `mode`, `sym`, reversed sibling order, numerical tolerances and region sample limits are controls/comparison families.  `record` is not a control: it is the fixed birth-history layer used to measure later live backreaction. None of these are counted as free model parameters of the reference CNNA path.

## Included chain

```text
∅
→ empty_state
→ birth_root_from_empty
→ sequential dynamic growth to L
→ live current layer and record fixed birth-history layer; sym symmetric reference control
→ F1/F2 provenance axes
→ signed skew/current layer separate from positive carrier
→ terminal Parseval carrier effects as control trace
→ true compressed carrier/GNS state: Q, E_v=z_v z_v^T, D_N, p_v=tr(D_N E_v)
→ terminal diagonal response-load state retained only as control proxy
→ center/noncenter sector drift for the true compressed state
→ regional Schur/Kron DtN responses
→ A_in|C ⊂ N_A(C) ⊂ A_out|C finite response algebras
→ finite GNS pre-representation
→ GNS U maps, algebra Π maps, CE commuting-square real residual derived_quantity rows
→ finite modular logD/preflow residual derived_quantity rows
→ direct 4←6 vs composed 4←5←6 coherence with strict computed_status coupling
```

## Preserved measure/cylinder rank-kernel conditions

- P0 prefix system visible.
- M1 positive carrier visible.
- M2a count/uniform carrier exact.
- M2b local S-density remains an rank_bound/condition_note and is not promoted to a measure.
- M3 modes remain comparison controls; sym remains the only state-control reference.
- M4 signed current survives over the positive carrier and is kept separate from it.

## Operator-stack status

Carrier/State projectivity is evaluated separately from the operator stack. CNNA analysis restores the compressed carrier/GNS state as the main state track and keeps the terminal diagonal state only as a control. GNS/Algebra/CE/Modular rows are real diagram tests with quantified residuals; a strict projective *-algebra/GNS inverse system is not stated unless the strict residual flags are residual_le_tolerance.

## Strict non-statements

No von Neumann algebra, no Type-III property, no KMS property, no AQFT split property, no strict *-homomorphism limit, and no completed infinite GNS Hilbert space are stated here.

## Default configuration used in package run

```text
branching = {args.branching}
levels    = {args.levels}
modes     = {args.modes}
states    = {args.states}
```
"""
    (outdir / "SUMMARY_cnna.md").write_text(text, encoding="utf-8")
    (outdir / "RESULTS_cnna.md").write_text(text, encoding="utf-8")
    notes = """# Implementation notes

- No external construction script is imported.
- No previous CSV/JSON/MD output is read as construction input.
- All structures are rebuilt in this script from the empty state.
- `linear/log/saturating` modes are retained as comparison controls; `sym` is the symmetric reference control; `record` is retained as the fixed birth-history structural layer; the reference path is explicitly flagged as `CNNA(b,L)`.
- Schur complements use `np.linalg.solve`; no `the dense inverse routine` is used.
- The operator inter-level maps are label-span finite maps. Their drifts are measured and wired into the final computed_status; they are not yet a property of strict star-homomorphic inverse-limit existence.
"""
    (outdir / "IMPLEMENTATION_NOTES_cnna.md").write_text(notes, encoding="utf-8")
    consistency_check = f"""# Consistency check

```bash
python3 -m py_compile run_cnna.py
python3 run_cnna.py --outdir {outdir.name}
# heavier optional comparison:
python3 run_cnna.py --branching 3 4 --levels 4 5 6 --modes linear log saturating --states live record sym --max-regions 1
```

The package was generated with an internal run and emitted the final computed_status JSON.
"""
    (outdir / "CONSISTENCY_CHECK_cnna.md").write_text(consistency_check, encoding="utf-8")
    condition_notes = """# Conditions

- L is level time of the finite self-regularized growth object, not a continuum cutoff.
- b and L are the only reference model parameters.
- Modes are retained as comparison controls.
- `record` is not a control; it is the fixed birth-history layer of the growing network.
- `sym` is the symmetric reference control.
- Positive carrier is not the signed current.
- Local S-response density is not promoted to a cylinder measure.
- Finite GNS derived_quantity rows are not a completed Hilbert-space construction.
- Algebra Pi maps are not named residual_le_tolerance unless product/star/center residuals are below fixed thresholds.
- Record/live operator-projectivity is evaluated separately.
- No von Neumann algebra, KMS property, Type-III limit, or split property is stated.
"""
    (outdir / "CONDITIONS_cnna.md").write_text(condition_notes, encoding="utf-8")
