from __future__ import annotations

from typing import List

from cnna.core.operator_test_config import OperatorTestConfig


BIANCONI_STATISTICS_CONDITIONS = (
    {
        "condition_id": "tree_to_simplicial_duality_kinematics",
        "condition_name": "contracting tree growth to deformed simplicial-complex growth",
        "finite_object": "CNNA sequential b-ary provenance tree and its deformed Sierpinski-like dual approximants",
        "test_question": "Does the CNNA dual growth satisfy the incidence/attachment kinematics required for NGF/CQNM-style statistics, or does it define a distinct subdivision kinematics?",
        "required_data": "simplex incidence counts by dimension, birth order, live-response weights pushed to faces",
        "pass_condition": "manifold-like s=-1 incidence constraints or explicitly measured deviations for the CNNA subdivision process",
        "falsification_condition_note": "Do not import Bianconi statistics from NGF unless the induced dual kinematics passes or is rederived for contraction/subdivision.",
    },
    {
        "condition_id": "face_occupancy_statistics_by_dimension",
        "condition_name": "Bose/Boltzmann/Fermi sector statistics on simplicial faces",
        "finite_object": "nodes/links/faces/higher simplices of the deformed dual complex",
        "test_question": "Do face generalized degrees follow dimension-dependent Bose, Boltzmann, or Fermi-like distributions when energies are CNNA live-response pushforwards?",
        "required_data": "face dimension delta, generalized degree, live energy/fitness proxy, beta/chemical-potential rule derived not fitted",
        "pass_condition": "sector-specific occupancy law is preferred over symmetric-null and shuffled-energy controls",
        "falsification_condition_note": "A fit with free beta/mu is not evidence; beta/mu must come from CNNA scale/branching or be declared as a control fit.",
    },
    {
        "condition_id": "branching_dimension_sector_prediction",
        "condition_name": "b-dependent sector availability",
        "finite_object": "b=3 SG-like and b=4 ST-like deformed duals",
        "test_question": "Does b qualitatively select the available statistics sectors, rather than acting only as a parameter_sensitivity parameter?",
        "required_data": "b=3/b=4 dual dimensions, nondegenerate face dimensions, sector occupancy tables",
        "pass_condition": "b=4 deformed tetrahedral/simplicial dual exposes the full intended sector family; b=3 exposes the lower-dimensional restricted sector family; symmetric SG/ST are null controls",
        "falsification_condition_note": "This is a hypothesis/condition, not a x result.  Failure would not falsify CNNA; it would falsify the Bianconi-statistics bridge.",
    },
    {
        "condition_id": "statistics_to_CCR_CAR_bridge",
        "condition_name": "statistics sector to CCR/CAR/Fock selection",
        "finite_object": "sector occupancy law plus one-particle S/A form layer",
        "test_question": "Can the bosonic/fermionic/boltzmannian statistics choice for second quantization be derived sectorwise from the dual complex?",
        "required_data": "dominance inequalities on sectors, Fermi incidence saturation, Bose degree distribution, Boltzmann link sector controls",
        "pass_condition": "the sector statistic selects the Fock functor without imposing it externally",
        "falsification_condition_note": "Ensemble occupancy statistics are not operator commutation relations; the bridge needs its own finite test.",
    },
    {
        "condition_id": "topological_Dirac_convergence_condition",
        "condition_name": "Bianconi topological Dirac as NCG/fractal/Fock convergence point",
        "finite_object": "topological cochains on the deformed simplicial complex and CNNA F1/F2 skew-signature",
        "test_question": "Can a topological Dirac/chiral operator on the CNNA dual complex reproduce or refine the D_F1F2 finite_object?",
        "required_data": "boundary/coboundary incidence matrices, Hodge/topological Dirac spectrum, comparison to F1/F2 skew-signature and B-current",
        "pass_condition": "Dirac spectrum/signature is stable under refinement and coarsens back to F1/F2 geometry",
        "falsification_condition_note": "Do not call this Connes spectral triple until the operator-domain, commutator-boundedness, and real-structure conditions are tested.",
    },
)


def bianconi_statistics_bridge_condition_rows() -> List[dict]:
    return [dict(row) for row in BIANCONI_STATISTICS_CONDITIONS]


def bianconi_branching_sector_expectation_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b in config.branching:
        b = int(b)
        if b == 3:
            dual = "deformed_SG_like_2_complex_finite_object"
            expected = "lower_dimensional_restricted_sector_family_hypothesis"
            computed_status = "statistics_bridge_hypothesis_requires_dual_incidence_measurement"
        elif b == 4:
            dual = "deformed_ST_like_3_complex_finite_object"
            expected = "full_Bose_Boltzmann_Fermi_sector_family_finite_object_if_NGF_s_minus_1_kinematics_passes"
            computed_status = "statistics_bridge_hypothesis_requires_dual_incidence_measurement"
        else:
            dual = "higher_or_nonstandard_deformed_simplicial_dual_finite_object"
            expected = "sector_family_undetermined_without_dual_dimension_and_incidence_measurement"
            computed_status = "statistics_bridge_out_of_documented_b3_b4_scope_control"
        rows.append({
            "b": b,
            "dual_geometry_proxy": dual,
            "symmetric_null_reference": "symmetric_SG_ST_like_control_not_physical_CNNA_target",
            "expected_sector_hypothesis": expected,
            "live_response_energy_pushforward_required": 1,
            "incidence_numbers_measured_in_current_core": 0,
            "NGF_s_minus_1_kinematics_external_reproduction_current_core": 0,
            "statistics_as_CCR_CAR_choice_stated": 0,
            "computed_status": computed_status,
        })
    return rows


def bianconi_statistics_bridge_report(conditions: List[dict], expectations: List[dict]) -> str:
    lines = [
        "# Bianconi simplicial statistics bridge dependency_table",
        "",
        "This dependency_table records the statistics bridge shared by the AQFT-internal Fock/GNS ladder and the deformed simplicial path: the CCR/CAR/Boltzmann choice should not be imposed if it can be derived from the tree-to-deformed-simplicial dual.  The symmetric SG/ST geometries are reference/null controls; the CNNA target is deformed and non-exactly self-similar.",
        "",
        "## Required conditions",
        "",
    ]
    for row in conditions:
        lines.append(f"- `{row['condition_id']}`: {row['test_question']}  Condition: {row['falsification_condition_note']}")
    lines.extend(["", "## Branching-sector hypotheses", ""])
    for row in expectations:
        lines.append(f"- b={row['b']}: {row['dual_geometry_proxy']} -> {row['expected_sector_hypothesis']} ({row['computed_status']})")
    lines.extend([
        "",
        "Condition: Bianconi/NGF statistics are not imported as a property for CNNA.  The induced dual incidence process must be measured.  If the CNNA process is a contraction/subdivision rather than NGF attachment, the distributions must be remeasured for that kinematics.",
    ])
    return "\n".join(lines) + "\n"
