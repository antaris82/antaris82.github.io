from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.derived_quantities.structural_ledgers import *

def compressed_carrier_state_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str], args) -> Tuple[List[dict], List[dict], List[dict], List[dict]]:
    """Rows for true compressed carrier/GNS state projective maps.

    This is the missing compressed carrier/GNS construction track.  The old terminal diagonal state
    remains a control; these rows are the main compressed carrier/GNS state continuation.
    """
    object_rows: List[dict] = []
    proj_rows: List[dict] = []
    sector_rows: List[dict] = []
    comp_rows: List[dict] = []
    levels_sorted = sorted(set(levels))
    cache: Dict[Tuple[int, int, str, str], Optional[dict]] = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            obj = compressed_state_object(model, st, args)
            cache[(b, L, mode, st)] = obj
            if obj is None:
                object_rows.append({"branching": b, "max_level": L, "mode": mode, "state": st, "object_available": 0, "computed_status": "compressed_carrier_state_object_unavailable"})
                continue
            p = obj["state_weights"]
            tr = obj["traces"]
            resp = obj["response_weights"]
            object_rows.append({
                "branching": b,
                "max_level": L,
                "mode": mode,
                "state": st,
                "reference_model": int(is_reference_model(mode, st)),
                "object_available": 1,
                "region_id": obj["spec"].region_id,
                "n_boundary_atoms": len(obj["spec"].boundary),
                "n_interior": len(obj["spec"].interior),
                "compressed_dim": obj["Q"].shape[1],
                "role_basis_names": " ".join(obj["qnames"]),
                "effect_formula": "E_v=z_v z_v^T_with_z_v_row_of_boundary_role_basis_Q",
                "state_formula": "p_v=tr(D_N E_v)",
                "density_variant": "center_restricted_D_N",
                "density_rank": obj["D_N_info"].get("density_rank", ""),
                "density_negative_mass": obj["D_N_info"].get("density_negative_mass", ""),
                "D_to_N_projected_residual_fro": obj["D_N_info"].get("D_to_N_projected_residual_fro", ""),
                "sumE_completeness_error": obj["sumE_completeness_error"],
                "state_sum": float(np.sum(p)),
                "trace_sum": float(np.sum(tr)),
                "response_sum": float(np.sum(resp)),
                "TV_state_vs_trace": tv_arr(p, tr),
                "TV_state_vs_response_energy": tv_arr(p, resp),
                "condition_note": "true_compressed_carrier_GNS_state_no_terminal_diagonal_proxy_no_infinite_state_statement",
                "computed_status": "compressed_carrier_state_object_residual_le_tolerance" if obj["sumE_completeness_error"] < 1e-9 and abs(float(np.sum(p))-1.0) < 1e-9 else "compressed_carrier_state_object_condition_not_met",
            })
    for (b, M, mode, rev), _mM in sorted(models.items()):
        if rev:
            continue
        for L in levels_sorted:
            if L >= M:
                continue
            for st in states:
                objM = cache.get((b, M, mode, st))
                objL = cache.get((b, L, mode, st))
                if objM is None or objL is None:
                    proj_rows.append({"branching": b, "mode": mode, "state": st, "source_level": M, "target_level": L, "available": 0, "computed_status": "compressed_state_projection_unavailable"})
                    continue
                dM = compressed_projective_distribution(objM, L)
                dL = compressed_projective_distribution(objL, L)
                keys = sorted(set(dM.keys()) | set(dL.keys()))
                trace_tv = tv_arr(values_for_keys(dL, keys, "trace"), values_for_keys(dM, keys, "trace"))
                state_tv = tv_arr(values_for_keys(dL, keys, "state"), values_for_keys(dM, keys, "state"))
                resp_tv = tv_arr(values_for_keys(dL, keys, "response"), values_for_keys(dM, keys, "response"))
                center_mass_drift, center_profile, center_contrib = sector_profile_tv(dL, dM, "state", key_is_center)
                non_mass_drift, non_profile, non_contrib = sector_profile_tv(dL, dM, "state", lambda k: not key_is_center(k))
                proj_rows.append({
                    "branching": b, "mode": mode, "state": st, "source_level": M, "target_level": L,
                    "reference_model": int(is_reference_model(mode, st)),
                    "available": 1,
                    "state_track": "true_compressed_carrier_GNS_state",
                    "trace_global_TV": trace_tv,
                    "state_global_TV": state_tv,
                    "response_energy_global_TV": resp_tv,
                    "state_vs_response_TV_gap": resp_tv - state_tv,
                    "center_state_mass_drift_abs": center_mass_drift,
                    "center_state_conditional_TV": center_profile,
                    "noncenter_state_mass_drift_abs": non_mass_drift,
                    "noncenter_state_conditional_TV": non_profile,
                    "state_mass_only_TV_two_sector": center_contrib + non_contrib,
                    "condition_note": "projective_drift_decomposition_on_E_v_zzt_state",
                    "computed_status": "compressed_GNS_state_projective_finite_object" if state_tv <= 0.08 and (math.isnan(non_profile) or non_profile <= 0.12) else "compressed_GNS_state_projective_drift_condition_not_met",
                })
                for sector, pred, md, prof in [("center", key_is_center, center_mass_drift, center_profile), ("noncenter", lambda k: not key_is_center(k), non_mass_drift, non_profile)]:
                    sector_rows.append({
                        "branching": b, "mode": mode, "state": st, "source_level": M, "target_level": L,
                        "state_track": "true_compressed_carrier_GNS_state",
                        "sector": sector,
                        "mass_drift_abs": md,
                        "conditional_profile_TV": prof,
                        "condition_note": "sector_decomposition_of_p_v_equals_trace_D_N_E_v",
                    })
        if {4, 5, 6}.issubset(set(levels_sorted)) and M == 6:
            for st in states:
                obj6 = cache.get((b, 6, mode, st)); obj5 = cache.get((b, 5, mode, st)); obj4 = cache.get((b, 4, mode, st))
                if obj6 is None or obj5 is None or obj4 is None:
                    comp_rows.append({"branching": b, "mode": mode, "state": st, "source_level": 6, "mid_level": 5, "target_level": 4, "available": 0, "computed_status": "compressed_state_composition_unavailable"})
                    continue
                d64 = compressed_projective_distribution(obj6, 4)
                d65 = compressed_projective_distribution(obj6, 5)
                # via 5 then 4: aggregate the role|word keys by truncating the word part.
                via: Dict[str, dict] = {}
                for key, vals in d65.items():
                    role, word = key.split("|", 1)
                    if word == "root":
                        addr = tuple()
                    else:
                        addr = tuple(int(x) for x in word.split(".") if x != "")
                    k4 = f"{role}|" + ("root" if len(prefix(addr, 4)) == 0 else ".".join(map(str, prefix(addr, 4))))
                    if k4 not in via:
                        via[k4] = {"trace": 0.0, "state": 0.0, "response": 0.0, "n_atoms": 0}
                    for field in ["trace", "state", "response"]:
                        via[k4][field] += float(vals.get(field, 0.0))
                    via[k4]["n_atoms"] += int(vals.get("n_atoms", 0))
                for field in ["trace", "state", "response"]:
                    norm = normalize_dict({k: max(0.0, v[field]) for k, v in via.items()})
                    for k, val in norm.items():
                        via[k][field] = val
                keys = sorted(set(d64.keys()) | set(via.keys()))
                comp_rows.append({
                    "branching": b, "mode": mode, "state": st, "source_level": 6, "mid_level": 5, "target_level": 4,
                    "reference_model": int(is_reference_model(mode, st)),
                    "available": 1,
                    "state_track": "true_compressed_carrier_GNS_state",
                    "trace_composition_TV": tv_arr(values_for_keys(d64, keys, "trace"), values_for_keys(via, keys, "trace")),
                    "state_composition_TV": tv_arr(values_for_keys(d64, keys, "state"), values_for_keys(via, keys, "state")),
                    "response_composition_TV": tv_arr(values_for_keys(d64, keys, "response"), values_for_keys(via, keys, "response")),
                    "condition_note": "composition_on_same_source_distribution_exactly_tests_key_truncation_not_interlevel_object_drift",
                    "computed_status": "compressed_GNS_state_composition_residual_le_tolerance" if tv_arr(values_for_keys(d64, keys, "state"), values_for_keys(via, keys, "state")) < 1e-12 else "compressed_GNS_state_composition_condition_not_met",
                })
    return object_rows, proj_rows, sector_rows, comp_rows


def state_construction_track_ledger_rows() -> List[dict]:
    return [
        {
            "track": "terminal_diagonal_response_load_state",
            "implemented_in_cnna": 1,
            "formula": "E_v=e_v e_v^T_on_terminal_address_basis; D_L=diag(p_v); p_v=tr(D_L E_v)",
            "status": "control_proxy_not_reference_compressed_carrier_GNS_state",
            "condition_note": "finite terminal diagonal carrier state; useful for CNNA projective derived_quantity rows; not a unique infinite GNS state",
        },
        {
            "track": "compressed_carrier_GNS_state",
            "implemented_in_cnna": 1,
            "formula": "E_v=z_v z_v^T on compressed boundary role/mode response basis; D_N=positive trace-normalized projection to N_A(C); p_v=tr(D_N E_v)",
            "status": "reference_compressed_carrier_GNS_state_reconstructed_for_projective_maps",
            "condition_note": "finite compressed carrier/GNS state only; no infinite state or completed GNS statement",
        },
    ]
