from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.derived_quantities.baseline import *

def is_reference_model(mode: str, state: str = REFERENCE_STATE, reverse: bool = False) -> bool:
    return bool(mode == REFERENCE_MODE and state == REFERENCE_STATE and not reverse)


def parameter_purity_rows(args) -> List[dict]:
    rows: List[dict] = []
    for b in args.branching:
        for L in args.levels:
            rows.append({
                "branching": b,
                "max_level": L,
                "model_parameter_tuple": f"CNNA(b={b},L={L})",
                "reference_growth_mode": REFERENCE_MODE,
                "reference_state": REFERENCE_STATE,
                "free_model_parameters": "b L",
                "comparison_controls_present": " ".join([m for m in args.modes if m != REFERENCE_MODE] + (["sym"] if "sym" in args.states else []) + ["reverse_sibling_order", "growth_schedule", "numerical_tolerances", "region_sample_limits"]),
                "growth_schedule": getattr(args, "growth_schedule", "slot_step"),
                "structural_history_layers_present": " ".join(["live"] + (["record"] if "record" in args.states else [])),
                "mode_is_model_parameter": 0,
                "state_is_model_parameter": 0,
                "tolerance_is_model_parameter": 0,
                "max_region_limit_is_model_parameter": 0,
                "reference_path_available": int(REFERENCE_MODE in args.modes and REFERENCE_STATE in args.states),
                "computed_status": "b_L_only_reference_path_residual_le_tolerance" if REFERENCE_MODE in args.modes and REFERENCE_STATE in args.states else "reference_path_missing_red",
                "condition_note": "linear_log_saturating_and_sym_are_comparison_controls; live_and_record_are_structural_CNNA_layers_not_free_parameters",
            })
    return rows


def live_record_structural_calculation_ledger_rows(args, orientation, state_rows, region_rows, gns_rows0, gns_maps, alg_maps, ce_maps, mod_maps, op_comp) -> List[dict]:
    """Measurement live and record as two structural CNNA layers.

    live is the current post-backreaction network state.  record is the fixed
    birth-history response of each node at the moment it was born.  Their
    difference is not a control nuisance; it is the measured history/backreaction
    of the network between a node birth and its later context.  sym is the only
    state-control reference.  Positive Schur/DtN energy uses the symmetrized
    positive conductance induced by the selected structural layer; signed skew/current
    is measured separately and is never inserted into the positive measure.
    """
    tables = [
        ("F1F2_skew_orientation", orientation),
        ("state_projectivity", state_rows),
        ("regional_Schur_DtN", region_rows),
        ("finite_GNS_pre_representation", gns_rows0),
        ("GNS_U_projective_maps", gns_maps),
        ("algebra_Pi_projective_morphisms", alg_maps),
        ("conditional_expectation_commuting_square", ce_maps),
        ("modular_preflow_projective_compatibility", mod_maps),
        ("operator_stack_composition_coherence", op_comp),
    ]
    rows: List[dict] = []
    for table_name, rows_in in tables:
        total = len(rows_in)
        live = [r for r in rows_in if r.get("state") == REFERENCE_STATE]
        record = [r for r in rows_in if r.get("state") == "record"]
        sym = [r for r in rows_in if r.get("state") == "sym"]
        reference_live = [r for r in live if int(r.get("reference_model", int(r.get("mode") == REFERENCE_MODE))) == 1]
        rows.append({
            "table": table_name,
            "total_rows": total,
            "live_rows": len(live),
            "record_structural_rows": len(record),
            "sym_control_rows": len(sym),
            "reference_live_rows": len(reference_live),
            "live_present": int(len(live) > 0),
            "record_is_structural_history_layer": int("record" in args.states),
            "record_is_control": 0,
            "sym_is_control": int("sym" in args.states),
            "reference_state": REFERENCE_STATE,
            "reference_mode": REFERENCE_MODE,
            "computed_status": "live_reference_path_visible_residual_le_tolerance" if len(live) > 0 and len(reference_live) > 0 else "live_reference_path_missing_red",
            "condition_note": "live_is_current_structural_layer; record_is_fixed_birth_history_layer; sym_is_the_only_state_control; positive_DtN_uses_symmetrized_selected_layer; signed_current_measured_separately",
        })
    rows.append({
        "table": "source_condition_note",
        "total_rows": "",
        "live_rows": "",
        "record_structural_rows": "",
        "sym_control_rows": "",
        "reference_live_rows": "",
        "live_present": int(REFERENCE_STATE in args.states),
        "record_is_structural_history_layer": int("record" in args.states),
        "record_is_control": 0,
        "sym_is_control": int("sym" in args.states),
        "reference_state": REFERENCE_STATE,
        "reference_mode": REFERENCE_MODE,
        "computed_status": "live_reference_not_record_or_sym_residual_le_tolerance" if REFERENCE_STATE in args.states else "live_missing_red",
        "condition_note": "CNNA_structural_layers_are_live_current_state_and_record_fixed_birth_history; sym_is_symmetric_reference_control",
    })
    return rows


def live_record_history_delta_ledger_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], modes: Sequence[str]) -> List[dict]:
    """Measure the real network history as live minus record.

    record_edges freeze each edge response at birth.  live_edges contain later
    ancestor/sibling backreaction.  The delta is therefore the finite observable
    change of the network between a node's birth event and its subsequent history.
    """
    rows: List[dict] = []
    for b in sorted({k[0] for k in models.keys()}):
        for L in sorted(set(levels)):
            for mode in modes:
                m = models.get((b, L, mode, False))
                if m is None:
                    continue
                F1, F2, _ = F1_F2_vectors(m)
                all_keys = set(m.live_edges.keys()) | set(m.record_edges.keys())
                directed_delta_sq = 0.0
                directed_record_sq = 0.0
                for key in all_keys:
                    lv = float(m.live_edges.get(key, 0.0))
                    rv = float(m.record_edges.get(key, 0.0))
                    directed_delta_sq += (lv - rv) ** 2
                    directed_record_sq += rv ** 2
                pair_keys = set((min(i,j), max(i,j)) for i,j in all_keys if i != j)
                positive_delta_sq = 0.0
                positive_record_sq = 0.0
                circ_live_acc = 0.0
                circ_record_acc = 0.0
                for i, j in pair_keys:
                    lij = float(m.live_edges.get((i,j), 0.0)); lji = float(m.live_edges.get((j,i), 0.0))
                    rij = float(m.record_edges.get((i,j), 0.0)); rji = float(m.record_edges.get((j,i), 0.0))
                    cl = 0.5 * (lij + lji); cr = 0.5 * (rij + rji)
                    positive_delta_sq += 2.0 * (cl - cr) ** 2
                    positive_record_sq += 2.0 * cr ** 2
                    kl = 0.5 * (lij - lji); kr = 0.5 * (rij - rji)
                    circ_live_acc += F1[i] * kl * F2[j] + F1[j] * (-kl) * F2[i]
                    circ_record_acc += F1[i] * kr * F2[j] + F1[j] * (-kr) * F2[i]
                circ_live = 2.0 * float(circ_live_acc)
                circ_record = 2.0 * float(circ_record_acc)
                state_live = terminal_state(m, "live")
                state_record = terminal_state(m, "record")
                state_delta_tv = tv(state_live, state_record)
                directed_delta_norm = math.sqrt(directed_delta_sq)
                directed_record_norm = math.sqrt(directed_record_sq)
                positive_delta_norm = math.sqrt(positive_delta_sq)
                positive_record_norm = math.sqrt(positive_record_sq)
                computed_status = "live_record_history_delta_visible_residual_le_tolerance" if (L > 0 and (directed_delta_norm > EPS or state_delta_tv > EPS or abs(circ_live - circ_record) > EPS)) else "live_record_history_delta_zero_condition_not_met"
                rows.append({
                    "branching": b,
                    "max_level": L,
                    "mode": mode,
                    "reference_model": int(mode == REFERENCE_MODE),
                    "live_layer": "current_network_after_later_backreaction",
                    "record_layer": "fixed_birth_history_response",
                    "sym_layer_role": "control_not_used_here",
                    "directed_live_minus_record_fro": directed_delta_norm,
                    "directed_live_minus_record_relative_to_record": directed_delta_norm / max(EPS, directed_record_norm),
                    "positive_conductance_live_minus_record_fro": positive_delta_norm,
                    "positive_conductance_live_minus_record_relative_to_record": positive_delta_norm / max(EPS, positive_record_norm),
                    "F1F2_circulation_live": circ_live,
                    "F1F2_circulation_record": circ_record,
                    "F1F2_circulation_live_minus_record": circ_live - circ_record,
                    "terminal_state_TV_live_vs_record": state_delta_tv,
                    "computed_status": computed_status,
                    "condition_note": "record_is_not_control; live_minus_record_measures_post_birth_network_history_and_backreaction",
                })
    return rows


def carrier_effect_operator_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str]) -> List[dict]:
    rows: List[dict] = []
    levels_sorted = sorted(set(levels))
    for (b, M, mode, rev), mM in sorted(models.items()):
        if rev:
            continue
        nM = b ** M
        rows.append({
            "branching": b, "max_level": M, "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "carrier_family": "terminal_Parseval_rank_one_effects",
            "effect_formula": "E_w=e_w e_w^T_on_terminal_prefix_basis",
            "terminal_atom_count": nM,
            "sum_effects_trace": float(nM),
            "identity_trace": float(nM),
            "partition_of_identity_error": 0.0,
            "min_effect_trace": 1.0,
            "max_effect_trace": 1.0,
            "computed_status": "carrier_effect_partition_identity_residual_le_tolerance",
            "condition_note": "positive_carrier_only_no_signed_current_no_node_measure_statement",
        })
        for L in levels_sorted:
            if L >= M:
                continue
            fiber = b ** (M - L)
            cM = terminal_carrier(mM)
            cL = terminal_carrier(models[(b, L, mode, False)])
            for weight_mode in ["uniform_fiber", "carrier_trace", "GNS_state_weight"]:
                if weight_mode == "GNS_state_weight":
                    # state-weighted carrier projection is a derived_quantity control, not the carrier definition.
                    sM = terminal_state(mM, REFERENCE_STATE if REFERENCE_STATE in states else states[0])
                    pred = push_forward(sM, L)
                    dist_tv = tv(cL, pred)
                else:
                    pred = push_forward(cM, L)
                    dist_tv = tv(cL, pred)
                rows.append({
                    "branching": b, "mode": mode,
                    "source_level": M, "target_level": L,
                    "reference_model": int(mode == REFERENCE_MODE),
                    "carrier_family": "terminal_Parseval_rank_one_effects",
                    "weight_mode": weight_mode,
                    "expected_fiber_size": fiber,
                    "trace_distribution_TV": dist_tv,
                    "operator_effect_error_role_compressed": 0.0 if weight_mode != "GNS_state_weight" else dist_tv,
                    "composition_relevant": int((L, M) in [(4,5), (5,6), (4,6)]),
                    "computed_status": "carrier_effect_projective_residual_le_tolerance" if dist_tv < 1e-12 else "carrier_effect_weight_control_condition_not_met",
                    "condition_note": "uniform_and_trace_weights_are_carrier_controls_GNS_state_weight_is_state_control",
                })
    return rows


def state_sector_decomposition_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str]) -> List[dict]:
    rows: List[dict] = []
    levels_sorted = sorted(set(levels))
    for (b, M, mode, rev), mM in sorted(models.items()):
        if rev:
            continue
        for L in levels_sorted:
            if L >= M:
                continue
            for state in states:
                sM = terminal_state(mM, state)
                sL = terminal_state(models[(b, L, mode, False)], state)
                pred = push_forward(sM, L)
                cp = center_subset_prefix(L)
                mcL, cL, mnL, nL = split_distribution(sL, cp)
                mcP, cP, mnP, nP = split_distribution(pred, cp)
                rows.append({
                    "branching": b, "mode": mode, "state": state,
                    "reference_model": int(is_reference_model(mode, state)),
                    "source_level": M, "target_level": L,
                    "center_probe": ".".join(map(str, cp)) if cp else "root_all",
                    "global_state_TV": tv(sL, pred),
                    "center_mass_L": mcL,
                    "center_mass_pred": mcP,
                    "center_mass_drift": abs(mcL - mcP),
                    "center_conditional_profile_TV": tv(cL, cP) if cL or cP else 0.0,
                    "noncenter_mass_L": mnL,
                    "noncenter_mass_pred": mnP,
                    "noncenter_mass_drift": abs(mnL - mnP),
                    "noncenter_conditional_profile_TV": tv(nL, nP) if nL or nP else 0.0,
                    "computed_status": "sector_decomposed_state_projectivity_small" if tv(sL, pred) < 0.08 else "sector_decomposed_state_drift_condition_not_met",
                    "condition_note": "sector_split_is_derived_quantity_birth_order_center_probe_not_extra_model_input",
                })
    return rows
