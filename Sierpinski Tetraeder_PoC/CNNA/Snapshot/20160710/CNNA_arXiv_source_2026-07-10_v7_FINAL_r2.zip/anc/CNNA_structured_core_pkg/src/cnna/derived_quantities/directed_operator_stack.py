from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.core.directed_dtn import *
from cnna.derived_quantities.structural_ledgers import is_reference_model


def _first_directed_region(model: EmptySetGrowthModel, args) -> Optional[RegionSpec]:
    # directed-region coverage: use the full terminal sibling-cone region when it fits;
    # otherwise fall back to the deepest deterministic coarse frontier that
    # fits the directed-DtN size condition_notes.  This prevents L>=7 sweeps from being
    # marked as residual_le_tolerance by only reusing L<=6 rows.
    specs = build_coarse_frontier_sibling_regions(
        model,
        max_regions=max(1, args.max_regions),
        max_boundary=args.max_boundary,
        max_interior=args.max_interior,
        max_frontier_level=getattr(args, "directed_frontier_cap", 6),
    )
    return specs[0] if specs else None



def _region_meta(model: EmptySetGrowthModel, spec: RegionSpec) -> dict:
    fl = region_frontier_level(model, spec)
    return {
        "region_pair_type": spec.pair_type,
        "frontier_level": int(fl),
        "terminal_level": int(model.L),
        "coarse_frontier_used": int(fl < int(model.L)),
        "n_boundary_without_env": len(spec.boundary),
        "n_interior": len(spec.interior),
    }

def _response_for_relations(model: EmptySetGrowthModel, state: str, spec: RegionSpec, relations: str, sign_relation: str) -> DirectedSchurResponse:
    if relations == "open_grounded_directed":
        return directed_schur_response_from_model(
            model, state, spec.boundary, spec.interior,
            include_external_degrees=True, matrix_sign_relation=sign_relation,
        )
    if relations == "closed_internal_directed":
        return directed_schur_response_from_model(
            model, state, spec.boundary, spec.interior,
            include_external_degrees=False, matrix_sign_relation=sign_relation,
        )
    if relations == "explicit_environment_port_directed":
        return directed_environment_port_response_from_model(
            model, state, spec.boundary, spec.interior,
            matrix_sign_relation=sign_relation,
        )
    raise ValueError(f"unknown directed response relations: {relations}")


def _matrix_metrics(Lambda: Optional[np.ndarray]) -> dict:
    if Lambda is None:
        return {
            "directed_response_norm": math.nan,
            "symmetric_part_norm": math.nan,
            "skew_part_norm": math.nan,
            "relative_skew_norm": math.nan,
            "S_min_eig": math.nan,
            "S_max_eig": math.nan,
            "S_negative_mass": math.nan,
            "S_psd_tol_ok": 0,
            "skew_symmetry_error": math.nan,
            "symmetric_symmetry_error": math.nan,
        }
    S, A = split_symmetric_skew(Lambda)
    try:
        eig = np.linalg.eigvalsh(S)
        min_eig = float(np.min(eig)) if eig.size else math.nan
        max_eig = float(np.max(eig)) if eig.size else math.nan
        neg_mass = float(np.sum(np.abs(eig[eig < -1.0e-10]))) if eig.size else 0.0
    except np.linalg.LinAlgError:
        min_eig = max_eig = neg_mass = math.nan
    return {
        "directed_response_norm": fro(Lambda),
        "symmetric_part_norm": fro(S),
        "skew_part_norm": fro(A),
        "relative_skew_norm": fro(A) / max(fro(Lambda), EPS),
        "S_min_eig": min_eig,
        "S_max_eig": max_eig,
        "S_negative_mass": neg_mass,
        "S_psd_tol_ok": int(math.isfinite(min_eig) and min_eig >= -1.0e-8),
        "skew_symmetry_error": fro(A + A.T) / max(fro(A), EPS),
        "symmetric_symmetry_error": fro(S - S.T) / max(fro(S), EPS),
    }


def _plane_metrics(Lambda: Optional[np.ndarray], Q: np.ndarray) -> dict:
    if Lambda is None or Q.shape[1] < 2:
        return {
            "signed_plane_dim": int(Q.shape[1]),
            "signed_plane_response_norm": math.nan,
            "signed_plane_symmetric_norm": math.nan,
            "signed_plane_skew_norm": math.nan,
            "signed_plane_relative_skew": math.nan,
            "F1F2_signed_omega": math.nan,
            "F1F2_signed_circulation": math.nan,
            "F1F2_skew_nonzero": 0,
        }
    Lp = Q.T @ Lambda @ Q
    Sp, Ap = split_symmetric_skew(Lp)
    omega = float(Ap[0, 1]) if Ap.shape[0] >= 2 and Ap.shape[1] >= 2 else math.nan
    return {
        "signed_plane_dim": int(Q.shape[1]),
        "signed_plane_response_norm": fro(Lp),
        "signed_plane_symmetric_norm": fro(Sp),
        "signed_plane_skew_norm": fro(Ap),
        "signed_plane_relative_skew": fro(Ap) / max(fro(Lp), EPS),
        "F1F2_signed_omega": omega,
        "F1F2_signed_circulation": 2.0 * omega if math.isfinite(omega) else math.nan,
        "F1F2_skew_nonzero": int(math.isfinite(omega) and abs(omega) > 1.0e-10),
    }


def _reference_open_out_snapshot(model: EmptySetGrowthModel, state: str, args):
    spec = _first_directed_region(model, args)
    if spec is None:
        return None, None, None, None
    res = _response_for_relations(model, state, spec, "open_grounded_directed", "out_degree")
    Qsig, qnames, qrank = signed_role_basis_F1F2(spec.boundary, spec)
    return spec, res, Qsig, qnames


def directed_response_construction_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    relations_list = ["open_grounded_directed", "closed_internal_directed", "explicit_environment_port_directed"]
    sign_relations = ["out_degree", "in_degree"]
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        spec = _first_directed_region(model, args)
        for st in states:
            base = {"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st))}
            if spec is None:
                rows.append({**base, "available": 0, "computed_status": "directed_region_missing", "condition_note": "2_requires_a_sibling_region_under_size_condition_notes"})
                continue
            for sign_relation in sign_relations:
                for relations in relations_list:
                    res = _response_for_relations(model, st, spec, relations, sign_relation)
                    metrics = _matrix_metrics(res.Lambda if res.ok else None)
                    rows.append({
                        **base,
                        "available": int(res.ok and res.Lambda is not None),
                        "region_id": spec.region_id,
                        **_region_meta(model, spec),
                        "matrix_sign_relation": sign_relation,
                        "boundary_response_model": relations,
                        "n_boundary": len(spec.boundary) + (1 if relations == "explicit_environment_port_directed" else 0),
                        "n_interior": len(spec.interior),
                        "response_ok": int(res.ok),
                        "response_error": res.error,
                        "cond_KII": res.cond_KII,
                        "solve_residual": res.solve_residual,
                        "row_sum_residual": res.row_sum_residual,
                        **metrics,
                        "computed_status": "directed_DtN_response_available_without_symmetrization" if res.ok and res.Lambda is not None else "directed_DtN_response_unavailable",
                        "condition_note": "2_no_edge_pair_averaging_no_final_schur_symmetrization; sym_state_is_control_only",
                    })
    return rows


def directed_sa_decomposition_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            spec, res, Qsig, qnames = _reference_open_out_snapshot(model, st, args)
            base = {"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "matrix_sign_relation": "out_degree", "boundary_response_model": "open_grounded_directed"}
            if spec is None or res is None or not res.ok or res.Lambda is None:
                rows.append({**base, "available": 0, "computed_status": "directed_SA_decomposition_unavailable"})
                continue
            metrics = _matrix_metrics(res.Lambda)
            plane = _plane_metrics(res.Lambda, Qsig)
            rows.append({
                **base,
                "available": 1,
                "region_id": spec.region_id,
                **_region_meta(model, spec),
                "signed_basis_names": " ".join(qnames),
                **metrics,
                **plane,
                "computed_status": "directed_response_decomposed_into_S_measure_and_A_current" if metrics["relative_skew_norm"] > 1e-10 else "directed_response_has_no_detected_A_current",
                "condition_note": "S_and_A_are_split_after_directed_DtN; positivity_statements_apply_only_to_S_not_to_Lambda_dir",
            })
    return rows


def directed_signed_role_survival_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        spec = _first_directed_region(model, args)
        for st in states:
            base = {"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st))}
            if spec is None:
                rows.append({**base, "available": 0, "computed_status": "directed_region_missing"})
                continue
            Qsig, qnames, rank = signed_role_basis_F1F2(spec.boundary, spec)
            Qpos, posnames = boundary_role_basis(model, spec)
            res = _response_for_relations(model, st, spec, "open_grounded_directed", "out_degree")
            plane = _plane_metrics(res.Lambda if res.ok else None, Qsig)
            computed_status = "signed_F1F2_plane_survives_and_carries_A_current" if rank >= 2 and plane.get("F1F2_skew_nonzero", 0) else "signed_F1F2_plane_missing_or_A_current_zero"
            rows.append({
                **base,
                "available": int(res.ok and res.Lambda is not None),
                "region_id": spec.region_id,
                **_region_meta(model, spec),
                "old_positive_role_dim": int(Qpos.shape[1]),
                "old_positive_role_names": " ".join(posnames),
                "signed_F1F2_basis_rank": rank,
                "signed_basis_names": " ".join(qnames),
                "F1_survives_in_signed_plane": int("F1_root_front_contrast" in qnames),
                "F2_survives_in_signed_plane": int("F2_birth_order_contrast" in qnames),
                **plane,
                "computed_status": computed_status,
                "condition_note": "2_tests_F1_F2_as_reference_signed_plane_not_as_late_vectors_after_C_B1_B2",
            })
    return rows


def directed_boundary_response_model_comparison_rows(rows: Sequence[dict]) -> List[dict]:
    keys = sorted({(int(r.get("branching", 0)), int(r.get("level", 0)), str(r.get("mode", "")), str(r.get("state", "")), str(r.get("matrix_sign_relation", ""))) for r in rows if r.get("available", "") != ""})
    out: List[dict] = []
    for b, L, mode, st, sign_relation in keys:
        rel = [r for r in rows if int(r.get("branching", -1)) == b and int(r.get("level", -1)) == L and str(r.get("mode", "")) == mode and str(r.get("state", "")) == st and str(r.get("matrix_sign_relation", "")) == sign_relation]
        by = {r.get("boundary_response_model"): r for r in rel}
        open_r = by.get("open_grounded_directed", {})
        closed_r = by.get("closed_internal_directed", {})
        env_r = by.get("explicit_environment_port_directed", {})
        open_row = float(open_r.get("row_sum_residual", math.nan)) if open_r else math.nan
        closed_row = float(closed_r.get("row_sum_residual", math.nan)) if closed_r else math.nan
        env_row = float(env_r.get("row_sum_residual", math.nan)) if env_r else math.nan
        computed_status = "directed_environment_port_accounting_available"
        if not int(env_r.get("available", 0) or 0):
            computed_status = "directed_environment_port_accounting_unavailable"
        elif math.isfinite(open_row) and math.isfinite(closed_row) and open_row > 1e-8 and closed_row <= 1e-8:
            computed_status = "open_grounded_load_separated_from_closed_internal_conservation"
        out.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "matrix_sign_relation": sign_relation,
            "open_grounded_available": int(open_r.get("available", 0) or 0),
            "closed_internal_available": int(closed_r.get("available", 0) or 0),
            "environment_port_available": int(env_r.get("available", 0) or 0),
            "open_grounded_row_sum_residual": open_row,
            "closed_internal_row_sum_residual": closed_row,
            "environment_port_row_sum_residual": env_row,
            "open_grounded_relative_skew": open_r.get("relative_skew_norm", math.nan),
            "closed_internal_relative_skew": closed_r.get("relative_skew_norm", math.nan),
            "environment_port_relative_skew": env_r.get("relative_skew_norm", math.nan),
            "computed_status": computed_status,
            "condition_note": "2_does_not_silently_identify_grounded_open_response_with_closed_local_algebra",
        })
    return out


def directed_skew_survival_rows(sa_rows: Sequence[dict]) -> List[dict]:
    out: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), int(r.get("level", 0)), str(r.get("mode", ""))) for r in sa_rows if int(r.get("available", 0) or 0) == 1})
    for b, L, mode in keys:
        rel = [r for r in sa_rows if int(r.get("branching", -1)) == b and int(r.get("level", -1)) == L and str(r.get("mode", "")) == mode]
        live = next((r for r in rel if r.get("state") == "live"), {})
        record = next((r for r in rel if r.get("state") == "record"), {})
        sym = next((r for r in rel if r.get("state") == "sym"), {})
        live_skew = float(live.get("signed_plane_relative_skew", math.nan)) if live else math.nan
        record_skew = float(record.get("signed_plane_relative_skew", math.nan)) if record else math.nan
        sym_skew = float(sym.get("signed_plane_relative_skew", math.nan)) if sym else math.nan
        live_omega = float(live.get("F1F2_signed_omega", math.nan)) if live else math.nan
        sym_omega = float(sym.get("F1F2_signed_omega", math.nan)) if sym else math.nan
        sep = abs(live_omega - sym_omega) if math.isfinite(live_omega) and math.isfinite(sym_omega) else math.nan
        computed_status = "directed_A_layer_separates_live_from_sym_control" if math.isfinite(live_skew) and live_skew > 1e-10 and (not math.isfinite(sym_skew) or sym_skew <= 1e-10 or sep > 1e-10) else "directed_A_layer_does_not_separate_live_from_sym_control"
        out.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "live_signed_plane_relative_skew": live_skew,
            "record_signed_plane_relative_skew": record_skew,
            "sym_signed_plane_relative_skew": sym_skew,
            "live_F1F2_signed_omega": live_omega,
            "record_F1F2_signed_omega": record.get("F1F2_signed_omega", math.nan) if record else math.nan,
            "sym_F1F2_signed_omega": sym_omega,
            "live_minus_sym_omega_abs": sep,
            "computed_status": computed_status,
            "condition_note": "directed_skew_survival_is_tested_on_directed_DtN_A_layer_not_on_symmetrized_positive_S_stack",
        })
    return out


def directed_operator_transport_rows(sa_rows: Sequence[dict], levels: Sequence[int]) -> List[dict]:
    out: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", "")), str(r.get("state", ""))) for r in sa_rows if int(r.get("available", 0) or 0) == 1})
    for b, mode, st in keys:
        rel = [r for r in sa_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and str(r.get("state", "")) == st and int(r.get("available", 0) or 0) == 1]
        byL = {int(r.get("level", -1)): r for r in rel}
        for source, target in [(M, L) for M in levels for L in levels if M > L]:
            rs = byL.get(int(source)); rt = byL.get(int(target))
            if not rs or not rt:
                continue
            omega_s = float(rs.get("F1F2_signed_omega", math.nan))
            omega_t = float(rt.get("F1F2_signed_omega", math.nan))
            skew_s = float(rs.get("signed_plane_skew_norm", math.nan))
            skew_t = float(rt.get("signed_plane_skew_norm", math.nan))
            omega_drift = abs(omega_s - omega_t) / max(abs(omega_t), EPS) if math.isfinite(omega_s) and math.isfinite(omega_t) else math.nan
            skew_norm_drift = abs(skew_s - skew_t) / max(abs(skew_t), EPS) if math.isfinite(skew_s) and math.isfinite(skew_t) else math.nan
            out.append({
                "branching": b,
                "mode": mode,
                "state": st,
                "reference_model": int(is_reference_model(mode, st)),
                "source_level": source,
                "target_level": target,
                "transport_finite_object": "signed_F1F2_plane_identity_coordinate_transport_derived_quantity",
                "source_F1F2_signed_omega": omega_s,
                "target_F1F2_signed_omega": omega_t,
                "relative_omega_drift": omega_drift,
                "source_signed_plane_skew_norm": skew_s,
                "target_signed_plane_skew_norm": skew_t,
                "relative_skew_norm_drift": skew_norm_drift,
                "computed_status": "signed_A_plane_transport_derived_quantity_available_not_star_hom_statement",
                "condition_note": "directed_transport_is_scalar_plane_derived_quantity_only; natural_operator_morphism_remains_open",
            })
        if {4, 5, 6}.issubset(set(byL.keys())):
            r4, r5, r6 = byL[4], byL[5], byL[6]
            o4 = float(r4.get("F1F2_signed_omega", math.nan))
            o5 = float(r5.get("F1F2_signed_omega", math.nan))
            o6 = float(r6.get("F1F2_signed_omega", math.nan))
            # There is not yet a nontrivial map on the plane.  The identity-plane
            # derived_quantity has exact formal composition, while object drift is the
            # actual finite-level content.
            object_drift_4_6 = abs(o6 - o4) / max(abs(o4), EPS) if all(math.isfinite(x) for x in [o4, o6]) else math.nan
            via_object_drift = (abs(o6 - o5) + abs(o5 - o4)) / max(abs(o4), EPS) if all(math.isfinite(x) for x in [o4, o5, o6]) else math.nan
            out.append({
                "branching": b,
                "mode": mode,
                "state": st,
                "reference_model": int(is_reference_model(mode, st)),
                "source_level": 6,
                "mid_level": 5,
                "target_level": 4,
                "transport_finite_object": "signed_F1F2_plane_identity_coordinate_transport_composition_control",
                "direct_vs_composed_residual": 0.0,
                "object_drift_4_vs_6": object_drift_4_6,
                "pathwise_object_variation_6_5_4": via_object_drift,
                "computed_status": "formal_composition_trivial_but_signed_A_object_drift_quantified",
                "condition_note": "do_not_read_zero_composition_as_projective_operator_limit; this_is_only_plane_coordinate_control",
            })
    return out


def directed_j_finite_object_comparison_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            spec, res, Qsig, qnames = _reference_open_out_snapshot(model, st, args)
            base = {"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "matrix_sign_relation": "out_degree", "boundary_response_model": "open_grounded_directed"}
            if spec is None or res is None or not res.ok or res.Lambda is None:
                rows.append({**base, "available": 0, "computed_status": "J_finite_object_comparison_unavailable_missing_directed_response"})
                continue
            Lp = Qsig.T @ res.Lambda @ Qsig
            Sp, Ap = split_symmetric_skew(Lp)
            J, info = j_finite_object_from_SA(Sp, Ap, tol=max(args.gns_tol, 1.0e-12))
            computed_status = "finite_J_finite_object_comparison_residual_le_tolerance_on_signed_plane" if int(info.get("available", 0) or 0) == 1 and float(info.get("J_square_minus_negative_projector_error", 1.0)) < 1e-8 else "finite_J_finite_object_comparison_not_residual_le_tolerance"
            rows.append({
                **base,
                "region_id": spec.region_id,
                **_region_meta(model, spec),
                "signed_basis_names": " ".join(qnames),
                "signed_plane_dim": int(Qsig.shape[1]),
                "available": int(info.get("available", 0) or 0),
                **info,
                "computed_status": computed_status,
                "condition_note": "finite_polar_comparison_only; no_complex_Hilbert_space_no_KMS_no_Tomita_statement",
            })
    return rows


def directed_operator_stack_summary_rows(sa_rows: Sequence[dict], skew_rows: Sequence[dict], role_rows: Sequence[dict], j_rows: Sequence[dict]) -> List[dict]:
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", ""))) for r in sa_rows if r.get("branching", "") != ""})
    rows: List[dict] = []
    for b, mode in keys:
        reference = int(mode == REFERENCE_MODE)
        live_sa = [r for r in sa_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "live" and int(r.get("available", 0) or 0) == 1]
        sym_sa = [r for r in sa_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "sym" and int(r.get("available", 0) or 0) == 1]
        role_live = [r for r in role_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "live"]
        j_live = [r for r in j_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "live"]

        # coverage consistency: distinguish a real rank/skew failure from a coverage
        # failure caused by the boundary/interior size condition_notes.  The previous
        # summary collapsed missing directed regions into
        # ``signed_F1F2_plane_not_rank_two``.  That was too coarse for L>=7
        # sweeps, where the reference sibling cone can exceed max-boundary while
        # the finite L=4..6 transport rows still look residual_le_tolerance.
        role_live_available = [r for r in role_live if int(r.get("available", 0) or 0) == 1]
        role_live_unavailable = [r for r in role_live if int(r.get("available", 0) or 0) != 1]
        directed_region_coverage_ok = int(bool(role_live) and not role_live_unavailable)
        unavailable_levels = sorted({int(r.get("level", -1)) for r in role_live_unavailable if str(r.get("level", "")) != ""})

        live_skew_ok = int(any(float(r.get("signed_plane_relative_skew", 0.0) or 0.0) > 1e-10 for r in live_sa))
        sym_zero_ok = int(bool(sym_sa) and all(float(r.get("signed_plane_relative_skew", 0.0) or 0.0) <= 1e-10 for r in sym_sa))
        role_ok = int(bool(role_live_available) and all(int(r.get("signed_F1F2_basis_rank", 0) or 0) >= 2 for r in role_live_available))
        j_ok = int(any(int(r.get("available", 0) or 0) == 1 and float(r.get("J_square_minus_negative_projector_error", 1.0)) < 1e-8 for r in j_live))
        unmet_conditions: List[str] = []
        if not directed_region_coverage_ok:
            unmet_conditions.append("directed_region_coverage_incomplete")
        if not live_skew_ok:
            unmet_conditions.append("live_directed_A_skew_missing")
        if not sym_zero_ok:
            unmet_conditions.append("sym_control_not_skew_zero")
        if not role_ok:
            unmet_conditions.append("signed_F1F2_plane_not_rank_two_on_available_regions")
        if not j_ok:
            unmet_conditions.append("finite_J_comparison_not_residual_le_tolerance")
        if directed_region_coverage_ok and live_skew_ok and role_ok and sym_zero_ok:
            computed_status = "directed_DtN_stack_carries_nonzero_signed_skew_current"
        else:
            computed_status = "directed_DtN_stack_not_yet_carrying_required_skew_current"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": reference,
            "directed_region_coverage_ok": directed_region_coverage_ok,
            "directed_region_unavailable_level_count": len(unavailable_levels),
            "directed_region_unavailable_levels": " ".join(map(str, unavailable_levels)) if unavailable_levels else "none",
            "live_directed_A_skew_available": live_skew_ok,
            "sym_control_A_skew_zero": sym_zero_ok,
            "signed_F1F2_plane_rank_two": role_ok,
            "finite_J_comparison_residual_le_tolerance_some_level": j_ok,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "2_is_directed_DtN_A_layer_comparison_not_vN_not_GNS_completion_not_KMS; coverage_incomplete_is_not_a_skew_rank_failure",
        })
    return rows


def write_directed_operator_stack_report(outdir: Path, construction_rows: Sequence[dict], sa_rows: Sequence[dict], role_rows: Sequence[dict], relations_rows: Sequence[dict], skew_rows: Sequence[dict], transport_rows: Sequence[dict], j_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference_summary = next((r for r in summary_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_sa = [r for r in sa_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("level", 0)) == 6 and r.get("state") == "live"]
    sa = reference_sa[0] if reference_sa else next((r for r in sa_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_role = [r for r in role_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("level", 0)) == 6 and r.get("state") == "live"]
    role = reference_role[0] if reference_role else next((r for r in role_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_sem = [r for r in relations_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("level", 0)) == 6 and r.get("state") == "live" and r.get("matrix_sign_relation") == "out_degree"]
    sem = reference_sem[0] if reference_sem else next((r for r in relations_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_skew = [r for r in skew_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("level", 0)) == 6]
    skew = reference_skew[0] if reference_skew else next((r for r in skew_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_j = [r for r in j_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("level", 0)) == 6 and r.get("state") == "live"]
    j = reference_j[0] if reference_j else next((r for r in j_rows if int(r.get("reference_model", 0)) == 1), {})
    text = f"""# Directed/skew DtN operator stack

## Purpose

The directed/skew layer refines the operator-stack measurement target.  It does not replace the positive S-layer.  It adds a directed DtN response `Lambda_dir`, decomposes it as `S + A`, and tests the signed F1/F2 current layer on `A` instead of searching for chirality inside the symmetrized positive response.

## Reference summary

```text
computed_status  = {reference_summary.get('computed_status', 'missing')}
unmet_conditions = {reference_summary.get('unmet_conditions', 'missing')}
```

## Directed S/A layer, selected reference live level

```text
level                         = {sa.get('level', 'n/a')}
boundary_response_model            = {sa.get('boundary_response_model', 'n/a')}
matrix_sign_relation             = {sa.get('matrix_sign_relation', 'n/a')}
directed_response_norm        = {sa.get('directed_response_norm', 'n/a')}
symmetric_part_norm           = {sa.get('symmetric_part_norm', 'n/a')}
skew_part_norm                = {sa.get('skew_part_norm', 'n/a')}
relative_skew_norm            = {sa.get('relative_skew_norm', 'n/a')}
signed_plane_relative_skew    = {sa.get('signed_plane_relative_skew', 'n/a')}
F1F2_signed_omega             = {sa.get('F1F2_signed_omega', 'n/a')}
S_min_eig                     = {sa.get('S_min_eig', 'n/a')}
S_negative_mass               = {sa.get('S_negative_mass', 'n/a')}
```

## Signed role survival, selected reference live level

```text
level                         = {role.get('level', 'n/a')}
old_positive_role_dim         = {role.get('old_positive_role_dim', 'n/a')}
old_positive_role_names       = {role.get('old_positive_role_names', 'n/a')}
signed_F1F2_basis_rank        = {role.get('signed_F1F2_basis_rank', 'n/a')}
signed_basis_names            = {role.get('signed_basis_names', 'n/a')}
computed_status                       = {role.get('computed_status', 'n/a')}
```

## Response relations, selected reference live level

```text
level                            = {sem.get('level', 'n/a')}
open_grounded_row_sum_residual    = {sem.get('open_grounded_row_sum_residual', 'n/a')}
closed_internal_row_sum_residual  = {sem.get('closed_internal_row_sum_residual', 'n/a')}
environment_port_row_sum_residual = {sem.get('environment_port_row_sum_residual', 'n/a')}
computed_status                           = {sem.get('computed_status', 'n/a')}
```

## live/record/sym skew survival, selected level

```text
level                          = {skew.get('level', 'n/a')}
live_signed_plane_relative_skew   = {skew.get('live_signed_plane_relative_skew', 'n/a')}
record_signed_plane_relative_skew = {skew.get('record_signed_plane_relative_skew', 'n/a')}
sym_signed_plane_relative_skew    = {skew.get('sym_signed_plane_relative_skew', 'n/a')}
live_F1F2_signed_omega            = {skew.get('live_F1F2_signed_omega', 'n/a')}
sym_F1F2_signed_omega             = {skew.get('sym_F1F2_signed_omega', 'n/a')}
computed_status                           = {skew.get('computed_status', 'n/a')}
```

## finite J comparison, selected reference live level

```text
level                                  = {j.get('level', 'n/a')}
available                              = {j.get('available', 'n/a')}
reason                                 = {j.get('reason', 'n/a')}
S_support_rank                         = {j.get('S_support_rank', 'n/a')}
skew_rank                              = {j.get('skew_rank', 'n/a')}
J_square_minus_negative_projector_error = {j.get('J_square_minus_negative_projector_error', 'n/a')}
computed_status                                = {j.get('computed_status', 'n/a')}
```

## Non-statements

2 does not statement a von Neumann algebra, Type-III limit, KMS condition, AQFT split property, completed GNS Hilbert space, or strict projective `*`-homomorphism.  It only establishes whether the directed finite DtN layer actually carries the signed current that the symmetrized S-stack could not see.
"""
    (outdir / "2_DIRECTED_OPERATOR_STACK_REPORT.md").write_text(text, encoding="utf-8")
