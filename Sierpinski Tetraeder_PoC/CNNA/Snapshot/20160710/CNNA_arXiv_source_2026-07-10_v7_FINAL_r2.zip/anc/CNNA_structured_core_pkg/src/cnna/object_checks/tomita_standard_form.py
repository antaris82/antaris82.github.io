from __future__ import annotations

from typing import List

from .observable_state_rows import state_relations_fields
from cnna.core.algebra_support import (
    finite_tomita_star_metrics,
    local_operator_algebras,
    operator_scale_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
    signed_orientation_metrics,
)


def _computed_status(metrics: dict, orientation: dict, tol: float) -> str:
    support_dim = int(metrics.get("tomita_support_dim", 0))
    polar_ok = (
        support_dim > 0
        and float(metrics.get("star_closure_residual", 1.0)) <= tol
        and float(metrics.get("star_involution_error", 1.0)) <= 1.0e-8
        and float(metrics.get("star_support_leakage", 1.0)) <= 1.0e-7
        and float(metrics.get("tomita_polar_residual", 1.0)) <= 1.0e-7
        and float(metrics.get("tomita_conjugation_orthogonality_error", 1.0)) <= 1.0e-7
    )
    orientation_ok = int(orientation.get("signed_orientation_available", 0)) == 1
    skew_flip_ok = float(orientation.get("skew_transpose_flip_error", 1.0)) <= 1.0e-8
    relation_scope = str(metrics.get("cnna_orientation_relation_scope", ""))
    if relation_scope == "orientation_vacuous_zero_current_control":
        return "orientation_vacuous_zero_current_control"
    relation_checked = int(metrics.get("tomita_cnna_orientation_relation_checked", 0)) == 1
    relation_residual = float(metrics.get("tomita_conjuconditions_cnna_orientation_to_negative_residual", 1.0))
    relation_ok = relation_checked and relation_residual <= 1.0e-7
    if polar_ok and orientation_ok and skew_flip_ok and relation_ok:
        return "finite_tomita_conjuconditions_cnna_orientation_to_negative_finite_object"
    if polar_ok and orientation_ok and skew_flip_ok and relation_checked:
        return "finite_tomita_polar_ok_cnna_orientation_relation_obstructed"
    if polar_ok and orientation_ok and skew_flip_ok:
        return "finite_tomita_polar_orientation_available_relation_unchecked"
    if polar_ok and not orientation_ok:
        return "finite_tomita_polar_ok_orientation_missing"
    if support_dim <= 0:
        return "tomita_support_empty"
    if orientation_ok and skew_flip_ok and float(metrics.get("star_support_leakage", 0.0)) > 1.0e-7:
        return "singular_support_tomita_polar_unresolved_control"
    if orientation_ok and skew_flip_ok:
        return "orientation_plane_ok_tomita_polar_unresolved"
    return "tomita_polar_orientation_comparison_failed"


def tomita_standard_form_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for sign_relation in config.tomita_matrix_sign_relations:
                orientation = signed_orientation_metrics(model, spec, config.rank_tol, matrix_sign_relation=sign_relation)
                for state in config.states:
                    resp = regional_response(model, spec, state, matrix_sign_relation=sign_relation)
                    if resp is None:
                        rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "matrix_sign_relation": sign_relation, "tomita_compatibility_computed_status": "response_unavailable"})
                        continue
                    algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    global_alg = algebras["full_regional_response"]
                    scale_meta = operator_scale_metadata(resp, tol=config.rank_tol)
                    metrics = finite_tomita_star_metrics(
                        global_alg,
                        resp.density,
                        config.rank_tol,
                        orientation_operator=resp.skew_role,
                        orientation_carrier_norm=scale_meta.get("symmetric_carrier_norm"),
                    )
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **state_relations_fields(state),
                        "tomita_physics_scope": (
                            "reference_live_tomita_comparison" if state == "live" else
                            "record_history_tomita_comparison_control" if state == "record" else
                            "sym_null_tomita_control"
                        ),
                        "matrix_sign_relation": sign_relation,
                        **resp.density_metadata,
                        **scale_meta,
                        "global_operator_system": "full_regional_response",
                        "global_algebra_dim": len(global_alg.basis),
                        **metrics,
                        **orientation,
                        "tomita_compatibility_computed_status": _computed_status(metrics, orientation, config.algebra_tol),
                    })
    return rows


def tomita_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("tomita_compatibility_computed_status", "unknown")) for r in rows})
    return "# Finite Tomita standard-form compatibility report\n\nComputes the finite star-induced Tomita map S0(aΩ)=aᵀΩ on the GNS support and measurements its polar decomposition.  The former star-isometry quantity is retained only as a control column.  The antiunitary/modular Tomita conjugation is not identified with the linear CNNA J-orientation; an explicit finite residual for J_T L_A J_T ≈ -L_A is reported.  If the state-specific directed current is below the carrier-relative norm condition, the row is labelled as an orientation-vacuous zero-current control rather than as an unchecked orientation relation.  If the orientation plane exists but star support leakage prevents a finite polar-standard-form computed_status, the row is labelled as a singular-support control rather than as a hidden Tomita rank_bound.  The optional Tomita sign_relation sweep records out-degree/in-degree response sign_relations instead of hiding sign_relation dependence, where L_A is the left-action of the directed CNNA skew-current proxy on the finite GNS support.  The orientation-operator span residual is condition-sensitive near the rank threshold and is reported as a derived_quantity, not used alone as a strict property condition.  This is still a compatibility derived_quantity, not an identification of Tomita conjugation with the linear CNNA J.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
