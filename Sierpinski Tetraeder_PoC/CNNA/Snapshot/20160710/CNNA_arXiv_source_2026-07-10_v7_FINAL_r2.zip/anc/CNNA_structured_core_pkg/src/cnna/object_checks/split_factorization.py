from __future__ import annotations

import math
from typing import List

from cnna.core.algebra_support import (
    commutator_metrics,
    joined_algebra,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


SPLIT_FINITE_OBJECTS = [
    ("left_frontier_response", "right_frontier_response", "frontier_sibling_factorization"),
    ("left_birth_cone_response", "right_birth_cone_response", "birth_cone_sibling_factorization"),
]


def _computed_status(comm_rel: float, tensor_ratio: float, floor_ratio: float, tol: float) -> str:
    if comm_rel <= tol and abs(tensor_ratio - 1.0) <= 1.0e-8:
        return "finite_tensor_factorization_finite_object"
    if comm_rel <= tol and abs(floor_ratio - 1.0) <= 1.0e-8:
        return "commuting_join_only_shared_identity_span_control"
    if comm_rel <= 1.0e-7:
        return "commuting_join_without_full_tensor_dimension"
    return "split_factorization_preform_failed"


def split_factorization_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "split_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                for left_name, right_name, sign_relation in SPLIT_FINITE_OBJECTS:
                    left = algebras[left_name]
                    right = algebras[right_name]
                    join = joined_algebra("split_join_" + sign_relation, [left, right], tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    met = commutator_metrics(left, right)
                    product_dim = int(len(left.basis) * len(right.basis))
                    shared_identity_span_floor = int(max(1, len(left.basis) + len(right.basis) - 1))
                    ratio = float(len(join.basis) / max(1, product_dim))
                    floor_ratio = float(len(join.basis) / max(1, shared_identity_span_floor))
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "separation_sign_relation": sign_relation,
                        "left_dim": len(left.basis),
                        "right_dim": len(right.basis),
                        "generated_join_dim": len(join.basis),
                        "tensor_product_dimension_proxy": product_dim,
                        "shared_identity_span_floor_proxy": shared_identity_span_floor,
                        "join_to_tensor_dimension_ratio": ratio,
                        "join_to_shared_identity_span_floor_ratio": floor_ratio,
                        "dimension_residual_abs": int(abs(product_dim - len(join.basis))),
                        "shared_identity_floor_residual_abs": int(abs(shared_identity_span_floor - len(join.basis))),
                        "tensor_proxy_note": "dim_L_times_dim_R remains the tensor target; shared_identity_span_floor separates mere unital join saturation from tensor factorization",
                        "max_relative_commutator": met["max_relative_commutator"],
                        "split_computed_status": _computed_status(float(met["max_relative_commutator"]), ratio, floor_ratio, config.algebra_tol),
                    })
    return rows


def split_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("split_computed_status", "unknown")) for r in rows})
    return "# Finite split-factorization report\n\nMeasurements a finite tensor-factorization proxy for separated sibling operator systems.  The rank product is only a finite derived_quantity; a shared-identity span floor is also reported so commuting unital-span controls are not mistaken for tensor factorization and does not establish the AQFT split property.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
