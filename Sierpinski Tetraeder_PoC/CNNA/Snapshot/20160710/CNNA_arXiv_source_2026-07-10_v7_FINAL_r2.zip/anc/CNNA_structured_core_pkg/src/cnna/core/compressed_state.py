from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core.math_utils import *
from cnna.core.emptyset_growth import *
from cnna.core.projective_maps import *
from cnna.core.schur_dtn import *
from cnna.core.response_algebra import *

def compressed_state_object(model: EmptySetGrowthModel, state: str, args) -> Optional[dict]:
    """Build the compressed carrier/GNS compressed carrier/GNS-state object.

    Main formulas:
      Q = orthonormal boundary role/mode map,
      z_v = row_v(Q),
      E_v = z_v z_v^T,  sum_v E_v = I on compressed carrier,
      D_N = positive trace-normalized projection of response density to N_A(C),
      p_v = tr(D_N E_v).
    """
    for spec in build_sibling_regions(model, max_regions=max(1, args.max_regions)):
        if len(spec.boundary) > args.max_boundary or len(spec.interior) > args.max_interior:
            continue
        res = schur_response_from_model(model, state, spec.boundary, spec.interior)
        if not res.ok or res.Lambda is None:
            continue
        Q, qnames = boundary_role_basis(model, spec)  # boundary x compressed_dim
        Lc = compress_response(res.Lambda, Q)
        D_raw = positive_density_from_response(Lc)
        g = gens_from_response(Lc)
        algs = build_algebras(g, args.algebra_tol, args.algebra_max_iter)
        N_A = algs[1]
        D_N, D_N_info = project_density_to_algebra_span(D_raw, N_A)
        effects: List[np.ndarray] = []
        traces: List[float] = []
        state_weights: List[float] = []
        response_weights = response_energy_distribution(res.Lambda)
        atom_rows: List[dict] = []
        sumE = np.zeros((Q.shape[1], Q.shape[1]), dtype=float)
        for k, nid in enumerate(spec.boundary):
            z = np.array(Q[k, :], dtype=float)
            E = np.outer(z, z)
            effects.append(E)
            sumE += E
            trE = float(np.trace(E))
            pv = float(np.real(np.trace(D_N @ E)))
            traces.append(max(0.0, trE))
            state_weights.append(max(0.0, pv))
            role = role_for_boundary_node(spec, int(nid))
            atom_rows.append({
                "node_id": int(nid),
                "node_address": ".".join(map(str, model.nodes[int(nid)].address)) if model.nodes[int(nid)].address else "root",
                "node_level": model.nodes[int(nid)].level,
                "role": role,
                "effect_trace": trE,
                "p_state_atom_raw": pv,
                "q_response_atom_raw": float(response_weights[k]) if k < len(response_weights) else 0.0,
            })
        completeness_error = fro(sumE - np.eye(Q.shape[1])) / (math.sqrt(max(1, Q.shape[1])) + EPS)
        return {
            "model": model,
            "state": state,
            "spec": spec,
            "Q": Q,
            "qnames": qnames,
            "Lc": Lc,
            "D_raw": D_raw,
            "D_N": D_N,
            "D_N_info": D_N_info,
            "effects": effects,
            "traces": normalize_distribution(traces),
            "state_weights": normalize_distribution(state_weights),
            "response_weights": normalize_distribution(response_weights),
            "atom_rows": atom_rows,
            "sumE_completeness_error": completeness_error,
            "response": res,
            "algebras": algs,
        }
    return None


def compressed_projective_distribution(obj: dict, target_level: int) -> Dict[str, dict]:
    model: EmptySetGrowthModel = obj["model"]
    spec: RegionSpec = obj["spec"]
    traces = obj["traces"]
    states = obj["state_weights"]
    responses = obj["response_weights"]
    out: Dict[str, dict] = {}
    for k, nid in enumerate(spec.boundary):
        role = role_for_boundary_node(spec, int(nid))
        key = atom_key(model, role, int(nid), target_level)
        if key not in out:
            out[key] = {"trace": 0.0, "state": 0.0, "response": 0.0, "n_atoms": 0}
        out[key]["trace"] += float(traces[k]) if k < len(traces) else 0.0
        out[key]["state"] += float(states[k]) if k < len(states) else 0.0
        out[key]["response"] += float(responses[k]) if k < len(responses) else 0.0
        out[key]["n_atoms"] += 1
    # Normalize fields separately after aggregation.
    for field in ["trace", "state", "response"]:
        vals = {k: max(0.0, v[field]) for k, v in out.items()}
        norm = normalize_dict(vals)
        for k, val in norm.items():
            out[k][field] = val
    return out


def values_for_keys(d: Dict[str, dict], keys: Sequence[str], field: str) -> np.ndarray:
    return normalize_distribution([d.get(k, {}).get(field, 0.0) for k in keys])


def key_is_center(k: str) -> bool:
    return k.split("|", 1)[0] in {"A_lca", "B1_root", "B2_root", "C_lca"}


def sector_profile_tv(d0: Dict[str, dict], d1: Dict[str, dict], field: str, pred) -> Tuple[float, float, float]:
    keys = sorted(set(d0.keys()) | set(d1.keys()))
    raw0 = np.array([max(0.0, d0.get(k, {}).get(field, 0.0)) if pred(k) else 0.0 for k in keys], dtype=float)
    raw1 = np.array([max(0.0, d1.get(k, {}).get(field, 0.0)) if pred(k) else 0.0 for k in keys], dtype=float)
    m0 = float(np.sum(raw0)); m1 = float(np.sum(raw1))
    if m0 <= EPS or m1 <= EPS:
        return abs(m0 - m1), math.nan, 0.0
    return abs(m0 - m1), tv_arr(raw0 / m0, raw1 / m1), 0.5 * float(np.sum(np.abs(raw0 - raw1)))
