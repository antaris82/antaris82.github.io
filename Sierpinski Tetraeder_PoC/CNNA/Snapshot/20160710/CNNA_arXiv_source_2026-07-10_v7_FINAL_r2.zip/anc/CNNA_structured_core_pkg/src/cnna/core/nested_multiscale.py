from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import EPS, fro
from cnna.core.schur_dtn import RegionSpec, SchurResponse, schur_response


@dataclass
class NestedRoleBasis:
    Q: np.ndarray
    labels: List[str]
    frontier_level: int
    relative_depth: int
    branching: int


@dataclass
class CommonAmbientSchurResult:
    direct: SchurResponse
    staged_first: SchurResponse
    staged_second: SchurResponse
    coarse_boundary: List[int]
    stage_boundary: List[int]
    selected_nodes: List[int]
    direct_vs_staged_residual: float


def helmert_slot_contrasts(branching: int) -> List[np.ndarray]:
    if branching < 2:
        raise ValueError("branching must be at least two")
    out: List[np.ndarray] = []
    for k in range(1, branching):
        v = np.zeros(branching, dtype=float)
        denominator = math.sqrt(float(k * (k + 1)))
        v[:k] = 1.0 / denominator
        v[k] = -float(k) / denominator
        out.append(v)
    return out


def _normalized_indicator(boundary: Sequence[int], ids: Sequence[int]) -> np.ndarray:
    position = {int(nid): i for i, nid in enumerate(boundary)}
    v = np.zeros(len(boundary), dtype=float)
    for nid in ids:
        if int(nid) in position:
            v[position[int(nid)]] = 1.0
    norm = float(np.linalg.norm(v))
    if norm <= EPS:
        raise ValueError("empty role support")
    return v / norm


def _relative_depths(model: EmptySetGrowthModel, root: int, frontier: Sequence[int]) -> List[int]:
    root_address = tuple(model.nodes[int(root)].address)
    return [len(tuple(model.nodes[int(nid)].address)) - len(root_address) for nid in frontier]


def nested_address_contrast_basis(model: EmptySetGrowthModel, region: RegionSpec) -> NestedRoleBasis:
    boundary = list(region.boundary)
    left_front = list(region.roles.get("B1_front", []))
    right_front = list(region.roles.get("B2_front", []))
    if not left_front or not right_front:
        raise ValueError("both sibling frontiers must be nonempty")
    left_depths = _relative_depths(model, region.left_root, left_front)
    right_depths = _relative_depths(model, region.right_root, right_front)
    if len(set(left_depths)) != 1 or len(set(right_depths)) != 1 or left_depths[0] != right_depths[0]:
        raise ValueError("frontier addresses must have one common relative depth")
    relative_depth = int(left_depths[0])
    if relative_depth < 0:
        raise ValueError("negative relative frontier depth")

    columns: List[np.ndarray] = [
        _normalized_indicator(boundary, region.roles.get("C_lca", [])),
        _normalized_indicator(boundary, left_front),
        _normalized_indicator(boundary, right_front),
    ]
    labels = ["C_lca", "B1_constant", "B2_constant"]
    position = {int(nid): i for i, nid in enumerate(boundary)}
    roots = {
        "B1": tuple(model.nodes[int(region.left_root)].address),
        "B2": tuple(model.nodes[int(region.right_root)].address),
    }
    fronts = {"B1": left_front, "B2": right_front}
    contrasts = helmert_slot_contrasts(model.b)

    for depth in range(relative_depth):
        for contrast_index, contrast in enumerate(contrasts, start=1):
            for side in ("B1", "B2"):
                v = np.zeros(len(boundary), dtype=float)
                root_address = roots[side]
                for nid in fronts[side]:
                    relative_address = tuple(model.nodes[int(nid)].address)[len(root_address):]
                    if depth >= len(relative_address):
                        raise ValueError("frontier address shorter than requested contrast depth")
                    v[position[int(nid)]] = float(contrast[int(relative_address[depth])])
                norm = float(np.linalg.norm(v))
                if norm <= EPS:
                    raise ValueError("degenerate address contrast")
                columns.append(v / norm)
                labels.append(f"{side}_digit{depth}_helmert{contrast_index}")

    Q = np.column_stack(columns)
    gram_error = fro(Q.T @ Q - np.eye(Q.shape[1]))
    if gram_error > 1.0e-9:
        raise ValueError(f"nested role basis is not orthonormal: {gram_error}")
    frontier_levels = [int(model.nodes[int(nid)].level) for nid in left_front + right_front]
    return NestedRoleBasis(
        Q=Q,
        labels=labels,
        frontier_level=max(frontier_levels),
        relative_depth=relative_depth,
        branching=int(model.b),
    )


def label_inclusion_matrix(source_labels: Sequence[str], target_labels: Sequence[str]) -> np.ndarray:
    target_positions = {str(label): i for i, label in enumerate(target_labels)}
    T = np.zeros((len(target_labels), len(source_labels)), dtype=float)
    for j, label in enumerate(source_labels):
        i = target_positions.get(str(label))
        if i is None:
            raise ValueError(f"source label missing in target basis: {label}")
        T[i, j] = 1.0
    return T


def role_intertwining_metrics(
    V: np.ndarray,
    source: NestedRoleBasis,
    target: NestedRoleBasis,
) -> Dict[str, float]:
    T_measured = target.Q.T @ V @ source.Q
    T_label = label_inclusion_matrix(source.labels, target.labels)
    lifted = V @ source.Q
    predicted = target.Q @ T_measured
    denominator = max(fro(lifted), EPS)
    return {
        "source_role_dim": float(source.Q.shape[1]),
        "target_role_dim": float(target.Q.shape[1]),
        "basis_intertwining_relative_error": fro(lifted - predicted) / denominator,
        "measured_vs_label_inclusion_error": fro(T_measured - T_label),
        "role_isometry_error": fro(T_measured.T @ T_measured - np.eye(T_measured.shape[1])),
        "new_role_count": float(target.Q.shape[1] - source.Q.shape[1]),
    }


def corner_embed(T: np.ndarray, X: np.ndarray) -> np.ndarray:
    return T @ X @ T.T


def corner_restrict(T: np.ndarray, Y: np.ndarray) -> np.ndarray:
    return T.T @ Y @ T


def symmetric_open_grounded_matrix(
    model: EmptySetGrowthModel,
    state: str,
    selected_nodes: Sequence[int],
) -> np.ndarray:
    selected = list(dict.fromkeys(int(nid) for nid in selected_nodes))
    position = {nid: i for i, nid in enumerate(selected)}
    K = np.zeros((len(selected), len(selected)), dtype=float)
    edges = model.record_edges if state == "record" else model.live_edges
    pairs = {(min(int(i), int(j)), max(int(i), int(j))) for i, j in edges if int(i) != int(j)}
    for i, j in pairs:
        conductance = 0.5 * (float(edges.get((i, j), 0.0)) + float(edges.get((j, i), 0.0)))
        if conductance <= 0.0:
            continue
        if i in position:
            K[position[i], position[i]] += conductance
        if j in position:
            K[position[j], position[j]] += conductance
        if i in position and j in position:
            K[position[i], position[j]] -= conductance
            K[position[j], position[i]] -= conductance
    return K


def _nodes_at_level_under(model: EmptySetGrowthModel, root: int, level: int) -> List[int]:
    base = tuple(model.nodes[int(root)].address)
    return [
        int(node.nid)
        for node in model.nodes
        if int(node.level) == int(level)
        and len(tuple(node.address)) >= len(base)
        and tuple(node.address[:len(base)]) == base
    ]


def _cone_nodes(model: EmptySetGrowthModel, roots: Sequence[int]) -> List[int]:
    prefixes = [tuple(model.nodes[int(root)].address) for root in roots]
    return [
        int(node.nid)
        for node in model.nodes
        if any(
            len(tuple(node.address)) >= len(prefix)
            and tuple(node.address[:len(prefix)]) == prefix
            for prefix in prefixes
        )
    ]


def common_ambient_interlevel_schur(
    model: EmptySetGrowthModel,
    terminal_region: RegionSpec,
    state: str,
    coarse_frontier_level: int,
    cond_max: float = 1.0e12,
) -> CommonAmbientSchurResult:
    coarse_left = _nodes_at_level_under(model, terminal_region.left_root, coarse_frontier_level)
    coarse_right = _nodes_at_level_under(model, terminal_region.right_root, coarse_frontier_level)
    if not coarse_left or not coarse_right:
        raise ValueError("coarse frontier is empty")
    coarse_boundary = [int(terminal_region.lca)] + coarse_left + coarse_right
    fine_boundary = list(terminal_region.boundary)
    stage_boundary = list(dict.fromkeys(coarse_boundary + fine_boundary))
    selected_nodes = list(dict.fromkeys([int(terminal_region.lca)] + _cone_nodes(model, [terminal_region.left_root, terminal_region.right_root])))
    selected_position = {nid: i for i, nid in enumerate(selected_nodes)}
    K = symmetric_open_grounded_matrix(model, state, selected_nodes)

    coarse_indices = [selected_position[nid] for nid in coarse_boundary]
    direct_interior = [i for i in range(len(selected_nodes)) if i not in set(coarse_indices)]
    direct = schur_response(K, coarse_indices, direct_interior, cond_max=cond_max)

    stage_indices = [selected_position[nid] for nid in stage_boundary]
    stage_interior = [i for i in range(len(selected_nodes)) if i not in set(stage_indices)]
    staged_first = schur_response(K, stage_indices, stage_interior, cond_max=cond_max)
    if not staged_first.ok or staged_first.Lambda is None:
        staged_second = SchurResponse(False, None, math.nan, math.nan, math.nan, "first_stage_failed")
        residual = math.inf
    else:
        stage_position = {nid: i for i, nid in enumerate(stage_boundary)}
        second_boundary = [stage_position[nid] for nid in coarse_boundary]
        second_interior = [i for i in range(len(stage_boundary)) if i not in set(second_boundary)]
        staged_second = schur_response(staged_first.Lambda, second_boundary, second_interior, cond_max=cond_max)
        if direct.ok and direct.Lambda is not None and staged_second.ok and staged_second.Lambda is not None:
            residual = fro(direct.Lambda - staged_second.Lambda) / max(fro(direct.Lambda), EPS)
        else:
            residual = math.inf

    return CommonAmbientSchurResult(
        direct=direct,
        staged_first=staged_first,
        staged_second=staged_second,
        coarse_boundary=coarse_boundary,
        stage_boundary=stage_boundary,
        selected_nodes=selected_nodes,
        direct_vs_staged_residual=residual,
    )


def resolved_support_graph_metrics(A: np.ndarray, tolerance: float) -> Dict[str, float]:
    n = int(A.shape[0])
    if n == 0:
        return {
            "support_graph_connected": 0.0,
            "support_graph_component_count": 0.0,
            "support_graph_edge_count": 0.0,
            "minimum_resolved_coupling": math.nan,
        }
    support = (np.abs(A) > tolerance) | (np.abs(A.T) > tolerance)
    np.fill_diagonal(support, False)
    seen: set[int] = set()
    components = 0
    for start in range(n):
        if start in seen:
            continue
        components += 1
        stack = [start]
        seen.add(start)
        while stack:
            i = stack.pop()
            for j in np.flatnonzero(support[i]):
                jj = int(j)
                if jj not in seen:
                    seen.add(jj)
                    stack.append(jj)
    off_diagonal = np.abs(A.copy())
    np.fill_diagonal(off_diagonal, 0.0)
    resolved = off_diagonal[off_diagonal > tolerance]
    return {
        "support_graph_connected": float(int(components == 1)),
        "support_graph_component_count": float(components),
        "support_graph_edge_count": float(np.sum(np.triu(support, 1))),
        "minimum_resolved_coupling": float(np.min(resolved)) if resolved.size else math.nan,
    }
