from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(pairs) < 2:
        return math.nan
    mx = sum(x for x, _ in pairs) / len(pairs)
    my = sum(y for _, y in pairs) / len(pairs)
    vx = [x - mx for x, _ in pairs]
    vy = [y - my for _, y in pairs]
    den = math.sqrt(sum(x*x for x in vx) * sum(y*y for y in vy))
    return float(sum(x*y for x, y in zip(vx, vy)) / den) if den > 0.0 else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("genealogical_corridor_length"))


def entropy_gradient_current_rows(history_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Test whether B=live-record behaves like the history/live entropy carrier.

    This is deliberately weaker than an analytic entropy-gradient property.  It
    checks level-direction, correlation, and modular-spread alignment of
    JS(live,record), ||B||, and the finite Tomita modular spread.
    """
    base = [r for r in history_rows if r.get("measure_surface") == "history_live_measure_finite_object"]
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in base:
        tracks[_track_key(r)].append(r)
    rows: List[dict] = []
    for key, xs in sorted(tracks.items(), key=lambda kv: str(kv[0])):
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            by_l[int(r.get("level", -1))].append(r)
        levels = sorted(k for k in by_l if k >= 0)
        js = {L: _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_l[L]) for L in levels}
        bnorm = {L: _median(_finite(r.get("backreaction_current_norm")) for r in by_l[L]) for L in levels}
        mod = {L: _median(_finite(r.get("modular_spread_live")) for r in by_l[L]) for L in levels}
        gain = {L: _median(_finite(r.get("record_tracking_gain_over_uniform")) for r in by_l[L]) for L in levels}
        corr_js_b = _pearson([_finite(r.get("JS_live_record_no_epsilon")) for r in xs], [_finite(r.get("backreaction_current_norm")) for r in xs])
        corr_js_mod = _pearson([_finite(r.get("JS_live_record_no_epsilon")) for r in xs], [_finite(r.get("modular_spread_live")) for r in xs])
        corr_b_mod = _pearson([_finite(r.get("backreaction_current_norm")) for r in xs], [_finite(r.get("modular_spread_live")) for r in xs])
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            d_js = js[last] - js[first] if math.isfinite(js[last]) and math.isfinite(js[first]) else math.nan
            d_b = bnorm[last] - bnorm[first] if math.isfinite(bnorm[last]) and math.isfinite(bnorm[first]) else math.nan
            d_mod = mod[last] - mod[first] if math.isfinite(mod[last]) and math.isfinite(mod[first]) else math.nan
            same_js_b = int(math.isfinite(d_js) and math.isfinite(d_b) and d_js * d_b > tol)
            same_js_mod = int(math.isfinite(d_js) and math.isfinite(d_mod) and d_js * d_mod > tol)
            if same_js_b and same_js_mod and corr_js_b > 0.5:
                computed_status = "entropy_gradient_current_direction_finite_object"
            elif same_js_b:
                computed_status = "entropy_current_direction_without_modular_alignment_control"
            elif math.isfinite(d_js) and math.isfinite(d_b) and d_js * d_b < -tol:
                computed_status = "entropy_current_direction_opposition_observed"
            else:
                computed_status = "entropy_gradient_current_unresolved_control"
        else:
            first = last = -1
            d_js = d_b = d_mod = math.nan
            same_js_b = same_js_mod = 0
            computed_status = "entropy_gradient_current_insufficient_level_track"
        rows.append({
            "branching": key[0],
            "mode": key[1],
            "genealogical_corridor_length": key[2],
            "entropy_gradient_surface": "JS_B_modular_birth_order_track",
            "track_level_count": int(len(levels)),
            "first_level": int(first),
            "last_level": int(last),
            "JS_first_level_median": js.get(first, math.nan),
            "JS_last_level_median": js.get(last, math.nan),
            "B_norm_first_level_median": bnorm.get(first, math.nan),
            "B_norm_last_level_median": bnorm.get(last, math.nan),
            "modular_spread_first_level_median": mod.get(first, math.nan),
            "modular_spread_last_level_median": mod.get(last, math.nan),
            "record_tracking_gain_first_level_median": gain.get(first, math.nan),
            "record_tracking_gain_last_level_median": gain.get(last, math.nan),
            "delta_JS_live_record": d_js,
            "delta_backreaction_current_norm": d_b,
            "delta_modular_spread_live": d_mod,
            "JS_and_B_same_level_direction": same_js_b,
            "JS_and_modular_spread_same_level_direction": same_js_mod,
            "corr_JS_vs_B_norm": corr_js_b,
            "corr_JS_vs_modular_spread": corr_js_mod,
            "corr_B_norm_vs_modular_spread": corr_b_mod,
            "entropy_gradient_current_computed_status": computed_status,
        })
    return rows


def entropy_gradient_current_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("entropy_gradient_current_computed_status", "unknown")) for r in rows})
    return (
        "# Entropy-gradient current derived_quantity rows\n\n"
        "This surface checks whether the history/live measure is carried by `B=live-record` in the finite tracks: level direction of JS, B-norm, and modular spread; plus track correlations.  It is not a differentiable entropy-gradient property.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
