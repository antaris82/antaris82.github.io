from __future__ import annotations

from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import EmptySetGrowthModel, orientation_measurement


def _edge_weights_by_address(model: EmptySetGrowthModel, state: str) -> Dict[Tuple[Tuple[int, ...], Tuple[int, ...]], float]:
    if state == "record":
        edges = model.record_edges
    elif state in {"live", "sym"}:
        edges = model.live_edges
    else:
        raise ValueError("state must be live/record/sym")
    out: Dict[Tuple[Tuple[int, ...], Tuple[int, ...]], float] = {}
    for (i, j), w in sorted(edges.items()):
        ai = tuple(model.nodes[i].address)
        aj = tuple(model.nodes[j].address)
        out[(ai, aj)] = float(out.get((ai, aj), 0.0) + float(w))
    if state == "sym":
        keys = set(out) | {(b, a) for (a, b) in out}
        return {k: 0.5 * (out.get(k, 0.0) + out.get((k[1], k[0]), 0.0)) for k in keys}
    return out


def _dict_linf(a: Dict, b: Dict) -> float:
    keys = set(a) | set(b)
    if not keys:
        return 0.0
    return float(max(abs(float(a.get(k, 0.0)) - float(b.get(k, 0.0))) for k in keys))


def _dict_l1(a: Dict, b: Dict) -> float:
    keys = set(a) | set(b)
    return float(sum(abs(float(a.get(k, 0.0)) - float(b.get(k, 0.0))) for k in keys))


def _node_field_by_address(model: EmptySetGrowthModel, field: str) -> Dict[Tuple[int, ...], float]:
    return {tuple(n.address): float(getattr(n, field)) for n in model.nodes}


def _rank_reverse_pair(branching: int, level: int, mode: str, growth_schedule: str) -> Tuple[EmptySetGrowthModel, EmptySetGrowthModel]:
    rank_model = EmptySetGrowthModel(
        branching,
        level,
        mode,
        sibling_linearization="rank",
        reverse_sibling_order=False,
        growth_schedule=growth_schedule,
    )
    reverse_model = EmptySetGrowthModel(
        branching,
        level,
        mode,
        sibling_linearization="reverse_rank",
        reverse_sibling_order=True,
        growth_schedule=growth_schedule,
    )
    return rank_model, reverse_model


def birth_linearization_invariance_rows(
    branching_values: Sequence[int],
    levels: Sequence[int],
    modes: Sequence[str],
    states: Sequence[str],
    growth_schedules: Sequence[str] = ("slot_step", "layer_batch"),
) -> List[dict]:
    rows: List[dict] = []
    for b in branching_values:
        for L in levels:
            for mode in modes:
                for schedule in growth_schedules:
                    rank_model, reverse_model = _rank_reverse_pair(int(b), int(L), str(mode), str(schedule))
                    g_rank = _node_field_by_address(rank_model, "g")
                    g_reverse = _node_field_by_address(reverse_model, "g")
                    birth_g_rank = _node_field_by_address(rank_model, "birth_g")
                    birth_g_reverse = _node_field_by_address(reverse_model, "birth_g")
                    for state in states:
                        edge_rank = _edge_weights_by_address(rank_model, state)
                        edge_reverse = _edge_weights_by_address(reverse_model, state)
                        orient_rank = orientation_measurement(rank_model, state)
                        orient_reverse = orientation_measurement(reverse_model, state)
                        circ_rank = float(orient_rank.get("F1F2_plane_circulation", 0.0))
                        circ_reverse = float(orient_reverse.get("F1F2_plane_circulation", 0.0))
                        rows.append({
                            "branching": int(b),
                            "max_level": int(L),
                            "mode": str(mode),
                            "state": str(state),
                            "growth_schedule": str(schedule),
                            "source_linearization": "rank",
                            "target_linearization": "reverse_rank",
                            "node_count_source": len(rank_model.nodes),
                            "node_count_target": len(reverse_model.nodes),
                            "node_count_equal": int(len(rank_model.nodes) == len(reverse_model.nodes)),
                            "event_count_source": len(rank_model.events),
                            "event_count_target": len(reverse_model.events),
                            "event_count_equal": int(len(rank_model.events) == len(reverse_model.events)),
                            "address_set_equal": int({tuple(n.address) for n in rank_model.nodes} == {tuple(n.address) for n in reverse_model.nodes}),
                            "node_g_linf_by_address": _dict_linf(g_rank, g_reverse),
                            "birth_g_linf_by_address": _dict_linf(birth_g_rank, birth_g_reverse),
                            "edge_l1_by_address": _dict_l1(edge_rank, edge_reverse),
                            "edge_linf_by_address": _dict_linf(edge_rank, edge_reverse),
                            "orientation_source": circ_rank,
                            "orientation_target": circ_reverse,
                            "orientation_abs_delta": abs(circ_rank - circ_reverse),
                            "computed_status": "birth_linearization_residual_le_tolerance" if _dict_linf(edge_rank, edge_reverse) < 1e-10 and abs(circ_rank - circ_reverse) < 1e-10 else "birth_linearization_residual_measured",
                        })
    return rows
