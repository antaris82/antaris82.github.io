from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("region_family"), r.get("genealogical_corridor_length"))


def _trend(vals: Dict[int, float], name: str, tol: float) -> Tuple[str, float, float]:
    levels = sorted(vals)
    if len(levels) < 2:
        return (f"{name}_level_trend_unavailable", math.nan, math.nan)
    first, last = levels[0], levels[-1]
    a, b = vals[first], vals[last]
    if not math.isfinite(a) or not math.isfinite(b):
        return (f"{name}_level_trend_unresolved", a, b)
    condition = max(tol, tol * max(1.0, abs(a)))
    if b > a + condition:
        return (f"{name}_increases_with_level", a, b)
    if b < a - condition:
        return (f"{name}_decreases_with_level", a, b)
    return (f"{name}_level_stable", a, b)


def extended_entropy_level_trajectory_rows(history_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Extended L/b trajectory surface for the 7 common measure finite_object."""
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in history_rows:
        if r.get("measure_surface") == "history_live_measure_finite_object":
            tracks[_track_key(r)].append(r)
    rows: List[dict] = []
    for key, rs in tracks.items():
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in rs:
            L = int(r.get("level", -1))
            if L >= 0:
                by_l[L].append(r)
        levels = sorted(by_l)
        js_by_l = {L: _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_l[L]) for L in levels}
        gain_by_l = {L: _median(_finite(r.get("record_tracking_gain_over_uniform")) for r in by_l[L]) for L in levels}
        b_by_l = {L: _median(_finite(r.get("backreaction_current_norm")) for r in by_l[L]) for L in levels}
        sp_by_l = {L: _median(_finite(r.get("modular_spread_live")) for r in by_l[L]) for L in levels}
        eff_by_l = {L: _median(_finite(r.get("JS_live_record_per_backreaction_current_norm")) for r in by_l[L]) for L in levels}
        js_tr, js0, js1 = _trend(js_by_l, "history_live_js", tol)
        gain_tr, gain0, gain1 = _trend(gain_by_l, "record_tracking_gain", tol)
        b_tr, b0, b1 = _trend(b_by_l, "backreaction_current_norm", tol)
        sp_tr, sp0, sp1 = _trend(sp_by_l, "modular_spread_live", tol)
        eff_tr, eff0, eff1 = _trend(eff_by_l, "history_measure_per_current_efficiency", tol)
        if len(levels) >= 3:
            adequacy = "three_or_more_level_finite_scaling_track"
        elif len(levels) == 2:
            adequacy = "two_level_trend_control_not_full_scaling"
        else:
            adequacy = "single_level_control_no_scaling"
        if "increases" in js_tr and "increases" in gain_tr and "increases" in b_tr:
            computed_status = "history_live_measure_deepens_with_current_and_tracking_finite_object"
        elif "increases" in js_tr and "increases" in gain_tr:
            computed_status = "history_live_measure_deepens_with_tracking_finite_object"
        else:
            computed_status = "history_live_measure_level_trend_unresolved_or_nonmonotone"
        rows.append({
            "branching": key[0],
            "mode": key[1],
            "region_family": key[2],
            "genealogical_corridor_length": key[3],
            "levels_available": "|".join(str(int(L)) for L in levels),
            "level_track_count": int(len(levels)),
            "finite_scaling_adequacy_computed_status": adequacy,
            "JS_live_record_first_level_median": js0,
            "JS_live_record_last_level_median": js1,
            "record_tracking_gain_first_level_median": gain0,
            "record_tracking_gain_last_level_median": gain1,
            "backreaction_current_norm_first_level_median": b0,
            "backreaction_current_norm_last_level_median": b1,
            "modular_spread_live_first_level_median": sp0,
            "modular_spread_live_last_level_median": sp1,
            "history_measure_per_current_first_level_median": eff0,
            "history_measure_per_current_last_level_median": eff1,
            "history_live_js_level_trend": js_tr,
            "record_tracking_gain_level_trend": gain_tr,
            "backreaction_current_norm_level_trend": b_tr,
            "modular_spread_live_level_trend": sp_tr,
            "history_measure_per_current_efficiency_level_trend": eff_tr,
            "extended_entropy_level_trajectory_computed_status": computed_status,
        })
    return rows


def extended_entropy_level_trajectory_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("extended_entropy_level_trajectory_computed_status", "unknown")) for r in rows})
    adequacy = sorted({str(r.get("finite_scaling_adequacy_computed_status", "unknown")) for r in rows})
    return (
        "# Extended history/live entropy level trajectory\n\n"
        "This surface promotes 7's common measure finite_object to the common finite scaling axis for b/L trajectories.  "
        "Two-level tracks are explicitly marked as controls; three or more levels are required for stronger finite scaling statements.\n\n"
        "Adequacy computed_status_rows: `" + "`, `".join(adequacy) + "`.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
