from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

from cnna.core.emptyset_growth import EmptySetGrowthModel


@dataclass(frozen=True)
class OperatorTestConfig:
    branching: Tuple[int, ...] = (3,)
    levels: Tuple[int, ...] = (4,)
    modes: Tuple[str, ...] = ("linear",)
    states: Tuple[str, ...] = ("live", "record", "sym")
    max_regions: int = 1
    max_boundary: int = 600
    max_interior: int = 900
    directed_frontier_cap: int = 6
    algebra_tol: float = 1.0e-10
    rank_tol: float = 1.0e-9
    max_algebra_iter: int = 8
    tomita_matrix_sign_relations: Tuple[str, ...] = ("out_degree",)
    growth_schedule: str = "layer_batch"


def iter_growth_models(config: OperatorTestConfig):
    for b in config.branching:
        for L in config.levels:
            for mode in config.modes:
                yield int(b), int(L), str(mode), EmptySetGrowthModel(int(b), int(L), str(mode), growth_schedule=config.growth_schedule)

__all__ = [
    'OperatorTestConfig',
    'iter_growth_models'
]
