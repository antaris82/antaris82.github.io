from __future__ import annotations

import math
from collections import defaultdict
from typing import Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"), row.get("region_id"), row.get("genealogical_corridor_length"))


def fixed_oriented_history_measure_rows(two_component_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Freeze the 12 two-component measure before geometry consistency_check.

    This module deliberately does not fit weights to locality/split/complement.
    The density and F1/F2 skew-profile components are reported separately;
    the additive score is the reference fixed scale, and the Euclidean score is
    a control.  This is an input-exclusion surface, not a new property statement.
    """
    rows: List[dict] = []
    by_track = defaultdict(list)
    for r in two_component_rows:
        js = _finite(r.get("JS_live_record_no_epsilon"))
        fgap = _finite(r.get("F1F2_profile_gap_live_record"))
        additive = _finite(r.get("two_component_history_measure_additive"))
        euclid = _finite(r.get("two_component_history_measure_euclidean_control"))
        if math.isfinite(additive) and additive > tol and math.isfinite(js) and math.isfinite(fgap):
            js_fraction = float(js / additive)
            f1f2_fraction = float(fgap / additive)
        else:
            js_fraction = math.nan
            f1f2_fraction = math.nan
        if not math.isfinite(additive):
            computed_status = "fixed_history_measure_unavailable"
        elif additive <= max(tol, tol * max(1.0, abs(fgap), abs(js))):
            computed_status = "fixed_history_measure_vacuous_zero_control"
        elif math.isfinite(fgap) and fgap > max(tol, tol * max(1.0, abs(js))):
            computed_status = "fixed_oriented_history_measure_F1F2_dominant_finite_object"
        else:
            computed_status = "fixed_oriented_history_measure_density_dominant_control"
        row = {
            "branching": r.get("branching"),
            "level": r.get("level"),
            "mode": r.get("mode"),
            "region_id": r.get("region_id"),
            "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "measure_definition_fixed_before_geometry_tests": 1,
            "measure_weight_fit_to_geometry": 0,
            "fixed_measure_relations": "HistoryMeasure2_fixed_equals_JS_live_record_plus_F1F2_skew_2form_profile_gap",
            "fixed_measure_density_component": js,
            "fixed_measure_F1F2_component": fgap,
            "fixed_measure_additive_reference": additive,
            "fixed_measure_euclidean_control": euclid,
            "density_component_fraction_of_additive": js_fraction,
            "F1F2_component_fraction_of_additive": f1f2_fraction,
            "record_tracking_gain_over_uniform": _finite(r.get("record_tracking_gain_over_uniform")),
            "F1F2_true_record_beats_F2_flipped_record": int(r.get("F1F2_true_record_beats_F2_flipped_record", 0) or 0),
            "backreaction_current_norm": _finite(r.get("backreaction_current_norm")),
            "modular_spread_live": _finite(r.get("modular_spread_live")),
            "fixed_oriented_history_measure_computed_status": computed_status,
        }
        rows.append(row)
        by_track[(row["branching"], row["mode"], row["region_family"], row["genealogical_corridor_length"])].append(row)
    for _t, xs in by_track.items():
        by_l = defaultdict(list)
        for row in xs:
            try:
                by_l[int(row.get("level", -1))].append(row)
            except Exception:
                pass
        levels = sorted(k for k in by_l if k >= 0)
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            f = _median(row.get("fixed_measure_additive_reference") for row in by_l[first])
            l = _median(row.get("fixed_measure_additive_reference") for row in by_l[last])
            if math.isfinite(f) and math.isfinite(l) and l > f + max(tol, tol * max(1.0, abs(f))):
                trend = "fixed_measure_deepens_with_level"
            elif math.isfinite(f) and math.isfinite(l) and l < f - max(tol, tol * max(1.0, abs(f))):
                trend = "fixed_measure_decreases_with_level"
            else:
                trend = "fixed_measure_level_stable_or_unresolved"
            meta = {"fixed_measure_level_track_count": len(levels), "fixed_measure_first_level": first, "fixed_measure_last_level": last, "fixed_measure_first_level_median": f, "fixed_measure_last_level_median": l, "fixed_measure_level_trend": trend}
        else:
            meta = {"fixed_measure_level_track_count": len(levels), "fixed_measure_level_trend": "fixed_measure_level_trend_unavailable"}
        for row in xs:
            row.update(meta)
    return rows


def fixed_oriented_history_measure_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("fixed_oriented_history_measure_computed_status", "unknown")) for r in rows})
    fixed = sum(1 for r in rows if int(r.get("measure_definition_fixed_before_geometry_tests", 0) or 0) == 1)
    fitted = sum(1 for r in rows if int(r.get("measure_weight_fit_to_geometry", 1) or 1) != 0)
    fdom = sum(1 for r in rows if str(r.get("fixed_oriented_history_measure_computed_status", "")) == "fixed_oriented_history_measure_F1F2_dominant_finite_object")
    return (
        "# Fixed oriented HistoryMeasure consistency_check surface\n\n"
        "This surface freezes the two-component measure before geometry tests: `JS(live,record) + F1/F2 skew 2-form profile gap`.  No geometry-fitted weights are used; the Euclidean score is reported only as a control.\n\n"
        f"Fixed rows: {fixed}/{len(rows)}. Geometry-fitted rows: {fitted}/{len(rows)}.\n\n"
        f"F1/F2-dominant rows: {fdom}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
