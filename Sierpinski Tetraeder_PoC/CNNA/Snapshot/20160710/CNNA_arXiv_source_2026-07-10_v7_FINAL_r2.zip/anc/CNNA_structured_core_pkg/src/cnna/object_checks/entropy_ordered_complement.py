from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _hist_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {
        (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length")): r
        for r in history_rows
        if r.get("measure_surface") == "history_live_measure_finite_object"
    }


def entropy_ordered_complement_rows(history_rows: List[dict], complement_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Classify finite complement sign_relations relative to the history/live measure.

    The history/live measure does not choose a complement by itself.  It tags
    whether a complement sign_relation has algebraic support in a region where the
    record actually tracks live better than the inherited uniform carrier.
    """
    hidx = _hist_index(history_rows)
    rows: List[dict] = []
    counts: Dict[Tuple[object, ...], Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for r in complement_rows:
        key = (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        two = int(r.get("two_sided_duality_ok", 0) or 0)
        one = int(r.get("one_sided_inclusion_ok", 0) or 0)
        if two and gain > tol:
            computed_status = "entropy_supported_two_sided_finite_complement_finite_object"
        elif one and gain > tol:
            computed_status = "entropy_supported_one_sided_complement_finite_object"
        elif one:
            computed_status = "one_sided_complement_without_record_tracking_gain_control"
        else:
            computed_status = "entropy_ordered_complement_obstructed"
        ckey = (r.get("branching"), r.get("mode"), r.get("finite_complement_type"))
        counts[ckey][computed_status] += 1
        rows.append({
            "branching": r.get("branching"),
            "level": r.get("level"),
            "mode": r.get("mode"),
            "region_id": r.get("region_id"),
            "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "finite_complement_type": r.get("finite_complement_type"),
            "history_measure_used": "JS_live_record_no_epsilon",
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "one_sided_inclusion_ok": one,
            "two_sided_duality_ok": two,
            "complement_into_region_commutant_residual": r.get("complement_into_region_commutant_residual"),
            "region_commutant_into_complement_residual": r.get("region_commutant_into_complement_residual"),
            "source_finite_complement_computed_status": r.get("finite_complement_computed_status"),
            "entropy_ordered_complement_row_computed_status": computed_status,
        })
    # Track summary per complement type.
    for row in rows:
        ckey = (row.get("branching"), row.get("mode"), row.get("finite_complement_type"))
        c = counts[ckey]
        if c.get("entropy_supported_two_sided_finite_complement_finite_object", 0) > 0:
            tv = "entropy_ordered_complement_type_two_sided_finite_object_present"
        elif c.get("entropy_supported_one_sided_complement_finite_object", 0) > 0:
            tv = "entropy_ordered_complement_type_one_sided_only"
        else:
            tv = "entropy_ordered_complement_type_obstructed"
        row.update({
            "entropy_ordered_complement_type_row_count": int(sum(c.values())),
            "entropy_ordered_complement_type_one_sided_count": int(c.get("entropy_supported_one_sided_complement_finite_object", 0)),
            "entropy_ordered_complement_type_two_sided_count": int(c.get("entropy_supported_two_sided_finite_complement_finite_object", 0)),
            "entropy_ordered_complement_type_track_computed_status": tv,
        })
    return rows


def entropy_ordered_complement_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("entropy_ordered_complement_type_track_computed_status", "unknown")) for r in rows if "entropy_ordered_complement_type_track_computed_status" in r})
    return (
        "# Entropy-ordered complement taxonomy\n\n"
        "This surface uses `JS(live,record)` and the record-vs-uniform tracking gain to label which finite complement sign_relations are algebraically meaningful in regions where history tracks live.  "
        "It does not assert Haag duality.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
