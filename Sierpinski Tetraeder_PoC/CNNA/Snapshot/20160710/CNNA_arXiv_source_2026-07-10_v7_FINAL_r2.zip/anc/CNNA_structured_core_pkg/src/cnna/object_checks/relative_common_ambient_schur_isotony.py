from __future__ import annotations

from typing import List

from cnna.core.algebra_support import relative_common_ambient_schur_embedding_metrics
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    sibling_pair_regions,
)


INCLUSION_FINITE_OBJECTS = [
    ("root_anchor_response", "left_birth_cone_response", "anchor_into_left_birth_cone"),
    ("root_anchor_response", "right_birth_cone_response", "anchor_into_right_birth_cone"),
    ("left_frontier_response", "left_birth_cone_response", "frontier_into_left_birth_cone"),
    ("right_frontier_response", "right_birth_cone_response", "frontier_into_right_birth_cone"),
    ("symmetric_left_birth_cone_response", "left_birth_cone_response", "S_layer_into_mixed_left_cone"),
    ("skew_left_birth_cone_response", "left_birth_cone_response", "A_layer_into_mixed_left_cone"),
    ("symmetric_right_birth_cone_response", "right_birth_cone_response", "S_layer_into_mixed_right_cone"),
    ("skew_right_birth_cone_response", "right_birth_cone_response", "A_layer_into_mixed_right_cone"),
    ("left_birth_cone_response", "sibling_pair_response", "left_birth_cone_into_sibling_pair"),
    ("right_birth_cone_response", "sibling_pair_response", "right_birth_cone_into_sibling_pair"),
    ("sibling_pair_response", "full_regional_response", "sibling_pair_into_full_role_response"),
    ("positive_carrier_pair_response", "full_regional_response", "S_carrier_pair_into_full_role_response"),
    ("directed_current_pair_response", "full_regional_response", "A_current_pair_into_full_role_response"),
]


def relative_common_ambient_schur_isotony_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                for small_name, large_name, inclusion_type in INCLUSION_FINITE_OBJECTS:
                    rel = relative_common_ambient_schur_embedding_metrics(
                        model,
                        spec,
                        state,
                        small_name,
                        large_name,
                        tol=config.algebra_tol,
                    )
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        "inclusion_type": inclusion_type,
                        "subsystem_finite_object": small_name,
                        "supersystem_finite_object": large_name,
                        **rel,
                    })
    return rows


def relative_common_ambient_schur_isotony_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("relative_common_ambient_computed_status", "unknown")) for r in rows})
    checked = sum(int(r.get("relative_common_ambient_checked", 0)) for r in rows)
    exact = sum(1 for r in rows if str(r.get("relative_common_ambient_computed_status", "")) == "relative_common_ambient_schur_isotony_exact_finite_object")
    obstructed = sum(1 for r in rows if str(r.get("relative_common_ambient_computed_status", "")) == "relative_common_ambient_schur_isotony_rank_bound_observed")
    return (
        "# Relative common-ambient Schur isotony report\n\n"
        "This is Variant 3.  It fixes the superregion finite ambient and the same open-grounded outer sign_relation, "
        "then compares the direct conditional response on the sub-boundary with the Schur reduction of the superregion response after eliminating the extra super-boundary ports.  It is therefore a Schur-associativity / relative-observable test, not the raw differently-conditioned node-level measurement.\n\n"
        f"Checked rows: {checked}. Exact finite_objects: {exact}. Obstructions: {obstructed}.\n\n"
        "Observed computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
