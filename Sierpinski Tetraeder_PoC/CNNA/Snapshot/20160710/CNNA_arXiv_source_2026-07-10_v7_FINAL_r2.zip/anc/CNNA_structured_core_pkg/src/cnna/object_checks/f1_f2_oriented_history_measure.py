from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.core.directed_dtn import directed_schur_response_from_model, signed_role_basis_F1F2, split_symmetric_skew
from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.entropy_quantities import jensen_shannon_divergence_no_epsilon
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    positive_support_density_from_response,
    region_size_meta,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _js(a: np.ndarray, b: np.ndarray, tol: float) -> float:
    val, _meta = jensen_shannon_divergence_no_epsilon(a, b, tol)
    return float(val) if math.isfinite(val) else math.inf


def _coupling(A: np.ndarray) -> float:
    if A.shape[0] < 2 or A.shape[1] < 2:
        return math.nan
    return float(A[0, 1])


def _sign(x: float, tol: float) -> int:
    if not math.isfinite(x) or abs(x) <= tol:
        return 0
    return 1 if x > 0.0 else -1


def _orientation_gap(c_live: float, c_ref: float, tol: float) -> float:
    if not math.isfinite(c_live) or not math.isfinite(c_ref):
        return math.nan
    scale = max(abs(c_live), abs(c_ref), float(tol))
    return float(abs(c_live - c_ref) / scale)


def _oriented_distance(js: float, c_live: float, c_ref: float, tol: float) -> float:
    gap = _orientation_gap(c_live, c_ref, tol)
    if not math.isfinite(js) or not math.isfinite(gap):
        return math.inf
    # Dimensionless derived_quantity product: density-distance and signed F1/F2
    # skew-coupling mismatch are kept as separate columns and combined only as
    # a transparent Euclidean score.  This is a finite measurement score, not a new
    # property or a replacement for the un-oriented JS measure.
    return float(math.sqrt(js * js + gap * gap))


def _f1f2_plane_response(model, spec, state: str, tol: float, matrix_sign_relation: str = "out_degree") -> dict:
    res = directed_schur_response_from_model(
        model,
        state,
        spec.boundary,
        spec.interior,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    if not res.ok or res.Lambda is None:
        return {"ok": 0, "error": res.error or "response_unavailable"}
    Q, qnames, qrank = signed_role_basis_F1F2(spec.boundary, spec)
    Lp = Q.T @ res.Lambda @ Q
    Sp, Ap = split_symmetric_skew(Lp)
    D, Dmeta = positive_support_density_from_response(Lp, tol=max(tol, 1.0e-9))
    c = _coupling(Ap)
    carrier_norm = float(fro(Sp))
    current_norm = float(fro(Ap))
    current_condition = max(float(tol), float(tol) * max(1.0, carrier_norm))
    return {
        "ok": 1,
        "Lambda_plane": Lp,
        "S_plane": Sp,
        "A_plane": Ap,
        "density": D,
        "density_meta": Dmeta,
        "basis_rank": int(qrank),
        "basis_names": tuple(qnames),
        "carrier_norm": carrier_norm,
        "current_norm": current_norm,
        "current_condition": float(current_condition),
        "vacuous_zero_f1f2_current": int(current_norm <= current_condition),
        "coupling": c,
        "coupling_sign": _sign(c, current_condition),
        "cond_KII": float(res.cond_KII),
        "solve_residual": float(res.solve_residual),
        "row_sum_residual": float(res.row_sum_residual),
        "boundary_response_model": res.boundary_response_model,
    }


def _plane_transform(dim: int, kind: str) -> np.ndarray:
    T = np.eye(dim, dtype=float)
    if dim < 2:
        return T
    if kind == "F2_flip":
        T[1, 1] = -1.0
    elif kind == "F1_flip":
        T[0, 0] = -1.0
    elif kind == "F1F2_swap":
        T = np.eye(dim, dtype=float)
        T[[0, 1], :] = T[[1, 0], :]
    return T


def _apply_transform(rec: dict, kind: str) -> Tuple[np.ndarray, float]:
    D = rec["density"]
    A = rec["A_plane"]
    T = _plane_transform(D.shape[0], kind)
    Dt = T @ D @ T.T
    At = T @ A @ T.T
    return 0.5 * (Dt + Dt.T), _coupling(At)


def _uniform_plane_density(dim: int) -> np.ndarray:
    if dim <= 0:
        return np.zeros((0, 0), dtype=float)
    return np.eye(dim, dtype=float) / float(dim)


def _meta_key_without_L(b: int, mode: str, meta: dict) -> Tuple[object, ...]:
    return (
        int(b), str(mode), str(meta.get("region_family")), int(meta.get("lca", -1)),
        int(meta.get("left_root", -1)), int(meta.get("right_root", -1)),
        int(meta.get("genealogical_corridor_length", -1)),
    )


def _meta_key_without_mode(b: int, L: int, meta: dict) -> Tuple[object, ...]:
    return (
        int(b), int(L), str(meta.get("region_family")), int(meta.get("lca", -1)),
        int(meta.get("left_root", -1)), int(meta.get("right_root", -1)),
        int(meta.get("genealogical_corridor_length", -1)), int(meta.get("frontier_level", -1)),
    )


def f1_f2_oriented_history_measure_rows(config: OperatorTestConfig) -> List[dict]:
    """Birth-order-sensitive history/live measure on the signed F1/F2 plane.

    The un-oriented `JS(live,record)` is kept as the density baseline.  CNNA's
    proposed physical carrier, however, is the skew F1/F2 coupling.  This measurement
    therefore adds an explicitly signed component from the F1/F2 skew coupling
    A[F1,F2].  Deterministic controls flip or swap the F axes without adding a
    stochastic model input.
    """
    recs: List[dict] = []
    by_no_L: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    by_no_mode: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []

    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _f1f2_plane_response(model, spec, "live", config.algebra_tol)
            record = _f1f2_plane_response(model, spec, "record", config.algebra_tol)
            sym = _f1f2_plane_response(model, spec, "sym", config.algebra_tol)
            if not live.get("ok") or not record.get("ok"):
                rows.append({
                    "branching": b, "level": L, "mode": mode, **meta,
                    "measure_surface": "F1_F2_oriented_history_measure",
                    "F1_F2_oriented_measure_computed_status": "F1F2_response_unavailable",
                    "F1_F2_response_error": str(live.get("error") or record.get("error") or "unknown"),
                })
                continue
            rec = {
                "b": int(b), "L": int(L), "mode": str(mode), "meta": meta,
                "live": live, "record": record, "sym": sym,
            }
            recs.append(rec)
            by_no_L[_meta_key_without_L(b, mode, meta)].append(rec)
            by_no_mode[_meta_key_without_mode(b, L, meta)].append(rec)

    for rec in recs:
        b = rec["b"]; L = rec["L"]; mode = rec["mode"]; meta = rec["meta"]
        live = rec["live"]; record = rec["record"]; sym = rec["sym"]
        tol = float(config.algebra_tol)
        Dlive = live["density"]
        Drec = record["density"]
        c_live = _finite(live["coupling"])
        c_record = _finite(record["coupling"])
        js_true = _js(Dlive, Drec, tol)
        oriented_true = _oriented_distance(js_true, c_live, c_record, tol)
        uniform = _uniform_plane_density(Dlive.shape[0])
        js_uniform = _js(Dlive, uniform, tol)
        oriented_uniform = _oriented_distance(js_uniform, c_live, 0.0, tol)

        control_scores: Dict[str, float] = {}
        control_js: Dict[str, float] = {}
        control_coupling: Dict[str, float] = {}
        for kind in ("F2_flip", "F1_flip", "F1F2_swap"):
            Dt, ct = _apply_transform(record, kind)
            control_js[kind] = _js(Dlive, Dt, tol)
            control_coupling[kind] = _finite(ct)
            control_scores[kind] = _oriented_distance(control_js[kind], c_live, control_coupling[kind], tol)

        # Time-shift and mode-mismatch controls are scored in the same oriented
        # metric, not only by support-density JS.
        level_controls = [x for x in by_no_L[_meta_key_without_L(b, mode, meta)] if int(x["L"]) != int(L) and x["record"]["density"].shape == Dlive.shape]
        time_pairs = []
        for x in level_controls:
            js = _js(Dlive, x["record"]["density"], tol)
            score = _oriented_distance(js, c_live, _finite(x["record"]["coupling"]), tol)
            time_pairs.append((int(x["L"]), js, score))
        if time_pairs:
            time_L, js_time, oriented_time = min(time_pairs, key=lambda p: p[2])
        else:
            time_L, js_time, oriented_time = -1, math.nan, math.nan

        mode_controls = [x for x in by_no_mode[_meta_key_without_mode(b, L, meta)] if str(x["mode"]) != str(mode) and x["record"]["density"].shape == Dlive.shape]
        mode_pairs = []
        for x in mode_controls:
            js = _js(Dlive, x["record"]["density"], tol)
            score = _oriented_distance(js, c_live, _finite(x["record"]["coupling"]), tol)
            mode_pairs.append((str(x["mode"]), js, score))
        if mode_pairs:
            mode_used, js_mode, oriented_mode = min(mode_pairs, key=lambda p: p[2])
        else:
            mode_used, js_mode, oriented_mode = "unavailable", math.nan, math.nan

        available = [oriented_uniform, control_scores["F2_flip"], control_scores["F1_flip"], control_scores["F1F2_swap"]]
        if math.isfinite(oriented_time):
            available.append(oriented_time)
        if math.isfinite(oriented_mode):
            available.append(oriented_mode)
        score_tol = max(1.0e-8, 100.0 * float(tol))
        passed = sum(1 for x in available if math.isfinite(x) and oriented_true < x - score_tol)
        available_count = sum(1 for x in available if math.isfinite(x))

        score_tol = max(1.0e-8, 100.0 * float(tol))
        density_only_beats_f2 = int(math.isfinite(js_true) and math.isfinite(control_js["F2_flip"]) and js_true < control_js["F2_flip"] - score_tol)
        oriented_beats_f2 = int(math.isfinite(oriented_true) and math.isfinite(control_scores["F2_flip"]) and oriented_true < control_scores["F2_flip"] - score_tol)
        orientation_resolves = int((not density_only_beats_f2) and oriented_beats_f2)
        sym_zero = int(bool(sym.get("ok")) and int(sym.get("vacuous_zero_f1f2_current", 0)) == 1)
        live_zero = int(live.get("vacuous_zero_f1f2_current", 0))
        record_zero = int(record.get("vacuous_zero_f1f2_current", 0))
        if live.get("basis_rank", 0) < 2:
            computed_status = "F1F2_plane_rank_insufficient_control"
        elif live_zero:
            computed_status = "F1F2_live_orientation_vacuous_zero_current_control"
        elif available_count >= 4 and passed >= 4:
            computed_status = "F1F2_oriented_true_record_preferred_finite_object"
        elif orientation_resolves:
            computed_status = "F1F2_orientation_resolves_density_control_ambiguity_finite_object"
        elif oriented_beats_f2 and passed >= 2:
            computed_status = "F1F2_birth_order_orientation_partially_supported_control"
        else:
            computed_status = "F1F2_oriented_history_measure_obstructed_or_unresolved"

        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            **meta,
            "measure_surface": "F1_F2_oriented_history_measure",
            "F1_F2_relations": "longitudinal_F1_root_front_axis_coupled_to_transversal_F2_birth_order_axis",
            "F1_F2_basis_names": "|".join(str(x) for x in live.get("basis_names", ())),
            "F1_F2_basis_rank": int(live.get("basis_rank", 0)),
            "F1_F2_density_measure_component": "JS_on_positive_support_density_in_signed_F1F2_plane_no_epsilon",
            "F1_F2_orientation_component": "signed_skew_coupling_A_F1_F2_no_complex_import",
            "JS_live_record_F1F2_density_no_epsilon": float(js_true) if math.isfinite(js_true) else math.inf,
            "F1_F2_live_skew_coupling": c_live,
            "F1_F2_record_skew_coupling": c_record,
            "F1_F2_backreaction_skew_coupling": float(c_live - c_record) if math.isfinite(c_live) and math.isfinite(c_record) else math.nan,
            "F1_F2_live_coupling_sign": int(live.get("coupling_sign", 0)),
            "F1_F2_record_coupling_sign": int(record.get("coupling_sign", 0)),
            "F1_F2_live_record_coupling_sign_alignment": int(_sign(c_live, tol) * _sign(c_record, tol)) if math.isfinite(c_live) and math.isfinite(c_record) else 0,
            "F1_F2_orientation_gap_live_record": _orientation_gap(c_live, c_record, tol),
            "F1_F2_oriented_history_distance_live_record": oriented_true,
            "F1_F2_oriented_distance_live_uniform": oriented_uniform,
            "F1_F2_oriented_distance_live_F2_flipped_record": control_scores["F2_flip"],
            "F1_F2_oriented_distance_live_F1_flipped_record": control_scores["F1_flip"],
            "F1_F2_oriented_distance_live_F1F2_swapped_record": control_scores["F1F2_swap"],
            "JS_live_F2_flipped_record_F1F2_density": control_js["F2_flip"],
            "F1_F2_F2_flipped_record_skew_coupling": control_coupling["F2_flip"],
            "F1_F2_oriented_distance_live_time_shifted_record_best_available": oriented_time,
            "F1_F2_time_shifted_record_level_used": int(time_L),
            "F1_F2_oriented_distance_live_mode_mismatched_record_best_available": oriented_mode,
            "F1_F2_mode_mismatched_record_mode_used": mode_used,
            "F1_F2_oriented_true_record_gain_over_uniform": float(oriented_uniform - oriented_true) if math.isfinite(oriented_uniform) and math.isfinite(oriented_true) else math.nan,
            "F1_F2_oriented_true_record_gain_over_F2_flipped": float(control_scores["F2_flip"] - oriented_true) if math.isfinite(control_scores["F2_flip"]) and math.isfinite(oriented_true) else math.nan,
            "F1_F2_oriented_true_record_gain_over_F1_flipped": float(control_scores["F1_flip"] - oriented_true) if math.isfinite(control_scores["F1_flip"]) and math.isfinite(oriented_true) else math.nan,
            "F1_F2_oriented_true_record_gain_over_F1F2_swapped": float(control_scores["F1F2_swap"] - oriented_true) if math.isfinite(control_scores["F1F2_swap"]) and math.isfinite(oriented_true) else math.nan,
            "F1_F2_density_only_true_beats_F2_flipped": density_only_beats_f2,
            "F1_F2_oriented_true_beats_F2_flipped": oriented_beats_f2,
            "F1_F2_orientation_resolves_density_control_ambiguity": orientation_resolves,
            "F1_F2_oriented_score_margin_tol": float(score_tol),
            "F1_F2_record_orientation_degenerate_zero_coupling": int(_sign(c_record, score_tol) == 0),
            "F1_F2_destroyed_history_control_count": int(available_count),
            "F1_F2_destroyed_history_control_passed_count": int(passed),
            "F1_F2_live_current_norm": float(live.get("current_norm", math.nan)),
            "F1_F2_record_current_norm": float(record.get("current_norm", math.nan)),
            "F1_F2_sym_current_norm": float(sym.get("current_norm", math.nan)) if bool(sym.get("ok")) else math.nan,
            "F1_F2_live_current_norm_condition": float(live.get("current_condition", math.nan)),
            "F1_F2_vacuous_zero_live_current": live_zero,
            "F1_F2_vacuous_zero_record_current": record_zero,
            "F1_F2_vacuous_zero_sym_current_control": sym_zero,
            "F1_F2_oriented_measure_computed_status": computed_status,
        })
    return rows


def f1_f2_oriented_history_measure_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("F1_F2_oriented_measure_computed_status", "unknown")) for r in rows})
    preferred = sum(1 for r in rows if str(r.get("F1_F2_oriented_measure_computed_status", "")).startswith("F1F2_oriented_true_record_preferred"))
    resolved = sum(1 for r in rows if str(r.get("F1_F2_oriented_measure_computed_status", "")) == "F1F2_orientation_resolves_density_control_ambiguity_finite_object")
    return (
        "# F1/F2 oriented history-live measure measurement\n\n"
        "This surface keeps `JS(live,record)` as the support-density baseline but adds the signed skew coupling on the longitudinal F1 / transversal F2 plane.  The purpose is to test the CNNA statement that the history-live measure is birth-order-sensitive because the physical structure is carried by the skew F1/F2 coupling, not by an unordered density distance alone.\n\n"
        f"Preferred true-record oriented computed_status_rows: {preferred}/{len(rows)}.\n\n"
        f"Rows where the orientation component resolves a density-only F2-flip ambiguity: {resolved}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
