from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.core.directed_dtn import (
    build_coarse_frontier_sibling_regions,
    directed_schur_response_from_model,
    split_symmetric_skew,
)
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import EPS, fro
from cnna.core.nested_multiscale import (
    CommonAmbientSchurResult,
    NestedRoleBasis,
    common_ambient_interlevel_schur,
    corner_embed,
    corner_restrict,
    label_inclusion_matrix,
    nested_address_contrast_basis,
    resolved_support_graph_metrics,
    role_intertwining_metrics,
)
from cnna.core.response_algebra import positive_density_from_response
from cnna.core.schur_dtn import RegionSpec, build_sibling_regions, schur_response_from_model
from cnna.derived_quantities.directed_current_transport import _boundary_prefix_transport_matrix




def _ambient_J_from_SA(S: np.ndarray, A: np.ndarray, tol: float = 1.0e-10) -> Tuple[Optional[np.ndarray], dict]:
    try:
        values, vectors = np.linalg.eigh(0.5 * (S + S.T))
    except np.linalg.LinAlgError:
        return None, {"available": 0, "reason": "S_eigh_failed"}
    maximum = float(np.max(values)) if values.size else 0.0
    support = values > max(tol, tol * max(1.0, maximum))
    support_rank = int(np.sum(support))
    if support_rank < 2:
        return None, {"available": 0, "reason": "positive_support_rank_lt_2", "S_support_rank": support_rank}
    U = vectors[:, support]
    inverse_sqrt = np.diag(1.0 / np.sqrt(values[support]))
    J_raw = inverse_sqrt @ (U.T @ A @ U) @ inverse_sqrt
    try:
        left, singular_values, right_t = np.linalg.svd(J_raw)
    except np.linalg.LinAlgError:
        return None, {"available": 0, "reason": "Jraw_svd_failed", "S_support_rank": support_rank}
    threshold = max(tol, tol * max(1.0, float(np.max(singular_values)) if singular_values.size else 0.0))
    nonzero = singular_values > threshold
    skew_rank = int(np.sum(nonzero))
    if skew_rank < 2:
        return None, {"available": 0, "reason": "skew_support_rank_lt_2", "S_support_rank": support_rank, "skew_rank": skew_rank}
    J_support = left[:, nonzero] @ right_t.T[:, nonzero].T
    projector_support = left[:, nonzero] @ left[:, nonzero].T
    J_ambient = U @ J_support @ U.T
    projector_ambient = U @ projector_support @ U.T
    square_error = fro(J_ambient @ J_ambient + projector_ambient) / max(fro(projector_ambient), EPS)
    return J_ambient, {
        "available": 1,
        "reason": "ambient_polar_partial_isometry_available",
        "S_support_rank": support_rank,
        "skew_rank": skew_rank,
        "skew_rank_even": int(skew_rank % 2 == 0),
        "J_square_minus_negative_projector_error": square_error,
    }


@dataclass
class NestedSnapshot:
    model: EmptySetGrowthModel
    state: str
    region: RegionSpec
    basis: NestedRoleBasis
    symmetric_boundary_response: np.ndarray
    directed_boundary_response: np.ndarray
    symmetric_role_response: np.ndarray
    directed_role_response: np.ndarray
    S: np.ndarray
    A: np.ndarray
    density: np.ndarray
    J: Optional[np.ndarray]
    J_info: dict


def _first_terminal_region(model: EmptySetGrowthModel) -> Optional[RegionSpec]:
    regions = build_sibling_regions(model, max_regions=1)
    return regions[0] if regions else None


def build_nested_snapshot(model: EmptySetGrowthModel, state: str) -> Optional[NestedSnapshot]:
    region = _first_terminal_region(model)
    if region is None:
        return None
    symmetric = schur_response_from_model(model, state, region.boundary, region.interior)
    directed = directed_schur_response_from_model(
        model,
        state,
        region.boundary,
        region.interior,
        include_external_degrees=True,
        matrix_sign_relation="out_degree",
    )
    if not symmetric.ok or symmetric.Lambda is None or not directed.ok or directed.Lambda is None:
        return None
    basis = nested_address_contrast_basis(model, region)
    symmetric_role = basis.Q.T @ symmetric.Lambda @ basis.Q
    directed_role = basis.Q.T @ directed.Lambda @ basis.Q
    S, A = split_symmetric_skew(directed_role)
    density = positive_density_from_response(directed_role)
    J, J_info = _ambient_J_from_SA(S, A, tol=1.0e-10)
    return NestedSnapshot(
        model=model,
        state=state,
        region=region,
        basis=basis,
        symmetric_boundary_response=symmetric.Lambda,
        directed_boundary_response=directed.Lambda,
        symmetric_role_response=symmetric_role,
        directed_role_response=directed_role,
        S=S,
        A=A,
        density=density,
        J=J,
        J_info=J_info,
    )


def _relative_error(X: np.ndarray, Y: np.ndarray) -> float:
    return fro(X - Y) / max(fro(Y), EPS)


def _deterministic_test_matrices(dimension: int) -> Tuple[np.ndarray, np.ndarray]:
    indices = np.arange(dimension, dtype=float)
    X = np.diag(1.0 + indices / float(max(1, dimension)))
    if dimension > 1:
        X += np.diag(np.full(dimension - 1, 0.125), 1)
    Y = np.diag(0.5 + indices[::-1] / float(max(1, dimension)))
    if dimension > 1:
        Y += np.diag(np.full(dimension - 1, -0.075), -1)
    return X, Y


def _state_inner_product(D: np.ndarray, X: np.ndarray, Y: np.ndarray) -> float:
    return float(np.trace(D @ X.T @ Y))


def _address_sequence(model: EmptySetGrowthModel, nodes: Sequence[int]) -> List[Tuple[int, ...]]:
    return [tuple(model.nodes[int(nid)].address) for nid in nodes]


def _permutation_from_addresses(
    source_model: EmptySetGrowthModel,
    source_nodes: Sequence[int],
    target_model: EmptySetGrowthModel,
    target_nodes: Sequence[int],
) -> np.ndarray:
    source_addresses = _address_sequence(source_model, source_nodes)
    target_positions = {address: i for i, address in enumerate(_address_sequence(target_model, target_nodes))}
    P = np.zeros((len(target_nodes), len(source_nodes)), dtype=float)
    for j, address in enumerate(source_addresses):
        i = target_positions.get(address)
        if i is None:
            raise ValueError(f"address missing from target boundary: {address}")
        P[i, j] = 1.0
    return P


def nested_carrier_rows(
    branchings: Sequence[int] = (2, 3, 4),
    levels: Sequence[int] = (4, 5, 6),
) -> Tuple[List[dict], Dict[Tuple[int, int], Tuple[EmptySetGrowthModel, RegionSpec, NestedRoleBasis]]]:
    rows: List[dict] = []
    cache: Dict[Tuple[int, int], Tuple[EmptySetGrowthModel, RegionSpec, NestedRoleBasis]] = {}
    for branching in branchings:
        for level in levels:
            model = EmptySetGrowthModel(branching, level, mode="linear", growth_schedule="layer_batch")
            region = _first_terminal_region(model)
            if region is None:
                rows.append({"branching": branching, "level": level, "available": 0})
                continue
            basis = nested_address_contrast_basis(model, region)
            cache[(branching, level)] = (model, region, basis)
            expected_dimension = 3 + 2 * (branching - 1) * basis.relative_depth
            support_tolerance = max(1.0e-14, 1.0e-12)
            symmetric = schur_response_from_model(model, "live", region.boundary, region.interior)
            directed = directed_schur_response_from_model(
                model,
                "live",
                region.boundary,
                region.interior,
                include_external_degrees=True,
                matrix_sign_relation="out_degree",
            )
            if not symmetric.ok or symmetric.Lambda is None or not directed.ok or directed.Lambda is None:
                rows.append({"branching": branching, "level": level, "available": 0, "error": "response_unavailable"})
                continue
            symmetric_role = basis.Q.T @ symmetric.Lambda @ basis.Q
            directed_role = basis.Q.T @ directed.Lambda @ basis.Q
            symmetric_graph = resolved_support_graph_metrics(symmetric_role, support_tolerance)
            directed_graph = resolved_support_graph_metrics(directed_role, support_tolerance)
            directed_density = positive_density_from_response(directed_role)
            density_eigenvalues = np.linalg.eigvalsh(0.5 * (directed_density + directed_density.T))
            rows.append({
                "branching": branching,
                "level": level,
                "available": 1,
                "frontier_level": basis.frontier_level,
                "relative_address_depth": basis.relative_depth,
                "boundary_dimension": len(region.boundary),
                "nested_role_dimension": basis.Q.shape[1],
                "expected_nested_role_dimension": expected_dimension,
                "carrier_algebra_dimension": basis.Q.shape[1] ** 2,
                "basis_orthonormality_error": fro(basis.Q.T @ basis.Q - np.eye(basis.Q.shape[1])),
                "dimension_formula_ok": int(basis.Q.shape[1] == expected_dimension),
                "symmetric_resolved_support_connected": int(symmetric_graph["support_graph_connected"]),
                "symmetric_resolved_component_count": int(symmetric_graph["support_graph_component_count"]),
                "symmetric_minimum_resolved_coupling": symmetric_graph["minimum_resolved_coupling"],
                "directed_resolved_support_connected": int(directed_graph["support_graph_connected"]),
                "directed_resolved_component_count": int(directed_graph["support_graph_component_count"]),
                "directed_minimum_resolved_coupling": directed_graph["minimum_resolved_coupling"],
                "directed_density_rank": int(np.sum(density_eigenvalues > 1.0e-10)),
                "directed_density_minimum_eigenvalue": float(np.min(density_eigenvalues)),
                "support_tolerance": support_tolerance,
                "response_generated_full_matrix_algebra_condition": int(
                    symmetric_graph["support_graph_connected"] == 1.0
                    and directed_graph["support_graph_connected"] == 1.0
                ),
                "statement_scope": "first_order_address_contrasts_and_coordinate_projections",
            })
    return rows, cache


def nested_handoff_rows(
    states: Sequence[str] = ("record", "live"),
    branchings: Sequence[int] = (2, 3, 4),
    levels: Sequence[int] = (4, 5, 6),
) -> Tuple[List[dict], List[dict]]:
    snapshots: Dict[Tuple[int, int, str], Optional[NestedSnapshot]] = {}
    for branching in branchings:
        for level in levels:
            model = EmptySetGrowthModel(branching, level, mode="linear", growth_schedule="layer_batch")
            for state in states:
                snapshots[(branching, level, state)] = build_nested_snapshot(model, state)

    rows: List[dict] = []
    composition_rows: List[dict] = []
    pairs = [(source, target) for source in levels for target in levels if source < target]
    for branching in branchings:
        for state in states:
            for source_level, target_level in pairs:
                source = snapshots.get((branching, source_level, state))
                target = snapshots.get((branching, target_level, state))
                base = {
                    "branching": branching,
                    "state": state,
                    "source_level": source_level,
                    "target_level": target_level,
                }
                if source is None or target is None:
                    rows.append({**base, "available": 0, "error": "snapshot_unavailable"})
                    continue
                R, mapped, unmapped, _ = _boundary_prefix_transport_matrix(
                    target.model,
                    target.region.boundary,
                    source.model,
                    source.region.boundary,
                    weighting="fiber_sqrt",
                )
                V = R.T
                role_metrics = role_intertwining_metrics(V, source.basis, target.basis)
                T = target.basis.Q.T @ V @ source.basis.Q
                T_label = label_inclusion_matrix(source.basis.labels, target.basis.labels)
                d_source = source.basis.Q.shape[1]
                d_target = target.basis.Q.shape[1]
                X, Y = _deterministic_test_matrices(d_source)
                embedded_X = corner_embed(T, X)
                embedded_Y = corner_embed(T, Y)
                product_residual = _relative_error(corner_embed(T, X @ Y), embedded_X @ embedded_Y)
                transpose_residual = _relative_error(corner_embed(T, X.T), embedded_X.T)
                left_inverse_residual = _relative_error(corner_restrict(T, embedded_X), X)
                old_corner_unit = T @ T.T
                old_corner_rank = int(np.linalg.matrix_rank(old_corner_unit, tol=1.0e-10))
                global_unitality_defect = fro(old_corner_unit - np.eye(d_target)) / math.sqrt(float(d_target))

                symmetric_restricted = T.T @ target.symmetric_role_response @ T
                directed_restricted = T.T @ target.directed_role_response @ T
                S_restricted = T.T @ target.S @ T
                A_restricted = T.T @ target.A @ T
                symmetric_drift = _relative_error(symmetric_restricted, source.symmetric_role_response)
                directed_drift = _relative_error(directed_restricted, source.directed_role_response)
                S_drift = _relative_error(S_restricted, source.S)
                A_drift = _relative_error(A_restricted, source.A)

                restricted_density = T.T @ target.density @ T
                corner_mass = float(np.trace(restricted_density))
                if corner_mass > EPS:
                    conditional_density = 0.5 * (restricted_density + restricted_density.T) / corner_mass
                    conditional_identity_residual = fro(restricted_density - corner_mass * conditional_density)
                    independent_density_drift = _relative_error(conditional_density, source.density)
                    full_matrix_gns_gram_drift = _relative_error(
                        np.kron(np.eye(d_source), conditional_density),
                        np.kron(np.eye(d_source), source.density),
                    )
                    lhs = _state_inner_product(target.density, embedded_X, embedded_Y)
                    rhs_conditional = corner_mass * _state_inner_product(conditional_density, X, Y)
                    rhs_independent = corner_mass * _state_inner_product(source.density, X, Y)
                    scaled_gns_identity_residual = abs(lhs - rhs_conditional) / max(1.0, abs(lhs), abs(rhs_conditional))
                    independent_gns_isometry_drift = abs(lhs - rhs_independent) / max(1.0, abs(lhs), abs(rhs_independent))
                else:
                    conditional_identity_residual = math.inf
                    independent_density_drift = math.inf
                    full_matrix_gns_gram_drift = math.inf
                    scaled_gns_identity_residual = math.inf
                    independent_gns_isometry_drift = math.inf

                if source.J is not None and target.J is not None:
                    J_intertwining_error = fro(target.J @ T - T @ source.J) / max(1.0, fro(T @ source.J))
                    J_old_corner_error = _relative_error(T.T @ target.J @ T, source.J)
                    J_leakage = fro((np.eye(d_target) - old_corner_unit) @ target.J @ T) / max(1.0, fro(target.J @ T))
                    J_available = 1
                else:
                    J_intertwining_error = math.nan
                    J_old_corner_error = math.nan
                    J_leakage = math.nan
                    J_available = 0

                rows.append({
                    **base,
                    "available": 1,
                    "source_boundary_dimension": len(source.region.boundary),
                    "target_boundary_dimension": len(target.region.boundary),
                    "source_role_dimension": d_source,
                    "target_role_dimension": d_target,
                    "new_role_count": d_target - d_source,
                    "mapped_source_boundary_count": mapped,
                    "unmapped_source_boundary_count": unmapped,
                    "boundary_coisometry_error": fro(R @ R.T - np.eye(R.shape[0])),
                    **role_metrics,
                    "label_inclusion_error": fro(T - T_label),
                    "corner_product_morphism_error": product_residual,
                    "corner_transpose_error": transpose_residual,
                    "corner_left_inverse_error": left_inverse_residual,
                    "old_corner_projection_error": fro(old_corner_unit @ old_corner_unit - old_corner_unit),
                    "old_corner_rank": old_corner_rank,
                    "global_unitality_defect_expected_nonzero": global_unitality_defect,
                    "symmetric_response_corner_drift": symmetric_drift,
                    "directed_response_corner_drift": directed_drift,
                    "S_corner_drift": S_drift,
                    "A_corner_drift": A_drift,
                    "corner_state_mass": corner_mass,
                    "conditional_density_identity_error": conditional_identity_residual,
                    "independent_density_corner_drift": independent_density_drift,
                    "full_matrix_GNS_Gram_corner_drift": full_matrix_gns_gram_drift,
                    "conditional_scaled_GNS_isometry_error": scaled_gns_identity_residual,
                    "independent_GNS_isometry_drift": independent_gns_isometry_drift,
                    "J_available_both_levels": J_available,
                    "J_intertwining_error": J_intertwining_error,
                    "J_old_corner_error": J_old_corner_error,
                    "J_new_role_leakage": J_leakage,
                    "computed_status": "exact_nonunital_corner_carrier_handoff_with_quantified_distinguished_object_drift",
                    "condition_note": "carrier_and_role_embedding_exact; response_density_GNS_and_J_naturality_tested_separately",
                })

            if all((branching, level, state) in snapshots and snapshots[(branching, level, state)] is not None for level in (4, 5, 6)):
                s4 = snapshots[(branching, 4, state)]
                s5 = snapshots[(branching, 5, state)]
                s6 = snapshots[(branching, 6, state)]
                assert s4 is not None and s5 is not None and s6 is not None
                R45, _, _, _ = _boundary_prefix_transport_matrix(s5.model, s5.region.boundary, s4.model, s4.region.boundary, weighting="fiber_sqrt")
                R56, _, _, _ = _boundary_prefix_transport_matrix(s6.model, s6.region.boundary, s5.model, s5.region.boundary, weighting="fiber_sqrt")
                R46, _, _, _ = _boundary_prefix_transport_matrix(s6.model, s6.region.boundary, s4.model, s4.region.boundary, weighting="fiber_sqrt")
                V54 = R45.T
                V65 = R56.T
                V64 = R46.T
                T54 = s5.basis.Q.T @ V54 @ s4.basis.Q
                T65 = s6.basis.Q.T @ V65 @ s5.basis.Q
                T64 = s6.basis.Q.T @ V64 @ s4.basis.Q
                composition_rows.append({
                    "branching": branching,
                    "state": state,
                    "source_level": 4,
                    "mid_level": 5,
                    "target_level": 6,
                    "available": 1,
                    "boundary_isometry_composition_error": fro(V64 - V65 @ V54) / max(1.0, fro(V64)),
                    "role_inclusion_composition_error": fro(T64 - T65 @ T54) / max(1.0, fro(T64)),
                    "corner_projection_composition_error": fro(
                        T64 @ T64.T - T65 @ (T54 @ T54.T) @ T65.T
                    ) / max(1.0, fro(T64 @ T64.T)),
                    "computed_status": "nested_role_and_corner_composition_tested",
                })
    return rows, composition_rows


def common_ambient_schur_rows(
    states: Sequence[str] = ("record", "live"),
    cases: Sequence[Tuple[int, int, int]] = ((2, 4, 6), (3, 4, 6), (4, 4, 5)),
) -> List[dict]:
    rows: List[dict] = []
    for branching, coarse_level, fine_level in cases:
        fine_model = EmptySetGrowthModel(branching, fine_level, mode="linear", growth_schedule="layer_batch")
        coarse_model = EmptySetGrowthModel(branching, coarse_level, mode="linear", growth_schedule="layer_batch")
        terminal_region = _first_terminal_region(fine_model)
        coarse_region_fine_candidates = build_coarse_frontier_sibling_regions(
            fine_model,
            max_regions=1,
            max_boundary=2000,
            max_interior=4000,
            max_frontier_level=coarse_level,
        )
        coarse_region_independent = _first_terminal_region(coarse_model)
        if terminal_region is None or not coarse_region_fine_candidates or coarse_region_independent is None:
            rows.append({
                "branching": branching,
                "coarse_level": coarse_level,
                "fine_level": fine_level,
                "available": 0,
                "error": "region_unavailable",
            })
            continue
        coarse_region_fine = coarse_region_fine_candidates[0]
        fine_coarse_basis = nested_address_contrast_basis(fine_model, coarse_region_fine)
        independent_basis = nested_address_contrast_basis(coarse_model, coarse_region_independent)
        boundary_permutation = _permutation_from_addresses(
            fine_model,
            coarse_region_fine.boundary,
            coarse_model,
            coarse_region_independent.boundary,
        )
        basis_address_identification_error = fro(boundary_permutation @ fine_coarse_basis.Q - independent_basis.Q)
        for state in states:
            common: CommonAmbientSchurResult = common_ambient_interlevel_schur(
                fine_model,
                terminal_region,
                state,
                coarse_level,
            )
            independent = schur_response_from_model(
                coarse_model,
                state,
                coarse_region_independent.boundary,
                coarse_region_independent.interior,
            )
            available = int(
                common.direct.ok
                and common.direct.Lambda is not None
                and common.staged_second.ok
                and common.staged_second.Lambda is not None
                and independent.ok
                and independent.Lambda is not None
            )
            if not available:
                rows.append({
                    "branching": branching,
                    "state": state,
                    "coarse_level": coarse_level,
                    "fine_level": fine_level,
                    "available": 0,
                    "direct_error": common.direct.error,
                    "staged_error": common.staged_second.error,
                    "independent_error": independent.error,
                })
                continue
            assert common.direct.Lambda is not None
            assert common.staged_second.Lambda is not None
            assert independent.Lambda is not None
            nested_aligned = boundary_permutation @ common.direct.Lambda @ boundary_permutation.T
            nested_role = independent_basis.Q.T @ nested_aligned @ independent_basis.Q
            independent_role = independent_basis.Q.T @ independent.Lambda @ independent_basis.Q
            rows.append({
                "branching": branching,
                "state": state,
                "coarse_level": coarse_level,
                "fine_level": fine_level,
                "available": 1,
                "coarse_boundary_dimension": len(common.coarse_boundary),
                "stage_boundary_dimension": len(common.stage_boundary),
                "common_ambient_dimension": len(common.selected_nodes),
                "basis_address_identification_error": basis_address_identification_error,
                "direct_vs_staged_full_response_error": common.direct_vs_staged_residual,
                "direct_vs_staged_role_response_error": _relative_error(
                    fine_coarse_basis.Q.T @ common.direct.Lambda @ fine_coarse_basis.Q,
                    fine_coarse_basis.Q.T @ common.staged_second.Lambda @ fine_coarse_basis.Q,
                ),
                "nested_vs_independent_full_response_drift": _relative_error(nested_aligned, independent.Lambda),
                "nested_vs_independent_role_response_drift": _relative_error(nested_role, independent_role),
                "computed_status": "common_ambient_Schur_associativity_positive_control_with_independent_level_drift",
                "condition_note": "direct_and_staged_use_one_fine_model; independent_comparison_uses_separately_built_coarse_model",
            })
    return rows


def nested_multiscale_summary_rows(
    carrier_rows: Sequence[dict],
    handoff_rows: Sequence[dict],
    composition_rows: Sequence[dict],
    schur_rows: Sequence[dict],
    tolerance: float = 1.0e-9,
) -> List[dict]:
    carrier_available = [row for row in carrier_rows if int(row.get("available", 0) or 0) == 1]
    handoff_available = [row for row in handoff_rows if int(row.get("available", 0) or 0) == 1]
    composition_available = [row for row in composition_rows if int(row.get("available", 0) or 0) == 1]
    schur_available = [row for row in schur_rows if int(row.get("available", 0) or 0) == 1]

    carrier_exact = bool(carrier_available) and all(
        float(row.get("basis_orthonormality_error", math.inf)) <= tolerance
        and int(row.get("dimension_formula_ok", 0) or 0) == 1
        for row in carrier_available
    )
    dimensions_by_b: Dict[int, List[int]] = {}
    for row in carrier_available:
        dimensions_by_b.setdefault(int(row["branching"]), []).append(int(row["nested_role_dimension"]))
    strict_growth = bool(dimensions_by_b) and all(
        all(a < b for a, b in zip(values, values[1:]))
        for values in (sorted(dims) for dims in dimensions_by_b.values())
    )
    response_full_condition = bool(carrier_available) and all(
        int(row.get("response_generated_full_matrix_algebra_condition", 0) or 0) == 1
        for row in carrier_available
    )
    handoff_exact = bool(handoff_available) and all(
        int(row.get("unmapped_source_boundary_count", 1)) == 0
        and float(row.get("boundary_coisometry_error", math.inf)) <= tolerance
        and float(row.get("basis_intertwining_relative_error", math.inf)) <= tolerance
        and float(row.get("label_inclusion_error", math.inf)) <= tolerance
        and float(row.get("corner_product_morphism_error", math.inf)) <= tolerance
        and float(row.get("corner_transpose_error", math.inf)) <= tolerance
        and float(row.get("corner_left_inverse_error", math.inf)) <= tolerance
        and float(row.get("old_corner_projection_error", math.inf)) <= tolerance
        and float(row.get("conditional_density_identity_error", math.inf)) <= tolerance
        and float(row.get("conditional_scaled_GNS_isometry_error", math.inf)) <= tolerance
        for row in handoff_available
    )
    composition_exact = bool(composition_available) and all(
        float(row.get("boundary_isometry_composition_error", math.inf)) <= tolerance
        and float(row.get("role_inclusion_composition_error", math.inf)) <= tolerance
        and float(row.get("corner_projection_composition_error", math.inf)) <= tolerance
        for row in composition_available
    )
    schur_exact = bool(schur_available) and all(
        float(row.get("basis_address_identification_error", math.inf)) <= tolerance
        and float(row.get("direct_vs_staged_full_response_error", math.inf)) <= tolerance
        and float(row.get("direct_vs_staged_role_response_error", math.inf)) <= tolerance
        for row in schur_available
    )
    independent_drift_detected = bool(handoff_available) and any(
        float(row.get("directed_response_corner_drift", 0.0) or 0.0) > 100.0 * tolerance
        or float(row.get("independent_density_corner_drift", 0.0) or 0.0) > 100.0 * tolerance
        for row in handoff_available
    )
    common_ambient_independent_drift_detected = bool(schur_available) and any(
        float(row.get("nested_vs_independent_role_response_drift", 0.0) or 0.0) > 100.0 * tolerance
        for row in schur_available
    )
    J_naturality_not_assumed = bool(handoff_available) and any(
        int(row.get("J_available_both_levels", 0) or 0) == 1
        and float(row.get("J_intertwining_error", 0.0) or 0.0) > 100.0 * tolerance
        for row in handoff_available
    )
    overall = int(
        carrier_exact
        and strict_growth
        and response_full_condition
        and handoff_exact
        and composition_exact
        and schur_exact
        and independent_drift_detected
        and common_ambient_independent_drift_detected
    )
    return [{
        "control": "nested_multiscale_nontrivial_handoff",
        "pass": overall,
        "carrier_rows": len(carrier_available),
        "handoff_rows": len(handoff_available),
        "composition_rows": len(composition_available),
        "common_ambient_rows": len(schur_available),
        "nested_carrier_exact": int(carrier_exact),
        "strict_role_dimension_growth": int(strict_growth),
        "resolved_response_algebra_full_condition": int(response_full_condition),
        "nonunital_corner_handoff_exact": int(handoff_exact),
        "corner_composition_exact": int(composition_exact),
        "common_ambient_Schur_associativity_exact": int(schur_exact),
        "independent_response_or_state_drift_detected": int(independent_drift_detected),
        "common_ambient_vs_independent_drift_detected": int(common_ambient_independent_drift_detected),
        "J_naturality_failure_observed": int(J_naturality_not_assumed),
        "statement_scope": "finite_nested_first_order_address_role_carriers_and_nonunital_corner_embeddings",
    }]


def nested_multiscale_all_rows() -> Dict[str, List[dict]]:
    carrier_rows, _ = nested_carrier_rows()
    handoff_rows, composition_rows = nested_handoff_rows()
    schur_rows = common_ambient_schur_rows()
    summary_rows = nested_multiscale_summary_rows(carrier_rows, handoff_rows, composition_rows, schur_rows)
    return {
        "carrier": carrier_rows,
        "handoff": handoff_rows,
        "composition": composition_rows,
        "common_ambient_schur": schur_rows,
        "summary": summary_rows,
    }
