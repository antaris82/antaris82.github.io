from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Set, Tuple

from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.directed_dtn import region_frontier_level
from cnna.core.schur_dtn import RegionSpec

from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    sibling_pair_regions,
)


@dataclass(frozen=True)
class FiniteRegionRecord:
    region_key: str
    region_family: str
    carrier_region_id: str
    node_set: frozenset[int]
    boundary_ports: frozenset[int]
    environment_ports: frozenset[int]
    frontier_level: int
    terminal_level: int
    is_true_subregion: bool


def _descendants_until(model: EmptySetGrowthModel, root: int, frontier_level: int) -> Set[int]:
    base = model.nodes[root].address
    return {
        n.nid for n in model.nodes
        if len(n.address) >= len(base)
        and n.address[: len(base)] == base
        and int(n.level) <= int(frontier_level)
    }


def finite_region_records(model: EmptySetGrowthModel, spec: RegionSpec) -> List[FiniteRegionRecord]:
    frontier = int(region_frontier_level(model, spec))
    pair_nodes = frozenset(set(spec.boundary) | set(spec.interior))
    left_nodes = frozenset(_descendants_until(model, spec.left_root, frontier) | {spec.lca}) & pair_nodes
    right_nodes = frozenset(_descendants_until(model, spec.right_root, frontier) | {spec.lca}) & pair_nodes
    boundary_set = frozenset(spec.boundary)
    left_front = frozenset(spec.roles.get("B1_front", []))
    right_front = frozenset(spec.roles.get("B2_front", []))
    lca_set = frozenset(spec.roles.get("C_lca", []))
    data = [
        ("lca_anchor_region", lca_set, lca_set),
        ("left_birth_cone_region", left_nodes, frozenset(lca_set | left_front)),
        ("right_birth_cone_region", right_nodes, frozenset(lca_set | right_front)),
        ("left_frontier_region", left_front, left_front),
        ("right_frontier_region", right_front, right_front),
        ("sibling_pair_boundary_region", boundary_set, boundary_set),
        ("sibling_pair_bulk_region", pair_nodes, boundary_set),
    ]
    records: List[FiniteRegionRecord] = []
    for family, nodes, ports in data:
        env = pair_nodes - set(nodes)
        records.append(
            FiniteRegionRecord(
                region_key=f"{spec.region_id}::{family}",
                region_family=family,
                carrier_region_id=spec.region_id,
                node_set=frozenset(nodes),
                boundary_ports=frozenset(ports),
                environment_ports=frozenset(env),
                frontier_level=frontier,
                terminal_level=int(model.L),
                is_true_subregion=family != "sibling_pair_bulk_region",
            )
        )
    return records


def region_grammar_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for rec in finite_region_records(model, spec):
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "finite_region_key": rec.region_key,
                    "finite_region_family": rec.region_family,
                    "node_count": int(len(rec.node_set)),
                    "boundary_port_count": int(len(rec.boundary_ports)),
                    "environment_port_count": int(len(rec.environment_ports)),
                    "true_subregion": int(rec.is_true_subregion),
                    "node_ids": " ".join(map(str, sorted(rec.node_set))),
                    "boundary_ports": " ".join(map(str, sorted(rec.boundary_ports))),
                    "environment_ports": " ".join(map(str, sorted(rec.environment_ports))),
                    "boundary_sign_relation": "finite cut inside sibling-pair carrier; outside nodes counted as environment ports",
                    "grammar_computed_status": "finite_region_record_constructed" if rec.node_set else "empty_region_record",
                })
    return rows


def region_inclusion_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            records = finite_region_records(model, spec)
            for R in records:
                for S in records:
                    included = set(R.node_set).issubset(set(S.node_set))
                    strict = included and set(R.node_set) != set(S.node_set)
                    boundary_included = set(R.boundary_ports).issubset(set(S.node_set) | set(S.boundary_ports))
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        "carrier_region_id": spec.region_id,
                        "subregion": R.region_family,
                        "superregion": S.region_family,
                        "subregion_key": R.region_key,
                        "superregion_key": S.region_key,
                        "node_inclusion": int(included),
                        "strict_inclusion": int(strict),
                        "boundary_compatible": int(boundary_included),
                        "inclusion_computed_status": "finite_region_inclusion" if included and boundary_included else "not_included",
                    })
    return rows


def region_poset_summary(rows: List[dict]) -> List[dict]:
    grouped: Dict[Tuple[int, int, str, str], List[dict]] = {}
    for row in rows:
        key = (int(row["branching"]), int(row["level"]), str(row["mode"]), str(row["carrier_region_id"]))
        grouped.setdefault(key, []).append(row)
    out: List[dict] = []
    for (b, L, mode, rid), part in grouped.items():
        keys = sorted({r["subregion_key"] for r in part})
        lookup = {(r["subregion_key"], r["superregion_key"]): int(r["node_inclusion"]) for r in part}
        reflexive = all(lookup.get((k, k), 0) == 1 for k in keys)
        antisym = True
        trans = True
        for a in keys:
            for c in keys:
                if a != c and lookup.get((a, c), 0) and lookup.get((c, a), 0):
                    antisym = False
                for d in keys:
                    if lookup.get((a, c), 0) and lookup.get((c, d), 0) and not lookup.get((a, d), 0):
                        trans = False
        out.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "carrier_region_id": rid,
            "region_count": len(keys),
            "reflexive": int(reflexive),
            "antisymmetric": int(antisym),
            "transitive": int(trans),
            "poset_computed_status": "finite_region_poset_finite_object" if reflexive and antisym and trans else "finite_region_poset_failed",
        })
    return out


def region_net_report(summary_rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("poset_computed_status", "unknown")) for r in summary_rows})
    return "# Finite region-net grammar report\n\nConstructs explicit finite node-set regions inside each sibling-pair carrier and measurements the inclusion relation as a finite poset.  This is a grammar/definition condition, not yet an AQFT net property.\n\nObserved poset computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
