from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import region_size_meta
from .f1_f2_orientation_resolution import (
    _response,
    _js,
    _profile_gap,
    _oriented_distance,
    _meta_key_without_L,
    _meta_key_without_mode,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("parameter_dependence_control_family"),
        row.get("branching"),
        row.get("mode"),
        row.get("control_mode"),
        row.get("region_family"),
        row.get("genealogical_corridor_length"),
    )


def _score(js: float, gap: float) -> Tuple[float, float]:
    if not math.isfinite(js) or not math.isfinite(gap):
        return math.nan, math.nan
    return float(js + gap), float(math.sqrt(js * js + gap * gap))


def _row_for_control(
    *,
    control_family: str,
    b: int,
    L: int,
    mode: str,
    meta: dict,
    true_js: float,
    true_gap: float,
    true_additive: float,
    true_euclidean: float,
    control_js: float,
    control_gap: float,
    control_additive: float,
    control_euclidean: float,
    control_level: int,
    control_mode: str,
    tol: float,
) -> dict:
    score_tol = max(1.0e-8, 100.0 * float(tol))
    density_margin = float(control_js - true_js) if math.isfinite(control_js) and math.isfinite(true_js) else math.nan
    orientation_margin = float(control_gap - true_gap) if math.isfinite(control_gap) and math.isfinite(true_gap) else math.nan
    additive_margin = float(control_additive - true_additive) if math.isfinite(control_additive) and math.isfinite(true_additive) else math.nan
    euclidean_margin = float(control_euclidean - true_euclidean) if math.isfinite(control_euclidean) and math.isfinite(true_euclidean) else math.nan
    additive_preferred = int(math.isfinite(additive_margin) and additive_margin > score_tol)
    euclidean_preferred = int(math.isfinite(euclidean_margin) and euclidean_margin > score_tol)
    density_preferred = int(math.isfinite(density_margin) and density_margin > score_tol)
    orientation_preferred = int(math.isfinite(orientation_margin) and orientation_margin > score_tol)
    density_ambiguous = int(math.isfinite(density_margin) and abs(density_margin) <= score_tol)
    orientation_ambiguous = int(math.isfinite(orientation_margin) and abs(orientation_margin) <= score_tol)

    if additive_preferred and euclidean_preferred:
        computed_status = f"true_record_{control_family}_parameter_dependence_supported_finite_object"
    elif orientation_preferred and not additive_preferred:
        computed_status = f"{control_family}_orientation_parameter_dependence_hidden_by_density_component_control"
    elif density_preferred and not additive_preferred:
        computed_status = f"{control_family}_density_parameter_dependence_hidden_by_orientation_component_control"
    elif density_ambiguous and orientation_ambiguous:
        computed_status = f"{control_family}_control_component_degenerate_with_true_record_observed"
    elif math.isfinite(additive_margin) and additive_margin <= score_tol:
        computed_status = f"{control_family}_control_as_close_or_closer_than_true_record_observed"
    else:
        computed_status = f"{control_family}_parameter_dependence_unresolved_control"

    return {
        "parameter_dependence_surface": "history_measure_level_mode_dependence",
        "parameter_dependence_control_family": control_family,
        "branching": int(b),
        "level": int(L),
        "mode": str(mode),
        **meta,
        "control_level": int(control_level),
        "control_delta_level": int(control_level) - int(L) if int(control_level) >= 0 else 0,
        "control_mode": str(control_mode),
        "true_density_JS_component": true_js,
        "true_F1F2_profile_gap_component": true_gap,
        "true_measure_additive_fixed_formula": true_additive,
        "true_measure_euclidean_control_formula": true_euclidean,
        "control_density_JS_component": control_js,
        "control_F1F2_profile_gap_component": control_gap,
        "control_measure_additive_same_formula": control_additive,
        "control_measure_euclidean_same_formula": control_euclidean,
        "density_margin_control_minus_true": density_margin,
        "F1F2_profile_margin_control_minus_true": orientation_margin,
        "additive_margin_control_minus_true": additive_margin,
        "euclidean_margin_control_minus_true": euclidean_margin,
        "true_additive_preferred_over_control": additive_preferred,
        "true_euclidean_preferred_over_control": euclidean_preferred,
        "true_density_component_preferred_over_control": density_preferred,
        "true_F1F2_component_preferred_over_control": orientation_preferred,
        "density_component_ambiguous_with_control": density_ambiguous,
        "F1F2_component_ambiguous_with_control": orientation_ambiguous,
        "level_mode_parameter_dependence_score_tol": float(score_tol),
        "history_measure_level_mode_dependence_computed_status": computed_status,
    }


def history_measure_level_mode_dependence_rows(config: OperatorTestConfig) -> List[dict]:
    """Resolve the time-shift/mode-mismatch anti-tautology rank_bound.

    The fixed-measure surface showed that F1/F2 flips are decisively worse than the true record,
    while time-shifted and mode-mismatched records can sometimes be as good.
    This surface recomputes those controls with the *same* additive/euclidean
    formulas as the true fixed measure and decomposes the ambiguity into
    density/support JS versus F1/F2 skew-profile components.
    """
    records: List[dict] = []
    by_no_L: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    by_no_mode: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []

    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _response(model, spec, "live", tol=config.algebra_tol)
            record = _response(model, spec, "record", tol=config.algebra_tol)
            if not live.get("ok") or not record.get("ok"):
                rows.append({
                    "parameter_dependence_surface": "history_measure_level_mode_dependence",
                    "parameter_dependence_control_family": "unavailable",
                    "branching": int(b), "level": int(L), "mode": str(mode), **meta,
                    "history_measure_level_mode_dependence_computed_status": "level_mode_parameter_dependence_response_unavailable",
                    "level_mode_parameter_dependence_error": str(live.get("error") or record.get("error") or "unknown"),
                })
                continue
            rec = {"b": int(b), "L": int(L), "mode": str(mode), "meta": meta, "live": live, "record": record}
            records.append(rec)
            by_no_L[_meta_key_without_L(b, mode, meta)].append(rec)
            by_no_mode[_meta_key_without_mode(b, L, meta)].append(rec)

    for rec in records:
        b = rec["b"]; L = rec["L"]; mode = rec["mode"]; meta = rec["meta"]
        live = rec["live"]; record = rec["record"]
        tol = float(config.algebra_tol)
        true_js = _js(live["density"], record["density"], tol)
        true_gap = _profile_gap(live["profile"], record["profile"], tol)
        true_additive, true_euclidean = _score(true_js, true_gap)

        # Time controls: report every available level shift, not only the best one.
        time_finite_objects = [
            x for x in by_no_L[_meta_key_without_L(b, mode, meta)]
            if int(x["L"]) != int(L)
            and x["record"]["density"].shape == live["density"].shape
            and x["record"]["profile"].shape == live["profile"].shape
        ]
        for x in sorted(time_finite_objects, key=lambda z: (abs(int(z["L"]) - int(L)), int(z["L"]))):
            cjs = _js(live["density"], x["record"]["density"], tol)
            cgap = _profile_gap(live["profile"], x["record"]["profile"], tol)
            cadd, ceuc = _score(cjs, cgap)
            rows.append(_row_for_control(
                control_family="time_shifted_record",
                b=b, L=L, mode=mode, meta=meta,
                true_js=true_js, true_gap=true_gap, true_additive=true_additive, true_euclidean=true_euclidean,
                control_js=cjs, control_gap=cgap, control_additive=cadd, control_euclidean=ceuc,
                control_level=int(x["L"]), control_mode=str(mode), tol=tol,
            ))

        # Mode controls: report every other mode, not only the closest one.
        mode_finite_objects = [
            x for x in by_no_mode[_meta_key_without_mode(b, L, meta)]
            if str(x["mode"]) != str(mode)
            and x["record"]["density"].shape == live["density"].shape
            and x["record"]["profile"].shape == live["profile"].shape
        ]
        for x in sorted(mode_finite_objects, key=lambda z: str(z["mode"])):
            cjs = _js(live["density"], x["record"]["density"], tol)
            cgap = _profile_gap(live["profile"], x["record"]["profile"], tol)
            cadd, ceuc = _score(cjs, cgap)
            rows.append(_row_for_control(
                control_family="mode_mismatched_record",
                b=b, L=L, mode=mode, meta=meta,
                true_js=true_js, true_gap=true_gap, true_additive=true_additive, true_euclidean=true_euclidean,
                control_js=cjs, control_gap=cgap, control_additive=cadd, control_euclidean=ceuc,
                control_level=int(L), control_mode=str(x["mode"]), tol=tol,
            ))

    # Track trends over L within each control family/mode/geometry track.
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        tracks[_track_key(r)].append(r)
    for _k, xs in tracks.items():
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            try:
                by_l[int(r.get("level", -1))].append(r)
            except Exception:
                pass
        levels = sorted(k for k in by_l if k >= 0)
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            f = _median(r.get("additive_margin_control_minus_true") for r in by_l[first])
            l = _median(r.get("additive_margin_control_minus_true") for r in by_l[last])
            if math.isfinite(f) and math.isfinite(l) and l > f + max(1.0e-10, 1.0e-10 * max(1.0, abs(f))):
                trend = "true_parameter_dependence_margin_improves_with_level"
            elif math.isfinite(f) and math.isfinite(l) and l < f - max(1.0e-10, 1.0e-10 * max(1.0, abs(f))):
                trend = "true_parameter_dependence_margin_degrades_with_level"
            else:
                trend = "true_parameter_dependence_margin_level_stable_or_unresolved"
            meta = {
                "parameter_dependence_track_level_count": int(len(levels)),
                "parameter_dependence_margin_first_level": f,
                "parameter_dependence_margin_last_level": l,
                "parameter_dependence_margin_level_trend": trend,
            }
        else:
            meta = {"parameter_dependence_track_level_count": int(len(levels)), "parameter_dependence_margin_level_trend": "parameter_dependence_margin_level_trend_unavailable"}
        for r in xs:
            r.update(meta)
    return rows


def history_measure_level_mode_dependence_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("history_measure_level_mode_dependence_computed_status", "unknown")) for r in rows})
    total = len(rows)
    supported = sum(1 for r in rows if str(r.get("history_measure_level_mode_dependence_computed_status", "")).endswith("parameter_dependence_supported_finite_object"))
    close = sum(1 for r in rows if "as_close_or_closer" in str(r.get("history_measure_level_mode_dependence_computed_status", "")))
    return (
        "# Level/mode history parameter_dependence measurement\n\n"
        "This surface addresses the fixed-measure rank_bound: time-shifted and mode-mismatched records can be as good as the true record.  The measurement compares every available level/mode control using the same additive and Euclidean formulas as the fixed true measure, and decomposes each result into density JS and F1/F2 skew-profile components.\n\n"
        f"True-record parameter_dependence-supported rows: {supported}/{total}.\n\n"
        f"Controls as close or closer than true record: {close}/{total}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
