from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core.math_utils import *
from cnna.core.emptyset_growth import *
from cnna.core.projective_maps import *

def orthonormal_pair(x: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    x0 = x - np.mean(x)
    nx = float(np.linalg.norm(x0))
    if nx <= EPS:
        x0 = np.ones_like(x0)
        x0[0] -= len(x0)
        nx = float(np.linalg.norm(x0))
    e1 = x0 / max(nx, EPS)
    y0 = y - np.mean(y)
    y0 = y0 - float(e1 @ y0) * e1
    ny = float(np.linalg.norm(y0))
    if ny <= EPS:
        # deterministic fallback vector independent from e1
        z = np.arange(len(y0), dtype=float)
        z = z - np.mean(z)
        z = z - float(e1 @ z) * e1
        ny = float(np.linalg.norm(z))
        y0 = z
    e2 = y0 / max(ny, EPS)
    return e1, e2, abs(float(e1 @ e2))


def F1_F2_vectors(model: EmptySetGrowthModel) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    n = len(model.nodes)
    if model.L <= 0:
        F1 = np.zeros(n, dtype=float)
    else:
        F1 = np.array([node.level / float(model.L) for node in model.nodes], dtype=float)
    # Transversal birth-order path coordinate.  Sum centered sibling ranks with
    # decreasing depth weight.  This is the F2-like axis used as the birth-order contrast:
    # birth_order_rank, not an externally supplied geometric angle.
    F2 = np.zeros(n, dtype=float)
    labels = []
    for node in model.nodes:
        val = 0.0
        for depth, r in enumerate(node.address, start=1):
            centered = (r - (model.b - 1) / 2.0) / max(1.0, (model.b - 1) / 2.0)
            val += centered / float(depth)
        F2[node.nid] = val
        labels.append(".".join(map(str, node.address)))
    return F1, F2, labels


def orientation_measurement(model: EmptySetGrowthModel, state: str) -> dict:
    # Sparse/dictionary measurement: avoid dense n x n adjacency for L=6, b=4.
    if state == "record":
        edges = model.record_edges
    elif state == "sym":
        # Symmetric reference has no skew by construction.
        edges = model.live_edges
    else:
        edges = model.live_edges
    F1, F2, _ = F1_F2_vectors(model)
    e1, e2, dot = orthonormal_pair(F1, F2)

    directed_sq = 0.0
    for w in edges.values():
        directed_sq += float(w) * float(w)
    directed_norm = math.sqrt(directed_sq)

    pair_keys = set()
    for (i, j) in edges.keys():
        if i == j:
            continue
        pair_keys.add((min(i, j), max(i, j)))

    sym_sq = 0.0
    skew_sq = 0.0
    omega12 = 0.0
    for i, j in pair_keys:
        wij = float(edges.get((i, j), 0.0))
        wji = float(edges.get((j, i), 0.0))
        sij = 0.5 * (wij + wji)
        kij = 0.0 if state == "sym" else 0.5 * (wij - wji)
        # Matrix Frobenius has both off-diagonal entries.
        sym_sq += 2.0 * sij * sij
        skew_sq += 2.0 * kij * kij
        # K_ij=kij, K_ji=-kij.
        omega12 += e1[i] * kij * e2[j] + e1[j] * (-kij) * e2[i]
    symmetric_norm = math.sqrt(sym_sq)
    skew_norm = math.sqrt(skew_sq)
    plane_circ = 2.0 * float(omega12)
    sym_skew_norm = 0.0
    return {
        "state": state,
        "F1_label": "root_front_prefix_depth",
        "F2_label": "birth_order_rank_path_coordinate",
        "F1_F2_orthogonality_abs_dot_after_GS": dot,
        "directed_norm_fro": directed_norm,
        "symmetric_norm_fro": symmetric_norm,
        "skew_norm_fro": skew_norm,
        "relative_skew_norm": skew_norm / max(directed_norm, EPS),
        "F1F2_omega": float(omega12),
        "F1F2_plane_circulation": plane_circ,
        "sym_reference_skew_norm": sym_skew_norm,
        "skew_nonzero": int(skew_norm > 1e-10),
        "F1F2_orientation_nonzero": int(abs(plane_circ) > 1e-10),
        "condition_note": "signed_current_separate_from_positive_carrier_measure",
    }
