from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(pairs) < 2:
        return math.nan
    mx = sum(x for x, _ in pairs) / float(len(pairs))
    my = sum(y for _, y in pairs) / float(len(pairs))
    dx = [x - mx for x, _ in pairs]
    dy = [y - my for _, y in pairs]
    den = math.sqrt(sum(x * x for x in dx) * sum(y * y for y in dy))
    return float(sum(x * y for x, y in zip(dx, dy)) / den) if den > 0.0 else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("mode"), row.get("region_family"), row.get("genealogical_corridor_length"))


def _same_direction(a: float, b: float, tol: float) -> int:
    return int(math.isfinite(a) and math.isfinite(b) and a * b > max(tol, tol * max(1.0, abs(a), abs(b))))


def decomposed_entropy_flow_rows(component_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Decompose the finite entropy-flow derived_quantity into density/signature/strength channels."""
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in component_rows:
        tracks[_track_key(r)].append(r)
    rows: List[dict] = []
    for key, xs in sorted(tracks.items(), key=lambda kv: str(kv[0])):
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            try:
                L = int(r.get("level", -1))
            except Exception:
                L = -1
            if L >= 0:
                by_l[L].append(r)
        levels = sorted(by_l)
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            def med(col: str, L: int) -> float:
                return _median(_finite(r.get(col)) for r in by_l[L])
            d_density = med("density_support_component_JS_live_record", last) - med("density_support_component_JS_live_record", first)
            d_signature = med("normalized_F1F2_signature_component", last) - med("normalized_F1F2_signature_component", first)
            d_strength = med("F1F2_response_strength_component", last) - med("F1F2_response_strength_component", first)
            d_total = med("decomposed_history_measure_additive_total", last) - med("decomposed_history_measure_additive_total", first)
            d_b = med("backreaction_current_norm", last) - med("backreaction_current_norm", first)
            d_mod = med("modular_spread_live", last) - med("modular_spread_live", first)
            same_density_b = _same_direction(d_density, d_b, tol)
            same_signature_b = _same_direction(d_signature, d_b, tol)
            same_strength_b = _same_direction(d_strength, d_b, tol)
            same_strength_mod = _same_direction(d_strength, d_mod, tol)
            same_signature_mod = _same_direction(d_signature, d_mod, tol)
            if same_signature_b and same_signature_mod and abs(d_signature) >= abs(d_strength):
                computed_status = "entropy_flow_carried_by_orientation_signature_finite_object"
            elif same_strength_b and same_strength_mod:
                computed_status = "entropy_flow_carried_by_response_strength_weighting_control"
            elif same_signature_b or same_strength_b:
                computed_status = "entropy_flow_partially_aligned_with_F1F2_components_control"
            elif _same_direction(d_density, d_b, tol):
                computed_status = "entropy_flow_density_support_alignment_control"
            else:
                computed_status = "entropy_flow_decomposition_unresolved_or_obstructed"
        else:
            first = last = -1
            d_density = d_signature = d_strength = d_total = d_b = d_mod = math.nan
            same_density_b = same_signature_b = same_strength_b = same_strength_mod = same_signature_mod = 0
            computed_status = "entropy_flow_decomposition_insufficient_level_track"
        density_vals = [_finite(r.get("density_support_component_JS_live_record")) for r in xs]
        sig_vals = [_finite(r.get("normalized_F1F2_signature_component")) for r in xs]
        strength_vals = [_finite(r.get("F1F2_response_strength_component")) for r in xs]
        b_vals = [_finite(r.get("backreaction_current_norm")) for r in xs]
        mod_vals = [_finite(r.get("modular_spread_live")) for r in xs]
        rows.append({
            "branching": key[0],
            "mode": key[1],
            "region_family": key[2],
            "genealogical_corridor_length": key[3],
            "entropy_flow_surface": "density_signature_strength_decomposed_B_modular_level_track",
            "track_level_count": int(len(levels)),
            "first_level": int(first),
            "last_level": int(last),
            "delta_density_support_component": d_density,
            "delta_normalized_F1F2_signature_component": d_signature,
            "delta_F1F2_response_strength_component": d_strength,
            "delta_decomposed_history_measure_total": d_total,
            "delta_backreaction_current_norm": d_b,
            "delta_modular_spread_live": d_mod,
            "density_component_and_B_same_level_direction": same_density_b,
            "signature_component_and_B_same_level_direction": same_signature_b,
            "strength_component_and_B_same_level_direction": same_strength_b,
            "signature_component_and_modular_spread_same_level_direction": same_signature_mod,
            "strength_component_and_modular_spread_same_level_direction": same_strength_mod,
            "corr_density_component_vs_B_norm": _pearson(density_vals, b_vals),
            "corr_signature_component_vs_B_norm": _pearson(sig_vals, b_vals),
            "corr_strength_component_vs_B_norm": _pearson(strength_vals, b_vals),
            "corr_density_component_vs_modular_spread": _pearson(density_vals, mod_vals),
            "corr_signature_component_vs_modular_spread": _pearson(sig_vals, mod_vals),
            "corr_strength_component_vs_modular_spread": _pearson(strength_vals, mod_vals),
            "decomposed_entropy_flow_computed_status": computed_status,
        })
    return rows


def decomposed_entropy_flow_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("decomposed_entropy_flow_computed_status", "unknown")) for r in rows})
    return (
        "# Decomposed entropy-flow derived_quantity rows\n\n"
        "This surface asks whether level-direction and modular/backreaction alignment are carried by density/support distance, normalized F1/F2 orientation signature, or F1/F2 response strength.  It is a finite trajectory derived_quantity, not an analytic modular-flow property.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
