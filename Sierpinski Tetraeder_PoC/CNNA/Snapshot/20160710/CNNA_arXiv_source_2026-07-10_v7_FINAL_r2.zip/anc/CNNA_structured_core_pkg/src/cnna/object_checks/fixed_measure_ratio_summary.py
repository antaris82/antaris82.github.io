from __future__ import annotations

import math
from collections import defaultdict
from typing import Iterable, List


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def fixed_measure_ratio_summary_rows(fixed_rows: List[dict], destroyed_geometry_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    # Summary 1: measure freeze / dominance.
    rows.append({
        "summary_surface": "fixed_measure_definition",
        "row_count": len(fixed_rows),
        "measure_definition_fixed_before_geometry_tests_count": sum(1 for r in fixed_rows if int(r.get("measure_definition_fixed_before_geometry_tests", 0) or 0) == 1),
        "measure_weight_fit_to_geometry_count": sum(1 for r in fixed_rows if int(r.get("measure_weight_fit_to_geometry", 0) or 0) != 0),
        "median_fixed_measure_additive": _median(r.get("fixed_measure_additive_reference") for r in fixed_rows),
        "median_density_fraction": _median(r.get("density_component_fraction_of_additive") for r in fixed_rows),
        "median_F1F2_fraction": _median(r.get("F1F2_component_fraction_of_additive") for r in fixed_rows),
        "summary_computed_status": "fixed_measure_no_fit_validated" if fixed_rows and all(int(r.get("measure_definition_fixed_before_geometry_tests", 0) or 0) == 1 for r in fixed_rows) else "fixed_measure_definition_unresolved",
    })
    # Summary 2+: geometry/control groups.
    groups = defaultdict(list)
    for r in destroyed_geometry_rows:
        groups[(r.get("geometry_surface"), r.get("destroyed_history_control"))].append(r)
    for (surface, control), xs in sorted(groups.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]))):
        total = len(xs)
        finite_object = sum(1 for r in xs if str(r.get("destroyed_history_oriented_geometry_computed_status", "")) == "true_record_tighter_fixed_measure_contains_geometry_finite_object")
        obs = sum(1 for r in xs if str(r.get("destroyed_history_oriented_geometry_computed_status", "")) == "destroyed_history_control_as_good_or_tighter_observed")
        ratio = float(finite_object / total) if total else math.nan
        if total and ratio >= 0.75:
            computed_status = "true_fixed_measure_parameter_dependence_supported_for_geometry_control"
        elif total and finite_object > obs:
            computed_status = "true_fixed_measure_parameter_dependence_partial_control"
        elif total and obs >= finite_object:
            computed_status = "destroyed_history_parameter_dependence_rank_bound_observed"
        else:
            computed_status = "geometry_parameter_dependence_unavailable"
        rows.append({
            "summary_surface": "destroyed_history_geometry_parameter_dependence",
            "geometry_surface": surface,
            "destroyed_history_control": control,
            "row_count": total,
            "true_record_tighter_contains_count": finite_object,
            "destroyed_control_as_good_or_tighter_count": obs,
            "true_parameter_dependence_fraction": ratio,
            "median_true_geometry_ratio": _median(r.get("geometry_ratio_true_fixed_measure") for r in xs),
            "median_destroyed_geometry_ratio": _median(r.get("geometry_ratio_destroyed_history_measure") for r in xs),
            "median_measure_margin_destroyed_minus_true": _median(r.get("measure_margin_destroyed_minus_true") for r in xs),
            "summary_computed_status": computed_status,
        })
    return rows


def fixed_measure_ratio_summary_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("summary_computed_status", "unknown")) for r in rows})
    return (
        "# Fixed measure / destroyed-history ratio summary\n\n"
        "This summary reports whether the fixed two-component measure is genuinely history-specific, rather than merely a large norm that contains every geometry residual.\n\n"
        f"Summary rows: {len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
