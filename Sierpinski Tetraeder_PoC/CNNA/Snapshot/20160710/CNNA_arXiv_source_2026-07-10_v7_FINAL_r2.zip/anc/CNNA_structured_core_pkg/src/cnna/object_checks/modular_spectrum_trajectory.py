from __future__ import annotations

import math
from typing import Dict, List, Tuple

from cnna.core.algebra_support import (
    finite_tomita_star_metrics,
    local_operator_algebras,
    operator_scale_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


def _parse_floats(xs: str) -> List[float]:
    out: List[float] = []
    for x in str(xs or "").split():
        try:
            out.append(float(x))
        except ValueError:
            pass
    return out


def _lambda_hint(ratios: List[float]) -> Tuple[str, float]:
    if not ratios:
        return "modular_ratio_unavailable", math.nan
    rmin = min(ratios)
    rmax = max(ratios)
    if rmax <= 0.0 or not math.isfinite(rmin) or not math.isfinite(rmax):
        return "modular_ratio_unavailable", math.nan
    spread = rmax / max(rmin, 1.0e-300)
    if spread <= 1.0 + 1.0e-6:
        return "single_ratio_lambda_finite_object", float(rmin)
    if spread <= 10.0:
        return "finite_ratio_band_finite_object", float(math.sqrt(rmin * rmax))
    return "broad_ratio_cloud_finite_object", float(math.sqrt(rmin * rmax))


def modular_spectrum_trajectory_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for sign_relation in config.tomita_matrix_sign_relations:
                for state in config.states:
                    resp = regional_response(model, spec, state, matrix_sign_relation=sign_relation)
                    if resp is None:
                        rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "matrix_sign_relation": sign_relation, "modular_trajectory_computed_status": "response_unavailable"})
                        continue
                    algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    global_alg = algebras["full_regional_response"]
                    scale = operator_scale_metadata(resp, tol=config.rank_tol)
                    metrics = finite_tomita_star_metrics(
                        global_alg,
                        resp.density,
                        config.rank_tol,
                        orientation_operator=resp.skew_role,
                        orientation_carrier_norm=scale.get("symmetric_carrier_norm"),
                    )
                    ratios = _parse_floats(str(metrics.get("modular_spectrum_adjacent_ratios", "")))
                    hint, lam = _lambda_hint(ratios)
                    spread = float(metrics.get("modular_spectrum_spread", math.nan))
                    nontrivial = int(metrics.get("modular_spectrum_nontrivial", 0))
                    computed_status = "modular_spectrum_nontrivial_limes_derived_quantity" if nontrivial else "modular_spectrum_tracial_or_unavailable_control"
                    if str(resp.density_metadata.get("density_computed_status", "")) == "singular_support_state":
                        computed_status = "singular_support_modular_spectrum_limes_derived_quantity"
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        "matrix_sign_relation": sign_relation,
                        **resp.density_metadata,
                        "global_operator_system": "full_regional_response",
                        "global_algebra_dim": len(global_alg.basis),
                        "tomita_support_dim": int(metrics.get("tomita_support_dim", 0)),
                        "modular_operator_min_eigenvalue": metrics.get("modular_operator_min_eigenvalue", math.nan),
                        "modular_operator_max_eigenvalue": metrics.get("modular_operator_max_eigenvalue", math.nan),
                        "modular_spectrum_spread": spread,
                        "modular_spectrum_log_span": metrics.get("modular_spectrum_log_span", math.nan),
                        "modular_spectrum_nontrivial": nontrivial,
                        "modular_spectrum_positive_eigenvalues": metrics.get("modular_spectrum_positive_eigenvalues", ""),
                        "modular_spectrum_adjacent_ratios": metrics.get("modular_spectrum_adjacent_ratios", ""),
                        "modular_spectrum_ratio_count": metrics.get("modular_spectrum_ratio_count", 0),
                        "modular_spectrum_adjacent_ratio_min": metrics.get("modular_spectrum_adjacent_ratio_min", math.nan),
                        "modular_spectrum_adjacent_ratio_max": metrics.get("modular_spectrum_adjacent_ratio_max", math.nan),
                        "finite_powers_lambda_hint": hint,
                        "finite_powers_lambda_proxy": lam,
                        "modular_trajectory_computed_status": computed_status,
                    })
    # Add coarse per-track level trend flags without fitting statements.
    tracks: Dict[Tuple, List[int]] = {}
    for i, r in enumerate(rows):
        key = (r.get("branching"), r.get("mode"), r.get("state"), r.get("matrix_sign_relation"), r.get("region_id"))
        tracks.setdefault(key, []).append(i)
    for idxs in tracks.values():
        idxs.sort(key=lambda i: int(rows[i].get("level", -1)))
        spreads = [float(rows[i].get("modular_spectrum_spread", math.nan)) for i in idxs]
        finite = [x for x in spreads if math.isfinite(x)]
        trend = "insufficient_level_trajectory"
        if len(finite) >= 2:
            if finite[-1] > finite[0]:
                trend = "spread_increases_over_available_levels"
            elif finite[-1] < finite[0]:
                trend = "spread_decreases_over_available_levels"
            else:
                trend = "spread_constant_over_available_levels"
        for i in idxs:
            rows[i]["modular_spread_level_trajectory"] = trend
            rows[i]["modular_trajectory_level_count"] = len(finite)
    return rows


def modular_spectrum_trajectory_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("modular_trajectory_computed_status", "unknown")) for r in rows})
    trends = sorted({str(r.get("modular_spread_level_trajectory", "unknown")) for r in rows})
    return "# Modular-spectrum trajectory report\n\nTracks finite Tomita modular spectra over L and records adjacent eigenvalue ratios as a Powers/Araki-Woods style limes derived_quantity.  A nontrivial or growing finite modular spread is not a Type-III property; it only identifies the finite data needed for an eventual inductive/GNS-limes construction.\n\nObserved trends: `" + "`, `".join(trends) + "`.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
