from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"), row.get("region_id"), row.get("genealogical_corridor_length"))


def _idx(rows: List[dict], field: str) -> Dict[Tuple[object, ...], dict]:
    return {_key(r): r for r in rows if field in r}


def _ratio(raw: float, measure: float) -> float:
    return float(raw / max(measure, 1.0e-300)) if math.isfinite(raw) and math.isfinite(measure) and measure > 0.0 else math.nan


def _control_measures(f1: dict, fixed: dict) -> List[Tuple[str, float]]:
    # True additive scale is separate.  Destroyed controls are represented by
    # their oriented density+profile distance when available.  This intentionally
    # avoids refitting additive weights per control.
    out = [
        ("uniform_node_reference", _finite(f1.get("F1F2_oriented_distance_live_uniform_multishell"))),
        ("F2_flipped_record", _finite(f1.get("F1F2_oriented_distance_live_F2_flipped_record_multishell"))),
        ("F1_flipped_record", _finite(f1.get("F1F2_oriented_distance_live_F1_flipped_record_multishell"))),
        ("F2_shell_reversed_record", _finite(f1.get("F1F2_oriented_distance_live_F2_shell_reversed_record_multishell"))),
        ("F1_shell_reversed_record", _finite(f1.get("F1F2_oriented_distance_live_F1_shell_reversed_record_multishell"))),
        ("time_shifted_record_best_available", _finite(f1.get("F1F2_oriented_distance_live_time_shifted_record_best_available"))),
        ("mode_mismatched_record_best_available", _finite(f1.get("F1F2_oriented_distance_live_mode_mismatched_record_best_available"))),
    ]
    return [(name, val) for name, val in out if math.isfinite(val) and val > 0.0]


def destroyed_history_oriented_geometry_rows(
    fixed_measure_rows: List[dict],
    f1f2_orientation_rows: List[dict],
    oriented_geometry_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Run the same geometry residuals against true and destroyed-history scales.

    The 12 row computed_status `within oriented scale` can be too weak if a much
    larger destroyed-history norm would also contain every residual.  this module keeps
    the true fixed measure separate and reports whether it remains the tighter
    history-specific scale while still containing the geometry rank_bound.
    """
    midx = _idx(fixed_measure_rows, "fixed_measure_additive_reference")
    fidx = _idx(f1f2_orientation_rows, "F1F2_orientation_resolution_computed_status")
    rows: List[dict] = []
    for g in oriented_geometry_rows:
        key = _key(g)
        m = midx.get(key, {})
        f = fidx.get(key, {})
        raw = _finite(g.get("geometry_raw_rank_bound"))
        true_measure = _finite(m.get("fixed_measure_additive_reference"))
        true_ratio = _ratio(raw, true_measure)
        for cname, cmeasure in _control_measures(f, m):
            cratio = _ratio(raw, cmeasure)
            tighter = int(math.isfinite(true_measure) and math.isfinite(cmeasure) and true_measure < cmeasure - max(1.0e-8, 100.0 * tol))
            contained = int(math.isfinite(true_ratio) and true_ratio < 10.0)
            c_contained = int(math.isfinite(cratio) and cratio < 10.0)
            if not math.isfinite(true_measure):
                computed_status = "destroyed_history_geometry_true_measure_unavailable"
            elif tighter and contained:
                computed_status = "true_record_tighter_fixed_measure_contains_geometry_finite_object"
            elif contained and c_contained and not tighter:
                computed_status = "destroyed_history_control_as_good_or_tighter_observed"
            elif not contained:
                computed_status = "true_record_fixed_measure_does_not_contain_geometry_observed"
            else:
                computed_status = "destroyed_history_geometry_unresolved_control"
            rows.append({
                "geometry_surface": g.get("geometry_surface"),
                "branching": g.get("branching"), "level": g.get("level"), "mode": g.get("mode"),
                "region_id": g.get("region_id"), "region_family": g.get("region_family"),
                "genealogical_corridor_length": g.get("genealogical_corridor_length"),
                "geometry_layer": g.get("geometry_layer"),
                "destroyed_history_control": cname,
                "geometry_raw_rank_bound": raw,
                "true_fixed_measure_additive": true_measure,
                "destroyed_history_oriented_measure": cmeasure,
                "geometry_ratio_true_fixed_measure": true_ratio,
                "geometry_ratio_destroyed_history_measure": cratio,
                "true_measure_tighter_than_destroyed_control": tighter,
                "true_measure_contains_geometry_ratio_lt_10": contained,
                "destroyed_measure_contains_geometry_ratio_lt_10": c_contained,
                "ratio_margin_destroyed_minus_true": float(cratio - true_ratio) if math.isfinite(cratio) and math.isfinite(true_ratio) else math.nan,
                "measure_margin_destroyed_minus_true": float(cmeasure - true_measure) if math.isfinite(cmeasure) and math.isfinite(true_measure) else math.nan,
                "source_oriented_history_geometry_row_computed_status": g.get("oriented_history_geometry_row_computed_status"),
                "destroyed_history_oriented_geometry_computed_status": computed_status,
            })
    # Track summary over L for each geometry/control/layer track.
    tracks = defaultdict(list)
    for r in rows:
        tracks[(r.get("geometry_surface"), r.get("destroyed_history_control"), r.get("branching"), r.get("mode"), r.get("geometry_layer"))].append(r)
    for _k, xs in tracks.items():
        by_l = defaultdict(list)
        for r in xs:
            try:
                by_l[int(r.get("level", -1))].append(r)
            except Exception:
                pass
        levels = sorted(k for k in by_l if k >= 0)
        if len(levels) >= 2:
            fL, lL = levels[0], levels[-1]
            f = _median(r.get("geometry_ratio_true_fixed_measure") for r in by_l[fL])
            l = _median(r.get("geometry_ratio_true_fixed_measure") for r in by_l[lL])
            if math.isfinite(f) and math.isfinite(l) and l < f - max(tol, tol * max(1.0, abs(f))):
                trend = "true_geometry_ratio_decreases_with_level_finite_object"
            elif math.isfinite(f) and math.isfinite(l) and l > f + max(tol, tol * max(1.0, abs(f))):
                trend = "true_geometry_ratio_increases_with_level_observed"
            else:
                trend = "true_geometry_ratio_level_stable_or_unresolved"
            meta = {"geometry_ratio_level_track_count": len(levels), "geometry_ratio_first_level": fL, "geometry_ratio_last_level": lL, "geometry_ratio_first_level_median": f, "geometry_ratio_last_level_median": l, "geometry_ratio_level_trend": trend}
        else:
            meta = {"geometry_ratio_level_track_count": len(levels), "geometry_ratio_level_trend": "geometry_ratio_level_trend_unavailable"}
        for r in xs:
            r.update(meta)
    return rows


def destroyed_history_oriented_geometry_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("destroyed_history_oriented_geometry_computed_status", "unknown")) for r in rows})
    cand = sum(1 for r in rows if str(r.get("destroyed_history_oriented_geometry_computed_status", "")) == "true_record_tighter_fixed_measure_contains_geometry_finite_object")
    obs = sum(1 for r in rows if str(r.get("destroyed_history_oriented_geometry_computed_status", "")) == "destroyed_history_control_as_good_or_tighter_observed")
    return (
        "# Destroyed-history oriented geometry consistency_check\n\n"
        "This surface sends locality/split/complement residuals through the same ratio conditions for the true fixed HistoryMeasure2 and deterministic destroyed-history controls.  A positive row means the true record remains the tighter history-specific scale while still containing the geometry rank_bound.\n\n"
        f"True-record tighter-and-containing finite_objects: {cand}/{len(rows)}.\n\n"
        f"Destroyed controls as good or tighter: {obs}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
