from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

from cnna.config import REFERENCE_MODE


def _to_int(x, default: int = 0) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def _to_float(x, default: float = math.nan) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def read_csv_rows(path: Path) -> List[dict]:
    with Path(path).open(newline="", encoding="utf-8") as f:
        return [dict(r) for r in csv.DictReader(f)]


def _mode_branching_key(row: dict) -> Tuple[int, str]:
    return (_to_int(row.get("branching")), str(row.get("mode", "")))


def deduplicate_mode_branching_rows(rows: Sequence[dict]) -> List[dict]:
    """Keep one row per (branching, mode), preferring larger region_count.

    This supports combining chunked local runs.  If the same b/mode appears in
    several files, the row with more regions is the stronger measurement.  Ties keep
    the latest encountered row so users can intentionally override older runs.
    """
    best: Dict[Tuple[int, str], dict] = {}
    for r in rows:
        key = _mode_branching_key(r)
        if key[0] <= 0 or not key[1]:
            continue
        old = best.get(key)
        if old is None:
            best[key] = dict(r)
            continue
        old_regions = _to_int(old.get("region_count"), 0)
        new_regions = _to_int(r.get("region_count"), 0)
        if new_regions >= old_regions:
            best[key] = dict(r)
    return [best[k] for k in sorted(best)]


def branching_shift_curve_rows(mode_branching_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    for r in deduplicate_mode_branching_rows(mode_branching_rows):
        b = _to_int(r.get("branching"))
        mode = str(r.get("mode", ""))
        linear_zero = _to_float(r.get("linear_zero_crossing_age_median"))
        nearest_zero = _to_float(r.get("nearest_zero_age_median"))
        first_nonneg = _to_float(r.get("first_nonnegative_age_median"))
        finite_object_count = _to_int(r.get("finite_object_region_count"), 0)
        region_count = _to_int(r.get("region_count"), 0)
        curve_finite_object = int(region_count > 0 and finite_object_count == region_count and math.isfinite(linear_zero))
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "region_count": region_count,
            "finite_object_region_count": finite_object_count,
            "first_nonnegative_age_median": first_nonneg,
            "nearest_zero_age_median": nearest_zero,
            "linear_zero_crossing_age_median": linear_zero,
            "zero_age_minus_three": linear_zero - 3.0 if math.isfinite(linear_zero) else math.nan,
            "curve_finite_object": curve_finite_object,
            "source_computed_status": r.get("computed_status", ""),
            "computed_status": "branching_zero_crossing_branching_shift_curve_row" if curve_finite_object else "branching_zero_crossing_branching_shift_curve_row_not_residual_le_tolerance",
            "condition_note": "each row summarizes a birth-relative full-terminal law fit; compare modes only when all requested b/mode rows are present",
        })
    return rows


def _linear_fit_slope(xs: List[float], ys: List[float]) -> float:
    if len(xs) < 2:
        return math.nan
    try:
        coeff = np.polyfit(np.asarray(xs, dtype=float), np.asarray(ys, dtype=float), 1)
        return float(coeff[0])
    except Exception:
        return math.nan


def branching_shift_summary_rows(curve_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    modes = sorted({str(r.get("mode", "")) for r in curve_rows if str(r.get("mode", ""))})
    for mode in modes:
        group = sorted([r for r in curve_rows if str(r.get("mode", "")) == mode], key=lambda r: _to_int(r.get("branching")))
        finite_objects = [r for r in group if _to_int(r.get("curve_finite_object"), 0) == 1]
        bs = [_to_int(r.get("branching")) for r in finite_objects]
        zs = [_to_float(r.get("linear_zero_crossing_age_median")) for r in finite_objects]
        firsts = [_to_float(r.get("first_nonnegative_age_median")) for r in finite_objects]
        nearest = [_to_float(r.get("nearest_zero_age_median")) for r in finite_objects]
        monotone_nonincreasing = int(len(zs) >= 2 and all(zs[i+1] <= zs[i] + 1e-12 for i in range(len(zs)-1)))
        nearest_three_all = int(bool(nearest) and all(abs(x - 3.0) <= 1e-12 for x in nearest if math.isfinite(x)))
        first_mode_stable = int(bool(firsts) and max(firsts) - min(firsts) <= 1e-12) if len(firsts) >= 2 else 0
        slope = _linear_fit_slope([float(x) for x in bs], zs)
        unmet_conditions: List[str] = []
        if not finite_objects:
            unmet_conditions.append("no_finite_object_rows")
        if len(finite_objects) < 2:
            unmet_conditions.append("fewer_than_two_branching_values")
        if not nearest_three_all:
            unmet_conditions.append("nearest_zero_age_not_exactly_three_for_all_finite_objects")
        if not monotone_nonincreasing:
            unmet_conditions.append("linear_zero_crossing_not_monotone_nonincreasing_with_branching")
        computed_status = "branching_zero_crossing_branching_shift_curve_finite_object" if not unmet_conditions else "branching_zero_crossing_branching_shift_curve_residual_gt_tolerance"
        rows.append({
            "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "branching_values": " ".join(str(b) for b in bs) if bs else "none",
            "finite_object_branching_count": len(finite_objects),
            "linear_zero_crossing_age_values": " ".join(f"{z:.12g}" for z in zs) if zs else "none",
            "linear_zero_crossing_age_min": min(zs) if zs else math.nan,
            "linear_zero_crossing_age_median": float(np.median(zs)) if zs else math.nan,
            "linear_zero_crossing_age_max": max(zs) if zs else math.nan,
            "linear_zero_crossing_age_range": (max(zs) - min(zs)) if len(zs) >= 2 else 0.0,
            "linear_zero_crossing_slope_per_branching": slope,
            "nearest_zero_age_all_three": nearest_three_all,
            "first_nonnegative_age_mode_stable": first_mode_stable,
            "linear_zero_crossing_monotone_earlier_with_larger_b": monotone_nonincreasing,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "branching-shift curve is a finite L4-L6 full-terminal birth-relative fit; it is not an asymptotic property",
        })
    return rows


def write_branching_zero_crossing_shift_report(outdir: Path, curve_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference = next((r for r in summary_rows if _to_int(r.get("reference_model"), 0) == 1), summary_rows[0] if summary_rows else {})
    lines = [
        "# Branching-shift measurement for birth-relative backreaction current",
        "",
        "## Purpose",
        "",
        "The branching-shift surface extends the birth-relative law by treating the weak b-dependence of the birth-relative zero crossing as its own finite measurement.",
        "The physical object remains:",
        "",
        "```text",
        "B_L = A_live,L - A_record,L",
        "age = frontier_level - birth_level(region)",
        "```",
        "",
        "`sym` is still only the symmetric-tree control path; it is not used to define physical backreaction.",
        "",
        "## Reference summary",
        "",
        "```text",
        f"mode = {reference.get('mode', 'missing')}",
        f"computed_status = {reference.get('computed_status', 'missing')}",
        f"unmet_conditions = {reference.get('unmet_conditions', 'missing')}",
        f"branching_values = {reference.get('branching_values', 'missing')}",
        f"linear_zero_crossing_age_values = {reference.get('linear_zero_crossing_age_values', 'missing')}",
        f"linear_zero_crossing_age_range = {reference.get('linear_zero_crossing_age_range', 'missing')}",
        f"linear_zero_crossing_slope_per_branching = {reference.get('linear_zero_crossing_slope_per_branching', 'missing')}",
        f"nearest_zero_age_all_three = {reference.get('nearest_zero_age_all_three', 'missing')}",
        f"first_nonnegative_age_mode_stable = {reference.get('first_nonnegative_age_mode_stable', 'missing')}",
        "```",
        "",
        "## Curve rows",
        "",
        "```text",
    ]
    for r in sorted(curve_rows, key=lambda x: (str(x.get("mode", "")), _to_int(x.get("branching")))):
        lines.append(
            f"b={r.get('branching')} mode={r.get('mode')} regions={r.get('finite_object_region_count')}/{r.get('region_count')} "
            f"nearest_zero_age={r.get('nearest_zero_age_median')} "
            f"first_nonnegative_age={r.get('first_nonnegative_age_median')} "
            f"linear_zero_age={r.get('linear_zero_crossing_age_median')} "
            f"zero_age_minus_three={r.get('zero_age_minus_three')} computed_status={r.get('computed_status')}"
        )
    lines.extend([
        "```",
        "",
        "## Interpretation",
        "",
        "A stable nearest-zero age at 3 means the discrete age-3 row remains the closest measured row to the live-record sign change.",
        "The interpolated zero crossing measures the sub-age shift: values below 3 mean live catches record before age 3; values above 3 mean the crossing occurs between ages 3 and 4.",
        "The first-nonnegative age is deliberately kept separate because it is a discrete measurement and can jump even when the interpolated crossing shifts smoothly.",
        "",
        "## Conditions",
        "",
        "- Only birth-relative finite_object rows should be used for the curve.",
        "- L7/L8 coarse-frontier coverage rows are not law-fit points.",
        "- b=5/6 full-terminal L=6 requires larger boundary/interior condition_notes than the birth-relative default.",
        "- This is a finite directed-DtN backreaction-current measurement, not a vN/KMS/Type-III statement.",
    ])
    (outdir / "4C_BRANCHING_SHIFT_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
