from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(pairs) < 2:
        return math.nan
    mx = sum(x for x, _ in pairs) / float(len(pairs))
    my = sum(y for _, y in pairs) / float(len(pairs))
    dx = [x - mx for x, _ in pairs]
    dy = [y - my for _, y in pairs]
    den = math.sqrt(sum(x * x for x in dx) * sum(y * y for y in dy))
    return float(sum(x * y for x, y in zip(dx, dy)) / den) if den > 0.0 else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("region_id"),
        row.get("genealogical_corridor_length"),
    )


def _track_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("mode"),
        row.get("region_family"),
        row.get("genealogical_corridor_length"),
    )


def _history_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {
        _key(r): r
        for r in history_rows
        if r.get("measure_surface") == "history_live_measure_finite_object"
    }


def _mode_ablation_true_index(mode_ablation_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    """One true live-record component row per geometry key.

    `mode_ablation_signature.csv` has one row per control mode.  The true
    density/signature/strength components are mode_stable within that control set;
    use the first deterministic row per key.
    """
    out: Dict[Tuple[object, ...], dict] = {}
    for r in mode_ablation_rows:
        if r.get("mode_ablation_surface") != "F1F2_mode_mode_stable_signature_vs_mode_sensitive_strength":
            continue
        k = _key(r)
        if k not in out:
            out[k] = r
    return out


def _f1f2_index(f1f2_orientation_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {
        _key(r): r
        for r in f1f2_orientation_rows
        if "F1F2_orientation_resolution_computed_status" in r
    }


def _dominance(density: float, signature: float, strength: float, tol: float) -> str:
    vals = {
        "density_support_component": density,
        "normalized_F1F2_signature_component": signature,
        "F1F2_response_strength_component": strength,
    }
    finite = {k: v for k, v in vals.items() if math.isfinite(v)}
    if not finite:
        return "component_dominance_unavailable"
    ordered = sorted(finite.items(), key=lambda kv: kv[1], reverse=True)
    if ordered[0][1] <= max(tol, tol * max(1.0, abs(ordered[0][1]))):
        return "all_components_vacuous_or_zero_control"
    if len(ordered) >= 2 and ordered[0][1] <= ordered[1][1] + max(tol, tol * max(1.0, abs(ordered[1][1]))):
        return "mixed_component_dominance_control"
    return ordered[0][0]


def _augment_tracks(rows: List[dict], tol: float) -> None:
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        tracks[_track_key(r)].append(r)
    for _t, xs in tracks.items():
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            try:
                L = int(r.get("level", -1))
            except Exception:
                L = -1
            if L >= 0:
                by_l[L].append(r)
        levels = sorted(by_l)
        meta = {"decomposed_measure_track_level_count": int(len(levels))}
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            comps = [
                ("density", "density_support_component_JS_live_record"),
                ("signature", "normalized_F1F2_signature_component"),
                ("strength", "F1F2_response_strength_component"),
                ("total", "decomposed_history_measure_additive_total"),
            ]
            meta.update({"decomposed_measure_first_level": int(first), "decomposed_measure_last_level": int(last)})
            for label, col in comps:
                a = _median(_finite(r.get(col)) for r in by_l[first])
                b = _median(_finite(r.get(col)) for r in by_l[last])
                if math.isfinite(a) and math.isfinite(b) and b > a + max(tol, tol * max(1.0, abs(a))):
                    trend = f"{label}_component_deepens_with_level"
                elif math.isfinite(a) and math.isfinite(b) and b < a - max(tol, tol * max(1.0, abs(a))):
                    trend = f"{label}_component_decreases_with_level"
                else:
                    trend = f"{label}_component_level_stable_or_unresolved"
                meta[f"{label}_component_first_level_median"] = a
                meta[f"{label}_component_last_level_median"] = b
                meta[f"{label}_component_level_trend"] = trend
        else:
            meta["decomposed_measure_level_trend"] = "decomposed_measure_level_trend_unavailable"
        density = [_finite(r.get("density_support_component_JS_live_record")) for r in xs]
        signature = [_finite(r.get("normalized_F1F2_signature_component")) for r in xs]
        strength = [_finite(r.get("F1F2_response_strength_component")) for r in xs]
        bnorm = [_finite(r.get("backreaction_current_norm")) for r in xs]
        mod = [_finite(r.get("modular_spread_live")) for r in xs]
        meta.update({
            "corr_density_component_vs_B_norm": _pearson(density, bnorm),
            "corr_signature_component_vs_B_norm": _pearson(signature, bnorm),
            "corr_strength_component_vs_B_norm": _pearson(strength, bnorm),
            "corr_density_component_vs_modular_spread": _pearson(density, mod),
            "corr_signature_component_vs_modular_spread": _pearson(signature, mod),
            "corr_strength_component_vs_modular_spread": _pearson(strength, mod),
        })
        for r in xs:
            r.update(meta)


def signature_strength_decomposed_measure_rows(
    history_rows: List[dict],
    f1f2_orientation_rows: List[dict],
    mode_ablation_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Decompose the oriented/history signature measure into three non-fitted components.

    The previous two-component measure used density/support JS plus the raw
    F1/F2 profile gap.  the signature comparison showed that the F1/F2 contribution itself has a
    mode-mode_stable signature part and a mode-sensitive strength part.  This
    surface freezes that decomposition and reports all three components without
    fitting them to locality, split, complement, or modular derived_quantity rows.
    """
    hidx = _history_index(history_rows)
    fidx = _f1f2_index(f1f2_orientation_rows)
    midx = _mode_ablation_true_index(mode_ablation_rows)
    rows: List[dict] = []
    for k, h in sorted(hidx.items(), key=lambda kv: str(kv[0])):
        f = fidx.get(k, {})
        m = midx.get(k, {})
        density = _finite(m.get("true_density_JS_component"))
        if not math.isfinite(density):
            density = _finite(h.get("JS_live_record_no_epsilon"))
        signature = _finite(m.get("true_F1F2_signature_gap_mode_mode_stable_component"))
        strength = _finite(m.get("true_F1F2_strength_gap_mode_sensitive_component"))
        raw_profile_gap = _finite(f.get("F1F2_profile_gap_live_record"))
        additive = density + signature + strength if all(math.isfinite(x) for x in (density, signature, strength)) else math.nan
        euclid = math.sqrt(density * density + signature * signature + strength * strength) if all(math.isfinite(x) for x in (density, signature, strength)) else math.nan
        ds = density + signature if math.isfinite(density) and math.isfinite(signature) else math.nan
        dstr = density + strength if math.isfinite(density) and math.isfinite(strength) else math.nan
        sstr = signature + strength if math.isfinite(signature) and math.isfinite(strength) else math.nan
        dom = _dominance(density, signature, strength, tol)
        total = additive if math.isfinite(additive) and additive > 0 else math.nan
        if not math.isfinite(density):
            computed_status = "decomposed_measure_density_component_unavailable"
        elif not math.isfinite(signature) or not math.isfinite(strength):
            computed_status = "decomposed_measure_signature_or_strength_component_unavailable"
        elif dom == "normalized_F1F2_signature_component":
            computed_status = "decomposed_measure_orientation_signature_dominant_finite_object"
        elif dom == "F1F2_response_strength_component":
            computed_status = "decomposed_measure_response_strength_dominant_control"
        elif dom == "density_support_component":
            computed_status = "decomposed_measure_density_support_dominant_control"
        elif dom == "all_components_vacuous_or_zero_control":
            computed_status = "decomposed_measure_vacuous_zero_control"
        else:
            computed_status = "decomposed_measure_mixed_component_control"
        rows.append({
            "branching": h.get("branching"),
            "level": h.get("level"),
            "mode": h.get("mode"),
            "region_id": h.get("region_id"),
            "region_family": h.get("region_family"),
            "genealogical_corridor_length": h.get("genealogical_corridor_length"),
            "measure_relations": "decomposed_history_measure_density_plus_normalized_F1F2_signature_plus_F1F2_strength",
            "measure_definition_fixed_before_geometry_tests": 1,
            "measure_weight_fit_to_geometry": 0,
            "density_support_component_JS_live_record": density,
            "normalized_F1F2_signature_component": signature,
            "F1F2_response_strength_component": strength,
            "raw_F1F2_profile_gap_control": raw_profile_gap,
            "density_plus_signature_component": ds,
            "density_plus_strength_component": dstr,
            "signature_plus_strength_component": sstr,
            "decomposed_history_measure_additive_total": additive,
            "decomposed_history_measure_euclidean_control": euclid,
            "density_fraction_of_total": float(density / total) if math.isfinite(total) and math.isfinite(density) and total > 0 else math.nan,
            "signature_fraction_of_total": float(signature / total) if math.isfinite(total) and math.isfinite(signature) and total > 0 else math.nan,
            "strength_fraction_of_total": float(strength / total) if math.isfinite(total) and math.isfinite(strength) and total > 0 else math.nan,
            "component_dominance": dom,
            "backreaction_current_norm": _finite(h.get("backreaction_current_norm")),
            "modular_spread_live": _finite(h.get("modular_spread_live")),
            "record_tracking_gain_over_uniform": _finite(h.get("record_tracking_gain_over_uniform")),
            "F1F2_live_profile_strength": _finite(m.get("true_F1F2_live_profile_strength")),
            "F1F2_record_profile_strength": _finite(m.get("true_F1F2_record_profile_strength")),
            "F1F2_true_record_beats_F2_flipped_record": int(f.get("F1F2_multishell_true_beats_F2_flipped_record", 0) or 0),
            "decomposed_measure_computed_status": computed_status,
        })
    _augment_tracks(rows, tol)
    return rows


def signature_strength_decomposed_measure_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("decomposed_measure_computed_status", "unknown")) for r in rows})
    doms = sorted({str(r.get("component_dominance", "unknown")) for r in rows})
    sig = sum(1 for r in rows if str(r.get("component_dominance")) == "normalized_F1F2_signature_component")
    strength = sum(1 for r in rows if str(r.get("component_dominance")) == "F1F2_response_strength_component")
    density = sum(1 for r in rows if str(r.get("component_dominance")) == "density_support_component")
    return (
        "# Signature-vs-strength decomposed HistoryMeasure\n\n"
        "This surface freezes the History/Live derived_quantity into three non-fitted components: density/support JS, normalized F1/F2 orientation signature gap, and F1/F2 response-strength gap.  Geometry tests consume these columns separately; no component weight is fitted to the downstream rank_bound surfaces.\n\n"
        f"Rows: {len(rows)}. Dominance counts — density: {density}, signature: {sig}, strength: {strength}.\n\n"
        "Dominance classes: `" + "`, `".join(doms) + "`.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
