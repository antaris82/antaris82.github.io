from __future__ import annotations

import math
from collections import defaultdict
from typing import Iterable, List


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(_finite(x) for x in xs if math.isfinite(_finite(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def mode_ablated_measure_summary_rows(mode_ablation_rows: List[dict], level_mode_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    groups = defaultdict(list)
    for r in mode_ablation_rows:
        if str(r.get("mode_ablation_signature_computed_status", "")) == "mode_ablation_response_unavailable":
            continue
        groups[(r.get("branching"), r.get("level"), r.get("mode"), r.get("control_mode"))].append(r)
    for (b, L, mode, cmode), xs in sorted(groups.items(), key=lambda kv: (int(kv[0][0]), int(kv[0][1]), str(kv[0][2]), str(kv[0][3]))):
        total = len(xs)
        sig = sum(1 for r in xs if int(r.get("true_signature_preferred_over_mode_control", 0)) == 1)
        strength = sum(1 for r in xs if int(r.get("true_strength_preferred_over_mode_control", 0)) == 1)
        combined = sum(1 for r in xs if int(r.get("true_combined_score_preferred_over_mode_control", 0)) == 1)
        same_sig = sum(1 for r in xs if int(r.get("mode_control_same_birth_order_signature_as_true_record", 0)) == 1)
        close = sum(1 for r in xs if "as_close_or_closer" in str(r.get("mode_ablation_signature_computed_status", "")))
        if total and sig / total >= 0.75 and combined / total >= 0.75:
            computed_status = "mode_parameter_dependence_restored_by_F1F2_signature_ablation_summary"
        elif total and same_sig / total >= 0.50:
            computed_status = "mode_family_preserves_birth_order_signature_summary"
        elif total and close / total >= 0.25:
            computed_status = "mode_ablation_parameter_dependence_rank_bound_summary"
        elif total and strength / total > sig / max(1, total):
            computed_status = "mode_difference_is_strength_not_signature_summary"
        else:
            computed_status = "mode_ablation_partial_or_unresolved_summary"
        rows.append({
            "summary_surface": "mode_ablated_measure_summary",
            "branching": int(b), "level": int(L), "mode": str(mode), "control_mode": str(cmode),
            "row_count": total,
            "true_signature_preferred_count": sig,
            "true_strength_preferred_count": strength,
            "true_combined_score_preferred_count": combined,
            "same_birth_order_signature_control_count": same_sig,
            "mode_control_as_close_or_closer_count": close,
            "median_signature_margin_control_minus_true": _median(r.get("signature_margin_control_minus_true") for r in xs),
            "median_strength_margin_control_minus_true": _median(r.get("strength_margin_control_minus_true") for r in xs),
            "median_density_margin_control_minus_true": _median(r.get("density_margin_control_minus_true") for r in xs),
            "median_combined_score_margin_control_minus_true": _median(r.get("combined_score_margin_control_minus_true") for r in xs),
            "summary_computed_status": computed_status,
        })

    # Compare additive ambiguity against signature/strength decomposition.
    previous_groups = defaultdict(list)
    for r in level_mode_rows:
        if str(r.get("parameter_dependence_control_family")) != "mode_mismatched_record":
            continue
        previous_groups[(r.get("branching"), r.get("level"), r.get("mode"), r.get("control_mode"))].append(r)
    for key, xs in sorted(previous_groups.items(), key=lambda kv: (int(kv[0][0]), int(kv[0][1]), str(kv[0][2]), str(kv[0][3]))):
        b, L, mode, cmode = key
        mkey = (b, L, mode, cmode)
        ab = groups.get(mkey, [])
        previous_close = sum(1 for r in xs if "as_close_or_closer" in str(r.get("history_measure_level_mode_dependence_computed_status", "")))
        ablation_shared = sum(1 for r in ab if int(r.get("mode_control_same_birth_order_signature_as_true_record", 0)) == 1)
        ablation_sig = sum(1 for r in ab if int(r.get("true_signature_preferred_over_mode_control", 0)) == 1)
        if xs and previous_close and ablation_shared >= ablation_sig:
            computed_status = "level_mode_degeneracy_explained_by_shared_F1F2_signature_control"
        elif xs and previous_close and ablation_sig > ablation_shared:
            computed_status = "level_mode_degeneracy_not_explained_by_signature_control"
        else:
            computed_status = "level_mode_parameter_dependence_consistent_with_ablation_control"
        rows.append({
            "summary_surface": "mode_ablation_vs_level_mode_parameter_dependence",
            "branching": int(b), "level": int(L), "mode": str(mode), "control_mode": str(cmode),
            "previous_mode_mismatch_row_count": len(xs),
            "previous_as_close_or_closer_count": previous_close,
            "ablation_row_count": len(ab),
            "ablation_same_birth_order_signature_count": ablation_shared,
            "ablation_true_signature_preferred_count": ablation_sig,
            "summary_computed_status": computed_status,
        })
    return rows


def mode_ablated_measure_summary_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("summary_computed_status", "unknown")) for r in rows})
    return (
        "# Mode-ablated measure summary\n\n"
        "This summary decides whether the mode-mismatch ambiguity is due to shared F1/F2 birth-order signature, response-strength differences, or a remaining parameter_dependence rank_bound.\n\n"
        f"Summary rows: {len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
