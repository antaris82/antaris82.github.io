from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    basis_to_algebra,
    build_genealogical_corridor_regions,
    commutant_algebra_basis,
    genealogical_corridor_metadata,
    local_operator_algebras,
    max_span_residual,
    max_star_residual,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)

COMPLEMENT_PAIRS = [
    ("left_frontier_response", "right_frontier_response", "boundary_frontier_complement_without_lca_anchor"),
    ("left_birth_cone_response", "right_birth_cone_response", "genealogical_opposite_cone_with_shared_lca_anchor"),
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "symmetric_carrier_opposite_cone"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "directed_current_opposite_cone"),
]


def finite_complement_relations_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            resp = regional_response(model, spec, "live")
            if resp is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, "finite_complement_computed_status": "response_unavailable"})
                continue
            algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            dim = int(resp.Lambda_role.shape[0])
            for region_name, complement_name, complement_type in COMPLEMENT_PAIRS:
                A = algebras[region_name]
                C = algebras[complement_name]
                Acomm = basis_to_algebra("commutant_of_" + region_name, commutant_algebra_basis(A, dim, config.rank_tol))
                Ccomm = basis_to_algebra("commutant_of_" + complement_name, commutant_algebra_basis(C, dim, config.rank_tol))
                comp_into_comm = max_span_residual(C.basis, Acomm.basis)
                comm_into_comp = max_span_residual(Acomm.basis, C.basis)
                region_into_compcomm = max_span_residual(A.basis, Ccomm.basis)
                star_comp_into_comm = max_star_residual(C.basis, Acomm.basis)
                one_sided = int(comp_into_comm <= config.algebra_tol and star_comp_into_comm <= config.algebra_tol)
                two_sided = int(one_sided and comm_into_comp <= config.algebra_tol)
                if two_sided:
                    computed_status = "finite_duality_finite_object_for_declared_complement"
                elif one_sided:
                    computed_status = "one_sided_complement_in_commutant_finite_object"
                elif complement_type == "genealogical_opposite_cone_with_shared_lca_anchor":
                    computed_status = "shared_lca_anchor_complement_obstructed_control"
                else:
                    computed_status = "finite_complement_relations_obstructed"
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "state": "live",
                    "region_operator_system": region_name,
                    "declared_complement_operator_system": complement_name,
                    "finite_complement_type": complement_type,
                    "region_dim": len(A.basis),
                    "complement_dim": len(C.basis),
                    "commutant_dim": len(Acomm.basis),
                    "opposite_commutant_dim": len(Ccomm.basis),
                    "complement_into_region_commutant_residual": float(comp_into_comm),
                    "complement_star_into_region_commutant_residual": float(star_comp_into_comm),
                    "region_commutant_into_complement_residual": float(comm_into_comp),
                    "region_into_complement_commutant_residual": float(region_into_compcomm),
                    "one_sided_inclusion_ok": one_sided,
                    "two_sided_duality_ok": two_sided,
                    "finite_complement_computed_status": computed_status,
                })
    return rows


def finite_complement_relations_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("finite_complement_computed_status", "unknown")) for r in rows})
    ctypes = sorted({str(r.get("finite_complement_type", "unknown")) for r in rows})
    return (
        "# Finite complement relations\n\n"
        "This surface separates declared finite complement sign_relations.  It reports one-sided inclusion into the commutant, the reverse inclusion, and double-sided finite duality finite_objects.  "
        "Full Haag duality is not stated.\n\n"
        "Complement types: `" + "`, `".join(ctypes) + "`.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
