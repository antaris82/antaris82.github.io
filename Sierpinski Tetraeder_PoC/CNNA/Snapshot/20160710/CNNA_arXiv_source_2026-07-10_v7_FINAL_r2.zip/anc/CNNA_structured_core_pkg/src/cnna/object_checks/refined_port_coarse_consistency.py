from __future__ import annotations

import math
from typing import List

import numpy as np

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.entropy_quantities import jensen_shannon_divergence_no_epsilon
from cnna.core.math_utils import fro
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.refined_port_basis import refined_regional_response
from cnna.core.region_response import (
    positive_support_density_from_response,
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def refined_port_coarse_consistency_rows(config: OperatorTestConfig) -> List[dict]:
    """Check that the refined test port basis is a genuine refinement.

    Coarsening the refined response by projecting the refined basis back onto
    the original 3-role basis must recover the direct 3-role response.  This is
    the input-exclusion condition_note for 8 refined-port derived_quantity rows.
    """
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            for state in ("live", "record", "sym"):
                coarse = regional_response(model, spec, state)
                refined = refined_regional_response(model, spec, state)
                if coarse is None or refined is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "refined_coarse_consistency_computed_status": "response_unavailable"})
                    continue
                Qc = coarse.role_basis
                Qr = refined.role_basis
                C = Qr.T @ Qc
                Qc_reconstructed = Qr @ C
                basis_res = float(fro(Qc_reconstructed - Qc))
                L_from_refined = C.T @ refined.Lambda_role @ C
                S_from_refined = 0.5 * (L_from_refined + L_from_refined.T)
                A_from_refined = 0.5 * (L_from_refined - L_from_refined.T)
                L_res = float(fro(L_from_refined - coarse.Lambda_role) / max(fro(coarse.Lambda_role), 1.0e-300))
                S_res = float(fro(S_from_refined - coarse.symmetric_role) / max(fro(coarse.symmetric_role), 1.0e-300))
                A_res = float(fro(A_from_refined - coarse.skew_role) / max(fro(coarse.skew_role), 1.0e-300)) if fro(coarse.skew_role) > config.algebra_tol else 0.0
                D_from_refined, dmeta = positive_support_density_from_response(L_from_refined, tol=config.rank_tol)
                js_density = _finite(jensen_shannon_divergence_no_epsilon(coarse.density, D_from_refined, config.algebra_tol)[0])
                exact = int(basis_res <= 1.0e-9 and L_res <= 1.0e-8 and js_density <= 1.0e-8)
                if exact:
                    computed_status = "refined_to_coarse_recovers_three_role_response_finite_object"
                elif basis_res <= 1.0e-9:
                    computed_status = "refined_basis_spans_coarse_roles_but_response_differs_observed"
                else:
                    computed_status = "refined_basis_not_a_clean_refinement_observed"
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "state": state,
                    "coarse_role_names": "|".join(coarse.role_names),
                    "refined_role_names": "|".join(refined.role_names),
                    "coarse_dim": int(coarse.Lambda_role.shape[0]),
                    "refined_dim": int(refined.Lambda_role.shape[0]),
                    "refined_has_extra_resolution": int(refined.Lambda_role.shape[0] > coarse.Lambda_role.shape[0]),
                    "coarse_basis_reconstruction_residual": basis_res,
                    "coarsened_refined_Lambda_relative_residual": L_res,
                    "coarsened_refined_S_relative_residual": S_res,
                    "coarsened_refined_A_relative_residual": A_res,
                    "JS_direct_coarse_density_vs_coarsened_refined_density": js_density,
                    "coarsened_density_computed_status": dmeta.get("density_computed_status", "unknown"),
                    "refined_coarse_consistency_exact": exact,
                    "refined_coarse_consistency_computed_status": computed_status,
                })
    return rows


def refined_port_coarse_consistency_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("refined_coarse_consistency_computed_status", "unknown")) for r in rows})
    exact = sum(1 for r in rows if int(r.get("refined_coarse_consistency_exact", 0)) == 1)
    return (
        "# Refined-port to coarse-role consistency\n\n"
        "This surface checks that the refined test port basis is a genuine finite refinement: projecting/coarsening refined responses back to the original 3-role carrier should recover the direct 3-role response.  It condition_notes against basis-level input_inclusion.\n\n"
        f"Exact refined-to-coarse rows: {exact}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
