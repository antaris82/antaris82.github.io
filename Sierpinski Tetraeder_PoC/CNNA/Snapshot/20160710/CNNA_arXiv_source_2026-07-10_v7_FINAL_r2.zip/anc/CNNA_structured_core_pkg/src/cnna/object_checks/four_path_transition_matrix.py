from __future__ import annotations

from typing import List


FOUR_PATHS = (
    {
        "path_id": "AQFT_path_with_DtN_form_layer",
        "path_name": "AQFT path: DtN one-particle form layer -> standard-subspace/Fock/GNS -> local operator net limit",
        "finite_anchor": "common-ambient Schur isotony; live S/A response split; finite one-particle quasifree comparisons; rank_bound map for locality/split/duality on the DtN layer",
        "what_supports": "DtN responses have the finite shape of real one-particle form data: positive symmetric carrier S and skew F1/F2 commutator/symplectic finite_object A.  AQFT is not tested on DtN itself but above it.",
        "what_does_not_statement": "no Haag-Kastler net, no full microcausality, no Reeh-Schlieder property, no split property, no Type-III statement, no chosen CCR/CAR statistics, no Fock representation yet",
        "main_open_bridge": "Construction step 1: check S/A as one-particle form data by quasifree dominance, skew locality and deterministic polarization conditions. Construction step 2: choose/derive CCR-CAR-Boltzmann sectors from the dual simplicial geometry. Construction step 3: only then construct standard-subspace/Fock/GNS local net finite_objects and test the long AQFT limit.",
        "path_sublayers": "AQFT_0_DtN_form_layer;AQFT_1_standard_subspace_or_Fock_bridge;AQFT_2_local_operator_net_limit",
        "next_package_target": "AQFT form-layer bridge derived_quantity rows plus multiscale port algebra; full AQFT net only after statistics and energy/spectrum positivity are available",
        "falsification_condition_note": "finite DtN noncommutation does not falsify AQFT; it only falsifies the wrong placement of AQFT at the raw DtN layer.  The AQFT path fails only if neither the one-particle form conditions nor the later net/coarse-graining conditions can be made stable.",
        "priority": "presentation_projection_not_dependency_order",
        "topology_status": "presentation_projection_of_dependency_stack",
        "stack_binding": "AQFT path contains L0->L4 ladder; Fock/GNS is internal to AQFT and not a fifth path",
        "dependency_edges": "uses L0 coarse DtN form data; depends on L1 statistics before CCR/CAR; targets L4 AQFT only after L3",
    },
    {
        "path_id": "Connes_NCG_path",
        "path_name": "Connes-style noncommutative spectral geometry",
        "finite_anchor": "normalized F1/F2 skew-signature explains local geometry residuals; live GNS/operator system is available",
        "what_supports": "finite geometry is operatorial and noncommutative; residuals are organized by the F1/F2 two-form rather than by point distance",
        "what_does_not_statement": "no spectral triple, no derived Dirac operator, no Connes distance, no first-order condition, no index/K-cycle statement",
        "main_open_bridge": "derive a Dirac/Lipschitz-seminorm finite_object from F1/F2 skew two-form, B-current, or Bianconi/topological Dirac data on the dual simplicial complex; test commutators [D,a]",
        "path_sublayers": "NCG_0_operator_system;NCG_1_D_F1F2_or_topological_Dirac;NCG_2_spectral_triple_finite_object",
        "next_package_target": "finite D_F1F2/topological-Dirac finite_object, spectral seminorm, refined-to-coarse stability, orientation/noncommutativity residuals",
        "falsification_condition_note": "do not identify Tomita-J with CNNA-J; NCG path fails only if no stable D/Lipschitz operator can be derived from F1/F2 or dual simplicial data",
        "priority": "presentation_projection_not_dependency_order",
        "topology_status": "presentation_projection_of_dependency_stack",
        "stack_binding": "maps to Layer 2 NCG/spectral layer, receiving Layer-1 deformed geometry",
        "dependency_edges": "depends on L1 Dirichlet/F1F2 geometry; exports spectral data toward L3",
    },
    {
        "path_id": "CFS_measure_cross_axis",
        "path_name": "Causal Fermion System / common-measure cross-axis (not a stack layer)",
        "finite_anchor": "live/record HistoryMeasure decomposes into density/support, normalized F1/F2 signature, and response strength; B=live-record is a current",
        "what_supports": "CNNA has an operator-valued history/backreaction measure derived_quantity and a finite_object pushforward direction from ports/regions to operator points",
        "what_does_not_statement": "no CFS triple (H,F,rho), no common measure rho on F, no causal action principle, no CFS spectral causal relation yet",
        "main_open_bridge": "map CNNA ports/regions to finite-rank operator points X_R and define rho_L as a pushforward of inherited node/live weights; compare spectra of X_R X_S to F1/F2-oriented causality",
        "path_sublayers": "CFS_cross_axis_0_operator_point_cloud;CFS_cross_axis_1_pushforward_measure_rho_L;CFS_cross_axis_2_spectral_causality_and_action_proxy",
        "next_package_target": "finite operator-point cloud, rho_L pushforward, CFS-like product spectra X_R X_S, causal-action derived_quantity controls",
        "falsification_condition_note": "do not call HistoryMeasure a common measure until rho_L on operator space is explicit; path fails only if no stable pushforward measure/causal spectra exist",
        "priority": "cross_axis_projection_not_stack_order",
        "topology_status": "CFS_cross_axis_not_stack_layer",
        "stack_binding": "cross-axis measure/operator-space register intersecting all layers",
        "dependency_edges": "construct X_R and rho_L only from exported lower-layer/operator data; does not define layers",
    },
    {
        "path_id": "Deformed_fractal_simplicial_quantum_geometry_path",
        "path_name": "deformed Sierpinski-like fractal/simplicial-complex quantum geometry",
        "finite_anchor": "tree provenance is dual to nested Sierpinski-like approximants; symmetric SG/ST-like cases serve as null controls, not physical CNNA",
        "what_supports": "F1/F2-oriented noncommutative geometry suggests a deformed, non-exactly-self-similar resistance/energy/simplicial geometry rather than a symmetric self-similar fractal",
        "what_does_not_statement": "no Kigami resistance form, no Strichartz fractafold Laplacian, no Bianconi/NGF statistics property, no spectral dimension property, no exact SG/ST geometry",
        "main_open_bridge": "construct finite deformed Sierpinski-like graph/simplicial approximants from live Schur/DtN data; test resistance forms, Laplacian spectra, simplicial incidence statistics, and symmetric-null recovery",
        "path_sublayers": "Fractal_0_deformed_approximants;Fractal_1_resistance_Laplacian;Fractal_2_simplicial_statistics_and_topological_Dirac",
        "next_package_target": "CNNA-to-deformed-fractal/simplicial pushforward: variable resistance weights, harmonic extension residuals, face-incidence statistics, Bianconi-sector conditions, symmetric SG/ST null comparison",
        "falsification_condition_note": "do not compare CNNA to symmetric SG/ST as target; use symmetric fractals only as controls. Path fails only if no stable deformed resistance/Laplacian/statistical simplicial geometry survives refinement",
        "priority": "presentation_projection_not_dependency_order",
        "topology_status": "presentation_projection_of_dependency_stack",
        "stack_binding": "Layer 1 deformed simplicial/fractal geometry under NCG and AQFT; not a parallel dependency to AQFT",
        "dependency_edges": "receives L0 provenance/response functor outputs; exports resistance/Dirichlet/F1F2/face statistics to L2/L3",
    },
)


def four_path_transition_matrix_rows() -> List[dict]:
    return [dict(row) for row in FOUR_PATHS]


def four_path_dependency_table_priority_rows() -> List[dict]:
    rows: List[dict] = []
    for row in FOUR_PATHS:
        rows.append(
            {
                "path_id": row["path_id"],
                "path_name": row["path_name"],
                "priority_relations": row["priority"],
                "topology_status": row.get("topology_status", "previous_projection"),
                "stack_binding": row.get("stack_binding", "not_recorded"),
                "dependency_edges": row.get("dependency_edges", "not_recorded"),
                "first_test_surface": row["next_package_target"],
                "must_not_overstatement": row["what_does_not_statement"],
                "do_not_falsify_yet_because": row["falsification_condition_note"],
            }
        )
    return rows


def four_path_literature_bridge_rows() -> List[dict]:
    return [
        {
            "bridge_id": "AQFT_standard_subspace_Fock_bridge",
            "path_ids": "AQFT_path_with_DtN_form_layer",
            "literature_object": "standard subspaces and second quantization: one-particle real subspaces/forms generate local von Neumann algebras only after a functorial Fock/GNS step",
            "CNNA_docking_object": "live DtN S/A split, F1/F2-derived skew form, deterministic polarization comparison, Bianconi-derived statistics condition",
            "required_test_before_statement": "quasifree dominance |A|^2 <= 4SS, symplectic quotient/kernel handling, deterministic polarization J from S/A, skew locality on multiscale ports, derived statistics sector",
            "overstatement_condition_note": "do not treat DtN matrices as AQFT local algebras; they are one-particle form data for the AQFT path",
        },
        {
            "bridge_id": "Finster_CFS",
            "path_ids": "CFS_measure_cross_axis;AQFT_path_with_DtN_form_layer",
            "literature_object": "causal fermion system triple (H,F,rho), spacetime as supp rho, common measure on finite-rank self-adjoint operators",
            "CNNA_docking_object": "regional/operator-point finite_objects X_R and pushforward rho_L from inherited node/live weights; record/live HistoryMeasure remains derived_quantity, not rho",
            "required_test_before_statement": "operator-point cloud X_R, rho_L support, spectra of X_R X_S, causal-action proxy, comparison to F1/F2 geometry",
            "overstatement_condition_note": "do not call CNNA HistoryMeasure a common measure until rho_L on operator space is explicitly built",
        },
        {
            "bridge_id": "Connes_NCG",
            "path_ids": "Connes_NCG_path;Deformed_fractal_simplicial_quantum_geometry_path",
            "literature_object": "spectral triple/operator-system spectral geometry with algebra, Hilbert space and Dirac-type operator D",
            "CNNA_docking_object": "F1/F2 skew signature, B-current and Bianconi/topological Dirac finite_object on deformed simplicial complex",
            "required_test_before_statement": "derive D_F1F2/topological D, bounded commutators [D,a], spectral seminorm, refined-to-coarse stability",
            "overstatement_condition_note": "do not statement spectral triple or Connes distance at x",
        },
        {
            "bridge_id": "Bianconi_simplicial_statistics_and_topological_Dirac",
            "path_ids": "Deformed_fractal_simplicial_quantum_geometry_path;AQFT_path_with_DtN_form_layer;Connes_NCG_path",
            "literature_object": "network geometry with flavor, quantum statistics on faces of growing simplicial complexes, and topological Dirac equation on networks/simplicial complexes",
            "CNNA_docking_object": "tree-to-deformed-Sierpinski/simplicial dual with live-response face weights; sector statistics as possible CCR/CAR/Boltzmann selector; topological Dirac as D_F1F2 comparison object",
            "required_test_before_statement": "incidence kinematics, face occupancy distributions by dimension, b=3/b=4 sector predictions, statistics-to-CCR/CAR bridge, topological Dirac comparison",
            "overstatement_condition_note": "do not import NGF distributions unless CNNA's contraction/subdivision dual passes the kinematics condition or is measured separately",
        },
    ]


def closed_finite_results_rows() -> List[dict]:
    return [
        {
            "result_id": "live_reference_relations",
            "status": "closed_for_property_layer",
            "finite_content": "live is the reference physics carrier; record is history/provenance reference; sym is null control; B=live-record is backreaction current",
            "condition_note": "record support loss is not a physics failure",
        },
        {
            "result_id": "core_construction_chain",
            "status": "closed_for_as_presentation_mainline",
            "finite_content": "empty_state -> root birth -> sequential b-ary provenance tree -> record/live directed response split -> Schur/DtN observables -> F1/F2-oriented response geometry -> four transition paths with AQFT-internal DtN→Fock/GNS sublayers",
            "condition_note": "this is the construction skeleton, not a continuum property; do not replace it by construction_step chronology or by isolated test surfaces",
        },
        {
            "result_id": "common_ambient_schur_isotony",
            "status": "closed_for_property_layer",
            "finite_content": "R subset S is exactly Schur-consistent when both are conditioned in the same ambient approximant and extra S\\R ports are eliminated",
            "condition_note": "raw separately conditioned Schur responses are context-dependent and not the isotony object",
        },
        {
            "result_id": "finite_RQFT_rank_bounds_classified",
            "status": "closed_for_as_rank_bound_map",
            "finite_content": "proper-subalgebra cyclicity is dimension-obstructed; split/duality/locality are not tensor-local in the finite F1/F2 carrier",
            "condition_note": "no full AQFT statements in finite 3-role/port approximants",
        },
        {
            "result_id": "history_measure_decomposition",
            "status": "closed_for_property_layer",
            "finite_content": "HistoryMeasure decomposes into density/support JS, normalized F1/F2 signature, and F1/F2 response strength",
            "condition_note": "do not collapse the three components into a fitted common scalar",
        },
        {
            "result_id": "F1F2_oriented_geometry_replacement",
            "status": "closed_for_as_finite_replacement_finite_object",
            "finite_content": "finite locality/split/complement residuals are organized by normalized F1/F2 skew-signature rather than naive tensor-local geometry",
            "condition_note": "replacement geometry is finite and derived_quantity; not a full continuum property",
        },
    ]


def external_measurement_assessment_rows() -> List[dict]:
    return [
        {
            "assessment_id": "measurement_scope",
            "status": "pass_with_scope",
            "content": "the finite-core dependency object is accepted as closure/dependency_table object. The measurement is a sampled measurement over the post-lock construction surfaces since the locked construction core, not a full re-measurement of every construction_step.",
            "evidence": "finite-core sample run reproduced; the largest late-chain run reproduced with zero computed_status differences; selected counters from earlier finite surfaces independently external_reproduction.",
            "condition_note": "Future reports must state measurement scope explicitly and must not present sampled verification as exhaustive reconsistency_check.",
        },
        {
            "assessment_id": "core_integrity",
            "status": "pass",
            "content": "The construction core remains byteidentical since the locked construction core; all post-lock changes sit in the object-check layer and runner dependency_table surface.",
            "evidence": "package hygiene and core-contract validators pass; late-chain outputs reproduce under the current code without hidden semantic drift.",
            "condition_note": "The external paper should separate locked construction core from exploratory/measurement surfaces.",
        },
        {
            "assessment_id": "node_level_schur_isotony",
            "status": "finite_discriminating_condition_closed_for_property_layer",
            "content": "Node-level Schur isotony became a real discriminating condition: 252 exact finite_objects and 216 observed rank_bounds in the external_reproduction 3 surface, before common-ambient conditioning resolves the intended isotony relations.",
            "evidence": "The old gap node_level_independent_schur_embedding_checked=0 is closed; the condition can fail and does fail under raw conditioning.",
            "condition_note": "Only common-ambient Schur isotony should be cited as the positive finite isotony object; raw node-level failures are context-dependence derived_quantity rows.",
        },
        {
            "assessment_id": "trajectory_program",
            "status": "implemented_as_rank_bound_map",
            "content": "The three-trajectory program was implemented: genealogical corridor commutation/split, modular-ratio trajectory, and node-level/common-ambient Schur relations.",
            "evidence": "Corridor commutators do not decay parameter_stablely; modular log-span grows from about 7--8.7 at L=4 to about 9--10.1 at L=5; broad ratio clouds are a III_1-like finite derived_quantity, not a property.",
            "condition_note": "Distance non-decay is measured inside the current compressed carrier; repeat in a multiscale port algebra before promoting it to a model-level fact.",
        },
        {
            "assessment_id": "F1F2_replacement_geometry",
            "status": "positive_finite_finite_object",
            "content": "Finite locality/split/complement residuals are organized by the normalized F1/F2 skew-signature rather than by naive tensor-local distance.",
            "evidence": "F1F2_true_record_beats_F2_flipped holds across the external_reproduction replacement-geometry counters, with strong margin; strict mode-invariance is not stated because the signature-mode comparison only supports drift-subdominant controls.",
            "condition_note": "Add an adversarial self-test in finite_core: replace record by F2-flipped record and require the true-record beats metric to collapse rather than remain trivially residual_le_tolerance.",
        },
        {
            "assessment_id": "presentation_readiness",
            "status": "curate_before_paper",
            "content": "x is too broad as raw code surface for a paper. The arXiv-facing result should discuss only decisive tests and archive or demote scaffolding, tautology controls, and historical construction_step surfaces.",
            "evidence": "object-check layer has 60+ modules; only a subset is needed for the overview paper: live/record relations, common-ambient Schur isotony, F1/F2 orientation resolution, decomposed history measure, replacement geometry, and four-path dependency_table.",
            "condition_note": "A presentation package should include a curated test list, exact run recipes, reproduced counters, and explicit non-statements before soliciting endorsement.",
        },
    ]


def consistency_prerequisite_rows() -> List[dict]:
    return [
        {
            "prerequisite_id": "multiscale_port_retest_of_corridor_nondecay",
            "priority": 1,
            "reason": "The current non-decay of commutators/split residuals is measured in a compressed carrier with a shared LCA anchor.",
            "required_test": "repeat locality/split/complement replacement geometry on disjoint carriers in a common larger ambient multiscale port algebra",
            "success_signal": "F1/F2-normalized ratios remain organized or improve under true port/collar separation",
            "failure_signal": "non-decay disappears entirely once LCA-anchor collapse is removed",
        },
        {
            "prerequisite_id": "adversarial_F2_flip_selftest",
            "priority": 1,
            "reason": "Perfect F2-flip counters are strong but require calibration of the control itself.",
            "required_test": "run an adversarial dataset where record is replaced by its F2-flipped version before scoring and require true-record preference to fall to zero or controlled failure",
            "success_signal": "F2 flip control is shown to bite and is not marker-driven",
            "failure_signal": "the beats metric remains residual_le_tolerance after adversarial replacement",
        },
        {
            "prerequisite_id": "runner_version_manifest",
            "priority": 2,
            "reason": "Old outputs and current outputs can differ in summary row counts because runner surfaces changed from 64 to 68.",
            "required_test": "write runner version, surface list hash, git/package hash if available, and command line into every output directory",
            "success_signal": "byte-reproduction comparisons can distinguish data drift from runner-surface drift",
            "failure_signal": "future diffs are ambiguous because runner provenance is missing",
        },
        {
            "prerequisite_id": "presentation_selection",
            "priority": 1,
            "reason": "Raw x contains many scaffolding and condition_note surfaces that are unsuitable as equal-weight paper results.",
            "required_test": "produce a curated external package with decisive surfaces, archived auxiliary checks, and one overview paper narrative",
            "success_signal": "only load-bearing tests appear in the main paper; auxiliary surfaces are releconditiond to appendices/repro archive",
            "failure_signal": "paper narrative is diluted by construction_step history and too many non-discriminating conditions",
        },
    ]


def presentation_selection_rows() -> List[dict]:
    return [
        {
            "surface_group": "main_text_keep",
            "items": "core construction from empty_state; live-reference relations; common-ambient Schur isotony; F1/F2 orientation resolution; history-measure decomposition; replacement geometry; four-path dependency_table",
            "reason": "These are the load-bearing finite statements and transition points.",
            "paper_role": "core result narrative",
        },
        {
            "surface_group": "appendix_keep",
            "items": "epsilon-free support measurement; null-layer controls; destroyed-history controls; mode-ablation; fixed-measure consistency_check; consistency_check recipes",
            "reason": "These are necessary input-exclusion and parameter_sensitivity checks but too detailed for the main narrative.",
            "paper_role": "parameter_sensitivity appendix",
        },
        {
            "surface_group": "archive_only",
            "items": "early scaffold property checks; tautology controls; superseded raw Schur isotony; historical 0--2 exploratory surfaces",
            "reason": "Useful for provenance, but not main evidence after later semantic consistency.",
            "paper_role": "reproducibility archive",
        },
        {
            "surface_group": "explicit_nonstatements",
            "items": "no full AQFT net; no C*-completion; no vN closure; no Type III property; no Connes spectral triple; no CFS common measure; no Kigami/Strichartz fractal property",
            "reason": "Prevents overstating and preserves all four paths as falsifiable future directions.",
            "paper_role": "scope and limitations",
        },
    ]


def four_path_transition_report() -> str:
    lines = [
        "# Four-path transition matrix",
        "",
        "This dependency_table keeps four research directions open but reorganizes them as a stack: deformed fractal/simplicial geometry, NCG and AQFT are layers, while CFS is the transverse measure/operator-space axis.  The former fifth Fock/AQFT route is integrated into path 1 as the internal AQFT construction ladder: DtN one-particle forms -> standard-subspace/Fock/GNS -> local operator net limit. None is declared solved and none is rejected by the finite finite_core results.  The finite conclusion is narrower: CNNA finite_core produces a live-reference, common-ambient Schur-isotone, F1/F2-oriented noncommutative response geometry with a decomposed history/backreaction measure.  The construction chain from empty_state to sequential provenance growth and live/record Schur-DtN response is part of the main dependency_table, not background ballast.",
        "",
        "## Paths",
    ]
    for row in FOUR_PATHS:
        lines.extend(
            [
                f"### {row['path_name']}",
                f"- finite finite_core anchor: {row['finite_anchor']}",
                f"- supported: {row['what_supports']}",
                f"- not stated: {row['what_does_not_statement']}",
                f"- bridge: {row['main_open_bridge']}",
                f"- condition_note: {row['falsification_condition_note']}",
                "",
            ]
        )
    lines.append("The deformed-fractal path is explicitly added as a fourth bridge.  CNNA should not be compared to symmetric SG/ST as target geometry.  Symmetric Sierpinski-type geometries are null/reference controls; the physical finite_object is deformed, non-exactly-self-similar, and induced by live Schur/DtN response and F1/F2 orientation.")
    lines.append("")
    return "\n".join(lines)


def closed_results_report() -> str:
    lines = [
        "# x closing report",
        "",
        "## Closed finite relations",
        "",
        "x should be closed as a finite property-comparison and rank_bound-classification construction_step, not as a continuum property package.  The key finite object is not an AQFT net, but a live-reference response geometry with common-ambient Schur isotony and F1/F2-oriented noncommutative residuals.",
        "",
        "## Four-way dependency_table",
        "",
        "1. AQFT remains the long limit-language path.  It requires a limit net, spectrum/energy positivity finite_object, and proof that F1/F2 residuals coarse-grain into causal complements or modular data.",
        "2. Connes NCG is the operator-geometric path.  It requires a derived D_F1F2 or Lipschitz seminorm from the skew two-form/current data.",
        "3. CFS is the transverse operator-measure axis.  It requires an explicit rho_L on operator points X_R, not only pairwise record/live divergences; it is not a stack layer.",
        "4. Deformed Sierpinski/simplicial quantum geometry is the fractal/resistance path.  It requires a pushforward from provenance tree to deformed finite graph/simplicial approximants and comparison against symmetric SG/ST null models.",
        "",
        "## Integrated external measurement assessment",
        "",
        "The finite-core dependency table is accepted as a closure and dependency_table object under sampled-measurement scope.  The locked construction core remains unchanged since the locked construction core; the late-chain run reproduced under the current code with no computed_status drift.  The decisive finite content is the F1/F2-oriented replacement geometry, not a finite AQFT property.",
        "",
        "## Critical finite_core prerequisites",
        "",
        "1. Repeat the corridor/nonlocality replacement-geometry tests on a genuine multiscale port algebra, because the present compressed carrier still shares an LCA anchor.",
        "2. Calibrate the F2-flip control adversarially by replacing the record with its F2-flipped version and requiring true-record preference to collapse.",
        "3. Add runner-version and surface-list provenance to every output directory before long-running presentation measurements.",
        "4. Curate the external result set: main text should keep only load-bearing tests, with scaffold and superseded surfaces archived.",
        "",
        "## Do not overstatement",
        "",
        "No full AQFT, no C*-completion, no von Neumann closure, no Type-III classification, no Connes spectral triple, no CFS common measure, and no Kigami/Strichartz fractal property is stated by x.",
        "",
    ]
    return "\n".join(lines)
