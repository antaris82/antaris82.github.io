from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _hist_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {
        (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length")): r
        for r in history_rows
        if r.get("measure_surface") == "history_live_measure_finite_object"
    }


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("refined_split_layer"))


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[dict]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        if c >= 0:
            by_c[c].append(r)
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"entropy_ordered_split_track_computed_status": "entropy_ordered_split_insufficient_collar_track"}
    first, last = cs[0], cs[-1]
    fdef = _median(_finite(r.get("refined_tensor_dimension_residual")) for r in by_c[first])
    ldef = _median(_finite(r.get("refined_tensor_dimension_residual")) for r in by_c[last])
    fnd = _median(_finite(r.get("split_residual_per_history_js")) for r in by_c[first])
    lnd = _median(_finite(r.get("split_residual_per_history_js")) for r in by_c[last])
    if math.isfinite(ldef) and ldef <= tol:
        computed_status = "entropy_ordered_split_tensor_finite_object"
    elif math.isfinite(fdef) and math.isfinite(ldef) and ldef < fdef and math.isfinite(fnd) and math.isfinite(lnd) and lnd < fnd:
        computed_status = "history_measure_normalized_split_improves_with_collar_finite_object"
    elif math.isfinite(fdef) and math.isfinite(ldef) and ldef > fdef:
        computed_status = "history_measure_ordered_split_residual_grows_with_collar_observed"
    else:
        computed_status = "history_measure_ordered_split_no_monotone_improvement_observed"
    return {
        "entropy_ordered_split_collar_count": int(len(cs)),
        "entropy_ordered_split_first_collar": int(first),
        "entropy_ordered_split_last_collar": int(last),
        "split_residual_first_collar_median": fdef,
        "split_residual_last_collar_median": ldef,
        "split_residual_per_history_js_first_collar_median": fnd,
        "split_residual_per_history_js_last_collar_median": lnd,
        "entropy_ordered_split_track_computed_status": computed_status,
    }


def entropy_ordered_split_rows(history_rows: List[dict], refined_split_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Use JS(live,record) to scale refined collar split residuals."""
    hidx = _hist_index(history_rows)
    rows: List[dict] = []
    for r in refined_split_rows:
        if "refined_tensor_dimension_residual" not in r:
            continue
        key = (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        residual = _finite(r.get("refined_tensor_dimension_residual"))
        per_js = float(residual / max(js, 1.0e-300)) if math.isfinite(residual) and math.isfinite(js) and js > 0 else math.nan
        if residual <= tol:
            row_computed_status = "entropy_ordered_split_tensor_row_finite_object"
        elif not math.isfinite(js):
            row_computed_status = "history_measure_unavailable_for_split_control"
        elif gain > tol:
            row_computed_status = "split_residual_with_record_tracking_gain_observed"
        else:
            row_computed_status = "split_residual_without_record_tracking_gain_control"
        rows.append({
            "branching": r.get("branching"),
            "level": r.get("level"),
            "mode": r.get("mode"),
            "region_id": r.get("region_id"),
            "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "refined_split_layer": r.get("refined_split_layer"),
            "history_measure_used": "JS_live_record_no_epsilon",
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "refined_tensor_dimension_residual": residual,
            "split_residual_per_history_js": per_js,
            "max_relative_commutator": r.get("max_relative_commutator"),
            "source_refined_split_row_computed_status": r.get("refined_split_row_computed_status"),
            "source_refined_split_track_computed_status": r.get("refined_split_track_computed_status"),
            "entropy_ordered_split_row_computed_status": row_computed_status,
        })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        tracks[_track_key(row)].append(row)
    summaries = {k: _summarize_track(v, tol) for k, v in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def entropy_ordered_split_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("entropy_ordered_split_track_computed_status", "unknown")) for r in rows if "entropy_ordered_split_track_computed_status" in r})
    return (
        "# Entropy-ordered split/collar derived_quantity rows\n\n"
        "This surface scales finite refined-basis split residuals by `JS(live,record)`.  "
        "It keeps split as a finite rank_bound unless tensor-dimension residuals actually decrease with collar width after history-measure normalization.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
