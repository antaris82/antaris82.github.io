from __future__ import annotations

from collections import Counter
from typing import List


def signature_strength_geometry_summary_rows(component_rows: List[dict], geometry_rows: List[dict], flow_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    comp = Counter(str(r.get("component_dominance", "unknown")) for r in component_rows)
    geo = Counter(str(r.get("component_explanation", "unknown")) for r in geometry_rows)
    flow = Counter(str(r.get("decomposed_entropy_flow_computed_status", "unknown")) for r in flow_rows)
    for k, v in sorted(comp.items()):
        rows.append({"summary_surface": "decomposed_measure_component_dominance", "category": k, "count": int(v)})
    for k, v in sorted(geo.items()):
        rows.append({"summary_surface": "geometry_component_explanation", "category": k, "count": int(v)})
    for k, v in sorted(flow.items()):
        rows.append({"summary_surface": "entropy_flow_component_computed_status", "category": k, "count": int(v)})
    return rows


def signature_strength_geometry_summary_report(rows: List[dict]) -> str:
    return (
        "# Signature-vs-strength geometry summary\n\n"
        "This summary collects component dominance, geometry explanations, and decomposed entropy-flow computed_status_rows.  It is meant to show which finite rank_bounds are tied to density/support, which to normalized F1/F2 orientation, and which only to F1/F2 response-strength weighting.\n\n"
        f"Rows: {len(rows)}.\n"
    )
