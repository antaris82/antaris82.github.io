from __future__ import annotations

import math
from typing import Dict, List

from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    regional_response,
    sibling_pair_regions,
)


def state_physical_role(state: str) -> str:
    s = str(state)
    if s == "live":
        return "reference_physics_state"
    if s == "record":
        return "historical_birth_record_control_state"
    if s == "sym":
        return "null_symmetry_control_state"
    return "unknown_state_role"


def property_statement_scope(state: str) -> str:
    role = state_physical_role(state)
    if role == "reference_physics_state":
        return "finite_property_comparisons_are_physically_read_on_live"
    if role == "historical_birth_record_control_state":
        return "record_is_history_derived_quantity_not_independent_physics_state"
    if role == "null_symmetry_control_state":
        return "sym_is_null_counterfactual_control_not_physics_state"
    return "unknown_scope"


def support_loss_interpretation(state: str, support_rank: int, ambient_dim: int) -> str:
    if int(ambient_dim) <= 0:
        return "support_scope_unavailable"
    full = int(support_rank) >= int(ambient_dim)
    role = state_physical_role(state)
    if role == "reference_physics_state":
        return "live_full_support_physics_carrier" if full else "live_support_loss_physics_rank_bound_finite_object"
    if role == "historical_birth_record_control_state":
        return "record_full_support_history_control" if full else "historical_record_support_loss_expected_control"
    if role == "null_symmetry_control_state":
        return "sym_full_support_null_control" if full else "sym_support_loss_null_control"
    return "unknown_support_scope"


def state_relations_fields(state: str, support_rank: int | None = None, ambient_dim: int | None = None) -> Dict[str, object]:
    fields: Dict[str, object] = {
        "observable_state_role": state_physical_role(state),
        "property_statement_scope": property_statement_scope(state),
        "physics_state_priority": 0 if str(state) == "live" else (1 if str(state) == "record" else 2),
        "live_reference_relations": "live_reference_record_history_B_current",
    }
    if support_rank is not None and ambient_dim is not None:
        fields["support_loss_interpretation"] = support_loss_interpretation(state, int(support_rank), int(ambient_dim))
    return fields


def observable_state_rows_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            for state in config.states:
                resp = regional_response(model, spec, state)
                base = {
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    "region_id": spec.region_id,
                    "state": state,
                    **state_relations_fields(state),
                    "observable_layer_relations": "S=symmetric_response_carrier; A=live_directed_orientation; record=provenance_birth_snapshot; B=live_minus_record_backreaction_current; sym=null_counterfactual_control",
                }
                if resp is None:
                    base.update({
                        "density_ambient_dim": 0,
                        "density_support_rank": 0,
                        "support_loss_interpretation": "response_unavailable",
                        "observable_state_rows_row_computed_status": "response_unavailable",
                    })
                else:
                    meta = resp.density_metadata
                    ambient = int(meta.get("density_ambient_dim", resp.Lambda_role.shape[0]) or 0)
                    support = int(meta.get("density_support_rank", 0) or 0)
                    base.update({
                        "density_ambient_dim": ambient,
                        "density_support_rank": support,
                        "density_computed_status": meta.get("density_computed_status", "unknown"),
                        "support_loss_interpretation": support_loss_interpretation(state, support, ambient),
                        "observable_state_rows_row_computed_status": property_statement_scope(state),
                    })
                rows.append(base)
    return rows


def observable_state_rows_report(rows: List[dict]) -> str:
    roles = sorted({str(r.get("observable_state_role", "unknown")) for r in rows})
    scopes = sorted({str(r.get("property_statement_scope", "unknown")) for r in rows})
    support = sorted({str(r.get("support_loss_interpretation", "unknown")) for r in rows})
    return (
        "# Observable relations\n\n"
        "This table fixes the live-reference interpretation used by the 5 property-comparison layer.  "
        "`live` is the reference physical response network, `record` is a fixed provenance/birth snapshot, "
        "`B = live - record` is a backreaction/history current, and `sym` is a null symmetry control.  "
        "Record support loss is therefore classified as historical incompleteness unless an explicit record-anchor condition is being tested.\n\n"
        "State roles: `" + "`, `".join(roles) + "`.\n\n"
        "Statement scopes: `" + "`, `".join(scopes) + "`.\n\n"
        "Support interpretations: `" + "`, `".join(support) + "`.\n"
    )
