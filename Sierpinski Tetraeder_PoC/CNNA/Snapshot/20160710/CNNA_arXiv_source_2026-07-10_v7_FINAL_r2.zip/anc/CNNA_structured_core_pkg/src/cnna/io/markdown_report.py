"""Markdown report helpers live in cnna.derived_quantities.computed_status_rows for CNNA_structure_1.
This module is reserved for CNNA_structure_2 IO consistency.
"""
