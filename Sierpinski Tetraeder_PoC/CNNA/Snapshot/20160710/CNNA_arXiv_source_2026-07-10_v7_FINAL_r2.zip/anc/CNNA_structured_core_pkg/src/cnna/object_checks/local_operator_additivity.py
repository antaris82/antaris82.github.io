from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    joined_algebra,
    local_operator_algebras,
    max_span_residual,
    max_star_residual,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


UNION_FINITE_OBJECTS = [
    ("left_birth_cone_response", "right_birth_cone_response", None, "sibling_pair_response", "two_sibling_cones_without_boundary_anchor"),
    ("left_birth_cone_response", "right_birth_cone_response", "root_anchor_response", "sibling_pair_response", "two_sibling_cones_with_required_lca_anchor"),
    ("left_frontier_response", "right_frontier_response", None, "sibling_pair_response", "frontiers_without_boundary_anchor"),
    ("left_frontier_response", "right_frontier_response", "root_anchor_response", "sibling_pair_response", "frontiers_with_required_lca_anchor"),
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "root_anchor_response", "positive_carrier_pair_response", "S_layer_birth_cones_with_lca_anchor"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "root_anchor_response", "directed_current_pair_response", "A_layer_birth_cones_with_lca_anchor"),
]


def _computed_status(target_to_join: float, join_to_target: float, dim_delta: int, tol: float, anchor_used: bool) -> str:
    if target_to_join <= tol and join_to_target <= tol and dim_delta == 0:
        return "additivity_with_required_boundary_anchor" if anchor_used else "additivity_without_boundary_anchor"
    if anchor_used and target_to_join <= 1.0e-7:
        return "boundary_anchor_repairs_target_generation"
    if (not anchor_used) and target_to_join <= 1.0e-7:
        return "additivity_without_anchor_span_finite_object"
    if target_to_join <= 1.0e-6 or join_to_target <= 1.0e-6:
        return "span_additivity_only"
    return "additivity_failed"


def local_operator_additivity_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "additivity_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                for left_name, right_name, anchor_name, target_name, sign_relation in UNION_FINITE_OBJECTS:
                    parts = [algebras[left_name], algebras[right_name]]
                    anchor_used = anchor_name is not None
                    if anchor_used:
                        parts.append(algebras[anchor_name])
                    join = joined_algebra("generated_union_" + sign_relation, parts, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    target = algebras[target_name]
                    target_to_join = max_span_residual(target.basis, join.basis)
                    join_to_target = max_span_residual(join.basis, target.basis)
                    star_error = max_star_residual(join.basis, target.basis)
                    dim_delta = int(len(target.basis) - len(join.basis))
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "boundary_anchor_used": int(anchor_used),
                        "boundary_anchor_system": "none" if anchor_name is None else anchor_name,
                        "target_union_system": target_name,
                        "generated_union_dim": len(join.basis),
                        "target_union_dim": len(target.basis),
                        "target_minus_generated_dim": dim_delta,
                        "missing_target_generator_count_lower_bound": max(0, dim_delta),
                        "generated_extra_dim_lower_bound": max(0, -dim_delta),
                        "target_to_generated_span_residual": target_to_join,
                        "generated_to_target_span_residual": join_to_target,
                        "generated_star_to_target_residual": star_error,
                        "additivity_sign_relation": sign_relation,
                        "additivity_computed_status": _computed_status(target_to_join, join_to_target, dim_delta, config.algebra_tol, anchor_used),
                    })
    return rows


def additivity_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("additivity_computed_status", "unknown")) for r in rows})
    return "# Finite local-operator additivity report\n\nMeasurements whether sibling-union operator systems are generated by their parts.  The LCA/root anchor is treated as an explicit boundary condition, not as a free helper; computed_status_rows distinguish additivity without anchor from additivity repaired by a required boundary anchor.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
