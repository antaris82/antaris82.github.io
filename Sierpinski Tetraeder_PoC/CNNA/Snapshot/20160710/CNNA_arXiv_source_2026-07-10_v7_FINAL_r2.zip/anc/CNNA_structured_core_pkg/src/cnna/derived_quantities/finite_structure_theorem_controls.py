from __future__ import annotations

import itertools
import math
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.core.directed_dtn import (
    build_coarse_frontier_sibling_regions,
    j_finite_object_from_SA,
)
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import fro
from cnna.core.projective_maps import prefix, push_forward, terminal_carrier
from cnna.core.schur_dtn import build_sibling_regions, schur_response_from_model
from cnna.derived_quantities.directed_current_transport import _boundary_prefix_transport_matrix
from cnna.derived_quantities.gns_cyclicity_controls import finite_gns_cyclicity_control_rows


def _growth_signature(model: EmptySetGrowthModel) -> tuple:
    nodes = tuple(
        (
            n.nid,
            n.address,
            n.level,
            n.parent,
            n.birth_time,
            n.sibling_rank,
            n.causal_depth,
            n.linearization_index,
            n.g,
            n.birth_g,
            n.lapse_weight,
            tuple(n.children),
            tuple(sorted(n.child_by_rank.items())),
        )
        for n in model.nodes
    )
    events = tuple(
        (
            e.event_id,
            e.kind,
            e.parent,
            e.child,
            e.address,
            e.level,
            e.causal_depth,
            e.sibling_rank,
            e.linearization_index,
            e.occupied_siblings_before,
            e.ancestors,
            e.env_load,
            e.birth_g,
            e.lapse_weight,
            e.saturation_before,
            e.saturation_after,
        )
        for e in model.events
    )
    live = tuple(sorted(model.live_edges.items()))
    record = tuple(sorted(model.record_edges.items()))
    return nodes, events, live, record


def _expected_addresses(branching: int, max_level: int) -> set[Tuple[int, ...]]:
    out: set[Tuple[int, ...]] = set()
    for depth in range(max_level + 1):
        out.update(tuple(word) for word in itertools.product(range(branching), repeat=depth))
    return out


def growth_well_defined_control() -> dict:
    configurations = 0
    exact_replays = 0
    address_failures = 0
    parent_failures = 0
    nonfinite_failures = 0
    for b in (2, 3):
        for L in (0, 1, 2, 3):
            for mode in ("linear", "log", "saturating"):
                for schedule in ("slot_step", "layer_batch"):
                    for linearization in ("rank", "reverse_rank"):
                        configurations += 1
                        first = EmptySetGrowthModel(
                            b,
                            L,
                            mode=mode,
                            sibling_linearization=linearization,
                            growth_schedule=schedule,
                        )
                        second = EmptySetGrowthModel(
                            b,
                            L,
                            mode=mode,
                            sibling_linearization=linearization,
                            growth_schedule=schedule,
                        )
                        exact_replays += int(_growth_signature(first) == _growth_signature(second))
                        addresses = {n.address for n in first.nodes}
                        if addresses != _expected_addresses(b, L) or len(addresses) != first.node_count_expected():
                            address_failures += 1
                        for node in first.nodes:
                            if node.address == tuple():
                                if node.parent is not None:
                                    parent_failures += 1
                            else:
                                expected_parent = first.addr_to_id.get(node.address[:-1])
                                if node.parent != expected_parent:
                                    parent_failures += 1
                        scalars = [n.g for n in first.nodes] + [n.birth_g for n in first.nodes] + [n.lapse_weight for n in first.nodes]
                        scalars += list(first.live_edges.values()) + list(first.record_edges.values())
                        if not all(math.isfinite(float(x)) for x in scalars):
                            nonfinite_failures += 1
    passed = int(
        exact_replays == configurations
        and address_failures == 0
        and parent_failures == 0
        and nonfinite_failures == 0
    )
    return {
        "control": "growth_well_defined_finite_replay",
        "pass": passed,
        "configurations": configurations,
        "exact_replays": exact_replays,
        "address_failures": address_failures,
        "parent_failures": parent_failures,
        "nonfinite_failures": nonfinite_failures,
        "statement_scope": "fixed_finite_inputs_and_fixed_binary64_environment",
    }


def symmetric_schur_positivity_control(tol: float = 1.0e-10) -> dict:
    rows = 0
    response_failures = 0
    symmetry_failures = 0
    psd_failures = 0
    positive_definite_rows = 0
    min_eig = math.inf
    max_symmetry_error = 0.0
    for schedule in ("slot_step", "layer_batch"):
        for mode in ("linear", "log", "saturating"):
            model = EmptySetGrowthModel(3, 3, mode=mode, growth_schedule=schedule)
            regions = build_sibling_regions(model, max_regions=2)
            for state in ("live", "record", "sym"):
                for region in regions:
                    rows += 1
                    response = schur_response_from_model(model, state, region.boundary, region.interior)
                    if not response.ok or response.Lambda is None:
                        response_failures += 1
                        continue
                    symmetry_error = fro(response.Lambda - response.Lambda.T) / max(1.0, fro(response.Lambda))
                    max_symmetry_error = max(max_symmetry_error, symmetry_error)
                    if symmetry_error > tol:
                        symmetry_failures += 1
                    eigenvalues = np.linalg.eigvalsh(0.5 * (response.Lambda + response.Lambda.T))
                    current_min = float(np.min(eigenvalues)) if eigenvalues.size else math.inf
                    min_eig = min(min_eig, current_min)
                    if current_min < -tol:
                        psd_failures += 1
                    if current_min > tol:
                        positive_definite_rows += 1
    passed = int(response_failures == 0 and symmetry_failures == 0 and psd_failures == 0 and rows > 0)
    return {
        "control": "symmetric_schur_psd",
        "pass": passed,
        "rows": rows,
        "response_failures": response_failures,
        "symmetry_failures": symmetry_failures,
        "psd_failures": psd_failures,
        "positive_definite_rows": positive_definite_rows,
        "minimum_eigenvalue": min_eig,
        "maximum_symmetry_error": max_symmetry_error,
        "statement_scope": "sampled_open_grounded_symmetric_responses",
    }


def gns_quotient_control() -> dict:
    controls = finite_gns_cyclicity_control_rows()
    passed_rows = sum(int(row.get("control_pass", 0) or 0) for row in controls)
    positive = sum(int(row.get("expected_cyclic_for_global_support", 0) or 0) == 1 for row in controls)
    negative = sum(int(row.get("expected_cyclic_for_global_support", 0) or 0) == 0 for row in controls)
    return {
        "control": "finite_gns_quotient_and_cyclicity",
        "pass": int(bool(controls) and passed_rows == len(controls) and positive > 0 and negative > 0),
        "rows": len(controls),
        "passed_rows": passed_rows,
        "positive_controls": positive,
        "negative_controls": negative,
        "statement_scope": "finite_matrix_star_algebras_with_explicit_density",
    }


def orientation_flip_control(tol: float = 1.0e-10) -> dict:
    S = np.diag([2.0, 3.0, 1.0])
    A = np.array([[0.0, -2.0, 0.0], [2.0, 0.0, 0.0], [0.0, 0.0, 0.0]], dtype=float)
    J_plus, info_plus = j_finite_object_from_SA(S, A, tol=tol)
    J_minus, info_minus = j_finite_object_from_SA(S, -A, tol=tol)
    if J_plus is None or J_minus is None:
        return {
            "control": "finite_J_sign_reversal_equivariance",
            "pass": 0,
            "available_plus": int(J_plus is not None),
            "available_minus": int(J_minus is not None),
            "statement_scope": "polar_partial_isometry_on_resolved_skew_support",
        }
    sign_flip_error = fro(J_minus + J_plus) / max(1.0, fro(J_plus))
    square_error_difference = abs(
        float(info_plus.get("J_square_minus_negative_projector_error", math.inf))
        - float(info_minus.get("J_square_minus_negative_projector_error", math.inf))
    )
    singular_plus = np.linalg.svd(np.diag([1.0 / math.sqrt(2.0), 1.0 / math.sqrt(3.0), 1.0]) @ A @ np.diag([1.0 / math.sqrt(2.0), 1.0 / math.sqrt(3.0), 1.0]), compute_uv=False)
    singular_minus = np.linalg.svd(np.diag([1.0 / math.sqrt(2.0), 1.0 / math.sqrt(3.0), 1.0]) @ (-A) @ np.diag([1.0 / math.sqrt(2.0), 1.0 / math.sqrt(3.0), 1.0]), compute_uv=False)
    singular_value_error = float(np.max(np.abs(singular_plus - singular_minus)))
    passed = int(
        int(info_plus.get("available", 0) or 0) == 1
        and int(info_minus.get("available", 0) or 0) == 1
        and sign_flip_error <= 100.0 * tol
        and square_error_difference <= 100.0 * tol
        and singular_value_error <= 100.0 * tol
    )
    return {
        "control": "finite_J_sign_reversal_equivariance",
        "pass": passed,
        "sign_flip_error": sign_flip_error,
        "square_error_difference": square_error_difference,
        "singular_value_error": singular_value_error,
        "skew_rank_plus": int(info_plus.get("skew_rank", 0) or 0),
        "skew_rank_minus": int(info_minus.get("skew_rank", 0) or 0),
        "statement_scope": "sign_even_diagnostics_do_not_select_between_J_and_minus_J",
    }


def backreaction_separation_control(tol: float = 1.0e-12) -> dict:
    J = np.array([[0.0, -1.0], [1.0, 0.0]], dtype=float)
    A_live = J
    A_record = -J
    B = A_live - A_record
    beta = fro(A_live) - fro(A_record)
    e1 = np.array([1.0, 0.0])
    e2 = np.array([0.0, 1.0])
    omega = float(e1 @ B @ e2)
    b_norm = fro(B)
    passed = int(abs(beta) <= tol and b_norm > tol and abs(omega) > tol)
    return {
        "control": "backreaction_scalar_nonimplication",
        "pass": passed,
        "beta": beta,
        "B_frobenius_norm": b_norm,
        "omega": omega,
        "statement_scope": "beta_zero_does_not_imply_B_zero_or_omega_zero",
    }


def prefix_handoff_control(tol: float = 1.0e-12) -> dict:
    prefix_failures = 0
    for address in ((0, 1, 2, 0), (1, 0), tuple(), (2, 2, 1)):
        for source_level in range(0, len(address) + 1):
            for target_level in range(0, source_level + 1):
                if prefix(prefix(address, source_level), target_level) != prefix(address, target_level):
                    prefix_failures += 1

    distribution = {
        (0, 0, 0): 0.10,
        (0, 1, 1): 0.20,
        (1, 0, 1): 0.30,
        (1, 1, 0): 0.40,
    }
    direct = push_forward(distribution, 1)
    via = push_forward(push_forward(distribution, 2), 1)
    keys = sorted(set(direct) | set(via))
    pushforward_error = max((abs(float(direct.get(k, 0.0)) - float(via.get(k, 0.0))) for k in keys), default=0.0)

    carrier_error = 0.0
    carrier_cases = 0
    for b in (2, 3):
        source = EmptySetGrowthModel(b, 4, mode="linear", growth_schedule="layer_batch")
        for target_level in (0, 1, 2, 3):
            target = EmptySetGrowthModel(b, target_level, mode="linear", growth_schedule="layer_batch")
            predicted = push_forward(terminal_carrier(source), target_level)
            expected = terminal_carrier(target)
            all_keys = set(predicted) | set(expected)
            carrier_error = max(
                carrier_error,
                max((abs(float(predicted.get(k, 0.0)) - float(expected.get(k, 0.0))) for k in all_keys), default=0.0),
            )
            carrier_cases += 1

    models = {L: EmptySetGrowthModel(3, L, mode="linear", growth_schedule="layer_batch") for L in (4, 5, 6)}
    regions = {
        L: build_coarse_frontier_sibling_regions(
            models[L],
            max_regions=1,
            max_boundary=600,
            max_interior=900,
            max_frontier_level=6,
        )[0]
        for L in (4, 5, 6)
    }
    composition_errors: Dict[str, float] = {}
    unmapped_total = 0
    for weighting in ("fiber_sum", "fiber_average", "fiber_sqrt"):
        R46, _, u46, _ = _boundary_prefix_transport_matrix(models[6], regions[6].boundary, models[4], regions[4].boundary, weighting=weighting)
        R56, _, u56, _ = _boundary_prefix_transport_matrix(models[6], regions[6].boundary, models[5], regions[5].boundary, weighting=weighting)
        R45, _, u45, _ = _boundary_prefix_transport_matrix(models[5], regions[5].boundary, models[4], regions[4].boundary, weighting=weighting)
        unmapped_total += u46 + u56 + u45
        composition_errors[weighting] = fro(R46 - R45 @ R56) / max(1.0, fro(R46))

    maximum_composition_error = max(composition_errors.values(), default=math.inf)
    passed = int(
        prefix_failures == 0
        and pushforward_error <= tol
        and carrier_error <= tol
        and unmapped_total == 0
        and maximum_composition_error <= 100.0 * tol
    )
    return {
        "control": "finite_prefix_handoff",
        "pass": passed,
        "prefix_failures": prefix_failures,
        "pushforward_composition_error": pushforward_error,
        "terminal_carrier_error": carrier_error,
        "terminal_carrier_cases": carrier_cases,
        "boundary_transport_unmapped_total": unmapped_total,
        "fiber_sum_composition_error": composition_errors.get("fiber_sum", math.nan),
        "fiber_average_composition_error": composition_errors.get("fiber_average", math.nan),
        "fiber_sqrt_composition_error": composition_errors.get("fiber_sqrt", math.nan),
        "statement_scope": "exact_prefix_and_carrier_handoff_conditional_boundary_matrix_composition",
    }


def finite_structure_theorem_control_rows() -> List[dict]:
    return [
        growth_well_defined_control(),
        symmetric_schur_positivity_control(),
        gns_quotient_control(),
        orientation_flip_control(),
        backreaction_separation_control(),
        prefix_handoff_control(),
    ]
