from __future__ import annotations

import math
from typing import List, Sequence, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.directed_dtn import directed_schur_response_from_model, split_symmetric_skew
from cnna.core.math_utils import fro
from cnna.core.response_algebra import algebra_closure

from .history_live_common_measure import inherited_uniform_node_density_for_role_basis
from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.entropy_quantities import (
    jensen_shannon_divergence_no_epsilon,
    record_live_entropy_metrics,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.refined_port_basis import (
    refined_regional_response,
    refined_support_algebra,
)
from cnna.core.region_response import (
    positive_support_density_from_response,
    region_size_meta,
)


def _chunks(xs: Sequence[int], k: int) -> List[List[int]]:
    ys = list(dict.fromkeys(int(x) for x in xs))
    if not ys:
        return []
    k = max(1, min(int(k), len(ys)))
    out: List[List[int]] = []
    for i in range(k):
        a = (len(ys) * i) // k
        b = (len(ys) * (i + 1)) // k
        out.append(ys[a:b])
    return [x for x in out if x]


def _indicator(boundary: Sequence[int], members: Sequence[int]) -> np.ndarray:
    idx = {int(n): i for i, n in enumerate(boundary)}
    v = np.zeros(len(boundary), dtype=float)
    for n in members:
        j = idx.get(int(n))
        if j is not None:
            v[j] = 1.0
    n = float(np.linalg.norm(v))
    return v / n if n > EPS else v


def _multiscale_basis(spec, shell_count: int = 3) -> Tuple[np.ndarray, List[str], dict]:
    boundary = [int(x) for x in spec.boundary]
    groups: List[Tuple[str, List[int]]] = [("C_lca", [int(x) for x in spec.roles.get("C_lca", [spec.lca])])]
    for side, key in (("B1", "B1_front"), ("B2", "B2_front")):
        for i, chunk in enumerate(_chunks([int(x) for x in spec.roles.get(key, [])], shell_count)):
            groups.append((f"{side}_front_shell_{i+1}_of_{shell_count}", chunk))
    cols: List[np.ndarray] = []
    names: List[str] = []
    counts: List[int] = []
    for name, members in groups:
        v = _indicator(boundary, members)
        if float(np.linalg.norm(v)) > EPS:
            cols.append(v)
            names.append(name)
            counts.append(len(members))
    Q = np.column_stack(cols) if cols else np.zeros((len(boundary), 0), dtype=float)
    return Q, names, {
        "multiscale_port_basis_relations": "C_lca_plus_left_right_frontier_shells_from_uniform_node_order",
        "multiscale_shell_count_requested": int(shell_count),
        "multiscale_role_dim": int(Q.shape[1]),
        "multiscale_role_names": "|".join(names),
        "multiscale_role_node_counts": "|".join(str(int(c)) for c in counts),
    }


def _response(model, spec, state: str, *, shell_count: int, tol: float):
    res = directed_schur_response_from_model(model, state, spec.boundary, spec.interior, cond_max=1.0e12, include_external_degrees=True, matrix_sign_relation="out_degree")
    if not res.ok or res.Lambda is None:
        return None
    Q, names, meta = _multiscale_basis(spec, shell_count=shell_count)
    if Q.size == 0 or Q.shape[1] == 0:
        return None
    Lc = Q.T @ res.Lambda @ Q
    S, A = split_symmetric_skew(Lc)
    D, Dmeta = positive_support_density_from_response(Lc, tol=tol)
    return {"Lambda_role": Lc, "S": S, "A": A, "density": D, "names": names, "basis_meta": meta, "density_meta": Dmeta}


def _simple_side_dim(resp: dict, side: str, layer: str, tol: float, max_iter: int) -> int:
    names = [n.lower() for n in resp["names"]]
    root = [i for i, n in enumerate(names) if "lca" in n]
    left = [i for i, n in enumerate(names) if "b1" in n or "left" in n]
    right = [i for i, n in enumerate(names) if "b2" in n or "right" in n]
    idx = root + (left if side == "left" else right)
    idx = list(dict.fromkeys(i for i in idx if 0 <= i < len(names)))
    d = len(names)
    P = np.zeros((d, d), dtype=float)
    for i in idx:
        P[i, i] = 1.0
    gens = [np.eye(d)]
    for i in idx:
        E = np.zeros((d, d), dtype=float); E[i, i] = 1.0; gens.append(E)
    if layer in {"S", "mixed"}:
        gens.append(P @ resp["S"] @ P)
    if layer in {"A", "mixed"}:
        X = P @ resp["A"] @ P
        if float(fro(X)) > max(tol, tol * max(1.0, float(fro(resp["S"])))):
            gens.append(X)
    return len(algebra_closure(f"multiscale_{side}_{layer}", gens, tol=tol, max_iter=max_iter).basis)


def multiscale_port_entropy_resolution_rows(config: OperatorTestConfig) -> List[dict]:
    """Implement a more explicit finite multi-shell port basis and test it by the 7 measure."""
    rows: List[dict] = []
    shell_count = 3
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _response(model, spec, "live", shell_count=shell_count, tol=config.algebra_tol)
            record = _response(model, spec, "record", shell_count=shell_count, tol=config.algebra_tol)
            ref = refined_regional_response(model, spec, "live")
            if live is None or record is None or ref is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, "multiscale_entropy_resolution_computed_status": "response_unavailable"})
                continue
            js, _m = jensen_shannon_divergence_no_epsilon(live["density"], record["density"], config.algebra_tol)
            uniform, umeta = inherited_uniform_node_density_for_role_basis(live["names"], {name: [] for name in live["names"]}, tol=config.algebra_tol)
            # Replace fallback uniform with role-count uniform from basis metadata where available.
            counts = [int(x) for x in str(live["basis_meta"].get("multiscale_role_node_counts", "")).split("|") if x != ""]
            if counts and sum(counts) > 0 and len(counts) == len(live["names"]):
                uniform = np.diag(np.array(counts, dtype=float) / float(sum(counts)))
            js_uniform, _ = jensen_shannon_divergence_no_epsilon(live["density"], uniform, config.algebra_tol)
            gain = float(js_uniform - js) if math.isfinite(js_uniform) and math.isfinite(js) else math.nan
            refined_left_dim = len(refined_support_algebra(ref, "left", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter).basis)
            refined_right_dim = len(refined_support_algebra(ref, "right", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter).basis)
            ms_left_dim = _simple_side_dim(live, "left", "mixed", config.algebra_tol, config.max_algebra_iter)
            ms_right_dim = _simple_side_dim(live, "right", "mixed", config.algebra_tol, config.max_algebra_iter)
            op_gain = int((ms_left_dim + ms_right_dim) - (refined_left_dim + refined_right_dim))
            if op_gain > 0 and gain > config.algebra_tol:
                computed_status = "multiscale_port_basis_increases_resolution_with_history_tracking_finite_object"
            elif op_gain > 0:
                computed_status = "multiscale_port_basis_increases_resolution_without_history_gain_control"
            else:
                computed_status = "multiscale_port_basis_no_extra_operator_resolution_control"
            rows.append({
                "branching": b,
                "level": L,
                "mode": mode,
                **meta,
                **live["basis_meta"],
                "history_measure_used": "JS_live_record_no_epsilon_on_multiscale_basis",
                "JS_live_record_multiscale_no_epsilon": float(js) if math.isfinite(js) else math.inf,
                "JS_live_uniform_multiscale_no_epsilon": float(js_uniform) if math.isfinite(js_uniform) else math.inf,
                "record_tracking_gain_over_multiscale_uniform": gain,
                "refined_role_dim_reference": int(ref.Lambda_role.shape[0]),
                "multiscale_role_dim_gain_over_refined": int(live["Lambda_role"].shape[0] - ref.Lambda_role.shape[0]),
                "refined_left_right_mixed_dim_sum": int(refined_left_dim + refined_right_dim),
                "multiscale_left_right_mixed_dim_sum": int(ms_left_dim + ms_right_dim),
                "multiscale_operator_dim_gain_over_refined": op_gain,
                "multiscale_entropy_resolution_computed_status": computed_status,
            })
    return rows


def multiscale_port_entropy_resolution_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("multiscale_entropy_resolution_computed_status", "unknown")) for r in rows})
    return (
        "# Multiscale port-basis entropy resolution\n\n"
        "This surface addresses the finite 3-role compression rank_bound by introducing a test-only multi-shell boundary-port basis.  "
        "It uses the 7 history/live measure to check whether additional operator resolution also preserves nontrivial record tracking over inherited uniform node count.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
