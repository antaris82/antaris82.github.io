from __future__ import annotations

from typing import List

from cnna.core.algebra_support import local_operator_algebras
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


def _scope(meta: dict) -> str:
    computed_status = str(meta.get("density_computed_status", "unknown"))
    if computed_status == "full_support_state_without_epsilon_floor":
        return "full_ambient_role_state"
    if computed_status == "singular_support_state":
        return "support_level_state_only"
    if computed_status == "zero_positive_response_support":
        return "no_positive_gns_support"
    return "state_construction_unresolved"


def _condition_not_met(meta: dict) -> str:
    neg = int(meta.get("density_negative_eigenvalue_count", 0) or 0)
    support = int(meta.get("density_support_rank", 0) or 0)
    ambient = int(meta.get("density_ambient_dim", 0) or 0)
    if support <= 0:
        return "no_positive_support_all_operator_statements_blocked"
    if support < ambient and neg > 0:
        return "singular_support_with_negative_symmetric_response_clipping"
    if support < ambient:
        return "singular_support_read_all_conditions_on_support_only"
    if neg > 0:
        return "full_rank_after_negative_clipping_check_boundary_response_model"
    return "full_support_no_epsilon_floor"


def support_state_summary_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "state_scope_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                ambient_dim = int(resp.density_metadata.get("density_ambient_dim", resp.Lambda_role.shape[0]))
                support_rank = int(resp.density_metadata.get("density_support_rank", 0))
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "state": state,
                    **resp.density_metadata,
                    "state_statement_scope": _scope(resp.density_metadata),
                    "support_residual_dim": int(max(0, ambient_dim - support_rank)),
                    "support_fraction": float(support_rank / ambient_dim) if ambient_dim else 0.0,
                    "state_scope_condition_not_met": _condition_not_met(resp.density_metadata),
                    "full_regional_algebra_dim": len(algebras["full_regional_response"].basis),
                    "sibling_pair_algebra_dim": len(algebras["sibling_pair_response"].basis),
                    "directed_current_pair_algebra_dim": len(algebras["directed_current_pair_response"].basis),
                    "interpretation_rule": "full ambient statements allowed only for full-support state; otherwise all faithfulness/cyclicity/Tomita computed_status_rows are support-level finite derived_quantity rows",
                    "state_scope_computed_status": _scope(resp.density_metadata),
                })
    return rows


def support_state_summary_report(rows: List[dict]) -> str:
    scopes = sorted({str(r.get("state_statement_scope", r.get("state_scope_computed_status", "unknown"))) for r in rows})
    conditions_not_met = sorted({str(r.get("state_scope_condition_not_met", "unknown")) for r in rows if "state_scope_condition_not_met" in r})
    return "# Support-vs-full-state summary\n\nSummarizes the reference no-epsilon GNS support used by the finite local-operator comparisons.  Rows with singular support are not full ambient-algebra statements; they are support-level derived_quantity rows.  Negative raw eigenvalues are clipped only to form the positive support and are reported as response-relations conditions_not_met, not hidden regularization.\n\nObserved state scopes: `" + "`, `".join(scopes) + "`.\n\nObserved conditions_not_met: `" + "`, `".join(conditions_not_met) + "`.\n"
