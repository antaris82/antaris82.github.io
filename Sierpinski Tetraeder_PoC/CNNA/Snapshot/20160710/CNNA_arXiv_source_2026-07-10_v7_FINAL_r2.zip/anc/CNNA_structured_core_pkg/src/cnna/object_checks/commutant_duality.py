from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    basis_to_algebra,
    commutant_algebra_basis,
    local_operator_algebras,
    max_span_residual,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


DUALITY_FINITE_OBJECTS = [
    ("left_frontier_response", "right_frontier_response", "frontier_sibling_complement"),
    ("left_birth_cone_response", "right_birth_cone_response", "birth_cone_sibling_complement"),
    ("positive_carrier_pair_response", "directed_current_pair_response", "carrier_current_complement_proxy"),
]


def _computed_status(complement_to_commutant: float, commutant_to_complement: float, dim_delta: int, tol: float) -> str:
    if complement_to_commutant <= tol and commutant_to_complement <= tol and dim_delta == 0:
        return "finite_Haag_duality_preform_finite_object"
    if complement_to_commutant <= 1.0e-7:
        return "one_sided_commutant_inclusion"
    if dim_delta > 0:
        return "commutant_too_large_for_chosen_complement"
    return "duality_preform_failed"


def commutant_duality_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "duality_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                dim = int(resp.Lambda_role.shape[0])
                for region_name, complement_name, sign_relation in DUALITY_FINITE_OBJECTS:
                    region_alg = algebras[region_name]
                    complement_alg = algebras[complement_name]
                    comm_basis = commutant_algebra_basis(region_alg, dim, config.rank_tol)
                    comm_alg = basis_to_algebra(region_name + "_commutant", comm_basis)
                    comp_to_comm = max_span_residual(complement_alg.basis, comm_alg.basis)
                    comm_to_comp = max_span_residual(comm_alg.basis, complement_alg.basis)
                    dim_delta = int(len(comm_alg.basis) - len(complement_alg.basis))
                    residual_tol = max(float(config.algebra_tol), float(config.rank_tol))
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        "region_operator_system": region_name,
                        "complement_operator_system": complement_name,
                        "complement_sign_relation": sign_relation,
                        "region_dim": len(region_alg.basis),
                        "chosen_complement_dim": len(complement_alg.basis),
                        "computed_commutant_dim": len(comm_alg.basis),
                        "commutant_minus_complement_dim": dim_delta,
                        "commutant_basis_rank_tol": float(config.rank_tol),
                        "duality_residual_computed_status_tol": float(residual_tol),
                        "complement_to_commutant_residual": comp_to_comm,
                        "commutant_to_complement_residual": comm_to_comp,
                        "duality_computed_status": _computed_status(comp_to_comm, comm_to_comp, dim_delta, residual_tol),
                    })
    return rows


def commutant_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("duality_computed_status", "unknown")) for r in rows})
    return "# Finite commutant-duality report\n\nMeasurements finite commutants for explicit sibling-complement sign_relations.  This is a matrix commutant preform only; commutant-basis rank tolerance and residual computed_status tolerance are reported explicitly; it does not statement Haag duality for a continuum causal complement.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
