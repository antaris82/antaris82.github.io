from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    gns_cyclic_rank,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


CYCLICITY_DIMENSION_SYSTEMS = [
    "root_anchor_response",
    "left_frontier_response",
    "right_frontier_response",
    "left_birth_cone_response",
    "right_birth_cone_response",
    "sibling_pair_response",
    "full_regional_response",
]


def cyclicity_dimension_rank_bound_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "dimension_rank_bound_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                global_alg = algebras["full_regional_response"]
                for name in CYCLICITY_DIMENSION_SYSTEMS:
                    alg = algebras[name]
                    cyclic_rank, support_dim = gns_cyclic_rank(alg, global_alg, resp.density, config.rank_tol)
                    local_dim = len(alg.basis)
                    ambient_saturated = int(local_dim >= int(resp.Lambda_role.shape[0] ** 2))
                    no_go = int(local_dim < support_dim)
                    if no_go:
                        computed_status = "proper_subalgebra_cyclicity_dimension_impossible_finite"
                    elif int(cyclic_rank) == int(support_dim) and not ambient_saturated:
                        computed_status = "proper_subalgebra_cyclicity_not_dimension_obstructed_finite_object"
                    elif ambient_saturated and int(cyclic_rank) == int(support_dim):
                        computed_status = "ambient_saturation_cyclicity_control"
                    else:
                        computed_status = "cyclicity_not_dimension_obstructed_but_failed"
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        "local_operator_system": name,
                        "local_algebra_dim": local_dim,
                        "global_algebra_dim": len(global_alg.basis),
                        "gns_support_dim": support_dim,
                        "cyclic_rank": cyclic_rank,
                        "dimension_upper_bound_for_cyclic_rank": local_dim,
                        "finite_dimension_no_go_applies": no_go,
                        "ambient_saturated_at_closure": ambient_saturated,
                        "dimension_rank_bound_computed_status": computed_status,
                    })
    return rows


def cyclicity_dimension_rank_bound_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("dimension_rank_bound_computed_status", "unknown")) for r in rows})
    return "# Finite cyclicity dimension-rank_bound report\n\nRecords the elementary finite-rank rank_bound behind the failed proper-subalgebra Reeh-Schlieder preform: a local algebra of dimension d cannot generate a GNS support of dimension greater than d by row-rank.  This is a finite no-go/control surface, not a negative physical property about the inductive limit.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
