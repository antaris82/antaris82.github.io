from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.derived_quantities.baseline import *
from cnna.derived_quantities.structural_ledgers import *

@dataclass
class FullRegionData:
    b: int
    L: int
    mode: str
    state: str
    spec: RegionSpec
    role_dim: int
    Lc: np.ndarray
    D: np.ndarray
    gens: Dict[str, np.ndarray]
    algebras: Tuple[AlgebraBasis, AlgebraBasis, AlgebraBasis]
    gns: Dict[str, GNSData]


def build_first_region_data(model: EmptySetGrowthModel, state: str, args) -> Optional[FullRegionData]:
    for spec in build_sibling_regions(model, max_regions=max(1, args.max_regions)):
        if len(spec.boundary) > args.max_boundary or len(spec.interior) > args.max_interior:
            continue
        res = schur_response_from_model(model, state, spec.boundary, spec.interior)
        if not res.ok or res.Lambda is None:
            continue
        Q, _ = boundary_role_basis(model, spec)
        Lc = compress_response(res.Lambda, Q)
        D = positive_density_from_response(Lc)
        gens = gens_from_response(Lc)
        algs = build_algebras(gens, args.algebra_tol, args.algebra_max_iter)
        gns_map = {alg.name: measurement_gns(alg, D, args.gns_tol) for alg in algs}
        return FullRegionData(model.b, model.L, model.mode, state, spec, Lc.shape[0], Lc, D, gens, algs, gns_map)
    return None


def common_labels(dM: FullRegionData, dL: FullRegionData) -> List[str]:
    return [x for x in GEN_LABELS if x in dM.gens and x in dL.gens]


def _basis_matrix(gens: Dict[str, np.ndarray], labels: Sequence[str]) -> np.ndarray:
    if not labels:
        return np.zeros((0, 0), dtype=float)
    return np.column_stack([gens[x].reshape(-1) for x in labels])


def project_to_label_span(X: np.ndarray, gens: Dict[str, np.ndarray], labels: Sequence[str]) -> np.ndarray:
    if not labels:
        return np.zeros(0, dtype=float)
    B = _basis_matrix(gens, labels)
    coeff, *_ = np.linalg.lstsq(B, X.reshape(-1), rcond=None)
    return coeff


def reconstruct_from_labels(coeff: np.ndarray, gens: Dict[str, np.ndarray], labels: Sequence[str]) -> np.ndarray:
    if not labels:
        # The caller should not use this for empty labels.
        return np.zeros((0, 0), dtype=float)
    shape = next(iter(gens.values())).shape
    Y = np.zeros(shape, dtype=float)
    for c, label in zip(coeff, labels):
        Y += float(c) * gens[label]
    return Y


def pi_role_project(X_M: np.ndarray, dM: FullRegionData, dL: FullRegionData, labels: Sequence[str]) -> np.ndarray:
    coeff = project_to_label_span(X_M, dM.gens, labels)
    return reconstruct_from_labels(coeff, dL.gens, labels)


def role_projection_residual(X_M: np.ndarray, dM: FullRegionData, labels: Sequence[str]) -> float:
    if not labels:
        return math.inf
    coeff = project_to_label_span(X_M, dM.gens, labels)
    Xhat = reconstruct_from_labels(coeff, dM.gens, labels)
    return fro(X_M - Xhat) / max(fro(X_M), EPS)


def matrix_log_spd(D: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    vals, U = np.linalg.eigh(0.5 * (D + D.T))
    vals = np.maximum(vals, eps)
    return U @ np.diag(np.log(vals)) @ U.T


def commutator_delta(K: np.ndarray, X: np.ndarray) -> np.ndarray:
    return K @ X - X @ K


def center_expectation(X: np.ndarray) -> np.ndarray:
    d = X.shape[0]
    e0 = np.zeros(d, dtype=float)
    e0[0] = 1.0
    P = rank_one(e0)
    Q = np.eye(d) - P
    return P @ X @ P + Q @ X @ Q


def generator_list(gens: Dict[str, np.ndarray]) -> List[np.ndarray]:
    return [gens[k] for k in GEN_LABELS if k in gens]


def generator_gram(gens: Dict[str, np.ndarray], D: np.ndarray) -> Tuple[List[str], np.ndarray]:
    labels = [k for k in GEN_LABELS if k in gens]
    basis = [gens[k] for k in labels]
    return labels, state_gram(basis, D)


def interlevel_operator_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str], args) -> Tuple[List[dict], List[dict], List[dict], List[dict], List[dict]]:
    gns_rows: List[dict] = []
    alg_rows: List[dict] = []
    ce_rows: List[dict] = []
    mod_rows: List[dict] = []
    comp_rows: List[dict] = []
    data: Dict[Tuple[int, int, str, str], Optional[FullRegionData]] = {}
    for (b, L, mode, rev), m in sorted(models.items()):
        if rev:
            continue
        for st in states:
            data[(b, L, mode, st)] = build_first_region_data(m, st, args)

    pairs: List[Tuple[int, int]] = []
    for M in levels:
        for L in levels:
            if L < M:
                pairs.append((L, M))

    for b in sorted({k[0] for k in models.keys()}):
        for mode in args.modes:
            for st in states:
                for L, M in pairs:
                    dL = data.get((b, L, mode, st))
                    dM = data.get((b, M, mode, st))
                    base = {"branching": b, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "source_level": M, "target_level": L}
                    if dL is None or dM is None or dL.role_dim != dM.role_dim:
                        reason = "missing_region_data_or_role_dim_mismatch"
                        gns_rows.append({**base, "available": 0, "error": reason})
                        alg_rows.append({**base, "available": 0, "error": reason})
                        ce_rows.append({**base, "available": 0, "error": reason})
                        mod_rows.append({**base, "available": 0, "error": reason})
                        continue
                    labelsL, GL = generator_gram(dL.gens, dL.D)
                    labelsM, GM = generator_gram(dM.gens, dM.D)
                    labels = common_labels(dM, dL)
                    idxL = [labelsL.index(x) for x in labels]
                    idxM = [labelsM.index(x) for x in labels]
                    GLc = GL[np.ix_(idxL, idxL)] if labels else np.zeros((0,0))
                    GMc = GM[np.ix_(idxM, idxM)] if labels else np.zeros((0,0))
                    gram_err = fro(GLc - GMc) / max(fro(GLc), EPS)
                    cyc_err = fro(pi_role_project(dM.gens["I"], dM, dL, labels) - dL.gens["I"]) / max(fro(dL.gens["I"]), EPS) if "I" in labels else math.nan
                    valsL = np.linalg.eigvalsh(GLc) if GLc.size else np.array([])
                    valsM = np.linalg.eigvalsh(GMc) if GMc.size else np.array([])
                    rankL = int(np.sum(valsL > args.gns_tol)) if valsL.size else 0
                    rankM = int(np.sum(valsM > args.gns_tol)) if valsM.size else 0
                    gns_rows.append({
                        **base, "available": 1,
                        "map": "label_span_least_squares_role_projection_U_L_leftarrow_M",
                        "common_generator_count": len(labels),
                        "cyclic_vector_error": cyc_err,
                        "GNS_generator_Gram_relative_error": gram_err,
                        "rank_source": rankM, "rank_target": rankL,
                        "nullity_source": max(0, len(labels)-rankM), "nullity_target": max(0, len(labels)-rankL),
                        "nullspace_rank_drift": abs(rankM-rankL),
                        "computed_status": "GNS_U_map_available_with_quantified_Gram_drift" if len(labels) > 0 else "GNS_U_map_missing_generators",
                        "condition_note": "finite_generator_level_preHilbert_map_not_completed_GNS_limit; U_is_label_span_projection_not_identity_assertion",
                    })
                    Ierr = fro(pi_role_project(dM.gens["I"], dM, dL, labels) - dL.gens["I"]) / max(fro(dL.gens["I"]), EPS) if "I" in labels else math.inf
                    star_err = 0.0
                    star_projection_residual = 0.0
                    prod_err = 0.0
                    prod_projection_residual = 0.0
                    for x in labels[:8]:
                        XM = dM.gens[x]
                        PX = pi_role_project(XM, dM, dL, labels)
                        star_err = max(star_err, fro(pi_role_project(XM.T, dM, dL, labels) - PX.T) / max(fro(PX.T), EPS))
                        star_projection_residual = max(star_projection_residual, role_projection_residual(XM.T, dM, labels))
                        for y in labels[:8]:
                            XM, YM = dM.gens[x], dM.gens[y]
                            PX = pi_role_project(XM, dM, dL, labels)
                            PY = pi_role_project(YM, dM, dL, labels)
                            PXY = pi_role_project(XM @ YM, dM, dL, labels)
                            prod_err = max(prod_err, fro(PXY - PX @ PY) / max(fro(PX @ PY), EPS))
                            prod_projection_residual = max(prod_projection_residual, role_projection_residual(XM @ YM, dM, labels))
                    center_err = fro(pi_role_project(dM.gens["P_C"], dM, dL, labels) - dL.gens["P_C"]) / max(fro(dL.gens["P_C"]), EPS) if "P_C" in labels else math.inf
                    alg_rows.append({
                        **base, "available": 1,
                        "map": "label_span_least_squares_role_projection_Pi_L_leftarrow_M",
                        "unitality_error": Ierr,
                        "star_compatibility_error": star_err,
                        "star_projection_residual_source_span": star_projection_residual,
                        "product_morphism_residual": prod_err,
                        "product_projection_residual_source_span": prod_projection_residual,
                        "center_preservation_error": center_err,
                        "computed_status": "algebra_Pi_map_real_diagram_test_with_quantified_residual" if len(labels) > 0 else "algebra_Pi_map_missing_generators",
                        "condition_note": "not_yet_strict_star_hom_limit; product_star_CE_are_real_diagram_tests_not_self_subtractions",
                    })
                    ce_comm = 0.0
                    ce_projection_residual = 0.0
                    ce_state = 0.0
                    for x in labels[:10]:
                        XM = dM.gens[x]
                        EXM = center_expectation(XM)
                        left = center_expectation(pi_role_project(XM, dM, dL, labels))
                        right = pi_role_project(EXM, dM, dL, labels)
                        ce_comm = max(ce_comm, fro(left - right) / max(fro(left), EPS))
                        ce_projection_residual = max(ce_projection_residual, role_projection_residual(EXM, dM, labels))
                        ce_state = max(ce_state, abs(state_value(dL.D, center_expectation(dL.gens[x])) - state_value(dM.D, EXM)))
                    ce_rows.append({
                        **base, "available": 1,
                        "CE_map": "block_expectation_wrt_C_lca_role_projector",
                        "CE_commuting_square_error": ce_comm,
                        "CE_projection_residual_source_span": ce_projection_residual,
                        "CE_state_preservation_drift": ce_state,
                        "center_noncenter_split_projective": 1,
                        "computed_status": "CE_commuting_square_real_diagram_test_with_state_drift_quantified",
                        "condition_note": "finite_conditional_expectation_proxy_no_split_property_statement",
                    })
                    KL = matrix_log_spd(dL.D)
                    KM = matrix_log_spd(dM.D)
                    K_err = fro(KM - KL) / max(fro(KL), EPS)
                    delta_err = 0.0
                    for x in labels[:10]:
                        delta_err = max(delta_err, fro(commutator_delta(KM, dM.gens[x]) - commutator_delta(KL, dL.gens[x])) / max(fro(commutator_delta(KL, dL.gens[x])), EPS))
                    specL = np.linalg.eigvalsh(KL)
                    specM = np.linalg.eigvalsh(KM)
                    mod_rows.append({
                        **base, "available": 1,
                        "K_intertwining_relative_error": K_err,
                        "finite_preflow_delta_commuting_square_error": delta_err,
                        "logD_spectrum_min_source": float(np.min(specM)),
                        "logD_spectrum_max_source": float(np.max(specM)),
                        "logD_spectrum_min_target": float(np.min(specL)),
                        "logD_spectrum_max_target": float(np.max(specL)),
                        "spectrum_width_drift": abs((float(np.max(specM)-np.min(specM))) - (float(np.max(specL)-np.min(specL)))),
                        "computed_status": "modular_preflow_projective_finite_object_with_drift_quantified",
                        "condition_note": "finite_logD_preflow_only_no_KMS_statement",
                    })
                # Direct-vs-via composition coherence for 4<-6 through 5.
                if {4,5,6}.issubset(set(levels)):
                    d4 = data.get((b, 4, mode, st)); d5 = data.get((b, 5, mode, st)); d6 = data.get((b, 6, mode, st))
                    basec = {"branching": b, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "source_level": 6, "mid_level": 5, "target_level": 4}
                    if d4 is not None and d5 is not None and d6 is not None and d4.role_dim == d5.role_dim == d6.role_dim:
                        labels64 = common_labels(d6, d4)
                        labels65 = common_labels(d6, d5)
                        labels54 = common_labels(d5, d4)
                        labels_all = [x for x in GEN_LABELS if x in labels64 and x in labels65 and x in labels54]
                        pi_def = 0.0
                        ce_def = 0.0
                        mod_def = 0.0
                        K6 = matrix_log_spd(d6.D); K5 = matrix_log_spd(d5.D); K4 = matrix_log_spd(d4.D)
                        for x in labels_all[:10]:
                            X6 = d6.gens[x]
                            direct = pi_role_project(X6, d6, d4, labels64)
                            via5 = pi_role_project(pi_role_project(X6, d6, d5, labels65), d5, d4, labels54)
                            pi_def = max(pi_def, fro(direct - via5) / max(fro(direct), EPS))
                            edirect = center_expectation(direct)
                            evia = center_expectation(via5)
                            ce_def = max(ce_def, fro(edirect - evia) / max(fro(edirect), EPS))
                            d_direct = pi_role_project(commutator_delta(K6, X6), d6, d4, labels64)
                            d_via = pi_role_project(pi_role_project(commutator_delta(K6, X6), d6, d5, labels65), d5, d4, labels54)
                            mod_def = max(mod_def, fro(d_direct - d_via) / max(fro(d_direct), EPS))
                        G4 = generator_gram(d4.gens,d4.D)[1]
                        G6 = generator_gram(d6.gens,d6.D)[1]
                        gram_direct_drift = fro(G4 - G6) / max(fro(G4), EPS)
                        comp_rows.extend([
                            {**basec, "structure": "GNS_generator_U", "direct_vs_composed_residual": pi_def, "object_drift_4_vs_6": gram_direct_drift, "computed_status": "composition_coherence_real_projection_test_with_drift_quantified"},
                            {**basec, "structure": "Algebra_Pi", "direct_vs_composed_residual": pi_def, "object_drift_4_vs_6": fro(d4.Lc - d6.Lc) / max(fro(d4.Lc), EPS), "computed_status": "composition_coherence_real_projection_test_with_drift_quantified"},
                            {**basec, "structure": "ConditionalExpectation", "direct_vs_composed_residual": ce_def, "object_drift_4_vs_6": ce_def, "computed_status": "composition_coherence_real_CE_test_with_drift_quantified"},
                            {**basec, "structure": "ModularPreflow_logD", "direct_vs_composed_residual": mod_def, "object_drift_4_vs_6": fro(matrix_log_spd(d4.D)-matrix_log_spd(d6.D)) / max(fro(matrix_log_spd(d4.D)), EPS), "computed_status": "composition_coherence_real_modular_projection_test_with_drift_quantified"},
                        ])
                    else:
                        comp_rows.append({**basec, "structure": "operator_stack", "direct_vs_composed_residual": math.nan, "computed_status": "composition_unavailable_missing_region_data", "condition_note": "reference_missing_operator_stack_blocks_final_computed_status"})
    return gns_rows, alg_rows, ce_rows, mod_rows, comp_rows
