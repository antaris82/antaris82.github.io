from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _hist_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    # Tomita standard-form rows use the sibling-cone region family, while the
    # History/live measure is computed on genealogical-corridor regions.
    # The correct integration level here is therefore the common finite
    # approximant track (b,L,mode), not a region-id join.  Values are medians
    # over the available history-measure regions.
    grouped: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in history_rows:
        if r.get("measure_surface") == "history_live_measure_finite_object":
            grouped[(r.get("branching"), r.get("level"), r.get("mode"))].append(r)
    out: Dict[Tuple[object, ...], dict] = {}
    for key, rows in grouped.items():
        out[key] = {
            "JS_live_record_no_epsilon": _median(_finite(r.get("JS_live_record_no_epsilon")) for r in rows),
            "backreaction_current_norm": _median(_finite(r.get("backreaction_current_norm")) for r in rows),
            "record_tracking_gain_over_uniform": _median(_finite(r.get("record_tracking_gain_over_uniform")) for r in rows),
            "history_measure_region_count": int(len(rows)),
            "history_measure_join_relations": "approximant_level_median_join_b_L_mode",
        }
    return out

def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("tomita_matrix_sign_relation"))


def _summarize(rows: List[dict], tol: float) -> dict:
    by_l: Dict[int, List[dict]] = defaultdict(list)
    for r in rows:
        L = int(r.get("level", -1))
        if L >= 0:
            by_l[L].append(r)
    levels = sorted(by_l)
    if len(levels) < 2:
        return {"modular_entropy_backreaction_track_computed_status": "modular_entropy_backreaction_level_track_unavailable"}
    first, last = levels[0], levels[-1]
    js0 = _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_l[first])
    js1 = _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_l[last])
    b0 = _median(_finite(r.get("backreaction_current_norm")) for r in by_l[first])
    b1 = _median(_finite(r.get("backreaction_current_norm")) for r in by_l[last])
    sp0 = _median(_finite(r.get("modular_spectrum_spread")) for r in by_l[first])
    sp1 = _median(_finite(r.get("modular_spectrum_spread")) for r in by_l[last])
    res0 = _median(_finite(r.get("tomita_conjuconditions_cnna_orientation_to_negative_residual")) for r in by_l[first])
    res1 = _median(_finite(r.get("tomita_conjuconditions_cnna_orientation_to_negative_residual")) for r in by_l[last])
    js_deepens = math.isfinite(js0) and math.isfinite(js1) and js1 > js0 + max(tol, tol * max(1.0, abs(js0)))
    b_deepens = math.isfinite(b0) and math.isfinite(b1) and b1 > b0 + max(tol, tol * max(1.0, abs(b0)))
    spread_deepens = math.isfinite(sp0) and math.isfinite(sp1) and sp1 > sp0 + max(tol, tol * max(1.0, abs(sp0)))
    residual_falls = math.isfinite(res0) and math.isfinite(res1) and res1 < res0 - max(tol, tol * max(1.0, abs(res0)))
    if js_deepens and b_deepens and spread_deepens and residual_falls:
        computed_status = "entropy_backreaction_modular_flow_with_residual_improvement_finite_object"
    elif js_deepens and b_deepens and spread_deepens:
        computed_status = "entropy_backreaction_modular_flow_finite_object_without_J_identity"
    elif js_deepens and b_deepens:
        computed_status = "entropy_backreaction_current_alignment_without_modular_spread_control"
    else:
        computed_status = "entropy_backreaction_modular_flow_alignment_obstructed_or_unresolved"
    return {
        "modular_entropy_backreaction_first_level": int(first),
        "modular_entropy_backreaction_last_level": int(last),
        "JS_live_record_first_level_median": js0,
        "JS_live_record_last_level_median": js1,
        "backreaction_current_norm_first_level_median": b0,
        "backreaction_current_norm_last_level_median": b1,
        "modular_spread_first_level_median": sp0,
        "modular_spread_last_level_median": sp1,
        "tomita_orientation_residual_first_level_median": res0,
        "tomita_orientation_residual_last_level_median": res1,
        "JS_deepens_with_level": int(js_deepens),
        "B_current_deepens_with_level": int(b_deepens),
        "modular_spread_deepens_with_level": int(spread_deepens),
        "tomita_orientation_residual_decreases_with_level": int(residual_falls),
        "modular_entropy_backreaction_track_computed_status": computed_status,
    }


def modular_entropy_backreaction_direction_rows(history_rows: List[dict], tomita_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Use JS(live,record) as the scale for Tomita/modular flow derived_quantity rows.

    The direct `J_T L_A J_T = -L_A` identity remains a residual, not a target
    property.  The finite question is whether history/live entropy, B-current,
    and modular spread co-move across available levels.
    """
    hidx = _hist_index(history_rows)
    rows: List[dict] = []
    for t in tomita_rows:
        if t.get("state") != "live":
            continue
        key = (t.get("branching"), t.get("level"), t.get("mode"))
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        bnorm = _finite(h.get("backreaction_current_norm"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        spread = _finite(t.get("modular_spectrum_spread"))
        residual = _finite(t.get("tomita_conjuconditions_cnna_orientation_to_negative_residual"))
        if not math.isfinite(js):
            rv = "history_measure_unavailable_for_modular_flow_control"
        elif spread > 1.0 + tol and gain > tol:
            rv = "modular_nontrivial_with_history_tracking_row_finite_object"
        else:
            rv = "modular_entropy_backreaction_row_unresolved"
        rows.append({
            "branching": t.get("branching"),
            "level": t.get("level"),
            "mode": t.get("mode"),
            "region_id": t.get("region_id"),
            "region_family": t.get("region_family"),
            "genealogical_corridor_length": t.get("genealogical_corridor_length"),
            "tomita_matrix_sign_relation": t.get("matrix_sign_relation", t.get("tomita_matrix_sign_relation", "out_degree")),
            "history_measure_used": "JS_live_record_no_epsilon",
            "history_measure_join_relations": h.get("history_measure_join_relations", "missing_history_measure_join"),
            "history_measure_region_count": h.get("history_measure_region_count", 0),
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "backreaction_current_norm": bnorm,
            "modular_spectrum_spread": spread,
            "modular_spectrum_log_span": t.get("modular_spectrum_log_span"),
            "tomita_conjuconditions_cnna_orientation_to_negative_residual": residual,
            "source_tomita_computed_status": t.get("tomita_standard_form_computed_status", t.get("tomita_entropy_flow_computed_status")),
            "modular_entropy_backreaction_row_computed_status": rv,
        })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        tracks[_track_key(r)].append(r)
    summaries = {k: _summarize(v, tol) for k, v in tracks.items()}
    for r in rows:
        r.update(summaries.get(_track_key(r), {}))
    return rows


def modular_entropy_backreaction_direction_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("modular_entropy_backreaction_track_computed_status", "unknown")) for r in rows if "modular_entropy_backreaction_track_computed_status" in r})
    return (
        "# Modular entropy/backreaction direction derived_quantity rows\n\n"
        "This surface keeps Tomita as a flow derived_quantity rather than an asserted CNNA-J identity.  "
        "It asks whether `JS(live,record)`, `||B||`, and modular spread co-move across finite levels.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
