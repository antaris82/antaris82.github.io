from __future__ import annotations

EPS = 1.0e-12

# CNNA reference path.  Comparison modes remain available, but they are controls,
# not additional free model parameters.
REFERENCE_MODE = "linear"
REFERENCE_STATE = "live"
STRUCTURAL_RECORD_STATE = "record"

GEN_LABELS = [
    "I", "S", "A", "P_C", "P_B1", "P_B2", "P_front", "P_F1", "P_F2",
    "S_C", "S_B1", "S_B2", "S_C_front", "S_front", "A_F1F2",
]

CONTROL_MODES = ("log", "saturating")
CONTROL_STATES = ("sym",)
