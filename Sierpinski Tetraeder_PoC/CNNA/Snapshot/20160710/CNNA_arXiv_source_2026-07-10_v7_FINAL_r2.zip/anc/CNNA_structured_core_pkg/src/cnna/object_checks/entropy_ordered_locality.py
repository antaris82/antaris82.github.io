from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _hist_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    idx: Dict[Tuple[object, ...], dict] = {}
    for r in history_rows:
        if r.get("measure_surface") != "history_live_measure_finite_object":
            continue
        key = (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))
        idx[key] = r
    return idx


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("live_cluster_layer"))


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[dict]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        if c >= 0:
            by_c[c].append(r)
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"entropy_ordered_locality_track_computed_status": "entropy_ordered_locality_insufficient_corridor_track"}
    first_c, last_c = cs[0], cs[-1]
    first_norm = _median(_finite(r.get("cluster_rank_bound_norm")) for r in by_c[first_c])
    last_norm = _median(_finite(r.get("cluster_rank_bound_norm")) for r in by_c[last_c])
    first_normed = _median(_finite(r.get("cluster_rank_bound_per_history_js")) for r in by_c[first_c])
    last_normed = _median(_finite(r.get("cluster_rank_bound_per_history_js")) for r in by_c[last_c])
    first_js = _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_c[first_c])
    last_js = _median(_finite(r.get("JS_live_record_no_epsilon")) for r in by_c[last_c])
    raw_decay = math.isfinite(first_norm) and math.isfinite(last_norm) and last_norm < first_norm - max(tol, tol * max(1.0, abs(first_norm)))
    normed_decay = math.isfinite(first_normed) and math.isfinite(last_normed) and last_normed < first_normed - max(tol, tol * max(1.0, abs(first_normed)))
    if max(abs(_finite(r.get("cluster_rank_bound_norm"))) for r in rows if math.isfinite(_finite(r.get("cluster_rank_bound_norm")))) <= tol:
        computed_status = "entropy_ordered_locality_zero_structural_control"
    elif raw_decay and normed_decay:
        computed_status = "history_measure_normalized_cluster_decay_finite_object"
    elif raw_decay and not normed_decay:
        computed_status = "raw_cluster_decay_not_history_normalized_control"
    elif math.isfinite(last_norm) and math.isfinite(first_norm) and last_norm > first_norm:
        computed_status = "history_measure_ordered_cluster_growth_observed"
    else:
        computed_status = "history_measure_ordered_cluster_no_monotone_decay_observed"
    return {
        "entropy_ordered_locality_corridor_count": int(len(cs)),
        "entropy_ordered_locality_first_corridor": int(first_c),
        "entropy_ordered_locality_last_corridor": int(last_c),
        "cluster_rank_bound_first_corridor_median": first_norm,
        "cluster_rank_bound_last_corridor_median": last_norm,
        "cluster_per_history_js_first_corridor_median": first_normed,
        "cluster_per_history_js_last_corridor_median": last_normed,
        "JS_live_record_first_corridor_median": first_js,
        "JS_live_record_last_corridor_median": last_js,
        "entropy_ordered_locality_track_computed_status": computed_status,
    }


def entropy_ordered_locality_rows(history_rows: List[dict], cluster_rows: List[dict], *, tol: float = 1.0e-10) -> List[dict]:
    """Inject the 7 history/live measure into finite locality derived_quantity rows.

    A locality row is not only evaluated by a raw commutator/current norm; it is
    also normalized by JS(live,record), the current best finite history/live
    measure.  This checks whether apparent locality rank_bounds are small or
    large relative to the actual backreaction-history scale.
    """
    hidx = _hist_index(history_rows)
    rows: List[dict] = []
    for r in cluster_rows:
        if "cluster_rank_bound_norm" not in r:
            continue
        key = (r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"), r.get("genealogical_corridor_length"))
        h = hidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        bnorm = _finite(h.get("backreaction_current_norm"))
        gain = _finite(h.get("record_tracking_gain_over_uniform"))
        norm = _finite(r.get("cluster_rank_bound_norm"))
        per_js = float(norm / max(js, 1.0e-300)) if math.isfinite(norm) and math.isfinite(js) and js > 0.0 else math.nan
        per_b = float(norm / max(bnorm, 1.0e-300)) if math.isfinite(norm) and math.isfinite(bnorm) and bnorm > 0.0 else math.nan
        if not math.isfinite(js):
            row_computed_status = "history_measure_unavailable_for_locality_control"
        elif norm <= tol:
            row_computed_status = "history_ordered_locality_zero_commutator_control"
        elif gain > tol and per_js < 10.0:
            row_computed_status = "locality_rank_bound_within_history_measure_scale_finite_object"
        elif gain > tol:
            row_computed_status = "locality_rank_bound_exceeds_history_measure_scale"
        else:
            row_computed_status = "locality_rank_bound_without_record_tracking_gain_control"
        rows.append({
            "branching": r.get("branching"),
            "level": r.get("level"),
            "mode": r.get("mode"),
            "region_id": r.get("region_id"),
            "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "frontier_level": r.get("frontier_level"),
            "live_cluster_layer": r.get("live_cluster_layer"),
            "history_measure_used": "JS_live_record_no_epsilon",
            "JS_live_record_no_epsilon": js,
            "record_tracking_gain_over_uniform": gain,
            "backreaction_current_norm": bnorm,
            "cluster_rank_bound_norm": norm,
            "cluster_rank_bound_per_history_js": per_js,
            "cluster_rank_bound_per_B_norm": per_b,
            "source_live_cluster_row_computed_status": r.get("live_cluster_row_computed_status"),
            "source_live_cluster_track_computed_status": r.get("live_cluster_track_computed_status"),
            "entropy_ordered_locality_row_computed_status": row_computed_status,
        })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        tracks[_track_key(row)].append(row)
    summaries = {k: _summarize_track(v, tol) for k, v in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def entropy_ordered_locality_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("entropy_ordered_locality_track_computed_status", "unknown")) for r in rows if "entropy_ordered_locality_track_computed_status" in r})
    rowv = sorted({str(r.get("entropy_ordered_locality_row_computed_status", "unknown")) for r in rows})
    return (
        "# Entropy-ordered locality derived_quantity rows\n\n"
        "This surface uses the 7 history/live measure `JS(live,record)` as the scale for finite locality/current rank_bounds.  "
        "It does not assert Haag locality; it asks whether commutator/current norms decay or remain large relative to the measured backreaction-history scale.\n\n"
        "Row computed_status_rows: `" + "`, `".join(rowv) + "`.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
