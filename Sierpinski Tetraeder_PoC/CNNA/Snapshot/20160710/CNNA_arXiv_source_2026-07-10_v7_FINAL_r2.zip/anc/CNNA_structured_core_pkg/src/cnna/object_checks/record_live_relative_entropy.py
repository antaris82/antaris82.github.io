from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
    state_pair_backreaction_algebras,
)
from cnna.core.entropy_quantities import record_live_entropy_metrics
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: List[float]) -> float:
    ys = sorted(x for x in xs if math.isfinite(x))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("mode"), row.get("genealogical_corridor_length"))


def _summarize_track(rows: List[dict]) -> dict:
    by_l: Dict[int, List[float]] = defaultdict(list)
    by_l_b: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        L = int(r.get("level", -1))
        js = _finite(r.get("jensen_shannon_live_record_no_epsilon"))
        bnorm = _finite(r.get("backreaction_current_norm"))
        if L >= 0 and math.isfinite(js):
            by_l[L].append(js)
        if L >= 0 and math.isfinite(bnorm):
            by_l_b[L].append(bnorm)
    levels = sorted(by_l)
    if len(levels) < 2:
        return {
            "record_live_entropy_level_track_count": int(len(levels)),
            "record_live_entropy_level_trend": "record_live_entropy_trend_unavailable",
        }
    first, last = levels[0], levels[-1]
    js_first = _median(by_l[first])
    js_last = _median(by_l[last])
    b_first = _median(by_l_b.get(first, []))
    b_last = _median(by_l_b.get(last, []))
    if math.isfinite(js_first) and math.isfinite(js_last) and js_last > js_first:
        trend = "record_live_js_divergence_deepens_with_level"
    elif math.isfinite(js_first) and math.isfinite(js_last) and js_last < js_first:
        trend = "record_live_js_divergence_decreases_with_level"
    else:
        trend = "record_live_js_divergence_level_stable_or_unresolved"
    return {
        "record_live_entropy_level_track_count": int(len(levels)),
        "record_live_entropy_first_level": int(first),
        "record_live_entropy_last_level": int(last),
        "record_live_js_first_median": float(js_first) if math.isfinite(js_first) else math.nan,
        "record_live_js_last_median": float(js_last) if math.isfinite(js_last) else math.nan,
        "backreaction_norm_first_median": float(b_first) if math.isfinite(b_first) else math.nan,
        "backreaction_norm_last_median": float(b_last) if math.isfinite(b_last) else math.nan,
        "record_live_entropy_level_trend": trend,
    }


def record_live_relative_entropy_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = regional_response(model, spec, "live")
            record = regional_response(model, spec, "record")
            if live is None or record is None:
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "relative_entropy_surface": "live_vs_birth_record_history_reference",
                    "record_live_entropy_computed_status": "response_unavailable",
                })
                continue
            entropy = record_live_entropy_metrics(live.density, record.density, tol=config.algebra_tol)
            bpair = state_pair_backreaction_algebras(model, spec, "live", "record", config.algebra_tol, config.max_algebra_iter)
            bmeta = bpair.get("__metadata__", {}) if bpair is not None else {}
            bnorm = _finite(bmeta.get("backreaction_current_norm", math.nan))
            js = _finite(entropy.get("jensen_shannon_live_record_no_epsilon"))
            ratio = float(js / max(bnorm, 1.0e-300)) if math.isfinite(js) and math.isfinite(bnorm) and bnorm > 0 else math.nan
            if entropy.get("live_support_in_record_support", 0) == 0:
                computed_status = "record_birth_history_not_absolute_reference_for_live_control"
            elif math.isfinite(js):
                computed_status = "finite_live_record_relative_entropy_measure_finite_object"
            else:
                computed_status = "record_live_entropy_unresolved"
            rows.append({
                "branching": b,
                "level": L,
                "mode": mode,
                **meta,
                "relative_entropy_surface": "live_vs_birth_record_history_reference",
                "physics_state": "live",
                "history_reference": "record",
                **live.density_metadata,
                **entropy,
                **bmeta,
                "js_divergence_per_backreaction_norm": float(ratio) if math.isfinite(ratio) else math.nan,
                "relative_entropy_current_measure_computed_status": computed_status,
            })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        tracks[_track_key(row)].append(row)
    summaries = {k: _summarize_track(v) for k, v in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def record_live_relative_entropy_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("relative_entropy_current_measure_computed_status", r.get("record_live_entropy_computed_status", "unknown"))) for r in rows})
    trends = sorted({str(r.get("record_live_entropy_level_trend", "unknown")) for r in rows if "record_live_entropy_level_trend" in r})
    return (
        "# Record/live relative entropy and history-current measure\n\n"
        "`live` is the reference physics state.  `record` is the fixed birth-history reference.  "
        "The one-way relative entropies use the exact finite support rule and no epsilon floor; "
        "therefore `D(live||record)` may be infinite when the birth record is not an absolute reference for the live support.  "
        "The Jensen-Shannon divergence is kept as the finite symmetric finite_object for a common live/history distance.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Level trends: `" + "`, `".join(trends) + "`.\n"
    )
