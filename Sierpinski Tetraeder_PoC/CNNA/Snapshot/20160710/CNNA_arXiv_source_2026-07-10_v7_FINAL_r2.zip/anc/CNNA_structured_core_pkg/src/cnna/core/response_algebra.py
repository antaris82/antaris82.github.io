from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core.math_utils import *
from cnna.core.schur_dtn import *

@dataclass
class AlgebraBasis:
    name: str
    basis: List[np.ndarray]
    generator_count: int
    iterations: int
    saturated: bool


def rank_one(v: np.ndarray) -> np.ndarray:
    return np.outer(v, v)


def add_to_basis(A: np.ndarray, basis: List[np.ndarray], tol: float) -> bool:
    R = A.copy()
    for B in basis:
        R -= float(np.trace(B.T @ R)) * B
    nrm = fro(R)
    if nrm <= tol:
        return False
    basis.append(R / nrm)
    return True


def algebra_closure(name: str, generators: Sequence[np.ndarray], tol: float = 1e-10, max_iter: int = 10) -> AlgebraBasis:
    basis: List[np.ndarray] = []
    for G in generators:
        add_to_basis(G, basis, tol)
        add_to_basis(G.T, basis, tol)
    gen_count = len(generators)
    saturated = False
    it_done = 0
    for it in range(max_iter):
        it_done = it + 1
        changed = False
        snapshot = list(basis)
        for A in snapshot:
            for B in snapshot:
                if add_to_basis(A @ B, basis, tol):
                    changed = True
                if len(basis) >= A.shape[0] * A.shape[1]:
                    saturated = True
                    return AlgebraBasis(name, basis, gen_count, it_done, saturated)
        if not changed:
            saturated = True
            break
    return AlgebraBasis(name, basis, gen_count, it_done, saturated)


def project_coeffs(X: np.ndarray, basis: Sequence[np.ndarray]) -> np.ndarray:
    return np.array([float(np.trace(B.T @ X)) for B in basis], dtype=float)


def reconstruct(c: np.ndarray, basis: Sequence[np.ndarray], shape: Tuple[int, int]) -> np.ndarray:
    Y = np.zeros(shape, dtype=float)
    for ci, B in zip(c, basis):
        Y += float(ci) * B
    return Y


def span_residual(X: np.ndarray, basis: Sequence[np.ndarray]) -> float:
    if not basis:
        return fro(X)
    c = project_coeffs(X, basis)
    return fro(X - reconstruct(c, basis, X.shape)) / max(fro(X), EPS)


def positive_density_from_response(Lc: np.ndarray, eps: float = 1e-9) -> np.ndarray:
    S = 0.5 * (Lc + Lc.T)
    try:
        vals, U = np.linalg.eigh(S)
        vals_pos = np.maximum(vals, 0.0) + eps
        D = U @ np.diag(vals_pos) @ U.T
    except np.linalg.LinAlgError:
        D = np.eye(S.shape[0])
    D = 0.5 * (D + D.T)
    tr = float(np.trace(D))
    if tr <= EPS:
        D = np.eye(S.shape[0]) / float(max(1, S.shape[0]))
    else:
        D = D / tr
    return D


def gens_from_response(Lc: np.ndarray) -> Dict[str, np.ndarray]:
    d = Lc.shape[0]
    I = np.eye(d)
    S = 0.5 * (Lc + Lc.T)
    A = 0.5 * (Lc - Lc.T)
    # Basis sign_relation after boundary_role_basis: C, B1, B2, F1, F2 if present.
    def e(i: int) -> np.ndarray:
        v = np.zeros(d, dtype=float)
        if i < d:
            v[i] = 1.0
        return v
    P_C = rank_one(e(0))
    P_B1 = rank_one(e(1)) if d > 1 else np.zeros((d, d))
    P_B2 = rank_one(e(2)) if d > 2 else np.zeros((d, d))
    P_F1 = rank_one(e(3)) if d > 3 else np.zeros((d, d))
    P_F2 = rank_one(e(4)) if d > 4 else np.zeros((d, d))
    P_front = P_B1 + P_B2
    P_all = I
    # Conditioned/block responses.
    return {
        "I": I,
        "S": S,
        "A": A,
        "P_C": P_C,
        "P_B1": P_B1,
        "P_B2": P_B2,
        "P_front": P_front,
        "P_F1": P_F1,
        "P_F2": P_F2,
        "S_C": P_C @ S @ P_C,
        "S_B1": P_B1 @ S @ P_B1,
        "S_B2": P_B2 @ S @ P_B2,
        "S_C_front": P_C @ S @ P_front + P_front @ S @ P_C,
        "S_front": P_front @ S @ P_front,
        "A_F1F2": P_F1 @ A @ P_F2 + P_F2 @ A @ P_F1,
        "A": A,
    }


def build_algebras(g: Dict[str, np.ndarray], tol: float, max_iter: int) -> Tuple[AlgebraBasis, AlgebraBasis, AlgebraBasis]:
    A_in_gens = [g["I"], g["P_C"], g["P_B1"], g["S_C"], g["S_B1"]]
    N_gens = A_in_gens + [g["P_B2"], g["P_front"], g["S_B2"], g["S_C_front"], g["A_F1F2"]]
    A_out_gens = N_gens + [g["S"], g["A"], g["P_F1"], g["P_F2"], g["S_front"]]
    return (
        algebra_closure("A_in_given_C", A_in_gens, tol, max_iter),
        algebra_closure("N_A_of_C", N_gens, tol, max_iter),
        algebra_closure("A_out_given_C", A_out_gens, tol, max_iter),
    )


def state_value(D: np.ndarray, X: np.ndarray) -> float:
    return float(np.trace(D @ X))


@dataclass
class GNSData:
    algebra: str
    basis_dim: int
    gram: np.ndarray
    rank: int
    nullity: int
    min_eig: float
    max_eig: float
    condition: float
    psd_ok: bool
    cyclic_ok: bool
    cyclic_span_rank: int
    cyclic_rank_defect: int
    omega_norm2: float
    identity_span_residual: float
    max_cyclic_vector_action_residual: float
    representation_element_count: int
    full_basis_representation_checked: bool
    representation_ok: bool
    max_star_adjoint_error: float
    max_left_closure_residual: float
    max_null_left_stability: float


def state_gram(basis: Sequence[np.ndarray], D: np.ndarray) -> np.ndarray:
    m = len(basis)
    G = np.zeros((m, m), dtype=float)
    for i, Bi in enumerate(basis):
        for j in range(i, m):
            val = state_value(D, Bi.T @ basis[j])
            G[i, j] = val
            G[j, i] = val
    return 0.5 * (G + G.T)


def quotient_support(G: np.ndarray, tol: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if G.size == 0:
        return np.zeros(0), np.zeros((0, 0)), np.zeros(0, dtype=bool)
    vals, U = np.linalg.eigh(G)
    maxeig = float(np.max(vals)) if vals.size else 0.0
    mask = vals > max(tol, tol * max(1.0, maxeig))
    return vals, U, mask


def left_coeff_matrix(A: np.ndarray, basis: Sequence[np.ndarray]) -> Tuple[np.ndarray, float]:
    m = len(basis)
    C = np.zeros((m, m), dtype=float)
    max_res = 0.0
    for j, Bj in enumerate(basis):
        Y = A @ Bj
        c = project_coeffs(Y, basis)
        C[:, j] = c
        max_res = max(max_res, span_residual(Y, basis))
    return C, max_res


def _column_rank(columns: np.ndarray, tol: float) -> int:
    if columns.size == 0:
        return 0
    try:
        singular_values = np.linalg.svd(columns, compute_uv=False)
    except np.linalg.LinAlgError:
        return 0
    if singular_values.size == 0:
        return 0
    cutoff = max(float(tol), float(tol) * max(1.0, float(np.max(singular_values))))
    return int(np.sum(singular_values > cutoff))


def measurement_gns(algebra: AlgebraBasis, D: np.ndarray, tol: float) -> GNSData:
    """Construct and audit the finite left-regular GNS quotient.

    The quotient coordinate of a coefficient vector ``c`` is
    ``diag(sqrt(lambda_support)) U_support.T c``.  Cyclicity is checked
    explicitly by applying every represented basis element to the identity
    class and computing the rank of the resulting quotient vectors.  The
    transpose-adjoint, algebra-closure, and null-left-ideal checks are likewise
    evaluated for the full algebra basis rather than a fixed probe prefix.
    """
    basis = algebra.basis
    G = state_gram(basis, D)
    vals, U, mask = quotient_support(G, tol)
    rank = int(np.sum(mask))
    nullity = int(len(basis) - rank)
    min_eig = float(np.min(vals)) if vals.size else math.nan
    max_eig = float(np.max(vals)) if vals.size else math.nan
    psd_ok = bool(vals.size == 0 or min_eig >= -10.0 * tol)
    condition = float(np.max(vals[mask]) / np.min(vals[mask])) if rank > 0 else math.inf

    n = D.shape[0]
    identity = np.eye(n)
    cI = project_coeffs(identity, basis)
    identity_span_residual = span_residual(identity, basis)
    omega_norm2 = float(cI.T @ G @ cI) if G.size else 0.0

    max_adj = 0.0
    max_closure = 0.0
    max_null = 0.0
    max_cyclic_action = 0.0
    support_U = U[:, mask] if U.size else np.zeros((len(basis), 0))
    null_U = U[:, ~mask] if U.size else np.zeros((len(basis), 0))
    support_vals = vals[mask] if rank > 0 else np.zeros(0)
    sqrtS = np.diag(np.sqrt(support_vals)) if rank > 0 else np.zeros((0, 0))
    invsqrtS = np.diag(1.0 / np.sqrt(support_vals)) if rank > 0 else np.zeros((0, 0))
    basis_class_vectors = sqrtS @ support_U.T if rank > 0 else np.zeros((0, len(basis)))
    cyclic_vectors: List[np.ndarray] = []

    for i, A in enumerate(basis):
        C, res = left_coeff_matrix(A, basis)
        CT, resT = left_coeff_matrix(A.T, basis)
        max_closure = max(max_closure, res, resT)
        if rank > 0:
            Q = sqrtS @ (support_U.T @ C @ support_U) @ invsqrtS
            QT = sqrtS @ (support_U.T @ CT @ support_U) @ invsqrtS
            max_adj = max(max_adj, fro(Q.T - QT) / max(1.0, fro(Q)))

            action_on_omega = sqrtS @ (support_U.T @ (C @ cI))
            direct_basis_class = basis_class_vectors[:, i]
            max_cyclic_action = max(
                max_cyclic_action,
                float(np.linalg.norm(action_on_omega - direct_basis_class))
                / max(1.0, float(np.linalg.norm(direct_basis_class))),
            )
            cyclic_vectors.append(action_on_omega)

        if nullity > 0 and rank > 0:
            for v in null_U.T:
                quotient_image = sqrtS @ (support_U.T @ (C @ v))
                max_null = max(max_null, float(np.linalg.norm(quotient_image)))

    cyclic_matrix = np.column_stack(cyclic_vectors) if cyclic_vectors else np.zeros((rank, 0))
    cyclic_span_rank = _column_rank(cyclic_matrix, tol)
    cyclic_rank_defect = max(0, rank - cyclic_span_rank)
    identity_ok = identity_span_residual <= 10.0 * tol
    action_ok = max_cyclic_action <= 100.0 * tol
    cyclic_ok = bool(rank > 0 and cyclic_span_rank == rank and identity_ok and action_ok and omega_norm2 > tol)
    full_basis_checked = bool(len(basis) == len(cyclic_vectors) if rank > 0 else len(basis) == 0)
    representation_ok = bool(
        psd_ok
        and full_basis_checked
        and max_closure <= 100.0 * tol
        and max_adj <= 100.0 * tol
        and max_null <= 100.0 * tol
    )

    return GNSData(
        algebra=algebra.name,
        basis_dim=len(basis),
        gram=G,
        rank=rank,
        nullity=nullity,
        min_eig=min_eig,
        max_eig=max_eig,
        condition=condition,
        psd_ok=psd_ok,
        cyclic_ok=cyclic_ok,
        cyclic_span_rank=cyclic_span_rank,
        cyclic_rank_defect=cyclic_rank_defect,
        omega_norm2=omega_norm2,
        identity_span_residual=identity_span_residual,
        max_cyclic_vector_action_residual=max_cyclic_action,
        representation_element_count=len(basis),
        full_basis_representation_checked=full_basis_checked,
        representation_ok=representation_ok,
        max_star_adjoint_error=max_adj,
        max_left_closure_residual=max_closure,
        max_null_left_stability=max_null,
    )

def positive_trace_normalize_matrix(A: np.ndarray, tol: float = 1e-12) -> Tuple[np.ndarray, dict]:
    """Positive trace-normalization by spectral support clipping.

    This is the finite compressed carrier/GNS density consistency used for the compressed
    response carrier.  It does not introduce an inverse and it makes no infinite
    state statement.
    """
    H = 0.5 * (A + A.T)
    try:
        vals, U = np.linalg.eigh(H)
    except np.linalg.LinAlgError:
        n = H.shape[0]
        return np.eye(n) / float(max(1, n)), {"density_ok": 0, "density_error": "eigh_failed"}
    vals_clip = np.where(np.isfinite(vals) & (vals > tol), vals, 0.0)
    tr = float(np.sum(vals_clip))
    neg_mass = float(np.sum(np.abs(vals[vals < -tol]))) if vals.size else 0.0
    if tr <= EPS:
        n = H.shape[0]
        return np.eye(n) / float(max(1, n)), {"density_ok": 0, "density_error": "zero_positive_trace", "density_negative_mass": neg_mass}
    D = (U * (vals_clip / tr)) @ U.T
    return 0.5 * (D + D.T), {
        "density_ok": 1,
        "density_rank": int(np.sum(vals_clip > tol)),
        "density_min_raw_eig": float(np.min(vals)) if vals.size else math.nan,
        "density_max_raw_eig": float(np.max(vals)) if vals.size else math.nan,
        "density_negative_mass": neg_mass,
    }


def project_density_to_algebra_span(D: np.ndarray, alg: AlgebraBasis) -> Tuple[np.ndarray, dict]:
    """Project D to the finite N_A(C)-span and positive trace-normalize."""
    if not alg.basis:
        Dpos, info = positive_trace_normalize_matrix(D)
        info.update({"projection_basis_dim": 0, "projection_residual_fro": math.nan})
        return Dpos, info
    coeff = project_coeffs(D, alg.basis)
    Dproj = reconstruct(coeff, alg.basis, D.shape)
    Dpos, info = positive_trace_normalize_matrix(Dproj)
    info.update({
        "projection_basis_dim": len(alg.basis),
        "D_to_N_projected_raw_trace": float(np.trace(Dproj)),
        "D_to_N_projected_residual_fro": fro(D - Dpos) / (fro(D) + EPS),
        "D_to_N_projected_min_eig_before_clip": float(np.min(np.linalg.eigvalsh(0.5*(Dproj+Dproj.T)))) if Dproj.size else math.nan,
    })
    return Dpos, info
