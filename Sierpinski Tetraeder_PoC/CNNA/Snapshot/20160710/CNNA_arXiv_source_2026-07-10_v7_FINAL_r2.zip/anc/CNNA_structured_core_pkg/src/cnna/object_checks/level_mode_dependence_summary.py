from __future__ import annotations

import math
from collections import defaultdict
from typing import Iterable, List


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def level_mode_dependence_summary_rows(level_mode_rows: List[dict], geometry_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    groups = defaultdict(list)
    for r in level_mode_rows:
        groups[(r.get("parameter_dependence_control_family"), r.get("control_delta_level"), r.get("control_mode"))].append(r)
    for (family, delta, cmode), xs in sorted(groups.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]), str(kv[0][2]))):
        total = len(xs)
        supported = sum(1 for r in xs if str(r.get("history_measure_level_mode_dependence_computed_status", "")).endswith("parameter_dependence_supported_finite_object"))
        close = sum(1 for r in xs if "as_close_or_closer" in str(r.get("history_measure_level_mode_dependence_computed_status", "")))
        hidden = sum(1 for r in xs if "hidden_by" in str(r.get("history_measure_level_mode_dependence_computed_status", "")))
        if total and supported / total >= 0.75:
            computed_status = "true_record_level_mode_parameter_dependence_supported_summary"
        elif total and close / total >= 0.25:
            computed_status = "level_mode_control_parameter_dependence_rank_bound_summary"
        elif total and hidden:
            computed_status = "level_mode_component_tradeoff_summary"
        else:
            computed_status = "level_mode_parameter_dependence_partial_or_unresolved_summary"
        rows.append({
            "summary_surface": "history_measure_level_mode_dependence_summary",
            "parameter_dependence_control_family": family,
            "control_delta_level": delta,
            "control_mode": cmode,
            "row_count": total,
            "true_parameter_dependence_supported_count": supported,
            "control_as_close_or_closer_count": close,
            "component_tradeoff_hidden_count": hidden,
            "median_additive_margin_control_minus_true": _median(r.get("additive_margin_control_minus_true") for r in xs),
            "median_density_margin_control_minus_true": _median(r.get("density_margin_control_minus_true") for r in xs),
            "median_F1F2_profile_margin_control_minus_true": _median(r.get("F1F2_profile_margin_control_minus_true") for r in xs),
            "summary_computed_status": computed_status,
        })
    ggroups = defaultdict(list)
    for r in geometry_rows:
        ggroups[(r.get("geometry_surface"), r.get("parameter_dependence_control_family"), r.get("control_delta_level"), r.get("control_mode"))].append(r)
    for (surface, family, delta, cmode), xs in sorted(ggroups.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]), str(kv[0][2]), str(kv[0][3]))):
        total = len(xs)
        cand = sum(1 for r in xs if str(r.get("oriented_geometry_level_mode_dependence_computed_status", "")) == "true_level_mode_specific_measure_contains_geometry_finite_object")
        obs = sum(1 for r in xs if str(r.get("oriented_geometry_level_mode_dependence_computed_status", "")) == "level_mode_control_measure_as_good_or_tighter_for_geometry_observed")
        if total and cand / total >= 0.75:
            computed_status = "true_record_level_mode_geometry_parameter_dependence_supported_summary"
        elif total and obs >= cand:
            computed_status = "level_mode_geometry_parameter_dependence_rank_bound_summary"
        else:
            computed_status = "level_mode_geometry_parameter_dependence_partial_summary"
        rows.append({
            "summary_surface": "oriented_geometry_level_mode_dependence_summary",
            "geometry_surface": surface,
            "parameter_dependence_control_family": family,
            "control_delta_level": delta,
            "control_mode": cmode,
            "row_count": total,
            "true_level_mode_geometry_specific_count": cand,
            "control_as_good_or_tighter_for_geometry_count": obs,
            "median_true_geometry_ratio": _median(r.get("geometry_ratio_true_additive_measure") for r in xs),
            "median_control_geometry_ratio": _median(r.get("geometry_ratio_control_additive_measure") for r in xs),
            "summary_computed_status": computed_status,
        })
    return rows


def level_mode_dependence_summary_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("summary_computed_status", "unknown")) for r in rows})
    return (
        "# Level/mode parameter_dependence summary\n\n"
        "This summary separates true history parameter_dependence, component tradeoffs, and geometry-ratio parameter_dependence for time-shifted and mode-mismatched records.\n\n"
        f"Summary rows: {len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
