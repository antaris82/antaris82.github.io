from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("region_id"),
        row.get("genealogical_corridor_length"),
    )


def _surface_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("geometry_surface"),
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("region_family"),
        row.get("genealogical_corridor_length"),
    )


def _f1f2_index(rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {_key(r): r for r in rows if "F1F2_orientation_resolution_computed_status" in r}


def _measure_index(rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {_key(r): r for r in rows if "normalized_F1F2_signature_component" in r}


def _bool01(x: object) -> int:
    try:
        return int(float(x))
    except Exception:
        return 0


def _ratio(raw: float, scale: float) -> float:
    return float(raw / max(scale, 1.0e-300)) if math.isfinite(raw) and math.isfinite(scale) and scale > 0.0 else math.nan


def _naive_tensor_status(row: dict) -> str:
    surface = str(row.get("geometry_surface", ""))
    source = str(row.get("source_computed_status", ""))
    if surface.startswith("locality"):
        if "raw_and_signature_normalized_decay" in source or "decay_finite_object" in source:
            return "naive_tensor_local_distance_decay_finite_object"
        if "no_monotone" in source or "growth" in source or "noncommutation" in source:
            return "naive_tensor_locality_obstructed_by_nonmonotone_or_nonzero_commutator"
        return "naive_tensor_locality_unresolved"
    if surface.startswith("split"):
        if "split_factorization" in source and "finite_object" in source:
            return "naive_tensor_split_finite_object"
        if "no_monotone" in source or "obstruct" in source or "shared_identity" in source:
            return "naive_tensor_split_obstructed_by_collar_or_dimension_residual"
        return "naive_tensor_split_unresolved"
    if surface.startswith("complement"):
        if _bool01(row.get("two_sided_duality_ok")):
            return "naive_tensor_complement_duality_finite_object"
        if _bool01(row.get("one_sided_inclusion_ok")):
            return "naive_tensor_complement_only_one_sided_control"
        return "naive_tensor_complement_duality_obstructed"
    return "naive_tensor_geometry_unclassified"


def _replacement_rule(row: dict, f1: dict, meas: dict, *, tol: float) -> Tuple[str, str]:
    surface = str(row.get("geometry_surface", ""))
    raw = _finite(row.get("geometry_raw_rank_bound"))
    signature = _finite(row.get("normalized_F1F2_signature_component", meas.get("normalized_F1F2_signature_component")))
    density = _finite(row.get("density_support_component_JS_live_record", meas.get("density_support_component_JS_live_record")))
    strength = _finite(row.get("F1F2_response_strength_component", meas.get("F1F2_response_strength_component")))
    sig_ratio = _ratio(raw, signature)
    dens_ratio = _ratio(raw, density)
    str_ratio = _ratio(raw, strength)
    within_sig = _bool01(row.get("within_orientation_signature_scale")) or (math.isfinite(sig_ratio) and sig_ratio <= 10.0)
    beats_f2 = _bool01(f1.get("F1F2_multishell_true_beats_F2_flipped_record"))
    live_nonzero = 1 - _bool01(f1.get("F1F2_vacuous_zero_live_profile_current"))
    record_nonzero = 1 - _bool01(f1.get("F1F2_vacuous_zero_record_profile_current"))
    sig_specific = int(beats_f2 and live_nonzero and record_nonzero)
    sig_best_scale = int(
        math.isfinite(sig_ratio)
        and (not math.isfinite(dens_ratio) or sig_ratio < dens_ratio)
        and (not math.isfinite(str_ratio) or sig_ratio < str_ratio)
    )
    if not math.isfinite(raw):
        return "F1F2_oriented_replacement_unavailable_raw_residual", "raw_geometry_residual_unavailable"
    if raw <= max(tol, tol * max(1.0, abs(raw))):
        return "F1F2_oriented_replacement_exact_zero_control", "zero_residual_no_replacement_needed"
    if not within_sig:
        return "F1F2_oriented_replacement_obstructed_residual_exceeds_signature_scale", "residual_not_contained_by_F1F2_signature"
    if not sig_specific:
        return "F1F2_oriented_replacement_weak_control_missing_destroyed_history_parameter_dependence", "signature_scale_contains_residual_but_F2_parameter_dependence_missing"
    if not sig_best_scale:
        return "F1F2_oriented_replacement_weak_control_signature_not_best_component", "signature_contains_residual_but_not_strict_best_component"
    if surface.startswith("locality"):
        return "F1F2_oriented_noncommutative_locality_replacement_finite_object", "locality_residual_is_oriented_F1F2_coupling_not_tensor_commutation"
    if surface.startswith("split"):
        return "F1F2_oriented_nonfactorizing_split_replacement_finite_object", "split_residual_is_oriented_F1F2_coupling_not_pure_tensor_factorization"
    if surface.startswith("complement"):
        if _bool01(row.get("one_sided_inclusion_ok")):
            return "F1F2_oriented_one_sided_complement_replacement_finite_object", "complement_is_orientation_balanced_one_sided_not_Haag_dual"
        return "F1F2_oriented_complement_balance_replacement_control", "complement_error_contained_by_F1F2_signature_without_duality"
    return "F1F2_oriented_geometry_replacement_finite_object", "geometry_residual_contained_by_F1F2_signature"


def f1f2_oriented_geometry_replacement_rows(
    decomposed_measure_rows: List[dict],
    decomposed_geometry_rows: List[dict],
    f1f2_orientation_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Compare naive tensor-local geometry with a finite F1/F2-oriented replacement geometry.

    This surface does not statement AQFT locality, split, or Haag duality.  It tests
    which finite geometry actually organizes the observed residuals.  The naive
    comparator is tensor-local: residuals should vanish or improve just because
    regions are separated/collared.  The F1/F2 comparator is orientation-local:
    nonzero commutators, split residuals, and complement errors are allowed, but
    they must be contained by the normalized F1/F2 skew-signature scale and must
    be specific to the true birth-order history against F2-destroyed controls.
    """
    midx = _measure_index(decomposed_measure_rows)
    fidx = _f1f2_index(f1f2_orientation_rows)
    rows: List[dict] = []
    for dg in decomposed_geometry_rows:
        k = _key(dg)
        meas = midx.get(k, {})
        f1 = fidx.get(k, {})
        computed_status, law = _replacement_rule(dg, f1, meas, tol=tol)
        raw = _finite(dg.get("geometry_raw_rank_bound"))
        signature = _finite(dg.get("normalized_F1F2_signature_component", meas.get("normalized_F1F2_signature_component")))
        density = _finite(dg.get("density_support_component_JS_live_record", meas.get("density_support_component_JS_live_record")))
        strength = _finite(dg.get("F1F2_response_strength_component", meas.get("F1F2_response_strength_component")))
        row = {
            "branching": dg.get("branching"),
            "level": dg.get("level"),
            "mode": dg.get("mode"),
            "region_id": dg.get("region_id"),
            "region_family": dg.get("region_family"),
            "genealogical_corridor_length": dg.get("genealogical_corridor_length"),
            "geometry_surface": dg.get("geometry_surface"),
            "geometry_layer": dg.get("geometry_layer"),
            "finite_geometry_test_question": "which_F1F2_oriented_geometry_replaces_naive_tensor_local_AQFT_geometry",
            "naive_tensor_geometry_status": _naive_tensor_status(dg),
            "F1F2_replacement_law": law,
            "geometry_raw_rank_bound": raw,
            "density_support_component_JS_live_record": density,
            "normalized_F1F2_signature_component": signature,
            "F1F2_response_strength_component": strength,
            "rank_bound_per_density_support": _ratio(raw, density),
            "rank_bound_per_orientation_signature": _ratio(raw, signature),
            "rank_bound_per_response_strength": _ratio(raw, strength),
            "within_orientation_signature_scale": _bool01(dg.get("within_orientation_signature_scale")),
            "within_total_decomposed_measure_scale": _bool01(dg.get("within_total_decomposed_measure_scale")),
            "component_explanation": dg.get("component_explanation"),
            "component_dominance": dg.get("component_dominance"),
            "F1F2_true_record_beats_F2_flipped": _bool01(f1.get("F1F2_multishell_true_beats_F2_flipped_record")),
            "F1F2_true_record_gain_over_F2_flipped": _finite(f1.get("F1F2_multishell_true_record_gain_over_F2_flipped")),
            "F1F2_live_profile_nonzero": int(not _bool01(f1.get("F1F2_vacuous_zero_live_profile_current"))),
            "F1F2_record_profile_nonzero": int(not _bool01(f1.get("F1F2_vacuous_zero_record_profile_current"))),
            "F1F2_B_oriented_entropy_current_profile_norm": _finite(f1.get("F1F2_B_oriented_entropy_current_profile_norm")),
            "source_decomposed_geometry_computed_status": dg.get("decomposed_geometry_row_computed_status"),
            "source_decomposed_geometry_track_computed_status": dg.get("decomposed_geometry_track_computed_status"),
            "finite_complement_type": dg.get("finite_complement_type", ""),
            "one_sided_inclusion_ok": _bool01(dg.get("one_sided_inclusion_ok")),
            "two_sided_duality_ok": _bool01(dg.get("two_sided_duality_ok")),
            "F1F2_oriented_geometry_replacement_computed_status": computed_status,
        }
        rows.append(row)
    return rows


def _summary_computed_status(rows: List[dict]) -> str:
    n = len(rows)
    if n == 0:
        return "F1F2_replacement_summary_empty"
    finite_object = sum(1 for r in rows if "replacement_finite_object" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    weak = sum(1 for r in rows if "weak_control" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    obstructed = sum(1 for r in rows if "obstructed" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    naive_obstructed = sum(1 for r in rows if "obstructed" in str(r.get("naive_tensor_geometry_status")) or "only_one_sided" in str(r.get("naive_tensor_geometry_status")))
    if finite_object == n and naive_obstructed >= n // 2:
        return "F1F2_oriented_geometry_replaces_naive_tensor_local_geometry_finite_object"
    if finite_object + weak == n and obstructed == 0:
        return "F1F2_oriented_geometry_partially_replaces_naive_tensor_local_geometry_control"
    if finite_object > obstructed:
        return "F1F2_oriented_geometry_preferred_but_not_complete_control"
    return "F1F2_oriented_geometry_replacement_unresolved_or_obstructed"


def f1f2_oriented_geometry_replacement_summary_rows(rows: List[dict]) -> List[dict]:
    by_surface: Dict[str, List[dict]] = defaultdict(list)
    by_surface_layer: Dict[Tuple[str, str], List[dict]] = defaultdict(list)
    for r in rows:
        surface = str(r.get("geometry_surface"))
        layer = str(r.get("geometry_layer"))
        by_surface[surface].append(r)
        by_surface_layer[(surface, layer)].append(r)
    out: List[dict] = []
    for surface, xs in sorted(by_surface.items()):
        out.append(_summary_row("surface", surface, xs))
    for (surface, layer), xs in sorted(by_surface_layer.items()):
        out.append(_summary_row("surface_layer", f"{surface}:{layer}", xs))
    out.append(_summary_row("all", "all_finite_geometry_surfaces", rows))
    return out


def _summary_row(kind: str, label: str, xs: List[dict]) -> dict:
    n = len(xs)
    finite_objects = sum(1 for r in xs if "replacement_finite_object" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    weak = sum(1 for r in xs if "weak_control" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    exact_zero = sum(1 for r in xs if "exact_zero" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    obstructed = sum(1 for r in xs if "obstructed" in str(r.get("F1F2_oriented_geometry_replacement_computed_status")))
    naive_obstructed = sum(1 for r in xs if "obstructed" in str(r.get("naive_tensor_geometry_status")) or "only_one_sided" in str(r.get("naive_tensor_geometry_status")))
    f2_specific = sum(1 for r in xs if _bool01(r.get("F1F2_true_record_beats_F2_flipped")))
    return {
        "summary_kind": kind,
        "summary_label": label,
        "row_count": n,
        "naive_tensor_obstructed_or_one_sided_count": naive_obstructed,
        "F1F2_replacement_finite_object_count": finite_objects,
        "F1F2_replacement_weak_control_count": weak,
        "F1F2_replacement_exact_zero_control_count": exact_zero,
        "F1F2_replacement_obstructed_count": obstructed,
        "F1F2_true_record_beats_F2_flipped_count": f2_specific,
        "median_rank_bound_per_density_support": _median(_finite(r.get("rank_bound_per_density_support")) for r in xs),
        "median_rank_bound_per_orientation_signature": _median(_finite(r.get("rank_bound_per_orientation_signature")) for r in xs),
        "median_rank_bound_per_response_strength": _median(_finite(r.get("rank_bound_per_response_strength")) for r in xs),
        "median_F1F2_true_record_gain_over_F2_flipped": _median(_finite(r.get("F1F2_true_record_gain_over_F2_flipped")) for r in xs),
        "finite_geometry_replacement_summary_computed_status": _summary_computed_status(xs),
    }


def f1f2_oriented_geometry_replacement_report(rows: List[dict], summary: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("F1F2_oriented_geometry_replacement_computed_status", "unknown")) for r in rows})
    summary_computed_status_rows = sorted({str(r.get("finite_geometry_replacement_summary_computed_status", "unknown")) for r in summary})
    all_row = next((r for r in summary if r.get("summary_label") == "all_finite_geometry_surfaces"), {})
    return (
        "# F1/F2-oriented finite geometry replacement test\n\n"
        "This surface tests the concrete question: which finite geometry replaces naive tensor-local AQFT geometry in the current CNNA stack?  The comparator is not fitted.  Naive tensor-local geometry expects distance/collar monotonicity, tensor factorization, or two-sided complement duality.  The replacement finite_object is F1/F2-oriented: residuals may be nonzero, but they must be contained by the normalized F1/F2 skew-signature scale and must be specific to the true birth-order history against F2-destroyed controls.\n\n"
        f"Rows: {len(rows)}.\n\n"
        f"All-surface summary computed_status: `{all_row.get('finite_geometry_replacement_summary_computed_status', 'unavailable')}`.\n\n"
        f"Replacement finite_objects: {all_row.get('F1F2_replacement_finite_object_count', 0)}/{all_row.get('row_count', 0)}.\n\n"
        f"Naive tensor-obstructed or one-sided rows: {all_row.get('naive_tensor_obstructed_or_one_sided_count', 0)}/{all_row.get('row_count', 0)}.\n\n"
        f"Median rank_bound/orientation-signature ratio: {all_row.get('median_rank_bound_per_orientation_signature', 'nan')}.\n\n"
        "Row computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Summary computed_status_rows: `" + "`, `".join(summary_computed_status_rows) + "`.\n"
    )
