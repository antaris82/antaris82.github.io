from __future__ import annotations

from typing import List


TOPOLOGY_PRECEDENCE = {
    "dependency_topology": "finite_core stack architecture",
    "presentation_projection": "four-path dependency_table table",
    "precedence_rule": "The stack is the dependency order for and input-exclusion checks. The four-path table is a reader-facing projection of the same stack, not a competing dependency topology.",
    "one_particle_location_rule": "DtN S/A/J port forms are the coarse/pre-spectral instance of the L2 one-particle form layer. L2 refines them through the Layer-1 deformed complex. Coarse DtN form conditions may run before refinement; statistics/sector choice may not.",
}

STACK_LAYERS = (
    {
        "layer_id": "L0_provenance",
        "layer_name": "Provenance / birth register",
        "input_objects": "empty_state; deterministic sequential b-ary growth; branching b; finite horizon L",
        "export_objects": "birth_tree; record/live split; inherited uniform node measure; F1/F2 axes; birth-order ledger; response-construction functor producing live/record/sym Schur/DtN S/A forms on declared ports",
        "response_functor_position": "Response is not imported into L1 from above. It is an L0-exported construction functor applied to L0 provenance/ports; L1 consumes its live/sym Schur-DtN forms as lower-layer data.",
        "null_control": "sym tree as orientation-free birth/reference control",
        "forbidden_downward_imports": "metric geometry; i/complex structure; statistics; AQFT local algebra; spectral triple; CFS common measure",
        "current_core_status": "core locked; used as fundamental layer",
    },
    {
        "layer_id": "L1_deformed_simplicial_fractal_geometry",
        "layer_name": "Deformed local Sierpinski-like simplicial/fractal geometry",
        "input_objects": "L0 provenance; L0 response-construction functor outputs live/record/sym Schur/DtN S/A forms; F1/F2 orientation; inherited node/live weights",
        "export_objects": "deformed SG/ST-like simplicial approximant; resistance/Dirichlet weights; F1/F2 oriented 2-form on the complex; face incidence and occupancy data; pass-through coarse DtN S/A/J form data for L2 refinement",
        "null_control": "symmetric SG/ST-like reference, not physical CNNA target",
        "forbidden_downward_imports": "continuum metric; symmetric exact self-similarity as target; NCG Dirac operator; Fock statistics",
        "current_core_status": "dependency_table layer; finite F1/F2 replacement geometry supports this revision",
    },
    {
        "layer_id": "L2_NCG_one_particle_spectral_layer",
        "layer_name": "NCG / one-particle spectral layer",
        "input_objects": "L1 Dirichlet/resistance geometry; F1/F2 2-form; finite port/operator system; L1 pass-through coarse DtN S/A/J form data",
        "export_objects": "D_F1F2 finite_object; Lipschitz-seminorm proxy ||[D,a]||; spectral dimension proxy; deterministic polarization J; one-particle Hilbert space finite_object; refined one-particle S/A/J data; pass-through face statistics sector data",
        "null_control": "orientation-free commutative/symmetric spectral control; no distinguished J in sym column",
        "forbidden_downward_imports": "Connes spectral triple stated before D is derived; Tomita-J identified with CNNA-J; AQFT locality used to define D",
        "current_core_status": "not constructed; finite_core transition target",
    },
    {
        "layer_id": "L3_Fock_GNS_standard_subspace_layer",
        "layer_name": "Fock/GNS/standard-subspace field layer",
        "input_objects": "L2 refined one-particle S/A/J data; L2 pass-through face statistics sector data originally exported by L1; quasifree positivity conditions",
        "export_objects": "CCR/CAR/sectorwise Fock finite_object; quasifree state finite_object; standard subspaces; modular data; local vN-algebra preforms",
        "null_control": "tracial/symmetric quasifree control with Delta=I where applicable",
        "forbidden_downward_imports": "CCR/CAR chosen before statistics condition; Reeh-Schlieder imposed on finite DtN layer; AQFT net asserted before standard subspaces",
        "current_core_status": "bridge registered; not a finite_core property",
    },
    {
        "layer_id": "L4_AQFT_target_layer",
        "layer_name": "AQFT local net as effective/global target layer",
        "input_objects": "L3 net finite_object; limit/coarse-graining; positivity/spectrum-energy analogue; collar/complement structure",
        "export_objects": "local operator net; Haag-Kastler properties if proven; modular data; split/Reeh-Schlieder/Type-III derived_quantity rows",
        "null_control": "Type-I/null AQFT-like symmetric control; no nontrivial vacuum selection from sym alone",
        "forbidden_downward_imports": "using AQFT axioms to define lower-layer regions, statistics, metric, or measure",
        "current_core_status": "long target path only",
    },
)


TRANSITIONS = (
    {
        "transition_id": "T01",
        "transition_name": "Provenance -> deformed simplicial/fractal geometry",
        "from_layer": "L0_provenance",
        "to_layer": "L1_deformed_simplicial_fractal_geometry",
        "reference_question": "Does the deterministic birth/provenance tree push forward to a deformed, non-exactly-self-similar Sierpinski-like simplicial/resistance geometry?",
        "export_contract": "weighted simplicial complex; resistance/Dirichlet form; F1/F2 oriented 2-form; face incidence statistics; pass-through coarse DtN S/A/J forms",
        "failure_contract": "no compatible resistance form; symmetric SG/ST null not recovered; live deformation indistinguishable from sym; F1/F2 orientation lost",
    },
    {
        "transition_id": "T12",
        "transition_name": "Deformed geometry -> NCG / one-particle spectral layer",
        "from_layer": "L1_deformed_simplicial_fractal_geometry",
        "to_layer": "L2_NCG_one_particle_spectral_layer",
        "reference_question": "Can the deformed Dirichlet/F1F2 data generate a stable Dirac/spectral-seminorm/polarization layer?",
        "export_contract": "D_F1F2; one-particle Hilbert space; refined S/A/J; deterministic polarization J; spectral dimension; Lipschitz seminorm finite_object; pass-through face statistics sector data",
        "failure_contract": "no stable D; commutator norms blow up; sym produces orientation; refined-to-coarse spectral stability fails",
    },
    {
        "transition_id": "T23",
        "transition_name": "NCG / one-particle layer -> Fock/GNS/standard-subspace layer",
        "from_layer": "L2_NCG_one_particle_spectral_layer",
        "to_layer": "L3_Fock_GNS_standard_subspace_layer",
        "reference_question": "Do S/A/J and derived statistics support a quasifree CCR/CAR/standard-subspace construction?",
        "export_contract": "statistics sector; quasifree state; standard subspaces; modular data; one-particle-to-field functor input",
        "failure_contract": "dominance inequality fails; symplectic quotient invalid; deterministic J incompatible; statistics not derivable",
    },
    {
        "transition_id": "T34",
        "transition_name": "Fock/GNS/standard-subspace layer -> AQFT target layer",
        "from_layer": "L3_Fock_GNS_standard_subspace_layer",
        "to_layer": "L4_AQFT_target_layer",
        "reference_question": "Does the correctly layered field construction produce a local AQFT-net finite_object with stable limit derived_quantity rows?",
        "export_contract": "local vN algebra net finite_object; AQFT observables; modular data; Type-III trajectory derived_quantity rows",
        "failure_contract": "no locality after correct layer; no standard-subspace net; no spectrum/energy positivity analogue; split/collar remains unresolved at field layer",
    },
)


CONDITIONS = (
    ("T01", "T01_G1_tree_to_simplicial_duality_kinematics", "measure the dual contraction/subdivision kinematics, incidence constraints and b=3/b=4 dimensional sector data", "dual incidence table; birth-to-simplex map", "kinematics not compatible or not measurable"),
    ("T01", "T01_G2_live_weight_pushforward_to_resistance_form", "push live Schur/DtN weights to graph/simplicial resistance or conductance weights", "weighted approximant; resistance matrix", "no positive/consistent resistance weights"),
    ("T01", "T01_G3_Kigami_Sabot_harmonic_structure_existence", "test finite harmonic-extension/eigenform convergence for deformed weights", "Dirichlet/resistance form finite_object", "renormalization does not converge or violates positivity"),
    ("T01", "T01_G4_sym_SG_ST_null_recovery", "recover symmetric SG/ST reference behavior in the sym column", "symmetric null approximant", "sym fails standard/null recovery"),
    ("T01", "T01_G5_deformation_nontriviality_live_vs_sym", "separate live deformation from symmetric null geometry", "deformation residual; F1/F2 2-form on complex", "live and sym indistinguishable"),
    ("T12", "T12_G1_D_F1F2_construction", "derive D_F1F2 from F1/F2 2-form, Dirichlet energy or topological Dirac comparison", "Dirac-type operator finite_object", "no stable self/skew-adjoint sign_relation"),
    ("T12", "T12_G2_bounded_commutator_proxy", "test finite bounded-commutator proxy ||[D,a]|| over port/operator generators", "Lipschitz seminorm table", "commutator norms unstable or blow up under refinement"),
    ("T12", "T12_G3_spectral_dimension_consistency", "track spectral dimension across L, b, live/sym and refined/coarse bases", "spectral dimension trajectory", "dimension is unstable or sym contaminated"),
    ("T12", "T12_G4_F1F2_polarization_J_consistency", "compare deterministic polarization from S/A with F1/F2-derived orientation", "J-polarization residuals", "J not compatible or sym produces J"),
    ("T12", "T12_G5_refined_to_coarse_spectral_stability", "coarse refined spectral data back to the older role basis", "coarse-recovery residual", "refined basis changes model instead of refining it"),
    ("T12", "T12_G6_topological_Dirac_comparison_Bianconi", "compare CNNA D_F1F2 to simplicial/topological Dirac on the deformed complex", "Dirac comparison spectrum", "topological Dirac comparison incompatible"),
    ("T23", "T23_G1_symplectic_rank_and_kernel", "compute rank/kernel of the skew form on the quotient support", "symplectic quotient data", "kernel handling invalid or odd/nonstable rank"),
    ("T23", "T23_G2_quasifree_dominance_inequality", "test |A(f,g)|^2 <= 4 S(f,f) S(g,g) without epsilon-floor", "dominance ratio table", "dominance inequality fails"),
    ("T23", "T23_G3_deterministic_polarization_from_SA", "derive deterministic polarization J from S/A and compare to F1/F2 orientation", "polarization residuals", "J^2 or compatibility fails"),
    ("T23", "T23_G4_face_statistics_to_CCR_CAR_sector", "derive sectorwise CCR/CAR/Boltzmann choice from face statistics rather than imposing it", "statistics sector map", "statistics not derivable or bridge to operator relations fails"),
    ("T23", "T23_G5_standard_subspace_reality_and_cyclicity_comparison", "build finite standard-subspace preforms over real one-particle data", "standard-subspace residuals", "subspaces not standard or modular data invalid"),
    ("T23", "T23_G6_Fock_null_sym_tracial_control", "propacondition sym as tracial/Fock null control", "sym modular/null derived_quantity rows", "sym produces nontrivial field dynamics"),
    ("T34", "T34_G1_local_net_isotony_after_Fock", "test local net isotony after the Fock/standard-subspace layer, not on raw DtN", "field-layer isotony residuals", "isotony fails at correct layer"),
    ("T34", "T34_G2_symplectic_spacelike_locality_A_decay", "test A/symplectic form decay/vanishing between spacelike/collared port supports", "field-layer locality derived_quantity rows", "no locality after correct layer"),
    ("T34", "T34_G3_Haag_duality_preform_after_standard_subspaces", "test complement/commutant after standard-subspace construction", "duality preform residuals", "duality remains obstructed"),
    ("T34", "T34_G4_split_property_with_collar_after_Fock", "test collar split after the field layer", "split/collar residuals", "split remains unresolved despite collar"),
    ("T34", "T34_G5_Reeh_Schlieder_preform_no_finite_rank_contradiction", "retest cyclicity after Fock, where finite matrix-rank rank_bound no longer applies", "cyclicity/separating derived_quantity rows", "no cyclicity even at correct layer"),
    ("T34", "T34_G6_modular_spectrum_TypeIII_limes_derived_quantity", "track modular spectrum and ratio-cloud after field-layer construction", "Type-III limes derived_quantity rows", "spectrum collapses to Type-I/tracial behavior"),
)


CFS_CROSS_AXIS = (
    {
        "condition_id": "CFS_G1_operator_point_cloud_XR",
        "axis_object": "finite operator point cloud X_R from ports/regions",
        "test_question": "Can CNNA regions/ports be mapped to finite-rank operator points without importing spacetime?",
        "export": "operator point set F_L subset End(H_L)",
        "failure": "no stable operator-point map",
    },
    {
        "condition_id": "CFS_G2_pushforward_measure_rho_L",
        "axis_object": "pushforward measure rho_L",
        "test_question": "Does inherited uniform/live weight push forward to a stable measure on operator points?",
        "export": "rho_L on F_L",
        "failure": "measure is only pairwise derived_quantity, not structural rho_L",
    },
    {
        "condition_id": "CFS_G3_support_as_spacetime_finite_object",
        "axis_object": "support of rho_L",
        "test_question": "Does supp(rho_L) carry the finite spacetime finite_object rather than an imposed graph?",
        "export": "operator-support spacetime finite_object",
        "failure": "support has no stable geometry",
    },
    {
        "condition_id": "CFS_G4_causal_spectral_relation_XR_XS",
        "axis_object": "spectra of products X_R X_S",
        "test_question": "Do product spectra organize causal/separation data consistently with F1/F2-oriented locality?",
        "export": "causal spectral relation table",
        "failure": "no spectral causal organization",
    },
    {
        "condition_id": "CFS_G5_action_like_measure_variation",
        "axis_object": "finite action-like derived_quantity",
        "test_question": "Is there a noncircular action-like variation tied to live/record Backreaction?",
        "export": "variation/action proxy",
        "failure": "only descriptive measure, no variational structure",
    },
    {
        "condition_id": "CFS_G6_Finster_docking_report",
        "axis_object": "comparison with CFS primitives",
        "test_question": "Which CFS objects are actually constructed: H, F, rho, causal relation, action?",
        "export": "docking/overstatement report",
        "failure": "CFS vocabulary unsupported by constructed objects",
    },
)


INPUT_EXCLUSION_RULES = (
    {
        "rule_id": "AS1_no_downward_import",
        "rule": "Layer k may export to layer k+1; layer k+1 may not define layer k objects retroactively.  Pass-through from lower layers is allowed only when explicitly listed in the export contract and carried by intervening layers.",
        "examples_forbidden": "AQFT locality defining DtN regions; Fock statistics chosen before face statistics; Dirac imported before F1/F2/Dirichlet derivation; CFS common measure asserted before rho_L construction",
    },
    {
        "rule_id": "AS2_sym_full_stack_control",
        "rule": "The sym column must propacondition through every layer as the null/reference world.",
        "examples_forbidden": "sym produces F1/F2 orientation, nontrivial modular spread, statistics-sector parameter_dependence, or CFS-like causal structure without live deformation",
    },
    {
        "rule_id": "AS3_geometry_revision_condition_note",
        "rule": "Only metric continuum geometry is postponed; finite oriented F1/F2 geometry is an intermediate derived layer.",
        "examples_forbidden": "treating Layer-1 geometry as externally given or as symmetric SG/ST target geometry",
    },
)


def topology_precedence_rows() -> List[dict]:
    return [dict(TOPOLOGY_PRECEDENCE)]


def stack_layer_rows() -> List[dict]:
    return [dict(row) for row in STACK_LAYERS]


def stack_transition_rows() -> List[dict]:
    return [dict(row) for row in TRANSITIONS]


def condition_register_rows() -> List[dict]:
    rows: List[dict] = []
    for transition_id, condition_id, question, export, failure in CONDITIONS:
        transition = next(row for row in TRANSITIONS if row["transition_id"] == transition_id)
        rows.append({
            "transition_id": transition_id,
            "from_layer": transition["from_layer"],
            "to_layer": transition["to_layer"],
            "condition_id": condition_id,
            "test_question": question,
            "export_if_passes": export,
            "failure_if_fails": failure,
            "current_core_status": "planned_condition_not_stated_in_current_core",
            "input_exclusion_required": 1,
        })
    return rows


def cfs_cross_axis_rows() -> List[dict]:
    return [dict(row, current_core_status="cross_axis_condition_planned_not_stated") for row in CFS_CROSS_AXIS]


def input_exclusion_rule_rows() -> List[dict]:
    return [dict(row) for row in INPUT_EXCLUSION_RULES]


def stack_architecture_report() -> str:
    lines = [
        "# finite_core stack architecture dependency_table",
        "",
        "The former four research ways are no longer treated as independent competitors.  The finite_core working hypothesis is a layered stack: provenance -> deformed F1/F2-oriented simplicial/fractal geometry -> NCG/one-particle spectral layer -> Fock/GNS/standard-subspace layer -> AQFT target layer.  CFS is not a layer; it is a cross-axis of measure/state selection through the stack.",
        "",
        "Normative precedence: the stack is the dependency topology.  The four-path dependency_table table is only the presentation projection of the stack and must not be read as a flat priority/dependency graph.",
        "",
        "## Official architecture revision",
        "",
        "Old wording: geometry is postponed.  New wording: metric continuum geometry is postponed; finite oriented F1/F2 geometry is an intermediate derived layer.  This is forced by the decomposition/replacement surfaces, where the normalized F1/F2 skew signature organizes the finite locality/split/complement rank_bounds.",
        "",
        "## One-particle layer location rule",
        "",
        "DtN port forms S/A/J are the coarse/pre-spectral instance of the one-particle form layer.  Layer 2 refines them over the Layer-1 deformed simplicial/fractal complex.  Therefore early dominance/polarization conditions may run on coarse DtN forms, but statistics/sector selection may not be made before Layer-1 face statistics are exported and passed through Layer 2.",
        "",
        "## Layers",
        "",
    ]
    for row in STACK_LAYERS:
        lines.append(f"- `{row['layer_id']}`: {row['layer_name']} exports {row['export_objects']}.")
    lines.extend(["", "## Export/pass-through contract patch",
        "",
        "The measurement-identified leaks are closed as follows: L0 exports the response-construction functor and its Schur/DtN S/A outputs; L1 passes coarse DtN S/A/J and face statistics forward; L2 exports refined S/A/J and passes face-statistics sector data to L3.  This keeps the no-downward-import rule checkable.",
        "",
        "## Transitions", ""])
    for row in TRANSITIONS:
        lines.append(f"- `{row['transition_id']}` {row['from_layer']} -> {row['to_layer']}: {row['reference_question']}")
    lines.extend([
        "",
        "## CFS cross-axis",
        "",
        "CFS is recorded as a measure/operator-space axis, not as a stack layer.  CNNA must construct operator points X_R and a pushforward measure rho_L before using CFS common-measure language.",
        "",
        "## Full-stack null control",
        "",
        "The sym column must propacondition as: sym tree -> symmetric SG/ST reference -> orientation-free spectral control -> tracial/Fock null control -> Type-I/null AQFT-like control.  Nontrivial F1/F2 orientation or modular/measure parameter_dependence in sym is contamination.",
    ])
    return "\n".join(lines) + "\n"


def condition_register_report() -> str:
    lines = [
        "# Derived stack condition register",
        "",
        "Every condition is a falsifiable transition test.  No condition may consume objects from a higher layer.  Passing a condition exports objects to the next layer; failing a condition localizes the rank_bound without falsifying lower layers.",
        "",
    ]
    for row in TRANSITIONS:
        lines.append(f"## {row['transition_id']} — {row['transition_name']}")
        lines.append("")
        for condition in [g for g in condition_register_rows() if g["transition_id"] == row["transition_id"]]:
            lines.append(f"- `{condition['condition_id']}`: {condition['test_question']} Export: {condition['export_if_passes']}. Failure: {condition['failure_if_fails']}.")
        lines.append("")
    lines.append("## CFS cross-axis conditions")
    lines.append("")
    for row in CFS_CROSS_AXIS:
        lines.append(f"- `{row['condition_id']}`: {row['test_question']} Export: {row['export']}. Failure: {row['failure']}.")
    return "\n".join(lines) + "\n"
