from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    joined_algebra,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.refined_port_basis import (
    refined_boundary_role_basis as refined_boundary_role_basis_for_tests,
    refined_regional_response,
    refined_support_algebra,
)
from cnna.core.region_response import region_size_meta


def _median(xs: List[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys)//2]) if ys else math.nan


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("level"), r.get("mode"), r.get("refined_split_layer"))


def _summarize(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        if c >= 0:
            by_c[c].append(float(r.get("refined_tensor_dimension_residual", math.nan)))
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"refined_split_track_computed_status": "refined_split_insufficient_collar_track"}
    vals = [_median(by_c[c]) for c in cs]
    if max(abs(v) for v in vals if math.isfinite(v)) <= tol:
        computed_status = "refined_split_tensor_factorization_finite_object"
    elif vals[-1] < vals[0]:
        computed_status = "refined_split_residual_decreases_with_collar_finite_object"
    elif vals[-1] > vals[0]:
        computed_status = "refined_split_residual_grows_with_collar_observed"
    else:
        computed_status = "refined_split_no_monotone_improvement_observed"
    return {
        "refined_split_collar_count": int(len(cs)),
        "refined_split_first_collar": int(cs[0]),
        "refined_split_last_collar": int(cs[-1]),
        "refined_split_first_residual_median": float(vals[0]),
        "refined_split_last_residual_median": float(vals[-1]),
        "refined_split_track_computed_status": computed_status,
    }


def collared_split_refined_basis_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            _Q, _names, bmeta = refined_boundary_role_basis_for_tests(model, spec)
            resp = refined_regional_response(model, spec, "live")
            if resp is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, **bmeta, "refined_split_row_computed_status": "response_unavailable"})
                continue
            for layer in ("S", "A", "mixed"):
                left = refined_support_algebra(resp, "left", layer, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                right = refined_support_algebra(resp, "right", layer, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                join = joined_algebra("refined_split_join_" + layer, [left, right], tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                cm = commutator_metrics(left, right)
                product_dim = int(len(left.basis) * len(right.basis))
                shared_floor = int(max(1, len(left.basis) + len(right.basis) - 1))
                join_dim = int(len(join.basis))
                tensor_ratio = float(join_dim / max(1, product_dim))
                residual = float(max(0.0, 1.0 - tensor_ratio))
                corridor = int(meta["genealogical_corridor_length"])
                if corridor == 0:
                    row_computed_status = "touching_sibling_refined_split_reference_row"
                elif cm["max_relative_commutator"] <= config.algebra_tol and residual <= config.algebra_tol:
                    row_computed_status = "collared_refined_split_tensor_finite_object_row"
                elif corridor >= 2:
                    row_computed_status = "collared_refined_split_residual_row"
                else:
                    row_computed_status = "uncollared_refined_split_row"
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    **bmeta,
                    "state": "live",
                    "refined_split_layer": layer,
                    "left_dim": len(left.basis),
                    "right_dim": len(right.basis),
                    "generated_join_dim": join_dim,
                    "tensor_product_dimension_proxy": product_dim,
                    "shared_identity_span_floor_proxy": shared_floor,
                    "join_to_tensor_dimension_ratio": tensor_ratio,
                    "join_to_shared_identity_span_floor_ratio": float(join_dim / max(1, shared_floor)),
                    "refined_tensor_dimension_residual": residual,
                    "max_relative_commutator": cm["max_relative_commutator"],
                    "refined_split_row_computed_status": row_computed_status,
                })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        if "refined_tensor_dimension_residual" in r:
            tracks[_track_key(r)].append(r)
    summaries = {k: _summarize(v, config.algebra_tol) for k, v in tracks.items()}
    for r in rows:
        r.update(summaries.get(_track_key(r), {}))
    return rows


def collared_split_refined_basis_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("refined_split_track_computed_status", "unknown")) for r in rows if "refined_split_track_computed_status" in r})
    return (
        "# Collared split test in the refined boundary-port basis\n\n"
        "This addresses the finite split/collar rank_bound with more than the 3-role carrier.  "
        "It remains a finite tensor-dimension proxy and does not assert the AQFT split property.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
