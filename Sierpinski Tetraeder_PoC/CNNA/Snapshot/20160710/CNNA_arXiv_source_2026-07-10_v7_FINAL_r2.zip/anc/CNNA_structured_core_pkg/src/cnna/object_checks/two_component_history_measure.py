from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(pairs) < 2:
        return math.nan
    mx = sum(x for x, _ in pairs) / float(len(pairs))
    my = sum(y for _, y in pairs) / float(len(pairs))
    dx = [x - mx for x, _ in pairs]
    dy = [y - my for _, y in pairs]
    den = math.sqrt(sum(x * x for x in dx) * sum(y * y for y in dy))
    return float(sum(x * y for x, y in zip(dx, dy)) / den) if den > 0.0 else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("region_id"),
        row.get("genealogical_corridor_length"),
    )


def _history_index(history_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {
        _key(r): r
        for r in history_rows
        if r.get("measure_surface") == "history_live_measure_finite_object"
    }


def _f1f2_index(f1f2_orientation_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {_key(r): r for r in f1f2_orientation_rows if "F1F2_orientation_resolution_computed_status" in r}


def _track_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("mode"),
        row.get("region_family"),
        row.get("genealogical_corridor_length"),
    )


def _augment_tracks(rows: List[dict], tol: float) -> None:
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        tracks[_track_key(r)].append(r)
    for key, xs in tracks.items():
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            try:
                L = int(r.get("level", -1))
            except Exception:
                L = -1
            if L >= 0:
                by_l[L].append(r)
        levels = sorted(by_l)
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            f = _median(_finite(r.get("two_component_history_measure_additive")) for r in by_l[first])
            l = _median(_finite(r.get("two_component_history_measure_additive")) for r in by_l[last])
            if math.isfinite(f) and math.isfinite(l) and l > f + max(tol, tol * max(1.0, abs(f))):
                trend = "two_component_history_measure_deepens_with_level"
            elif math.isfinite(f) and math.isfinite(l) and l < f - max(tol, tol * max(1.0, abs(f))):
                trend = "two_component_history_measure_decreases_with_level"
            else:
                trend = "two_component_history_measure_level_stable_or_unresolved"
            meta = {
                "two_component_measure_track_level_count": int(len(levels)),
                "two_component_measure_first_level": int(first),
                "two_component_measure_last_level": int(last),
                "two_component_measure_first_level_median": f,
                "two_component_measure_last_level_median": l,
                "two_component_history_measure_level_trend": trend,
            }
        else:
            meta = {
                "two_component_measure_track_level_count": int(len(levels)),
                "two_component_history_measure_level_trend": "two_component_measure_level_trend_unavailable",
            }
        js = [_finite(r.get("JS_live_record_no_epsilon")) for r in xs]
        prof = [_finite(r.get("F1F2_profile_gap_live_record")) for r in xs]
        total = [_finite(r.get("two_component_history_measure_additive")) for r in xs]
        bnorm = [_finite(r.get("backreaction_current_norm")) for r in xs]
        mod = [_finite(r.get("modular_spread_live")) for r in xs]
        meta.update({
            "corr_two_component_measure_vs_JS": _pearson(total, js),
            "corr_two_component_measure_vs_F1F2_profile_gap": _pearson(total, prof),
            "corr_two_component_measure_vs_B_norm": _pearson(total, bnorm),
            "corr_two_component_measure_vs_live_modular_spread": _pearson(total, mod),
        })
        for r in xs:
            r.update(meta)


def two_component_history_measure_rows(
    history_rows: List[dict],
    f1f2_orientation_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Combine density/history JS with the resolved F1/F2 skew 2-form gap.

    7 made `JS(live,record)` the parameter_stable finite carrier/history distance.
    11 showed that the birth-order-sensitive part is not fully visible in
    density alone: it lives in the provenance-derived skew F1/F2 2-form profile.
    This surface keeps both components explicit and uses the additive score as
    the reference geometry order parameter.
    """
    hidx = _history_index(history_rows)
    fidx = _f1f2_index(f1f2_orientation_rows)
    rows: List[dict] = []
    for key, h in hidx.items():
        f = fidx.get(key, {})
        js = _finite(h.get("JS_live_record_no_epsilon"))
        profile_gap = _finite(f.get("F1F2_profile_gap_live_record"))
        if not math.isfinite(profile_gap):
            profile_gap = math.nan
        additive = js + profile_gap if math.isfinite(js) and math.isfinite(profile_gap) else math.nan
        euclidean = math.sqrt(js * js + profile_gap * profile_gap) if math.isfinite(js) and math.isfinite(profile_gap) else math.nan
        uniform_gain = _finite(h.get("record_tracking_gain_over_uniform"))
        f2_gain = _finite(f.get("F1F2_multishell_true_record_gain_over_F2_flipped"))
        f2_beats = int(f.get("F1F2_multishell_true_beats_F2_flipped_record", 0) or 0)
        fcomputed_status = str(f.get("F1F2_orientation_resolution_computed_status", "F1F2_resolution_unavailable"))
        if not math.isfinite(js):
            computed_status = "two_component_history_measure_density_component_unavailable"
        elif not math.isfinite(profile_gap):
            computed_status = "two_component_history_measure_F1F2_component_unavailable"
        elif profile_gap <= max(tol, tol * max(1.0, abs(js))):
            computed_status = "two_component_history_measure_density_dominant_control"
        elif uniform_gain > tol and f2_beats:
            computed_status = "two_component_history_measure_F1F2_supported_finite_object"
        elif uniform_gain > tol:
            computed_status = "two_component_history_measure_density_supported_F1F2_unresolved_control"
        else:
            computed_status = "two_component_history_measure_unresolved_or_obstructed"
        rows.append({
            "branching": h.get("branching"),
            "level": h.get("level"),
            "mode": h.get("mode"),
            "region_id": h.get("region_id"),
            "region_family": h.get("region_family"),
            "genealogical_corridor_length": h.get("genealogical_corridor_length"),
            "measure_relations": "two_component_history_measure_JS_density_plus_F1F2_skew_2form_profile_gap",
            "density_component_relations": "JS_live_record_no_epsilon_on_positive_support_density",
            "skew_component_relations": "relative_norm_of_A_live_minus_A_record_on_provenance_derived_F1_shells_by_F2_shells",
            "two_component_history_measure_reference_formula": "JS_live_record_no_epsilon + F1F2_profile_gap_live_record",
            "JS_live_record_no_epsilon": js,
            "F1F2_profile_gap_live_record": profile_gap,
            "two_component_history_measure_additive": additive,
            "two_component_history_measure_euclidean_control": euclidean,
            "record_tracking_gain_over_uniform": uniform_gain,
            "F1F2_true_record_gain_over_F2_flipped": f2_gain,
            "F1F2_true_record_beats_F2_flipped_record": f2_beats,
            "F1F2_orientation_resolution_computed_status": fcomputed_status,
            "backreaction_current_norm": _finite(h.get("backreaction_current_norm")),
            "modular_spread_live": _finite(h.get("modular_spread_live")),
            "JS_per_B_norm": _finite(h.get("JS_live_record_per_backreaction_current_norm")),
            "two_component_history_measure_computed_status": computed_status,
        })
    _augment_tracks(rows, tol)
    return rows


def two_component_history_measure_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("two_component_history_measure_computed_status", "unknown")) for r in rows})
    supported = sum(1 for r in rows if str(r.get("two_component_history_measure_computed_status", "")) == "two_component_history_measure_F1F2_supported_finite_object")
    density = sum(1 for r in rows if str(r.get("two_component_history_measure_computed_status", "")) == "two_component_history_measure_density_supported_F1F2_unresolved_control")
    return (
        "# Two-component history/live measure\n\n"
        "This surface combines the 7 support/carrier component `JS(live,record)` with the 11 provenance-derived F1/F2 skew 2-form profile gap.  The additive score is the reference finite geometry order parameter; the Euclidean score is reported only as a control.\n\n"
        f"F1/F2-supported finite_objects: {supported}/{len(rows)}.\n\n"
        f"Density-supported but F1/F2-unresolved controls: {density}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
