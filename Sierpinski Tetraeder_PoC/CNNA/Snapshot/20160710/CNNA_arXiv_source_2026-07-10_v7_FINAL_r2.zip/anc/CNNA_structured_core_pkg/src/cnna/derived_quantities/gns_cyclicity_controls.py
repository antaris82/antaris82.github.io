from __future__ import annotations

from typing import List, Tuple

import numpy as np

from cnna.core.algebra_support import gns_cyclic_rank
from cnna.core.response_algebra import AlgebraBasis, algebra_closure, measurement_gns


def _control_algebras(tol: float, max_iter: int) -> Tuple[AlgebraBasis, AlgebraBasis, AlgebraBasis]:
    """Return scalar, diagonal, and full real 2x2 matrix algebras."""
    I = np.eye(2, dtype=float)
    Z = np.diag([1.0, -1.0])
    E12 = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=float)
    scalar = algebra_closure("scalar_RI", [I], tol=tol, max_iter=max_iter)
    diagonal = algebra_closure("diagonal_D2", [I, Z], tol=tol, max_iter=max_iter)
    full = algebra_closure("full_M2R", [I, E12], tol=tol, max_iter=max_iter)
    return scalar, diagonal, full


def finite_gns_cyclicity_control_rows(tol: float = 1.0e-10, max_iter: int = 8) -> List[dict]:
    """Positive and negative finite controls for the explicit cyclic-span rank test.

    Cyclicity is measured relative to the GNS support of the stated ambient
    algebra.  The proper scalar/diagonal subalgebras are expected not to span
    that ambient support, while the full algebra is expected to do so.  These
    controls ensure that the rank test is discriminating rather than a
    tautological dimension comparison.
    """
    scalar, diagonal, full = _control_algebras(tol, max_iter)
    tracial = 0.5 * np.eye(2, dtype=float)
    pure = np.diag([1.0, 0.0])
    cases = [
        ("full_M2R_tracial_positive_control", full, full, tracial, 1),
        ("diagonal_in_M2R_tracial_negative_control", diagonal, full, tracial, 0),
        ("full_M2R_rank_one_positive_control", full, full, pure, 1),
        ("scalar_in_M2R_rank_one_negative_control", scalar, full, pure, 0),
    ]
    rows: List[dict] = []
    for name, local_alg, global_alg, density, expected in cases:
        cyclic_rank, support_dim = gns_cyclic_rank(local_alg, global_alg, density, tol)
        actual = int(support_dim > 0 and cyclic_rank == support_dim)
        full_gns = measurement_gns(global_alg, density, tol)
        rows.append({
            "control_name": name,
            "local_algebra": local_alg.name,
            "global_algebra": global_alg.name,
            "local_algebra_dim": len(local_alg.basis),
            "global_algebra_dim": len(global_alg.basis),
            "global_gns_support_dim": support_dim,
            "local_cyclic_span_rank": cyclic_rank,
            "expected_cyclic_for_global_support": expected,
            "actual_cyclic_for_global_support": actual,
            "control_pass": int(actual == expected),
            "global_measurement_cyclic_ok": int(full_gns.cyclic_ok),
            "global_measurement_cyclic_span_rank": full_gns.cyclic_span_rank,
            "global_measurement_representation_ok": int(full_gns.representation_ok),
            "computed_status": "finite_GNS_cyclicity_control_pass" if actual == expected else "finite_GNS_cyclicity_control_fail",
            "condition_note": "explicit_rank_of_local_action_on_identity_class_inside_global_GNS_support",
        })
    return rows


__all__ = ["finite_gns_cyclicity_control_rows"]
