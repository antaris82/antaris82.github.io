from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.derived_quantities.structural_ledgers import is_reference_model
from cnna.derived_quantities.operator_stack_residuals import (
    FullRegionData,
    build_first_region_data,
    common_labels,
    pi_role_project,
    project_to_label_span,
    reconstruct_from_labels,
    role_projection_residual,
)


@dataclass
class RegionMeasurementSnapshot:
    b: int
    L: int
    mode: str
    state: str
    region_id: str
    boundary_count: int
    interior_count: int
    role_dim: int
    role_names: List[str]
    open_row_sum_residual: float
    open_cond_KII: float
    open_solve_residual: float
    closed_available: int
    closed_row_sum_residual: float
    closed_cond_KII: float
    closed_solve_residual: float
    Lc_open: np.ndarray
    D: np.ndarray
    gens: Dict[str, np.ndarray]


def _state_edges(model: EmptySetGrowthModel, state: str):
    return model.record_edges if state == "record" else model.live_edges


def _selected_schur_response(model: EmptySetGrowthModel, state: str, boundary: Sequence[int], interior: Sequence[int], include_external_degrees: bool) -> SchurResponse:
    """Local Schur response with explicit grounded/open vs closed-internal relations.

    include_external_degrees=True reproduces the 0/1 regional response:
    selected-node diagonal degrees include conductance to the full current network.

    include_external_degrees=False uses only edges with both endpoints in the selected
    B∪I region, which is the closed-internal comparison.  It is derived_quantity only and
    may become singular for some regions.
    """
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    if not B:
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "empty_boundary")
    if set(B) & set(I):
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "boundary_interior_overlap")
    selected = B + I
    selected_set = set(selected)
    pos = {nid: k for k, nid in enumerate(selected)}
    Kloc = np.zeros((len(selected), len(selected)), dtype=float)
    edges = _state_edges(model, state)
    pair_keys = set()
    for i, j in edges.keys():
        if i != j:
            pair_keys.add((min(i, j), max(i, j)))
    for i, j in pair_keys:
        cij = 0.5 * (float(edges.get((i, j), 0.0)) + float(edges.get((j, i), 0.0)))
        if cij <= 0.0:
            continue
        both_selected = i in selected_set and j in selected_set
        if include_external_degrees or both_selected:
            if i in pos:
                Kloc[pos[i], pos[i]] += cij
            if j in pos:
                Kloc[pos[j], pos[j]] += cij
        if both_selected:
            Kloc[pos[i], pos[j]] -= cij
            Kloc[pos[j], pos[i]] -= cij
    bidx = list(range(len(B)))
    iidx = list(range(len(B), len(B) + len(I)))
    return schur_response(Kloc, bidx, iidx)


def _first_snapshot(model: EmptySetGrowthModel, state: str, args) -> Optional[RegionMeasurementSnapshot]:
    for spec in build_sibling_regions(model, max_regions=max(1, args.max_regions)):
        if len(spec.boundary) > args.max_boundary or len(spec.interior) > args.max_interior:
            continue
        open_res = _selected_schur_response(model, state, spec.boundary, spec.interior, include_external_degrees=True)
        if not open_res.ok or open_res.Lambda is None:
            continue
        closed_res = _selected_schur_response(model, state, spec.boundary, spec.interior, include_external_degrees=False)
        Q, role_names = boundary_role_basis(model, spec)
        Lc = compress_response(open_res.Lambda, Q)
        D = positive_density_from_response(Lc)
        gens = gens_from_response(Lc)
        return RegionMeasurementSnapshot(
            b=model.b,
            L=model.L,
            mode=model.mode,
            state=state,
            region_id=spec.region_id,
            boundary_count=len(spec.boundary),
            interior_count=len(spec.interior),
            role_dim=int(Q.shape[1]),
            role_names=list(role_names),
            open_row_sum_residual=float(open_res.row_sum_residual),
            open_cond_KII=float(open_res.cond_KII),
            open_solve_residual=float(open_res.solve_residual),
            closed_available=int(closed_res.ok and closed_res.Lambda is not None),
            closed_row_sum_residual=float(closed_res.row_sum_residual) if closed_res.ok and closed_res.Lambda is not None else math.nan,
            closed_cond_KII=float(closed_res.cond_KII),
            closed_solve_residual=float(closed_res.solve_residual),
            Lc_open=Lc,
            D=D,
            gens=gens,
        )
    return None


def _snapshots(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> Dict[Tuple[int, int, str, str], Optional[RegionMeasurementSnapshot]]:
    out: Dict[Tuple[int, int, str, str], Optional[RegionMeasurementSnapshot]] = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            out[(b, L, mode, st)] = _first_snapshot(model, st, args)
    return out


def _span_rank(gens: Dict[str, np.ndarray], labels: Sequence[str], tol: float) -> Tuple[int, int, int, float, float]:
    present = [x for x in labels if x in gens]
    if not present:
        return 0, 0, 0, math.nan, math.nan
    mats = [gens[x].reshape(-1) for x in present]
    B = np.column_stack(mats)
    s = np.linalg.svd(B, compute_uv=False)
    maxs = float(np.max(s)) if s.size else 0.0
    threshold = max(tol, tol * max(1.0, maxs))
    rank = int(np.sum(s > threshold))
    zero = int(sum(fro(gens[x]) <= threshold for x in present))
    cond = float(maxs / np.min(s[s > threshold])) if rank > 0 else math.inf
    min_nonzero = float(np.min(s[s > threshold])) if rank > 0 else math.nan
    return rank, len(present) - rank, zero, cond, min_nonzero


def operator_stack_role_dimension_condition_note_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    snaps = _snapshots(models, states, args)
    rows: List[dict] = []
    for (b, L, mode, st), s in sorted(snaps.items()):
        if s is None:
            rows.append({
                "branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)),
                "available": 0, "computed_status": "region_snapshot_missing", "condition_note": "operator_stack_condition_role_dimension_condition_note_requires_available_region",
            })
            continue
        planned = ["C_lca", "B1_front", "B2_front", "F1_root_front", "F2_birth_order"]
        present = set(s.role_names)
        f1_survives = int("F1_root_front" in present)
        f2_survives = int("F2_birth_order" in present)
        f1f2_pair_survives = int(f1_survives and f2_survives)
        if f1f2_pair_survives:
            computed_status = "F1_F2_independent_after_role_compression"
        elif s.role_dim <= 3:
            computed_status = "F1_F2_collapsed_into_C_B1_B2_span"
        else:
            computed_status = "F1_or_F2_partly_collapsed_after_role_compression"
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "available": 1,
            "region_id": s.region_id,
            "boundary_count": s.boundary_count,
            "interior_count": s.interior_count,
            "planned_role_count": len(planned),
            "compressed_role_dim": s.role_dim,
            "role_names": " ".join(s.role_names),
            "F1_survives_after_GS": f1_survives,
            "F2_survives_after_GS": f2_survives,
            "F1F2_pair_survives_after_GS": f1f2_pair_survives,
            "lost_roles": " ".join([x for x in planned if x not in present]),
            "computed_status": computed_status,
            "condition_note": "operator_stack_condition_checks_whether_signed_F1_F2_axes_are_present_in_the_positive_regional_operator_stack",
        })
    return rows


def operator_stack_generator_rank_condition_note_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    snaps = _snapshots(models, states, args)
    rows: List[dict] = []
    for (b, L, mode, st), s in sorted(snaps.items()):
        if s is None:
            rows.append({"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "available": 0, "computed_status": "region_snapshot_missing"})
            continue
        present = [x for x in GEN_LABELS if x in s.gens]
        rank, nullity, zero, cond, min_nonzero = _span_rank(s.gens, present, args.algebra_tol)
        matrix_dim = int(s.role_dim * s.role_dim)
        if nullity > 0 or zero > 0:
            computed_status = "generator_label_span_redundant_coordinate_gauge_present"
        elif rank == matrix_dim:
            computed_status = "generator_label_span_full_matrix_space"
        else:
            computed_status = "generator_label_span_independent_but_not_full_matrix_space"
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "available": 1,
            "region_id": s.region_id,
            "compressed_role_dim": s.role_dim,
            "matrix_vector_dim": matrix_dim,
            "generator_label_count": len(present),
            "generator_span_rank": rank,
            "generator_span_nullity": nullity,
            "zero_generator_count": zero,
            "generator_span_condition_proxy": cond,
            "generator_span_min_nonzero_singular": min_nonzero,
            "generator_labels": " ".join(present),
            "computed_status": computed_status,
            "condition_note": "operator_stack_condition_reports_coordinate_gauge_before_interpreting_label_span_least_squares_as_operator_morphism",
        })
    return rows


def operator_stack_coordinate_gauge_condition_note_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str], args) -> List[dict]:
    data: Dict[Tuple[int, int, str, str], Optional[FullRegionData]] = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            data[(b, L, mode, st)] = build_first_region_data(model, st, args)
    pairs = [(L, M) for M in levels for L in levels if L < M]
    rows: List[dict] = []
    for b in sorted({k[0] for k in models.keys()}):
        for mode in args.modes:
            for st in states:
                for L, M in pairs:
                    dL = data.get((b, L, mode, st))
                    dM = data.get((b, M, mode, st))
                    base = {"branching": b, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "source_level": M, "target_level": L}
                    if dL is None or dM is None or dL.role_dim != dM.role_dim:
                        rows.append({**base, "available": 0, "computed_status": "missing_region_data_or_role_dim_mismatch", "condition_note": "operator_stack_condition_coordinate_gauge_condition_note_requires_common_role_dim"})
                        continue
                    labels = common_labels(dM, dL)
                    worst: Optional[dict] = None
                    for x in labels:
                        for y in labels:
                            XM, YM = dM.gens[x], dM.gens[y]
                            PX = pi_role_project(XM, dM, dL, labels)
                            PY = pi_role_project(YM, dM, dL, labels)
                            PXY = pi_role_project(XM @ YM, dM, dL, labels)
                            target_product = PX @ PY
                            abs_err = fro(PXY - target_product)
                            denom = fro(target_product)
                            rel_err = abs_err / max(denom, EPS)
                            source_res = role_projection_residual(XM @ YM, dM, labels)
                            target_res = role_projection_residual(PXY, dL, labels)
                            source_coeff = project_to_label_span(XM @ YM, dM.gens, labels)
                            target_coeff = project_to_label_span(PXY, dL.gens, labels)
                            coeff_norm_source = float(np.linalg.norm(source_coeff))
                            coeff_norm_target = float(np.linalg.norm(target_coeff))
                            entry = {
                                **base,
                                "available": 1,
                                "map": "label_span_least_squares_role_projection_Pi_L_leftarrow_M",
                                "generator_x": x,
                                "generator_y": y,
                                "absolute_product_error": abs_err,
                                "relative_product_error": rel_err,
                                "target_product_norm_denominator": denom,
                                "source_span_residual_XY": source_res,
                                "target_span_residual_PXY": target_res,
                                "source_coeff_norm_XY": coeff_norm_source,
                                "target_coeff_norm_PXY": coeff_norm_target,
                            }
                            if worst is None or rel_err > float(worst["relative_product_error"]):
                                worst = entry
                    if worst is None:
                        rows.append({**base, "available": 0, "computed_status": "no_common_generator_labels", "condition_note": "operator_stack_condition_coordinate_gauge_condition_note_requires_common_labels"})
                    else:
                        small_denom = int(float(worst["target_product_norm_denominator"]) <= 1.0e-8)
                        source_closed = int(float(worst["source_span_residual_XY"]) <= 1.0e-6)
                        if small_denom:
                            computed_status = "relative_product_residual_amplified_by_small_denominator"
                        elif source_closed:
                            computed_status = "coordinate_transport_nonmultiplicative_despite_source_span_closure"
                        else:
                            computed_status = "product_partly_outside_source_label_span_and_transport_residualive"
                        rows.append({
                            **worst,
                            "small_denominator_condition_not_met": small_denom,
                            "source_product_closed_in_label_span": source_closed,
                            "computed_status": computed_status,
                            "condition_note": "operator_stack_condition_separates_absolute_error_relative_error_span_residual_and_denominator_for_product_residuals",
                        })
    return rows


def operator_stack_boundary_response_model_condition_note_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    snaps = _snapshots(models, states, args)
    rows: List[dict] = []
    for (b, L, mode, st), s in sorted(snaps.items()):
        if s is None:
            rows.append({"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "available": 0, "computed_status": "region_snapshot_missing"})
            continue
        open_grounded = int(math.isfinite(s.open_row_sum_residual) and s.open_row_sum_residual > 1.0e-8)
        closed_zero = int(s.closed_available and math.isfinite(s.closed_row_sum_residual) and s.closed_row_sum_residual <= 1.0e-8)
        if open_grounded and closed_zero:
            computed_status = "open_grounded_response_confirmed_closed_internal_control_zero_rowsum"
        elif open_grounded:
            computed_status = "open_grounded_response_visible_closed_internal_not_zero_or_unavailable"
        else:
            computed_status = "row_sum_not_showing_grounded_environment_under_current_region"
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "available": 1,
            "region_id": s.region_id,
            "boundary_count": s.boundary_count,
            "interior_count": s.interior_count,
            "open_grounded_row_sum_residual": s.open_row_sum_residual,
            "open_grounded_cond_KII": s.open_cond_KII,
            "open_grounded_solve_residual": s.open_solve_residual,
            "closed_internal_available": s.closed_available,
            "closed_internal_row_sum_residual": s.closed_row_sum_residual,
            "closed_internal_cond_KII": s.closed_cond_KII,
            "closed_internal_solve_residual": s.closed_solve_residual,
            "explicit_environment_port_response_implemented": 0,
            "open_grounded_relations_visible": open_grounded,
            "closed_internal_rowsum_zero_control": closed_zero,
            "computed_status": computed_status,
            "condition_note": "operator_stack_condition_marks_regional_DtN_as_open_grounded_unless_explicit_environment_port_response_is_built",
        })
    return rows


def _orientation_lookup(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str]) -> Dict[Tuple[int, int, str, str], dict]:
    out: Dict[Tuple[int, int, str, str], dict] = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            out[(b, L, mode, st)] = orientation_measurement(model, st)
    return out


def operator_stack_skew_survival_condition_note_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    snaps = _snapshots(models, states, args)
    orient = _orientation_lookup(models, states)
    rows: List[dict] = []
    for (b, L, mode, st), s in sorted(snaps.items()):
        o = orient.get((b, L, mode, st), {})
        if s is None:
            rows.append({"branching": b, "level": L, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "available": 0, "computed_status": "region_snapshot_missing"})
            continue
        S = 0.5 * (s.Lc_open + s.Lc_open.T)
        A = 0.5 * (s.Lc_open - s.Lc_open.T)
        compressed_skew_norm = fro(A)
        compressed_response_norm = fro(s.Lc_open)
        compressed_relative_skew = compressed_skew_norm / max(compressed_response_norm, EPS)
        global_relative_skew = float(o.get("relative_skew_norm", math.nan))
        lost = int(math.isfinite(global_relative_skew) and global_relative_skew > 1.0e-8 and compressed_relative_skew <= 1.0e-8)
        if lost:
            computed_status = "signed_F1F2_skew_present_globally_but_removed_by_positive_regional_stack"
        elif compressed_relative_skew > 1.0e-8:
            computed_status = "skew_survives_positive_regional_stack"
        else:
            computed_status = "no_signed_skew_detected_in_global_or_regional_stack"
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "available": 1,
            "region_id": s.region_id,
            "global_F1F2_relative_skew_norm": global_relative_skew,
            "global_F1F2_plane_circulation": float(o.get("F1F2_plane_circulation", math.nan)),
            "regional_positive_compressed_skew_norm": compressed_skew_norm,
            "regional_positive_compressed_relative_skew": compressed_relative_skew,
            "skew_removed_by_positive_schur_DtN": lost,
            "computed_status": computed_status,
            "condition_note": "operator_stack_condition_distinguishes_signed_current_layer_from_positive_conductance_Schur_DtN_operator_stack",
        })
    return rows


def operator_stack_consistency_checks_summary_rows(role_rows: Sequence[dict], rank_rows: Sequence[dict], gauge_rows: Sequence[dict], response_rows: Sequence[dict], skew_rows: Sequence[dict]) -> List[dict]:
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", "")), str(r.get("state", ""))) for seq in [role_rows, rank_rows, gauge_rows, response_rows, skew_rows] for r in seq if r.get("branching", "") != ""})
    rows: List[dict] = []
    for b, mode, st in keys:
        reference = int(is_reference_model(mode, st))
        f = lambda r: int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and str(r.get("state", "")) == st
        role_collapse = int(any("collapsed" in str(r.get("computed_status", "")) for r in role_rows if f(r)))
        rank_gauge = int(any("redundant" in str(r.get("computed_status", "")) for r in rank_rows if f(r)))
        coord_nonmult = int(any("coordinate_transport_nonmultiplicative" in str(r.get("computed_status", "")) for r in gauge_rows if f(r)))
        small_denom = int(any(int(float(r.get("small_denominator_condition_not_met", 0) or 0)) == 1 for r in gauge_rows if f(r)))
        open_grounded = int(any(int(float(r.get("open_grounded_relations_visible", 0) or 0)) == 1 for r in response_rows if f(r)))
        skew_lost = int(any(int(float(r.get("skew_removed_by_positive_schur_DtN", 0) or 0)) == 1 for r in skew_rows if f(r)))
        unmet_conditions = []
        if role_collapse:
            unmet_conditions.append("role_dimension_collapse")
        if rank_gauge:
            unmet_conditions.append("generator_coordinate_gauge")
        if coord_nonmult:
            unmet_conditions.append("nonmultiplicative_label_coordinate_transport")
        if small_denom:
            unmet_conditions.append("relative_error_small_denominator_cases")
        if open_grounded:
            unmet_conditions.append("open_grounded_boundary_response_model")
        if skew_lost:
            unmet_conditions.append("signed_skew_removed_by_positive_stack")
        if unmet_conditions:
            computed_status = "operator_stack_condition_consistency_detected_interpretation_unmet_conditions"
        else:
            computed_status = "operator_stack_condition_no_measurement_interpretation_unmet_condition_detected_under_current_thresholds"
        rows.append({
            "branching": b,
            "mode": mode,
            "state": st,
            "reference_model": reference,
            "role_dimension_collapse": role_collapse,
            "generator_coordinate_gauge": rank_gauge,
            "coordinate_transport_nonmultiplicative": coord_nonmult,
            "relative_error_small_denominator_condition_not_met": small_denom,
            "open_grounded_boundary_response_model_visible": open_grounded,
            "signed_skew_removed_by_positive_stack": skew_lost,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "operator_stack_condition_hardens_the_measurement; it_does_not_repair_or_disprove_natural_CNNA_operator_morphisms",
        })
    return rows


def write_operator_stack_condition_consistency_report(outdir: Path, role_rows: Sequence[dict], rank_rows: Sequence[dict], gauge_rows: Sequence[dict], response_rows: Sequence[dict], skew_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference = [r for r in summary_rows if int(r.get("reference_model", 0)) == 1]
    p = reference[0] if reference else {}
    pr_role = [r for r in role_rows if int(r.get("reference_model", 0)) == 1]
    pr_rank = [r for r in rank_rows if int(r.get("reference_model", 0)) == 1]
    pr_gauge = [r for r in gauge_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("source_level", 0)) == 6 and int(r.get("target_level", 0)) == 4]
    pr_response = [r for r in response_rows if int(r.get("reference_model", 0)) == 1]
    pr_skew = [r for r in skew_rows if int(r.get("reference_model", 0)) == 1]
    role = pr_role[-1] if pr_role else {}
    rank = pr_rank[-1] if pr_rank else {}
    gauge = pr_gauge[0] if pr_gauge else (gauge_rows[0] if gauge_rows else {})
    response = pr_response[-1] if pr_response else {}
    skew = pr_skew[-1] if pr_skew else {}
    text = f"""# Operator-stack measurement consistency

## Purpose

1b does not repair the operator stack and does not statement that a natural CNNA operator morphism is impossible.  It hardens the measurement so the current label-span least-squares derived_quantity cannot be overread as a mathematical no-go property.

## Reference consistency computed_status

`{p.get('computed_status', 'no_reference_summary_row')}`

Detected unmet_conditions:

```text
{p.get('unmet_conditions', 'n/a')}
```

## Role-dimension condition_note

```text
level                                = {role.get('level', 'n/a')}
planned_role_count                   = {role.get('planned_role_count', 'n/a')}
compressed_role_dim                  = {role.get('compressed_role_dim', 'n/a')}
role_names                           = {role.get('role_names', 'n/a')}
lost_roles                           = {role.get('lost_roles', 'n/a')}
computed_status                              = {role.get('computed_status', 'n/a')}
```

Interpretation: if F1/F2 do not survive the Gram-Schmidt role compression, the positive regional operator stack is not testing the signed F1/F2 layer as an independent operator direction.

## Generator-rank / coordinate-gauge condition_note

```text
level                                = {rank.get('level', 'n/a')}
compressed_role_dim                  = {rank.get('compressed_role_dim', 'n/a')}
matrix_vector_dim                    = {rank.get('matrix_vector_dim', 'n/a')}
generator_label_count                = {rank.get('generator_label_count', 'n/a')}
generator_span_rank                  = {rank.get('generator_span_rank', 'n/a')}
generator_span_nullity               = {rank.get('generator_span_nullity', 'n/a')}
zero_generator_count                 = {rank.get('zero_generator_count', 'n/a')}
computed_status                              = {rank.get('computed_status', 'n/a')}
```

Interpretation: a redundant label span makes least-squares coefficients gauge-dependent. Product failure of that coordinate transport is a real measurement residual, but not yet a no-go for a different, natural effect-pushforward morphism.

## Product coordinate-gauge condition_note for 6→4

```text
generator_x                          = {gauge.get('generator_x', 'n/a')}
generator_y                          = {gauge.get('generator_y', 'n/a')}
absolute_product_error               = {gauge.get('absolute_product_error', 'n/a')}
relative_product_error               = {gauge.get('relative_product_error', 'n/a')}
target_product_norm_denominator      = {gauge.get('target_product_norm_denominator', 'n/a')}
source_span_residual_XY              = {gauge.get('source_span_residual_XY', 'n/a')}
small_denominator_condition_not_met            = {gauge.get('small_denominator_condition_not_met', 'n/a')}
computed_status                              = {gauge.get('computed_status', 'n/a')}
```

## Response-relations condition_note

```text
level                                = {response.get('level', 'n/a')}
open_grounded_row_sum_residual       = {response.get('open_grounded_row_sum_residual', 'n/a')}
closed_internal_available            = {response.get('closed_internal_available', 'n/a')}
closed_internal_row_sum_residual     = {response.get('closed_internal_row_sum_residual', 'n/a')}
computed_status                              = {response.get('computed_status', 'n/a')}
```

Interpretation: the existing regional DtN response uses global degrees restricted to a local block.  That is an open/grounded response unless an explicit environment-port response is built.

## Skew-survival condition_note

```text
level                                      = {skew.get('level', 'n/a')}
global_F1F2_relative_skew_norm             = {skew.get('global_F1F2_relative_skew_norm', 'n/a')}
regional_positive_compressed_relative_skew = {skew.get('regional_positive_compressed_relative_skew', 'n/a')}
skew_removed_by_positive_schur_DtN         = {skew.get('skew_removed_by_positive_schur_DtN', 'n/a')}
computed_status                                    = {skew.get('computed_status', 'n/a')}
```

## Non-statements

1b does not introduce a von Neumann algebra, KMS condition, Type-III limit, split property, completed GNS Hilbert space, or strict projective `*`-homomorphism. It only marks where the current measurement is too degenerate to carry those statements.
"""
    (outdir / "1B_OPERATOR_STACK_MEASUREMENT_CONSISTENCY_REFINEMENT_REPORT.md").write_text(text, encoding="utf-8")
