from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *

def fro(A: np.ndarray) -> float:
    return float(np.linalg.norm(A, ord="fro")) if A.size else 0.0


def tv(p: Dict[Tuple[int, ...], float], q: Dict[Tuple[int, ...], float]) -> float:
    keys = set(p) | set(q)
    return 0.5 * float(sum(abs(float(p.get(k, 0.0)) - float(q.get(k, 0.0))) for k in keys))


def normalize_dict(d: Dict[Tuple[int, ...], float]) -> Dict[Tuple[int, ...], float]:
    s = float(sum(max(0.0, v) for v in d.values()))
    if s <= EPS:
        n = max(1, len(d))
        return {k: 1.0 / n for k in d}
    return {k: max(0.0, float(v)) / s for k, v in d.items()}


def normalize_distribution(x: Sequence[float]) -> np.ndarray:
    arr = np.array(list(x), dtype=float)
    if arr.size == 0:
        return arr
    arr = np.where(np.isfinite(arr) & (arr > 0.0), arr, 0.0)
    s = float(np.sum(arr))
    if s <= EPS:
        return np.ones(arr.size, dtype=float) / float(arr.size)
    return arr / s


def tv_arr(p: Sequence[float], q: Sequence[float]) -> float:
    pp = normalize_distribution(p)
    qq = normalize_distribution(q)
    n = max(pp.size, qq.size)
    if pp.size < n:
        pp = np.pad(pp, (0, n - pp.size))
    if qq.size < n:
        qq = np.pad(qq, (0, n - qq.size))
    return 0.5 * float(np.sum(np.abs(pp - qq)))


def _float_field(row: dict, key: str, default: float = math.nan) -> float:
    try:
        x = row.get(key, default)
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def _max_metric(rows: Sequence[dict], key: str, filt) -> float:
    vals: List[float] = []
    for r in rows:
        if not filt(r):
            continue
        v = _float_field(r, key)
        if math.isfinite(v):
            vals.append(v)
    return max(vals) if vals else math.nan
