from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np

from cnna.core.math_utils import fro

from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    regional_response,
    sibling_pair_regions,
)


def _support_basis(D: np.ndarray, tol: float) -> Tuple[np.ndarray, int, np.ndarray]:
    if D.size == 0:
        return np.zeros((0, 0)), 0, np.zeros(0)
    vals, U = np.linalg.eigh(0.5 * (D + D.T))
    maxeig = float(np.max(vals)) if vals.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxeig))
    mask = vals > cutoff
    return U[:, mask], int(np.sum(mask)), vals


def _density_support_overlap(D_live: np.ndarray, D_record: np.ndarray, tol: float) -> dict:
    Ul, rl, _vl = _support_basis(D_live, tol)
    Ur, rr, _vr = _support_basis(D_record, tol)
    if rl == 0 or rr == 0:
        return {
            "live_support_rank": rl,
            "record_support_rank": rr,
            "support_overlap_trace": 0.0,
            "support_overlap_fraction_of_live": 0.0,
            "support_overlap_fraction_of_record": 0.0,
            "support_principal_cosine_min": math.nan,
            "support_principal_cosine_max": math.nan,
            "support_subspace_gap_fro": math.nan,
        }
    Pl = Ul @ Ul.T
    Pr = Ur @ Ur.T
    overlap = float(np.trace(Pl @ Pr))
    svals = np.linalg.svd(Ul.T @ Ur, compute_uv=False)
    return {
        "live_support_rank": rl,
        "record_support_rank": rr,
        "support_overlap_trace": overlap,
        "support_overlap_fraction_of_live": float(overlap / max(1, rl)),
        "support_overlap_fraction_of_record": float(overlap / max(1, rr)),
        "support_principal_cosine_min": float(np.min(svals)) if svals.size else math.nan,
        "support_principal_cosine_max": float(np.max(svals)) if svals.size else math.nan,
        "support_subspace_gap_fro": float(fro(Pl - Pr) / max(1.0, fro(Pl))),
    }


def _skew_alignment(A_live: np.ndarray, A_record: np.ndarray) -> dict:
    nl = float(fro(A_live))
    nr = float(fro(A_record))
    B = A_live - A_record
    nb = float(fro(B))
    denom = max(nl * nr, 1.0e-300)
    cosine = float(np.sum(A_live * A_record) / denom) if nl > 0.0 and nr > 0.0 else math.nan
    return {
        "live_directed_current_norm": nl,
        "record_directed_snapshot_norm": nr,
        "backreaction_current_norm": nb,
        "backreaction_to_live_current_ratio": float(nb / max(nl, 1.0e-300)) if nl > 0 else math.inf,
        "live_record_skew_cosine": cosine,
        "orientation_sign_consistency": int(math.isfinite(cosine) and cosine > 0.0),
    }


def _computed_status(overlap_fraction_record: float, cosine: float, b_ratio: float, record_rank: int, live_rank: int) -> str:
    if record_rank <= 0 or live_rank <= 0:
        return "record_anchor_unavailable_zero_support"
    if record_rank < live_rank:
        # This is not a failure of record as history; it is a failure of using
        # record as a full physical-state anchor without additional conditions.
        if overlap_fraction_record >= 0.999 and math.isfinite(cosine) and cosine > 0.0:
            return "partial_record_history_anchor_aligned_control"
        return "record_partial_history_not_full_physical_anchor"
    if overlap_fraction_record >= 0.999 and math.isfinite(cosine) and cosine > 0.95 and b_ratio <= 0.1:
        return "record_physical_anchor_finite_object_strong"
    if overlap_fraction_record >= 0.95 and math.isfinite(cosine) and cosine > 0.0:
        return "record_physical_anchor_finite_object_weak"
    return "record_not_valid_as_physical_anchor_use_as_history_control"


def record_anchor_consistency_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            live = regional_response(model, spec, "live")
            record = regional_response(model, spec, "record")
            base = {
                "branching": b,
                "level": L,
                "mode": mode,
                "region_id": spec.region_id,
                "record_relations": "fixed_birth_history_snapshot_not_independent_physics_state",
                "record_anchor_question": "can_record_be_used_as_physical_anchor_after_explicit_condition",
                "record_history_derived_quantity_always_allowed": 1,
            }
            if live is None or record is None:
                rows.append({**base, "record_anchor_consistency_computed_status": "response_unavailable"})
                continue
            support = _density_support_overlap(live.density, record.density, config.rank_tol)
            align = _skew_alignment(live.skew_role, record.skew_role)
            density_gap = float(fro(live.density - record.density) / max(1.0, fro(live.density)))
            support_live = int(support["live_support_rank"])
            support_record = int(support["record_support_rank"])
            rows.append({
                **base,
                "density_construction": "positive_spectral_support_no_epsilon_floor",
                "live_density_computed_status": live.density_metadata.get("density_computed_status", "unknown"),
                "record_density_computed_status": record.density_metadata.get("density_computed_status", "unknown"),
                **support,
                **align,
                "live_record_density_relative_fro_gap": density_gap,
                "record_support_loss_expected_control": int(support_record < support_live),
                "record_anchor_requires_explicit_condition": 1,
                "record_as_physics_state_allowed_without_condition": 0,
                "record_anchor_consistency_computed_status": _computed_status(
                    float(support["support_overlap_fraction_of_record"]),
                    float(align["live_record_skew_cosine"]),
                    float(align["backreaction_to_live_current_ratio"]),
                    support_record,
                    support_live,
                ),
            })
    return rows


def record_anchor_consistency_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("record_anchor_consistency_computed_status", "unknown")) for r in rows})
    return (
        "# Record-anchor consistency\n\n"
        "`record` is treated as a fixed birth/provenance snapshot.  It is always valid as a historical derived_quantity, "
        "but it may be used as a physical anchor only if this explicit anchor condition supports it.  "
        "Record support loss is reported as expected historical incompleteness rather than as a live-network failure.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
