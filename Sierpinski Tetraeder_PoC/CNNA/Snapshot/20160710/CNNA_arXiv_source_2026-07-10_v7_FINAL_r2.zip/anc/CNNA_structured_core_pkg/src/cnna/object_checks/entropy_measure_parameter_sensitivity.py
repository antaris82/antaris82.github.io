from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

import numpy as np

from .history_live_common_measure import inherited_uniform_node_density_for_role_basis
from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.entropy_quantities import jensen_shannon_divergence_no_epsilon
from cnna.core.math_utils import fro
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Sequence[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _js(a: np.ndarray, b: np.ndarray, tol: float) -> float:
    val, _meta = jensen_shannon_divergence_no_epsilon(a, b, tol)
    return float(val) if math.isfinite(val) else math.inf


def _swap_left_right_permutation(role_names: Sequence[str]) -> np.ndarray:
    names = [str(n).lower() for n in role_names]
    d = len(names)
    perm = list(range(d))
    left = [i for i, n in enumerate(names) if "b1" in n or "left" in n]
    right = [i for i, n in enumerate(names) if "b2" in n or "right" in n]
    for li, ri in zip(left, right):
        perm[li], perm[ri] = perm[ri], perm[li]
    if perm == list(range(d)) and d >= 2:
        perm = list(range(1, d)) + [0]
    P = np.zeros((d, d), dtype=float)
    for i, j in enumerate(perm):
        P[i, j] = 1.0
    return P


def _density_key(b: int, L: int, mode: str, spec_meta: dict) -> Tuple[object, ...]:
    return (
        int(b), int(L), str(mode),
        str(spec_meta.get("region_id")),
        int(spec_meta.get("genealogical_corridor_length", -1)),
        int(spec_meta.get("frontier_level", -1)),
    )


def _region_shape_key(spec_meta: dict, *, include_frontier: bool) -> Tuple[object, ...]:
    # `region_id` intentionally contains the frontier level and is therefore
    # not stable under L-shifts.  The parameter_stable finite-history comparison uses the
    # common birth roots/LCA and corridor relations instead.
    xs = [
        str(spec_meta.get("region_family")),
        int(spec_meta.get("lca", -1)),
        int(spec_meta.get("left_root", -1)),
        int(spec_meta.get("right_root", -1)),
        int(spec_meta.get("genealogical_corridor_length", -1)),
    ]
    if include_frontier:
        xs.append(int(spec_meta.get("frontier_level", -1)))
    return tuple(xs)


def _base_key_without_L(b: int, mode: str, spec_meta: dict) -> Tuple[object, ...]:
    return (int(b), str(mode), *_region_shape_key(spec_meta, include_frontier=False))


def _base_key_without_mode(b: int, L: int, spec_meta: dict) -> Tuple[object, ...]:
    return (int(b), int(L), *_region_shape_key(spec_meta, include_frontier=True))


def entropy_measure_parameter_sensitivity_rows(config: OperatorTestConfig) -> List[dict]:
    """Anti-tautology controls for the 7 history/live measure.

    The true fixed record is compared against deterministic controls that
    destroy part of the birth-history alignment without adding stochastic model
    inputs: inherited uniform node density, sibling/role-shuffled record,
    neighboring-level record, and mode-mismatched record.
    """
    records: Dict[Tuple[object, ...], dict] = {}
    by_no_L: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    by_no_mode: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []

    # First pass: compute the true rows and retain densities for cross controls.
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = regional_response(model, spec, "live")
            record = regional_response(model, spec, "record")
            if live is None or record is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, "measure_parameter_sensitivity_computed_status": "response_unavailable"})
                continue
            uniform, umeta = inherited_uniform_node_density_for_role_basis(live.role_names, spec.roles, tol=config.algebra_tol)
            P = _swap_left_right_permutation(record.role_names)
            shuffled = P @ record.density @ P.T
            js_true = _js(live.density, record.density, config.algebra_tol)
            js_uniform = _js(live.density, uniform, config.algebra_tol)
            js_shuffled = _js(live.density, shuffled, config.algebra_tol)
            rec = {
                "b": int(b), "L": int(L), "mode": str(mode), "meta": meta,
                "live_density": live.density, "record_density": record.density,
                "uniform_density": uniform, "shuffled_record_density": shuffled,
                "role_names": tuple(live.role_names),
                "JS_true_record": js_true,
                "JS_uniform": js_uniform,
                "JS_shuffled_record": js_shuffled,
                "record_norm": float(fro(record.density)),
            }
            key = _density_key(b, L, mode, meta)
            records[key] = rec
            by_no_L[_base_key_without_L(b, mode, meta)].append(rec)
            by_no_mode[_base_key_without_mode(b, L, meta)].append(rec)

    # Second pass: attach time-shifted and mode-mismatched controls.
    for rec in records.values():
        b = rec["b"]; L = rec["L"]; mode = rec["mode"]; meta = rec["meta"]
        js_true = _finite(rec["JS_true_record"])
        js_uniform = _finite(rec["JS_uniform"])
        js_shuffled = _finite(rec["JS_shuffled_record"])
        # Time-shift: nearest other level for same b/mode/region geometry.
        level_controls = [x for x in by_no_L[_base_key_without_L(b, mode, meta)] if int(x["L"]) != int(L) and x["record_density"].shape == rec["live_density"].shape]
        time_vals = [_js(rec["live_density"], x["record_density"], config.algebra_tol) for x in level_controls]
        js_time = min([_finite(x) for x in time_vals if math.isfinite(_finite(x))], default=math.nan)
        time_L = min((int(x["L"]) for x in level_controls), key=lambda z: abs(z - int(L)), default=-1) if level_controls else -1
        # Mode mismatch: best non-current mode at same b/L/region geometry.
        mode_controls = [x for x in by_no_mode[_base_key_without_mode(b, L, meta)] if str(x["mode"]) != str(mode) and x["record_density"].shape == rec["live_density"].shape]
        mode_vals = [(str(x["mode"]), _js(rec["live_density"], x["record_density"], config.algebra_tol)) for x in mode_controls]
        finite_mode_vals = [(m, _finite(v)) for m, v in mode_vals if math.isfinite(_finite(v))]
        if finite_mode_vals:
            mode_mismatch, js_mode = min(finite_mode_vals, key=lambda p: p[1])
        else:
            mode_mismatch, js_mode = "unavailable", math.nan
        beats_uniform = int(math.isfinite(js_true) and math.isfinite(js_uniform) and js_true < js_uniform - config.algebra_tol)
        beats_shuffled = int(math.isfinite(js_true) and math.isfinite(js_shuffled) and js_true < js_shuffled - config.algebra_tol)
        beats_time = int(math.isfinite(js_true) and math.isfinite(js_time) and js_true < js_time - config.algebra_tol)
        beats_mode = int(math.isfinite(js_true) and math.isfinite(js_mode) and js_true < js_mode - config.algebra_tol)
        available_controls = int(math.isfinite(js_uniform)) + int(math.isfinite(js_shuffled)) + int(math.isfinite(js_time)) + int(math.isfinite(js_mode))
        passed_controls = int(beats_uniform) + int(beats_shuffled) + int(beats_time) + int(beats_mode)
        if available_controls >= 3 and passed_controls >= 3:
            computed_status = "true_record_preferred_over_destroyed_history_controls_finite_object"
        elif beats_uniform and beats_shuffled and available_controls == 2:
            computed_status = "true_record_preferred_over_available_static_controls_finite_object"
        elif not beats_uniform:
            computed_status = "true_record_not_better_than_uniform_control"
        elif not beats_shuffled:
            computed_status = "true_record_not_better_than_shuffled_history_control"
        else:
            computed_status = "true_record_parameter_sensitivity_partially_supported_control"
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            **meta,
            "measure_surface": "entropy_measure_parameter_sensitivity",
            "history_reference_under_test": "true_record_vs_destroyed_history_controls",
            "deterministic_carrier_control": "|".join(str(x) for x in rec.get("role_names", ())),
            "JS_live_true_record": js_true,
            "JS_live_uniform_node_reference": js_uniform,
            "JS_live_shuffled_record": js_shuffled,
            "JS_live_time_shifted_record_best_available": js_time,
            "time_shifted_record_level_used": int(time_L),
            "JS_live_mode_mismatched_record_best_available": js_mode,
            "mode_mismatched_record_mode_used": mode_mismatch,
            "true_record_gain_over_uniform": float(js_uniform - js_true) if math.isfinite(js_uniform) and math.isfinite(js_true) else math.nan,
            "true_record_gain_over_shuffled": float(js_shuffled - js_true) if math.isfinite(js_shuffled) and math.isfinite(js_true) else math.nan,
            "true_record_gain_over_time_shifted": float(js_time - js_true) if math.isfinite(js_time) and math.isfinite(js_true) else math.nan,
            "true_record_gain_over_mode_mismatched": float(js_mode - js_true) if math.isfinite(js_mode) and math.isfinite(js_true) else math.nan,
            "true_record_beats_uniform": beats_uniform,
            "true_record_beats_shuffled_record": beats_shuffled,
            "true_record_beats_time_shifted_record": beats_time,
            "true_record_beats_mode_mismatched_record": beats_mode,
            "available_destroyed_history_control_count": int(available_controls),
            "passed_destroyed_history_control_count": int(passed_controls),
            **umeta,
            "measure_parameter_sensitivity_computed_status": computed_status,
        })
    return rows


def entropy_measure_parameter_sensitivity_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("measure_parameter_sensitivity_computed_status", "unknown")) for r in rows})
    passed = sum(1 for r in rows if str(r.get("measure_parameter_sensitivity_computed_status", "")).startswith("true_record_preferred"))
    return (
        "# Entropy measure parameter_sensitivity / anti-tautology measurement\n\n"
        "This surface hardens `JS(live,record)` against triviality.  The true birth record is compared to the inherited uniform node carrier, a deterministic sibling/role-shuffled record, a neighboring-level record when available, and a mode-mismatched record when available.  No stochastic model input is introduced.\n\n"
        f"Rows with preferred true record computed_status_rows: {passed}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
