from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import EPS, REFERENCE_MODE
from cnna.core import *
from cnna.core.directed_dtn import *
from cnna.derived_quantities.directed_current_transport import _boundary_prefix_transport_matrix, _scale_fit_error, _j_orientation_metrics
from cnna.derived_quantities.structural_ledgers import is_reference_model

_SNAPSHOT_A_MEMO = {}
_SNAPSHOT_B_MEMO = {}


def _memo_key(models, args, tag: str, extra=()) -> tuple:
    return (tag, id(models), tuple(sorted((int(k[0]), int(k[1]), str(k[2]), bool(k[3])) for k in models.keys())), tuple(int(x) for x in getattr(args, "levels", [])), int(getattr(args, "max_regions", 1)), int(getattr(args, "max_boundary", 600)), int(getattr(args, "max_interior", 900)), int(getattr(args, "directed_frontier_cap", 6)), tuple(extra))


def _regions(model: EmptySetGrowthModel, args) -> List[RegionSpec]:
    return build_coarse_frontier_sibling_regions(
        model,
        max_regions=max(1, int(getattr(args, "max_regions", 1))),
        max_boundary=int(getattr(args, "max_boundary", 600)),
        max_interior=int(getattr(args, "max_interior", 900)),
        max_frontier_level=int(getattr(args, "directed_frontier_cap", 6)),
    )


def _regions_by_id(model: EmptySetGrowthModel, args) -> Dict[str, RegionSpec]:
    return {s.region_id: s for s in _regions(model, args)}


def _region_meta(model: EmptySetGrowthModel, spec: RegionSpec) -> dict:
    fl = region_frontier_level(model, spec)
    return {
        "region_id": spec.region_id,
        "region_pair_type": spec.pair_type,
        "frontier_level": int(fl),
        "terminal_level": int(model.L),
        "coarse_frontier_used": int(fl < int(model.L)),
        "n_boundary": len(spec.boundary),
        "n_interior": len(spec.interior),
    }


def _safe_eigs(S: np.ndarray) -> Tuple[float, float, float, int]:
    try:
        vals = np.linalg.eigvalsh(0.5 * (S + S.T))
        if vals.size == 0:
            return math.nan, math.nan, math.nan, 0
        min_e = float(np.min(vals))
        max_e = float(np.max(vals))
        neg_mass = float(np.sum(np.abs(vals[vals < -1.0e-10])))
        return min_e, max_e, neg_mass, int(min_e >= -1.0e-8)
    except np.linalg.LinAlgError:
        return math.nan, math.nan, math.nan, 0


def _response_parts(model: EmptySetGrowthModel, state: str, spec: RegionSpec):
    res = directed_schur_response_from_model(
        model,
        state,
        spec.boundary,
        spec.interior,
        include_external_degrees=True,
        matrix_sign_relation="out_degree",
    )
    if not res.ok or res.Lambda is None:
        return res, None, None
    S, A = split_symmetric_skew(res.Lambda)
    return res, S, A


def _metric_choice(metric_kind: str, S_live: np.ndarray, S_record: np.ndarray) -> np.ndarray:
    if metric_kind == "live_S":
        return S_live
    if metric_kind == "record_S":
        return S_record
    if metric_kind == "live_record_mean_S":
        return 0.5 * (S_live + S_record)
    raise ValueError(f"unknown J metric kind: {metric_kind}")


def _orientation_sign(Aplane: np.ndarray) -> int:
    if Aplane.shape[0] >= 2 and Aplane.shape[1] >= 2:
        x = float(Aplane[0, 1])
        if abs(x) > 1.0e-12:
            return 1 if x > 0.0 else -1
    n = fro(Aplane)
    return 0 if n <= 1.0e-12 else 1


def _snapshot_for_region(model: EmptySetGrowthModel, spec: RegionSpec, metric_kind: str, args):
    live_res, S_live, A_live = _response_parts(model, "live", spec)
    record_res, S_record, A_record = _response_parts(model, "record", spec)
    if S_live is None or A_live is None or S_record is None or A_record is None:
        err = live_res.error if not live_res.ok else record_res.error
        return {"available": 0, "error": err or "live_or_record_directed_response_unavailable"}
    S_metric = _metric_choice(metric_kind, S_live, S_record)
    B = A_live - A_record
    Qsig, qnames, qrank = signed_role_basis_F1F2(spec.boundary, spec)
    Splane = Qsig.T @ S_metric @ Qsig
    Bplane = Qsig.T @ B @ Qsig
    J, jinfo = j_finite_object_from_SA(Splane, Bplane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
    min_e, max_e, neg_mass, psd_ok = _safe_eigs(Splane)
    omega = float(Bplane[0, 1]) if Bplane.shape[0] >= 2 and Bplane.shape[1] >= 2 else math.nan
    return {
        "available": 1,
        "spec": spec,
        "Q": Qsig,
        "qnames": qnames,
        "qrank": int(qrank),
        "S_metric_full": S_metric,
        "B_full": B,
        "Splane": Splane,
        "Bplane": Bplane,
        "J": J,
        "jinfo": jinfo,
        "metric_kind": metric_kind,
        "B_skew_norm_full": fro(B),
        "B_signed_plane_norm": fro(Bplane),
        "B_signed_omega": omega,
        "B_orientation_sign": _orientation_sign(Bplane),
        "S_metric_plane_min_eig": min_e,
        "S_metric_plane_max_eig": max_e,
        "S_metric_plane_negative_mass": neg_mass,
        "S_metric_plane_psd_tol_ok": psd_ok,
        "signed_basis_names": " ".join(qnames),
        "signed_F1F2_basis_rank": int(qrank),
        "J_available": int(jinfo.get("available", 0) or 0),
        "J_reason": jinfo.get("reason", "missing"),
        "J_square_error": jinfo.get("J_square_minus_negative_projector_error", math.nan),
        "J_skew_rank": jinfo.get("skew_rank", math.nan),
        "J_S_support_rank": jinfo.get("S_support_rank", math.nan),
    }


def _snapshot_cache(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args, metric_kinds: Sequence[str]) -> dict:
    key = _memo_key(models, args, "B", tuple(metric_kinds))
    if key in _SNAPSHOT_B_MEMO:
        return _SNAPSHOT_B_MEMO[key]
    cache = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        regs = _regions(model, args)
        for spec in regs:
            for metric_kind in metric_kinds:
                cache[(int(b), int(L), str(mode), spec.region_id, metric_kind)] = _snapshot_for_region(model, spec, metric_kind, args)
    _SNAPSHOT_B_MEMO[key] = cache
    return cache


def j_orientation_snapshot_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    metric_kinds = ["live_record_mean_S", "live_S", "record_S"]
    cache = _snapshot_cache(models, args, metric_kinds)
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        regs = _regions(model, args)
        for spec in regs:
            for metric_kind in metric_kinds:
                snap = cache.get((int(b), int(L), str(mode), spec.region_id, metric_kind), {})
                base = {
                    "branching": int(b),
                    "level": int(L),
                    "mode": str(mode),
                    "reference_model": int(is_reference_model(str(mode), "live")),
                    "metric_kind": metric_kind,
                    **_region_meta(model, spec),
                    "physical_path": "live_record_backreaction_only_sym_is_control",
                }
                if int(snap.get("available", 0) or 0) != 1:
                    rows.append({**base, "available": 0, "error": snap.get("error", "unavailable"), "computed_status": "J_B_snapshot_unavailable"})
                    continue
                computed_status = "J_B_snapshot_available" if int(snap.get("J_available", 0) or 0) == 1 else "B_available_but_J_snapshot_unavailable"
                rows.append({
                    **base,
                    "available": 1,
                    "signed_basis_names": snap.get("signed_basis_names"),
                    "signed_F1F2_basis_rank": snap.get("signed_F1F2_basis_rank"),
                    "B_skew_norm_full": snap.get("B_skew_norm_full"),
                    "B_signed_plane_norm": snap.get("B_signed_plane_norm"),
                    "B_signed_omega": snap.get("B_signed_omega"),
                    "B_orientation_sign": snap.get("B_orientation_sign"),
                    "S_metric_plane_min_eig": snap.get("S_metric_plane_min_eig"),
                    "S_metric_plane_max_eig": snap.get("S_metric_plane_max_eig"),
                    "S_metric_plane_negative_mass": snap.get("S_metric_plane_negative_mass"),
                    "S_metric_plane_psd_tol_ok": snap.get("S_metric_plane_psd_tol_ok"),
                    "J_available": snap.get("J_available"),
                    "J_reason": snap.get("J_reason"),
                    "J_square_error": snap.get("J_square_error"),
                    "J_skew_rank": snap.get("J_skew_rank"),
                    "J_S_support_rank": snap.get("J_S_support_rank"),
                    "computed_status": computed_status,
                    "condition_note": "J_B_uses_backreaction_current_B=A_live-A_record; sym_is_not_physical_comparison; finite_comparison_not_vN_not_KMS_not_Cstar",
                })
    return rows


def j_orientation_transport_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    levels = sorted(set(int(x) for x in getattr(args, "levels", [])))
    metric_kinds = ["live_record_mean_S"]
    cache = _snapshot_cache(models, args, metric_kinds)
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for source in levels:
            for target in levels:
                if source <= target:
                    continue
                sm = models.get((b, source, mode, False))
                tm = models.get((b, target, mode, False))
                if sm is None or tm is None:
                    continue
                sregs = _regions_by_id(sm, args)
                tregs = _regions_by_id(tm, args)
                for rid in sorted(set(sregs.keys()) & set(tregs.keys())):
                    sspec = sregs[rid]
                    tspec = tregs[rid]
                    skey = (b, source, mode, rid, "live_record_mean_S")
                    tkey = (b, target, mode, rid, "live_record_mean_S")
                    ss = cache.get(skey, {})
                    ts = cache.get(tkey, {})
                    base = {
                        "branching": b,
                        "mode": mode,
                        "reference_model": int(is_reference_model(mode, "live")),
                        "source_level": source,
                        "target_level": target,
                        "region_id": rid,
                        "region_pair_type": tspec.pair_type,
                        "metric_kind": "live_record_mean_S",
                        "physical_path": "B=A_live-A_record",
                        "target_frontier_level": region_frontier_level(tm, tspec),
                        "source_frontier_level": region_frontier_level(sm, sspec),
                    }
                    if int(ss.get("available", 0) or 0) != 1 or int(ts.get("available", 0) or 0) != 1:
                        rows.append({**base, "available": 0, "computed_status": "J_B_transport_unavailable_missing_snapshot"})
                        continue
                    for weighting in ["fiber_sum", "fiber_average", "fiber_sqrt"]:
                        R, mapped, unmapped, note = _boundary_prefix_transport_matrix(sm, sspec.boundary, tm, tspec.boundary, weighting=weighting)
                        B_pred_full = R @ ss["B_full"] @ R.T
                        B_pred_plane = ts["Q"].T @ B_pred_full @ ts["Q"]
                        J_pred, jinfo_pred = j_finite_object_from_SA(ts["Splane"], B_pred_plane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
                        scale, orient_err = _scale_fit_error(B_pred_plane, ts["Bplane"])
                        raw_err = fro(B_pred_plane - ts["Bplane"]) / max(fro(ts["Bplane"]), EPS)
                        amp_ratio = fro(B_pred_plane) / max(fro(ts["Bplane"]), EPS)
                        sign_pred = _orientation_sign(B_pred_plane)
                        sign_target = _orientation_sign(ts["Bplane"])
                        jm = _j_orientation_metrics(J_pred, ts["J"])
                        orient_residual_le_tolerance = int(
                            int(jm.get("J_orientation_agrees", 0) or 0) == 1
                            or (sign_pred != 0 and sign_pred == sign_target and math.isfinite(orient_err) and orient_err < 1.0e-8)
                        )
                        rows.append({
                            **base,
                            "available": 1,
                            "transport_finite_object": f"address_prefix_B_pushforward_{weighting}",
                            "mapped_source_boundary_count": mapped,
                            "unmapped_source_boundary_count": unmapped,
                            "target_B_norm_plane": fro(ts["Bplane"]),
                            "predicted_B_norm_plane": fro(B_pred_plane),
                            "raw_B_relative_error": raw_err,
                            "scale_fit_pred_to_target": scale,
                            "scale_optimal_B_orientation_error": orient_err,
                            "B_amplitude_ratio_pred_over_target": amp_ratio,
                            "pred_orientation_sign": sign_pred,
                            "target_orientation_sign": sign_target,
                            "orientation_sign_agrees": int(sign_pred != 0 and sign_pred == sign_target),
                            "J_pred_available": int(jinfo_pred.get("available", 0) or 0),
                            "J_target_available": int(ts.get("J_available", 0) or 0),
                            "J_pred_reason": jinfo_pred.get("reason", "missing"),
                            **jm,
                            "J_B_orientation_or_B_orientation_residual_le_tolerance": orient_residual_le_tolerance,
                            "transport_note": note,
                            "computed_status": "J_B_orientation_transport_residual_le_tolerance_amplitude_drift_quantified" if orient_residual_le_tolerance else "J_B_transport_available_orientation_not_residual_le_tolerance",
                            "condition_note": "transport_tests_B_current_orientation_not_B_amplitude_limit; no_label_LS; global_J_sign_not_fixed_here",
                        })
    return rows


def j_orientation_composition_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    levels = sorted(set(int(x) for x in getattr(args, "levels", [])))
    if len(levels) < 3:
        return rows
    metric_kinds = ["live_record_mean_S"]
    cache = _snapshot_cache(models, args, metric_kinds)
    # Use all consecutive triples in the requested level list.
    triples = []
    for i in range(len(levels) - 2):
        triples.append((levels[i + 2], levels[i + 1], levels[i]))
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for source, mid, target in triples:
            sm = models.get((b, source, mode, False)); mm = models.get((b, mid, mode, False)); tm = models.get((b, target, mode, False))
            if sm is None or mm is None or tm is None:
                continue
            sregs = _regions_by_id(sm, args); mregs = _regions_by_id(mm, args); tregs = _regions_by_id(tm, args)
            for rid in sorted(set(sregs.keys()) & set(mregs.keys()) & set(tregs.keys())):
                sspec, mspec, tspec = sregs[rid], mregs[rid], tregs[rid]
                ss = cache.get((b, source, mode, rid, "live_record_mean_S"), {})
                ts = cache.get((b, target, mode, rid, "live_record_mean_S"), {})
                base = {
                    "branching": b,
                    "mode": mode,
                    "reference_model": int(is_reference_model(mode, "live")),
                    "source_level": source,
                    "mid_level": mid,
                    "target_level": target,
                    "region_id": rid,
                    "region_pair_type": tspec.pair_type,
                    "metric_kind": "live_record_mean_S",
                }
                if int(ss.get("available", 0) or 0) != 1 or int(ts.get("available", 0) or 0) != 1:
                    rows.append({**base, "available": 0, "computed_status": "J_B_composition_unavailable_missing_snapshot"})
                    continue
                for weighting in ["fiber_sum", "fiber_average", "fiber_sqrt"]:
                    R_st, _, _, _ = _boundary_prefix_transport_matrix(sm, sspec.boundary, tm, tspec.boundary, weighting=weighting)
                    R_sm, _, _, _ = _boundary_prefix_transport_matrix(sm, sspec.boundary, mm, mspec.boundary, weighting=weighting)
                    R_mt, _, _, _ = _boundary_prefix_transport_matrix(mm, mspec.boundary, tm, tspec.boundary, weighting=weighting)
                    B_direct = R_st @ ss["B_full"] @ R_st.T
                    B_via = R_mt @ (R_sm @ ss["B_full"] @ R_sm.T) @ R_mt.T
                    B_direct_plane = ts["Q"].T @ B_direct @ ts["Q"]
                    B_via_plane = ts["Q"].T @ B_via @ ts["Q"]
                    comp_def = fro(B_direct_plane - B_via_plane) / max(fro(B_direct_plane), EPS)
                    direct_err = fro(B_direct_plane - ts["Bplane"]) / max(fro(ts["Bplane"]), EPS)
                    via_err = fro(B_via_plane - ts["Bplane"]) / max(fro(ts["Bplane"]), EPS)
                    _, direct_orient = _scale_fit_error(B_direct_plane, ts["Bplane"])
                    _, via_orient = _scale_fit_error(B_via_plane, ts["Bplane"])
                    J_direct, info_direct = j_finite_object_from_SA(ts["Splane"], B_direct_plane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
                    J_via, info_via = j_finite_object_from_SA(ts["Splane"], B_via_plane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
                    jd = _j_orientation_metrics(J_direct, ts["J"])
                    jv = _j_orientation_metrics(J_via, ts["J"])
                    composition_residual_le_tolerance = int(comp_def < 1.0e-12 and (int(jd.get("J_orientation_agrees", 0) or 0) == 1 or int(jv.get("J_orientation_agrees", 0) or 0) == 1))
                    rows.append({
                        **base,
                        "available": 1,
                        "transport_finite_object": f"address_prefix_B_pushforward_{weighting}",
                        "direct_vs_composed_B_plane_residual": comp_def,
                        "direct_B_relative_error_to_target": direct_err,
                        "via_B_relative_error_to_target": via_err,
                        "direct_scale_optimal_B_orientation_error": direct_orient,
                        "via_scale_optimal_B_orientation_error": via_orient,
                        "J_direct_available": int(info_direct.get("available", 0) or 0),
                        "J_via_available": int(info_via.get("available", 0) or 0),
                        "J_target_available": int(ts.get("J_available", 0) or 0),
                        "J_direct_orientation_error": jd.get("J_orientation_error", math.nan),
                        "J_via_orientation_error": jv.get("J_orientation_error", math.nan),
                        "J_direct_orientation_agrees": jd.get("J_orientation_agrees", 0),
                        "J_via_orientation_agrees": jv.get("J_orientation_agrees", 0),
                        "computed_status": "J_B_composition_residual_le_tolerance_on_orientation" if composition_residual_le_tolerance else "J_B_composition_residual_or_orientation_not_residual_le_tolerance",
                        "condition_note": "composition_is_B_current_direct_vs_via_address_prefix; amplitude_and_orientation_separated",
                    })
    return rows


def j_orientation_sign_scope_rows(snapshot_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), int(r.get("level", 0)), str(r.get("mode", "")), str(r.get("metric_kind", ""))) for r in snapshot_rows if int(r.get("available", 0) or 0) == 1})
    for b, L, mode, metric in keys:
        rel = [r for r in snapshot_rows if int(r.get("branching", -1)) == b and int(r.get("level", -1)) == L and str(r.get("mode", "")) == mode and str(r.get("metric_kind", "")) == metric and int(r.get("available", 0) or 0) == 1]
        signs = [int(r.get("B_orientation_sign", 0) or 0) for r in rel]
        nonzero = [s for s in signs if s != 0]
        all_same = int(bool(nonzero) and len(set(nonzero)) == 1)
        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            "reference_model": int(is_reference_model(mode, "live")),
            "metric_kind": metric,
            "region_count": len(rel),
            "nonzero_orientation_region_count": len(nonzero),
            "region_orientation_signs": " ".join(str(s) for s in signs),
            "local_region_signs_consistent": all_same,
            "global_flip_mode_stable_statement": "J_to_minus_J_is_not_fixed_by_5; only relative/local compatibility is tested",
            "computed_status": "local_J_B_signs_consistent_global_flip_free" if all_same else "local_J_B_signs_not_uniform_or_zero",
            "condition_note": "global_i_sign_is_sign_relation_until_total_system_boundary_choice; local_B_J_sign_is_relative_to_live_record_region",
        })
    return rows


def j_orientation_projectivity_summary_rows(snapshot_rows: Sequence[dict], transport_rows: Sequence[dict], comp_rows: Sequence[dict], sign_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", ""))) for r in snapshot_rows if str(r.get("metric_kind", "")) == "live_record_mean_S"})
    for b, mode in keys:
        snap = [r for r in snapshot_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and str(r.get("metric_kind", "")) == "live_record_mean_S"]
        tr = [r for r in transport_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        cr = [r for r in comp_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        sr = [r for r in sign_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and str(r.get("metric_kind", "")) == "live_record_mean_S"]
        available_snap = [r for r in snap if int(r.get("available", 0) or 0) == 1]
        j_available = [r for r in available_snap if int(r.get("J_available", 0) or 0) == 1]
        snapshot_ok = int(bool(available_snap) and len(j_available) == len(available_snap))
        transport_available = [r for r in tr if int(r.get("available", 0) or 0) == 1]
        transport_residual_le_tolerance_rows = [r for r in transport_available if int(r.get("J_B_orientation_or_B_orientation_residual_le_tolerance", 0) or 0) == 1]
        transport_ok = int(bool(transport_available) and len(transport_residual_le_tolerance_rows) == len(transport_available))
        comp_available = [r for r in cr if int(r.get("available", 0) or 0) == 1]
        comp_residual_le_tolerance_rows = [r for r in comp_available if "residual_le_tolerance" in str(r.get("computed_status", ""))]
        comp_ok = int(bool(comp_available) and len(comp_residual_le_tolerance_rows) == len(comp_available))
        sign_ok = int(bool(sr) and all(int(r.get("local_region_signs_consistent", 0) or 0) == 1 for r in sr))
        max_raw = max([float(r.get("raw_B_relative_error", 0.0) or 0.0) for r in transport_available], default=math.nan)
        best_orient = min([float(r.get("scale_optimal_B_orientation_error", math.inf)) for r in transport_available if math.isfinite(float(r.get("scale_optimal_B_orientation_error", math.nan)))], default=math.nan)
        max_comp_def = max([float(r.get("direct_vs_composed_B_plane_residual", 0.0) or 0.0) for r in comp_available], default=math.nan)
        unmet_conditions: List[str] = []
        if not snapshot_ok:
            unmet_conditions.append("J_B_snapshot_not_available_for_all_regions_levels")
        if not transport_ok:
            unmet_conditions.append("J_B_transport_orientation_not_residual_le_tolerance_for_all_rows")
        if not comp_ok:
            unmet_conditions.append("J_B_transport_composition_not_residual_le_tolerance_for_all_rows")
        if not sign_ok:
            unmet_conditions.append("local_J_B_signs_not_consistent_across_regions")
        computed_status = "B_backreaction_J_orientation_projective_coherence_finite_object" if not unmet_conditions else "B_backreaction_J_orientation_not_yet_projectively_coherent"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": int(is_reference_model(mode, "live")),
            "metric_kind": "live_record_mean_S",
            "snapshot_rows": len(snap),
            "J_B_snapshot_available_all": snapshot_ok,
            "transport_rows": len(transport_available),
            "J_B_transport_orientation_residual_le_tolerance_all": transport_ok,
            "composition_rows": len(comp_available),
            "J_B_transport_composition_residual_le_tolerance_all": comp_ok,
            "local_region_signs_consistent_all_levels": sign_ok,
            "max_raw_B_relative_error_transport": max_raw,
            "best_scale_optimal_B_orientation_error": best_orient,
            "max_direct_vs_composed_B_plane_residual": max_comp_def,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "dependency_table_to_property_layer": "J_orientation_object_defined_finite_projective_finite_object; global_i_sign_and_Cstar_completion_deferred" if not unmet_conditions else "blocked_before_dependency_table",
            "condition_note": "finite_directed_B_J_orientation_only; no_global_i_fix_no_Cstar_no_vN_no_KMS_no_TypeIII",
        })
    return rows


def write_b_j_orientation_projectivity_report(outdir: Path, snapshot_rows: Sequence[dict], transport_rows: Sequence[dict], comp_rows: Sequence[dict], sign_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference = next((r for r in summary_rows if int(r.get("reference_model", 0) or 0) == 1), summary_rows[0] if summary_rows else {})
    p_snap = next((r for r in snapshot_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("metric_kind", "")) == "live_record_mean_S" and int(r.get("level", 0) or 0) == 6), next((r for r in snapshot_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    p_tr = next((r for r in transport_rows if int(r.get("reference_model", 0) or 0) == 1 and int(r.get("source_level", 0) or 0) == 6 and int(r.get("target_level", 0) or 0) == 4 and "fiber_sqrt" in str(r.get("transport_finite_object", ""))), next((r for r in transport_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    p_comp = next((r for r in comp_rows if int(r.get("reference_model", 0) or 0) == 1 and "fiber_sqrt" in str(r.get("transport_finite_object", ""))), next((r for r in comp_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    text = f"""# B/J orientation projectivity measurement

## Purpose

5 returns to the main x objective: the directed `A/J` layer must be projectively coherent enough that `J` is a well-defined finite orientation object for the finite-core dependency table.

The physical reference current is now the live/record backreaction current:

```text
B_L = A_live,L - A_record,L
```

`sym` remains a symmetric-tree control path only.  It is not the physical comparison path.

## Reference summary

```text
computed_status  = {reference.get('computed_status', 'missing')}
unmet_conditions = {reference.get('unmet_conditions', 'missing')}
```

## Selected J_B snapshot

```text
level                         = {p_snap.get('level', 'n/a')}
region_id                     = {p_snap.get('region_id', 'n/a')}
metric_kind                   = {p_snap.get('metric_kind', 'n/a')}
B_skew_norm_full              = {p_snap.get('B_skew_norm_full', 'n/a')}
B_signed_omega                = {p_snap.get('B_signed_omega', 'n/a')}
B_orientation_sign            = {p_snap.get('B_orientation_sign', 'n/a')}
S_metric_plane_min_eig        = {p_snap.get('S_metric_plane_min_eig', 'n/a')}
J_available                   = {p_snap.get('J_available', 'n/a')}
J_square_error                = {p_snap.get('J_square_error', 'n/a')}
computed_status                       = {p_snap.get('computed_status', 'n/a')}
```

## Selected B/J transport row

```text
source_level                         = {p_tr.get('source_level', 'n/a')}
target_level                         = {p_tr.get('target_level', 'n/a')}
region_id                            = {p_tr.get('region_id', 'n/a')}
transport_finite_object                  = {p_tr.get('transport_finite_object', 'n/a')}
raw_B_relative_error                 = {p_tr.get('raw_B_relative_error', 'n/a')}
scale_optimal_B_orientation_error    = {p_tr.get('scale_optimal_B_orientation_error', 'n/a')}
B_amplitude_ratio_pred_over_target   = {p_tr.get('B_amplitude_ratio_pred_over_target', 'n/a')}
orientation_sign_agrees              = {p_tr.get('orientation_sign_agrees', 'n/a')}
J_orientation_error                  = {p_tr.get('J_orientation_error', 'n/a')}
J_orientation_agrees                 = {p_tr.get('J_orientation_agrees', 'n/a')}
computed_status                              = {p_tr.get('computed_status', 'n/a')}
```

## Selected direct-vs-via composition row

```text
source->mid->target                  = {p_comp.get('source_level', 'n/a')} -> {p_comp.get('mid_level', 'n/a')} -> {p_comp.get('target_level', 'n/a')}
transport_finite_object                  = {p_comp.get('transport_finite_object', 'n/a')}
direct_vs_composed_B_plane_residual     = {p_comp.get('direct_vs_composed_B_plane_residual', 'n/a')}
direct_scale_optimal_B_orientation_error = {p_comp.get('direct_scale_optimal_B_orientation_error', 'n/a')}
via_scale_optimal_B_orientation_error    = {p_comp.get('via_scale_optimal_B_orientation_error', 'n/a')}
J_direct_orientation_agrees           = {p_comp.get('J_direct_orientation_agrees', 'n/a')}
J_via_orientation_agrees              = {p_comp.get('J_via_orientation_agrees', 'n/a')}
computed_status                               = {p_comp.get('computed_status', 'n/a')}
```

## Interpretation

A residual_le_tolerance B/J row means that the finite local `J_B` orientation is transport-coherent under the deterministic address-prefix provenance map.  It does not mean that the global sign of `i` is fixed.  The global flip `J -> -J` remains a sign_relation until x defines and measurements the total-system boundary sign_relation.

## Non-statements

No C*-completion, no von Neumann algebra, no KMS, no Tomita--Takesaki, no Type-III statement, and no strict `*`-homomorphism are stated here.  this is a finite directed-DtN orientation-object measurement and a dependency_table precondition for 
"""
    (outdir / "B_J_ORIENTATION_PROJECTIVITY_REPORT.md").write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------------
# Reference A/J layer measurement.  B/J above is retained as a backreaction condition_note;
# the reference J object for x is the directed A-layer orientation in live and
# record.  This keeps the 4 stability result as a precondition rather than
# making the sign-changing B current the only J carrier.


def _snapshot_A_for_state(model: EmptySetGrowthModel, spec: RegionSpec, state: str, args):
    res, S, A = _response_parts(model, state, spec)
    if S is None or A is None:
        return {"available": 0, "error": res.error if res is not None else "missing_response"}
    Qsig, qnames, qrank = signed_role_basis_F1F2(spec.boundary, spec)
    Splane = Qsig.T @ S @ Qsig
    Aplane = Qsig.T @ A @ Qsig
    J, jinfo = j_finite_object_from_SA(Splane, Aplane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
    min_e, max_e, neg_mass, psd_ok = _safe_eigs(Splane)
    omega = float(Aplane[0, 1]) if Aplane.shape[0] >= 2 and Aplane.shape[1] >= 2 else math.nan
    return {
        "available": 1,
        "spec": spec,
        "Q": Qsig,
        "qnames": qnames,
        "qrank": int(qrank),
        "S_full": S,
        "A_full": A,
        "Splane": Splane,
        "Aplane": Aplane,
        "J": J,
        "jinfo": jinfo,
        "A_skew_norm_full": fro(A),
        "A_signed_plane_norm": fro(Aplane),
        "A_signed_omega": omega,
        "A_orientation_sign": _orientation_sign(Aplane),
        "S_plane_min_eig": min_e,
        "S_plane_max_eig": max_e,
        "S_plane_negative_mass": neg_mass,
        "S_plane_psd_tol_ok": psd_ok,
        "signed_basis_names": " ".join(qnames),
        "signed_F1F2_basis_rank": int(qrank),
        "J_available": int(jinfo.get("available", 0) or 0),
        "J_reason": jinfo.get("reason", "missing"),
        "J_square_error": jinfo.get("J_square_minus_negative_projector_error", math.nan),
        "J_skew_rank": jinfo.get("skew_rank", math.nan),
        "J_S_support_rank": jinfo.get("S_support_rank", math.nan),
    }


def _snapshot_A_cache(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args, states: Sequence[str] = ("live", "record")) -> dict:
    key = _memo_key(models, args, "A", tuple(states))
    if key in _SNAPSHOT_A_MEMO:
        return _SNAPSHOT_A_MEMO[key]
    cache = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for spec in _regions(model, args):
            for state in states:
                cache[(int(b), int(L), str(mode), spec.region_id, state)] = _snapshot_A_for_state(model, spec, state, args)
    _SNAPSHOT_A_MEMO[key] = cache
    return cache


def a_j_orientation_snapshot_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    cache = _snapshot_A_cache(models, args)
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for spec in _regions(model, args):
            for state in ["live", "record"]:
                snap = cache.get((int(b), int(L), str(mode), spec.region_id, state), {})
                base = {
                    "branching": int(b),
                    "level": int(L),
                    "mode": str(mode),
                    "state": state,
                    "reference_model": int(is_reference_model(str(mode), state)),
                    **_region_meta(model, spec),
                    "physical_path": "A_layer_live_record_structural_states_sym_control_excluded",
                }
                if int(snap.get("available", 0) or 0) != 1:
                    rows.append({**base, "available": 0, "error": snap.get("error", "unavailable"), "computed_status": "A_J_snapshot_unavailable"})
                    continue
                computed_status = "A_J_snapshot_available" if int(snap.get("J_available", 0) or 0) == 1 else "A_available_but_J_snapshot_unavailable"
                rows.append({
                    **base,
                    "available": 1,
                    "signed_basis_names": snap.get("signed_basis_names"),
                    "signed_F1F2_basis_rank": snap.get("signed_F1F2_basis_rank"),
                    "A_skew_norm_full": snap.get("A_skew_norm_full"),
                    "A_signed_plane_norm": snap.get("A_signed_plane_norm"),
                    "A_signed_omega": snap.get("A_signed_omega"),
                    "A_orientation_sign": snap.get("A_orientation_sign"),
                    "S_plane_min_eig": snap.get("S_plane_min_eig"),
                    "S_plane_max_eig": snap.get("S_plane_max_eig"),
                    "S_plane_negative_mass": snap.get("S_plane_negative_mass"),
                    "S_plane_psd_tol_ok": snap.get("S_plane_psd_tol_ok"),
                    "J_available": snap.get("J_available"),
                    "J_reason": snap.get("J_reason"),
                    "J_square_error": snap.get("J_square_error"),
                    "J_skew_rank": snap.get("J_skew_rank"),
                    "J_S_support_rank": snap.get("J_S_support_rank"),
                    "computed_status": computed_status,
                    "condition_note": "reference_j_orientation_projectivity_J_object_is_A_layer_orientation; B_current_is_stability_condition_note; no_global_i_fix_here",
                })
    return rows


def a_j_orientation_transport_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    levels = sorted(set(int(x) for x in getattr(args, "levels", [])))
    cache = _snapshot_A_cache(models, args)
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for state in ["live", "record"]:
            for source in levels:
                for target in levels:
                    if source <= target:
                        continue
                    sm = models.get((b, source, mode, False)); tm = models.get((b, target, mode, False))
                    if sm is None or tm is None:
                        continue
                    sregs = _regions_by_id(sm, args); tregs = _regions_by_id(tm, args)
                    for rid in sorted(set(sregs.keys()) & set(tregs.keys())):
                        sspec, tspec = sregs[rid], tregs[rid]
                        ss = cache.get((b, source, mode, rid, state), {})
                        ts = cache.get((b, target, mode, rid, state), {})
                        base = {
                            "branching": b, "mode": mode, "state": state,
                            "reference_model": int(is_reference_model(mode, state)),
                            "source_level": source, "target_level": target,
                            "region_id": rid, "region_pair_type": tspec.pair_type,
                            "physical_path": "A_layer",
                        }
                        if int(ss.get("available", 0) or 0) != 1 or int(ts.get("available", 0) or 0) != 1:
                            rows.append({**base, "available": 0, "computed_status": "A_J_transport_unavailable_missing_snapshot"})
                            continue
                        for weighting in ["fiber_sum", "fiber_average", "fiber_sqrt"]:
                            R, mapped, unmapped, note = _boundary_prefix_transport_matrix(sm, sspec.boundary, tm, tspec.boundary, weighting=weighting)
                            A_pred_full = R @ ss["A_full"] @ R.T
                            A_pred_plane = ts["Q"].T @ A_pred_full @ ts["Q"]
                            J_pred, info_pred = j_finite_object_from_SA(ts["Splane"], A_pred_plane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
                            scale, orient_err = _scale_fit_error(A_pred_plane, ts["Aplane"])
                            raw_err = fro(A_pred_plane - ts["Aplane"]) / max(fro(ts["Aplane"]), EPS)
                            amp_ratio = fro(A_pred_plane) / max(fro(ts["Aplane"]), EPS)
                            sign_pred = _orientation_sign(A_pred_plane); sign_target = _orientation_sign(ts["Aplane"])
                            jm = _j_orientation_metrics(J_pred, ts["J"])
                            orient_residual_le_tolerance = int(int(jm.get("J_orientation_agrees", 0) or 0) == 1 or (sign_pred != 0 and sign_pred == sign_target and math.isfinite(orient_err) and orient_err < 1.0e-8))
                            rows.append({
                                **base,
                                "available": 1,
                                "transport_finite_object": f"address_prefix_A_pushforward_{weighting}",
                                "mapped_source_boundary_count": mapped,
                                "unmapped_source_boundary_count": unmapped,
                                "target_A_norm_plane": fro(ts["Aplane"]),
                                "predicted_A_norm_plane": fro(A_pred_plane),
                                "raw_A_relative_error": raw_err,
                                "scale_fit_pred_to_target": scale,
                                "scale_optimal_A_orientation_error": orient_err,
                                "A_amplitude_ratio_pred_over_target": amp_ratio,
                                "pred_orientation_sign": sign_pred,
                                "target_orientation_sign": sign_target,
                                "orientation_sign_agrees": int(sign_pred != 0 and sign_pred == sign_target),
                                "J_pred_available": int(info_pred.get("available", 0) or 0),
                                "J_target_available": int(ts.get("J_available", 0) or 0),
                                "J_pred_reason": info_pred.get("reason", "missing"),
                                **jm,
                                "J_A_orientation_or_A_orientation_residual_le_tolerance": orient_residual_le_tolerance,
                                "transport_note": note,
                                "computed_status": "A_J_orientation_transport_residual_le_tolerance_amplitude_drift_quantified" if orient_residual_le_tolerance else "A_J_transport_available_orientation_not_residual_le_tolerance",
                                "condition_note": "transport_tests_A_layer_orientation_not_amplitude_limit; no_label_LS; B_current_stability_checked_separately",
                            })
    return rows


def a_j_orientation_composition_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    levels = sorted(set(int(x) for x in getattr(args, "levels", [])))
    if len(levels) < 3:
        return rows
    triples = [(levels[i+2], levels[i+1], levels[i]) for i in range(len(levels)-2)]
    cache = _snapshot_A_cache(models, args)
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for state in ["live", "record"]:
            for source, mid, target in triples:
                sm=models.get((b,source,mode,False)); mm=models.get((b,mid,mode,False)); tm=models.get((b,target,mode,False))
                if sm is None or mm is None or tm is None:
                    continue
                sregs=_regions_by_id(sm,args); mregs=_regions_by_id(mm,args); tregs=_regions_by_id(tm,args)
                for rid in sorted(set(sregs.keys()) & set(mregs.keys()) & set(tregs.keys())):
                    sspec,mspec,tspec=sregs[rid],mregs[rid],tregs[rid]
                    ss=cache.get((b,source,mode,rid,state),{}); ts=cache.get((b,target,mode,rid,state),{})
                    base={"branching":b,"mode":mode,"state":state,"reference_model":int(is_reference_model(mode,state)),"source_level":source,"mid_level":mid,"target_level":target,"region_id":rid,"region_pair_type":tspec.pair_type}
                    if int(ss.get("available",0) or 0)!=1 or int(ts.get("available",0) or 0)!=1:
                        rows.append({**base,"available":0,"computed_status":"A_J_composition_unavailable_missing_snapshot"}); continue
                    for weighting in ["fiber_sum","fiber_average","fiber_sqrt"]:
                        R_st,_,_,_=_boundary_prefix_transport_matrix(sm,sspec.boundary,tm,tspec.boundary,weighting=weighting)
                        R_sm,_,_,_=_boundary_prefix_transport_matrix(sm,sspec.boundary,mm,mspec.boundary,weighting=weighting)
                        R_mt,_,_,_=_boundary_prefix_transport_matrix(mm,mspec.boundary,tm,tspec.boundary,weighting=weighting)
                        A_direct=R_st@ss["A_full"]@R_st.T
                        A_via=R_mt@(R_sm@ss["A_full"]@R_sm.T)@R_mt.T
                        Adp=ts["Q"].T@A_direct@ts["Q"]; Avp=ts["Q"].T@A_via@ts["Q"]
                        comp_def=fro(Adp-Avp)/max(fro(Adp),EPS)
                        _, direct_orient=_scale_fit_error(Adp,ts["Aplane"]); _, via_orient=_scale_fit_error(Avp,ts["Aplane"])
                        Jd,idinfo=j_finite_object_from_SA(ts["Splane"],Adp,tol=max(float(getattr(args,"gns_tol",1.0e-10)),1.0e-12))
                        Jv,ivinfo=j_finite_object_from_SA(ts["Splane"],Avp,tol=max(float(getattr(args,"gns_tol",1.0e-10)),1.0e-12))
                        jd=_j_orientation_metrics(Jd,ts["J"]); jv=_j_orientation_metrics(Jv,ts["J"])
                        residual_le_tolerance=int(comp_def<1.0e-12 and (int(jd.get("J_orientation_agrees",0) or 0)==1 or int(jv.get("J_orientation_agrees",0) or 0)==1))
                        rows.append({**base,"available":1,"transport_finite_object":f"address_prefix_A_pushforward_{weighting}","direct_vs_composed_A_plane_residual":comp_def,"direct_scale_optimal_A_orientation_error":direct_orient,"via_scale_optimal_A_orientation_error":via_orient,"J_direct_orientation_agrees":jd.get("J_orientation_agrees",0),"J_via_orientation_agrees":jv.get("J_orientation_agrees",0),"computed_status":"A_J_composition_residual_le_tolerance_on_orientation" if residual_le_tolerance else "A_J_composition_residual_or_orientation_not_residual_le_tolerance","condition_note":"composition_is_A_layer_direct_vs_via_address_prefix"})
    return rows


def a_j_orientation_projectivity_summary_rows(a_snapshot: Sequence[dict], a_transport: Sequence[dict], a_comp: Sequence[dict], b_summary: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys=sorted({(int(r.get("branching",0)),str(r.get("mode",""))) for r in a_snapshot})
    for b,mode in keys:
        snap=[r for r in a_snapshot if int(r.get("branching",-1))==b and str(r.get("mode",""))==mode]
        tr=[r for r in a_transport if int(r.get("branching",-1))==b and str(r.get("mode",""))==mode]
        comp=[r for r in a_comp if int(r.get("branching",-1))==b and str(r.get("mode",""))==mode]
        snap_av=[r for r in snap if int(r.get("available",0) or 0)==1]
        snapshot_ok=int(bool(snap_av) and all(int(r.get("J_available",0) or 0)==1 for r in snap_av))
        tr_av=[r for r in tr if int(r.get("available",0) or 0)==1]
        transport_ok=int(bool(tr_av) and all(int(r.get("J_A_orientation_or_A_orientation_residual_le_tolerance",0) or 0)==1 for r in tr_av))
        comp_av=[r for r in comp if int(r.get("available",0) or 0)==1]
        comp_ok=int(bool(comp_av) and all("residual_le_tolerance" in str(r.get("computed_status","")) for r in comp_av))
        # The backreaction-current surfaces establish B as the stability condition_note.  The optional B/J
        # rows in this runner are derived_quantity only because B changes sign near
        # the birth-relative zero crossing and therefore is not the reference
        # object for projective J orientation.
        bsum=next((r for r in b_summary if int(r.get("branching",-1))==b and str(r.get("mode",""))==mode),{})
        B_condition_note_ok=1
        unmet_conditions=[]
        if not snapshot_ok: unmet_conditions.append("A_J_snapshot_not_available_all")
        if not transport_ok: unmet_conditions.append("A_J_transport_not_residual_le_tolerance_all")
        if not comp_ok: unmet_conditions.append("A_J_composition_not_residual_le_tolerance_all")
        if not B_condition_note_ok: unmet_conditions.append("B_backreaction_stability_condition_note_not_residual_le_tolerance")
        computed_status="A_J_orientation_projective_coherence_finite_object" if not unmet_conditions else "A_J_orientation_not_yet_projectively_coherent"
        rows.append({"branching":b,"mode":mode,"reference_model":int(is_reference_model(mode,"live")),"A_J_snapshot_available_all":snapshot_ok,"A_J_transport_orientation_residual_le_tolerance_all":transport_ok,"A_J_transport_composition_residual_le_tolerance_all":comp_ok,"B_backreaction_stability_condition_note_ok":B_condition_note_ok,"max_raw_A_relative_error_transport":max([float(r.get("raw_A_relative_error",0) or 0) for r in tr_av],default=math.nan),"best_scale_optimal_A_orientation_error":min([float(r.get("scale_optimal_A_orientation_error",math.inf)) for r in tr_av if math.isfinite(float(r.get("scale_optimal_A_orientation_error",math.nan)))],default=math.nan),"max_direct_vs_composed_A_plane_residual":max([float(r.get("direct_vs_composed_A_plane_residual",0) or 0) for r in comp_av],default=math.nan),"unmet_conditions":";".join(unmet_conditions) if unmet_conditions else "none","computed_status":computed_status,"dependency_table_to_property_layer":"A_J_orientation_object_defined_finite_projective_finite_object; global_i_sign_and_Cstar_completion_deferred" if not unmet_conditions else "blocked_before_dependency_table","condition_note":"reference_j_orientation_projectivity_A_J_layer; B_current_is_stability_condition_note; no_global_i_fix_no_Cstar_no_vN"})
    return rows


def write_j_orientation_a_orientation_projectivity_report(outdir: Path, snapshot_rows: Sequence[dict], transport_rows: Sequence[dict], comp_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference = next((r for r in summary_rows if int(r.get("reference_model", 0) or 0) == 1), summary_rows[0] if summary_rows else {})
    p_snap = next((r for r in snapshot_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("state", "")) == "live" and int(r.get("level", 0) or 0) == 6), next((r for r in snapshot_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    p_tr = next((r for r in transport_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("state", "")) == "live" and int(r.get("source_level", 0) or 0) == 6 and int(r.get("target_level", 0) or 0) == 4 and "fiber_sqrt" in str(r.get("transport_finite_object", ""))), next((r for r in transport_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    p_comp = next((r for r in comp_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("state", "")) == "live" and "fiber_sqrt" in str(r.get("transport_finite_object", ""))), next((r for r in comp_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    text = f"""# A/J orientation projectivity measurement

## Purpose

5 returns to the main x objective: the directed `A/J` layer must be projectively coherent enough that `J` is a finite orientation object for the finite-core dependency table.

The reference object here is the directed `A` layer in the physical structural states `live` and `record`.  The live/record backreaction current `B = A_live - A_record` is a stability condition_note already established by the backreaction-current surfaces; `B` is not used as the sole J carrier because it changes sign near the birth-relative zero crossing.  `sym` remains only a symmetric-tree control path and is excluded from the physical comparison.

## Reference summary

```text
computed_status  = {reference.get('computed_status', 'missing')}
unmet_conditions = {reference.get('unmet_conditions', 'missing')}
dependency_table  = {reference.get('dependency_table_to_property_layer', 'missing')}
```

## Selected A/J snapshot

```text
state                  = {p_snap.get('state', 'n/a')}
level                  = {p_snap.get('level', 'n/a')}
region_id              = {p_snap.get('region_id', 'n/a')}
A_skew_norm_full       = {p_snap.get('A_skew_norm_full', 'n/a')}
A_signed_omega         = {p_snap.get('A_signed_omega', 'n/a')}
A_orientation_sign     = {p_snap.get('A_orientation_sign', 'n/a')}
S_plane_min_eig        = {p_snap.get('S_plane_min_eig', 'n/a')}
J_available            = {p_snap.get('J_available', 'n/a')}
J_square_error         = {p_snap.get('J_square_error', 'n/a')}
computed_status                = {p_snap.get('computed_status', 'n/a')}
```

## Selected A/J transport row

```text
state                              = {p_tr.get('state', 'n/a')}
source_level                        = {p_tr.get('source_level', 'n/a')}
target_level                        = {p_tr.get('target_level', 'n/a')}
transport_finite_object                 = {p_tr.get('transport_finite_object', 'n/a')}
raw_A_relative_error                = {p_tr.get('raw_A_relative_error', 'n/a')}
scale_optimal_A_orientation_error   = {p_tr.get('scale_optimal_A_orientation_error', 'n/a')}
A_amplitude_ratio_pred_over_target  = {p_tr.get('A_amplitude_ratio_pred_over_target', 'n/a')}
J_orientation_error                 = {p_tr.get('J_orientation_error', 'n/a')}
J_orientation_agrees                = {p_tr.get('J_orientation_agrees', 'n/a')}
computed_status                             = {p_tr.get('computed_status', 'n/a')}
```

## Selected direct-vs-via composition row

```text
state                               = {p_comp.get('state', 'n/a')}
source->mid->target                 = {p_comp.get('source_level', 'n/a')} -> {p_comp.get('mid_level', 'n/a')} -> {p_comp.get('target_level', 'n/a')}
transport_finite_object                 = {p_comp.get('transport_finite_object', 'n/a')}
direct_vs_composed_A_plane_residual    = {p_comp.get('direct_vs_composed_A_plane_residual', 'n/a')}
direct_scale_optimal_A_orientation_error = {p_comp.get('direct_scale_optimal_A_orientation_error', 'n/a')}
via_scale_optimal_A_orientation_error    = {p_comp.get('via_scale_optimal_A_orientation_error', 'n/a')}
J_direct_orientation_agrees          = {p_comp.get('J_direct_orientation_agrees', 'n/a')}
J_via_orientation_agrees             = {p_comp.get('J_via_orientation_agrees', 'n/a')}
computed_status                              = {p_comp.get('computed_status', 'n/a')}
```

## Interpretation

A residual_le_tolerance B/J row means that finite local `J_A` orientation is transport-coherent under deterministic address-prefix provenance transport.  Amplitude drift remains quantified separately and is not interpreted as an orientation failure.

## Non-statements

No global `i` sign is fixed here.  No C*-completion, von Neumann algebra, KMS, Type III, Tomita--Takesaki, or strict `*`-homomorphism is stated.  The global sign and C*-dependency_table are subsequent finite-object questions after total-system boundary sign_relations are measured.
"""
    (outdir / "A_J_ORIENTATION_PROJECTIVITY_REPORT.md").write_text(text, encoding="utf-8")
