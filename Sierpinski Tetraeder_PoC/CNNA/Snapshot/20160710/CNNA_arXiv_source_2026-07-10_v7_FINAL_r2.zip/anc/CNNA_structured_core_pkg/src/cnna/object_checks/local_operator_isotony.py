from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    independent_embedding_metrics,
    local_operator_algebras,
    local_operator_generators,
    max_span_residual,
    max_star_residual,
    node_level_schur_embedding_metrics,
    operator_scale_metadata,
    relative_common_ambient_schur_embedding_metrics,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


INCLUSION_FINITE_OBJECTS = [
    ("root_anchor_response", "left_birth_cone_response", "anchor_into_left_birth_cone"),
    ("root_anchor_response", "right_birth_cone_response", "anchor_into_right_birth_cone"),
    ("left_frontier_response", "left_birth_cone_response", "frontier_into_left_birth_cone"),
    ("right_frontier_response", "right_birth_cone_response", "frontier_into_right_birth_cone"),
    ("symmetric_left_birth_cone_response", "left_birth_cone_response", "S_layer_into_mixed_left_cone"),
    ("skew_left_birth_cone_response", "left_birth_cone_response", "A_layer_into_mixed_left_cone"),
    ("symmetric_right_birth_cone_response", "right_birth_cone_response", "S_layer_into_mixed_right_cone"),
    ("skew_right_birth_cone_response", "right_birth_cone_response", "A_layer_into_mixed_right_cone"),
    ("left_birth_cone_response", "sibling_pair_response", "left_birth_cone_into_sibling_pair"),
    ("right_birth_cone_response", "sibling_pair_response", "right_birth_cone_into_sibling_pair"),
    ("sibling_pair_response", "full_regional_response", "sibling_pair_into_full_role_response"),
    ("positive_carrier_pair_response", "full_regional_response", "S_carrier_pair_into_full_role_response"),
    ("directed_current_pair_response", "full_regional_response", "A_current_pair_into_full_role_response"),
]


def _is_current_system(name: str) -> bool:
    return (
        "skew" in name
        or "directed_current" in name
        or "A_current" in name
    )


def _computed_status(span_error: float, star_error: float, tol: float, construction_overlap: float, ambient_saturated: bool, low_dim_coordinate_control: bool, vacuous_zero_current_source: bool) -> str:
    if vacuous_zero_current_source:
        return "vacuous_zero_current_isotony_control"
    if span_error <= tol and star_error <= tol:
        if ambient_saturated:
            return "ambient_saturation_inclusion_control"
        if low_dim_coordinate_control:
            return "coordinate_support_low_dim_isotony_control"
        if construction_overlap > 0.0:
            return "construction_nested_finite_isotony_finite_object"
        return "strict_finite_isotony_finite_object_requires_independent_embedding_measurement"
    if span_error <= 1.0e-7 and star_error <= 1.0e-7:
        return "finite_isotony_approx_finite_object"
    if span_error <= 1.0e-6:
        return "span_inclusion_only"
    return "isotony_failed"


def _construction_overlap(gens: dict, small_name: str, large_name: str) -> float:
    small_ids = {id(x) for x in gens.get(small_name, [])}
    large_ids = {id(x) for x in gens.get(large_name, [])}
    if not small_ids:
        return 0.0
    return float(len(small_ids & large_ids) / len(small_ids))


def local_operator_isotony_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "isotony_computed_status": "response_unavailable"})
                    continue
                scale_meta = operator_scale_metadata(resp, tol=config.algebra_tol)
                gens = local_operator_generators(resp, generator_tol=config.algebra_tol)
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                ambient_dim = int(resp.Lambda_role.shape[0])
                full_matrix_dim = int(ambient_dim * ambient_dim)
                for small_name, large_name, inclusion_type in INCLUSION_FINITE_OBJECTS:
                    small = algebras[small_name]
                    large = algebras[large_name]
                    span_error = max_span_residual(small.basis, large.basis)
                    star_error = max_star_residual(small.basis, large.basis)
                    overlap = _construction_overlap(gens, small_name, large_name)
                    ambient_saturated = len(large.basis) >= full_matrix_dim
                    emb = independent_embedding_metrics(
                        resp,
                        small_name,
                        large_name,
                        tol=config.algebra_tol,
                        max_iter=config.max_algebra_iter,
                    )
                    node_emb = node_level_schur_embedding_metrics(
                        model,
                        spec,
                        state,
                        small_name,
                        large_name,
                        tol=config.algebra_tol,
                    )
                    rel_common = relative_common_ambient_schur_embedding_metrics(
                        model,
                        spec,
                        state,
                        small_name,
                        large_name,
                        tol=config.algebra_tol,
                    )
                    vacuous_zero_current_source = bool(
                        int(scale_meta.get("vacuous_zero_current_layer", 0))
                        and (
                            _is_current_system(small_name)
                            or "A_current" in inclusion_type
                            or large_name == "full_regional_response"
                        )
                    )
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        **scale_meta,
                        "inclusion_type": inclusion_type,
                        "subalgebra_finite_object": small_name,
                        "superalgebra_finite_object": large_name,
                        "subalgebra_dim": len(small.basis),
                        "superalgebra_dim": len(large.basis),
                        "ambient_matrix_dim": full_matrix_dim,
                        "superalgebra_is_full_ambient_matrix": int(ambient_saturated),
                        "source_generators_reused_in_target_fraction": overlap,
                        **emb,
                        **node_emb,
                        **rel_common,
                        "sub_to_super_span_residual": span_error,
                        "sub_star_to_super_residual": star_error,
                        "super_saturated": int(large.saturated),
                        "sub_saturated": int(small.saturated),
                        "vacuous_zero_current_source_system": int(vacuous_zero_current_source),
                        "isotony_computed_status": _computed_status(span_error, star_error, config.algebra_tol, overlap, ambient_saturated, bool(int(emb.get("coordinate_support_low_dim_control", 0))), vacuous_zero_current_source),
                    })
    return rows


def isotony_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("isotony_computed_status", "unknown")) for r in rows})
    return "# Finite local-operator isotony report\n\nMeasurements finite span/star inclusion for objectively named local operator systems inside one CNNA sibling-pair carrier.  Exact inclusions are labelled when they are construction-nested or caused by saturation of the ambient finite matrix algebra.  The strengthened measurement additionally rebuilds source and target systems from finite role-support restrictions and tests the coordinate-support embedding map.  In the current three-role carrier this coordinate-support condition is explicitly labelled as a low-dimensional control when it has no real failure potential.  Directed-current systems, and pair-to-full ambient inclusions whose state-specific skew/current norm is below the carrier-relative norm condition, are labelled as vacuous zero-current controls rather than as finite isotony failures.  It now also emits a separate raw node-level Schur/DtN embedding residual by recomputing subregion and superregion cuts independently and comparing differently conditioned responses.  This raw condition is an rank_bound map.  In addition it emits the Variant-3 relative-common-ambient Schur isotony derived_quantity: source and target are placed in the same finite superregion ambient and the additional super-boundary ports are Schur-eliminated.  This is the finite associativity trace for relative CNNA observables and is the finite_object relations for a genuine node-level Schur-isotony property.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
