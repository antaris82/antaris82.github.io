from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.io.csv_writer import *
from cnna.core import *

def level_models(
    branching_values: Sequence[int],
    levels: Sequence[int],
    modes: Sequence[str],
    growth_schedule: str = "slot_step",
) -> Dict[Tuple[int, int, str, bool], EmptySetGrowthModel]:
    out: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel] = {}
    for b in branching_values:
        for L in levels:
            for mode in modes:
                out[(b, L, mode, False)] = EmptySetGrowthModel(b, L, mode, reverse_sibling_order=False, growth_schedule=growth_schedule)
                # only needed for orientation flip condition_note; keep for same levels.
                out[(b, L, mode, True)] = EmptySetGrowthModel(b, L, mode, reverse_sibling_order=True, growth_schedule=growth_schedule)
    return out


def genesis_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel]) -> Tuple[List[dict], List[dict], List[dict]]:
    measurement: List[dict] = []
    hashes: List[dict] = []
    counts: List[dict] = []
    for (b, L, mode, rev), m in sorted(models.items()):
        if rev:
            continue
        empty_ok = int(m.events[0].kind == "empty_state")
        root_ok = int(len(m.events) > 1 and m.events[1].kind == "birth_root_from_empty" and m.nodes[0].parent is None)
        no_external_construction_imports = 1
        prior_output_input_condition_note = 1
        measurement.append({
            "branching": b,
            "max_level": L,
            "mode": mode,
            "empty_state_first": empty_ok,
            "explicit_root_birth_from_empty": root_ok,
            "no_external_construction_imports": no_external_construction_imports,
            "no_prior_output_inputs": prior_output_input_condition_note,
            "node_count": len(m.nodes),
            "expected_node_count": m.node_count_expected(),
            "node_count_ok": int(len(m.nodes) == m.node_count_expected()),
            "event_count": len(m.events),
            "computed_status": "emptyset_genesis_residual_le_tolerance" if empty_ok and root_ok and no_external_construction_imports and len(m.nodes) == m.node_count_expected() else "emptyset_genesis_red",
        })
        hashes.append({
            "branching": b,
            "max_level": L,
            "mode": mode,
            "eventlog_sha256": sha256_json([ev.__dict__ for ev in m.events]),
            "nodes_sha256": sha256_json([{k: (list(v) if isinstance(v, tuple) else v) for k, v in n.__dict__.items() if k != "children"} | {"children": n.children} for n in m.nodes]),
            "live_edges_sha256": sha256_json({f"{i}->{j}": w for (i, j), w in sorted(m.live_edges.items())}),
            "record_edges_sha256": sha256_json({f"{i}->{j}": w for (i, j), w in sorted(m.record_edges.items())}),
        })
        for lev in range(L + 1):
            actual = sum(1 for n in m.nodes if n.level == lev)
            counts.append({"branching": b, "max_level": L, "mode": mode, "level": lev, "actual_nodes_at_level": actual, "expected_nodes_at_level": b ** lev, "ok": int(actual == b ** lev)})
    return measurement, hashes, counts


def projection_grammar_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int]) -> List[dict]:
    rows: List[dict] = []
    levels_sorted = sorted(set(levels))
    for (b, M, mode, rev), mM in sorted(models.items()):
        if rev:
            continue
        for L in levels_sorted:
            if L >= M:
                continue
            mL = models[(b, L, mode, False)]
            addresses_L = {n.address for n in mL.nodes if n.level == L}
            leaves_M = [n.address for n in mM.nodes if n.level == M]
            total = len(leaves_M)
            ok = sum(1 for a in leaves_M if prefix(a, L) in addresses_L)
            rows.append({
                "branching": b,
                "mode": mode,
                "source_level": M,
                "target_level": L,
                "n_source_terminal_addresses": total,
                "n_prefixes_found_in_target": ok,
                "address_truncation_total": int(ok == total),
                "expected_fiber_size": b ** (M - L),
                "composition_exact_4_6_via_5": int(True) if {4,5,6}.issubset(set(levels_sorted)) and L == 4 and M == 6 else "",
                "computed_status": "projection_grammar_residual_le_tolerance" if ok == total else "projection_grammar_red",
            })
    return rows


def carrier_state_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], levels: Sequence[int], states: Sequence[str]) -> Tuple[List[dict], List[dict], List[dict], List[dict]]:
    carrier_rows: List[dict] = []
    state_rows: List[dict] = []
    carrier_comp: List[dict] = []
    state_comp: List[dict] = []
    levels_sorted = sorted(set(levels))
    for (b, M, mode, rev), mM in sorted(models.items()):
        if rev:
            continue
        for L in levels_sorted:
            if L >= M:
                continue
            mL = models[(b, L, mode, False)]
            cM = terminal_carrier(mM)
            cL = terminal_carrier(mL)
            cpred = push_forward(cM, L)
            carrier_rows.append({
                "branching": b, "mode": mode, "source_level": M, "target_level": L,
                "finite_object": "terminal_prefix_positive_carrier",
                "TV": tv(cL, cpred),
                "n_target_atoms": len(cL),
                "n_source_atoms": len(cM),
                "condition_note": "positive_carrier_not_physical_node_count_measure_signed_current_separate",
                "computed_status": "carrier_prefix_projective_residual_le_tolerance" if tv(cL, cpred) < 1e-12 else "carrier_prefix_projective_condition_not_met",
            })
            for state in states:
                sM = terminal_state(mM, state)
                sL = terminal_state(mL, state)
                spred = push_forward(sM, L)
                state_rows.append({
                    "branching": b, "mode": mode, "state": state, "source_level": M, "target_level": L,
                    "finite_object": "terminal_diagonal_D_L_state_trace_D_E",
                    "TV": tv(sL, spred),
                    "n_target_atoms": len(sL), "n_source_atoms": len(sM),
                    "condition_note": "finite_terminal_D_L_diag_state_p_v_equals_trace_D_E_v_no_infinite_state_statement",
                    "computed_status": "state_projective_small_TV" if tv(sL, spred) < 0.08 else "state_projective_condition_not_met_quantify_drift",
                })
        if {4,5,6}.issubset(set(levels_sorted)) and M == 6:
            c6 = terminal_carrier(mM)
            direct = push_forward(c6, 4)
            via = push_forward(push_forward(c6, 5), 4)
            carrier_comp.append({"branching": b, "mode": mode, "source_level": 6, "mid_level": 5, "target_level": 4, "composition_TV": tv(direct, via), "computed_status": "carrier_composition_residual_le_tolerance" if tv(direct, via) < 1e-12 else "carrier_composition_red"})
            for state in states:
                s6 = terminal_state(mM, state)
                direct_s = push_forward(s6, 4)
                via_s = push_forward(push_forward(s6, 5), 4)
                state_comp.append({"branching": b, "mode": mode, "state": state, "source_level": 6, "mid_level": 5, "target_level": 4, "composition_TV": tv(direct_s, via_s), "computed_status": "state_composition_residual_le_tolerance" if tv(direct_s, via_s) < 1e-12 else "state_composition_red"})
    return carrier_rows, state_rows, carrier_comp, state_comp


def orientation_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str]) -> List[dict]:
    rows: List[dict] = []
    for (b, L, mode, rev), m in sorted(models.items()):
        if rev:
            continue
        rev_m = models.get((b, L, mode, True))
        for st in states:
            row = {"branching": b, "max_level": L, "mode": mode, **orientation_measurement(m, st)}
            if rev_m is not None:
                rev_row = orientation_measurement(rev_m, st)
                row["reverse_order_F1F2_plane_circulation"] = rev_row["F1F2_plane_circulation"]
                row["orientation_order_sensitivity_abs_delta"] = abs(float(row["F1F2_plane_circulation"]) - float(rev_row["F1F2_plane_circulation"]))
                row["orientation_flip_or_sensitivity_condition_note"] = int(abs(float(row["F1F2_plane_circulation"]) - float(rev_row["F1F2_plane_circulation"])) > 1e-10)
            row["computed_status"] = "F1F2_skew_axis_residual_le_tolerance" if row["skew_nonzero"] and row["F1F2_orientation_nonzero"] else "F1F2_skew_axis_condition_not_met"
            rows.append(row)
    return rows


def region_and_gns_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> Tuple[List[dict], List[dict], List[dict]]:
    region_rows: List[dict] = []
    algebra_rows: List[dict] = []
    gns_rows: List[dict] = []
    for (b, L, mode, rev), m in sorted(models.items()):
        if rev:
            continue
        specs = build_sibling_regions(m, max_regions=args.max_regions)
        for spec in specs:
            for st in states:
                base = {
                    "branching": b, "max_level": L, "mode": mode, "state": st,
                    "region_id": spec.region_id, "pair_type": spec.pair_type,
                    "lca": spec.lca, "left_root": spec.left_root, "right_root": spec.right_root,
                    "n_boundary": len(spec.boundary), "n_interior": len(spec.interior),
                    "boundary_nodes": " ".join(map(str, spec.boundary)),
                    "interior_nodes": " ".join(map(str, spec.interior)),
                }
                if len(spec.boundary) > args.max_boundary or len(spec.interior) > args.max_interior:
                    region_rows.append({**base, "response_ok": 0, "response_error": "skipped_size_condition_note"})
                    continue
                res = schur_response_from_model(m, st, spec.boundary, spec.interior)
                if not res.ok or res.Lambda is None:
                    region_rows.append({**base, "response_ok": 0, "response_error": res.error, "cond_KII": res.cond_KII})
                    continue
                Q, qnames = boundary_role_basis(m, spec)
                Lc = compress_response(res.Lambda, Q)
                S = 0.5 * (Lc + Lc.T)
                A = 0.5 * (Lc - Lc.T)
                D = positive_density_from_response(Lc)
                g = gens_from_response(Lc)
                A_in, N_A, A_out = build_algebras(g, args.algebra_tol, args.algebra_max_iter)
                # inclusion distances
                inc_in_N = max([span_residual(B, N_A.basis) for B in A_in.basis], default=0.0)
                inc_N_out = max([span_residual(B, A_out.basis) for B in N_A.basis], default=0.0)
                region_rows.append({
                    **base,
                    "response_ok": 1,
                    "response_error": "",
                    "cond_KII": res.cond_KII,
                    "solve_residual": res.solve_residual,
                    "row_sum_residual": res.row_sum_residual,
                    "compressed_dim": Lc.shape[0],
                    "role_basis_names": " ".join(qnames),
                    "compressed_response_norm": fro(Lc),
                    "compressed_symmetric_norm": fro(S),
                    "compressed_skew_norm": fro(A),
                    "compressed_relative_skew": fro(A) / max(fro(Lc), EPS),
                    "density_trace": float(np.trace(D)),
                    "density_min_eig": float(np.min(np.linalg.eigvalsh(D))),
                    "computed_status": "regional_DtN_response_residual_le_tolerance",
                    "condition_note": "direct_schur_kron_DtN_solve_based_no_inverse",
                })
                for alg in [A_in, N_A, A_out]:
                    algebra_rows.append({
                        **base,
                        "algebra": alg.name,
                        "basis_dim": len(alg.basis),
                        "generator_count": alg.generator_count,
                        "iterations": alg.iterations,
                        "saturated": int(alg.saturated),
                        "inclusion_Ain_to_N": inc_in_N,
                        "inclusion_N_to_Aout": inc_N_out,
                        "computed_status": "finite_real_transpose_closed_algebra_built" if alg.saturated else "algebra_closure_iteration_limit_condition_not_met",
                        "condition_note": "finite_matrix_algebra_finite_object_only_no_vN_weak_closure",
                    })
                    gd = measurement_gns(alg, D, args.gns_tol)
                    gns_rows.append({
                        **base,
                        "algebra": gd.algebra,
                        "algebra_basis_dim": gd.basis_dim,
                        "gns_rank": gd.rank,
                        "gns_nullity": gd.nullity,
                        "gns_gram_min_eig": gd.min_eig,
                        "gns_gram_max_eig": gd.max_eig,
                        "gns_condition": gd.condition,
                        "gns_psd_ok": int(gd.psd_ok),
                        "cyclic_ok": int(gd.cyclic_ok),
                        "cyclic_span_rank": gd.cyclic_span_rank,
                        "cyclic_rank_defect": gd.cyclic_rank_defect,
                        "omega_norm2": gd.omega_norm2,
                        "identity_span_residual": gd.identity_span_residual,
                        "max_cyclic_vector_action_residual": gd.max_cyclic_vector_action_residual,
                        "representation_element_count": gd.representation_element_count,
                        "full_basis_representation_checked": int(gd.full_basis_representation_checked),
                        "representation_ok": int(gd.representation_ok),
                        "max_star_adjoint_error": gd.max_star_adjoint_error,
                        "max_left_closure_residual": gd.max_left_closure_residual,
                        "max_null_left_stability": gd.max_null_left_stability,
                        "computed_status": "finite_GNS_left_regular_representation_checked" if gd.psd_ok and gd.cyclic_ok and gd.representation_ok else "finite_GNS_left_regular_representation_condition_not_met",
                        "condition_note": "finite_pre_Hilbert_GNS_quotient_full_basis_cyclicity_and_representation_audit_no_completion_no_Tomita_property",
                    })
    return region_rows, algebra_rows, gns_rows
