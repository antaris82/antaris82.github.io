from __future__ import annotations

from typing import List, Tuple

from cnna.core.algebra_support import (
    gns_cyclic_rank,
    gns_separating_nullity,
    joined_algebra,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


LOCAL_GNS_SYSTEMS = [
    ("root_anchor_response", 1),
    ("left_frontier_response", 1),
    ("right_frontier_response", 1),
    ("left_birth_cone_response", 1),
    ("right_birth_cone_response", 1),
    ("sibling_pair_response", 0),
    ("full_regional_response", 0),
]

GRADED_BACKREACTION_SYSTEMS = {
    "root_anchor_response",
    "left_frontier_response",
    "right_frontier_response",
    "left_birth_cone_response",
    "right_birth_cone_response",
}


def _computed_status(true_subregion: int, closure_depth: int, cyclic: bool, separating: bool, ambient_saturated: bool) -> str:
    if true_subregion and cyclic and ambient_saturated:
        return "cyclic_only_by_ambient_saturation_control"
    if true_subregion and closure_depth == 0 and cyclic and separating:
        return "proper_subalgebra_static_cyclic_separating_finite_object"
    if true_subregion and closure_depth > 0 and cyclic and separating:
        return "proper_subalgebra_graded_backreaction_cyclic_finite_object"
    if true_subregion and cyclic:
        return "proper_subalgebra_local_cyclic_only"
    if true_subregion and separating:
        return "finite_local_separating_only"
    if (not true_subregion) and cyclic:
        return "finite_total_cyclic_only"
    return "local_vacuum_cyclicity_preform_failed"


def _append_row(rows: List[dict], base: dict, name: str, true_subregion: int, closure_type: str, closure_depth: int, alg, global_alg, D, tol: float, ambient_matrix_dim: int) -> dict:
    cyclic_rank, support_dim = gns_cyclic_rank(alg, global_alg, D, tol)
    gram_rank, nullity, min_pos, max_pos, condition = gns_separating_nullity(alg, D, tol)
    cyclic = cyclic_rank == support_dim and support_dim > 0
    separating = nullity == 0 and len(alg.basis) > 0
    ambient_saturated = len(alg.basis) >= int(ambient_matrix_dim)
    row = {
        **base,
        "local_operator_system": name,
        "closure_type": closure_type,
        "graded_backreaction_closure_depth": int(closure_depth),
        "true_local_subregion": int(true_subregion),
        "local_algebra_dim": len(alg.basis),
        "ambient_matrix_dim": int(ambient_matrix_dim),
        "ambient_saturated_at_closure": int(ambient_saturated),
        "proper_subalgebra_at_closure": int(len(alg.basis) < int(ambient_matrix_dim)),
        "global_gns_support_dim": support_dim,
        "cyclic_span_rank": cyclic_rank,
        "local_gram_rank": gram_rank,
        "separating_kernel_dim": nullity,
        "local_gram_min_positive_eigenvalue_no_epsilon": min_pos,
        "local_gram_max_positive_eigenvalue_no_epsilon": max_pos,
        "local_gram_condition_no_epsilon": condition,
        "cyclic_for_global_support": int(cyclic),
        "separating_on_local_algebra": int(separating),
        "cyclicity_evidence_scope": ("proper_subalgebra" if len(alg.basis) < int(ambient_matrix_dim) else "ambient_saturation_control"),
        "cyclicity_computed_status": _computed_status(int(true_subregion), int(closure_depth), cyclic, separating, ambient_saturated),
    }
    rows.append(row)
    return row


def _graded_closures(name: str, algebras: dict, tol: float, max_iter: int) -> List[Tuple[str, int, object]]:
    base = algebras[name]
    out: List[Tuple[str, int, object]] = [("static_local_operator_system", 0, base)]
    if name not in GRADED_BACKREACTION_SYSTEMS:
        return out

    root = algebras["root_anchor_response"]
    out.append((
        "boundary_anchor_closure",
        1,
        joined_algebra("boundary_anchor_closure_of_" + name, [base, root], tol=tol, max_iter=max_iter),
    ))

    if "left" in name:
        local_current = algebras["skew_left_birth_cone_response"]
    elif "right" in name:
        local_current = algebras["skew_right_birth_cone_response"]
    else:
        local_current = algebras["directed_current_pair_response"]
    out.append((
        "local_directed_current_closure",
        2,
        joined_algebra("local_directed_current_closure_of_" + name, [base, root, local_current], tol=tol, max_iter=max_iter),
    ))
    out.append((
        "pair_backreaction_current_closure",
        3,
        joined_algebra("pair_backreaction_current_closure_of_" + name, [base, root, algebras["directed_current_pair_response"]], tol=tol, max_iter=max_iter),
    ))
    return out


def _annotate_first_cyclic_depth(rows: List[dict], start: int) -> None:
    grouped = {}
    for idx in range(start, len(rows)):
        r = rows[idx]
        key = (
            r.get("branching"), r.get("level"), r.get("mode"), r.get("region_id"),
            r.get("state"), r.get("local_operator_system"),
        )
        grouped.setdefault(key, []).append(idx)
    for idxs in grouped.values():
        cyclic_depths = [int(rows[i]["graded_backreaction_closure_depth"]) for i in idxs if int(rows[i].get("cyclic_for_global_support", 0)) == 1]
        proper_cyclic_depths = [int(rows[i]["graded_backreaction_closure_depth"]) for i in idxs if int(rows[i].get("cyclic_for_global_support", 0)) == 1 and int(rows[i].get("ambient_saturated_at_closure", 0)) == 0]
        first = min(cyclic_depths) if cyclic_depths else -1
        first_proper = min(proper_cyclic_depths) if proper_cyclic_depths else -1
        for i in idxs:
            rows[i]["minimal_cyclic_closure_depth"] = int(first)
            rows[i]["minimal_proper_subalgebra_cyclic_closure_depth"] = int(first_proper)
            rows[i]["is_minimal_cyclic_closure_depth"] = int(first >= 0 and int(rows[i]["graded_backreaction_closure_depth"]) == first)
            rows[i]["is_minimal_proper_subalgebra_cyclic_closure_depth"] = int(first_proper >= 0 and int(rows[i]["graded_backreaction_closure_depth"]) == first_proper)


def local_vacuum_cyclicity_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                block_start = len(rows)
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "cyclicity_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                global_alg = algebras["full_regional_response"]
                ambient_matrix_dim = int(resp.Lambda_role.shape[0] * resp.Lambda_role.shape[0])
                base = {"branching": b, "level": L, "mode": mode, **meta, "state": state, **resp.density_metadata}
                for name, true_subregion in LOCAL_GNS_SYSTEMS:
                    for closure_type, closure_depth, alg in _graded_closures(name, algebras, config.algebra_tol, config.max_algebra_iter):
                        _append_row(rows, base, name, true_subregion, closure_type, closure_depth, alg, global_alg, resp.density, config.rank_tol, ambient_matrix_dim)
                _annotate_first_cyclic_depth(rows, block_start)
    return rows


def cyclicity_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("cyclicity_computed_status", "unknown")) for r in rows})
    closures = sorted({str(r.get("closure_type", "unknown")) for r in rows if "closure_type" in r})
    return "# Finite local vacuum cyclicity report\n\nMeasurements the finite Reeh-Schlieder preform with graded closures: static local operator system (depth 0), explicit boundary-anchor closure (depth 1), local directed-current closure (depth 2), and pair-level backreaction-current closure (depth 3).  The CSV reports both the raw minimal closure depth k_min and the proper-subalgebra minimal depth; cyclic rows caused only by saturation of the finite ambient matrix algebra are labelled as controls, not Reeh-Schlieder evidence.  Total-algebra cyclicity is reported separately and is not counted as the nontrivial local result.  The reference GNS state has no epsilon floor.\n\nObserved closure types: `" + "`, `".join(closures) + "`.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
