from __future__ import annotations

from typing import List

from cnna.core.response_algebra import positive_density_from_response

from cnna.core.algebra_support import (
    gns_separating_nullity,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


FAITHFULNESS_SYSTEMS = [
    "root_anchor_response",
    "left_frontier_response",
    "right_frontier_response",
    "left_birth_cone_response",
    "right_birth_cone_response",
    "sibling_pair_response",
    "positive_carrier_pair_response",
    "directed_current_pair_response",
    "full_regional_response",
]


EPSILON_FLOOR_CONTROL = 1.0e-9


def _computed_status(nullity: int, condition: float, support_rank: int, ambient_dim: int) -> str:
    if support_rank <= 0:
        return "zero_positive_support_state"
    if nullity == 0 and support_rank == ambient_dim and condition < 1.0e12:
        return "faithful_on_operator_system_no_epsilon_floor"
    if nullity == 0 and support_rank == ambient_dim:
        return "separating_but_ill_conditioned_no_epsilon_floor"
    if nullity == 0 and support_rank < ambient_dim:
        return "separating_on_operator_system_but_state_singular"
    return "not_faithful_on_operator_system_no_epsilon_floor"


def faithful_state_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "faithfulness_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                control_density = positive_density_from_response(resp.Lambda_role, eps=EPSILON_FLOOR_CONTROL)
                support_rank = int(resp.density_metadata.get("density_support_rank", 0))
                ambient_dim = int(resp.density_metadata.get("density_ambient_dim", resp.Lambda_role.shape[0]))
                for name in FAITHFULNESS_SYSTEMS:
                    alg = algebras[name]
                    rank, nullity, min_pos, max_pos, condition = gns_separating_nullity(alg, resp.density, config.rank_tol)
                    c_rank, c_nullity, c_min_pos, c_max_pos, c_condition = gns_separating_nullity(alg, control_density, config.rank_tol)
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        "operator_system": name,
                        "algebra_dim": len(alg.basis),
                        "state_gram_rank_no_epsilon": rank,
                        "state_gram_nullity_no_epsilon": nullity,
                        "state_gram_min_positive_eigenvalue_no_epsilon": min_pos,
                        "state_gram_max_positive_eigenvalue_no_epsilon": max_pos,
                        "state_gram_condition_no_epsilon": condition,
                        "separating_state_finite_object_no_epsilon": int(nullity == 0),
                        "epsilon_floor_control": EPSILON_FLOOR_CONTROL,
                        "epsilon_control_gram_rank": c_rank,
                        "epsilon_control_gram_nullity": c_nullity,
                        "epsilon_control_gram_min_positive_eigenvalue": c_min_pos,
                        "epsilon_control_gram_max_positive_eigenvalue": c_max_pos,
                        "epsilon_control_gram_condition": c_condition,
                        "epsilon_floor_changes_nullity": int(c_nullity != nullity),
                        "faithfulness_computed_status": _computed_status(nullity, condition, support_rank, ambient_dim),
                    })
    return rows


def faithful_state_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("faithfulness_computed_status", "unknown")) for r in rows})
    return "# Finite faithful-state report\n\nMeasurements finite faithfulness/separating behavior by the Gram form ρ(aᵀb) on each local operator system.  The reference state is the positive spectral support of the symmetrized response with no epsilon floor.  An epsilon-floored density is reported only as a labelled numerical control and is not counted as the CNNA reference state.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
