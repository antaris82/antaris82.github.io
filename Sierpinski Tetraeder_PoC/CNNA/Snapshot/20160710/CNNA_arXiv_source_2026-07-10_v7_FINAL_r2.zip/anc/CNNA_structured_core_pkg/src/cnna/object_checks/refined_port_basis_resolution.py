from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.refined_port_basis import (
    refined_boundary_role_basis as refined_boundary_role_basis_for_tests,
    refined_regional_response,
    refined_support_algebra,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def refined_port_basis_resolution_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            Qref, names, bmeta = refined_boundary_role_basis_for_tests(model, spec)
            live3 = regional_response(model, spec, "live")
            liveref = refined_regional_response(model, spec, "live")
            if live3 is None or liveref is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, **bmeta, "refined_basis_resolution_computed_status": "response_unavailable"})
                continue
            alg3 = local_operator_algebras(live3, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            left_ref = refined_support_algebra(liveref, "left", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            right_ref = refined_support_algebra(liveref, "right", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            left_front_ref = refined_support_algebra(liveref, "left_frontier", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            right_front_ref = refined_support_algebra(liveref, "right_frontier", "mixed", tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            dim_gain = int(liveref.Lambda_role.shape[0] - live3.Lambda_role.shape[0])
            alg_gain = int((len(left_ref.basis) + len(right_ref.basis)) - (len(alg3["left_birth_cone_response"].basis) + len(alg3["right_birth_cone_response"].basis)))
            if dim_gain <= 0:
                computed_status = "refined_basis_no_extra_resolution_control"
            elif alg_gain > 0:
                computed_status = "refined_port_basis_increases_operator_resolution_finite_object"
            else:
                computed_status = "refined_port_basis_extra_coordinates_without_algebra_gain_control"
            rows.append({
                "branching": b,
                "level": L,
                "mode": mode,
                **meta,
                **bmeta,
                "coarse_role_dim": int(live3.Lambda_role.shape[0]),
                "refined_role_dim_actual": int(liveref.Lambda_role.shape[0]),
                "refined_role_dim_gain": dim_gain,
                "coarse_left_birth_dim": len(alg3["left_birth_cone_response"].basis),
                "coarse_right_birth_dim": len(alg3["right_birth_cone_response"].basis),
                "refined_left_birth_dim": len(left_ref.basis),
                "refined_right_birth_dim": len(right_ref.basis),
                "refined_left_frontier_dim": len(left_front_ref.basis),
                "refined_right_frontier_dim": len(right_front_ref.basis),
                "refined_operator_dim_gain_sum": alg_gain,
                "refined_basis_resolution_computed_status": computed_status,
            })
    return rows


def refined_port_basis_resolution_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("refined_basis_resolution_computed_status", "unknown")) for r in rows})
    return (
        "# Refined boundary-port basis resolution\n\n"
        "This finite surface addresses the 3-role compression rank_bound without changing the locked core.  "
        "It refines C_lca/B1_front/B2_front into disjoint early/late boundary-port groups and reports whether this creates real operator-resolution gain.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
