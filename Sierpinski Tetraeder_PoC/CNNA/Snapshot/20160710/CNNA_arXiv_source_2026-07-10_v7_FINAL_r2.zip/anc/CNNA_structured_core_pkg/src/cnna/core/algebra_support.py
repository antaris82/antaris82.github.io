from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import fro
from cnna.core.response_algebra import (
    AlgebraBasis,
    add_to_basis,
    algebra_closure,
    project_coeffs,
    reconstruct,
    span_residual,
    state_gram,
    left_coeff_matrix,
)
from cnna.core.schur_dtn import RegionSpec, boundary_role_basis
from cnna.core.directed_dtn import (
    directed_local_matrix,
    directed_schur_response,
    directed_schur_response_from_model,
    region_frontier_level,
    split_symmetric_skew,
)
from cnna.core.region_response import RegionalResponse


def _unit_projector(index: int, dim: int) -> np.ndarray:
    P = np.zeros((dim, dim), dtype=float)
    if 0 <= index < dim:
        P[index, index] = 1.0
    return P


def _sandwich(P: np.ndarray, X: np.ndarray, Q: Optional[np.ndarray] = None) -> np.ndarray:
    return P @ X @ (P if Q is None else Q)


def _symmetric_coupling(S: np.ndarray, i: int, j: int) -> np.ndarray:
    d = S.shape[0]
    Pi = _unit_projector(i, d)
    Pj = _unit_projector(j, d)
    return Pi @ S @ Pj + Pj @ S @ Pi


def _skew_coupling(A: np.ndarray, i: int, j: int) -> np.ndarray:
    d = A.shape[0]
    Pi = _unit_projector(i, d)
    Pj = _unit_projector(j, d)
    return Pi @ A @ Pj + Pj @ A @ Pi


def operator_scale_metadata(response: RegionalResponse, *, tol: float = 1.0e-10) -> dict:
    """Scale condition_note for null directed-current layers.

    CNNA sym controls can have a skew/current matrix whose Frobenius norm is
    only floating-point residue.  Without a norm condition, algebra_closure would
    normalize that residue and produce a spurious finite algebra.  The condition_note is
    relative to the symmetric carrier scale and records the decision explicitly.
    """
    carrier_norm = float(fro(response.symmetric_role))
    current_norm = float(fro(response.skew_role))
    scale = max(1.0, carrier_norm)
    condition = max(float(tol), float(tol) * scale)
    zero_current = int(current_norm <= condition)
    return {
        "symmetric_carrier_norm": carrier_norm,
        "directed_current_norm": current_norm,
        "directed_current_relative_norm": float(current_norm / scale),
        "directed_current_norm_condition": float(condition),
        "vacuous_zero_current_layer": zero_current,
        "current_norm_condition_rule": "fro(A) <= max(tol, tol*max(1,fro(S)))",
    }


def _nonzero_or_empty(X: np.ndarray, *, tol: float, scale: float) -> List[np.ndarray]:
    condition = max(float(tol), float(tol) * max(1.0, float(scale)))
    return [] if float(fro(X)) <= condition else [X]


def local_operator_generators(response: RegionalResponse, *, generator_tol: float = 1.0e-10) -> Dict[str, List[np.ndarray]]:
    """Named generator systems in the compressed role response space.

    Names describe the finite physical object being generated, not the
    generator-list construction.  Layer-split systems are explicit so locality and
    additivity can distinguish symmetric carrier response from directed skew
    response.  Directed-current generators are norm-conditiond relative to the
    symmetric carrier so sym/null-current controls cannot become nontrivial
    algebras merely by Frobenius normalization of numerical residue.
    """
    L = response.Lambda_role
    S = response.symmetric_role
    A_raw = response.skew_role
    d = int(L.shape[0])
    I = np.eye(d)
    P = [_unit_projector(k, d) for k in range(max(d, 3))]
    scale_S = max(1.0, float(fro(S)))
    A_terms = _nonzero_or_empty(A_raw, tol=generator_tol, scale=scale_S)
    A = A_terms[0] if A_terms else np.zeros_like(A_raw)

    def a_block(X: np.ndarray) -> List[np.ndarray]:
        return _nonzero_or_empty(X, tol=generator_tol, scale=scale_S)

    root_anchor = [I, P[0], _sandwich(P[0], S)] + a_block(_sandwich(P[0], A))

    left_symmetric_cone = [I, P[0], P[1], _sandwich(P[0], S), _sandwich(P[1], S), _symmetric_coupling(S, 0, 1)]
    right_symmetric_cone = [I, P[0], P[2], _sandwich(P[0], S), _sandwich(P[2], S), _symmetric_coupling(S, 0, 2)]
    left_skew_cone = [I, P[0], P[1]] + a_block(_sandwich(P[0], A)) + a_block(_sandwich(P[1], A)) + a_block(_skew_coupling(A, 0, 1))
    right_skew_cone = [I, P[0], P[2]] + a_block(_sandwich(P[0], A)) + a_block(_sandwich(P[2], A)) + a_block(_skew_coupling(A, 0, 2))

    left_cone = left_symmetric_cone + a_block(_skew_coupling(A, 0, 1))
    right_cone = right_symmetric_cone + a_block(_skew_coupling(A, 0, 2))
    left_boundary = [I, P[1], _sandwich(P[1], S)]
    right_boundary = [I, P[2], _sandwich(P[2], S)]

    symmetric_pair = [I, P[0], P[1], P[2], S, _symmetric_coupling(S, 0, 1), _symmetric_coupling(S, 0, 2), _symmetric_coupling(S, 1, 2)]
    skew_pair = [I, P[0], P[1], P[2]] + A_terms + a_block(_skew_coupling(A, 0, 1)) + a_block(_skew_coupling(A, 0, 2)) + a_block(_skew_coupling(A, 1, 2))
    sibling_pair = [I, P[0], P[1], P[2], S, _symmetric_coupling(S, 1, 2)] + A_terms + a_block(_skew_coupling(A, 1, 2))
    full_regional = [I, S] + A_terms + P[:d]
    return {
        "root_anchor_response": root_anchor,
        "left_birth_cone_response": left_cone,
        "right_birth_cone_response": right_cone,
        "left_frontier_response": left_boundary,
        "right_frontier_response": right_boundary,
        "symmetric_left_birth_cone_response": left_symmetric_cone,
        "symmetric_right_birth_cone_response": right_symmetric_cone,
        "skew_left_birth_cone_response": left_skew_cone,
        "skew_right_birth_cone_response": right_skew_cone,
        "sibling_pair_response": sibling_pair,
        "positive_carrier_pair_response": symmetric_pair,
        "directed_current_pair_response": skew_pair,
        "full_regional_response": full_regional,
    }


def role_coordinate_mapping(role_names: Sequence[str], dim: int) -> Tuple[Dict[str, int], dict]:
    """Resolve deterministic role coordinates from role names, with explicit condition_note metadata."""
    names = [str(x) for x in role_names]
    lower = [x.lower() for x in names]

    def find_role(*needles: str, fallback: int) -> int:
        for needle in needles:
            for i, name in enumerate(lower):
                if needle in name:
                    return i
        return fallback if fallback < int(dim) else -1

    root_i = find_role("lca", "root", fallback=0)
    left_i = find_role("b1", "left", "f1", fallback=1)
    right_i = find_role("b2", "right", "f2", fallback=2)
    mapping = {"root": root_i, "left": left_i, "right": right_i}
    ok = int(root_i >= 0 and left_i >= 0 and right_i >= 0 and len({root_i, left_i, right_i}) == 3 and int(dim) >= 3)
    meta = {
        "role_name_mapping_ok": ok,
        "deterministic_role_names": "|".join(names),
        "root_role_index": int(root_i),
        "left_role_index": int(left_i),
        "right_role_index": int(right_i),
        "role_index_relations": "name_resolved_C_lca_B1_front_B2_front_with_numeric_fallback_condition_note",
    }
    return mapping, meta


def role_support_indices(system_name: str, dim: int, role_names: Optional[Sequence[str]] = None) -> Tuple[int, ...]:
    """Deterministic role-coordinate support used by finite embedding measurements.

    When role names are available, coordinates are derived from names rather
    than silently assuming 0=LCA, 1=left, 2=right.  The numeric fallback is
    retained only for backwards-compatible helpers and is conditioned by metadata
    in independent_embedding_metrics.  This is still a compressed role-carrier
    support map, not a node-level Schur embedding.
    """
    all_idx = tuple(range(int(dim)))
    if int(dim) <= 0:
        return tuple()
    if role_names is not None:
        mapping, _meta = role_coordinate_mapping(role_names, dim)
        root_i = mapping.get("root", -1)
        left_i = mapping.get("left", -1)
        right_i = mapping.get("right", -1)
    else:
        root_i, left_i, right_i = 0, 1 if dim > 1 else -1, 2 if dim > 2 else -1

    def keep(xs: Sequence[int]) -> Tuple[int, ...]:
        return tuple(int(i) for i in xs if 0 <= int(i) < int(dim))

    root = keep((root_i,))
    left = keep((root_i, left_i))
    right = keep((root_i, right_i))
    left_front = keep((left_i,))
    right_front = keep((right_i,))
    pair = keep((root_i, left_i, right_i))
    if system_name == "root_anchor_response":
        return root
    if system_name in {"left_frontier_response"}:
        return left_front
    if system_name in {"right_frontier_response"}:
        return right_front
    if system_name in {"left_birth_cone_response", "symmetric_left_birth_cone_response", "skew_left_birth_cone_response", "backreaction_current_left_birth_cone"}:
        return left
    if system_name in {"right_birth_cone_response", "symmetric_right_birth_cone_response", "skew_right_birth_cone_response", "backreaction_current_right_birth_cone"}:
        return right
    if system_name in {"sibling_pair_response", "positive_carrier_pair_response", "directed_current_pair_response", "backreaction_current_pair", "backreaction_current_sibling_cross"}:
        return pair
    return all_idx


def role_support_projector(indices: Sequence[int], dim: int) -> np.ndarray:
    P = np.zeros((int(dim), int(dim)), dtype=float)
    for i in indices:
        if 0 <= int(i) < int(dim):
            P[int(i), int(i)] = 1.0
    return P


def independently_restricted_operator_algebra(
    response: RegionalResponse,
    system_name: str,
    *,
    tol: float,
    max_iter: int,
) -> AlgebraBasis:
    """Build an operator algebra from role-support restrictions, not generator IDs.

    This is a stronger finite coordinate embedding measurement than the construction-
    nested generator check.  It still does not statement a separate node-level Schur
    reconstruction of every subregion; that limitation is recorded by callers.
    """
    L = response.Lambda_role
    S = response.symmetric_role
    A = response.skew_role
    d = int(L.shape[0])
    idx = role_support_indices(system_name, d, response.role_names)
    Psys = role_support_projector(idx, d)
    gens: List[np.ndarray] = [np.eye(d)]
    for i in idx:
        gens.append(_unit_projector(int(i), d))
    wants_s = (
        "symmetric" in system_name
        or "positive_carrier" in system_name
        or "frontier" in system_name
        or "birth_cone" in system_name
        or "root_anchor" in system_name
        or "sibling_pair" in system_name
        or "full_regional" in system_name
    )
    wants_a = (
        "skew" in system_name
        or "directed_current" in system_name
        or "birth_cone" in system_name
        or "root_anchor" in system_name
        or "sibling_pair" in system_name
        or "full_regional" in system_name
    )
    scale_S = max(1.0, float(fro(S)))
    if wants_s:
        gens.append(Psys @ S @ Psys)
    if wants_a:
        gens.extend(_nonzero_or_empty(Psys @ A @ Psys, tol=tol, scale=scale_S))
    # Keep explicit same-support off-diagonal carrier/current blocks.
    for a, i in enumerate(idx):
        for j in idx[a + 1:]:
            if wants_s:
                gens.append(_symmetric_coupling(S, int(i), int(j)))
            if wants_a:
                gens.extend(_nonzero_or_empty(_skew_coupling(A, int(i), int(j)), tol=tol, scale=scale_S))
    return algebra_closure("independent_restricted_" + system_name, gens, tol=tol, max_iter=max_iter)


def independent_embedding_metrics(
    response: RegionalResponse,
    small_name: str,
    large_name: str,
    *,
    tol: float,
    max_iter: int,
) -> dict:
    d = int(response.Lambda_role.shape[0])
    small_idx = role_support_indices(small_name, d, response.role_names)
    large_idx = role_support_indices(large_name, d, response.role_names)
    _role_map, role_meta = role_coordinate_mapping(response.role_names, d)
    support_inclusion = set(small_idx).issubset(set(large_idx))
    small_ind = independently_restricted_operator_algebra(response, small_name, tol=tol, max_iter=max_iter)
    large_ind = independently_restricted_operator_algebra(response, large_name, tol=tol, max_iter=max_iter)
    embedded_span = max_span_residual(small_ind.basis, large_ind.basis)
    embedded_star = max_star_residual(small_ind.basis, large_ind.basis)
    low_dim_control = int(d <= 3 and support_inclusion)
    return {
        "embedding_map_type": "finite_coordinate_support_identity_inclusion_not_node_level_schur",
        **role_meta,
        "independent_embedding_map_checked": int(support_inclusion),
        "node_level_independent_schur_embedding_checked": 0,
        "subregion_role_support": " ".join(str(i) for i in small_idx),
        "superregion_role_support": " ".join(str(i) for i in large_idx),
        "role_support_subset_ok": int(support_inclusion),
        "coordinate_support_low_dim_control": low_dim_control,
        "embedding_condition_has_failure_potential": int((not low_dim_control) and role_meta.get("role_name_mapping_ok", 0) == 1),
        "embedding_discrimination_scope": (
            "low_dim_coordinate_support_control_not_node_level_property"
            if low_dim_control else "coordinate_support_embedding_measurement"
        ),
        "independent_subalgebra_dim": len(small_ind.basis),
        "independent_superalgebra_dim": len(large_ind.basis),
        "independent_sub_to_super_span_residual": float(embedded_span),
        "independent_sub_star_to_super_residual": float(embedded_star),
        "independent_embedding_computed_status": (
            "finite_coordinate_support_embedding_ok_low_dim_control"
            if low_dim_control and embedded_span <= tol and embedded_star <= tol
            else ("finite_coordinate_support_embedding_ok" if support_inclusion and embedded_span <= tol and embedded_star <= tol else "finite_coordinate_support_embedding_obstructed")
        ),
    }


def local_operator_algebras(response: RegionalResponse, *, tol: float, max_iter: int) -> Dict[str, AlgebraBasis]:
    out: Dict[str, AlgebraBasis] = {}
    for name, gens in local_operator_generators(response, generator_tol=tol).items():
        out[name] = algebra_closure(name, gens, tol=tol, max_iter=max_iter)
    return out


def max_span_residual(source: Sequence[np.ndarray], target: Sequence[np.ndarray]) -> float:
    if not source:
        return 0.0
    return max(float(span_residual(X, target)) for X in source)


def max_star_residual(source: Sequence[np.ndarray], target: Sequence[np.ndarray]) -> float:
    if not source:
        return 0.0
    return max(float(span_residual(X.T, target)) for X in source)


def joined_algebra(name: str, parts: Sequence[AlgebraBasis], *, tol: float, max_iter: int) -> AlgebraBasis:
    gens: List[np.ndarray] = []
    for alg in parts:
        gens.extend(alg.basis)
    return algebra_closure(name, gens, tol=tol, max_iter=max_iter)


def commutator_metrics(left: AlgebraBasis, right: AlgebraBasis) -> dict:
    max_abs = 0.0
    max_rel = 0.0
    count = 0
    for A in left.basis:
        for B in right.basis:
            C = A @ B - B @ A
            n = fro(C)
            denom = max(fro(A) * fro(B), EPS)
            max_abs = max(max_abs, n)
            max_rel = max(max_rel, n / denom)
            count += 1
    return {"commutator_pair_count": int(count), "max_commutator_fro": float(max_abs), "max_relative_commutator": float(max_rel)}


def state_commutator_metric(left: AlgebraBasis, right: AlgebraBasis, D: np.ndarray) -> float:
    mx = 0.0
    for A in left.basis:
        for B in right.basis:
            mx = max(mx, abs(float(np.trace(D @ (A @ B - B @ A)))))
    return float(mx)


def matrix_rank_from_columns(columns: np.ndarray, tol: float) -> int:
    if columns.size == 0:
        return 0
    try:
        s = np.linalg.svd(columns, compute_uv=False)
    except np.linalg.LinAlgError:
        return 0
    if s.size == 0:
        return 0
    cutoff = max(float(tol), float(tol) * max(1.0, float(np.max(s))))
    return int(np.sum(s > cutoff))


def gns_support_data(global_alg: AlgebraBasis, D: np.ndarray, tol: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    G = state_gram(global_alg.basis, D)
    if G.size == 0:
        return G, np.zeros(0), np.zeros((0, 0)), np.zeros(0, dtype=bool)
    vals, U = np.linalg.eigh(0.5 * (G + G.T))
    maxeig = float(np.max(vals)) if vals.size else 0.0
    mask = vals > max(float(tol), float(tol) * max(1.0, maxeig))
    return G, vals, U, mask


def gns_cyclic_rank(local_alg: AlgebraBasis, global_alg: AlgebraBasis, D: np.ndarray, tol: float) -> Tuple[int, int]:
    G, vals, U, mask = gns_support_data(global_alg, D, tol)
    support_dim = int(np.sum(mask))
    if support_dim == 0:
        return 0, 0
    coords = np.column_stack([project_coeffs(X, global_alg.basis) for X in local_alg.basis]) if local_alg.basis else np.zeros((len(global_alg.basis), 0))
    weighted = np.diag(np.sqrt(vals[mask])) @ (U[:, mask].T @ coords)
    return matrix_rank_from_columns(weighted, tol), support_dim


def gns_separating_nullity(local_alg: AlgebraBasis, D: np.ndarray, tol: float) -> Tuple[int, int, float, float, float]:
    G = state_gram(local_alg.basis, D)
    if G.size == 0:
        return 0, 0, math.nan, math.nan, math.inf
    vals = np.linalg.eigvalsh(0.5 * (G + G.T))
    maxeig = float(np.max(vals)) if vals.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxeig))
    rank = int(np.sum(vals > cutoff))
    nullity = int(len(vals) - rank)
    pos = vals[vals > cutoff]
    min_pos = float(np.min(pos)) if pos.size else math.nan
    max_pos = float(np.max(pos)) if pos.size else math.nan
    cond = float(max_pos / min_pos) if pos.size and min_pos > 0 else math.inf
    return rank, nullity, min_pos, max_pos, cond


def nullspace(A: np.ndarray, tol: float) -> np.ndarray:
    if A.size == 0:
        return np.eye(A.shape[1] if A.ndim == 2 else 0)
    U, s, Vt = np.linalg.svd(A, full_matrices=True)
    maxs = float(np.max(s)) if s.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxs))
    return Vt.T[:, int(np.sum(s > cutoff)):]


def commutant_algebra_basis(algebra: AlgebraBasis, dim: int, tol: float) -> List[np.ndarray]:
    """Compute an orthonormal Frobenius basis for {X : XA=AX for all A}."""
    equations: List[np.ndarray] = []
    for A in algebra.basis:
        cols = []
        for r in range(dim):
            for c in range(dim):
                E = np.zeros((dim, dim), dtype=float)
                E[r, c] = 1.0
                cols.append((E @ A - A @ E).reshape(-1))
        equations.append(np.column_stack(cols))
    if not equations:
        return [np.eye(dim)]
    M = np.vstack(equations)
    Z = nullspace(M, tol)
    basis: List[np.ndarray] = []
    for k in range(Z.shape[1]):
        X = Z[:, k].reshape(dim, dim)
        add_to_basis(X, basis, tol)
    return basis


def basis_to_algebra(name: str, basis: Sequence[np.ndarray]) -> AlgebraBasis:
    return AlgebraBasis(name=name, basis=list(basis), generator_count=len(basis), iterations=0, saturated=True)


def star_map_matrix(algebra: AlgebraBasis) -> Tuple[np.ndarray, float]:
    m = len(algebra.basis)
    C = np.zeros((m, m), dtype=float)
    max_res = 0.0
    for j, B in enumerate(algebra.basis):
        C[:, j] = project_coeffs(B.T, algebra.basis)
        max_res = max(max_res, span_residual(B.T, algebra.basis))
    return C, float(max_res)


def finite_tomita_star_metrics(
    global_alg: AlgebraBasis,
    D: np.ndarray,
    tol: float,
    orientation_operator: Optional[np.ndarray] = None,
    orientation_carrier_norm: Optional[float] = None,
) -> dict:
    """Finite Tomita comparison on the GNS support.

    This computes the star-induced Tomita map S0(aΩ)=aᵀΩ on the finite GNS
    quotient support and then performs a real polar decomposition.  It does
    not require the star map to be an isometry in the state Gram form; that
    would only be appropriate in special tracial/isometric cases.
    """
    orientation_norm = float(fro(orientation_operator)) if orientation_operator is not None else math.nan
    orientation_scale = max(1.0, float(orientation_carrier_norm) if orientation_carrier_norm is not None else 1.0)
    orientation_condition = max(float(tol), float(tol) * orientation_scale)
    orientation_vacuous = int(orientation_operator is not None and orientation_norm <= orientation_condition)
    orientation_relation_scope = (
        "orientation_vacuous_zero_current_control" if orientation_vacuous else
        ("orientation_operator_available" if orientation_operator is not None else "orientation_operator_missing")
    )

    C, star_res = star_map_matrix(global_alg)
    invol = fro(C @ C - np.eye(C.shape[0])) / max(1.0, math.sqrt(max(1, C.shape[0]))) if C.size else 0.0
    G, vals, U, mask = gns_support_data(global_alg, D, tol)
    support_dim = int(np.sum(mask))
    if support_dim == 0:
        return {
            "tomita_support_dim": 0,
            "star_closure_residual": star_res,
            "star_involution_error": invol,
            "star_support_leakage": math.nan,
            "tomita_map_rank": 0,
            "tomita_polar_residual": math.nan,
            "tomita_conjugation_orthogonality_error": math.nan,
            "tomita_conjugation_involution_error": math.nan,
            "modular_operator_min_eigenvalue": math.nan,
            "modular_operator_max_eigenvalue": math.nan,
            "modular_inverse_relation_error": math.nan,
            "modular_spectrum_spread": math.nan,
            "modular_spectrum_nontrivial": 0,
            "star_isometry_error_control": math.nan,
            "cnna_orientation_operator_norm": float(orientation_norm) if math.isfinite(orientation_norm) else math.nan,
            "cnna_orientation_operator_relative_norm": float(orientation_norm / orientation_scale) if math.isfinite(orientation_norm) else math.nan,
            "cnna_orientation_norm_condition": float(orientation_condition),
            "cnna_orientation_relation_scope": orientation_relation_scope,
            "orientation_vacuous_zero_current": int(orientation_vacuous),
            "cnna_orientation_left_action_residual": math.nan,
            "tomita_conjuconditions_cnna_orientation_to_negative_residual": math.nan,
            "tomita_cnna_orientation_relation_checked": 0,
            "cnna_orientation_operator_span_residual": math.nan,
            "cnna_orientation_support_leakage": math.nan,
        }
    Us = U[:, mask]
    Un = U[:, ~mask]
    leakage = fro(Un.T @ C @ Us) if Un.size else 0.0
    sqrtS = np.diag(np.sqrt(vals[mask]))
    invsqrtS = np.diag(1.0 / np.sqrt(vals[mask]))
    T = sqrtS @ (Us.T @ C @ Us) @ invsqrtS

    # Control only: this was the former strict condition and is retained only
    # to show whether the state happens to be star-isometric.
    isom = fro(T.T @ T - np.eye(support_dim)) / max(1.0, math.sqrt(support_dim))

    try:
        U_svd, svals, Vt = np.linalg.svd(T, full_matrices=True)
        Jt = U_svd @ Vt
    except np.linalg.LinAlgError:
        return {
            "tomita_support_dim": support_dim,
            "star_closure_residual": float(star_res),
            "star_involution_error": float(invol),
            "star_support_leakage": float(leakage),
            "tomita_map_rank": 0,
            "tomita_polar_residual": math.nan,
            "tomita_conjugation_orthogonality_error": math.nan,
            "tomita_conjugation_involution_error": math.nan,
            "modular_operator_min_eigenvalue": math.nan,
            "modular_operator_max_eigenvalue": math.nan,
            "modular_inverse_relation_error": math.nan,
            "modular_spectrum_spread": math.nan,
            "modular_spectrum_nontrivial": 0,
            "star_isometry_error_control": float(isom),
            "cnna_orientation_operator_norm": float(orientation_norm) if math.isfinite(orientation_norm) else math.nan,
            "cnna_orientation_operator_relative_norm": float(orientation_norm / orientation_scale) if math.isfinite(orientation_norm) else math.nan,
            "cnna_orientation_norm_condition": float(orientation_condition),
            "cnna_orientation_relation_scope": orientation_relation_scope,
            "orientation_vacuous_zero_current": int(orientation_vacuous),
            "cnna_orientation_left_action_residual": math.nan,
            "tomita_conjuconditions_cnna_orientation_to_negative_residual": math.nan,
            "tomita_cnna_orientation_relation_checked": 0,
            "cnna_orientation_operator_span_residual": math.nan,
            "cnna_orientation_support_leakage": math.nan,
        }

    Delta = T.T @ T
    dvals = np.zeros(0, dtype=float)
    dpos = np.zeros(0, dtype=float)
    try:
        dvals, dU = np.linalg.eigh(0.5 * (Delta + Delta.T))
        dpos = np.maximum(dvals, 0.0)
        sqrtDelta = dU @ np.diag(np.sqrt(dpos)) @ dU.T
        inv_vals = np.array([1.0 / x if x > max(tol, tol * max(1.0, float(np.max(dpos)))) else 0.0 for x in dpos], dtype=float)
        invDelta = dU @ np.diag(inv_vals) @ dU.T
        min_delta = float(np.min(dvals)) if dvals.size else math.nan
        max_delta = float(np.max(dvals)) if dvals.size else math.nan
        inverse_relation = fro(Jt @ Delta @ Jt.T - invDelta) / max(1.0, fro(invDelta))
    except np.linalg.LinAlgError:
        sqrtDelta = np.zeros_like(T)
        min_delta = math.nan
        max_delta = math.nan
        inverse_relation = math.nan

    polar_res = fro(T - Jt @ sqrtDelta) / max(1.0, fro(T))
    ortho = fro(Jt.T @ Jt - np.eye(support_dim)) / max(1.0, math.sqrt(support_dim))
    involJ = fro(Jt @ Jt - np.eye(support_dim)) / max(1.0, math.sqrt(support_dim))

    orientation_span_res = math.nan
    orientation_leakage = math.nan
    orientation_action_norm = math.nan
    orientation_relation = math.nan
    orientation_checked = 0
    if orientation_operator is not None and not orientation_vacuous:
        try:
            Cx, orientation_span_res = left_coeff_matrix(orientation_operator, global_alg.basis)
            orientation_leakage = fro(Un.T @ Cx @ Us) if Un.size else 0.0
            Xs = sqrtS @ (Us.T @ Cx @ Us) @ invsqrtS
            orientation_action_norm = fro(Xs)
            orientation_relation = fro(Jt @ Xs @ Jt.T + Xs) / max(1.0, orientation_action_norm)
            orientation_checked = int(orientation_span_res <= max(1.0e-7, 10.0 * tol) and orientation_leakage <= max(1.0e-7, 10.0 * tol))
            if orientation_checked:
                orientation_relation_scope = "orientation_relation_checked"
            else:
                orientation_relation_scope = "orientation_relation_unchecked_condition_sensitive"
        except Exception:
            orientation_checked = 0
            orientation_relation_scope = "orientation_relation_exception_unchecked"
    map_rank = matrix_rank_from_columns(T, tol)
    positive_delta = [float(x) for x in dpos if float(x) > max(float(tol), float(tol) * max(1.0, float(np.max(dpos)) if dpos.size else 1.0))]
    positive_delta_sorted = sorted(positive_delta)
    adjacent_ratios = [positive_delta_sorted[i + 1] / positive_delta_sorted[i] for i in range(len(positive_delta_sorted) - 1) if positive_delta_sorted[i] > 0.0]
    modular_log_span = float(math.log(max_delta / min_delta)) if math.isfinite(min_delta) and math.isfinite(max_delta) and min_delta > 0 else math.inf
    return {
        "tomita_support_dim": support_dim,
        "star_closure_residual": float(star_res),
        "star_involution_error": float(invol),
        "star_support_leakage": float(leakage),
        "tomita_map_rank": int(map_rank),
        "tomita_polar_residual": float(polar_res),
        "tomita_conjugation_orthogonality_error": float(ortho),
        "tomita_conjugation_involution_error": float(involJ),
        "modular_operator_min_eigenvalue": float(min_delta),
        "modular_operator_max_eigenvalue": float(max_delta),
        "modular_inverse_relation_error": float(inverse_relation),
        "modular_spectrum_spread": float(max_delta / min_delta) if math.isfinite(min_delta) and math.isfinite(max_delta) and min_delta > 0 else math.inf,
        "modular_spectrum_nontrivial": int(math.isfinite(min_delta) and math.isfinite(max_delta) and min_delta > 0 and abs((max_delta / min_delta) - 1.0) > 1.0e-7),
        "modular_spectrum_positive_eigenvalues": " ".join(f"{x:.17g}" for x in positive_delta_sorted),
        "modular_spectrum_adjacent_ratios": " ".join(f"{x:.17g}" for x in adjacent_ratios),
        "modular_spectrum_ratio_count": int(len(adjacent_ratios)),
        "modular_spectrum_adjacent_ratio_min": float(min(adjacent_ratios)) if adjacent_ratios else math.nan,
        "modular_spectrum_adjacent_ratio_max": float(max(adjacent_ratios)) if adjacent_ratios else math.nan,
        "modular_spectrum_log_span": float(modular_log_span),
        "star_isometry_error_control": float(isom),
        "cnna_orientation_operator_norm": float(orientation_norm) if math.isfinite(orientation_norm) else math.nan,
        "cnna_orientation_operator_relative_norm": float(orientation_norm / orientation_scale) if math.isfinite(orientation_norm) else math.nan,
        "cnna_orientation_norm_condition": float(orientation_condition),
        "cnna_orientation_relation_scope": orientation_relation_scope,
        "orientation_vacuous_zero_current": int(orientation_vacuous),
        "cnna_orientation_left_action_residual": float(orientation_action_norm) if math.isfinite(orientation_action_norm) else math.nan,
        "tomita_conjuconditions_cnna_orientation_to_negative_residual": float(orientation_relation) if math.isfinite(orientation_relation) else math.nan,
        "tomita_cnna_orientation_relation_checked": int(orientation_checked),
        "cnna_orientation_operator_span_residual": float(orientation_span_res) if math.isfinite(orientation_span_res) else math.nan,
        "cnna_orientation_support_leakage": float(orientation_leakage) if math.isfinite(orientation_leakage) else math.nan,
    }


def state_pair_backreaction_algebras(
    model: EmptySetGrowthModel,
    spec: RegionSpec,
    left_state: str,
    right_state: str,
    tol: float,
    max_iter: int,
) -> Optional[Dict[str, AlgebraBasis]]:
    """Operator systems generated by B = A_left_state - A_right_state on the same cut."""
    left_res = directed_schur_response_from_model(model, left_state, spec.boundary, spec.interior, include_external_degrees=True, matrix_sign_relation="out_degree")
    right_res = directed_schur_response_from_model(model, right_state, spec.boundary, spec.interior, include_external_degrees=True, matrix_sign_relation="out_degree")
    if not left_res.ok or left_res.Lambda is None or not right_res.ok or right_res.Lambda is None:
        return None
    Q, _qnames = boundary_role_basis(model, spec)
    Lleft = Q.T @ left_res.Lambda @ Q
    Lright = Q.T @ right_res.Lambda @ Q
    _S_left, A_left = split_symmetric_skew(Lleft)
    _S_right, A_right = split_symmetric_skew(Lright)
    B = A_left - A_right
    d = int(B.shape[0])
    I = np.eye(d)
    P = [_unit_projector(k, d) for k in range(max(d, 3))]
    P_left = P[0] + P[1]
    P_right = P[0] + P[2]
    B_left = P_left @ B @ P_left
    B_right = P_right @ B @ P_right
    B_cross = P[1] @ B @ P[2] + P[2] @ B @ P[1]
    left = [I, P[0], P[1], B_left]
    right = [I, P[0], P[2], B_right]
    cross = [I, P[1], P[2], B_cross]
    pair = [I, P[0], P[1], P[2], B_left, B_right, B_cross]
    return {
        "__metadata__": {
            "backreaction_state_pair": f"{left_state}_minus_{right_state}",
            "backreaction_current_norm": float(fro(B)),
            "backreaction_current_left_norm": float(fro(B_left)),
            "backreaction_current_right_norm": float(fro(B_right)),
            "backreaction_current_cross_norm": float(fro(B_cross)),
            "identical_history_null_control": int(left_state == right_state),
        },
        "backreaction_current_left_birth_cone": algebra_closure("backreaction_current_left_birth_cone", left, tol=tol, max_iter=max_iter),
        "backreaction_current_right_birth_cone": algebra_closure("backreaction_current_right_birth_cone", right, tol=tol, max_iter=max_iter),
        "backreaction_current_sibling_cross": algebra_closure("backreaction_current_sibling_cross", cross, tol=tol, max_iter=max_iter),
        "backreaction_current_pair": algebra_closure("backreaction_current_pair", pair, tol=tol, max_iter=max_iter),
    }


def live_record_backreaction_algebras(model: EmptySetGrowthModel, spec: RegionSpec, tol: float, max_iter: int) -> Optional[Dict[str, AlgebraBasis]]:
    return state_pair_backreaction_algebras(model, spec, "live", "record", tol, max_iter)


def identical_history_backreaction_algebras(model: EmptySetGrowthModel, spec: RegionSpec, tol: float, max_iter: int) -> Optional[Dict[str, AlgebraBasis]]:
    return state_pair_backreaction_algebras(model, spec, "live", "live", tol, max_iter)


def _node_address_is_prefix(prefix_addr: Tuple[int, ...], addr: Tuple[int, ...]) -> bool:
    return len(addr) >= len(prefix_addr) and tuple(addr[: len(prefix_addr)]) == tuple(prefix_addr)


def _descendants_at_exact_level(model: EmptySetGrowthModel, root: int, level: int) -> List[int]:
    base = tuple(model.nodes[int(root)].address)
    return [
        int(n.nid) for n in model.nodes
        if int(n.level) == int(level) and _node_address_is_prefix(base, tuple(n.address))
    ]


def _lca_id_for_nodes(model: EmptySetGrowthModel, a: int, b: int) -> int:
    aa = tuple(model.nodes[int(a)].address)
    bb = tuple(model.nodes[int(b)].address)
    k = 0
    while k < min(len(aa), len(bb)) and aa[k] == bb[k]:
        k += 1
    return int(model.addr_to_id[aa[:k]])


def _cone_interior_to_frontier(model: EmptySetGrowthModel, root: int, frontier_level: int, boundary: Sequence[int]) -> List[int]:
    base = tuple(model.nodes[int(root)].address)
    bset = set(int(x) for x in boundary)
    return sorted(
        int(n.nid) for n in model.nodes
        if _node_address_is_prefix(base, tuple(n.address))
        and int(n.level) < int(frontier_level)
        and int(n.nid) not in bset
    )


def node_level_cut_for_operator_system(model: EmptySetGrowthModel, spec: RegionSpec, system_name: str) -> Tuple[List[int], List[int], dict]:
    """Actual node-level cut for a named finite operator system.

    The role-space checks compress everything to C_lca/B1_front/B2_front.  This
    helper instead returns real boundary and interior node lists for the same
    object so a Schur/DtN response can be recomputed independently.  It is still
    finite and cut-dependent; it does not assert a continuum causal complement.
    """
    frontier = int(region_frontier_level(model, spec))
    lca = int(spec.lca)
    left_front = [int(x) for x in spec.roles.get("B1_front", [])]
    right_front = [int(x) for x in spec.roles.get("B2_front", [])]
    lname = str(system_name)
    meta = {
        "node_level_cut_frontier_level": frontier,
        "node_level_cut_relations": "independent_finite_node_schur_cut",
    }

    if lname == "root_anchor_response":
        boundary = [lca]
        interior: List[int] = []
        cut_family = "root_anchor_single_boundary_node"
    elif lname in {"left_frontier_response"}:
        boundary = list(left_front)
        interior = []
        cut_family = "left_frontier_boundary_only"
    elif lname in {"right_frontier_response"}:
        boundary = list(right_front)
        interior = []
        cut_family = "right_frontier_boundary_only"
    elif "left_birth_cone" in lname:
        boundary = [lca] + list(left_front)
        interior = _cone_interior_to_frontier(model, int(spec.left_root), frontier, boundary)
        cut_family = "left_birth_cone_with_lca_anchor"
    elif "right_birth_cone" in lname:
        boundary = [lca] + list(right_front)
        interior = _cone_interior_to_frontier(model, int(spec.right_root), frontier, boundary)
        cut_family = "right_birth_cone_with_lca_anchor"
    elif lname in {"sibling_pair_response", "positive_carrier_pair_response", "directed_current_pair_response", "full_regional_response"}:
        boundary = [int(x) for x in spec.boundary]
        interior = [int(x) for x in spec.interior]
        cut_family = "sibling_pair_full_cut"
    else:
        boundary = [int(x) for x in spec.boundary]
        interior = [int(x) for x in spec.interior]
        cut_family = "fallback_full_cut"
    # Preserve order and remove accidental duplicates.
    boundary = list(dict.fromkeys(boundary))
    interior = [x for x in list(dict.fromkeys(interior)) if x not in set(boundary)]
    meta.update({
        "node_level_cut_family": cut_family,
        "node_level_boundary_count": int(len(boundary)),
        "node_level_interior_count": int(len(interior)),
    })
    return boundary, interior, meta


def node_level_schur_embedding_metrics(
    model: EmptySetGrowthModel,
    spec: RegionSpec,
    state: str,
    small_name: str,
    large_name: str,
    *,
    tol: float,
    cond_max: float = 1.0e12,
    matrix_sign_relation: str = "out_degree",
) -> dict:
    """Independent finite node-level Schur/DtN embedding measurement.

    It recomputes the subregion and superregion responses from their actual
    node cuts, then compares the subregion response with the node restriction of
    the superregion response.  This is the first finite condition with genuine failure
    potential for isotony beyond the three-coordinate role carrier.
    """
    sb, si, smeta = node_level_cut_for_operator_system(model, spec, small_name)
    lb, li, lmeta = node_level_cut_for_operator_system(model, spec, large_name)
    base = {
        "node_level_embedding_map_type": "boundary_node_identity_restriction_after_independent_schur",
        "node_level_independent_schur_embedding_checked": 0,
        "node_level_embedding_failure_potential": 0,
        "node_level_sub_boundary_count": int(len(sb)),
        "node_level_sub_interior_count": int(len(si)),
        "node_level_super_boundary_count": int(len(lb)),
        "node_level_super_interior_count": int(len(li)),
        "node_level_sub_cut_family": smeta.get("node_level_cut_family", ""),
        "node_level_super_cut_family": lmeta.get("node_level_cut_family", ""),
        "node_level_boundary_subset_ok": 0,
        "node_level_schur_embedding_relative_residual": math.nan,
        "node_level_schur_embedding_absolute_residual": math.nan,
        "node_level_schur_embedding_symmetric_relative_residual": math.nan,
        "node_level_schur_embedding_skew_relative_residual": math.nan,
        "node_level_sub_cond_KII": math.nan,
        "node_level_super_cond_KII": math.nan,
        "node_level_embedding_computed_status": "node_level_schur_embedding_unavailable",
    }
    if not sb or not lb:
        base["node_level_embedding_computed_status"] = "node_level_schur_embedding_empty_boundary"
        return base
    subset = all(int(x) in set(lb) for x in sb)
    base["node_level_boundary_subset_ok"] = int(subset)
    if not subset:
        base["node_level_embedding_computed_status"] = "node_level_boundary_not_subset"
        return base
    small = directed_schur_response_from_model(
        model,
        state,
        sb,
        si,
        cond_max=cond_max,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    large = directed_schur_response_from_model(
        model,
        state,
        lb,
        li,
        cond_max=cond_max,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    base["node_level_sub_cond_KII"] = float(small.cond_KII)
    base["node_level_super_cond_KII"] = float(large.cond_KII)
    if not small.ok or small.Lambda is None or not large.ok or large.Lambda is None:
        base["node_level_embedding_computed_status"] = f"node_level_response_unavailable:{small.error or large.error}"
        return base
    pos = {int(nid): i for i, nid in enumerate(lb)}
    idx = [pos[int(nid)] for nid in sb]
    restricted = large.Lambda[np.ix_(idx, idx)]
    delta = small.Lambda - restricted
    abs_res = float(fro(delta))
    rel_res = float(abs_res / max(fro(small.Lambda), EPS))
    Ss, As = split_symmetric_skew(small.Lambda)
    Sr, Ar = split_symmetric_skew(restricted)
    sym_res = float(fro(Ss - Sr) / max(fro(Ss), EPS))
    skew_res = float(fro(As - Ar) / max(fro(As), EPS)) if fro(As) > EPS else float(fro(As - Ar))
    base.update({
        "node_level_independent_schur_embedding_checked": 1,
        "node_level_embedding_failure_potential": int(len(lb) > len(sb) or len(li) != len(si)),
        "node_level_schur_embedding_relative_residual": rel_res,
        "node_level_schur_embedding_absolute_residual": abs_res,
        "node_level_schur_embedding_symmetric_relative_residual": sym_res,
        "node_level_schur_embedding_skew_relative_residual": skew_res,
    })
    if rel_res <= tol:
        computed_status = "node_level_schur_embedding_exact_finite_object"
    elif rel_res <= 1.0e-7:
        computed_status = "node_level_schur_embedding_approx_finite_object"
    else:
        computed_status = "node_level_schur_embedding_rank_bound_observed"
    base["node_level_embedding_computed_status"] = computed_status
    return base


def relative_common_ambient_schur_embedding_metrics(
    model: EmptySetGrowthModel,
    spec: RegionSpec,
    state: str,
    small_name: str,
    large_name: str,
    *,
    tol: float,
    cond_max: float = 1.0e12,
    matrix_sign_relation: str = "out_degree",
) -> dict:
    """Variant-3 node-level Schur embedding in one common finite ambient.

    This is the physically relevant isotony derived_quantity when local observables
    are read as relative Schur/DtN measurements.  The subregion response is not
    recomputed with its own outside world.  Instead, the superregion cut
    ``X = B_S ∪ I_S`` is fixed, the same open-grounded outer sign_relation is used
    for both systems, and the additional super-boundary ports ``B_S minus B_R`` are
    eliminated by a second Schur step.

    Therefore the comparison is:

        direct conditional response on B_R inside common X
        versus
        Schur reduction of Lambda(B_S) eliminating the extra super-boundary ports.

    The separate raw node-level measurement remains useful as an rank_bound map for
    differently conditioned responses.  This function measures Schur associativity
    under a shared finite ambient and is the correct Variant-3 trace.
    """
    sb, _si, smeta = node_level_cut_for_operator_system(model, spec, small_name)
    lb, li, lmeta = node_level_cut_for_operator_system(model, spec, large_name)
    base = {
        "relative_common_ambient_map_type": "schur_reduction_inside_fixed_superregion_ambient",
        "relative_common_ambient_relations": "same_superregion_selected_nodes_same_open_grounded_outer_sign_relation",
        "relative_common_ambient_checked": 0,
        "relative_common_ambient_failure_potential": 0,
        "relative_common_ambient_sub_boundary_count": int(len(sb)),
        "relative_common_ambient_super_boundary_count": int(len(lb)),
        "relative_common_ambient_super_interior_count": int(len(li)),
        "relative_common_ambient_extra_boundary_count": 0,
        "relative_common_ambient_sub_cut_family": smeta.get("node_level_cut_family", ""),
        "relative_common_ambient_super_cut_family": lmeta.get("node_level_cut_family", ""),
        "relative_common_ambient_boundary_subset_ok": 0,
        "relative_common_ambient_direct_cond_KII": math.nan,
        "relative_common_ambient_super_cond_KII": math.nan,
        "relative_common_ambient_reduction_cond_KII": math.nan,
        "relative_common_ambient_direct_solve_residual": math.nan,
        "relative_common_ambient_super_solve_residual": math.nan,
        "relative_common_ambient_reduction_solve_residual": math.nan,
        "relative_common_ambient_relative_residual": math.nan,
        "relative_common_ambient_absolute_residual": math.nan,
        "relative_common_ambient_symmetric_relative_residual": math.nan,
        "relative_common_ambient_skew_relative_residual": math.nan,
        "relative_common_ambient_naive_restriction_relative_residual": math.nan,
        "relative_common_ambient_computed_status": "relative_common_ambient_unavailable",
    }
    if not sb or not lb:
        base["relative_common_ambient_computed_status"] = "relative_common_ambient_empty_boundary"
        return base
    lb_set = set(int(x) for x in lb)
    subset = all(int(x) in lb_set for x in sb)
    base["relative_common_ambient_boundary_subset_ok"] = int(subset)
    if not subset:
        base["relative_common_ambient_computed_status"] = "relative_common_ambient_boundary_not_subset"
        return base

    selected = list(dict.fromkeys([int(x) for x in lb] + [int(x) for x in li]))
    pos = {nid: i for i, nid in enumerate(selected)}
    boundary_super = [pos[int(nid)] for nid in lb]
    interior_super = [pos[int(nid)] for nid in li]
    sub_boundary_in_selected = [pos[int(nid)] for nid in sb]
    extra_boundary_nodes = [int(nid) for nid in lb if int(nid) not in set(int(x) for x in sb)]
    extra_boundary_in_selected = [pos[int(nid)] for nid in extra_boundary_nodes]
    common_sub_interior = extra_boundary_in_selected + interior_super
    base["relative_common_ambient_extra_boundary_count"] = int(len(extra_boundary_nodes))
    base["relative_common_ambient_failure_potential"] = int(len(extra_boundary_nodes) > 0 or len(interior_super) > 0)

    K_common = directed_local_matrix(
        model,
        state,
        selected,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    direct = directed_schur_response(
        K_common,
        sub_boundary_in_selected,
        common_sub_interior,
        cond_max=cond_max,
        matrix_sign_relation=matrix_sign_relation,
        boundary_response_model="relative_common_ambient_direct_conditional",
    )
    super_res = directed_schur_response(
        K_common,
        boundary_super,
        interior_super,
        cond_max=cond_max,
        matrix_sign_relation=matrix_sign_relation,
        boundary_response_model="relative_common_ambient_super_response",
    )
    base["relative_common_ambient_direct_cond_KII"] = float(direct.cond_KII)
    base["relative_common_ambient_super_cond_KII"] = float(super_res.cond_KII)
    base["relative_common_ambient_direct_solve_residual"] = float(direct.solve_residual)
    base["relative_common_ambient_super_solve_residual"] = float(super_res.solve_residual)
    if not direct.ok or direct.Lambda is None or not super_res.ok or super_res.Lambda is None:
        base["relative_common_ambient_computed_status"] = f"relative_common_ambient_response_unavailable:{direct.error or super_res.error}"
        return base

    super_pos = {int(nid): i for i, nid in enumerate(lb)}
    sub_in_super = [super_pos[int(nid)] for nid in sb]
    extra_in_super = [super_pos[int(nid)] for nid in extra_boundary_nodes]
    reduced = directed_schur_response(
        super_res.Lambda,
        sub_in_super,
        extra_in_super,
        cond_max=cond_max,
        matrix_sign_relation=matrix_sign_relation,
        boundary_response_model="relative_common_ambient_schur_reduction_of_super_boundary",
    )
    base["relative_common_ambient_reduction_cond_KII"] = float(reduced.cond_KII)
    base["relative_common_ambient_reduction_solve_residual"] = float(reduced.solve_residual)
    if not reduced.ok or reduced.Lambda is None:
        base["relative_common_ambient_computed_status"] = f"relative_common_ambient_reduction_unavailable:{reduced.error}"
        return base

    naive = super_res.Lambda[np.ix_(sub_in_super, sub_in_super)]
    delta = direct.Lambda - reduced.Lambda
    naive_delta = direct.Lambda - naive
    abs_res = float(fro(delta))
    rel_res = float(abs_res / max(fro(direct.Lambda), EPS))
    naive_rel = float(fro(naive_delta) / max(fro(direct.Lambda), EPS))
    Sd, Ad = split_symmetric_skew(direct.Lambda)
    Sr, Ar = split_symmetric_skew(reduced.Lambda)
    sym_res = float(fro(Sd - Sr) / max(fro(Sd), EPS))
    skew_res = float(fro(Ad - Ar) / max(fro(Ad), EPS)) if fro(Ad) > EPS else float(fro(Ad - Ar))
    base.update({
        "relative_common_ambient_checked": 1,
        "relative_common_ambient_relative_residual": rel_res,
        "relative_common_ambient_absolute_residual": abs_res,
        "relative_common_ambient_symmetric_relative_residual": sym_res,
        "relative_common_ambient_skew_relative_residual": skew_res,
        "relative_common_ambient_naive_restriction_relative_residual": naive_rel,
    })
    if rel_res <= tol:
        computed_status = "relative_common_ambient_schur_isotony_exact_finite_object"
    elif rel_res <= 1.0e-7:
        computed_status = "relative_common_ambient_schur_isotony_approx_finite_object"
    else:
        computed_status = "relative_common_ambient_schur_isotony_rank_bound_observed"
    base["relative_common_ambient_computed_status"] = computed_status
    return base


def build_genealogical_corridor_regions(
    model: EmptySetGrowthModel,
    *,
    max_regions: int = 2,
    max_boundary: int = 600,
    max_interior: int = 900,
    max_frontier_level: Optional[int] = 6,
) -> List[RegionSpec]:
    """Build finite two-cone regions with a genealogical collar/corridor.

    Sibling cones have corridor 0.  Cousin or deeper separated cones have a
    positive corridor: the number of internal ancestor edges between each root
    and their LCA, summed over both sides.  This is the finite analogue of a
    collar separating local regions; it is the right finite place to measure
    locality/split trends rather than forcing touching sibling cones to commute.
    """
    specs: List[RegionSpec] = []
    seen_corridor: Dict[int, int] = {}
    cap = int(model.L if max_frontier_level is None else min(model.L, int(max_frontier_level)))
    root_level_max = max(1, min(int(model.L) - 1, cap, 3))
    for root_level in range(1, root_level_max + 1):
        roots = [int(n.nid) for n in model.nodes if int(n.level) == root_level and n.children]
        for i, left in enumerate(roots):
            for right in roots[i + 1:]:
                lca = _lca_id_for_nodes(model, left, right)
                lca_level = int(model.nodes[lca].level)
                if lca == left or lca == right:
                    continue
                corridor = int((root_level - lca_level - 1) + (root_level - lca_level - 1))
                if seen_corridor.get(corridor, 0) >= max(1, int(max_regions)):
                    continue
                frontier_min = root_level
                chosen = None
                frontier_cap = max(frontier_min, cap)
                for frontier in range(frontier_cap, frontier_min - 1, -1):
                    lf = _descendants_at_exact_level(model, left, frontier)
                    rf = _descendants_at_exact_level(model, right, frontier)
                    if not lf or not rf:
                        continue
                    boundary = [lca] + lf + rf
                    if len(boundary) > int(max_boundary):
                        continue
                    interior = _cone_interior_to_frontier(model, left, frontier, boundary) + _cone_interior_to_frontier(model, right, frontier, boundary)
                    interior = sorted(set(interior))
                    if len(interior) > int(max_interior):
                        continue
                    chosen = (frontier, boundary, interior, lf, rf)
                    break
                if chosen is None:
                    continue
                frontier, boundary, interior, lf, rf = chosen
                direct_siblings = int(model.nodes[left].parent == model.nodes[right].parent)
                roles = {
                    "C_lca": [lca],
                    "B1_front": list(lf),
                    "B2_front": list(rf),
                    "F1_root_front": list(boundary),
                    "F2_birth_order": list(lf) + list(rf),
                }
                specs.append(RegionSpec(
                    region_id=f"genealogical_corridor{corridor}_frontierL{frontier}_lca{lca}_roots{left}_{right}",
                    pair_type="genealogical_corridor_pair" if corridor > 0 else "touching_sibling_cone_pair",
                    lca=lca,
                    left_root=left,
                    right_root=right,
                    level=lca_level,
                    boundary=list(boundary),
                    interior=list(interior),
                    roles=roles,
                ))
                seen_corridor[corridor] = seen_corridor.get(corridor, 0) + 1
    specs.sort(key=lambda s: (int(genealogical_corridor_metadata(model, s)["genealogical_corridor_length"]), s.region_id))
    return specs


def genealogical_corridor_metadata(model: EmptySetGrowthModel, spec: RegionSpec) -> dict:
    lca_level = int(model.nodes[int(spec.lca)].level)
    left_level = int(model.nodes[int(spec.left_root)].level)
    right_level = int(model.nodes[int(spec.right_root)].level)
    corridor = int(max(0, left_level - lca_level - 1) + max(0, right_level - lca_level - 1))
    return {
        "genealogical_corridor_length": corridor,
        "left_region_root_level": left_level,
        "right_region_root_level": right_level,
        "shared_lca_level": lca_level,
        "direct_sibling_birth_coupling": int(model.nodes[int(spec.left_root)].parent == model.nodes[int(spec.right_root)].parent),
        "collar_condition_met": int(corridor >= 2),
        "genealogical_separation_relations": "touching_sibling" if corridor == 0 else "collared_cousin_or_deeper",
    }

__all__ = [
    '_unit_projector',
    '_sandwich',
    '_symmetric_coupling',
    '_skew_coupling',
    'operator_scale_metadata',
    '_nonzero_or_empty',
    'local_operator_generators',
    'role_coordinate_mapping',
    'role_support_indices',
    'role_support_projector',
    'independently_restricted_operator_algebra',
    'independent_embedding_metrics',
    'local_operator_algebras',
    'max_span_residual',
    'max_star_residual',
    'joined_algebra',
    'commutator_metrics',
    'state_commutator_metric',
    'matrix_rank_from_columns',
    'gns_support_data',
    'gns_cyclic_rank',
    'gns_separating_nullity',
    'nullspace',
    'commutant_algebra_basis',
    'basis_to_algebra',
    'star_map_matrix',
    'finite_tomita_star_metrics',
    'state_pair_backreaction_algebras',
    'live_record_backreaction_algebras',
    'identical_history_backreaction_algebras',
    '_node_address_is_prefix',
    '_descendants_at_exact_level',
    '_lca_id_for_nodes',
    '_cone_interior_to_frontier',
    'node_level_cut_for_operator_system',
    'node_level_schur_embedding_metrics',
    'relative_common_ambient_schur_embedding_metrics',
    'build_genealogical_corridor_regions',
    'genealogical_corridor_metadata'
]
