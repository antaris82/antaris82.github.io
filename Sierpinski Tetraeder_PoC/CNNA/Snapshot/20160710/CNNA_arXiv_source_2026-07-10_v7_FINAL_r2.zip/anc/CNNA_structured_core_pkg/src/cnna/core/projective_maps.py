from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core.math_utils import *
from cnna.core.emptyset_growth import *

def prefix(address: Tuple[int, ...], level: int) -> Tuple[int, ...]:
    if level <= 0:
        return tuple()
    return tuple(address[:level])


def terminal_carrier(model: EmptySetGrowthModel) -> Dict[Tuple[int, ...], float]:
    leaves = [n.address for n in model.nodes if n.level == model.L]
    return normalize_dict({a: 1.0 for a in leaves})


def terminal_state(model: EmptySetGrowthModel, state: str) -> Dict[Tuple[int, ...], float]:
    leaves = [n for n in model.nodes if n.level == model.L]
    leaf_ids = {n.nid for n in leaves}
    incident_abs: Dict[int, float] = {n.nid: 0.0 for n in leaves}
    if state == "record":
        edges = model.record_edges
    else:
        # For live and sym the positive state proxy uses the same absolute
        # incident response load.  This avoids constructing huge dense matrices.
        edges = model.live_edges
    for (i, j), w in edges.items():
        aw = abs(float(w))
        if i in leaf_ids:
            incident_abs[i] = incident_abs.get(i, 0.0) + aw
        if j in leaf_ids:
            incident_abs[j] = incident_abs.get(j, 0.0) + aw
    d: Dict[Tuple[int, ...], float] = {}
    for n in leaves:
        # Positive state layer: use current load + absolute incident response load,
        # but never signed current directly.
        d[n.address] = max(EPS, float(n.g) + 0.05 * incident_abs.get(n.nid, 0.0))
    return normalize_dict(d)


def push_forward(dist: Dict[Tuple[int, ...], float], target_level: int) -> Dict[Tuple[int, ...], float]:
    out: Dict[Tuple[int, ...], float] = {}
    for addr, val in dist.items():
        p = prefix(addr, target_level)
        out[p] = out.get(p, 0.0) + float(val)
    return normalize_dict(out)


def center_subset_prefix(level: int) -> Tuple[int, ...]:
    # Deterministic center probe: first born root-child cylinder.  It is not an external region;
    # it is the deterministic birth-order center probe used only for drift decomposition.
    if level <= 0:
        return tuple()
    return (0,)


def split_distribution(dist: Dict[Tuple[int, ...], float], center_pref: Tuple[int, ...]) -> Tuple[float, Dict[Tuple[int, ...], float], float, Dict[Tuple[int, ...], float]]:
    center: Dict[Tuple[int, ...], float] = {}
    noncenter: Dict[Tuple[int, ...], float] = {}
    for a, v in dist.items():
        if len(center_pref) == 0 or a[:len(center_pref)] == center_pref:
            center[a] = float(v)
        else:
            noncenter[a] = float(v)
    mc = float(sum(center.values()))
    mn = float(sum(noncenter.values()))
    cprof = {k: v / mc for k, v in center.items()} if mc > EPS else {}
    nprof = {k: v / mn for k, v in noncenter.items()} if mn > EPS else {}
    return mc, cprof, mn, nprof


def response_energy_distribution(Lambda_full: np.ndarray) -> np.ndarray:
    if Lambda_full.size == 0:
        return np.zeros(0, dtype=float)
    row = np.sum(Lambda_full * Lambda_full, axis=1)
    col = np.sum(Lambda_full * Lambda_full, axis=0)
    e = np.sqrt(np.maximum(row + col, 0.0))
    return normalize_distribution(e)
