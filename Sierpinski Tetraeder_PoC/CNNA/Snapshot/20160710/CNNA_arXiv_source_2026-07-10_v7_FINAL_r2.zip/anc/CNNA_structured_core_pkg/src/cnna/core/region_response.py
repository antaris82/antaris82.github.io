from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import fro
from cnna.core.operator_test_config import OperatorTestConfig
from cnna.core.schur_dtn import RegionSpec, boundary_role_basis
from cnna.core.directed_dtn import (
    build_coarse_frontier_sibling_regions,
    directed_schur_response_from_model,
    j_finite_object_from_SA,
    region_frontier_level,
    region_is_coarse_frontier,
    signed_role_basis_F1F2,
    split_symmetric_skew,
)


def sibling_pair_regions(model: EmptySetGrowthModel, config: OperatorTestConfig) -> List[RegionSpec]:
    return build_coarse_frontier_sibling_regions(
        model,
        max_regions=max(1, int(config.max_regions)),
        max_boundary=int(config.max_boundary),
        max_interior=int(config.max_interior),
        max_frontier_level=int(config.directed_frontier_cap),
    )


def region_size_meta(model: EmptySetGrowthModel, spec: RegionSpec) -> dict:
    frontier = region_frontier_level(model, spec)
    return {
        "region_id": spec.region_id,
        "region_family": spec.pair_type,
        "lca": int(spec.lca),
        "left_root": int(spec.left_root),
        "right_root": int(spec.right_root),
        "lca_level": int(model.nodes[spec.lca].level),
        "frontier_level": int(frontier),
        "terminal_level": int(model.L),
        "coarse_frontier_used": int(region_is_coarse_frontier(model, spec)),
        "boundary_count": int(len(spec.boundary)),
        "interior_count": int(len(spec.interior)),
    }


def positive_support_density_from_response(Lc: np.ndarray, tol: float = 1.0e-9) -> Tuple[np.ndarray, dict]:
    """Finite GNS density from positive spectral support, without epsilon flooring.

    The construction records support metadata explicitly and does not replace
    zero support by an artificial positive floor.
    """
    S = 0.5 * (Lc + Lc.T)
    meta = {
        "density_construction": "positive_spectral_support_no_epsilon_floor",
        "density_epsilon_floor": 0.0,
        "density_ambient_dim": int(S.shape[0]),
        "density_support_rank": 0,
        "density_positive_trace_before_normalization": 0.0,
        "density_negative_eigenvalue_count": 0,
        "density_clipped_negative_mass": 0.0,
        "density_min_raw_eigenvalue": math.nan,
        "density_max_raw_eigenvalue": math.nan,
        "density_computed_status": "density_spectral_failure",
    }
    try:
        vals, U = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.zeros_like(S), meta
    maxeig = float(np.max(vals)) if vals.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxeig))
    vals_pos = np.maximum(vals, 0.0)
    positive_trace = float(np.sum(vals_pos))
    meta.update({
        "density_support_rank": int(np.sum(vals > cutoff)),
        "density_positive_trace_before_normalization": positive_trace,
        "density_negative_eigenvalue_count": int(np.sum(vals < -cutoff)),
        "density_clipped_negative_mass": float(np.sum(np.maximum(-vals, 0.0))),
        "density_min_raw_eigenvalue": float(np.min(vals)) if vals.size else math.nan,
        "density_max_raw_eigenvalue": float(np.max(vals)) if vals.size else math.nan,
    })
    if positive_trace <= EPS:
        meta["density_computed_status"] = "zero_positive_response_support"
        return np.zeros_like(S), meta
    D = U @ np.diag(vals_pos) @ U.T
    D = 0.5 * (D + D.T)
    D = D / float(np.trace(D))
    if meta["density_support_rank"] < int(S.shape[0]):
        meta["density_computed_status"] = "singular_support_state"
    else:
        meta["density_computed_status"] = "full_support_state_without_epsilon_floor"
    return D, meta


@dataclass
class RegionalResponse:
    model: EmptySetGrowthModel
    spec: RegionSpec
    state: str
    Lambda_boundary: np.ndarray
    Lambda_role: np.ndarray
    symmetric_role: np.ndarray
    skew_role: np.ndarray
    role_basis: np.ndarray
    role_names: List[str]
    density: np.ndarray
    density_metadata: dict
    cond_KII: float
    solve_residual: float
    row_sum_residual: float
    boundary_response_model: str


def regional_response(model: EmptySetGrowthModel, spec: RegionSpec, state: str, *, cond_max: float = 1.0e12, matrix_sign_relation: str = "out_degree") -> Optional[RegionalResponse]:
    res = directed_schur_response_from_model(
        model,
        state,
        spec.boundary,
        spec.interior,
        cond_max=cond_max,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    if not res.ok or res.Lambda is None:
        return None
    Q, qnames = boundary_role_basis(model, spec)
    Lc = Q.T @ res.Lambda @ Q
    S, A = split_symmetric_skew(Lc)
    D, Dmeta = positive_support_density_from_response(Lc, tol=1.0e-9)
    return RegionalResponse(
        model=model,
        spec=spec,
        state=str(state),
        Lambda_boundary=res.Lambda,
        Lambda_role=Lc,
        symmetric_role=S,
        skew_role=A,
        role_basis=Q,
        role_names=list(qnames),
        density=D,
        density_metadata=Dmeta,
        cond_KII=float(res.cond_KII),
        solve_residual=float(res.solve_residual),
        row_sum_residual=float(res.row_sum_residual),
        boundary_response_model=res.boundary_response_model,
    )


def signed_orientation_metrics(model: EmptySetGrowthModel, spec: RegionSpec, tol: float, matrix_sign_relation: str = "out_degree") -> dict:
    live = directed_schur_response_from_model(model, "live", spec.boundary, spec.interior, include_external_degrees=True, matrix_sign_relation=matrix_sign_relation)
    record = directed_schur_response_from_model(model, "record", spec.boundary, spec.interior, include_external_degrees=True, matrix_sign_relation=matrix_sign_relation)
    if not live.ok or live.Lambda is None or not record.ok or record.Lambda is None:
        return {"signed_orientation_available": 0, "signed_orientation_error": live.error or record.error or "response_missing"}
    S_live, A_live = split_symmetric_skew(live.Lambda)
    _S_record, A_record = split_symmetric_skew(record.Lambda)
    B = A_live - A_record
    Qsig, qnames, qrank = signed_role_basis_F1F2(spec.boundary, spec)
    Splane = Qsig.T @ S_live @ Qsig
    Bplane = Qsig.T @ B @ Qsig
    J, info = j_finite_object_from_SA(Splane, Bplane, tol=tol)
    out = {
        "signed_orientation_available": int(info.get("available", 0)),
        "signed_orientation_basis_rank": int(qrank),
        "signed_orientation_basis": "|".join(qnames),
        "orientation_carrier_norm": float(fro(Splane)),
        "orientation_current_norm": float(fro(Bplane)),
        "skew_transpose_flip_error": float(fro(Bplane.T + Bplane) / max(fro(Bplane), EPS)),
    }
    for k, v in info.items():
        if isinstance(v, (int, float, str)):
            out[f"J_finite_object_{k}"] = v
    return out

__all__ = [
    'sibling_pair_regions',
    'region_size_meta',
    'positive_support_density_from_response',
    'RegionalResponse',
    'regional_response',
    'signed_orientation_metrics'
]
