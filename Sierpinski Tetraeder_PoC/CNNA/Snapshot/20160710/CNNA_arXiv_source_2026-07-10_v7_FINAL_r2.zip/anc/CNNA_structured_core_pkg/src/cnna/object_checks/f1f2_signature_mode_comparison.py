from __future__ import annotations

import math
from collections import defaultdict
from itertools import combinations
from typing import Dict, Iterable, List, Tuple

import numpy as np

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import region_size_meta
from .f1_f2_orientation_resolution import _response, _js, _meta_key_without_mode


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(y for y in (_finite(x) for x in xs) if math.isfinite(y))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _signature(P: np.ndarray, tol: float) -> Tuple[np.ndarray, float, int]:
    norm = float(fro(P)) if P.size else 0.0
    condition = max(float(tol), float(tol) * max(1.0, norm))
    if norm <= condition:
        return np.zeros_like(P), norm, 1
    return np.array(P, dtype=float) / norm, norm, 0


def _signature_gap(A: np.ndarray, B: np.ndarray) -> float:
    if A.shape != B.shape or A.size == 0:
        return math.inf
    return float(fro(A - B))


def _cosine(A: np.ndarray, B: np.ndarray) -> float:
    if A.shape != B.shape or A.size == 0:
        return math.nan
    a = A.reshape(-1)
    b = B.reshape(-1)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float((a @ b) / den) if den > 0.0 else math.nan


def _strength_range(vals: Iterable[float], tol: float) -> Tuple[float, float, float]:
    xs = [float(x) for x in vals if math.isfinite(float(x))]
    if not xs:
        return math.nan, math.nan, math.nan
    lo = min(xs)
    hi = max(xs)
    rel = float((hi - lo) / max(hi, float(tol)))
    return lo, hi, rel


def _track_key_from_meta(b: int, L: int, meta: dict) -> Tuple[object, ...]:
    return _meta_key_without_mode(b, L, meta)


def _pairwise_state_stats(items: List[dict], state: str, tol: float) -> dict:
    sigs: Dict[str, np.ndarray] = {}
    amps: Dict[str, float] = {}
    densities: Dict[str, np.ndarray] = {}
    zeros: Dict[str, int] = {}
    for item in items:
        mode = str(item["mode"])
        resp = item[state]
        sig, amp, zero = _signature(resp["profile"], tol)
        sigs[mode] = sig
        amps[mode] = amp
        densities[mode] = resp["density"]
        zeros[mode] = int(zero)
    pair_rows: List[dict] = []
    for a, b in combinations(sorted(sigs), 2):
        if sigs[a].shape != sigs[b].shape or densities[a].shape != densities[b].shape:
            gap = math.inf
            cos = math.nan
            js = math.inf
        else:
            gap = _signature_gap(sigs[a], sigs[b])
            cos = _cosine(sigs[a], sigs[b])
            js = _js(densities[a], densities[b], tol)
        denom = max(amps[a], amps[b], tol)
        strength_rel_gap = float(abs(amps[a] - amps[b]) / denom)
        pair_rows.append({
            "mode_left": a,
            "mode_right": b,
            "signature_gap": gap,
            "signature_alignment_cosine": cos,
            "density_JS_between_modes": js,
            "strength_left": amps[a],
            "strength_right": amps[b],
            "strength_relative_gap": strength_rel_gap,
            "left_zero_signature": zeros[a],
            "right_zero_signature": zeros[b],
        })
    lo, hi, rel = _strength_range(amps.values(), tol)
    finite_gaps = [r["signature_gap"] for r in pair_rows if math.isfinite(float(r["signature_gap"]))]
    finite_cos = [r["signature_alignment_cosine"] for r in pair_rows if math.isfinite(float(r["signature_alignment_cosine"]))]
    finite_js = [r["density_JS_between_modes"] for r in pair_rows if math.isfinite(float(r["density_JS_between_modes"]))]
    finite_strength = [r["strength_relative_gap"] for r in pair_rows if math.isfinite(float(r["strength_relative_gap"]))]
    return {
        "pair_rows": pair_rows,
        "mode_count": len(sigs),
        "modes": "|".join(sorted(sigs)),
        "zero_signature_count": sum(int(v) for v in zeros.values()),
        "max_signature_gap": max(finite_gaps) if finite_gaps else math.inf,
        "median_signature_gap": _median(finite_gaps),
        "min_signature_alignment_cosine": min(finite_cos) if finite_cos else math.nan,
        "median_signature_alignment_cosine": _median(finite_cos),
        "max_density_JS_between_modes": max(finite_js) if finite_js else math.inf,
        "median_density_JS_between_modes": _median(finite_js),
        "max_strength_relative_gap": max(finite_strength) if finite_strength else math.nan,
        "median_strength_relative_gap": _median(finite_strength),
        "strength_min": lo,
        "strength_max": hi,
        "strength_relative_range": rel,
    }


def f1f2_signature_mode_comparison_rows(config: OperatorTestConfig) -> List[dict]:
    """Test whether the normalized F1/F2 birth-order signature is mode mode_stable.

    The admissible modes are the finite response-weighting regimes already used
    in the package: linear/log/saturating.  This surface deliberately separates:

    * normalized F1/F2 skew profile direction  -> birth-order signature;
    * Frobenius norm of that profile           -> response strength;
    * positive-support density JS              -> carrier/support response.

    A residual_le_tolerance row means the signature is stable under mode changes while strength
    may scale.  It does not statement a continuum property.
    """
    records: List[dict] = []
    groups: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []
    tol = float(config.algebra_tol)
    # This is an measurement tolerance for normalized finite profiles, not a proof
    # tolerance for equality of raw floating-point matrices.  It is deliberately
    # recorded in every row.
    signature_stability_tol = max(1.0e-2, 1.0e6 * tol)
    strength_scaling_tol = max(1.0e-3, 1.0e5 * tol)

    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _response(model, spec, "live", tol=tol)
            record = _response(model, spec, "record", tol=tol)
            if not live.get("ok") or not record.get("ok"):
                rows.append({
                    "mode_mode_stable_surface": "F1F2_normalized_birth_order_signature_property_comparison",
                    "branching": int(b), "level": int(L), "mode": str(mode), **meta,
                    "mode_mode_stable_signature_computed_status": "mode_mode_stable_signature_response_unavailable",
                    "mode_mode_stable_signature_error": str(live.get("error") or record.get("error") or "unknown"),
                })
                continue
            rec = {"b": int(b), "L": int(L), "mode": str(mode), "meta": meta, "live": live, "record": record}
            records.append(rec)
            groups[_track_key_from_meta(int(b), int(L), meta)].append(rec)

    for key, items0 in sorted(groups.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        # Keep only modes whose refined F1/F2 profile/density shapes are common.
        shape_groups: Dict[Tuple[Tuple[int, ...], Tuple[int, ...]], List[dict]] = defaultdict(list)
        for item in items0:
            shape_groups[(tuple(item["live"]["profile"].shape), tuple(item["live"]["density"].shape))].append(item)
        for _shape, items in shape_groups.items():
            if len(items) < 2:
                item = items[0]
                rows.append({
                    "mode_mode_stable_surface": "F1F2_normalized_birth_order_signature_property_comparison",
                    "branching": int(item["b"]), "level": int(item["L"]), **item["meta"],
                    "admissible_mode_count": int(len(items)),
                    "admissible_modes": str(item["mode"]),
                    "mode_mode_stable_signature_computed_status": "mode_mode_stable_signature_requires_at_least_two_modes_control",
                })
                continue
            item0 = items[0]
            live_stats = _pairwise_state_stats(items, "live", tol)
            record_stats = _pairwise_state_stats(items, "record", tol)

            # Joint condition: live and record signatures are stable.  Strength is
            # allowed to vary; if it does not vary, we still report signature
            # invariance but not strength-scaling evidence.
            live_sig_stable = int(live_stats["max_signature_gap"] <= signature_stability_tol and (not math.isfinite(live_stats["min_signature_alignment_cosine"]) or live_stats["min_signature_alignment_cosine"] >= 1.0 - signature_stability_tol))
            record_sig_stable = int(record_stats["max_signature_gap"] <= signature_stability_tol and (not math.isfinite(record_stats["min_signature_alignment_cosine"]) or record_stats["min_signature_alignment_cosine"] >= 1.0 - signature_stability_tol))
            live_strength_scales = int(math.isfinite(live_stats["strength_relative_range"]) and live_stats["strength_relative_range"] > strength_scaling_tol)
            record_strength_scales = int(math.isfinite(record_stats["strength_relative_range"]) and record_stats["strength_relative_range"] > strength_scaling_tol)
            live_signature_drift_subdominant = int(math.isfinite(live_stats["max_signature_gap"]) and math.isfinite(live_stats["strength_relative_range"]) and live_stats["max_signature_gap"] < live_stats["strength_relative_range"])
            record_signature_drift_subdominant = int(math.isfinite(record_stats["max_signature_gap"]) and math.isfinite(record_stats["strength_relative_range"]) and record_stats["max_signature_gap"] < record_stats["strength_relative_range"])
            zero_control = int(live_stats["zero_signature_count"] > 0 or record_stats["zero_signature_count"] > 0)

            if zero_control:
                computed_status = "mode_mode_stable_signature_vacuous_zero_profile_control"
            elif live_sig_stable and record_sig_stable and (live_strength_scales or record_strength_scales):
                computed_status = "strict_mode_mode_stable_F1F2_signature_strength_scaling_finite_object"
            elif live_sig_stable and record_sig_stable:
                computed_status = "strict_mode_mode_stable_F1F2_signature_without_strength_scaling_control"
            elif live_signature_drift_subdominant and record_signature_drift_subdominant and (live_strength_scales or record_strength_scales):
                computed_status = "F1F2_signature_drift_subdominant_to_mode_strength_scaling_control"
            elif (live_strength_scales or record_strength_scales) and not (live_sig_stable and record_sig_stable):
                computed_status = "mode_changes_F1F2_signature_not_only_strength_observed"
            else:
                computed_status = "mode_mode_stable_signature_unresolved_control"

            base = {
                "mode_mode_stable_surface": "F1F2_normalized_birth_order_signature_property_comparison",
                "branching": int(item0["b"]),
                "level": int(item0["L"]),
                **item0["meta"],
                **{k: v for k, v in item0["live"].items() if k.startswith("F1F2_resolution_")},
                "admissible_mode_count": int(live_stats["mode_count"]),
                "admissible_modes": live_stats["modes"],
                "mode_signature_stability_tol": float(signature_stability_tol),
                "mode_strength_scaling_tol": float(strength_scaling_tol),
                "live_max_signature_gap_across_modes": float(live_stats["max_signature_gap"]),
                "live_median_signature_gap_across_modes": float(live_stats["median_signature_gap"]),
                "live_min_signature_alignment_cosine_across_modes": float(live_stats["min_signature_alignment_cosine"]),
                "live_max_density_JS_across_modes": float(live_stats["max_density_JS_between_modes"]),
                "live_strength_min_across_modes": float(live_stats["strength_min"]),
                "live_strength_max_across_modes": float(live_stats["strength_max"]),
                "live_strength_relative_range_across_modes": float(live_stats["strength_relative_range"]),
                "record_max_signature_gap_across_modes": float(record_stats["max_signature_gap"]),
                "record_median_signature_gap_across_modes": float(record_stats["median_signature_gap"]),
                "record_min_signature_alignment_cosine_across_modes": float(record_stats["min_signature_alignment_cosine"]),
                "record_max_density_JS_across_modes": float(record_stats["max_density_JS_between_modes"]),
                "record_strength_min_across_modes": float(record_stats["strength_min"]),
                "record_strength_max_across_modes": float(record_stats["strength_max"]),
                "record_strength_relative_range_across_modes": float(record_stats["strength_relative_range"]),
                "live_signature_mode_mode_stable_finite_object": live_sig_stable,
                "record_signature_mode_mode_stable_finite_object": record_sig_stable,
                "live_strength_scales_with_mode_finite_object": live_strength_scales,
                "record_strength_scales_with_mode_finite_object": record_strength_scales,
                "live_signature_drift_subdominant_to_strength_scaling": live_signature_drift_subdominant,
                "record_signature_drift_subdominant_to_strength_scaling": record_signature_drift_subdominant,
                "mode_mode_stable_signature_zero_profile_control": zero_control,
                "mode_mode_stable_signature_relations": "normalized_F1F2_skew_profile_is_birth_order_signature_profile_norm_is_response_strength",
                "mode_mode_stable_signature_computed_status": computed_status,
            }
            rows.append(base)
    return rows


def mode_mode_stable_f1f2_signature_summary_rows(rows: List[dict]) -> List[dict]:
    out: List[dict] = []
    groups: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        groups[(r.get("branching"), r.get("level"), r.get("region_family", "all"))].append(r)
    for (b, L, fam), xs in sorted(groups.items(), key=lambda kv: (int(kv[0][0]), int(kv[0][1]), str(kv[0][2]))):
        total = len(xs)
        cand = sum(1 for r in xs if str(r.get("mode_mode_stable_signature_computed_status")) == "strict_mode_mode_stable_F1F2_signature_strength_scaling_finite_object")
        stable_no_strength = sum(1 for r in xs if str(r.get("mode_mode_stable_signature_computed_status")) == "strict_mode_mode_stable_F1F2_signature_without_strength_scaling_control")
        subdominant = sum(1 for r in xs if str(r.get("mode_mode_stable_signature_computed_status")) == "F1F2_signature_drift_subdominant_to_mode_strength_scaling_control")
        changed = sum(1 for r in xs if str(r.get("mode_mode_stable_signature_computed_status")) == "mode_changes_F1F2_signature_not_only_strength_observed")
        zero = sum(1 for r in xs if str(r.get("mode_mode_stable_signature_computed_status")) == "mode_mode_stable_signature_vacuous_zero_profile_control")
        if total and cand / total >= 0.75:
            computed_status = "strict_mode_mode_stable_F1F2_signature_property_comparison_supported_summary"
        elif total and (cand + stable_no_strength) / total >= 0.75 and changed == 0:
            computed_status = "strict_mode_mode_stable_F1F2_signature_supported_but_strength_scaling_weak_summary"
        elif total and subdominant / total >= 0.75:
            computed_status = "F1F2_signature_drift_subdominant_to_strength_scaling_summary"
        elif total and changed / total >= 0.25:
            computed_status = "mode_mode_stable_F1F2_signature_obstructed_summary"
        elif total and zero / total >= 0.25:
            computed_status = "mode_mode_stable_F1F2_signature_zero_profile_control_summary"
        else:
            computed_status = "mode_mode_stable_F1F2_signature_partial_or_unresolved_summary"
        out.append({
            "summary_surface": "mode_mode_stable_F1F2_signature_comparison_summary",
            "branching": int(b),
            "level": int(L),
            "region_family": str(fam),
            "row_count": int(total),
            "mode_mode_stable_strength_scaling_finite_object_count": int(cand),
            "mode_mode_stable_without_strength_scaling_control_count": int(stable_no_strength),
            "signature_drift_subdominant_to_strength_scaling_count": int(subdominant),
            "mode_changes_signature_not_only_strength_count": int(changed),
            "zero_profile_control_count": int(zero),
            "median_live_max_signature_gap": _median(r.get("live_max_signature_gap_across_modes") for r in xs),
            "median_record_max_signature_gap": _median(r.get("record_max_signature_gap_across_modes") for r in xs),
            "median_live_strength_relative_range": _median(r.get("live_strength_relative_range_across_modes") for r in xs),
            "median_record_strength_relative_range": _median(r.get("record_strength_relative_range_across_modes") for r in xs),
            "summary_computed_status": computed_status,
        })
    return out


def f1f2_signature_mode_comparison_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("mode_mode_stable_signature_computed_status", "unknown")) for r in rows})
    total = len(rows)
    cand = sum(1 for r in rows if str(r.get("mode_mode_stable_signature_computed_status")) == "strict_mode_mode_stable_F1F2_signature_strength_scaling_finite_object")
    stable = sum(1 for r in rows if str(r.get("mode_mode_stable_signature_computed_status")) == "strict_mode_mode_stable_F1F2_signature_without_strength_scaling_control")
    subdominant = sum(1 for r in rows if str(r.get("mode_mode_stable_signature_computed_status")) == "F1F2_signature_drift_subdominant_to_mode_strength_scaling_control")
    changed = sum(1 for r in rows if str(r.get("mode_mode_stable_signature_computed_status")) == "mode_changes_F1F2_signature_not_only_strength_observed")
    return (
        "# Mode-mode_stable F1/F2 signature property-comparison\n\n"
        "This surface tests whether admissible response modes preserve the normalized F1/F2 birth-order signature while changing only the response strength.  The tested modes are the finite weighting regimes already present in the package: linear, log, and saturating.  The surface is finite and real; it does not introduce complex structure, stochasticity, an external metric, or an epsilon state floor.\n\n"
        f"Rows: {total}.\n\n"
        f"Strict mode-mode_stable signature with strength-scaling finite_objects: {cand}/{total}.\n\n"
        f"Strict mode-mode_stable signature without visible strength scaling controls: {stable}/{total}.\n\n"
        f"Rows where signature drift is subdominant to strength scaling: {subdominant}/{total}.\n\n"
        f"Rows where mode changes the F1/F2 signature beyond the subdominant-strength condition: {changed}/{total}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )


def mode_mode_stable_f1f2_signature_summary_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("summary_computed_status", "unknown")) for r in rows})
    return (
        "# Mode-mode_stable F1/F2 signature summary\n\n"
        "This summary aggregates the signature-mode comparison by branching, level, and region family.  A supported row means that the normalized F1/F2 signature is stable under admissible mode changes in most tracks, while response strength is allowed to scale.\n\n"
        f"Summary rows: {len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
