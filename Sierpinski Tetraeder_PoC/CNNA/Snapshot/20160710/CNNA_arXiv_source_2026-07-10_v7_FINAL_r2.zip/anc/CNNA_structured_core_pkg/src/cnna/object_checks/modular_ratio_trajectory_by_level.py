from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from .modular_spectrum_trajectory import modular_spectrum_trajectory_rows
from cnna.core.operator_test_config import OperatorTestConfig
from .observable_state_rows import state_relations_fields


def _f(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: List[float]) -> float:
    ys = sorted(x for x in xs if math.isfinite(x))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    # Region ids can change with the selected terminal frontier.  4 asks for
    # a finite scaling derived_quantity, so the reference track aggregates over the
    # sampled regions at fixed b/mode/state/sign_relation.
    return (row.get("branching"), row.get("mode"), row.get("state"), row.get("matrix_sign_relation"))


def _lambda_trend(lambda_by_l: Dict[int, float]) -> str:
    levels = sorted(lambda_by_l)
    vals = [lambda_by_l[L] for L in levels if math.isfinite(lambda_by_l[L])]
    if len(vals) < 2:
        return "lambda_proxy_insufficient_level_trajectory"
    if max(vals) - min(vals) <= 1.0e-8 * max(1.0, max(abs(x) for x in vals)):
        return "lambda_proxy_level_stable_finite_object"
    if vals[-1] > vals[0]:
        return "lambda_proxy_increases_over_available_levels"
    if vals[-1] < vals[0]:
        return "lambda_proxy_decreases_over_available_levels"
    return "lambda_proxy_no_clear_level_trend"


def _ratio_cloud_computed_status(ratio_min: float, ratio_max: float, ratio_count: int) -> str:
    if ratio_count <= 0 or not math.isfinite(ratio_min) or not math.isfinite(ratio_max):
        return "ratio_cloud_unavailable"
    if ratio_max <= 0:
        return "ratio_cloud_unavailable"
    spread = ratio_max / max(ratio_min, 1.0e-300)
    if spread <= 1.0 + 1.0e-6:
        return "single_ratio_lambda_band_finite_object"
    if spread <= 10.0:
        return "finite_ratio_band_limes_derived_quantity"
    return "broad_ratio_cloud_limes_derived_quantity"


def modular_ratio_trajectory_by_level_rows(config: OperatorTestConfig) -> List[dict]:
    base_rows = modular_spectrum_trajectory_rows(config)
    by_track_level: Dict[Tuple[object, ...], Dict[int, List[dict]]] = defaultdict(lambda: defaultdict(list))
    for row in base_rows:
        if "modular_spectrum_spread" not in row:
            continue
        by_track_level[_track_key(row)][int(row.get("level", -1))].append(row)

    rows: List[dict] = []
    for key, by_level in sorted(by_track_level.items(), key=lambda kv: str(kv[0])):
        levels = sorted(L for L in by_level if L >= 0)
        spread_by_l: Dict[int, float] = {}
        log_by_l: Dict[int, float] = {}
        lambda_by_l: Dict[int, float] = {}
        ratio_min_by_l: Dict[int, float] = {}
        ratio_max_by_l: Dict[int, float] = {}
        ratio_count_by_l: Dict[int, int] = {}
        support_singular_by_l: Dict[int, int] = {}
        support_rows_by_l: Dict[int, int] = {}
        for L in levels:
            rs = by_level[L]
            spread_by_l[L] = _median([_f(r.get("modular_spectrum_spread")) for r in rs])
            log_by_l[L] = _median([_f(r.get("modular_spectrum_log_span")) for r in rs])
            lambda_by_l[L] = _median([_f(r.get("finite_powers_lambda_proxy")) for r in rs])
            ratio_min_by_l[L] = _median([_f(r.get("modular_spectrum_adjacent_ratio_min")) for r in rs])
            ratio_max_by_l[L] = _median([_f(r.get("modular_spectrum_adjacent_ratio_max")) for r in rs])
            ratio_count_by_l[L] = int(sum(int(r.get("modular_spectrum_ratio_count", 0) or 0) for r in rs))
            support_rows_by_l[L] = int(len(rs))
            support_singular_by_l[L] = int(sum(1 for r in rs if str(r.get("density_computed_status", "")) == "singular_support_state"))
        if len(levels) >= 2:
            first_L, last_L = levels[0], levels[-1]
            first_spread = spread_by_l[first_L]
            last_spread = spread_by_l[last_L]
            if math.isfinite(first_spread) and math.isfinite(last_spread) and first_spread > 0 and last_spread > 0:
                spread_ratio = float(last_spread / first_spread)
                spread_slope = float((math.log(last_spread) - math.log(first_spread)) / max(1, last_L - first_L))
            else:
                spread_ratio = math.nan
                spread_slope = math.nan
            if math.isfinite(spread_ratio) and spread_ratio > 1.0 + 1.0e-8:
                spread_trend = "modular_spread_increases_with_level"
            elif math.isfinite(spread_ratio) and spread_ratio < 1.0 - 1.0e-8:
                spread_trend = "modular_spread_decreases_with_level"
            elif math.isfinite(spread_ratio):
                spread_trend = "modular_spread_level_stable_finite_object"
            else:
                spread_trend = "modular_spread_trend_unavailable"
        else:
            first_L = last_L = levels[0] if levels else -1
            spread_ratio = math.nan
            spread_slope = math.nan
            spread_trend = "modular_spread_insufficient_level_trajectory"
        lam_trend = _lambda_trend(lambda_by_l)
        for L in levels:
            rmin = ratio_min_by_l.get(L, math.nan)
            rmax = ratio_max_by_l.get(L, math.nan)
            rcount = ratio_count_by_l.get(L, 0)
            rows.append({
                "branching": key[0],
                "mode": key[1],
                "state": key[2],
                **state_relations_fields(str(key[2])),
                "modular_ratio_physics_scope": (
                    "reference_live_modular_limes_derived_quantity" if str(key[2]) == "live" else
                    "record_history_modular_comparison_control" if str(key[2]) == "record" else
                    "sym_null_modular_control"
                ),
                "matrix_sign_relation": key[3],
                "level": L,
                "level_track_min": first_L,
                "level_track_max": last_L,
                "level_track_count": int(len(levels)),
                "median_modular_spectrum_spread": spread_by_l.get(L, math.nan),
                "median_modular_log_span": log_by_l.get(L, math.nan),
                "median_finite_powers_lambda_proxy": lambda_by_l.get(L, math.nan),
                "median_adjacent_ratio_min": rmin,
                "median_adjacent_ratio_max": rmax,
                "total_adjacent_ratio_count": rcount,
                "ratio_cloud_level_computed_status": _ratio_cloud_computed_status(rmin, rmax, rcount),
                "singular_support_rows_at_level": support_singular_by_l.get(L, 0),
                "total_rows_at_level": support_rows_by_l.get(L, 0),
                "singular_support_fraction_at_level": float(support_singular_by_l.get(L, 0) / max(1, support_rows_by_l.get(L, 0))),
                "modular_spread_ratio_last_over_first": spread_ratio,
                "modular_spread_log_slope_proxy": spread_slope,
                "modular_spread_level_trend": spread_trend,
                "finite_powers_lambda_proxy_level_trend": lam_trend,
                "modular_ratio_trajectory_computed_status": (
                    "modular_ratio_limes_derived_quantity_nontrivial" if rcount > 0 and spread_trend != "modular_spread_insufficient_level_trajectory" else "modular_ratio_limes_derived_quantity_insufficient"
                ),
            })
    return rows


def modular_ratio_trajectory_by_level_report(rows: List[dict]) -> str:
    trends = sorted({str(r.get("modular_spread_level_trend", "unknown")) for r in rows})
    ratios = sorted({str(r.get("ratio_cloud_level_computed_status", "unknown")) for r in rows})
    lambdas = sorted({str(r.get("finite_powers_lambda_proxy_level_trend", "unknown")) for r in rows})
    return (
        "# Modular ratio trajectory by level\n\n"
        "Aggregates finite Tomita modular eigenvalue ratios over terminal level L.  "
        "This is a Powers/Araki-Woods-style limes derived_quantity only: finite rows remain Type-I matrix data and do not prove a Type-III factor.\n\n"
        "Spread trends: `" + "`, `".join(trends) + "`.\n\n"
        "Ratio-cloud computed_status_rows: `" + "`, `".join(ratios) + "`.\n\n"
        "Lambda-proxy trends: `" + "`, `".join(lambdas) + "`.\n"
    )
