from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.directed_dtn import directed_schur_response_from_model, split_symmetric_skew
from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.entropy_quantities import jensen_shannon_divergence_no_epsilon
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    positive_support_density_from_response,
    region_size_meta,
)


def _unique(xs: Sequence[int]) -> List[int]:
    return list(dict.fromkeys(int(x) for x in xs))


def _path_from_lca_to_node(model, lca: int, nid: int) -> List[int]:
    path: List[int] = []
    cur = int(nid)
    while cur != int(lca) and cur is not None:
        path.append(cur)
        parent = model.nodes[cur].parent
        if parent is None:
            break
        cur = int(parent)
    path.reverse()
    return path


def _chunks_by_birth_time(model, xs: Sequence[int], k: int) -> List[List[int]]:
    ys = sorted(_unique(xs), key=lambda nid: (int(model.nodes[nid].birth_time), tuple(model.nodes[nid].address), nid))
    if not ys:
        return []
    k = max(1, min(int(k), len(ys)))
    out: List[List[int]] = []
    for i in range(k):
        a = (len(ys) * i) // k
        b = (len(ys) * (i + 1)) // k
        if a < b:
            out.append(ys[a:b])
    return out


def _indicator(boundary: Sequence[int], ids: Sequence[int]) -> np.ndarray:
    pos = {int(nid): i for i, nid in enumerate(boundary)}
    v = np.zeros(len(boundary), dtype=float)
    for nid in ids:
        j = pos.get(int(nid))
        if j is not None:
            v[j] = 1.0
    n = float(np.linalg.norm(v))
    return v / n if n > EPS else v


def _gram_schmidt(raw: Sequence[Tuple[str, str, np.ndarray]]) -> Tuple[np.ndarray, List[str], List[str]]:
    basis: List[np.ndarray] = []
    names: List[str] = []
    kinds: List[str] = []
    for kind, name, v0 in raw:
        u = np.array(v0, dtype=float).copy()
        for q in basis:
            u -= float(q @ u) * q
        n = float(np.linalg.norm(u))
        if n > 1.0e-10:
            basis.append(u / n)
            names.append(str(name))
            kinds.append(str(kind))
    if not basis:
        return np.zeros((0, 0), dtype=float), [], []
    return np.column_stack(basis), names, kinds


def _paired_shells(model, spec, *, frontier_shell_count: int = 3) -> Tuple[List[Tuple[str, List[int], List[int]]], List[int]]:
    """Derive paired longitudinal/transversal shells purely from provenance.

    Each pair is left/right matched.  F1 modes use the shell average relative to
    the LCA; F2 modes use the left-minus-right birth-order contrast.  The shells
    are not chosen from metric data: they are ancestor path depth and frontier
    birth-order chunks inherited from the deterministic growth record.
    """
    shells: List[Tuple[str, List[int], List[int]]] = []
    extra_boundary: List[int] = []
    left_path = _path_from_lca_to_node(model, int(spec.lca), int(spec.left_root))
    right_path = _path_from_lca_to_node(model, int(spec.lca), int(spec.right_root))
    for i, (l, r) in enumerate(zip(left_path, right_path), start=1):
        shells.append((f"ancestor_path_shell_{i}", [int(l)], [int(r)]))
        extra_boundary.extend([int(l), int(r)])
    lf = _unique(spec.roles.get("B1_front", []))
    rf = _unique(spec.roles.get("B2_front", []))
    lchunks = _chunks_by_birth_time(model, lf, frontier_shell_count)
    rchunks = _chunks_by_birth_time(model, rf, frontier_shell_count)
    for i, (lc, rc) in enumerate(zip(lchunks, rchunks), start=1):
        shells.append((f"frontier_birth_order_shell_{i}_of_{min(len(lchunks), len(rchunks))}", list(lc), list(rc)))
        extra_boundary.extend(list(lc) + list(rc))
    return shells, _unique(extra_boundary)


def _multishell_f1f2_basis(model, spec, *, frontier_shell_count: int = 3) -> Tuple[List[int], List[int], np.ndarray, List[str], List[str], dict]:
    shells, shell_nodes = _paired_shells(model, spec, frontier_shell_count=frontier_shell_count)
    boundary = _unique([int(spec.lca)] + shell_nodes)
    # Move newly exposed ancestor/path shell ports from interior to boundary.
    boundary_set = set(boundary)
    interior = [int(x) for x in spec.interior if int(x) not in boundary_set]
    C = _indicator(boundary, [int(spec.lca)])
    raw: List[Tuple[str, str, np.ndarray]] = []
    raw_counts: List[str] = []
    for shell_name, left_ids, right_ids in shells:
        L = _indicator(boundary, left_ids)
        R = _indicator(boundary, right_ids)
        if float(np.linalg.norm(L)) <= EPS or float(np.linalg.norm(R)) <= EPS:
            continue
        avg = 0.5 * (L + R)
        f1 = C - avg
        f2 = L - R
        raw.append(("F1", f"F1_longitudinal_root_to_{shell_name}", f1))
        raw.append(("F2", f"F2_transversal_left_minus_right_{shell_name}", f2))
        raw_counts.append(f"{shell_name}:{len(left_ids)}:{len(right_ids)}")
    Q, names, kinds = _gram_schmidt(raw)
    meta = {
        "F1F2_resolution_basis_relations": "provenance_derived_multishell_F1_longitudinal_and_F2_transversal_2form_basis",
        "F1F2_resolution_frontier_shell_count_requested": int(frontier_shell_count),
        "F1F2_resolution_augmented_boundary_count": int(len(boundary)),
        "F1F2_resolution_augmented_interior_count": int(len(interior)),
        "F1F2_resolution_shell_count": int(len(shells)),
        "F1F2_resolution_shell_counts": "|".join(raw_counts),
        "F1F2_resolution_role_names": "|".join(names),
        "F1F2_resolution_role_kinds": "|".join(kinds),
        "F1F2_resolution_basis_dim": int(Q.shape[1]) if Q.size else 0,
        "F1F2_resolution_F1_dim": int(sum(1 for k in kinds if k == "F1")),
        "F1F2_resolution_F2_dim": int(sum(1 for k in kinds if k == "F2")),
    }
    return boundary, interior, Q, names, kinds, meta


def _profile(A: np.ndarray, kinds: Sequence[str]) -> np.ndarray:
    f1 = [i for i, k in enumerate(kinds) if str(k) == "F1"]
    f2 = [i for i, k in enumerate(kinds) if str(k) == "F2"]
    if not f1 or not f2:
        return np.zeros((0, 0), dtype=float)
    return A[np.ix_(f1, f2)]


def _response(model, spec, state: str, *, tol: float, frontier_shell_count: int = 3, matrix_sign_relation: str = "out_degree") -> dict:
    boundary, interior, Q, names, kinds, bmeta = _multishell_f1f2_basis(model, spec, frontier_shell_count=frontier_shell_count)
    if Q.size == 0 or Q.shape[1] == 0:
        return {"ok": 0, **bmeta, "error": "empty_multishell_F1F2_basis"}
    res = directed_schur_response_from_model(
        model,
        state,
        boundary,
        interior,
        include_external_degrees=True,
        matrix_sign_relation=matrix_sign_relation,
    )
    if not res.ok or res.Lambda is None:
        return {"ok": 0, **bmeta, "error": res.error or "response_unavailable"}
    Lc = Q.T @ res.Lambda @ Q
    S, A = split_symmetric_skew(Lc)
    D, dmeta = positive_support_density_from_response(Lc, tol=max(tol, 1.0e-9))
    P = _profile(A, kinds)
    carrier_norm = float(fro(S))
    profile_norm = float(fro(P))
    condition = max(float(tol), float(tol) * max(1.0, carrier_norm))
    return {
        "ok": 1,
        **bmeta,
        "Lambda_role": Lc,
        "S": S,
        "A": A,
        "density": D,
        "density_meta": dmeta,
        "names": names,
        "kinds": kinds,
        "profile": P,
        "carrier_norm": carrier_norm,
        "skew_norm": float(fro(A)),
        "profile_norm": profile_norm,
        "profile_condition": float(condition),
        "vacuous_zero_profile_current": int(profile_norm <= condition),
        "cond_KII": float(res.cond_KII),
        "solve_residual": float(res.solve_residual),
        "row_sum_residual": float(res.row_sum_residual),
        "boundary_response_model": res.boundary_response_model,
    }


def _js(a: np.ndarray, b: np.ndarray, tol: float) -> float:
    val, _meta = jensen_shannon_divergence_no_epsilon(a, b, tol)
    return float(val) if math.isfinite(val) else math.inf


def _profile_gap(a: np.ndarray, b: np.ndarray, tol: float) -> float:
    if a.shape != b.shape or a.size == 0:
        return math.inf
    den = max(float(fro(a)), float(fro(b)), float(tol))
    return float(fro(a - b) / den)


def _oriented_distance(js: float, profile_gap: float) -> float:
    if not math.isfinite(js) or not math.isfinite(profile_gap):
        return math.inf
    return float(math.sqrt(js * js + profile_gap * profile_gap))


def _transform_matrix(kinds: Sequence[str], kind: str) -> np.ndarray:
    n = len(kinds)
    T = np.eye(n, dtype=float)
    if kind == "F2_flip":
        for i, k in enumerate(kinds):
            if str(k) == "F2":
                T[i, i] = -1.0
    elif kind == "F1_flip":
        for i, k in enumerate(kinds):
            if str(k) == "F1":
                T[i, i] = -1.0
    elif kind == "F2_shell_reverse":
        f2 = [i for i, k in enumerate(kinds) if str(k) == "F2"]
        if len(f2) >= 2:
            T = np.eye(n, dtype=float)
            for a, b in zip(f2, reversed(f2)):
                T[a, a] = 0.0
                T[a, b] = 1.0
    elif kind == "F1_shell_reverse":
        f1 = [i for i, k in enumerate(kinds) if str(k) == "F1"]
        if len(f1) >= 2:
            T = np.eye(n, dtype=float)
            for a, b in zip(f1, reversed(f1)):
                T[a, a] = 0.0
                T[a, b] = 1.0
    return T


def _apply_transform(resp: dict, kind: str) -> Tuple[np.ndarray, np.ndarray]:
    T = _transform_matrix(resp["kinds"], kind)
    D = T @ resp["density"] @ T.T
    A = T @ resp["A"] @ T.T
    return 0.5 * (D + D.T), _profile(0.5 * (A - A.T), resp["kinds"])


def _uniform_density(dim: int) -> np.ndarray:
    return np.eye(dim, dtype=float) / float(dim) if dim > 0 else np.zeros((0, 0), dtype=float)


def _cosine(A: np.ndarray, B: np.ndarray) -> float:
    if A.shape != B.shape or A.size == 0:
        return math.nan
    a = A.reshape(-1)
    b = B.reshape(-1)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float((a @ b) / den) if den > 0.0 else math.nan


def _meta_key_without_L(b: int, mode: str, meta: dict) -> Tuple[object, ...]:
    return (int(b), str(mode), str(meta.get("region_family")), int(meta.get("lca", -1)), int(meta.get("left_root", -1)), int(meta.get("right_root", -1)), int(meta.get("genealogical_corridor_length", -1)))


def _meta_key_without_mode(b: int, L: int, meta: dict) -> Tuple[object, ...]:
    return (int(b), int(L), str(meta.get("region_family")), int(meta.get("lca", -1)), int(meta.get("left_root", -1)), int(meta.get("right_root", -1)), int(meta.get("genealogical_corridor_length", -1)), int(meta.get("frontier_level", -1)))


def f1_f2_orientation_resolution_rows(config: OperatorTestConfig) -> List[dict]:
    """Resolve F1/F2 orientation by measuring a provenance-derived skew 2-form profile.

    10 compressed the F1/F2 orientation to one signed coupling.  This surface
    replaces that scalar by a multi-shell block profile A[F1_shell_i,F2_shell_j].
    It is still finite and real: no complex structure, metric, stochastic input,
    or external epsilon floor is introduced.
    """
    records: List[dict] = []
    by_no_L: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    by_no_mode: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []

    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _response(model, spec, "live", tol=config.algebra_tol)
            record = _response(model, spec, "record", tol=config.algebra_tol)
            sym = _response(model, spec, "sym", tol=config.algebra_tol)
            if not live.get("ok") or not record.get("ok"):
                rows.append({"branching": b, "level": L, "mode": mode, **meta, "F1F2_orientation_resolution_computed_status": "F1F2_multishell_response_unavailable", "F1F2_orientation_resolution_error": str(live.get("error") or record.get("error") or "unknown")})
                continue
            rec = {"b": int(b), "L": int(L), "mode": str(mode), "meta": meta, "live": live, "record": record, "sym": sym}
            records.append(rec)
            by_no_L[_meta_key_without_L(b, mode, meta)].append(rec)
            by_no_mode[_meta_key_without_mode(b, L, meta)].append(rec)

    for rec in records:
        b = rec["b"]; L = rec["L"]; mode = rec["mode"]; meta = rec["meta"]
        live = rec["live"]; record = rec["record"]; sym = rec["sym"]
        tol = float(config.algebra_tol)
        js_true = _js(live["density"], record["density"], tol)
        profile_gap_true = _profile_gap(live["profile"], record["profile"], tol)
        oriented_true = _oriented_distance(js_true, profile_gap_true)
        uniform_js = _js(live["density"], _uniform_density(live["density"].shape[0]), tol)
        uniform_gap = _profile_gap(live["profile"], np.zeros_like(live["profile"]), tol)
        oriented_uniform = _oriented_distance(uniform_js, uniform_gap)

        controls: Dict[str, Tuple[float, float, float]] = {}
        for kind in ("F2_flip", "F1_flip", "F2_shell_reverse", "F1_shell_reverse"):
            Dt, Pt = _apply_transform(record, kind)
            js = _js(live["density"], Dt, tol)
            gap = _profile_gap(live["profile"], Pt, tol)
            controls[kind] = (js, gap, _oriented_distance(js, gap))

        time_finite_objects = []
        for x in by_no_L[_meta_key_without_L(b, mode, meta)]:
            if int(x["L"]) == int(L) or x["record"]["density"].shape != live["density"].shape or x["record"]["profile"].shape != live["profile"].shape:
                continue
            js = _js(live["density"], x["record"]["density"], tol)
            gap = _profile_gap(live["profile"], x["record"]["profile"], tol)
            time_finite_objects.append((int(x["L"]), js, gap, _oriented_distance(js, gap)))
        if time_finite_objects:
            time_L, time_js, time_gap, time_dist = min(time_finite_objects, key=lambda p: p[3])
        else:
            time_L, time_js, time_gap, time_dist = -1, math.nan, math.nan, math.nan

        mode_finite_objects = []
        for x in by_no_mode[_meta_key_without_mode(b, L, meta)]:
            if str(x["mode"]) == str(mode) or x["record"]["density"].shape != live["density"].shape or x["record"]["profile"].shape != live["profile"].shape:
                continue
            js = _js(live["density"], x["record"]["density"], tol)
            gap = _profile_gap(live["profile"], x["record"]["profile"], tol)
            mode_finite_objects.append((str(x["mode"]), js, gap, _oriented_distance(js, gap)))
        if mode_finite_objects:
            mode_used, mode_js, mode_gap, mode_dist = min(mode_finite_objects, key=lambda p: p[3])
        else:
            mode_used, mode_js, mode_gap, mode_dist = "unavailable", math.nan, math.nan, math.nan

        score_tol = max(1.0e-8, 100.0 * tol)
        all_control_distances = [oriented_uniform] + [v[2] for v in controls.values()]
        if math.isfinite(time_dist):
            all_control_distances.append(time_dist)
        if math.isfinite(mode_dist):
            all_control_distances.append(mode_dist)
        available = [x for x in all_control_distances if math.isfinite(x)]
        passed = sum(1 for x in available if oriented_true < x - score_tol)
        beats_f2_flip = int(math.isfinite(oriented_true) and math.isfinite(controls["F2_flip"][2]) and oriented_true < controls["F2_flip"][2] - score_tol)
        profile_resolves_f2 = int((not (math.isfinite(js_true) and math.isfinite(controls["F2_flip"][0]) and js_true < controls["F2_flip"][0] - score_tol)) and beats_f2_flip)
        B_profile = live["profile"] - record["profile"]
        B_norm = float(fro(B_profile))
        B_alignment = _cosine(live["profile"] - record["profile"], B_profile)
        sym_zero = int(bool(sym.get("ok")) and int(sym.get("vacuous_zero_profile_current", 0)) == 1)
        live_zero = int(live.get("vacuous_zero_profile_current", 0))
        record_zero = int(record.get("vacuous_zero_profile_current", 0))
        if int(live.get("F1F2_resolution_F1_dim", 0)) == 0 or int(live.get("F1F2_resolution_F2_dim", 0)) == 0:
            computed_status = "F1F2_multishell_basis_rank_insufficient_control"
        elif live_zero:
            computed_status = "F1F2_multishell_live_orientation_vacuous_zero_current_control"
        elif passed >= max(4, min(6, len(available))):
            computed_status = "F1F2_multishell_true_record_preferred_finite_object"
        elif beats_f2_flip and passed >= 3:
            computed_status = "F1F2_multishell_birth_order_orientation_supported_control"
        elif profile_resolves_f2:
            computed_status = "F1F2_multishell_profile_resolves_density_ambiguity_finite_object"
        else:
            computed_status = "F1F2_multishell_orientation_resolution_obstructed_or_unresolved"

        rows.append({
            "branching": b,
            "level": L,
            "mode": mode,
            **meta,
            **{k: v for k, v in live.items() if k.startswith("F1F2_resolution_")},
            "F1F2_orientation_resolution_surface": "multishell_provenance_derived_F1F2_skew_2form_profile",
            "F1F2_orientation_resolution_density_component": "JS_live_record_on_multishell_positive_support_density_no_epsilon",
            "F1F2_orientation_resolution_profile_component": "relative_norm_of_A_live_minus_A_record_on_F1_shells_by_F2_shells",
            "JS_live_record_multishell_no_epsilon": float(js_true) if math.isfinite(js_true) else math.inf,
            "F1F2_live_profile_norm": float(live["profile_norm"]),
            "F1F2_record_profile_norm": float(record["profile_norm"]),
            "F1F2_sym_profile_norm": float(sym.get("profile_norm", math.nan)) if bool(sym.get("ok")) else math.nan,
            "F1F2_profile_gap_live_record": float(profile_gap_true) if math.isfinite(profile_gap_true) else math.inf,
            "F1F2_oriented_distance_live_record_multishell": float(oriented_true) if math.isfinite(oriented_true) else math.inf,
            "F1F2_oriented_distance_live_uniform_multishell": float(oriented_uniform) if math.isfinite(oriented_uniform) else math.inf,
            "F1F2_oriented_distance_live_F2_flipped_record_multishell": controls["F2_flip"][2],
            "F1F2_oriented_distance_live_F1_flipped_record_multishell": controls["F1_flip"][2],
            "F1F2_oriented_distance_live_F2_shell_reversed_record_multishell": controls["F2_shell_reverse"][2],
            "F1F2_oriented_distance_live_F1_shell_reversed_record_multishell": controls["F1_shell_reverse"][2],
            "F1F2_profile_gap_live_F2_flipped_record": controls["F2_flip"][1],
            "F1F2_profile_gap_live_F2_shell_reversed_record": controls["F2_shell_reverse"][1],
            "F1F2_oriented_distance_live_time_shifted_record_best_available": time_dist,
            "F1F2_time_shifted_record_level_used": int(time_L),
            "F1F2_oriented_distance_live_mode_mismatched_record_best_available": mode_dist,
            "F1F2_mode_mismatched_record_mode_used": mode_used,
            "F1F2_multishell_true_record_gain_over_uniform": float(oriented_uniform - oriented_true) if math.isfinite(oriented_uniform) and math.isfinite(oriented_true) else math.nan,
            "F1F2_multishell_true_record_gain_over_F2_flipped": float(controls["F2_flip"][2] - oriented_true) if math.isfinite(controls["F2_flip"][2]) and math.isfinite(oriented_true) else math.nan,
            "F1F2_multishell_true_record_gain_over_F2_shell_reversed": float(controls["F2_shell_reverse"][2] - oriented_true) if math.isfinite(controls["F2_shell_reverse"][2]) and math.isfinite(oriented_true) else math.nan,
            "F1F2_multishell_destroyed_history_control_count": int(len(available)),
            "F1F2_multishell_destroyed_history_control_passed_count": int(passed),
            "F1F2_multishell_true_beats_F2_flipped_record": beats_f2_flip,
            "F1F2_multishell_profile_resolves_density_F2_ambiguity": profile_resolves_f2,
            "F1F2_B_oriented_entropy_current_profile_norm": B_norm,
            "F1F2_B_profile_alignment_with_live_record_gap": B_alignment,
            "F1F2_vacuous_zero_live_profile_current": live_zero,
            "F1F2_vacuous_zero_record_profile_current": record_zero,
            "F1F2_vacuous_zero_sym_profile_current_control": sym_zero,
            "F1F2_orientation_resolution_score_margin_tol": float(score_tol),
            "F1F2_orientation_resolution_computed_status": computed_status,
        })
    return rows


def f1_f2_orientation_resolution_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("F1F2_orientation_resolution_computed_status", "unknown")) for r in rows})
    preferred = sum(1 for r in rows if str(r.get("F1F2_orientation_resolution_computed_status", "")) == "F1F2_multishell_true_record_preferred_finite_object")
    birth = sum(1 for r in rows if str(r.get("F1F2_orientation_resolution_computed_status", "")) == "F1F2_multishell_birth_order_orientation_supported_control")
    resolved = sum(1 for r in rows if str(r.get("F1F2_orientation_resolution_computed_status", "")) == "F1F2_multishell_profile_resolves_density_ambiguity_finite_object")
    return (
        "# F1/F2 orientation resolution measurement\n\n"
        "This surface replaces the scalar F1/F2 coupling by a provenance-derived multi-shell skew 2-form profile `A[F1_shell_i,F2_shell_j]`.  F1 shells come from LCA-to-frontier provenance depth; F2 shells come from left/right birth-order contrast.  The result is still finite and real, with no complex import and no external metric.\n\n"
        f"Preferred true-record computed_status_rows: {preferred}/{len(rows)}.\n\n"
        f"Birth-order-supported controls: {birth}/{len(rows)}.\n\n"
        f"Rows where the multi-shell profile resolves a density-only ambiguity: {resolved}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
