from __future__ import annotations

from collections import Counter
from typing import Dict, Iterable, List, Sequence


LIVE_REFERENCE_NOTE = "live_is_reference_physics_state; record_is_history_control; sym_is_null_control; B_is_backreaction_current"


def _count(rows: Sequence[dict], *, state: str | None, computed_status_key: str) -> Dict[str, int]:
    c: Counter[str] = Counter()
    for r in rows:
        if state is not None and str(r.get("state", "")) != state:
            continue
        c[str(r.get(computed_status_key, "missing_computed_status"))] += 1
    return dict(sorted(c.items()))


def _append_counts(out: List[dict], surface: str, rows: Sequence[dict], computed_status_key: str, state: str | None, scope: str) -> None:
    counts = _count(rows, state=state, computed_status_key=computed_status_key)
    total = sum(counts.values())
    for computed_status, n in counts.items():
        out.append({
            "surface": surface,
            "state_filter": state if state is not None else "all",
            "semantic_scope": scope,
            "computed_status_key": computed_status_key,
            "computed_status": computed_status,
            "rows": int(n),
            "total_rows_in_scope": int(total),
            "live_reference_relations": LIVE_REFERENCE_NOTE,
        })


def live_current_property_summary_rows(
    *,
    relative_common_ambient: Sequence[dict],
    commutator_decay: Sequence[dict],
    split_residual_scaling: Sequence[dict],
    modular_ratio_levels: Sequence[dict],
    support_rank_levels: Sequence[dict],
    tomita_rows: Sequence[dict],
    record_anchor_rows: Sequence[dict],
    backreaction_current_rows: Sequence[dict],
) -> List[dict]:
    rows: List[dict] = []
    _append_counts(rows, "relative_common_ambient_schur_isotony", relative_common_ambient, "relative_common_ambient_computed_status", "live", "reference_live_property_comparison")
    _append_counts(rows, "commutator_decay_by_genealogical_distance", commutator_decay, "commutator_decay_track_computed_status", "live", "reference_live_locality_scaling_derived_quantity")
    _append_counts(rows, "split_residual_by_collar_width", split_residual_scaling, "split_residual_track_computed_status", "live", "reference_live_split_scaling_derived_quantity")
    _append_counts(rows, "modular_ratio_trajectory_by_level", modular_ratio_levels, "modular_ratio_trajectory_computed_status", "live", "reference_live_modular_limes_derived_quantity")
    _append_counts(rows, "support_rank_trajectory", support_rank_levels, "support_rank_trajectory_computed_status", "live", "reference_live_support_derived_quantity")
    _append_counts(rows, "tomita_standard_form_compatibility", tomita_rows, "tomita_compatibility_computed_status", "live", "reference_live_tomita_comparison")
    _append_counts(rows, "record_anchor_consistency", record_anchor_rows, "record_anchor_consistency_computed_status", None, "record_anchor_condition_not_physics_state")
    _append_counts(rows, "backreaction_current_localization", backreaction_current_rows, "backreaction_current_localization_computed_status", None, "B_current_derived_quantity_not_operator_property")
    _append_counts(rows, "support_rank_trajectory_record_control", support_rank_levels, "support_rank_trajectory_computed_status", "record", "historical_record_control_not_physics_rank_bound")
    _append_counts(rows, "support_rank_trajectory_sym_control", support_rank_levels, "support_rank_trajectory_computed_status", "sym", "null_symmetry_control")
    return rows


def live_current_property_summary_report(rows: List[dict]) -> str:
    surfaces = sorted({str(r.get("surface", "unknown")) for r in rows})
    return (
        "# Live-reference property summary\n\n"
        "This summary re-reads the finite_core property-comparison outputs with the corrected CNNA relations: "
        "`live` is the physical response network; `record` is a fixed birth-history/provenance control; "
        "`B = live - record` is a backreaction current; `sym` is a null control.  "
        "Consequently, record support loss is not counted as a live physics rank_bound unless the explicit record-anchor condition is being evaluated.\n\n"
        "Surfaces summarized: `" + "`, `".join(surfaces) + "`.\n"
    )
