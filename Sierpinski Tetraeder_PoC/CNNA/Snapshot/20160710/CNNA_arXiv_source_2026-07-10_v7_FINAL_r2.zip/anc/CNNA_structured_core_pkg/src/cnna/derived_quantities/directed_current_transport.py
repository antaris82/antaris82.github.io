from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core import *
from cnna.core.directed_dtn import *
from cnna.derived_quantities.structural_ledgers import is_reference_model


def _first_transport_region(model: EmptySetGrowthModel, args) -> Optional[RegionSpec]:
    # directed-region coverage: full terminal region if it fits, otherwise the deepest admissible
    # coarse-frontier sibling cut.  The resulting boundary is still
    # C_lca+B1_front+B2_front, but B1/B2 may be prefix-frontiers instead of
    # terminal leaves for large L.
    specs = build_coarse_frontier_sibling_regions(
        model,
        max_regions=max(1, args.max_regions),
        max_boundary=args.max_boundary,
        max_interior=args.max_interior,
        max_frontier_level=getattr(args, "directed_frontier_cap", 6),
    )
    return specs[0] if specs else None



def _transport_region_meta(model: EmptySetGrowthModel, spec: RegionSpec, prefix: str) -> dict:
    fl = region_frontier_level(model, spec)
    return {
        f"{prefix}_region_pair_type": spec.pair_type,
        f"{prefix}_frontier_level": int(fl),
        f"{prefix}_terminal_level": int(model.L),
        f"{prefix}_coarse_frontier_used": int(fl < int(model.L)),
    }

def _open_out_directed_snapshot(model: EmptySetGrowthModel, state: str, args):
    spec = _first_transport_region(model, args)
    if spec is None:
        return None, None, None, None, None, None
    res = directed_schur_response_from_model(
        model,
        state,
        spec.boundary,
        spec.interior,
        include_external_degrees=True,
        matrix_sign_relation="out_degree",
    )
    if not res.ok or res.Lambda is None:
        return spec, res, None, None, None, None
    Qsig, qnames, _ = signed_role_basis_F1F2(spec.boundary, spec)
    Lp = Qsig.T @ res.Lambda @ Qsig
    Sp, Ap = split_symmetric_skew(Lp)
    J, jinfo = j_finite_object_from_SA(Sp, Ap, tol=max(getattr(args, "gns_tol", 1.0e-10), 1.0e-12))
    return spec, res, Qsig, qnames, (Sp, Ap), (J, jinfo)


def _address_at_target(model: EmptySetGrowthModel, nid: int, target_level: int) -> Tuple[int, ...]:
    addr = tuple(model.nodes[nid].address)
    if len(addr) <= target_level:
        return addr
    return prefix(addr, target_level)


def _boundary_prefix_transport_matrix(
    source_model: EmptySetGrowthModel,
    source_boundary: Sequence[int],
    target_model: EmptySetGrowthModel,
    target_boundary: Sequence[int],
    *,
    weighting: str,
) -> Tuple[np.ndarray, int, int, str]:
    """Boundary push-forward by address truncation.

    Rows are target-boundary nodes, columns are source-boundary nodes.  This is
    a deterministic provenance map, not a fitted least-squares map.  It is only
    defined where a source boundary address truncates to a target boundary
    address of the same regional cut.
    """
    if weighting not in {"fiber_sum", "fiber_average", "fiber_sqrt"}:
        raise ValueError("unknown transport weighting")
    target_pos_by_addr = {tuple(target_model.nodes[nid].address): k for k, nid in enumerate(target_boundary)}
    target_level = int(target_model.L)
    raw_hits: List[Tuple[int, int]] = []
    unmapped = 0
    for s_col, nid in enumerate(source_boundary):
        addr = _address_at_target(source_model, nid, target_level)
        row = target_pos_by_addr.get(addr)
        if row is None:
            unmapped += 1
            continue
        raw_hits.append((row, s_col))
    counts: Dict[int, int] = {}
    for row, _ in raw_hits:
        counts[row] = counts.get(row, 0) + 1
    R = np.zeros((len(target_boundary), len(source_boundary)), dtype=float)
    for row, col in raw_hits:
        if weighting == "fiber_sum":
            w = 1.0
        elif weighting == "fiber_average":
            w = 1.0 / float(max(1, counts.get(row, 1)))
        else:
            w = 1.0 / math.sqrt(float(max(1, counts.get(row, 1))))
        R[row, col] = w
    mapped_target = len(counts)
    note = "address_prefix_boundary_transport"
    if unmapped:
        note += "_with_unmapped_source_boundary_nodes"
    return R, len(raw_hits), unmapped, note


def _safe_rel_err(X: np.ndarray, Y: np.ndarray) -> float:
    return fro(X - Y) / max(fro(Y), EPS)


def _scale_fit_error(pred: np.ndarray, target: np.ndarray) -> Tuple[float, float]:
    denom = float(np.sum(pred * pred))
    if denom <= EPS:
        return math.nan, math.nan
    scale = float(np.sum(pred * target) / denom)
    err = fro(scale * pred - target) / max(fro(target), EPS)
    return scale, err


def _skew_orientation_sign(A: np.ndarray) -> int:
    if A.shape[0] >= 2 and A.shape[1] >= 2 and math.isfinite(float(A[0, 1])) and abs(float(A[0, 1])) > 1e-12:
        return 1 if float(A[0, 1]) > 0.0 else -1
    n = fro(A)
    return 0 if n <= 1e-12 else 1


def _j_orientation_metrics(J_pred: Optional[np.ndarray], J_target: Optional[np.ndarray]) -> dict:
    if J_pred is None or J_target is None:
        return {
            "J_available_pred": int(J_pred is not None),
            "J_available_target": int(J_target is not None),
            "J_orientation_error": math.nan,
            "J_sign_flip_error": math.nan,
            "J_orientation_agrees": 0,
        }
    same = fro(J_pred - J_target) / max(fro(J_target), EPS)
    flip = fro(J_pred + J_target) / max(fro(J_target), EPS)
    return {
        "J_available_pred": 1,
        "J_available_target": 1,
        "J_orientation_error": same,
        "J_sign_flip_error": flip,
        "J_orientation_agrees": int(same <= flip and same < 1e-8),
    }




def _snapshot_cache(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> dict:
    cache = {}
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        for st in states:
            spec, res, Q, qnames, plane, jpair = _open_out_directed_snapshot(model, st, args)
            cache[(int(b), int(L), str(mode), str(st))] = {
                "model": model,
                "spec": spec,
                "res": res,
                "Q": Q,
                "qnames": qnames,
                "plane": plane,
                "jpair": jpair,
            }
    return cache


def _pair_records(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args):
    levels = sorted(set(int(x) for x in args.levels))
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for st in states:
            for source in levels:
                for target in levels:
                    if source <= target:
                        continue
                    sm = models.get((b, source, mode, False))
                    tm = models.get((b, target, mode, False))
                    if sm is None or tm is None:
                        continue
                    yield b, mode, st, source, target, sm, tm


def directed_current_transport_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    cache = _snapshot_cache(models, states, args)
    S_A_cache: Dict[Tuple[int, int, str, str], Tuple[np.ndarray, np.ndarray]] = {}
    for b, mode, st, source, target, sm, tm in _pair_records(models, states, args):
        base = {
            "branching": b,
            "mode": mode,
            "state": st,
            "reference_model": int(is_reference_model(mode, st)),
            "source_level": source,
            "target_level": target,
            "boundary_response_model": "open_grounded_directed",
            "matrix_sign_relation": "out_degree",
        }
        ss = cache.get((b, source, mode, st), {})
        ts = cache.get((b, target, mode, st), {})
        sspec, sres, sQ, splane, sj = ss.get("spec"), ss.get("res"), ss.get("Q"), ss.get("plane"), ss.get("jpair")
        tspec, tres, tQ, tqnames, tplane, tj = ts.get("spec"), ts.get("res"), ts.get("Q"), ts.get("qnames"), ts.get("plane"), ts.get("jpair")
        if sspec is None or tspec is None or sres is None or tres is None or not sres.ok or not tres.ok or sres.Lambda is None or tres.Lambda is None or sQ is None or tQ is None or splane is None or tplane is None:
            rows.append({**base, "available": 0, "computed_status": "directed_current_transport_unavailable_missing_response_or_region"})
            continue
        S_t_plane, A_t_plane = tplane
        J_t, jinfo_t = tj if tj is not None else (None, {})
        skey = (b, source, mode, st)
        if skey not in S_A_cache:
            S_A_cache[skey] = split_symmetric_skew(sres.Lambda)
        S_s, A_s = S_A_cache[skey]
        for weighting in ["fiber_sum", "fiber_average", "fiber_sqrt"]:
            R, mapped, unmapped, note = _boundary_prefix_transport_matrix(sm, sspec.boundary, tm, tspec.boundary, weighting=weighting)
            S_pred_full = R @ S_s @ R.T
            A_pred_full = R @ A_s @ R.T
            S_pred_plane = tQ.T @ S_pred_full @ tQ
            A_pred_plane = tQ.T @ A_pred_full @ tQ
            J_pred, jinfo_pred = j_finite_object_from_SA(S_t_plane, A_pred_plane, tol=max(getattr(args, "gns_tol", 1.0e-10), 1.0e-12))
            a_rel = _safe_rel_err(A_pred_plane, A_t_plane)
            s_rel = _safe_rel_err(S_pred_plane, S_t_plane)
            scale, orient_err = _scale_fit_error(A_pred_plane, A_t_plane)
            source_scale = fro(A_pred_plane) / max(fro(A_t_plane), EPS)
            pred_sign = _skew_orientation_sign(A_pred_plane)
            target_sign = _skew_orientation_sign(A_t_plane)
            jmetrics = _j_orientation_metrics(J_pred, J_t)
            orientation_residual_le_tolerance = int(
                int(jmetrics.get("J_orientation_agrees", 0)) == 1
                or (target_sign != 0 and pred_sign == target_sign and math.isfinite(orient_err) and orient_err < 1e-8)
            )
            rows.append({
                **base,
                "available": 1,
                "transport_finite_object": f"address_prefix_boundary_pushforward_{weighting}",
                "source_region_id": sspec.region_id,
                "target_region_id": tspec.region_id,
                **_transport_region_meta(sm, sspec, "source"),
                **_transport_region_meta(tm, tspec, "target"),
                "source_boundary_size": len(sspec.boundary),
                "target_boundary_size": len(tspec.boundary),
                "mapped_source_boundary_count": mapped,
                "unmapped_source_boundary_count": unmapped,
                "target_signed_basis_names": " ".join(tqnames or []),
                "source_A_norm_full": fro(A_s),
                "target_A_norm_plane": fro(A_t_plane),
                "predicted_A_norm_plane": fro(A_pred_plane),
                "raw_A_relative_error": a_rel,
                "scale_optimal_A_orientation_error": orient_err,
                "scale_fit_pred_to_target": scale,
                "A_amplitude_ratio_pred_over_target": source_scale,
                "S_relative_error_control": s_rel,
                "pred_orientation_sign": pred_sign,
                "target_orientation_sign": target_sign,
                "orientation_sign_agrees": int(pred_sign != 0 and pred_sign == target_sign),
                "J_pred_available": int(jinfo_pred.get("available", 0) or 0),
                "J_target_available": int(jinfo_t.get("available", 0) or 0),
                "J_pred_reason": jinfo_pred.get("reason", "missing"),
                "J_target_reason": jinfo_t.get("reason", "missing"),
                "J_pred_square_error": jinfo_pred.get("J_square_minus_negative_projector_error", math.nan),
                "J_target_square_error": jinfo_t.get("J_square_minus_negative_projector_error", math.nan),
                **jmetrics,
                "J_orientation_or_A_orientation_residual_le_tolerance": orientation_residual_le_tolerance,
                "transport_note": note,
                "computed_status": "J_orientation_projective_coherence_residual_le_tolerance_A_amplitude_drift_quantified" if orientation_residual_le_tolerance else "directed_current_transport_available_orientation_not_residual_le_tolerance",
                "condition_note": "3_uses_address_prefix_transport_not_label_LS; separates_A_amplitude_drift_from_J_orientation",
            })
    return rows


def directed_current_composition_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    rows: List[dict] = []
    levels = sorted(set(int(x) for x in args.levels))
    if not {4, 5, 6}.issubset(set(levels)):
        return rows
    cache = _snapshot_cache(models, states, args)
    for (b, mode) in sorted({(int(k[0]), str(k[2])) for k in models.keys() if not bool(k[3])}):
        for st in states:
            m6 = models.get((b, 6, mode, False)); m5 = models.get((b, 5, mode, False)); m4 = models.get((b, 4, mode, False))
            base = {"branching": b, "mode": mode, "state": st, "reference_model": int(is_reference_model(mode, st)), "source_level": 6, "mid_level": 5, "target_level": 4}
            if m6 is None or m5 is None or m4 is None:
                rows.append({**base, "available": 0, "computed_status": "composition_unavailable_missing_level_model"})
                continue
            c6 = cache.get((b, 6, mode, st), {}); c5 = cache.get((b, 5, mode, st), {}); c4 = cache.get((b, 4, mode, st), {})
            s6, r6 = c6.get("spec"), c6.get("res")
            s5, r5 = c5.get("spec"), c5.get("res")
            s4, r4, q4, plane4, j4 = c4.get("spec"), c4.get("res"), c4.get("Q"), c4.get("plane"), c4.get("jpair")
            if not all([s6, s5, s4]) or r6 is None or r5 is None or r4 is None or not (r6.ok and r5.ok and r4.ok) or r6.Lambda is None or r5.Lambda is None or r4.Lambda is None or q4 is None or plane4 is None:
                rows.append({**base, "available": 0, "computed_status": "composition_unavailable_missing_directed_response"})
                continue
            _, A6 = split_symmetric_skew(r6.Lambda)
            S4_plane, A4_plane = plane4
            for weighting in ["fiber_sum", "fiber_average", "fiber_sqrt"]:
                R46, mapped46, unmapped46, _ = _boundary_prefix_transport_matrix(m6, s6.boundary, m4, s4.boundary, weighting=weighting)
                R56, mapped56, unmapped56, _ = _boundary_prefix_transport_matrix(m6, s6.boundary, m5, s5.boundary, weighting=weighting)
                R45, mapped45, unmapped45, _ = _boundary_prefix_transport_matrix(m5, s5.boundary, m4, s4.boundary, weighting=weighting)
                A_direct_full = R46 @ A6 @ R46.T
                A_via_full = R45 @ (R56 @ A6 @ R56.T) @ R45.T
                A_direct_plane = q4.T @ A_direct_full @ q4
                A_via_plane = q4.T @ A_via_full @ q4
                comp_residual = fro(A_direct_plane - A_via_plane) / max(fro(A_direct_plane), EPS)
                direct_target_err = _safe_rel_err(A_direct_plane, A4_plane)
                via_target_err = _safe_rel_err(A_via_plane, A4_plane)
                _, orient_direct = _scale_fit_error(A_direct_plane, A4_plane)
                _, orient_via = _scale_fit_error(A_via_plane, A4_plane)
                J_direct, info_direct = j_finite_object_from_SA(S4_plane, A_direct_plane, tol=max(getattr(args, "gns_tol", 1.0e-10), 1.0e-12))
                J_via, info_via = j_finite_object_from_SA(S4_plane, A_via_plane, tol=max(getattr(args, "gns_tol", 1.0e-10), 1.0e-12))
                J_target, info_target = j4 if j4 is not None else (None, {})
                jd = _j_orientation_metrics(J_direct, J_target)
                jv = _j_orientation_metrics(J_via, J_target)
                rows.append({
                    **base,
                    "available": 1,
                    "transport_finite_object": f"address_prefix_boundary_pushforward_{weighting}",
                    "mapped_6_to_4": mapped46,
                    "unmapped_6_to_4": unmapped46,
                    "mapped_6_to_5": mapped56,
                    "unmapped_6_to_5": unmapped56,
                    "mapped_5_to_4": mapped45,
                    "unmapped_5_to_4": unmapped45,
                    "direct_vs_composed_A_plane_residual": comp_residual,
                    "direct_A_relative_error_to_target": direct_target_err,
                    "via_A_relative_error_to_target": via_target_err,
                    "direct_scale_optimal_A_orientation_error": orient_direct,
                    "via_scale_optimal_A_orientation_error": orient_via,
                    "J_direct_available": int(info_direct.get("available", 0) or 0),
                    "J_via_available": int(info_via.get("available", 0) or 0),
                    "J_target_available": int(info_target.get("available", 0) or 0),
                    "J_direct_orientation_error": jd.get("J_orientation_error", math.nan),
                    "J_via_orientation_error": jv.get("J_orientation_error", math.nan),
                    "J_direct_orientation_agrees": jd.get("J_orientation_agrees", 0),
                    "J_via_orientation_agrees": jv.get("J_orientation_agrees", 0),
                    "computed_status": "directed_current_transport_composition_residual_le_tolerance_on_J_orientation" if comp_residual < 1e-12 and (jd.get("J_orientation_agrees", 0) or jv.get("J_orientation_agrees", 0)) else "directed_current_composition_residual_or_orientation_not_residual_le_tolerance",
                    "condition_note": "composition_is_tested_on_address_prefix_A_transport; amplitude_vs_orientation_reported_separately",
                })
    return rows


def directed_j_orientation_summary_rows(transport_rows: Sequence[dict], comp_rows: Sequence[dict]) -> List[dict]:
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", ""))) for r in transport_rows if int(r.get("available", 0) or 0) == 1})
    rows: List[dict] = []
    for b, mode in keys:
        reference = int(mode == REFERENCE_MODE)
        all_for_key = [r for r in transport_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        unavailable = [r for r in all_for_key if int(r.get("available", 0) or 0) != 1]
        unavailable_pairs = sorted({
            (int(r.get("source_level", -1)), int(r.get("target_level", -1)), str(r.get("state", "")))
            for r in unavailable
            if str(r.get("source_level", "")) != "" and str(r.get("target_level", "")) != ""
        })
        coverage_ok = int(not unavailable_pairs)

        live = [r for r in all_for_key if r.get("state") == "live" and int(r.get("available", 0) or 0) == 1]
        sym = [r for r in all_for_key if r.get("state") == "sym" and int(r.get("available", 0) or 0) == 1]
        live_residual_le_tolerance = int(bool(live) and any(int(r.get("J_orientation_or_A_orientation_residual_le_tolerance", 0) or 0) == 1 for r in live))
        live_amp_drift = max([float(r.get("raw_A_relative_error", 0.0) or 0.0) for r in live], default=math.nan)
        live_best_orient = min([float(r.get("scale_optimal_A_orientation_error", math.inf)) for r in live if math.isfinite(float(r.get("scale_optimal_A_orientation_error", math.nan)))], default=math.nan)
        sym_degenerate_ok = int(bool(sym) and all(int(r.get("target_orientation_sign", 0) or 0) == 0 or int(r.get("J_target_available", 0) or 0) == 0 for r in sym))
        comp_live = [r for r in comp_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "live" and int(r.get("available", 0) or 0) == 1]
        comp_residual_le_tolerance = int(bool(comp_live) and any(float(r.get("direct_vs_composed_A_plane_residual", 1.0) or 1.0) < 1e-12 for r in comp_live))
        unmet_conditions: List[str] = []
        if not coverage_ok:
            unmet_conditions.append("directed_current_transport_coverage_incomplete")
        if not live_residual_le_tolerance:
            unmet_conditions.append("live_J_or_A_orientation_transport_not_residual_le_tolerance")
        if not comp_residual_le_tolerance:
            unmet_conditions.append("A_transport_composition_not_residual_le_tolerance")
        if not sym_degenerate_ok:
            unmet_conditions.append("sym_control_not_degenerate_for_J_transport")
        if coverage_ok and live_residual_le_tolerance and comp_residual_le_tolerance:
            computed_status = "3_J_orientation_projective_coherence_residual_le_tolerance_A_amplitude_drift_quantified"
        else:
            computed_status = "3_directed_current_transport_residual_gt_tolerance"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": reference,
            "directed_transport_coverage_ok": coverage_ok,
            "directed_transport_unavailable_pair_count": len(unavailable_pairs),
            "directed_transport_unavailable_pairs": " ".join(f"{s}->{t}:{st}" for s, t, st in unavailable_pairs) if unavailable_pairs else "none",
            "live_J_or_A_orientation_transport_residual_le_tolerance": live_residual_le_tolerance,
            "A_transport_composition_residual_le_tolerance": comp_residual_le_tolerance,
            "sym_control_J_transport_degenerate": sym_degenerate_ok,
            "max_raw_A_relative_error_live": live_amp_drift,
            "best_scale_optimal_A_orientation_error_live": live_best_orient,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "3_statement_is_projective_orientation_not_amplitude_limit_not_star_hom_not_KMS; coverage_incomplete_blocks_residual_le_tolerance_computed_status",
        })
    return rows


def write_directed_current_transport_report(outdir: Path, transport_rows: Sequence[dict], comp_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference_summary = next((r for r in summary_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_transport = [r for r in transport_rows if int(r.get("reference_model", 0)) == 1 and r.get("state") == "live" and int(r.get("source_level", 0)) == 6 and int(r.get("target_level", 0)) == 4 and "fiber_sqrt" in str(r.get("transport_finite_object", ""))]
    tr = reference_transport[0] if reference_transport else next((r for r in transport_rows if int(r.get("reference_model", 0)) == 1), {})
    reference_comp = [r for r in comp_rows if int(r.get("reference_model", 0)) == 1 and r.get("state") == "live" and "fiber_sqrt" in str(r.get("transport_finite_object", ""))]
    cr = reference_comp[0] if reference_comp else next((r for r in comp_rows if int(r.get("reference_model", 0)) == 1), {})
    text = f"""# Natural directed DtN current transport

## Purpose

3 tests whether the directed/skew DtN current from 2 can be transported between levels by the CNNA provenance projection itself.  The map is not the old label-span least-squares operator map.  It is an address-prefix boundary push-forward applied to the directed `A` layer.

The measurement deliberately separates amplitude from orientation:

```text
A_L = current amplitude + orientation
J_L = polar(S_L^(-1/2) A_L S_L^(-1/2)) on finite support
```

## Reference summary

```text
computed_status  = {reference_summary.get('computed_status', 'missing')}
unmet_conditions = {reference_summary.get('unmet_conditions', 'missing')}
```

## Selected reference live transport row

```text
source_level                         = {tr.get('source_level', 'n/a')}
target_level                         = {tr.get('target_level', 'n/a')}
transport_finite_object                  = {tr.get('transport_finite_object', 'n/a')}
raw_A_relative_error                 = {tr.get('raw_A_relative_error', 'n/a')}
scale_optimal_A_orientation_error    = {tr.get('scale_optimal_A_orientation_error', 'n/a')}
A_amplitude_ratio_pred_over_target   = {tr.get('A_amplitude_ratio_pred_over_target', 'n/a')}
orientation_sign_agrees              = {tr.get('orientation_sign_agrees', 'n/a')}
J_orientation_error                  = {tr.get('J_orientation_error', 'n/a')}
J_orientation_agrees                 = {tr.get('J_orientation_agrees', 'n/a')}
computed_status                              = {tr.get('computed_status', 'n/a')}
```

## Selected 6→4 direct vs 6→5→4 composition row

```text
transport_finite_object                  = {cr.get('transport_finite_object', 'n/a')}
direct_vs_composed_A_plane_residual     = {cr.get('direct_vs_composed_A_plane_residual', 'n/a')}
direct_A_relative_error_to_target     = {cr.get('direct_A_relative_error_to_target', 'n/a')}
via_A_relative_error_to_target        = {cr.get('via_A_relative_error_to_target', 'n/a')}
direct_scale_optimal_A_orientation_error = {cr.get('direct_scale_optimal_A_orientation_error', 'n/a')}
via_scale_optimal_A_orientation_error    = {cr.get('via_scale_optimal_A_orientation_error', 'n/a')}
J_direct_orientation_agrees           = {cr.get('J_direct_orientation_agrees', 'n/a')}
J_via_orientation_agrees              = {cr.get('J_via_orientation_agrees', 'n/a')}
computed_status                               = {cr.get('computed_status', 'n/a')}
```

## Non-statements

3 does not statement an amplitude limit, a strict `*`-homomorphism, a completed GNS Hilbert space, a von Neumann algebra, Type III, KMS, or Tomita--Takesaki.  A residual_le_tolerance 3 only means that finite directed `A/J` orientation is coherent under the tested provenance push-forward while amplitude drift remains explicitly measured.
"""
    (outdir / "3_DIRECTED_CURRENT_TRANSPORT_REPORT.md").write_text(text, encoding="utf-8")


def directed_large_L_region_coverage_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], states: Sequence[str], args) -> List[dict]:
    """3c coverage measurement for large-L directed regions.

    This explicitly records whether each requested level is tested by a full
    terminal sibling-cone region or by the deterministic coarse-frontier proxy.
    Coarse frontier is not a mathematical shortcut statement; it is a finite
    multiscale DtN cut with deeper UV descendants accounted as external load or
    environment port by the response relations.
    """
    rows: List[dict] = []
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        spec = _first_transport_region(model, args)
        for st in states:
            base = {
                "branching": b,
                "level": L,
                "mode": mode,
                "state": st,
                "reference_model": int(is_reference_model(mode, st)),
                "max_boundary_condition_note": int(args.max_boundary),
                "max_interior_condition_note": int(args.max_interior),
            }
            if spec is None:
                rows.append({
                    **base,
                    "available": 0,
                    "region_id": "",
                    "region_pair_type": "none",
                    "frontier_level": math.nan,
                    "terminal_level": int(model.L),
                    "coarse_frontier_used": 0,
                    "n_boundary": math.nan,
                    "n_interior": math.nan,
                    "signed_F1F2_basis_rank": 0,
                    "relative_skew_norm": math.nan,
                    "signed_plane_relative_skew": math.nan,
                    "F1F2_signed_omega": math.nan,
                    "response_ok": 0,
                    "response_error": "directed_region_missing_under_size_condition_notes",
                    "computed_status": "directed_region_coverage_missing",
                    "condition_note": "coverage_missing_blocks_large_L_statements",
                })
                continue
            res = directed_schur_response_from_model(
                model,
                st,
                spec.boundary,
                spec.interior,
                include_external_degrees=True,
                matrix_sign_relation="out_degree",
            )
            Qsig, qnames, rank = signed_role_basis_F1F2(spec.boundary, spec)
            matrix_metrics = _safe_region_matrix_metrics(res.Lambda if res.ok else None)
            plane_metrics = _safe_region_plane_metrics(res.Lambda if res.ok else None, Qsig)
            fl = region_frontier_level(model, spec)
            coarse = int(fl < int(model.L))
            if res.ok and res.Lambda is not None and coarse:
                computed_status = "directed_region_coverage_coarse_frontier_directed_region_available"
            elif res.ok and res.Lambda is not None:
                computed_status = "directed_region_coverage_full_terminal_directed_region_available"
            else:
                computed_status = "directed_region_coverage_directed_region_response_unavailable"
            rows.append({
                **base,
                "available": int(res.ok and res.Lambda is not None),
                "region_id": spec.region_id,
                "region_pair_type": spec.pair_type,
                "frontier_level": int(fl),
                "terminal_level": int(model.L),
                "coarse_frontier_used": coarse,
                "n_boundary": len(spec.boundary),
                "n_interior": len(spec.interior),
                "signed_F1F2_basis_rank": int(rank),
                "signed_basis_names": " ".join(qnames),
                "response_ok": int(res.ok),
                "response_error": res.error,
                "cond_KII": res.cond_KII,
                "solve_residual": res.solve_residual,
                "row_sum_residual": res.row_sum_residual,
                **matrix_metrics,
                **plane_metrics,
                "computed_status": computed_status,
                "condition_note": "directed_region_coverage_full_terminal_when_possible_else_deepest_coarse_frontier; no_threshold_residual_le_tolerancewashing",
            })
    return rows


def _safe_region_matrix_metrics(Lambda: Optional[np.ndarray]) -> dict:
    if Lambda is None:
        return {
            "directed_response_norm": math.nan,
            "symmetric_part_norm": math.nan,
            "skew_part_norm": math.nan,
            "relative_skew_norm": math.nan,
        }
    S, A = split_symmetric_skew(Lambda)
    return {
        "directed_response_norm": fro(Lambda),
        "symmetric_part_norm": fro(S),
        "skew_part_norm": fro(A),
        "relative_skew_norm": fro(A) / max(fro(Lambda), EPS),
    }


def _safe_region_plane_metrics(Lambda: Optional[np.ndarray], Q: np.ndarray) -> dict:
    if Lambda is None or Q.shape[1] < 2:
        return {
            "signed_plane_relative_skew": math.nan,
            "F1F2_signed_omega": math.nan,
            "F1F2_skew_nonzero": 0,
        }
    Lp = Q.T @ Lambda @ Q
    Sp, Ap = split_symmetric_skew(Lp)
    omega = float(Ap[0, 1]) if Ap.shape[0] >= 2 and Ap.shape[1] >= 2 else math.nan
    return {
        "signed_plane_relative_skew": fro(Ap) / max(fro(Lp), EPS),
        "F1F2_signed_omega": omega,
        "F1F2_skew_nonzero": int(math.isfinite(omega) and abs(omega) > 1.0e-10),
    }


def directed_large_L_coverage_summary_rows(coverage_rows: Sequence[dict], transport_rows: Sequence[dict]) -> List[dict]:
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", ""))) for r in coverage_rows if str(r.get("branching", "")) != ""})
    rows: List[dict] = []
    for b, mode in keys:
        reference = int(mode == REFERENCE_MODE)
        live_cov = [r for r in coverage_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "live"]
        sym_cov = [r for r in coverage_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode and r.get("state") == "sym"]
        live_unavailable = [r for r in live_cov if int(r.get("available", 0) or 0) != 1]
        live_levels = sorted({int(r.get("level", -1)) for r in live_cov if str(r.get("level", "")) != ""})
        unavailable_levels = sorted({int(r.get("level", -1)) for r in live_unavailable if str(r.get("level", "")) != ""})
        coarse_levels = sorted({int(r.get("level", -1)) for r in live_cov if int(r.get("coarse_frontier_used", 0) or 0) == 1})
        full_levels = sorted({int(r.get("level", -1)) for r in live_cov if int(r.get("available", 0) or 0) == 1 and int(r.get("coarse_frontier_used", 0) or 0) == 0})
        live_skew_ok = int(bool(live_cov) and all(
            int(r.get("available", 0) or 0) == 1 and int(r.get("signed_F1F2_basis_rank", 0) or 0) >= 2 and float(r.get("signed_plane_relative_skew", 0.0) or 0.0) > 1.0e-10
            for r in live_cov
        ))
        sym_zero_ok = int(not sym_cov or all(
            int(r.get("available", 0) or 0) == 1 and abs(float(r.get("F1F2_signed_omega", 0.0) or 0.0)) <= 1.0e-10
            for r in sym_cov
        ))
        trans_rel = [r for r in transport_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        trans_unavailable = [r for r in trans_rel if int(r.get("available", 0) or 0) != 1]
        transport_coverage_ok = int(not trans_unavailable and bool(trans_rel))
        unmet_conditions: List[str] = []
        if live_unavailable:
            unmet_conditions.append("large_L_directed_region_coverage_incomplete")
        if not live_skew_ok:
            unmet_conditions.append("large_L_live_signed_skew_not_available_on_all_covered_levels")
        if not sym_zero_ok:
            unmet_conditions.append("large_L_sym_control_not_zero_on_covered_levels")
        if not transport_coverage_ok:
            unmet_conditions.append("large_L_transport_pair_coverage_incomplete")
        if not unmet_conditions:
            computed_status = "directed_large_L_directed_region_coverage_residual_le_tolerance"
        else:
            computed_status = "directed_large_L_directed_region_coverage_residual_gt_tolerance"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": reference,
            "requested_live_levels": " ".join(map(str, live_levels)) if live_levels else "none",
            "full_terminal_levels": " ".join(map(str, full_levels)) if full_levels else "none",
            "coarse_frontier_levels": " ".join(map(str, coarse_levels)) if coarse_levels else "none",
            "unavailable_levels": " ".join(map(str, unavailable_levels)) if unavailable_levels else "none",
            "directed_region_coverage_ok": int(not live_unavailable and bool(live_cov)),
            "live_signed_skew_all_covered_levels": live_skew_ok,
            "sym_control_zero_all_covered_levels": sym_zero_ok,
            "directed_transport_pair_coverage_ok": transport_coverage_ok,
            "transport_unavailable_pair_count": len(trans_unavailable),
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "directed_large_L_residual_le_tolerance_requires_actual_region_and_transport_coverage_for_requested_levels",
        })
    return rows


def write_directed_region_coverage_report(outdir: Path, coverage_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference_summary = next((r for r in summary_rows if int(r.get("reference_model", 0)) == 1), {})
    live_rows = [r for r in coverage_rows if int(r.get("reference_model", 0)) == 1 and r.get("state") == "live"]
    lines = [
        "# Large-L directed region coverage",
        "",
        "## Purpose",
        "",
        "3c prevents L>=7 directed/skew-DtN sweeps from being classified by stale L<=6 rows.  It uses the full terminal sibling-cone cut when it fits the size condition_notes and otherwise uses the deepest deterministic coarse-frontier cut that fits.  The coarse cut keeps `C_lca + B1_front + B2_front`; deeper UV nodes are outside the coarse boundary and enter as external load/environment accounting, not as hidden Schur interior.",
        "",
        "## Reference summary",
        "",
        "```text",
        f"computed_status  = {reference_summary.get('computed_status', 'missing')}",
        f"unmet_conditions = {reference_summary.get('unmet_conditions', 'missing')}",
        f"full_terminal_levels   = {reference_summary.get('full_terminal_levels', 'missing')}",
        f"coarse_frontier_levels = {reference_summary.get('coarse_frontier_levels', 'missing')}",
        f"unavailable_levels     = {reference_summary.get('unavailable_levels', 'missing')}",
        "```",
        "",
        "## Reference live coverage rows",
        "",
        "```text",
    ]
    for r in sorted(live_rows, key=lambda x: int(x.get("level", 0))):
        lines.append(
            f"L={r.get('level')} available={r.get('available')} frontier={r.get('frontier_level')} terminal={r.get('terminal_level')} "
            f"coarse={r.get('coarse_frontier_used')} boundary={r.get('n_boundary')} interior={r.get('n_interior')} "
            f"omega={r.get('F1F2_signed_omega')} computed_status={r.get('computed_status')}"
        )
    lines.extend([
        "```",
        "",
        "## Non-statements",
        "",
        "A coarse-frontier residual_le_tolerance result is not a proof of a full terminal L-limit.  It is a finite multiscale directed-DtN coverage result.  It exists to distinguish real large-L coverage from missing-region artifacts and to prepare a later multiscale consistency measurement.",
    ])
    (outdir / "3C_LARGE_L_DIRECTED_REGION_COVERAGE_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
