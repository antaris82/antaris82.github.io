"""CNNA structured package: construction core plus derived_quantity rows."""
