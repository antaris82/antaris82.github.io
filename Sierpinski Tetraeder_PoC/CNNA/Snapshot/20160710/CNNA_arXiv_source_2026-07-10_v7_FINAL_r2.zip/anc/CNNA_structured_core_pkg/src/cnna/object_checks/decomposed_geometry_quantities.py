from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"), row.get("region_id"), row.get("genealogical_corridor_length"))


def _component_index(component_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {_key(r): r for r in component_rows if "decomposed_history_measure_additive_total" in r}


def _ratio(raw: float, scale: float) -> float:
    return float(raw / max(scale, 1.0e-300)) if math.isfinite(raw) and math.isfinite(scale) and scale > 0.0 else math.nan


def _within(raw: float, scale: float, *, factor: float = 10.0) -> int:
    return int(math.isfinite(raw) and math.isfinite(scale) and scale > 0.0 and raw <= factor * scale)


def _dominant_explanation(row: dict) -> str:
    flags = {
        "density_support_scale": int(row.get("within_density_support_scale", 0) or 0),
        "orientation_signature_scale": int(row.get("within_orientation_signature_scale", 0) or 0),
        "response_strength_scale": int(row.get("within_response_strength_scale", 0) or 0),
    }
    # Prefer the most semantically specific explanation when several scales contain the residual.
    if flags["orientation_signature_scale"] and not flags["density_support_scale"]:
        return "explained_by_normalized_F1F2_signature_scale"
    if flags["response_strength_scale"] and not flags["orientation_signature_scale"] and not flags["density_support_scale"]:
        return "explained_only_by_F1F2_strength_weighting_scale"
    if flags["orientation_signature_scale"] and flags["response_strength_scale"] and not flags["density_support_scale"]:
        return "explained_by_F1F2_orientation_plus_strength_scale"
    if flags["density_support_scale"] and not flags["orientation_signature_scale"] and not flags["response_strength_scale"]:
        return "explained_only_by_density_support_scale"
    if flags["density_support_scale"] and flags["orientation_signature_scale"]:
        return "explained_by_density_and_orientation_scale"
    if int(row.get("within_total_decomposed_measure_scale", 0) or 0):
        return "explained_only_by_combined_decomposed_measure_scale"
    return "exceeds_all_decomposed_component_scales"


def _surface_track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("geometry_surface"), row.get("branching"), row.get("mode"), row.get("geometry_layer"), row.get("component_explanation"))


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[dict]] = defaultdict(list)
    for r in rows:
        try:
            c = int(r.get("genealogical_corridor_length", -1))
        except Exception:
            c = -1
        if c >= 0:
            by_c[c].append(r)
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"decomposed_geometry_track_computed_status": "decomposed_geometry_insufficient_corridor_track"}
    first, last = cs[0], cs[-1]
    raw_f = _median(_finite(r.get("geometry_raw_rank_bound")) for r in by_c[first])
    raw_l = _median(_finite(r.get("geometry_raw_rank_bound")) for r in by_c[last])
    total_f = _median(_finite(r.get("rank_bound_per_decomposed_total")) for r in by_c[first])
    total_l = _median(_finite(r.get("rank_bound_per_decomposed_total")) for r in by_c[last])
    sig_f = _median(_finite(r.get("rank_bound_per_orientation_signature")) for r in by_c[first])
    sig_l = _median(_finite(r.get("rank_bound_per_orientation_signature")) for r in by_c[last])
    raw_decay = math.isfinite(raw_f) and math.isfinite(raw_l) and raw_l < raw_f - max(tol, tol * max(1.0, abs(raw_f)))
    total_decay = math.isfinite(total_f) and math.isfinite(total_l) and total_l < total_f - max(tol, tol * max(1.0, abs(total_f)))
    sig_decay = math.isfinite(sig_f) and math.isfinite(sig_l) and sig_l < sig_f - max(tol, tol * max(1.0, abs(sig_f)))
    if raw_decay and total_decay and sig_decay:
        computed_status = "decomposed_geometry_raw_and_signature_normalized_decay_finite_object"
    elif total_decay:
        computed_status = "decomposed_geometry_improves_only_after_total_decomposition_control"
    elif sig_decay:
        computed_status = "decomposed_geometry_signature_normalized_decay_control"
    elif math.isfinite(total_f) and math.isfinite(total_l) and total_l > total_f + max(tol, tol * max(1.0, abs(total_f))):
        computed_status = "decomposed_geometry_total_normalized_worsens_with_corridor_observed"
    else:
        computed_status = "decomposed_geometry_no_monotone_corridor_improvement_observed"
    return {
        "decomposed_geometry_corridor_count": int(len(cs)),
        "decomposed_geometry_first_corridor": int(first),
        "decomposed_geometry_last_corridor": int(last),
        "raw_rank_bound_first_corridor_median": raw_f,
        "raw_rank_bound_last_corridor_median": raw_l,
        "rank_bound_per_total_first_corridor_median": total_f,
        "rank_bound_per_total_last_corridor_median": total_l,
        "rank_bound_per_signature_first_corridor_median": sig_f,
        "rank_bound_per_signature_last_corridor_median": sig_l,
        "decomposed_geometry_track_computed_status": computed_status,
    }


def _base_row(*, source: dict, comp: dict, surface: str, layer: str, raw: float, tol: float) -> dict:
    density = _finite(comp.get("density_support_component_JS_live_record"))
    signature = _finite(comp.get("normalized_F1F2_signature_component"))
    strength = _finite(comp.get("F1F2_response_strength_component"))
    ds = _finite(comp.get("density_plus_signature_component"))
    dstr = _finite(comp.get("density_plus_strength_component"))
    sstr = _finite(comp.get("signature_plus_strength_component"))
    total = _finite(comp.get("decomposed_history_measure_additive_total"))
    row = {
        "geometry_surface": surface,
        "branching": source.get("branching"),
        "level": source.get("level"),
        "mode": source.get("mode"),
        "region_id": source.get("region_id"),
        "region_family": source.get("region_family"),
        "genealogical_corridor_length": source.get("genealogical_corridor_length"),
        "geometry_layer": layer,
        "geometry_raw_rank_bound": raw,
        "density_support_component_JS_live_record": density,
        "normalized_F1F2_signature_component": signature,
        "F1F2_response_strength_component": strength,
        "decomposed_history_measure_additive_total": total,
        "rank_bound_per_density_support": _ratio(raw, density),
        "rank_bound_per_orientation_signature": _ratio(raw, signature),
        "rank_bound_per_response_strength": _ratio(raw, strength),
        "rank_bound_per_density_plus_signature": _ratio(raw, ds),
        "rank_bound_per_density_plus_strength": _ratio(raw, dstr),
        "rank_bound_per_signature_plus_strength": _ratio(raw, sstr),
        "rank_bound_per_decomposed_total": _ratio(raw, total),
        "within_density_support_scale": _within(raw, density),
        "within_orientation_signature_scale": _within(raw, signature),
        "within_response_strength_scale": _within(raw, strength),
        "within_density_plus_signature_scale": _within(raw, ds),
        "within_density_plus_strength_scale": _within(raw, dstr),
        "within_signature_plus_strength_scale": _within(raw, sstr),
        "within_total_decomposed_measure_scale": _within(raw, total),
        "component_dominance": comp.get("component_dominance"),
        "source_computed_status": source.get("live_cluster_track_computed_status", source.get("refined_split_track_computed_status", source.get("finite_complement_computed_status"))),
    }
    row["component_explanation"] = _dominant_explanation(row)
    if not math.isfinite(raw):
        computed_status = "decomposed_geometry_raw_rank_bound_unavailable"
    elif raw <= tol:
        computed_status = "decomposed_geometry_exact_zero_control"
    elif row["component_explanation"] == "explained_by_normalized_F1F2_signature_scale":
        computed_status = "geometry_rank_bound_explained_by_orientation_signature_scale_finite_object"
    elif row["component_explanation"] == "explained_only_by_F1F2_strength_weighting_scale":
        computed_status = "geometry_rank_bound_explained_only_by_mode_strength_scale_control"
    elif row["component_explanation"] == "explained_by_F1F2_orientation_plus_strength_scale":
        computed_status = "geometry_rank_bound_explained_by_F1F2_signature_plus_strength_scale_finite_object"
    elif row["component_explanation"] == "explained_only_by_density_support_scale":
        computed_status = "geometry_rank_bound_explained_only_by_density_support_scale_control"
    elif row["component_explanation"] == "explained_by_density_and_orientation_scale":
        computed_status = "geometry_rank_bound_explained_by_density_plus_orientation_scale_finite_object"
    elif row["component_explanation"] == "explained_only_by_combined_decomposed_measure_scale":
        computed_status = "geometry_rank_bound_explained_only_by_combined_measure_scale_control"
    else:
        computed_status = "geometry_rank_bound_exceeds_decomposed_measure_scales_observed"
    row["decomposed_geometry_row_computed_status"] = computed_status
    return row


def decomposed_geometry_quantities_rows(
    component_rows: List[dict],
    locality_rows: List[dict],
    split_rows: List[dict],
    complement_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Evaluate locality/split/complement residuals against density, signature, and strength separately."""
    cidx = _component_index(component_rows)
    rows: List[dict] = []
    for r in locality_rows:
        comp = cidx.get(_key(r), {})
        raw = _finite(r.get("cluster_rank_bound_norm"))
        rows.append(_base_row(source=r, comp=comp, surface="locality_commutator_decomposed_by_history_components", layer=str(r.get("live_cluster_layer")), raw=raw, tol=tol))
    for r in split_rows:
        comp = cidx.get(_key(r), {})
        raw = _finite(r.get("refined_tensor_dimension_residual", r.get("split_residual_raw", math.nan)))
        rows.append(_base_row(source=r, comp=comp, surface="split_residual_decomposed_by_history_components", layer=str(r.get("refined_split_layer", r.get("split_layer", "split"))), raw=raw, tol=tol))
    for r in complement_rows:
        comp = cidx.get(_key(r), {})
        raw = max(
            _finite(r.get("complement_into_region_commutant_residual")),
            _finite(r.get("region_commutant_into_complement_residual")),
            _finite(r.get("region_into_complement_commutant_residual")),
        )
        row = _base_row(source=r, comp=comp, surface="complement_error_decomposed_by_history_components", layer="finite_complement_relations", raw=raw, tol=tol)
        row["finite_complement_type"] = r.get("finite_complement_type")
        row["one_sided_inclusion_ok"] = int(r.get("one_sided_inclusion_ok", 0) or 0)
        row["two_sided_duality_ok"] = int(r.get("two_sided_duality_ok", 0) or 0)
        rows.append(row)
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        tracks[_surface_track_key(row)].append(row)
    summaries = {k: _summarize_track(v, tol) for k, v in tracks.items()}
    for row in rows:
        row.update(summaries.get(_surface_track_key(row), {}))
    return rows


def decomposed_geometry_quantities_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("decomposed_geometry_row_computed_status", "unknown")) for r in rows})
    explanations = sorted({str(r.get("component_explanation", "unknown")) for r in rows})
    surfaces = sorted({str(r.get("geometry_surface", "unknown")) for r in rows})
    return (
        "# Geometry derived_quantity rows decomposed by density, F1/F2 signature, and F1/F2 strength\n\n"
        "This surface stops judging locality, split, and complement residuals against one mixed HistoryMeasure.  Each residual is reported relative to density/support JS, normalized F1/F2 orientation signature, F1/F2 response strength, pairwise component sums, and the total decomposed score.\n\n"
        "Surfaces: `" + "`, `".join(surfaces) + "`.\n\n"
        "Component explanations: `" + "`, `".join(explanations) + "`.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
