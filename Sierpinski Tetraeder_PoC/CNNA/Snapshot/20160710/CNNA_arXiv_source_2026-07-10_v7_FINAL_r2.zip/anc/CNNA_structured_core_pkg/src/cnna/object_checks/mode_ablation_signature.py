from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple

import numpy as np

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    genealogical_corridor_metadata,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import region_size_meta
from .f1_f2_orientation_resolution import _response, _js, _meta_key_without_mode


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _signature(P: np.ndarray, tol: float) -> Tuple[np.ndarray, float, int]:
    norm = float(fro(P)) if P.size else 0.0
    condition = max(float(tol), float(tol) * max(1.0, norm))
    if norm <= condition:
        return np.zeros_like(P), norm, 1
    return np.array(P, dtype=float) / norm, norm, 0


def _cosine(A: np.ndarray, B: np.ndarray) -> float:
    if A.shape != B.shape or A.size == 0:
        return math.nan
    a = A.reshape(-1)
    b = B.reshape(-1)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float((a @ b) / den) if den > 0.0 else math.nan


def _signature_gap(A: np.ndarray, B: np.ndarray, tol: float) -> float:
    if A.shape != B.shape or A.size == 0:
        return math.inf
    return float(fro(A - B))


def _amplitude_gap(a: float, b: float, tol: float) -> float:
    den = max(float(a), float(b), float(tol))
    return float(abs(float(a) - float(b)) / den)


def _combined(js: float, sig_gap: float, amp_gap: float) -> float:
    if not all(math.isfinite(x) for x in (js, sig_gap, amp_gap)):
        return math.inf
    return float(math.sqrt(js * js + sig_gap * sig_gap + amp_gap * amp_gap))


def _mode_signature_row(*, b: int, L: int, mode: str, meta: dict, control_mode: str, true_js: float, true_sig_gap: float, true_amp_gap: float, true_score: float, true_alignment: float, control_js: float, control_sig_gap: float, control_amp_gap: float, control_score: float, control_alignment: float, tol: float) -> dict:
    score_tol = max(1.0e-8, 100.0 * float(tol))
    js_margin = float(control_js - true_js) if math.isfinite(control_js) and math.isfinite(true_js) else math.nan
    sig_margin = float(control_sig_gap - true_sig_gap) if math.isfinite(control_sig_gap) and math.isfinite(true_sig_gap) else math.nan
    amp_margin = float(control_amp_gap - true_amp_gap) if math.isfinite(control_amp_gap) and math.isfinite(true_amp_gap) else math.nan
    score_margin = float(control_score - true_score) if math.isfinite(control_score) and math.isfinite(true_score) else math.nan
    align_margin = float(true_alignment - control_alignment) if math.isfinite(true_alignment) and math.isfinite(control_alignment) else math.nan

    true_signature_preferred = int(math.isfinite(sig_margin) and sig_margin > score_tol)
    true_amplitude_preferred = int(math.isfinite(amp_margin) and amp_margin > score_tol)
    true_score_preferred = int(math.isfinite(score_margin) and score_margin > score_tol)
    same_signature = int(math.isfinite(sig_margin) and abs(sig_margin) <= score_tol)
    same_amplitude = int(math.isfinite(amp_margin) and abs(amp_margin) <= score_tol)

    if true_signature_preferred and true_score_preferred:
        computed_status = "true_record_mode_signature_parameter_dependence_supported_finite_object"
    elif same_signature and true_amplitude_preferred:
        computed_status = "mode_family_shares_birth_order_signature_but_differs_in_strength_control"
    elif true_signature_preferred and not true_score_preferred:
        computed_status = "mode_signature_parameter_dependence_hidden_by_density_or_amplitude_control"
    elif same_signature and same_amplitude:
        computed_status = "mode_mismatched_record_signature_and_strength_degenerate_observed"
    elif math.isfinite(score_margin) and score_margin <= score_tol:
        computed_status = "mode_mismatched_record_mode_ablated_score_as_close_or_closer_observed"
    else:
        computed_status = "mode_ablation_parameter_dependence_unresolved_control"

    return {
        "mode_ablation_surface": "F1F2_mode_mode_stable_signature_vs_mode_sensitive_strength",
        "branching": int(b),
        "level": int(L),
        "mode": str(mode),
        **meta,
        "control_mode": str(control_mode),
        "true_density_JS_component": float(true_js) if math.isfinite(true_js) else math.inf,
        "true_F1F2_signature_gap_mode_mode_stable_component": float(true_sig_gap) if math.isfinite(true_sig_gap) else math.inf,
        "true_F1F2_strength_gap_mode_sensitive_component": float(true_amp_gap) if math.isfinite(true_amp_gap) else math.inf,
        "true_mode_ablated_combined_score": float(true_score) if math.isfinite(true_score) else math.inf,
        "true_F1F2_signature_alignment_cosine": float(true_alignment) if math.isfinite(true_alignment) else math.nan,
        "control_density_JS_component": float(control_js) if math.isfinite(control_js) else math.inf,
        "control_F1F2_signature_gap_mode_mode_stable_component": float(control_sig_gap) if math.isfinite(control_sig_gap) else math.inf,
        "control_F1F2_strength_gap_mode_sensitive_component": float(control_amp_gap) if math.isfinite(control_amp_gap) else math.inf,
        "control_mode_ablated_combined_score": float(control_score) if math.isfinite(control_score) else math.inf,
        "control_F1F2_signature_alignment_cosine": float(control_alignment) if math.isfinite(control_alignment) else math.nan,
        "density_margin_control_minus_true": js_margin,
        "signature_margin_control_minus_true": sig_margin,
        "strength_margin_control_minus_true": amp_margin,
        "combined_score_margin_control_minus_true": score_margin,
        "signature_alignment_margin_true_minus_control": align_margin,
        "true_signature_preferred_over_mode_control": true_signature_preferred,
        "true_strength_preferred_over_mode_control": true_amplitude_preferred,
        "true_combined_score_preferred_over_mode_control": true_score_preferred,
        "mode_control_same_birth_order_signature_as_true_record": same_signature,
        "mode_control_same_response_strength_as_true_record": same_amplitude,
        "mode_ablation_score_tol": float(score_tol),
        "mode_ablation_signature_computed_status": computed_status,
    }


def mode_ablation_signature_rows(config: OperatorTestConfig) -> List[dict]:
    """Separate mode-mode_stable F1/F2 birth-order signature from mode-sensitive strength.

    The preceding surface showed that mode-mismatched records can be close to the true record.
    This surface tests whether that is because linear/log/saturating encode the
    same oriented birth-order signature while only changing response strength.
    """
    records: List[dict] = []
    by_no_mode: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    rows: List[dict] = []

    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = _response(model, spec, "live", tol=config.algebra_tol)
            record = _response(model, spec, "record", tol=config.algebra_tol)
            if not live.get("ok") or not record.get("ok"):
                rows.append({
                    "mode_ablation_surface": "F1F2_mode_mode_stable_signature_vs_mode_sensitive_strength",
                    "branching": int(b), "level": int(L), "mode": str(mode), **meta,
                    "mode_ablation_signature_computed_status": "mode_ablation_response_unavailable",
                    "mode_ablation_error": str(live.get("error") or record.get("error") or "unknown"),
                })
                continue
            rec = {"b": int(b), "L": int(L), "mode": str(mode), "meta": meta, "live": live, "record": record}
            records.append(rec)
            by_no_mode[_meta_key_without_mode(b, L, meta)].append(rec)

    for rec in records:
        b = rec["b"]; L = rec["L"]; mode = rec["mode"]; meta = rec["meta"]
        live = rec["live"]; record = rec["record"]
        tol = float(config.algebra_tol)
        live_sig, live_amp, live_zero = _signature(live["profile"], tol)
        rec_sig, rec_amp, rec_zero = _signature(record["profile"], tol)
        true_js = _js(live["density"], record["density"], tol)
        true_sig_gap = _signature_gap(live_sig, rec_sig, tol)
        true_amp_gap = _amplitude_gap(live_amp, rec_amp, tol)
        true_score = _combined(true_js, true_sig_gap, true_amp_gap)
        true_alignment = _cosine(live_sig, rec_sig)
        finite_objects = [
            x for x in by_no_mode[_meta_key_without_mode(b, L, meta)]
            if str(x["mode"]) != str(mode)
            and x["record"]["density"].shape == live["density"].shape
            and x["record"]["profile"].shape == live["profile"].shape
        ]
        if not finite_objects:
            rows.append({
                "mode_ablation_surface": "F1F2_mode_mode_stable_signature_vs_mode_sensitive_strength",
                "branching": int(b), "level": int(L), "mode": str(mode), **meta,
                "true_density_JS_component": true_js,
                "true_F1F2_signature_gap_mode_mode_stable_component": true_sig_gap,
                "true_F1F2_strength_gap_mode_sensitive_component": true_amp_gap,
                "true_F1F2_signature_zero_current": int(live_zero or rec_zero),
                "mode_ablation_signature_computed_status": "mode_ablation_no_mode_control_available",
            })
            continue
        for x in sorted(finite_objects, key=lambda z: str(z["mode"])):
            c_sig, c_amp, c_zero = _signature(x["record"]["profile"], tol)
            cjs = _js(live["density"], x["record"]["density"], tol)
            csig_gap = _signature_gap(live_sig, c_sig, tol)
            camp_gap = _amplitude_gap(live_amp, c_amp, tol)
            cscore = _combined(cjs, csig_gap, camp_gap)
            calign = _cosine(live_sig, c_sig)
            row = _mode_signature_row(
                b=b, L=L, mode=mode, meta=meta, control_mode=str(x["mode"]),
                true_js=true_js, true_sig_gap=true_sig_gap, true_amp_gap=true_amp_gap,
                true_score=true_score, true_alignment=true_alignment,
                control_js=cjs, control_sig_gap=csig_gap, control_amp_gap=camp_gap,
                control_score=cscore, control_alignment=calign, tol=tol,
            )
            row.update({
                "true_F1F2_live_profile_strength": float(live_amp),
                "true_F1F2_record_profile_strength": float(rec_amp),
                "control_F1F2_record_profile_strength": float(c_amp),
                "true_F1F2_signature_zero_current": int(live_zero or rec_zero),
                "control_F1F2_signature_zero_current": int(live_zero or c_zero),
                "mode_ablation_relations": "signature_is_profile_direction_normalized_strength_is_profile_norm",
            })
            rows.append(row)
    return rows


def mode_ablation_signature_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("mode_ablation_signature_computed_status", "unknown")) for r in rows})
    total = len(rows)
    sig = sum(1 for r in rows if str(r.get("mode_ablation_signature_computed_status", "")) == "true_record_mode_signature_parameter_dependence_supported_finite_object")
    shared = sum(1 for r in rows if str(r.get("mode_ablation_signature_computed_status", "")) == "mode_family_shares_birth_order_signature_but_differs_in_strength_control")
    close = sum(1 for r in rows if "as_close_or_closer" in str(r.get("mode_ablation_signature_computed_status", "")))
    return (
        "# Mode-ablation F1/F2 signature measurement\n\n"
        "This surface separates the F1/F2 skew-profile direction, treated as the mode-mode_stable birth-order signature, from the profile norm, treated as mode-sensitive response strength.  It tests whether mode-mismatched records are close because the tested mode family preserves the same oriented birth-order structure.\n\n"
        f"Rows: {total}.\n\n"
        f"True-record signature parameter_dependence finite_objects: {sig}/{total}.\n\n"
        f"Shared-signature but different-strength controls: {shared}/{total}.\n\n"
        f"Mode controls as close or closer than true record: {close}/{total}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
