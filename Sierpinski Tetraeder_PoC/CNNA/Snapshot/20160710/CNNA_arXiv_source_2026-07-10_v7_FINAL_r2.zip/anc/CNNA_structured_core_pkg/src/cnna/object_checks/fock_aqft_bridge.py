from __future__ import annotations

import math
from typing import List

import numpy as np

from cnna.core.directed_dtn import j_finite_object_from_SA
from cnna.core.math_utils import fro

from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)


FOCK_AQFT_COMPARISON_RUN_REGISTER = (
    {
        "condition_id": "one_particle_form_layer_relations",
        "condition_name": "DtN as one-particle form data, not local AQFT algebra",
        "finite_input": "live Schur/DtN response Lambda with S=(Lambda+Lambda^T)/2 and A=(Lambda-Lambda^T)/2",
        "target_question": "Can CNNA response data be read as real one-particle covariance/commutator data before second quantization?",
        "required_test": "positive S-support, skew A-rank, kernel quotient, no epsilon floor",
        "pass_condition": "support and skew metadata are explicit; null directions are quotiented or reported",
        "failure_meaning": "No stable one-particle form layer exists on the tested finite carrier",
        "current_core_status": "implemented_as_finite_comparison_surface",
    },
    {
        "condition_id": "quasifree_dominance_inequality",
        "condition_name": "finite quasifree positivity / dominance",
        "finite_input": "S positive form and A skew form on the same role/port carrier",
        "target_question": "Is |A(f,g)|^2 <= 4 S(f,f) S(g,g) on the tested carrier?",
        "required_test": "max dominance ratio over deterministic basis pairs and sampled role directions",
        "pass_condition": "max_ratio <= 1 + tolerance, or rank_bound explicitly reported",
        "failure_meaning": "The pair (S,A) cannot directly define the tested quasifree covariance/commutator pre-data without quotient/rescaling/domain restriction",
        "current_core_status": "implemented_as_finite_comparison_surface",
    },
    {
        "condition_id": "skew_locality_before_AQFT",
        "condition_name": "A-form collar/locality comparison",
        "finite_input": "skew form A between separated boundary/port directions",
        "target_question": "Does the skew form, not matrix-block commutation, vanish or fall for finite_object spacelike/collared support?",
        "required_test": "A-coupling between F2-separated or collared port directions, before Weyl/CAR algebra construction",
        "pass_condition": "layer-specific A-coupling decay/vanishing on the intended support relation",
        "failure_meaning": "The proposed support relation is not spacelike for the one-particle form layer",
        "current_core_status": "registered; needs multiscale-port retest beyond 3-role compression",
    },
    {
        "condition_id": "deterministic_polarization_from_SA",
        "condition_name": "deterministic polarization J from skew-over-positive data",
        "finite_input": "S and A on positive support",
        "target_question": "Does the deterministic polar J extracted from S^{-1/2} A S^{-1/2} agree with the CNNA F1/F2 orientation finite_object?",
        "required_test": "J-polar availability, even skew rank, J^2 approx -P, comparison to CNNA orientation plane",
        "pass_condition": "finite J-finite_object exists with small J^2 residual and stable F1/F2 alignment",
        "failure_meaning": "Second-quantized AQFT route may still exist, but the CNNA-derived J is not the deterministic one-particle polarization on the tested carrier",
        "current_core_status": "implemented_as_finite_comparison_surface; alignment remains a finite_core task",
    },
    {
        "condition_id": "statistics_from_dual_simplicial_geometry",
        "condition_name": "CCR/CAR/Boltzmann choice from dual simplicial-sector statistics",
        "finite_input": "tree-to-deformed-Sierpinski/simplicial dual, incidence numbers and face dimensions",
        "target_question": "Can Bose/Fermi/Boltzmann sector choice be derived from dual growth geometry rather than postulated?",
        "required_test": "Bianconi/NGF-style face occupancy conditions on CNNA-induced deformed simplicial complex",
        "pass_condition": "sector statistics follow from incidence constraints and live-response weights; sym SG/ST remains null comparison",
        "failure_meaning": "Statistics must remain an external choice for the Fock/AQFT route",
        "current_core_status": "registered as bridge condition; implemented in Bianconi statistics dependency_table surface",
    },
)


def fock_aqft_bridge_comparison_register_rows() -> List[dict]:
    return [dict(row) for row in FOCK_AQFT_COMPARISON_RUN_REGISTER]


def _dominance_ratio(S: np.ndarray, A: np.ndarray, tol: float) -> tuple[float, str]:
    n = int(S.shape[0])
    max_ratio = 0.0
    worst = "none"
    for i in range(n):
        for j in range(n):
            den = 4.0 * abs(float(S[i, i])) * abs(float(S[j, j]))
            if den <= max(tol, tol * max(1.0, fro(S))) ** 2:
                continue
            ratio = float((A[i, j] * A[i, j]) / den)
            if ratio > max_ratio:
                max_ratio = ratio
                worst = f"{i}:{j}"
    return float(max_ratio), worst


def fock_aqft_one_particle_comparison_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    tol = float(config.algebra_tol)
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            resp = regional_response(model, spec, "live")
            if resp is None:
                rows.append({
                    **meta,
                    "b": b,
                    "L": L,
                    "mode": mode,
                    "state": "live",
                    "one_particle_comparison_available": 0,
                    "computed_status": "one_particle_form_comparison_unavailable",
                })
                continue
            S = resp.symmetric_role
            A = resp.skew_role
            dominance, worst = _dominance_ratio(S, A, tol)
            J, jmeta = j_finite_object_from_SA(S, A, tol=max(tol, 1.0e-10))
            rankS = int(resp.density_metadata.get("density_support_rank", 0))
            skew_svals = np.linalg.svd(A, compute_uv=False) if A.size else np.array([], dtype=float)
            skew_condition = max(tol, tol * max(1.0, float(np.max(skew_svals)) if skew_svals.size else 0.0))
            skew_rank = int(np.sum(skew_svals > skew_condition)) if skew_svals.size else 0
            dominance_ok = int(dominance <= 1.0 + max(1.0e-8, 100.0 * tol))
            j_ok = int(jmeta.get("available", 0) == 1 and float(jmeta.get("J_square_minus_negative_projector_error", math.inf)) <= 1.0e-6)
            if rankS < 2:
                computed_status = "one_particle_form_support_too_small_control"
            elif dominance_ok and j_ok:
                computed_status = "one_particle_quasifree_polarization_finite_object"
            elif dominance_ok:
                computed_status = "one_particle_quasifree_dominance_finite_object_polarization_unresolved"
            else:
                computed_status = "one_particle_quasifree_dominance_obstructed"
            rows.append({
                **meta,
                "b": b,
                "L": L,
                "mode": mode,
                "state": "live",
                "one_particle_comparison_available": 1,
                "S_support_rank": rankS,
                "skew_rank": skew_rank,
                "skew_rank_even": int(skew_rank % 2 == 0),
                "max_quasifree_dominance_ratio_A2_over_4SS": dominance,
                "worst_dominance_basis_pair": worst,
                "quasifree_dominance_ok": dominance_ok,
                "deterministic_polarization_available": int(jmeta.get("available", 0)),
                "deterministic_polarization_reason": jmeta.get("reason", ""),
                "deterministic_polarization_J2_error": jmeta.get("J_square_minus_negative_projector_error", math.nan),
                "deterministic_polarization_skew_rank": jmeta.get("skew_rank", -1),
                "deterministic_polarization_S_support_rank": jmeta.get("S_support_rank", -1),
                "computed_status": computed_status,
            })
    return rows


def fock_aqft_bridge_report(register_rows: List[dict], comparison_rows: List[dict]) -> str:
    from collections import Counter
    counts = Counter(r.get("computed_status", "") for r in comparison_rows)
    lines = [
        "# Emergent Fock/AQFT bridge dependency_table",
        "",
        "This surface is the internal bridge register of the AQFT path: DtN responses are treated as a real one-particle form layer, not as local AQFT algebras themselves.  AQFT-like local von Neumann algebras may only emerge after a standard-subspace/Fock/GNS construction over these forms.",
        "",
        "## Condition register",
        "",
    ]
    for row in register_rows:
        lines.append(f"- `{row['condition_id']}`: {row['target_question']}  Status: {row['current_core_status']}.")
    lines.extend(["", "## Finite one-particle comparison computed_status_rows", ""])
    for k, v in sorted(counts.items()):
        lines.append(f"- {k}: {v}")
    lines.extend([
        "",
        "Condition: passing these comparisons would not prove an AQFT net.  It would only justify applying a CCR/CAR/standard-subspace construction in a later construction_step.  The statistics choice is deliberately deferred to the dual simplicial/Bianconi condition rather than inserted as an axiom.",
    ])
    return "\n".join(lines) + "\n"
