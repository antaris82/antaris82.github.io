from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _measure_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"), row.get("level"), row.get("mode"), row.get("region_id"), row.get("genealogical_corridor_length")
    )


def _measure_index(measure_rows: List[dict]) -> Dict[Tuple[object, ...], dict]:
    return {_measure_key(r): r for r in measure_rows if "two_component_history_measure_additive" in r}


def _per(value: float, measure: float) -> float:
    return float(value / max(measure, 1.0e-300)) if math.isfinite(value) and math.isfinite(measure) and measure > 0.0 else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("geometry_surface"), row.get("branching"), row.get("mode"), row.get("geometry_layer"))


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[dict]] = defaultdict(list)
    for r in rows:
        try:
            c = int(r.get("genealogical_corridor_length", -1))
        except Exception:
            c = -1
        if c >= 0:
            by_c[c].append(r)
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"oriented_history_geometry_track_computed_status": "oriented_history_geometry_insufficient_corridor_track"}
    first, last = cs[0], cs[-1]
    raw_f = _median(_finite(r.get("geometry_raw_rank_bound")) for r in by_c[first])
    raw_l = _median(_finite(r.get("geometry_raw_rank_bound")) for r in by_c[last])
    per_f = _median(_finite(r.get("geometry_rank_bound_per_two_component_measure")) for r in by_c[first])
    per_l = _median(_finite(r.get("geometry_rank_bound_per_two_component_measure")) for r in by_c[last])
    raw_decay = math.isfinite(raw_f) and math.isfinite(raw_l) and raw_l < raw_f - max(tol, tol * max(1.0, abs(raw_f)))
    per_decay = math.isfinite(per_f) and math.isfinite(per_l) and per_l < per_f - max(tol, tol * max(1.0, abs(per_f)))
    if math.isfinite(raw_l) and raw_l <= tol:
        computed_status = "oriented_history_geometry_exact_zero_or_tensor_finite_object"
    elif raw_decay and per_decay:
        computed_status = "oriented_history_geometry_improves_with_corridor_finite_object"
    elif per_decay:
        computed_status = "oriented_history_geometry_improves_only_after_F1F2_history_normalization_control"
    elif math.isfinite(per_f) and math.isfinite(per_l) and per_l > per_f + max(tol, tol * max(1.0, abs(per_f))):
        computed_status = "oriented_history_geometry_worsens_with_corridor_observed"
    else:
        computed_status = "oriented_history_geometry_no_monotone_improvement_observed"
    return {
        "oriented_history_geometry_corridor_count": int(len(cs)),
        "oriented_history_geometry_first_corridor": int(first),
        "oriented_history_geometry_last_corridor": int(last),
        "raw_rank_bound_first_corridor_median": raw_f,
        "raw_rank_bound_last_corridor_median": raw_l,
        "rank_bound_per_two_component_measure_first_corridor_median": per_f,
        "rank_bound_per_two_component_measure_last_corridor_median": per_l,
        "oriented_history_geometry_track_computed_status": computed_status,
    }


def oriented_history_geometry_rows(
    measure_rows: List[dict],
    locality_rows: List[dict],
    split_rows: List[dict],
    complement_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Re-evaluate locality, split, and complement using the two-component measure.

    The previous 8/9 geometry normalization used only the density JS
    component.  This surface uses
    `JS(live,record) + F1/Fdirected_skew_2form_profile_gap` so that geometry is read
    relative to the birth-order-sensitive antisymmetric structure.
    """
    midx = _measure_index(measure_rows)
    rows: List[dict] = []

    for r in locality_rows:
        m = midx.get(_measure_key(r), {})
        measure = _finite(m.get("two_component_history_measure_additive"))
        js = _finite(m.get("JS_live_record_no_epsilon"))
        fgap = _finite(m.get("F1F2_profile_gap_live_record"))
        raw = _finite(r.get("cluster_rank_bound_norm"))
        per = _per(raw, measure)
        if not math.isfinite(measure):
            computed_status = "two_component_measure_unavailable_for_locality"
        elif raw <= tol:
            computed_status = "two_component_locality_zero_commutator_control"
        elif per < 10.0:
            computed_status = "two_component_locality_within_oriented_history_scale_finite_object"
        else:
            computed_status = "two_component_locality_exceeds_oriented_history_scale_observed"
        rows.append({
            "geometry_surface": "locality_commutator_per_two_component_history_measure",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "geometry_layer": r.get("live_cluster_layer"),
            "JS_live_record_no_epsilon": js,
            "F1F2_profile_gap_live_record": fgap,
            "two_component_history_measure_additive": measure,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_two_component_measure": per,
            "source_computed_status": r.get("live_cluster_track_computed_status"),
            "oriented_history_geometry_row_computed_status": computed_status,
        })

    for r in split_rows:
        m = midx.get(_measure_key(r), {})
        measure = _finite(m.get("two_component_history_measure_additive"))
        js = _finite(m.get("JS_live_record_no_epsilon"))
        fgap = _finite(m.get("F1F2_profile_gap_live_record"))
        raw = _finite(r.get("refined_tensor_dimension_residual", r.get("split_residual_raw", math.nan)))
        per = _per(raw, measure)
        if not math.isfinite(measure):
            computed_status = "two_component_measure_unavailable_for_split"
        elif raw <= tol:
            computed_status = "two_component_split_tensor_finite_object"
        elif per < 10.0:
            computed_status = "two_component_split_residual_within_oriented_history_scale_control"
        else:
            computed_status = "two_component_split_residual_exceeds_oriented_history_scale_observed"
        rows.append({
            "geometry_surface": "split_residual_per_two_component_history_measure",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "geometry_layer": r.get("refined_split_layer", r.get("split_layer", "split")),
            "JS_live_record_no_epsilon": js,
            "F1F2_profile_gap_live_record": fgap,
            "two_component_history_measure_additive": measure,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_two_component_measure": per,
            "source_computed_status": r.get("refined_split_track_computed_status", r.get("collared_split_refined_basis_computed_status")),
            "oriented_history_geometry_row_computed_status": computed_status,
        })

    for r in complement_rows:
        m = midx.get(_measure_key(r), {})
        measure = _finite(m.get("two_component_history_measure_additive"))
        js = _finite(m.get("JS_live_record_no_epsilon"))
        fgap = _finite(m.get("F1F2_profile_gap_live_record"))
        raw = max(
            _finite(r.get("complement_into_region_commutant_residual")),
            _finite(r.get("region_commutant_into_complement_residual")),
            _finite(r.get("region_into_complement_commutant_residual")),
        )
        per = _per(raw, measure)
        if not math.isfinite(measure):
            computed_status = "two_component_measure_unavailable_for_complement"
        elif int(r.get("two_sided_duality_ok", 0) or 0) == 1 and raw <= tol:
            computed_status = "two_component_complement_two_sided_finite_object"
        elif int(r.get("one_sided_inclusion_ok", 0) or 0) == 1 and per < 10.0:
            computed_status = "two_component_complement_one_sided_within_oriented_history_scale_finite_object"
        elif per < 10.0:
            computed_status = "two_component_complement_error_within_oriented_history_scale_control"
        else:
            computed_status = "two_component_complement_error_exceeds_oriented_history_scale_observed"
        rows.append({
            "geometry_surface": "complement_error_per_two_component_history_measure",
            "branching": r.get("branching"), "level": r.get("level"), "mode": r.get("mode"),
            "region_id": r.get("region_id"), "region_family": r.get("region_family"),
            "genealogical_corridor_length": r.get("genealogical_corridor_length"),
            "geometry_layer": "finite_complement_relations",
            "finite_complement_type": r.get("finite_complement_type"),
            "JS_live_record_no_epsilon": js,
            "F1F2_profile_gap_live_record": fgap,
            "two_component_history_measure_additive": measure,
            "geometry_raw_rank_bound": raw,
            "geometry_rank_bound_per_two_component_measure": per,
            "one_sided_inclusion_ok": int(r.get("one_sided_inclusion_ok", 0) or 0),
            "two_sided_duality_ok": int(r.get("two_sided_duality_ok", 0) or 0),
            "source_computed_status": r.get("finite_complement_computed_status"),
            "oriented_history_geometry_row_computed_status": computed_status,
        })

    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        tracks[_track_key(row)].append(row)
    summaries = {k: _summarize_track(v, tol) for k, v in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def oriented_history_geometry_report(rows: List[dict]) -> str:
    surfaces = sorted({str(r.get("geometry_surface", "unknown")) for r in rows})
    row_computed_status_rows = sorted({str(r.get("oriented_history_geometry_row_computed_status", "unknown")) for r in rows})
    track_computed_status_rows = sorted({str(r.get("oriented_history_geometry_track_computed_status", "unknown")) for r in rows if "oriented_history_geometry_track_computed_status" in r})
    return (
        "# Oriented two-component history geometry\n\n"
        "This surface re-evaluates locality, split, and complement derived_quantity rows using the two-component history measure `JS(live,record) + F1/F2 skew 2-form profile gap`.  It does not assert locality, split, or Haag duality; it asks whether their finite rank_bound magnitudes are small relative to the density-plus-orientation HistoryMeasure.\n\n"
        "Surfaces: `" + "`, `".join(surfaces) + "`.\n\n"
        "Row computed_status_rows: `" + "`, `".join(row_computed_status_rows) + "`.\n\n"
        "Track computed_status_rows: `" + "`, `".join(track_computed_status_rows) + "`.\n"
    )
