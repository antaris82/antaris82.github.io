from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    finite_tomita_star_metrics,
    genealogical_corridor_metadata,
    local_operator_algebras,
    state_pair_backreaction_algebras,
)
from cnna.core.entropy_quantities import (
    jensen_shannon_divergence_no_epsilon,
    quantum_relative_entropy_no_epsilon,
    record_live_entropy_metrics,
    von_neumann_entropy_no_epsilon,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Sequence[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _pearson(xs: Sequence[float], ys: Sequence[float]) -> float:
    pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(pairs) < 2:
        return math.nan
    x = np.array([p[0] for p in pairs], dtype=float)
    y = np.array([p[1] for p in pairs], dtype=float)
    x = x - float(np.mean(x))
    y = y - float(np.mean(y))
    den = float(np.linalg.norm(x) * np.linalg.norm(y))
    return float((x @ y) / den) if den > 0.0 else math.nan


def inherited_uniform_node_density_for_role_basis(role_names: Sequence[str], roles: Dict[str, Sequence[int]], *, tol: float = 1.0e-12) -> Tuple[np.ndarray, dict]:
    """Push the uniform boundary-node measure through the compressed role basis.

    For the standard CNNA role basis the role vectors are normalized indicators
    over disjoint node sets.  Uniform node mass therefore induces diagonal role
    weights n_role / n_boundary, not an external epsilon-floor and not a new
    physical state.  It is a deterministic provenance/carrier reference inherited
    from the finite node counting measure.

    If a future role basis is not recognized by name, the helper falls back to
    a maximally mixed role density and records that fallback explicitly.
    """
    names = [str(x) for x in role_names]
    dim = len(names)
    counts: List[float] = []
    source: List[str] = []
    for name in names:
        if name in roles:
            c = len(list(roles.get(name, [])))
            key = name
        elif "lca" in name.lower():
            c = len(list(roles.get("C_lca", [])))
            key = "C_lca"
        elif "b1" in name.lower() or "left" in name.lower():
            c = len(list(roles.get("B1_front", [])))
            key = "B1_front"
        elif "b2" in name.lower() or "right" in name.lower():
            c = len(list(roles.get("B2_front", [])))
            key = "B2_front"
        else:
            c = 0
            key = "unresolved"
        counts.append(float(max(0, c)))
        source.append(key)
    total = float(sum(counts))
    if dim <= 0:
        D = np.zeros((0, 0), dtype=float)
        computed_status = "uniform_node_density_empty_role_basis"
    elif total <= tol:
        D = np.eye(dim, dtype=float) / float(dim)
        counts = [1.0 for _ in range(dim)]
        source = ["maximally_mixed_role_fallback" for _ in range(dim)]
        total = float(dim)
        computed_status = "uniform_node_density_role_fallback_control"
    else:
        D = np.diag(np.array(counts, dtype=float) / total)
        computed_status = "inherited_uniform_node_density_on_role_basis"
    trace = float(np.trace(D)) if D.size else 0.0
    return D, {
        "uniform_reference_relations": "uniform_boundary_node_measure_pushed_to_role_density",
        "uniform_reference_computed_status": computed_status,
        "uniform_reference_role_names": "|".join(names),
        "uniform_reference_role_count_sources": "|".join(source),
        "uniform_reference_role_counts": "|".join(str(int(c)) for c in counts),
        "uniform_reference_total_node_count": int(round(total)),
        "uniform_reference_density_trace": trace,
        "uniform_reference_trace_ok": int(abs(trace - 1.0) <= 1.0e-9) if dim > 0 else 0,
        "uniform_reference_density_min_diag": float(np.min(np.diag(D))) if D.size else math.nan,
        "uniform_reference_density_max_diag": float(np.max(np.diag(D))) if D.size else math.nan,
    }


def _distance_metrics(name: str, rho: np.ndarray, sigma: np.ndarray, tol: float) -> dict:
    d_rs, m_rs = quantum_relative_entropy_no_epsilon(rho, sigma, tol)
    d_sr, m_sr = quantum_relative_entropy_no_epsilon(sigma, rho, tol)
    js, m_js = jensen_shannon_divergence_no_epsilon(rho, sigma, tol)
    diff = 0.5 * (rho + rho.T) - 0.5 * (sigma + sigma.T)
    trace_norm = float(np.sum(np.linalg.svd(diff, compute_uv=False))) if diff.size else math.nan
    fro_gap = float(fro(diff)) if diff.size else math.nan
    directional = math.nan
    if math.isfinite(d_rs) and math.isfinite(d_sr):
        den = d_rs + d_sr
        directional = float((d_rs - d_sr) / den) if abs(den) > 1.0e-300 else 0.0
    return {
        f"D_{name}_forward_no_epsilon": float(d_rs) if math.isfinite(d_rs) else math.inf,
        f"D_{name}_reverse_no_epsilon": float(d_sr) if math.isfinite(d_sr) else math.inf,
        f"{name}_forward_support_in_reference": int(m_rs.get("relative_entropy_support_inclusion_ok", 0)),
        f"{name}_reverse_support_in_reference": int(m_sr.get("relative_entropy_support_inclusion_ok", 0)),
        f"{name}_forward_support_leakage": float(m_rs.get("relative_entropy_support_leakage", math.nan)),
        f"{name}_reverse_support_leakage": float(m_sr.get("relative_entropy_support_leakage", math.nan)),
        f"JS_{name}_no_epsilon": float(js) if math.isfinite(js) else math.inf,
        f"trace_distance_{name}": float(0.5 * trace_norm) if math.isfinite(trace_norm) else math.nan,
        f"frobenius_gap_{name}": fro_gap,
        f"directed_entropy_asymmetry_{name}": directional,
        f"{name}_js_support_rule": str(m_js.get("js_divergence_support_rule", "unknown")),
    }


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("mode"), row.get("genealogical_corridor_length"))


def _augment_track_summaries(rows: List[dict]) -> None:
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        if row.get("measure_surface") == "history_live_measure_finite_object":
            tracks[_track_key(row)].append(row)
    for key, xs in tracks.items():
        by_l: Dict[int, List[dict]] = defaultdict(list)
        for r in xs:
            by_l[int(r.get("level", -1))].append(r)
        levels = sorted(k for k in by_l if k >= 0)
        js_by_l = {L: _median([_finite(r.get("JS_live_record_no_epsilon")) for r in by_l[L]]) for L in levels}
        b_by_l = {L: _median([_finite(r.get("backreaction_current_norm")) for r in by_l[L]]) for L in levels}
        gain_by_l = {L: _median([_finite(r.get("record_tracking_gain_over_uniform")) for r in by_l[L]]) for L in levels}
        if len(levels) >= 2:
            first, last = levels[0], levels[-1]
            if math.isfinite(js_by_l[first]) and math.isfinite(js_by_l[last]) and js_by_l[last] > js_by_l[first]:
                js_trend = "history_live_js_deepens_with_level"
            elif math.isfinite(js_by_l[first]) and math.isfinite(js_by_l[last]) and js_by_l[last] < js_by_l[first]:
                js_trend = "history_live_js_decreases_with_level"
            else:
                js_trend = "history_live_js_level_stable_or_unresolved"
            if math.isfinite(gain_by_l[first]) and math.isfinite(gain_by_l[last]) and gain_by_l[last] > gain_by_l[first]:
                gain_trend = "record_tracking_gain_over_uniform_increases_with_level"
            elif math.isfinite(gain_by_l[first]) and math.isfinite(gain_by_l[last]) and gain_by_l[last] < gain_by_l[first]:
                gain_trend = "record_tracking_gain_over_uniform_decreases_with_level"
            else:
                gain_trend = "record_tracking_gain_over_uniform_level_stable_or_unresolved"
            track_meta = {
                "history_measure_track_level_count": int(len(levels)),
                "history_measure_first_level": int(first),
                "history_measure_last_level": int(last),
                "JS_live_record_first_level_median": float(js_by_l[first]),
                "JS_live_record_last_level_median": float(js_by_l[last]),
                "backreaction_current_norm_first_level_median": float(b_by_l[first]) if math.isfinite(b_by_l[first]) else math.nan,
                "backreaction_current_norm_last_level_median": float(b_by_l[last]) if math.isfinite(b_by_l[last]) else math.nan,
                "record_tracking_gain_first_level_median": float(gain_by_l[first]) if math.isfinite(gain_by_l[first]) else math.nan,
                "record_tracking_gain_last_level_median": float(gain_by_l[last]) if math.isfinite(gain_by_l[last]) else math.nan,
                "history_live_js_level_trend": js_trend,
                "record_tracking_gain_level_trend": gain_trend,
            }
        else:
            track_meta = {
                "history_measure_track_level_count": int(len(levels)),
                "history_live_js_level_trend": "history_measure_level_trend_unavailable",
                "record_tracking_gain_level_trend": "record_tracking_gain_level_trend_unavailable",
            }
        # Correlations are track-local, not property statements.
        all_js = [_finite(r.get("JS_live_record_no_epsilon")) for r in xs]
        all_b = [_finite(r.get("backreaction_current_norm")) for r in xs]
        all_mod = [_finite(r.get("modular_spread_live")) for r in xs]
        track_meta.update({
            "history_measure_track_row_count": int(len(xs)),
            "corr_JS_live_record_vs_B_norm": _pearson(all_js, all_b),
            "corr_JS_live_record_vs_live_modular_spread": _pearson(all_js, all_mod),
        })
        for r in xs:
            r.update(track_meta)


def history_live_common_measure_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = regional_response(model, spec, "live")
            record = regional_response(model, spec, "record")
            if live is None or record is None:
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "measure_surface": "history_live_measure_finite_object",
                    "common_measure_computed_status": "response_unavailable",
                })
                continue

            uniform, uniform_meta = inherited_uniform_node_density_for_role_basis(live.role_names, spec.roles, tol=config.algebra_tol)
            lr = record_live_entropy_metrics(live.density, record.density, tol=config.algebra_tol)
            lu = _distance_metrics("live_uniform", live.density, uniform, config.algebra_tol)
            ru = _distance_metrics("record_uniform", record.density, uniform, config.algebra_tol)
            ll = record_live_entropy_metrics(live.density, live.density, tol=config.algebra_tol)
            bpair = state_pair_backreaction_algebras(model, spec, "live", "record", config.algebra_tol, config.max_algebra_iter)
            bmeta = bpair.get("__metadata__", {}) if bpair is not None else {}
            bnorm = _finite(bmeta.get("backreaction_current_norm", math.nan))
            try:
                live_alg = local_operator_algebras(live, tol=config.algebra_tol, max_iter=config.max_algebra_iter)["full_regional_response"]
                tomita_meta = finite_tomita_star_metrics(live_alg, live.density, config.algebra_tol, orientation_operator=live.skew_role, orientation_carrier_norm=fro(live.symmetric_role))
            except Exception as exc:
                tomita_meta = {"history_measure_tomita_metric_error": f"{type(exc).__name__}:{exc}"}
            js_lr = _finite(lr.get("jensen_shannon_live_record_no_epsilon"))
            js_lu = _finite(lu.get("JS_live_uniform_no_epsilon"))
            js_ru = _finite(ru.get("JS_record_uniform_no_epsilon"))
            null_js = _finite(ll.get("jensen_shannon_live_record_no_epsilon"))
            gain = float(js_lu - js_lr) if math.isfinite(js_lu) and math.isfinite(js_lr) else math.nan
            excess = float(js_lr - min(js_lu, js_ru)) if math.isfinite(js_lu) and math.isfinite(js_ru) and math.isfinite(js_lr) else math.nan
            efficiency = float(js_lr / max(bnorm, 1.0e-300)) if math.isfinite(js_lr) and math.isfinite(bnorm) and bnorm > 0.0 else math.nan
            bounded_js = int(math.isfinite(js_lr) and js_lr >= -config.algebra_tol and js_lr <= math.log(2.0) + 1.0e-8)
            null_pass = int(math.isfinite(null_js) and abs(null_js) <= max(config.algebra_tol, 1.0e-12))
            if not bounded_js:
                computed_status = "history_live_js_measure_boundedness_failed"
            elif not null_pass:
                computed_status = "history_live_entropy_null_control_failed"
            elif gain > config.algebra_tol:
                computed_status = "record_tracks_live_better_than_uniform_measure_finite_object"
            elif gain < -config.algebra_tol:
                computed_status = "uniform_reference_closer_than_record_control"
            else:
                computed_status = "record_uniform_tracking_tie_or_unresolved_control"
            if lr.get("live_support_in_record_support", 0) == 0:
                directed_reference = "directed_relative_entropy_infinite_record_not_absolute_reference"
            else:
                directed_reference = "directed_relative_entropy_finite_record_reference_finite_object"
            rows.append({
                "branching": b,
                "level": L,
                "mode": mode,
                **meta,
                "measure_surface": "history_live_measure_finite_object",
                "physics_state": "live",
                "history_reference": "record",
                "deterministic_carrier_reference": "inherited_uniform_boundary_node_measure",
                **live.density_metadata,
                **uniform_meta,
                "entropy_live": float(von_neumann_entropy_no_epsilon(live.density, config.algebra_tol)),
                "entropy_record": float(von_neumann_entropy_no_epsilon(record.density, config.algebra_tol)),
                "entropy_uniform_inherited_node": float(von_neumann_entropy_no_epsilon(uniform, config.algebra_tol)),
                "D_live_given_record_no_epsilon": lr.get("D_live_given_record_no_epsilon", math.nan),
                "D_record_given_live_no_epsilon": lr.get("D_record_given_live_no_epsilon", math.nan),
                "live_support_in_record_support": lr.get("live_support_in_record_support", 0),
                "record_support_in_live_support": lr.get("record_support_in_live_support", 0),
                "live_into_record_support_leakage": lr.get("live_into_record_support_leakage", math.nan),
                "record_into_live_support_leakage": lr.get("record_into_live_support_leakage", math.nan),
                "JS_live_record_no_epsilon": lr.get("jensen_shannon_live_record_no_epsilon", math.nan),
                "trace_distance_live_record_density": lr.get("trace_distance_live_record_density", math.nan),
                "frobenius_density_gap_live_record": lr.get("frobenius_density_gap_live_record", math.nan),
                **lu,
                **ru,
                **bmeta,
                "modular_spread_live": tomita_meta.get("modular_spectrum_spread", math.nan),
                "modular_log_span_live": tomita_meta.get("modular_spectrum_log_span", math.nan),
                "tomita_orientation_residual_live_control": tomita_meta.get("tomita_conjuconditions_cnna_orientation_to_negative_residual", math.nan),
                "record_tracking_gain_over_uniform": float(gain) if math.isfinite(gain) else math.nan,
                "history_live_excess_over_nearest_uniform_distance": float(excess) if math.isfinite(excess) else math.nan,
                "JS_live_record_per_backreaction_current_norm": float(efficiency) if math.isfinite(efficiency) else math.nan,
                "history_live_js_bounded_by_log2": bounded_js,
                "identical_history_entropy_null_control_value": float(null_js) if math.isfinite(null_js) else math.nan,
                "identical_history_entropy_null_control_passed": null_pass,
                "directed_relative_entropy_reference_computed_status": directed_reference,
                "common_measure_computed_status": computed_status,
            })
    _augment_track_summaries(rows)
    return rows


def history_live_common_measure_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("common_measure_computed_status", "unknown")) for r in rows})
    directed = sorted({str(r.get("directed_relative_entropy_reference_computed_status", "unknown")) for r in rows if "directed_relative_entropy_reference_computed_status" in r})
    trends = sorted({str(r.get("history_live_js_level_trend", "unknown")) for r in rows if "history_live_js_level_trend" in r})
    gains = [_finite(r.get("record_tracking_gain_over_uniform")) for r in rows]
    pos_gain = sum(1 for x in gains if math.isfinite(x) and x > 0.0)
    neg_gain = sum(1 for x in gains if math.isfinite(x) and x < 0.0)
    return (
        "# History/live common measure measurement\n\n"
        "This surface treats `record` as fixed birth history and `live` as the reference physics carrier.  "
        "The inherited uniform node measure is used only as a deterministic provenance/carrier reference: uniform mass on the finite boundary nodes is pushed through the role basis as role weights.  "
        "This prevents the live-record entropy from being confused with mere deviation from a trivial count carrier.\n\n"
        "Reference finite finite_object: `JS_live_record_no_epsilon`, because it is symmetric, finite under exact support relations, non-negative, and bounded by log(2).  "
        "Directed relative entropy remains a separate orientation/reference derived_quantity and may be infinite when record is not an absolute support reference for live.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Directed-reference computed_status_rows: `" + "`, `".join(directed) + "`.\n\n"
        f"Record-tracking gain over inherited uniform carrier: positive rows={pos_gain}, negative rows={neg_gain}.\n\n"
        "Level trends: `" + "`, `".join(trends) + "`.\n"
    )
