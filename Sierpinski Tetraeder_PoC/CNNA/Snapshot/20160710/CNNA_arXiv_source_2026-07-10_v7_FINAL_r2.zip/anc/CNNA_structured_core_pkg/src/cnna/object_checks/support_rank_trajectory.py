from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    regional_response,
    sibling_pair_regions,
)
from .observable_state_rows import state_relations_fields, support_loss_interpretation


def _mean(xs: List[float]) -> float:
    ys = [x for x in xs if math.isfinite(x)]
    return float(sum(ys) / len(ys)) if ys else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("mode"), row.get("state"))


def _trend(first: float, last: float, name: str) -> str:
    if not math.isfinite(first) or not math.isfinite(last):
        return f"{name}_trend_unavailable"
    condition = 1.0e-12 * max(1.0, abs(first), abs(last))
    if last > first + condition:
        return f"{name}_increases_with_level"
    if last < first - condition:
        return f"{name}_decreases_with_level"
    return f"{name}_level_stable_finite_object"


def support_rank_trajectory_rows(config: OperatorTestConfig) -> List[dict]:
    raw: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    raw.append({"branching": b, "level": L, "mode": mode, "state": state, "support_trajectory_row_computed_status": "response_unavailable"})
                    continue
                meta = resp.density_metadata
                ambient = int(meta.get("density_ambient_dim", resp.Lambda_role.shape[0]) or 0)
                support = int(meta.get("density_support_rank", 0) or 0)
                raw.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    "state": state,
                    "region_id": spec.region_id,
                    "density_computed_status": meta.get("density_computed_status", "unknown"),
                    "density_ambient_dim": ambient,
                    "density_support_rank": support,
                    "support_residual_dim": int(max(0, ambient - support)),
                    "support_fraction": float(support / ambient) if ambient else 0.0,
                    "density_negative_eigenvalue_count": int(meta.get("density_negative_eigenvalue_count", 0) or 0),
                    "density_clipped_negative_mass": float(meta.get("density_clipped_negative_mass", math.nan)),
                    "density_min_raw_eigenvalue": float(meta.get("density_min_raw_eigenvalue", math.nan)),
                    "density_max_raw_eigenvalue": float(meta.get("density_max_raw_eigenvalue", math.nan)),
                    **state_relations_fields(state, support, ambient),
                    "support_trajectory_row_computed_status": "support_level_state_only" if support < ambient else "full_support_state_without_epsilon_floor",
                })
    by_track_level: Dict[Tuple[object, ...], Dict[int, List[dict]]] = defaultdict(lambda: defaultdict(list))
    for r in raw:
        if "density_support_rank" in r:
            by_track_level[_track_key(r)][int(r.get("level", -1))].append(r)
    rows: List[dict] = []
    for key, by_level in sorted(by_track_level.items(), key=lambda kv: str(kv[0])):
        levels = sorted(L for L in by_level if L >= 0)
        support_frac: Dict[int, float] = {}
        support_rank: Dict[int, float] = {}
        residual: Dict[int, float] = {}
        neg_mass: Dict[int, float] = {}
        singular_count: Dict[int, int] = {}
        total_count: Dict[int, int] = {}
        for L in levels:
            rs = by_level[L]
            support_frac[L] = _mean([float(r.get("support_fraction", math.nan)) for r in rs])
            support_rank[L] = _mean([float(r.get("density_support_rank", math.nan)) for r in rs])
            residual[L] = _mean([float(r.get("support_residual_dim", math.nan)) for r in rs])
            neg_mass[L] = _mean([float(r.get("density_clipped_negative_mass", math.nan)) for r in rs])
            singular_count[L] = int(sum(1 for r in rs if str(r.get("density_computed_status", "")) == "singular_support_state"))
            total_count[L] = int(len(rs))
        if len(levels) >= 2:
            first_L, last_L = levels[0], levels[-1]
            frac_trend = _trend(support_frac[first_L], support_frac[last_L], "support_fraction")
            residual_trend = _trend(residual[first_L], residual[last_L], "support_residual")
            neg_trend = _trend(neg_mass[first_L], neg_mass[last_L], "negative_clipped_mass")
        else:
            first_L = last_L = levels[0] if levels else -1
            frac_trend = "support_fraction_insufficient_level_trajectory"
            residual_trend = "support_residual_insufficient_level_trajectory"
            neg_trend = "negative_clipped_mass_insufficient_level_trajectory"
        for L in levels:
            state = str(key[2])
            if state == "record" and ("decreases" in frac_trend or "increases" in residual_trend):
                trajectory_computed_status = "record_history_support_loss_expected_control"
            elif state == "record":
                trajectory_computed_status = "record_history_support_rank_control"
            elif state == "sym":
                trajectory_computed_status = "sym_null_support_rank_control"
            else:
                trajectory_computed_status = (
                    "live_support_loss_deepens_with_level_rank_bound_finite_object" if "decreases" in frac_trend or "increases" in residual_trend else
                    "live_support_rank_level_stable_finite_object" if "stable" in frac_trend else
                    "live_support_rank_limes_derived_quantity_insufficient"
                )
            rows.append({
                "branching": key[0],
                "mode": key[1],
                "state": state,
                **state_relations_fields(state),
                "level": L,
                "level_track_min": first_L,
                "level_track_max": last_L,
                "level_track_count": int(len(levels)),
                "mean_support_rank": support_rank.get(L, math.nan),
                "mean_support_fraction": support_frac.get(L, math.nan),
                "mean_support_residual_dim": residual.get(L, math.nan),
                "mean_clipped_negative_mass": neg_mass.get(L, math.nan),
                "singular_support_rows_at_level": singular_count.get(L, 0),
                "total_rows_at_level": total_count.get(L, 0),
                "singular_support_fraction_at_level": float(singular_count.get(L, 0) / max(1, total_count.get(L, 0))),
                "support_fraction_level_trend": frac_trend,
                "support_residual_level_trend": residual_trend,
                "negative_clipped_mass_level_trend": neg_trend,
                "support_rank_trajectory_computed_status": trajectory_computed_status,
                "support_rank_physics_interpretation": (
                    "record_support_loss_is_expected_history_incompleteness_not_live_physics_failure" if state == "record" else
                    "sym_support_is_null_control" if state == "sym" else
                    "live_support_is_reference_physics_carrier"
                ),
            })
    return rows


def support_rank_trajectory_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("support_rank_trajectory_computed_status", "unknown")) for r in rows})
    frac = sorted({str(r.get("support_fraction_level_trend", "unknown")) for r in rows})
    residual = sorted({str(r.get("support_residual_level_trend", "unknown")) for r in rows})
    return (
        "# Support-rank trajectory\n\n"
        "Tracks the no-epsilon GNS support rank for live/record/sym states over terminal level L.  "
        "In 5, live is the reference physics carrier, record is a historical birth-register control, and sym is a null control.  "
        "Record support loss is therefore expected historical incompleteness unless the separate record-anchor condition validates record as a physical anchor.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Support-fraction trends: `" + "`, `".join(frac) + "`.\n\n"
        "Support-residual trends: `" + "`, `".join(residual) + "`.\n"
    )
