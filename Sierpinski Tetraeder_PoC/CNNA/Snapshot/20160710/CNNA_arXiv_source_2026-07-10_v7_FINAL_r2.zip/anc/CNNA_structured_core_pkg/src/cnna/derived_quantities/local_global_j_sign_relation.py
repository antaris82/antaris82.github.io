from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import fro
from cnna.core.directed_dtn import (
    directed_schur_response_from_model,
    directed_environment_port_response_from_model,
    split_symmetric_skew,
    j_finite_object_from_SA,
    region_frontier_level,
)
from cnna.derived_quantities.directed_current_transport import _boundary_prefix_transport_matrix
from cnna.derived_quantities.j_orientation_projectivity import (
    _regions,
    _safe_eigs,
    _orientation_sign,
    _response_parts,
    _snapshot_A_cache,
    a_j_orientation_snapshot_rows,
)
from cnna.derived_quantities.structural_ledgers import is_reference_model


def _frontier_nodes(model: EmptySetGrowthModel, frontier_level: int) -> List[int]:
    return [n.nid for n in model.nodes if int(n.level) == int(frontier_level)]


def _choose_global_frontier_level(model: EmptySetGrowthModel, args) -> int:
    cap = int(getattr(args, "directed_frontier_cap", 6))
    max_boundary = int(getattr(args, "max_boundary", 3500))
    max_interior = int(getattr(args, "max_interior", 6000))
    max_level = min(int(model.L), cap)
    # root + all nodes at frontier are boundary.  Interior is all earlier levels
    # except root.  Choose deepest admissible frontier.
    for fl in range(max_level, 0, -1):
        bcount = 1 + len(_frontier_nodes(model, fl))
        icount = sum(1 for n in model.nodes if 0 < int(n.level) < fl)
        if bcount <= max_boundary and icount <= max_interior:
            return int(fl)
    return 0


def _global_boundary_sets(model: EmptySetGrowthModel, sign_relation: str, frontier_level: int):
    root = 0
    front = _frontier_nodes(model, frontier_level)
    if sign_relation in {"bulk_root_front", "bulk_root_front_env_port"}:
        boundary = [root] + front
        interior = [n.nid for n in model.nodes if 0 < int(n.level) < int(frontier_level)]
    elif sign_relation == "bulk_root_front_schured":
        # Root retained, front/bulk eliminated.  This intentionally has no F2
        # axis and is a negative control for global J.
        boundary = [root]
        interior = [n.nid for n in model.nodes if 0 < int(n.level) <= int(frontier_level)]
    elif sign_relation == "bulk_front_root_schured":
        # Front retained, root/bulk eliminated.  This has birth-order/front data
        # but no root/front F1 axis.
        boundary = front
        interior = [n.nid for n in model.nodes if 0 <= int(n.level) < int(frontier_level)]
    else:
        raise ValueError(f"unknown global boundary sign_relation: {sign_relation}")
    return list(dict.fromkeys(boundary)), list(dict.fromkeys(interior))


def _global_signed_basis(model: EmptySetGrowthModel, boundary: Sequence[int], sign_relation: str, env_port: bool = False):
    n = len(boundary) + (1 if env_port else 0)
    pos = {nid: i for i, nid in enumerate(boundary)}

    def normed(v: np.ndarray) -> np.ndarray:
        return v / max(float(np.linalg.norm(v)), EPS)

    root_vec = np.zeros(n, dtype=float)
    front_mean = np.zeros(n, dtype=float)
    birth_rank = np.zeros(n, dtype=float)
    if 0 in pos:
        root_vec[pos[0]] = 1.0
    front_nodes = [nid for nid in boundary if nid != 0]
    if front_nodes:
        for nid in front_nodes:
            front_mean[pos[nid]] = 1.0
        ranks = []
        for nid in front_nodes:
            addr = model.nodes[nid].address
            ranks.append(float(addr[0]) if len(addr) > 0 else 0.0)
        mean_rank = float(np.mean(ranks)) if ranks else 0.0
        for nid, r in zip(front_nodes, ranks):
            birth_rank[pos[nid]] = r - mean_rank
    raw = []
    names = []
    # F1 requires both root and front.  F2 requires at least two different root-child ranks.
    if np.linalg.norm(root_vec) > 0 and np.linalg.norm(front_mean) > 0:
        raw.append(normed(root_vec) - normed(front_mean))
        names.append("G_F1_root_front_contrast")
    if np.linalg.norm(birth_rank) > 1.0e-12:
        raw.append(birth_rank.copy())
        names.append("G_F2_front_birth_order_contrast")
    basis: List[np.ndarray] = []
    out_names: List[str] = []
    for name, v in zip(names, raw):
        u = v.copy()
        for q in basis:
            u -= float(q @ u) * q
        nn = float(np.linalg.norm(u))
        if nn > 1.0e-10:
            basis.append(u / nn)
            out_names.append(name)
    if not basis:
        return np.zeros((n, 0), dtype=float), [], 0
    return np.column_stack(basis), out_names, len(basis)


def _safe_response(model: EmptySetGrowthModel, state: str, sign_relation: str, boundary: Sequence[int], interior: Sequence[int], frontier_level: int):
    include_external = int(frontier_level) < int(model.L)
    if sign_relation == "bulk_root_front_env_port":
        return directed_environment_port_response_from_model(
            model,
            state,
            boundary,
            interior,
            matrix_sign_relation="out_degree",
        )
    return directed_schur_response_from_model(
        model,
        state,
        boundary,
        interior,
        include_external_degrees=include_external,
        matrix_sign_relation="out_degree",
    )


def global_j_boundary_sign_relation_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args) -> List[dict]:
    rows: List[dict] = []
    sign_relations = [
        "bulk_root_front",
        "bulk_root_front_env_port",
        "bulk_root_front_schured",
        "bulk_front_root_schured",
    ]
    for (b, L, mode, rev), model in sorted(models.items()):
        if rev:
            continue
        fl = _choose_global_frontier_level(model, args)
        for state in ["live", "record"]:
            for sign_relation in sign_relations:
                boundary, interior = _global_boundary_sets(model, sign_relation, fl)
                env_port = sign_relation == "bulk_root_front_env_port"
                base = {
                    "branching": int(b),
                    "level": int(L),
                    "mode": str(mode),
                    "state": state,
                    "reference_model": int(is_reference_model(str(mode), state)),
                    "boundary_sign_relation": sign_relation,
                    "frontier_level": int(fl),
                    "terminal_level": int(model.L),
                    "coarse_frontier_used": int(int(fl) < int(model.L)),
                    "n_boundary_input": len(boundary),
                    "n_interior": len(interior),
                    "global_scope": "finite_object_closed_global_system" if sign_relation == "bulk_root_front" and int(fl) == int(model.L) else "finite_boundary_sign_relation_measurement",
                }
                Q, qnames, qrank = _global_signed_basis(model, boundary, sign_relation, env_port=env_port)
                if qrank < 2:
                    reason = "missing_two_axis_global_signed_plane"
                    if sign_relation == "bulk_root_front_schured":
                        reason = "front_schured_no_F2_axis"
                    elif sign_relation == "bulk_front_root_schured":
                        reason = "root_schured_no_F1_root_front_axis"
                    rows.append({
                        **base,
                        "response_available": 0,
                        "global_signed_basis_rank": int(qrank),
                        "global_signed_basis_names": " ".join(qnames),
                        "J_global_available": 0,
                        "global_orientation_sign": 0,
                        "J_square_error": math.nan,
                        "S_plane_min_eig": math.nan,
                        "A_signed_omega": math.nan,
                        "missing_axis_reason": reason,
                        "computed_status": "j_sign_global_J_not_available_boundary_control",
                        "condition_note": "negative_control_or_axis_missing; no_global_i_fix",
                    })
                    continue
                res = _safe_response(model, state, sign_relation, boundary, interior, fl)
                if not res.ok or res.Lambda is None:
                    rows.append({
                        **base,
                        "response_available": 0,
                        "response_error": res.error,
                        "global_signed_basis_rank": int(qrank),
                        "global_signed_basis_names": " ".join(qnames),
                        "J_global_available": 0,
                        "global_orientation_sign": 0,
                        "J_square_error": math.nan,
                        "S_plane_min_eig": math.nan,
                        "A_signed_omega": math.nan,
                        "missing_axis_reason": "response_unavailable",
                        "computed_status": "j_sign_global_J_response_unavailable",
                        "condition_note": "finite_response_failure_not_sign_result",
                    })
                    continue
                S, A = split_symmetric_skew(res.Lambda)
                Splane = Q.T @ S @ Q
                Aplane = Q.T @ A @ Q
                J, info = j_finite_object_from_SA(Splane, Aplane, tol=max(float(getattr(args, "gns_tol", 1.0e-10)), 1.0e-12))
                mine, maxe, neg_mass, psd_ok = _safe_eigs(Splane)
                sign = _orientation_sign(Aplane)
                computed_status = "j_sign_global_root_front_J_reference_available" if int(info.get("available", 0) or 0) == 1 and sign != 0 else "j_sign_global_response_available_but_J_not_available"
                rows.append({
                    **base,
                    "response_available": 1,
                    "boundary_response_model": res.boundary_response_model,
                    "response_row_sum_residual": res.row_sum_residual,
                    "response_cond_KII": res.cond_KII,
                    "response_solve_residual": res.solve_residual,
                    "global_signed_basis_rank": int(qrank),
                    "global_signed_basis_names": " ".join(qnames),
                    "J_global_available": int(info.get("available", 0) or 0),
                    "global_orientation_sign": int(sign),
                    "J_square_error": info.get("J_square_minus_negative_projector_error", math.nan),
                    "J_skew_rank": info.get("skew_rank", math.nan),
                    "J_S_support_rank": info.get("S_support_rank", math.nan),
                    "S_plane_min_eig": mine,
                    "S_plane_max_eig": maxe,
                    "S_plane_negative_mass": neg_mass,
                    "S_plane_psd_tol_ok": psd_ok,
                    "A_signed_omega": float(Aplane[0, 1]) if Aplane.shape[0] >= 2 else math.nan,
                    "missing_axis_reason": "none",
                    "computed_status": computed_status,
                    "condition_note": "global_reference_available_does_not_fix_absolute_i; simultaneous_J_flip_remains_sign_relation",
                })
    return rows


def local_global_j_sign_comparison_rows(models: Dict[Tuple[int, int, str, bool], EmptySetGrowthModel], args, global_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    local_rows = a_j_orientation_snapshot_rows(models, args)
    # Use root+front as the reference global sign_relation for comparisons.
    global_index = {}
    for r in global_rows:
        if str(r.get("boundary_sign_relation", "")) != "bulk_root_front":
            continue
        global_index[(int(r.get("branching", -1)), int(r.get("level", -1)), str(r.get("mode", "")), str(r.get("state", "")))] = r
    for lr in local_rows:
        if int(lr.get("available", 0) or 0) != 1:
            continue
        key = (int(lr.get("branching", -1)), int(lr.get("level", -1)), str(lr.get("mode", "")), str(lr.get("state", "")))
        gr = global_index.get(key)
        base = {
            "branching": key[0], "level": key[1], "mode": key[2], "state": key[3],
            "reference_model": int(lr.get("reference_model", 0) or 0),
            "region_id": lr.get("region_id", ""),
            "region_pair_type": lr.get("region_pair_type", ""),
            "global_boundary_sign_relation": "bulk_root_front",
            "local_frontier_level": lr.get("frontier_level", ""),
            "local_coarse_frontier_used": lr.get("coarse_frontier_used", ""),
        }
        if gr is None or int(gr.get("J_global_available", 0) or 0) != 1:
            rows.append({**base, "available": 0, "computed_status": "local_global_comparison_unavailable_no_global_J"})
            continue
        lsign = int(lr.get("A_orientation_sign", 0) or 0)
        gsign = int(gr.get("global_orientation_sign", 0) or 0)
        rel = int(lsign * gsign) if lsign != 0 and gsign != 0 else 0
        flipped_local_sign = -lsign if lsign != 0 else 0
        flipped_global_sign = -gsign if gsign != 0 else 0
        flipped_rel = int(flipped_local_sign * flipped_global_sign) if flipped_local_sign != 0 and flipped_global_sign != 0 else 0
        flip_error = abs(flipped_rel - rel)
        rows.append({
            **base,
            "available": 1,
            "local_orientation_sign": lsign,
            "global_orientation_sign": gsign,
            "local_global_relative_sign": rel,
            "local_J_available": lr.get("J_available", 0),
            "global_J_available": gr.get("J_global_available", 0),
            "local_J_square_error": lr.get("J_square_error", math.nan),
            "global_J_square_error": gr.get("J_square_error", math.nan),
            "simultaneous_global_flip_local_sign": flipped_local_sign,
            "simultaneous_global_flip_global_sign": flipped_global_sign,
            "simultaneous_global_flip_relative_sign": flipped_rel,
            "flip_invariance_error": flip_error,
            "absolute_global_sign_fixed": 0,
            "computed_status": "local_sign_compared_to_global_reference_relative_only",
            "condition_note": "local_relative_sign_bound; absolute_global_J_to_minus_J_flip_free",
        })
    return rows


def local_global_j_sign_summary_rows(global_rows: Sequence[dict], comparison_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(int(r.get("branching", 0)), str(r.get("mode", ""))) for r in global_rows})
    for b, mode in keys:
        g = [r for r in global_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        c = [r for r in comparison_rows if int(r.get("branching", -1)) == b and str(r.get("mode", "")) == mode]
        rootfront = [r for r in g if str(r.get("boundary_sign_relation", "")) == "bulk_root_front"]
        rootctl = [r for r in g if str(r.get("boundary_sign_relation", "")) == "bulk_root_front_schured"]
        frontctl = [r for r in g if str(r.get("boundary_sign_relation", "")) == "bulk_front_root_schured"]
        env = [r for r in g if str(r.get("boundary_sign_relation", "")) == "bulk_root_front_env_port"]
        rootfront_ok = int(bool(rootfront) and all(int(r.get("J_global_available", 0) or 0) == 1 and int(r.get("global_orientation_sign", 0) or 0) != 0 for r in rootfront))
        controls_ok = int(bool(rootctl) and bool(frontctl) and all(int(r.get("J_global_available", 0) or 0) == 0 for r in rootctl + frontctl))
        env_ok = int(not env or any(int(r.get("J_global_available", 0) or 0) == 1 for r in env))
        comp_av = [r for r in c if int(r.get("available", 0) or 0) == 1]
        rels = sorted({int(r.get("local_global_relative_sign", 0) or 0) for r in comp_av if int(r.get("local_global_relative_sign", 0) or 0) != 0})
        local_rel_consistent = int(bool(comp_av) and len(rels) == 1)
        flip_ok = int(bool(comp_av) and all(float(r.get("flip_invariance_error", 1.0)) == 0.0 for r in comp_av))
        unmet_conditions: List[str] = []
        if not rootfront_ok:
            unmet_conditions.append("bulk_root_front_global_J_reference_not_available_all")
        if not controls_ok:
            unmet_conditions.append("axis_schur_controls_not_negative")
        if not local_rel_consistent:
            unmet_conditions.append("local_global_relative_signs_not_consistent")
        if not flip_ok:
            unmet_conditions.append("global_flip_not_mode_stable")
        computed_status = "local_J_sign_rigid_global_flip_free_finite_object" if not unmet_conditions else "J_sign_sign_relation_measurement_blocked_or_incomplete"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": int(is_reference_model(mode, "live")),
            "bulk_root_front_global_J_available_all": rootfront_ok,
            "axis_schur_negative_controls_ok": controls_ok,
            "env_port_reference_available_any": env_ok,
            "local_global_relative_sign_consistent": local_rel_consistent,
            "local_global_relative_sign_value": rels[0] if len(rels) == 1 else 0,
            "global_flip_invariance_ok": flip_ok,
            "absolute_global_sign_fixed": 0,
            "local_regions_compared": len(comp_av),
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "dependency_table_to_property_layer": "local_J_sign_bound_global_J_to_minus_J_free; ready_for_Cstar_boundary_dependency_table" if not unmet_conditions else "blocked_before_sign_dependency_table",
            "condition_note": "finite_sign_sign_relation_measurement_only; no_i_fix_no_Cstar_no_vN_no_KMS_no_TypeIII",
        })
    return rows


def write_local_global_j_sign_relation_report(outdir: Path, global_rows: Sequence[dict], comparison_rows: Sequence[dict], summary_rows: Sequence[dict]) -> None:
    reference = next((r for r in summary_rows if int(r.get("reference_model", 0) or 0) == 1), summary_rows[0] if summary_rows else {})
    p_global = next((r for r in global_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("boundary_sign_relation", "")) == "bulk_root_front" and str(r.get("state", "")) == "live"), next((r for r in global_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    p_comp = next((r for r in comparison_rows if int(r.get("reference_model", 0) or 0) == 1 and str(r.get("state", "")) == "live"), next((r for r in comparison_rows if int(r.get("reference_model", 0) or 0) == 1), {}))
    text = f"""# Local/global J-sign sign_relation measurement

## Purpose

6 tests the next x question after projective A/J orientation: whether local `J` signs are rigid relative to CNNA provenance while the absolute global flip `J -> -J` remains a sign_relation.

`sym` is not a physical comparison path here.  The measurement uses only the structural `live` and `record` A-layer.  The total-system boundary sign_relation is tested explicitly rather than assumed.

## Boundary sign_relations tested

```text
bulk_root_front            : root + frontier retained; finite_object global 2-axis system
bulk_root_front_env_port   : root + frontier retained plus aggregate outside port for coarse cuts
bulk_root_front_schured    : root retained, front schured; negative control, no F2 axis
bulk_front_root_schured    : front retained, root schured; negative control, no F1 root/front axis
```

## Reference summary

```text
computed_status  = {reference.get('computed_status', 'missing')}
unmet_conditions = {reference.get('unmet_conditions', 'missing')}
dependency_table  = {reference.get('dependency_table_to_property_layer', 'missing')}
```

## Selected global reference row

```text
boundary_sign_relation       = {p_global.get('boundary_sign_relation', 'n/a')}
state                     = {p_global.get('state', 'n/a')}
level                     = {p_global.get('level', 'n/a')}
frontier_level            = {p_global.get('frontier_level', 'n/a')}
coarse_frontier_used      = {p_global.get('coarse_frontier_used', 'n/a')}
J_global_available        = {p_global.get('J_global_available', 'n/a')}
global_orientation_sign   = {p_global.get('global_orientation_sign', 'n/a')}
J_square_error            = {p_global.get('J_square_error', 'n/a')}
S_plane_min_eig           = {p_global.get('S_plane_min_eig', 'n/a')}
A_signed_omega            = {p_global.get('A_signed_omega', 'n/a')}
computed_status                   = {p_global.get('computed_status', 'n/a')}
```

## Selected local/global comparison row

```text
state                         = {p_comp.get('state', 'n/a')}
level                         = {p_comp.get('level', 'n/a')}
region_id                     = {p_comp.get('region_id', 'n/a')}
local_orientation_sign         = {p_comp.get('local_orientation_sign', 'n/a')}
global_orientation_sign        = {p_comp.get('global_orientation_sign', 'n/a')}
local_global_relative_sign     = {p_comp.get('local_global_relative_sign', 'n/a')}
absolute_global_sign_fixed     = {p_comp.get('absolute_global_sign_fixed', 'n/a')}
flip_invariance_error          = {p_comp.get('flip_invariance_error', 'n/a')}
computed_status                        = {p_comp.get('computed_status', 'n/a')}
```

## Interpretation

A residual_le_tolerance 6 row means that the local finite `J` orientation sign is bound relative to the chosen CNNA provenance sign_relation and is consistent with the `bulk_root_front` global reference.  It also confirms that the simultaneous global flip `J -> -J` leaves relative signs mode_stable; therefore 6 does **not** fix a physical global `i` sign.

The negative controls are important: if the front is schured away, the F2 axis is absent; if the root is schured away, the F1 root/front axis is absent.  Those variants should not pretend to define a global two-axis `J` reference.

## Non-statements

No C*-completion, von Neumann algebra, KMS, Type III, Tomita--Takesaki, or strict `*`-homomorphism is stated.  this is a finite sign-sign_relation and boundary-sign_relation measurement for the finite-core dependency table.
"""
    (outdir / "LOCAL_GLOBAL_J_SIGN_RELATION_REPORT.md").write_text(text, encoding="utf-8")
