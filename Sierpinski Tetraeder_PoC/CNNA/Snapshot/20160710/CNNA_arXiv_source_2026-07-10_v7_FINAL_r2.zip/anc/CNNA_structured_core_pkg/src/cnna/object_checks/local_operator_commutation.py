from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    commutator_metrics,
    identical_history_backreaction_algebras,
    live_record_backreaction_algebras,
    local_operator_algebras,
    state_commutator_metric,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
    sibling_pair_regions,
)
from cnna.core.math_utils import fro


SEPARATED_PAIRS = [
    ("left_frontier_response", "right_frontier_response", "frontier_sibling_separated", "symmetric_boundary_layer"),
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "birth_cone_sibling_separated", "S_symmetric_carrier_layer"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "birth_cone_sibling_separated", "A_directed_skew_layer"),
    ("left_birth_cone_response", "right_birth_cone_response", "birth_cone_sibling_separated", "mixed_S_plus_A_response_layer"),
    ("positive_carrier_pair_response", "directed_current_pair_response", "carrier_current_same_cut", "S_A_same_cut_layer_split"),
]


def _computed_status(max_rel: float, state_abs: float, tol: float, layer: str, separation: str, layer_null_norm: float | None = None) -> str:
    if layer == "B_identical_history_null_control":
        if layer_null_norm is not None and layer_null_norm <= tol:
            return "identical_history_null_control_passed"
        return "identical_history_null_control_FAILED"
    if layer == "A_directed_skew_layer" and layer_null_norm is not None and layer_null_norm <= tol:
        return "vacuous_zero_layer_null_control"
    if layer == "symmetric_boundary_layer" and separation == "frontier_sibling_separated" and max_rel <= tol and state_abs <= tol:
        return "structurally_commuting_disjoint_support_control"
    if max_rel <= tol and state_abs <= tol:
        return "strict_commutation_finite_object"
    if max_rel <= 1.0e-7 or state_abs <= 1.0e-9:
        return "state_or_approx_commutation_finite_object"
    return "finite_noncommutation_observed"


def _append_commutator_row(rows: List[dict], base: dict, left_name: str, right_name: str, separation: str, layer: str, left, right, D, tol: float, *, layer_null_norm: float | None = None, extra: dict | None = None) -> None:
    met = commutator_metrics(left, right)
    state_abs = state_commutator_metric(left, right, D)
    rows.append({
        **base,
        **(extra or {}),
        "operator_layer": layer,
        "separation_sign_relation": separation,
        "left_operator_system": left_name,
        "right_operator_system": right_name,
        "left_dim": len(left.basis),
        "right_dim": len(right.basis),
        **met,
        "max_state_commutator_abs_no_epsilon": state_abs,
        "operator_layer_null_norm": float(layer_null_norm) if layer_null_norm is not None else "",
        "commutation_computed_status": _computed_status(float(met["max_relative_commutator"]), state_abs, tol, layer, separation, layer_null_norm),
    })


def local_operator_commutator_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        for spec in sibling_pair_regions(model, config):
            meta = region_size_meta(model, spec)
            b_algebras = live_record_backreaction_algebras(model, spec, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            b_null_algebras = identical_history_backreaction_algebras(model, spec, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "commutation_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                base = {"branching": b, "level": L, "mode": mode, **meta, "state": state, **resp.density_metadata}
                for left_name, right_name, separation, layer in SEPARATED_PAIRS:
                    layer_null_norm = fro(resp.skew_role) if layer == "A_directed_skew_layer" else None
                    _append_commutator_row(
                        rows,
                        base,
                        left_name,
                        right_name,
                        separation,
                        layer,
                        algebras[left_name],
                        algebras[right_name],
                        resp.density,
                        config.algebra_tol,
                        layer_null_norm=layer_null_norm,
                    )
                if b_algebras is not None:
                    b_meta = b_algebras.get("__metadata__", {})
                    _append_commutator_row(
                        rows,
                        base,
                        "restricted_backreaction_current_left_birth_cone",
                        "restricted_backreaction_current_right_birth_cone",
                        "birth_cone_sibling_separated_with_shared_lca_anchor",
                        "B_restricted_live_minus_record_layer",
                        b_algebras["backreaction_current_left_birth_cone"],
                        b_algebras["backreaction_current_right_birth_cone"],
                        resp.density,
                        config.algebra_tol,
                        layer_null_norm=float(b_meta.get("backreaction_current_norm", 0.0)),
                        extra=b_meta,
                    )
                    _append_commutator_row(
                        rows,
                        base,
                        "restricted_backreaction_current_left_birth_cone",
                        "backreaction_current_sibling_cross",
                        "cross_current_control_not_local_subalgebra",
                        "B_cross_current_control",
                        b_algebras["backreaction_current_left_birth_cone"],
                        b_algebras["backreaction_current_sibling_cross"],
                        resp.density,
                        config.algebra_tol,
                        layer_null_norm=float(b_meta.get("backreaction_current_cross_norm", 0.0)),
                        extra=b_meta,
                    )
                    _append_commutator_row(
                        rows,
                        base,
                        "restricted_backreaction_current_right_birth_cone",
                        "backreaction_current_sibling_cross",
                        "cross_current_control_not_local_subalgebra",
                        "B_cross_current_control",
                        b_algebras["backreaction_current_right_birth_cone"],
                        b_algebras["backreaction_current_sibling_cross"],
                        resp.density,
                        config.algebra_tol,
                        layer_null_norm=float(b_meta.get("backreaction_current_cross_norm", 0.0)),
                        extra=b_meta,
                    )
                if b_null_algebras is not None:
                    n_meta = b_null_algebras.get("__metadata__", {})
                    _append_commutator_row(
                        rows,
                        base,
                        "identical_history_null_left_birth_cone",
                        "identical_history_null_right_birth_cone",
                        "identical_history_same_state_null_pipeline",
                        "B_identical_history_null_control",
                        b_null_algebras["backreaction_current_left_birth_cone"],
                        b_null_algebras["backreaction_current_right_birth_cone"],
                        resp.density,
                        config.algebra_tol,
                        layer_null_norm=float(n_meta.get("backreaction_current_norm", 0.0)),
                        extra=n_meta,
                    )

    return rows


def commutation_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("commutation_computed_status", "unknown")) for r in rows})
    layers = sorted({str(r.get("operator_layer", "unknown")) for r in rows if "operator_layer" in r})
    return "# Finite local-operator commutation report\n\nMeasurements commutators for sibling-separated finite operator systems with explicit layer separation: symmetric carrier response S, directed skew response A, mixed response systems, and restricted B_R/B_S = P_R(A_live-A_record)P_R backreaction-current systems where available.  Cross-current terms are emitted separately as controls rather than being inserted into both local B systems.  Structurally commuting disjoint-support rows, vacuous zero A-layer rows, and live-minus-live identical-history null rows are explicitly labelled as controls; a broken identical-history null pipeline is exposed as `identical_history_null_control_FAILED` rather than falling through to generic computed_status_rows.  Noncommutation is reported as a finite layer rank_bound rather than as an automatic CNNA failure.\n\nObserved layers: `" + "`, `".join(layers) + "`.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
