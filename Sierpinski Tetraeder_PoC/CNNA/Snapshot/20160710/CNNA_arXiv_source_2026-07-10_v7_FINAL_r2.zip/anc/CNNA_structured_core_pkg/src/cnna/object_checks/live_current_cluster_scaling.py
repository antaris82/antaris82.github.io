from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    local_operator_algebras,
    state_pair_backreaction_algebras,
)
from cnna.core.entropy_quantities import record_live_entropy_metrics
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: List[float]) -> float:
    ys = sorted(x for x in xs if math.isfinite(x))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"), row.get("live_cluster_layer"))


def _summarize(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        x = _finite(r.get("cluster_rank_bound_norm"))
        if c >= 0 and math.isfinite(x):
            by_c[c].append(x)
    cs = sorted(by_c)
    if len(cs) < 2:
        return {"live_cluster_track_computed_status": "live_cluster_insufficient_corridor_track", "live_cluster_corridor_count": len(cs)}
    first = _median(by_c[cs[0]])
    last = _median(by_c[cs[-1]])
    mono = all(_median(by_c[cs[i + 1]]) <= _median(by_c[cs[i]]) + max(tol, tol * max(1.0, _median(by_c[cs[i]]))) for i in range(len(cs) - 1))
    if max(_median(v) for v in by_c.values()) <= tol:
        computed_status = "live_cluster_zero_structural_control"
    elif mono and math.isfinite(first) and math.isfinite(last) and last < first:
        computed_status = "live_cluster_decay_finite_object"
    elif math.isfinite(first) and math.isfinite(last) and last > first:
        computed_status = "live_cluster_growth_observed"
    else:
        computed_status = "live_cluster_no_monotone_decay_observed"
    return {
        "live_cluster_corridor_count": int(len(cs)),
        "live_cluster_first_corridor": int(cs[0]),
        "live_cluster_last_corridor": int(cs[-1]),
        "live_cluster_first_median": float(first),
        "live_cluster_last_median": float(last),
        "live_cluster_last_over_first": float(last / max(first, 1.0e-300)) if first > 0 else math.nan,
        "live_cluster_track_computed_status": computed_status,
    }


def live_current_cluster_scaling_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            live = regional_response(model, spec, "live")
            record = regional_response(model, spec, "record")
            if live is None:
                rows.append({"branching": b, "level": L, "mode": mode, **meta, "live_cluster_layer": "unavailable", "live_cluster_row_computed_status": "live_response_unavailable"})
                continue
            algebras = local_operator_algebras(live, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
            pairs = [
                ("S_live_carrier", algebras["symmetric_left_birth_cone_response"], algebras["symmetric_right_birth_cone_response"]),
                ("A_live_directed", algebras["skew_left_birth_cone_response"], algebras["skew_right_birth_cone_response"]),
                ("mixed_live_response", algebras["left_birth_cone_response"], algebras["right_birth_cone_response"]),
            ]
            bpair = state_pair_backreaction_algebras(model, spec, "live", "record", config.algebra_tol, config.max_algebra_iter)
            if bpair is not None:
                pairs.append(("B_live_minus_record_current", bpair["backreaction_current_left_birth_cone"], bpair["backreaction_current_right_birth_cone"]))
            entropy = record_live_entropy_metrics(live.density, record.density, tol=config.algebra_tol) if record is not None else {}
            for layer, left, right in pairs:
                cm = commutator_metrics(left, right)
                norm = float(cm["max_relative_commutator"])
                corridor = int(meta["genealogical_corridor_length"])
                row_computed_status = "touching_reference_not_spacelike" if corridor == 0 else ("collared_live_cluster_row" if corridor >= 2 else "uncollared_live_cluster_row")
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "state_relations": "live_reference_record_history_current_control",
                    "live_cluster_layer": layer,
                    "left_dim": len(left.basis),
                    "right_dim": len(right.basis),
                    **cm,
                    "cluster_rank_bound_norm": norm,
                    "jensen_shannon_live_record_no_epsilon": entropy.get("jensen_shannon_live_record_no_epsilon", math.nan),
                    "D_live_given_record_no_epsilon": entropy.get("D_live_given_record_no_epsilon", math.nan),
                    "live_cluster_row_computed_status": row_computed_status,
                })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        if "cluster_rank_bound_norm" in r:
            tracks[_track_key(r)].append(r)
    summaries = {k: _summarize(v, config.algebra_tol) for k, v in tracks.items()}
    for r in rows:
        r.update(summaries.get(_track_key(r), {}))
    return rows


def live_current_cluster_scaling_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("live_cluster_track_computed_status", "unknown")) for r in rows if "live_cluster_track_computed_status" in r})
    layers = sorted({str(r.get("live_cluster_layer", "unknown")) for r in rows})
    return (
        "# Live-reference cluster and history-current scaling\n\n"
        "This surface addresses finite locality without treating touching birth-coupled siblings as spacelike.  "
        "It separates `S_live`, `A_live`, mixed live response, and `B=live-record` history-current layers, and reports their corridor trajectories.\n\n"
        "Layers: `" + "`, `".join(layers) + "`.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
