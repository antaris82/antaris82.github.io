from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.io.csv_writer import write_csv
from cnna.derived_quantities import *

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA construction analysis: live/record carrier-state and operator-stack derived_quantity rows")
    p.add_argument("--branching", nargs="+", type=int, default=[3])
    p.add_argument("--levels", nargs="+", type=int, default=[4, 5, 6])
    p.add_argument("--modes", nargs="+", choices=["linear", "log", "saturating"], default=["linear", "log", "saturating"])
    p.add_argument("--states", nargs="+", choices=["live", "record", "sym"], default=["live", "record", "sym"])
    p.add_argument("--max-regions", type=int, default=1)
    p.add_argument("--max-boundary", type=int, default=600)
    p.add_argument("--max-interior", type=int, default=900)
    p.add_argument("--directed-frontier-cap", type=int, default=6,
                   help="largest absolute frontier level used by directed coarse-frontier DtN coverage; levels above this are cut at this frontier instead of terminal leaves")
    p.add_argument("--algebra-tol", type=float, default=1e-10)
    p.add_argument("--algebra-max-iter", type=int, default=8)
    p.add_argument("--gns-tol", type=float, default=1e-10)
    p.add_argument("--growth-schedule", choices=["slot_step", "layer_batch"], default="slot_step")
    p.add_argument("--outdir", type=Path, default=Path("outputs/cnna_analysis"))
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if REFERENCE_MODE not in args.modes:
        args.modes = [REFERENCE_MODE] + list(args.modes)
    if REFERENCE_STATE not in args.states:
        args.states = [REFERENCE_STATE] + list(args.states)
    outdir: Path = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    models = level_models(args.branching, args.levels, args.modes, growth_schedule=args.growth_schedule)
    parameter_rows = parameter_purity_rows(args)
    genesis, hashes, counts = genesis_rows(models)
    projection = projection_grammar_rows(models, args.levels)
    orientation = orientation_rows(models, args.states)
    carrier, state_rows, carrier_comp, state_comp = carrier_state_rows(models, args.levels, args.states)
    carrier_effects = carrier_effect_operator_rows(models, args.levels, args.states)
    state_sector = state_sector_decomposition_rows(models, args.levels, args.states)
    region_rows, algebra_rows, gns_rows0 = region_and_gns_rows(models, args.states, args)
    gns_cyclicity_control_rows = finite_gns_cyclicity_control_rows(args.gns_tol, args.algebra_max_iter)
    gns_maps, alg_maps, ce_maps, mod_maps, op_comp = interlevel_operator_rows(models, args.levels, args.states, args)
    measure_condition_note_rows = measure_rank_kernel_condition_rows(models, args.levels, args.modes)
    construction_rows = construction_coverage_rows()
    fixed_rule_rows = fixed_rule_constants_measurement_rows(args.branching)
    regional_condition_note_rows = regional_rank_kernel_condition_rows(models, args.levels, args.modes)
    terminal_density_rows = terminal_density_state_measurement_rows(models, args.states)
    compressed_state_objects, compressed_state_proj, compressed_state_sectors, compressed_state_comp = compressed_carrier_state_rows(models, args.levels, args.states, args)
    state_construction_rows = state_construction_track_ledger_rows()
    operator_class_rows = operator_stack_residuals_classification_rows(gns_maps, alg_maps, ce_maps, mod_maps, op_comp)
    operator_seam_rows = operator_stack_seam_localization_rows(
        gns_maps, alg_maps, ce_maps, mod_maps, op_comp,
        compressed_state_proj, compressed_state_comp, carrier_comp,
    )
    operator_state_comparison_rows = operator_stack_live_record_sym_comparison_rows(operator_seam_rows)
    operator_level_scaling_rows = operator_stack_level_scaling_rows(operator_seam_rows)
    operator_naturality_rows = operator_stack_map_naturality_measurement_rows(operator_seam_rows)
    operator_stack_condition_role_dimension_rows = operator_stack_role_dimension_condition_note_rows(models, args.states, args)
    operator_stack_condition_generator_rank_rows = operator_stack_generator_rank_condition_note_rows(models, args.states, args)
    operator_stack_condition_coordinate_gauge_rows = operator_stack_coordinate_gauge_condition_note_rows(models, args.levels, args.states, args)
    operator_stack_condition_boundary_response_model_rows = operator_stack_boundary_response_model_condition_note_rows(models, args.states, args)
    operator_stack_condition_skew_survival_rows = operator_stack_skew_survival_condition_note_rows(models, args.states, args)
    operator_stack_condition_summary_rows = operator_stack_consistency_checks_summary_rows(
        operator_stack_condition_role_dimension_rows,
        operator_stack_condition_generator_rank_rows,
        operator_stack_condition_coordinate_gauge_rows,
        operator_stack_condition_boundary_response_model_rows,
        operator_stack_condition_skew_survival_rows,
    )
    directed_response_rows = directed_response_construction_rows(models, args.states, args)
    directed_sa_rows = directed_sa_decomposition_rows(models, args.states, args)
    directed_signed_role_rows = directed_signed_role_survival_rows(models, args.states, args)
    directed_boundary_response_model_rows = directed_boundary_response_model_comparison_rows(directed_response_rows)
    directed_skew_survival_result_rows = directed_skew_survival_rows(directed_sa_rows)
    directed_transport_rows = directed_operator_transport_rows(directed_sa_rows, args.levels)
    directed_j_rows = directed_j_finite_object_comparison_rows(models, args.states, args)
    directed_summary_rows = directed_operator_stack_summary_rows(directed_sa_rows, directed_skew_survival_result_rows, directed_signed_role_rows, directed_j_rows)
    directed_current_transport_result_rows = directed_current_transport_rows(models, args.states, args)
    directed_current_composition_result_rows = directed_current_composition_rows(models, args.states, args)
    directed_j_orientation_summary_result_rows = directed_j_orientation_summary_rows(directed_current_transport_result_rows, directed_current_composition_result_rows)
    directed_large_L_coverage_rows = directed_large_L_region_coverage_rows(models, args.states, args)
    directed_large_L_summary_rows = directed_large_L_coverage_summary_rows(directed_large_L_coverage_rows, directed_current_transport_result_rows)
    backreaction_rows = backreaction_current_rows(models, args)
    backreaction_growth_rows = backreaction_growth_profile_rows(backreaction_rows)
    backreaction_parameter_sensitivity_rows = backreaction_region_parameter_sensitivity_rows(backreaction_rows)
    backreaction_transport_result_rows = backreaction_transport_rows(models, args)
    backreaction_summary_rows = backreaction_current_summary_rows(backreaction_rows, backreaction_growth_rows, backreaction_parameter_sensitivity_rows, backreaction_transport_result_rows)
    birth_relative_rows = birth_relative_backreaction_rows(backreaction_rows)
    birth_relative_zero_rows = birth_relative_zero_crossing_rows(birth_relative_rows)
    birth_relative_mode_branching_result_rows = birth_relative_mode_branching_rows(birth_relative_zero_rows)
    birth_relative_region_family_result_rows = birth_relative_region_family_rows(birth_relative_rows, birth_relative_zero_rows)
    birth_relative_summary_result_rows = birth_relative_summary_rows(birth_relative_rows, birth_relative_zero_rows, birth_relative_mode_branching_result_rows, birth_relative_region_family_result_rows)
    j_orientation_b_snapshot_rows = []
    j_orientation_b_transport_rows = []
    j_orientation_b_composition_rows = []
    j_orientation_sign_scope_rows = []
    j_orientation_b_summary_rows = []
    j_orientation_a_snapshot_rows = a_j_orientation_snapshot_rows(models, args)
    j_orientation_a_transport_rows = a_j_orientation_transport_rows(models, args)
    j_orientation_a_composition_rows = a_j_orientation_composition_rows(models, args)
    j_orientation_summary_rows = a_j_orientation_projectivity_summary_rows(j_orientation_a_snapshot_rows, j_orientation_a_transport_rows, j_orientation_a_composition_rows, j_orientation_b_summary_rows)
    j_sign_global_rows = global_j_boundary_sign_relation_rows(models, args)
    j_sign_comparison_rows = local_global_j_sign_comparison_rows(models, args, j_sign_global_rows)
    j_sign_summary_rows = local_global_j_sign_summary_rows(j_sign_global_rows, j_sign_comparison_rows)
    finals = final_computed_status_rows_full(genesis, parameter_rows, projection, orientation, carrier_effects, state_rows, region_rows, gns_rows0, gns_maps, alg_maps, ce_maps, mod_maps, op_comp, measure_condition_note_rows, operator_class_rows)
    # Harden CNNA analysis computed_status: distinguish the restored compressed carrier/GNS state
    # track from the terminal diagonal control state and keep the operator stack
    # as a residual measurement unless strict algebraic conditions are actually small.
    reference_compressed_objs = [r for r in compressed_state_objects if int(r.get("reference_model", 0)) == 1]
    reference_compressed_proj = [r for r in compressed_state_proj if int(r.get("reference_model", 0)) == 1]
    reference_compressed_comp = [r for r in compressed_state_comp if int(r.get("reference_model", 0)) == 1]
    compressed_restored = int(bool(reference_compressed_objs) and all(int(r.get("object_available", 0)) == 1 and float(r.get("sumE_completeness_error", 1.0)) < 1e-9 for r in reference_compressed_objs))
    compressed_projective = int(bool(reference_compressed_proj) and all(float(r.get("state_global_TV", 1.0)) <= 0.08 for r in reference_compressed_proj))
    compressed_composition = int(bool(reference_compressed_comp) and all(float(r.get("state_composition_TV", 1.0)) < 1e-12 for r in reference_compressed_comp))
    if finals:
        finals[0]["compressed_carrier_GNS_state_restored"] = compressed_restored
        finals[0]["compressed_carrier_GNS_state_projective_finite_object"] = compressed_projective
        finals[0]["compressed_carrier_GNS_state_composition_residual_le_tolerance"] = compressed_composition
        finals[0]["terminal_diagonal_state_is_control_only"] = 1
        reference_seams = [r for r in operator_seam_rows if int(r.get("reference_model", 0)) == 1]
        reference_seam_64 = [r for r in reference_seams if int(r.get("source_level", 0)) == 6 and int(r.get("target_level", 0)) == 4]
        residual_row = reference_seam_64[0] if reference_seam_64 else (reference_seams[0] if reference_seams else {})
        finals[0]["fixed_baseline"] = int(compressed_restored and compressed_projective and compressed_composition)
        finals[0]["residual_localization_active"] = int(bool(residual_row))
        finals[0]["reference_residual_computed_status"] = residual_row.get("computed_status", "missing_operator_stack_interface_row")
        finals[0]["reference_dominant_interface"] = residual_row.get("dominant_seam", "missing_operator_stack_interface_row")
        finals[0]["operator_map_kind"] = residual_row.get("map_kind", "missing_operator_stack_interface_row")
        reference_consistency = [r for r in operator_stack_condition_summary_rows if int(r.get("reference_model", 0)) == 1]
        consistency_row = reference_consistency[0] if reference_consistency else {}
        finals[0]["operator_stack_condition_consistency_active"] = int(bool(consistency_row))
        finals[0]["operator_stack_condition_consistency_computed_status"] = consistency_row.get("computed_status", "missing_operator_stack_condition_summary_row")
        finals[0]["operator_stack_condition_interpretation_unmet_conditions"] = consistency_row.get("unmet_conditions", "missing_operator_stack_condition_summary_row")
        reference_directed_operator_stack = [r for r in directed_summary_rows if int(r.get("reference_model", 0)) == 1]
        directed_operator_stack_row = reference_directed_operator_stack[0] if reference_directed_operator_stack else {}
        finals[0]["directed_operator_stack_active"] = int(bool(directed_operator_stack_row))
        finals[0]["directed_operator_stack_computed_status"] = directed_operator_stack_row.get("computed_status", "missing_directed_summary_row")
        finals[0]["directed_operator_stack_unmet_conditions"] = directed_operator_stack_row.get("unmet_conditions", "missing_directed_summary_row")
        reference_directed_current_transport = [r for r in directed_j_orientation_summary_result_rows if int(r.get("reference_model", 0)) == 1]
        directed_current_transport_row = reference_directed_current_transport[0] if reference_directed_current_transport else {}
        finals[0]["directed_current_transport_active"] = int(bool(directed_current_transport_row))
        finals[0]["directed_current_transport_computed_status"] = directed_current_transport_row.get("computed_status", "missing_directed_j_orientation_summary_row")
        finals[0]["directed_current_transport_unmet_conditions"] = directed_current_transport_row.get("unmet_conditions", "missing_directed_j_orientation_summary_row")
        reference_directed_region_coverage = [r for r in directed_large_L_summary_rows if int(r.get("reference_model", 0)) == 1]
        directed_region_coverage_row = reference_directed_region_coverage[0] if reference_directed_region_coverage else {}
        finals[0]["directed_large_L_coverage_active"] = int(bool(directed_region_coverage_row))
        finals[0]["directed_large_L_coverage_computed_status"] = directed_region_coverage_row.get("computed_status", "missing_directed_region_coverage_summary_row")
        finals[0]["directed_large_L_coverage_unmet_conditions"] = directed_region_coverage_row.get("unmet_conditions", "missing_directed_region_coverage_summary_row")
        finals[0]["coarse_frontier_levels"] = directed_region_coverage_row.get("coarse_frontier_levels", "missing_directed_region_coverage_summary_row")
        reference_backreaction_current = [r for r in backreaction_summary_rows if int(r.get("reference_model", 0)) == 1]
        backreaction_current_row = reference_backreaction_current[0] if reference_backreaction_current else {}
        finals[0]["backreaction_current_active"] = int(bool(backreaction_current_row))
        finals[0]["backreaction_current_computed_status"] = backreaction_current_row.get("computed_status", "missing_backreaction_summary_row")
        finals[0]["backreaction_current_unmet_conditions"] = backreaction_current_row.get("unmet_conditions", "missing_backreaction_summary_row")
        finals[0]["physical_path"] = backreaction_current_row.get("physical_path", "live_record_only_sym_is_control")
        reference_birth_relative_backreaction = [r for r in birth_relative_summary_result_rows if int(r.get("reference_model", 0)) == 1]
        birth_relative_backreaction_row = reference_birth_relative_backreaction[0] if reference_birth_relative_backreaction else {}
        finals[0]["birth_relative_relative_active"] = int(bool(birth_relative_backreaction_row))
        finals[0]["birth_relative_relative_computed_status"] = birth_relative_backreaction_row.get("computed_status", "missing_birth_relative_summary_row")
        finals[0]["birth_relative_relative_unmet_conditions"] = birth_relative_backreaction_row.get("unmet_conditions", "missing_birth_relative_summary_row")
        finals[0]["first_nonnegative_age"] = birth_relative_backreaction_row.get("reference_first_nonnegative_age", "missing_birth_relative_summary_row")
        reference_j_orientation_projectivity = [r for r in j_orientation_summary_rows if int(r.get("reference_model", 0)) == 1]
        j_orientation_projectivity_row = reference_j_orientation_projectivity[0] if reference_j_orientation_projectivity else {}
        finals[0]["A_J_orientation_projectivity_active"] = int(bool(j_orientation_projectivity_row))
        finals[0]["A_J_orientation_projectivity_computed_status"] = j_orientation_projectivity_row.get("computed_status", "missing_j_orientation_summary_row")
        finals[0]["A_J_orientation_projectivity_unmet_conditions"] = j_orientation_projectivity_row.get("unmet_conditions", "missing_j_orientation_summary_row")
        finals[0]["j_orientation_projectivity_dependency"] = j_orientation_projectivity_row.get("dependency_table_to_property_layer", "missing_j_orientation_summary_row")
        reference_j_sign_relation = [r for r in j_sign_summary_rows if int(r.get("reference_model", 0)) == 1]
        j_sign_relation_row = reference_j_sign_relation[0] if reference_j_sign_relation else {}
        finals[0]["local_global_J_sign_active"] = int(bool(j_sign_relation_row))
        finals[0]["local_global_J_sign_computed_status"] = j_sign_relation_row.get("computed_status", "missing_j_sign_summary_row")
        finals[0]["local_global_J_sign_unmet_conditions"] = j_sign_relation_row.get("unmet_conditions", "missing_j_sign_summary_row")
        finals[0]["local_global_J_sign_dependency"] = j_sign_relation_row.get("dependency_table_to_property_layer", "missing_j_sign_summary_row")
        if compressed_restored and compressed_projective and "local_J_sign_rigid_global_flip_free_finite_object" in str(j_sign_relation_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_local_global_J_sign_active"
        elif compressed_restored and compressed_projective and "A_J_orientation_projective_coherence_finite_object" in str(j_orientation_projectivity_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_A_J_orientation_projectivity_active"
        elif compressed_restored and compressed_projective and "birth_relative_backreaction_law_finite_object" in str(birth_relative_backreaction_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_birth_relative_backreaction_current_birth_relative_active"
        elif compressed_restored and compressed_projective and "backreaction_current_law_finite_object" in str(backreaction_current_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_live_record_backreaction_current_active"
        elif compressed_restored and compressed_projective and "large_L_directed_region_coverage_residual_le_tolerance" in str(directed_region_coverage_row.get("computed_status", "")) and "J_orientation_projective_coherence_residual_le_tolerance" in str(directed_current_transport_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_J_orientation_transport_large_L_coverage_directed_region_coverage_active"
        elif compressed_restored and compressed_projective and "J_orientation_projective_coherence_residual_le_tolerance" in str(directed_current_transport_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_J_orientation_transport_directed_current_transport_active"
        elif compressed_restored and compressed_projective and "carries_nonzero_signed_skew_current" in str(directed_operator_stack_row.get("computed_status", "")):
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_directed_DtN_skew_stack_directed_operator_stack_active"
        elif compressed_restored and compressed_projective:
            finals[0]["final_computed_status"] = "compressed_carrier_state_residual_le_tolerance_operator_stack_residuals_measurement_consistency_refined_active"
    live_record_structural_rows = live_record_structural_calculation_ledger_rows(args, orientation, state_rows, region_rows, gns_rows0, gns_maps, alg_maps, ce_maps, mod_maps, op_comp)
    history_delta_rows = live_record_history_delta_ledger_rows(models, args.levels, args.modes)
    birth_linearization_rows = birth_linearization_invariance_rows(args.branching, args.levels, args.modes, args.states)

    write_csv(outdir / "parameter_purity_measurement.csv", parameter_rows)
    write_csv(outdir / "emptyset_genesis_measurement.csv", genesis)
    write_csv(outdir / "eventlog_hashes.csv", hashes)
    write_csv(outdir / "level_count_measurement.csv", counts)
    write_csv(outdir / "projection_grammar.csv", projection)
    write_csv(outdir / "f1f2_skew_orientation_measurement.csv", orientation)
    write_csv(outdir / "measure_rank_kernel_condition_ledger.csv", measure_condition_note_rows)
    write_csv(outdir / "regional_rank_kernel_condition_ledger.csv", regional_condition_note_rows)
    write_csv(outdir / "construction_coverage.csv", construction_rows)
    write_csv(outdir / "rule_coefficients_measurement.csv", fixed_rule_rows)
    write_csv(outdir / "terminal_diagonal_state_measurement.csv", terminal_density_rows)
    write_csv(outdir / "compressed_carrier_state_objects.csv", compressed_state_objects)
    write_csv(outdir / "compressed_carrier_state_projectivity.csv", compressed_state_proj)
    write_csv(outdir / "compressed_carrier_state_sector_decomposition.csv", compressed_state_sectors)
    write_csv(outdir / "compressed_carrier_state_composition.csv", compressed_state_comp)
    write_csv(outdir / "state_track_ledger.csv", state_construction_rows)
    write_csv(outdir / "comparison_mode_control_ledger.csv", [r for r in parameter_rows] + [r for r in measure_condition_note_rows if r.get("condition_note_name") == "M3_mode_commonity_is_control_only"])
    write_csv(outdir / "live_record_structural_ledger.csv", live_record_structural_rows)
    write_csv(outdir / "live_record_history_delta.csv", history_delta_rows)
    write_csv(outdir / "birth_linearization_invariance.csv", birth_linearization_rows)
    write_csv(outdir / "carrier_projectivity.csv", carrier)
    write_csv(outdir / "carrier_effect_operator_measurement.csv", carrier_effects)
    write_csv(outdir / "carrier_composition.csv", carrier_comp)
    write_csv(outdir / "terminal_diagonal_state_projectivity.csv", state_rows)
    write_csv(outdir / "terminal_diagonal_state_sector_decomposition.csv", state_sector)
    write_csv(outdir / "terminal_diagonal_state_composition.csv", state_comp)
    write_csv(outdir / "regional_schur_dtn_response_measurement.csv", region_rows)
    write_csv(outdir / "response_algebra_measurement.csv", algebra_rows)
    write_csv(outdir / "finite_gns_pre_representation_measurement.csv", gns_rows0)
    write_csv(outdir / "finite_gns_cyclicity_controls.csv", gns_cyclicity_control_rows)
    write_csv(outdir / "gns_generator_transport_maps.csv", gns_maps)
    write_csv(outdir / "algebra_projection_morphism_measurement.csv", alg_maps)
    write_csv(outdir / "conditional_expectation_commuting_square.csv", ce_maps)
    write_csv(outdir / "modular_preflow_transport_measurement.csv", mod_maps)
    write_csv(outdir / "operator_stack_composition_coherence.csv", op_comp)
    write_csv(outdir / "operator_stack_residuals_classification.csv", operator_class_rows)
    write_csv(outdir / "1_operator_stack_seam_localization.csv", operator_seam_rows)
    write_csv(outdir / "1_operator_stack_live_record_sym_comparison.csv", operator_state_comparison_rows)
    write_csv(outdir / "1_operator_stack_level_scaling.csv", operator_level_scaling_rows)
    write_csv(outdir / "1_operator_stack_map_naturality_measurement.csv", operator_naturality_rows)
    write_csv(outdir / "operator_stack_condition_role_dimension_condition_note.csv", operator_stack_condition_role_dimension_rows)
    write_csv(outdir / "operator_stack_condition_generator_rank_condition_note.csv", operator_stack_condition_generator_rank_rows)
    write_csv(outdir / "operator_stack_condition_coordinate_gauge_condition_note.csv", operator_stack_condition_coordinate_gauge_rows)
    write_csv(outdir / "operator_stack_condition_boundary_response_model_condition_note.csv", operator_stack_condition_boundary_response_model_rows)
    write_csv(outdir / "operator_stack_condition_skew_survival_condition_note.csv", operator_stack_condition_skew_survival_rows)
    write_csv(outdir / "operator_stack_condition_consistency_summary.csv", operator_stack_condition_summary_rows)
    write_csv(outdir / "directed_response_construction.csv", directed_response_rows)
    write_csv(outdir / "directed_SA_decomposition.csv", directed_sa_rows)
    write_csv(outdir / "directed_signed_role_survival.csv", directed_signed_role_rows)
    write_csv(outdir / "directed_boundary_response_model_comparison.csv", directed_boundary_response_model_rows)
    write_csv(outdir / "directed_skew_survival.csv", directed_skew_survival_result_rows)
    write_csv(outdir / "directed_operator_stack_transport.csv", directed_transport_rows)
    write_csv(outdir / "directed_J_finite_object_comparison.csv", directed_j_rows)
    write_csv(outdir / "directed_operator_stack_summary.csv", directed_summary_rows)
    write_csv(outdir / "directed_current_transport.csv", directed_current_transport_result_rows)
    write_csv(outdir / "directed_current_composition.csv", directed_current_composition_result_rows)
    write_csv(outdir / "J_orientation_transport_summary.csv", directed_j_orientation_summary_result_rows)
    write_csv(outdir / "directed_large_L_directed_region_coverage.csv", directed_large_L_coverage_rows)
    write_csv(outdir / "directed_large_L_directed_region_coverage_summary.csv", directed_large_L_summary_rows)
    write_csv(outdir / "live_record_backreaction_current.csv", backreaction_rows)
    write_csv(outdir / "backreaction_growth_profile.csv", backreaction_growth_rows)
    write_csv(outdir / "backreaction_region_parameter_sensitivity.csv", backreaction_parameter_sensitivity_rows)
    write_csv(outdir / "backreaction_transport.csv", backreaction_transport_result_rows)
    write_csv(outdir / "backreaction_current_summary.csv", backreaction_summary_rows)
    write_csv(outdir / "birth_relative_relative_backreaction_current.csv", birth_relative_rows)
    write_csv(outdir / "birth_relative_zero_crossing_by_region.csv", birth_relative_zero_rows)
    write_csv(outdir / "birth_relative_mode_branching_comparison.csv", birth_relative_mode_branching_result_rows)
    write_csv(outdir / "birth_relative_region_family_comparison.csv", birth_relative_region_family_result_rows)
    write_csv(outdir / "birth_relative_backreaction_law_summary.csv", birth_relative_summary_result_rows)
    write_csv(outdir / "A_J_orientation_snapshot.csv", j_orientation_a_snapshot_rows)
    write_csv(outdir / "A_J_orientation_transport.csv", j_orientation_a_transport_rows)
    write_csv(outdir / "A_J_orientation_composition.csv", j_orientation_a_composition_rows)
    write_csv(outdir / "A_J_orientation_projectivity_summary.csv", j_orientation_summary_rows)
    write_csv(outdir / "j_sign_global_boundary_sign_relation.csv", j_sign_global_rows)
    write_csv(outdir / "local_global_J_sign_comparison.csv", j_sign_comparison_rows)
    write_csv(outdir / "J_sign_sign_relation_summary.csv", j_sign_summary_rows)
    write_operator_stack_residual_report(outdir, operator_seam_rows, operator_state_comparison_rows, operator_level_scaling_rows, operator_naturality_rows)
    write_operator_stack_condition_consistency_report(
        outdir,
        operator_stack_condition_role_dimension_rows,
        operator_stack_condition_generator_rank_rows,
        operator_stack_condition_coordinate_gauge_rows,
        operator_stack_condition_boundary_response_model_rows,
        operator_stack_condition_skew_survival_rows,
        operator_stack_condition_summary_rows,
    )
    write_directed_operator_stack_report(
        outdir,
        directed_response_rows,
        directed_sa_rows,
        directed_signed_role_rows,
        directed_boundary_response_model_rows,
        directed_skew_survival_result_rows,
        directed_transport_rows,
        directed_j_rows,
        directed_summary_rows,
    )
    write_directed_current_transport_report(outdir, directed_current_transport_result_rows, directed_current_composition_result_rows, directed_j_orientation_summary_result_rows)
    write_directed_region_coverage_report(outdir, directed_large_L_coverage_rows, directed_large_L_summary_rows)
    write_live_record_backreaction_current_report(outdir, backreaction_rows, backreaction_growth_rows, backreaction_parameter_sensitivity_rows, backreaction_transport_result_rows, backreaction_summary_rows)
    write_birth_relative_backreaction_current_report(outdir, birth_relative_rows, birth_relative_zero_rows, birth_relative_mode_branching_result_rows, birth_relative_region_family_result_rows, birth_relative_summary_result_rows)
    write_j_orientation_a_orientation_projectivity_report(outdir, j_orientation_a_snapshot_rows, j_orientation_a_transport_rows, j_orientation_a_composition_rows, j_orientation_summary_rows)
    write_local_global_j_sign_relation_report(outdir, j_sign_global_rows, j_sign_comparison_rows, j_sign_summary_rows)
    write_csv(outdir / "final_computed_status_rows.csv", finals)
    write_markdown_full(outdir, args, finals)

    print(json.dumps(finals[0], indent=2, sort_keys=True))
    return 0
