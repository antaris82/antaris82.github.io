from __future__ import annotations

from collections import Counter
from typing import List


def oriented_history_measure_geometry_summary_rows(measure_rows: List[dict], geometry_rows: List[dict]) -> List[dict]:
    mv = Counter(str(r.get("two_component_history_measure_computed_status", "unknown")) for r in measure_rows)
    gv = Counter(str(r.get("oriented_history_geometry_row_computed_status", "unknown")) for r in geometry_rows)
    tv = Counter(str(r.get("oriented_history_geometry_track_computed_status", "unknown")) for r in geometry_rows if "oriented_history_geometry_track_computed_status" in r)
    rows = []
    for computed_status, count in sorted(mv.items()):
        rows.append({"summary_surface": "two_component_history_measure", "computed_status": computed_status, "count": int(count)})
    for computed_status, count in sorted(gv.items()):
        rows.append({"summary_surface": "oriented_history_geometry_rows", "computed_status": computed_status, "count": int(count)})
    for computed_status, count in sorted(tv.items()):
        rows.append({"summary_surface": "oriented_history_geometry_tracks", "computed_status": computed_status, "count": int(count)})
    return rows


def oriented_history_measure_geometry_summary_report(rows: List[dict]) -> str:
    return (
        "# Oriented HistoryMeasure geometry summary\n\n"
        "This summary counts the two-component measure computed_status_rows and the locality/split/complement computed_status_rows after normalizing by `JS(live,record) + F1/F2 skew 2-form profile gap`.\n"
    )
