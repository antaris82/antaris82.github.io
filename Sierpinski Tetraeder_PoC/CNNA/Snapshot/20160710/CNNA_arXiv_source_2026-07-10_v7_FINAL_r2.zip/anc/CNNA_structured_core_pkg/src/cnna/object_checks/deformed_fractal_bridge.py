from __future__ import annotations

from typing import List


def deformed_fractal_bridge_rows() -> List[dict]:
    """Finite dependency_table rows for the fourth CNNA transition path.

    These rows are intentionally dependency_table derived_quantity rows, not property statements.  They
    encode what must be built in finite_core before comparing CNNA to Kigami/Strichartz
    style analysis on fractals.  CNNA's target is deformed Sierpinski-like
    geometry induced by live response, not the symmetric SG/ST model.
    """
    return [
        {
            "bridge_surface": "tree_to_deformed_sierpinski_like_approximant",
            "object_to_construct": "finite graph/simplicial approximant dual to CNNA provenance tree",
            "CNNA_input": "live Schur/DtN response, F1/F2 orientation, inherited uniform node measure",
            "symmetric_null_control": "symmetric SG/ST-like graph with equal harmonic/resistance weights",
            "deformed_physical_finite_object": "non-exactly-self-similar Sierpinski-like complex with variable live-response weights",
            "finite_test": "pushforward_consistency_and_refined_to_coarse_recovery",
            "expected_output": "deformed_fractal_approximant.csv",
            "statement_status": "dependency_table_not_yet_tested",
            "condition_note": "do_not_target_symmetric_fractal_as_physical_CNNA_geometry",
        },
        {
            "bridge_surface": "resistance_form_finite_object",
            "object_to_construct": "Dirichlet energy/resistance form on deformed approximants",
            "CNNA_input": "symmetric live response S plus F1/F2 skew-current as orientation derived_quantity",
            "symmetric_null_control": "Kigami-style symmetric resistance renormalization baseline where applicable",
            "deformed_physical_finite_object": "variable-energy form whose renormalization is not assumed exactly self-similar",
            "finite_test": "positivity_kernel_markov_property_resistance_metric_stability",
            "expected_output": "deformed_resistance_form_derived_quantity rows.csv",
            "statement_status": "dependency_table_not_yet_tested",
            "condition_note": "do_not_import_self_similarity_or_exact_spectral_decimation",
        },
        {
            "bridge_surface": "laplacian_spectral_dimension_finite_object",
            "object_to_construct": "graph/fractal Laplacian and spectral counting trajectory",
            "CNNA_input": "deformed conductance/resistance weights from live response",
            "symmetric_null_control": "SG/ST spectral dimension and spectral-decimation-like baseline as control only",
            "deformed_physical_finite_object": "non-periodic or weakly self-similar spectral trajectory with F1/F2 deformation",
            "finite_test": "N_lambda_scaling_heat_kernel_trace_spectral_dimension_by_L",
            "expected_output": "deformed_laplacian_spectrum_trajectory.csv",
            "statement_status": "dependency_table_not_yet_tested",
            "condition_note": "spectral_dimension_must_be_measured_on_asymmetric_live_geometry_not_on_symmetric_null",
        },
        {
            "bridge_surface": "simplicial_quantum_geometry_finite_object",
            "object_to_construct": "oriented finite simplicial/cochain complex carrying F1/F2 skew two-form",
            "CNNA_input": "birth-order orientation, F1/F2 shells/sectors, live-record current B",
            "symmetric_null_control": "orientation-erased sym tree and symmetric Sierpinski complex",
            "deformed_physical_finite_object": "oriented cochain/circulation geometry with noncommutative response residuals",
            "finite_test": "boundary_coboundary_chain_consistency_skew_circulation_nonzero_controls",
            "expected_output": "oriented_simplicial_cochain_geometry.csv",
            "statement_status": "dependency_table_not_yet_tested",
            "condition_note": "do_not_treat_fractal_geometry_as_classical_background; it must be pushed forward from provenance",
        },
    ]


def deformed_fractal_bridge_report() -> str:
    return """# Deformed Sierpinski-like fractal / simplicial-complex bridge

This is the fourth transition path.  It is not the symmetric SG/ST path.  CNNA uses a provenance tree whose live Schur/DtN response and F1/F2 orientation can be pushed forward to deformed Sierpinski-like graph/simplicial approximants.  Symmetric Sierpinski gasket/tetrahedron geometries are retained only as null/reference controls, analogous to the sym tree.

Required finite_core objects:

1. a finite deformed graph/simplicial approximant dual to the provenance tree,
2. a variable resistance/Dirichlet form finite_object induced by live response,
3. a Laplacian and spectral-dimension trajectory on the asymmetric live geometry,
4. an oriented cochain/two-form sector carrying the F1/F2 skew structure,
5. refined-to-coarse checks back to the finite_core F1/F2 signature derived_quantity rows.

No Kigami resistance form, Strichartz fractafold Laplacian, exact self-similar renormalization, spectral decimation, or symmetric fractal geometry property is stated in the current core.
"""
