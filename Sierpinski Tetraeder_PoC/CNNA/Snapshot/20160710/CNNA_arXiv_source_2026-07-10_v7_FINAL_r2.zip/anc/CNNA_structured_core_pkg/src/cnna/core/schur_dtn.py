from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *
from cnna.core.math_utils import *
from cnna.core.emptyset_growth import *
from cnna.core.projective_maps import *

@dataclass
class SchurResponse:
    ok: bool
    Lambda: Optional[np.ndarray]
    cond_KII: float
    solve_residual: float
    row_sum_residual: float
    error: str = ""


@dataclass
class RegionSpec:
    region_id: str
    pair_type: str
    lca: int
    left_root: int
    right_root: int
    level: int
    boundary: List[int]
    interior: List[int]
    roles: Dict[str, List[int]]


def schur_response(K: np.ndarray, boundary: Sequence[int], interior: Sequence[int], cond_max: float = 1.0e12) -> SchurResponse:
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    if not B:
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "empty_boundary")
    if set(B) & set(I):
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "boundary_interior_overlap")
    if not I:
        L = K[np.ix_(B, B)].copy()
        return SchurResponse(True, 0.5 * (L + L.T), 1.0, 0.0, float(np.max(np.abs(np.sum(L, axis=1)))) if L.size else 0.0, "")
    KBB = K[np.ix_(B, B)]
    KBI = K[np.ix_(B, I)]
    KIB = K[np.ix_(I, B)]
    KII = K[np.ix_(I, I)]
    try:
        cond = float(np.linalg.cond(KII)) if KII.size else 1.0
        if not math.isfinite(cond) or cond > cond_max:
            return SchurResponse(False, None, cond, math.nan, math.nan, "singular_or_ill_conditioned_KII")
        X = np.linalg.solve(KII, KIB)
        residual = fro(KII @ X - KIB) / max(fro(KIB), EPS)
        L = KBB - KBI @ X
        L = 0.5 * (L + L.T)
        rowsum = float(np.max(np.abs(np.sum(L, axis=1)))) if L.size else 0.0
        return SchurResponse(True, L, cond, residual, rowsum, "")
    except np.linalg.LinAlgError as exc:
        return SchurResponse(False, None, math.nan, math.nan, math.nan, f"lin_alg_error:{exc}")


def schur_response_from_model(model: EmptySetGrowthModel, state: str, boundary: Sequence[int], interior: Sequence[int], cond_max: float = 1.0e12) -> SchurResponse:
    """Schur/Kron response using sparse edge dictionaries and global degrees.

    This avoids materializing the full N x N Laplacian for b=4,L=6 while
    preserving the same block relations as selecting K[B∪I,B∪I] from the full
    graph Laplacian: diagonal entries contain total conductance to the full
    current network, off-diagonal entries are included for selected nodes.
    """
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    if not B:
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "empty_boundary")
    if set(B) & set(I):
        return SchurResponse(False, None, math.nan, math.nan, math.nan, "boundary_interior_overlap")
    selected = B + I
    pos = {nid: k for k, nid in enumerate(selected)}
    m = len(selected)
    Kloc = np.zeros((m, m), dtype=float)
    if state == "record":
        edges = model.record_edges
    else:
        edges = model.live_edges
    pair_keys = set()
    for i, j in edges.keys():
        if i != j:
            pair_keys.add((min(i, j), max(i, j)))
    for i, j in pair_keys:
        cij = 0.5 * (float(edges.get((i, j), 0.0)) + float(edges.get((j, i), 0.0)))
        if cij <= 0.0:
            continue
        if i in pos:
            Kloc[pos[i], pos[i]] += cij
        if j in pos:
            Kloc[pos[j], pos[j]] += cij
        if i in pos and j in pos:
            Kloc[pos[i], pos[j]] -= cij
            Kloc[pos[j], pos[i]] -= cij
    bidx = list(range(len(B)))
    iidx = list(range(len(B), len(B) + len(I)))
    return schur_response(Kloc, bidx, iidx, cond_max=cond_max)


def build_sibling_regions(model: EmptySetGrowthModel, max_regions: int = 4) -> List[RegionSpec]:
    specs: List[RegionSpec] = []
    # Prefer LCAs at level 1 then root.  Keep small deterministic sample.
    lca_finite_objects = [n.nid for n in model.nodes if n.level == 1 and len(n.children) >= 2]
    if not lca_finite_objects and model.nodes[0].children:
        lca_finite_objects = [0]
    for lca in lca_finite_objects:
        children = list(model.nodes[lca].children)
        if len(children) < 2:
            continue
        # adjacent sibling pairs preserve birth-order F2 information.
        for idx in range(min(len(children) - 1, max_regions)):
            left = children[idx]
            right = children[idx + 1]
            left_leaves = model.terminal_descendants(left)
            right_leaves = model.terminal_descendants(right)
            if not left_leaves or not right_leaves:
                continue
            boundary = [lca] + left_leaves + right_leaves
            cone_nodes = set(model.descendants(left, True)) | set(model.descendants(right, True))
            interior = sorted([x for x in cone_nodes if x not in set(boundary)])
            roles = {
                "C_lca": [lca],
                "B1_front": left_leaves,
                "B2_front": right_leaves,
                "F1_root_front": [lca] + left_leaves + right_leaves,
                "F2_birth_order": left_leaves + right_leaves,
            }
            specs.append(RegionSpec(
                region_id=f"sibling_cone_pair_lca{lca}_sib{idx}_{idx+1}",
                pair_type="sibling_cone_pair",
                lca=lca,
                left_root=left,
                right_root=right,
                level=model.nodes[lca].level,
                boundary=boundary,
                interior=interior,
                roles=roles,
            ))
            if len(specs) >= max_regions:
                return specs
    return specs


def normalized_indicator(boundary: Sequence[int], ids: Sequence[int]) -> np.ndarray:
    pos = {nid: i for i, nid in enumerate(boundary)}
    v = np.zeros(len(boundary), dtype=float)
    for nid in ids:
        if nid in pos:
            v[pos[nid]] = 1.0
    nrm = float(np.linalg.norm(v))
    return v / max(nrm, EPS)


def boundary_role_basis(model: EmptySetGrowthModel, region: RegionSpec) -> Tuple[np.ndarray, List[str]]:
    B = region.boundary
    C = normalized_indicator(B, region.roles["C_lca"])
    Lf = normalized_indicator(B, region.roles["B1_front"])
    Rf = normalized_indicator(B, region.roles["B2_front"])
    # F1: root/front contrast; F2: left/right birth-order contrast.
    F1 = C - 0.5 * (Lf + Rf)
    F2 = Lf - Rf
    vecs = [C, Lf, Rf, F1, F2]
    names = ["C_lca", "B1_front", "B2_front", "F1_root_front", "F2_birth_order"]
    # Deterministic modified Gram-Schmidt.
    basis: List[np.ndarray] = []
    out_names: List[str] = []
    for name, v in zip(names, vecs):
        u = v.copy()
        for q in basis:
            u -= float(q @ u) * q
        nrm = float(np.linalg.norm(u))
        if nrm > 1.0e-10:
            basis.append(u / nrm)
            out_names.append(name)
    if not basis:
        basis.append(np.ones(len(B), dtype=float) / math.sqrt(max(1, len(B))))
        out_names.append("constant_fallback")
    Q = np.column_stack(basis)
    return Q, out_names


def compress_response(Lambda: np.ndarray, Q: np.ndarray) -> np.ndarray:
    return Q.T @ Lambda @ Q


def role_for_boundary_node(spec: RegionSpec, nid: int) -> str:
    if nid in set(spec.roles.get("C_lca", [])):
        return "A_lca"
    if nid in set(spec.roles.get("B1_front", [])):
        return "B1_front"
    if nid in set(spec.roles.get("B2_front", [])):
        return "B2_front"
    return "A_shell"


def atom_key(model: EmptySetGrowthModel, role: str, nid: int, target_level: int) -> str:
    addr = prefix(model.nodes[nid].address, target_level)
    word = "root" if len(addr) == 0 else ".".join(map(str, addr))
    return f"{role}|{word}"
