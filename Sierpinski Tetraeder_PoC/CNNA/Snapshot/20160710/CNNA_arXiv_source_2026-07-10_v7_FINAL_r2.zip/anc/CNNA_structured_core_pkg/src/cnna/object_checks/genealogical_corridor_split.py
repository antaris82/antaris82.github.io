from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    joined_algebra,
    local_operator_algebras,
)
from cnna.core.operator_test_config import OperatorTestConfig
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


CORRIDOR_SPLIT_PAIRS = [
    ("left_frontier_response", "right_frontier_response", "frontier_without_shared_lca_anchor"),
    ("left_birth_cone_response", "right_birth_cone_response", "birth_cones_with_shared_lca_anchor"),
]


def _computed_status(comm_rel: float, tensor_ratio: float, floor_ratio: float, corridor: int, direct_sibling: int, tol: float, sign_relation: str) -> str:
    if corridor == 0 and direct_sibling:
        return "touching_sibling_split_not_expected_control"
    if sign_relation == "frontier_without_shared_lca_anchor" and comm_rel <= tol and abs(floor_ratio - 1.0) <= 1.0e-8:
        return "collared_or_frontier_shared_identity_span_control"
    if corridor >= 2 and comm_rel <= tol and abs(tensor_ratio - 1.0) <= 1.0e-8:
        return "collared_finite_tensor_factorization_finite_object"
    if corridor >= 2 and comm_rel <= 1.0e-7:
        return "collared_commuting_without_tensor_dimension"
    if corridor >= 2:
        return "collared_split_factorization_obstructed"
    return "uncollared_split_derived_quantity"


def genealogical_corridor_split_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    from cnna.core.operator_test_config import iter_growth_models
    for b, L, mode, model in iter_growth_models(config):
        for spec in build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        ):
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "corridor_split_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                for left_name, right_name, sign_relation in CORRIDOR_SPLIT_PAIRS:
                    left = algebras[left_name]
                    right = algebras[right_name]
                    join = joined_algebra("corridor_split_join_" + sign_relation, [left, right], tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    met = commutator_metrics(left, right)
                    product_dim = int(len(left.basis) * len(right.basis))
                    shared_floor = int(max(1, len(left.basis) + len(right.basis) - 1))
                    tensor_ratio = float(len(join.basis) / max(1, product_dim))
                    floor_ratio = float(len(join.basis) / max(1, shared_floor))
                    corridor = int(meta["genealogical_corridor_length"])
                    direct = int(meta["direct_sibling_birth_coupling"])
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "corridor_split_sign_relation": sign_relation,
                        "left_dim": len(left.basis),
                        "right_dim": len(right.basis),
                        "generated_join_dim": len(join.basis),
                        "tensor_product_dimension_proxy": product_dim,
                        "shared_identity_span_floor_proxy": shared_floor,
                        "join_to_tensor_dimension_ratio": tensor_ratio,
                        "join_to_shared_identity_span_floor_ratio": floor_ratio,
                        "max_relative_commutator": met["max_relative_commutator"],
                        "corridor_split_computed_status": _computed_status(float(met["max_relative_commutator"]), tensor_ratio, floor_ratio, corridor, direct, config.algebra_tol, sign_relation),
                    })
    return rows


def genealogical_corridor_split_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("corridor_split_computed_status", "unknown")) for r in rows})
    return "# Genealogical-corridor split report\n\nMeasurements finite split-factorization only after separating touching sibling cuts from collared genealogical cuts.  The shared-identity floor is retained so a commuting unital join is not mistaken for tensor factorization.  This is a finite collar derived_quantity, not the AQFT split property.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
