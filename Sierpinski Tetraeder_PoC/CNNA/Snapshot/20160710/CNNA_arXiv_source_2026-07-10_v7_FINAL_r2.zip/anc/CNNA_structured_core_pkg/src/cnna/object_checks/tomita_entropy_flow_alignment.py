from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.math_utils import fro

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    finite_tomita_star_metrics,
    genealogical_corridor_metadata,
    local_operator_algebras,
)
from cnna.core.entropy_quantities import record_live_entropy_metrics
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _track_key(r: dict) -> Tuple[object, ...]:
    return (r.get("branching"), r.get("mode"), r.get("genealogical_corridor_length"), r.get("tomita_matrix_sign_relation"))


def _summarize(rows: List[dict]) -> dict:
    ys = sorted(rows, key=lambda r: int(r.get("level", -1)))
    if len(ys) < 2:
        return {"tomita_entropy_flow_track_computed_status": "tomita_entropy_flow_trend_unavailable"}
    first, last = ys[0], ys[-1]
    res0 = _finite(first.get("tomita_conjuconditions_cnna_orientation_to_negative_residual"))
    res1 = _finite(last.get("tomita_conjuconditions_cnna_orientation_to_negative_residual"))
    js0 = _finite(first.get("jensen_shannon_live_record_no_epsilon"))
    js1 = _finite(last.get("jensen_shannon_live_record_no_epsilon"))
    sp0 = _finite(first.get("modular_spectrum_spread"))
    sp1 = _finite(last.get("modular_spectrum_spread"))
    if math.isfinite(res0) and math.isfinite(res1) and res1 < res0:
        res_trend = "tomita_cnna_residual_decreases_with_level"
    elif math.isfinite(res0) and math.isfinite(res1) and res1 > res0:
        res_trend = "tomita_cnna_residual_grows_with_level"
    else:
        res_trend = "tomita_cnna_residual_level_stable_or_unresolved"
    if math.isfinite(js0) and math.isfinite(js1) and math.isfinite(sp0) and math.isfinite(sp1):
        same_direction = int((js1 - js0) * (sp1 - sp0) > 0)
    else:
        same_direction = 0
    if same_direction and res_trend == "tomita_cnna_residual_decreases_with_level":
        computed_status = "entropy_flow_and_tomita_direction_limes_finite_object"
    elif same_direction:
        computed_status = "entropy_flow_modular_spread_direction_finite_object_without_J_identity"
    else:
        computed_status = "tomita_entropy_flow_alignment_unresolved_or_obstructed"
    return {
        "tomita_entropy_first_level": int(first.get("level", -1)),
        "tomita_entropy_last_level": int(last.get("level", -1)),
        "tomita_cnna_residual_first": float(res0) if math.isfinite(res0) else math.nan,
        "tomita_cnna_residual_last": float(res1) if math.isfinite(res1) else math.nan,
        "jensen_shannon_first": float(js0) if math.isfinite(js0) else math.nan,
        "jensen_shannon_last": float(js1) if math.isfinite(js1) else math.nan,
        "modular_spread_first": float(sp0) if math.isfinite(sp0) else math.nan,
        "modular_spread_last": float(sp1) if math.isfinite(sp1) else math.nan,
        "entropy_and_modular_spread_same_trend": same_direction,
        "tomita_cnna_residual_level_trend": res_trend,
        "tomita_entropy_flow_track_computed_status": computed_status,
    }


def tomita_entropy_flow_alignment_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(model, max_regions=config.max_regions, max_boundary=config.max_boundary, max_interior=config.max_interior, max_frontier_level=config.directed_frontier_cap)
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            record = regional_response(model, spec, "record")
            for sign_relation in config.tomita_matrix_sign_relations:
                live = regional_response(model, spec, "live", matrix_sign_relation=sign_relation)
                if live is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "tomita_matrix_sign_relation": sign_relation, "tomita_entropy_flow_computed_status": "live_response_unavailable"})
                    continue
                algebras = local_operator_algebras(live, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                global_alg = algebras["full_regional_response"]
                orientation = live.skew_role
                metrics = finite_tomita_star_metrics(global_alg, live.density, config.algebra_tol, orientation_operator=orientation, orientation_carrier_norm=fro(live.symmetric_role))
                entropy = record_live_entropy_metrics(live.density, record.density, tol=config.algebra_tol) if record is not None else {}
                residual = _finite(metrics.get("tomita_conjuconditions_cnna_orientation_to_negative_residual"))
                if not int(metrics.get("tomita_cnna_orientation_relation_checked", 0)):
                    computed_status = "tomita_orientation_relation_not_checked_control"
                elif residual <= 1.0e-7:
                    computed_status = "tomita_cnna_J_identity_finite_object"
                else:
                    computed_status = "tomita_cnna_J_identity_obstructed_use_flow_derived_quantity"
                rows.append({
                    "branching": b,
                    "level": L,
                    "mode": mode,
                    **meta,
                    "state": "live",
                    "history_reference": "record",
                    "tomita_matrix_sign_relation": sign_relation,
                    **metrics,
                    "jensen_shannon_live_record_no_epsilon": entropy.get("jensen_shannon_live_record_no_epsilon", math.nan),
                    "D_live_given_record_no_epsilon": entropy.get("D_live_given_record_no_epsilon", math.nan),
                    "tomita_entropy_flow_computed_status": computed_status,
                })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        tracks[_track_key(r)].append(r)
    summaries = {k: _summarize(v) for k, v in tracks.items()}
    for r in rows:
        r.update(summaries.get(_track_key(r), {}))
    return rows


def tomita_entropy_flow_alignment_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("tomita_entropy_flow_computed_status", "unknown")) for r in rows})
    tracks = sorted({str(r.get("tomita_entropy_flow_track_computed_status", "unknown")) for r in rows if "tomita_entropy_flow_track_computed_status" in r})
    return (
        "# Tomita flow and live/record entropy alignment\n\n"
        "This replaces the too-strong demand `J_T L_A J_T = -L_A` by a finite trajectory derived_quantity.  "
        "The direct identity residual is still reported, but the physical question is whether modular spread and live/history entropy gradients co-move with level.\n\n"
        "Row computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Track computed_status_rows: `" + "`, `".join(tracks) + "`.\n"
    )
