from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

from cnna.config import EPS
from cnna.derived_quantities.structural_ledgers import is_reference_model


def _finite(x: object, default: float = math.nan) -> float:
    try:
        y = float(x)
    except (TypeError, ValueError):
        return default
    return y if math.isfinite(y) else default


def _key_pair(row: dict) -> Tuple[int, str, str, int, int]:
    return (
        int(row.get("branching", 0)),
        str(row.get("mode", "")),
        str(row.get("state", "")),
        int(row.get("source_level", 0)),
        int(row.get("target_level", 0)),
    )


def _index(rows: Sequence[dict]) -> Dict[Tuple[int, str, str, int, int], dict]:
    out: Dict[Tuple[int, str, str, int, int], dict] = {}
    for r in rows:
        if "source_level" not in r or "target_level" not in r:
            continue
        out[_key_pair(r)] = r
    return out


def _composition_index(rows: Sequence[dict]) -> Dict[Tuple[int, str, str, str, int, int, int], dict]:
    out: Dict[Tuple[int, str, str, str, int, int, int], dict] = {}
    for r in rows:
        try:
            key = (
                int(r.get("branching", 0)),
                str(r.get("mode", "")),
                str(r.get("state", "")),
                str(r.get("structure", "")),
                int(r.get("source_level", 0)),
                int(r.get("mid_level", 0)),
                int(r.get("target_level", 0)),
            )
        except (TypeError, ValueError):
            continue
        out[key] = r
    return out


def _metric(row: dict | None, name: str, default: float = math.nan) -> float:
    if row is None:
        return default
    return _finite(row.get(name, default), default)


def _dominant_seam(metrics: dict) -> str:
    # This is intentionally thresholded by structural meaning, not by raw maximum.
    if metrics["carrier_composition_TV"] <= 1.0e-12 and metrics["compressed_state_composition_TV"] <= 1.0e-12:
        upstream = "carrier_state_composition_residual_le_tolerance"
    else:
        upstream = "carrier_or_state_composition_residual"
    if metrics["product_morphism_residual"] > 1.0e-1:
        return upstream + "; algebra_product_morphism_residual_reference"
    if metrics["GNS_generator_Gram_relative_error"] > 2.5e-1:
        return upstream + "; GNS_inner_product_transport_residual_reference"
    if metrics["CE_state_preservation_drift"] > 5.0e-2:
        return upstream + "; CE_state_preservation_residual_reference"
    if metrics["K_intertwining_relative_error"] > 1.0e-1:
        return upstream + "; modular_logD_transport_residual_reference"
    return upstream + "; no_large_operator_seam_residual_under_current_thresholds"


def _seam_computed_status(metrics: dict) -> str:
    if metrics["carrier_composition_TV"] <= 1.0e-12 and metrics["compressed_state_composition_TV"] <= 1.0e-12:
        if metrics["product_morphism_residual"] > 1.0e-1 or metrics["center_preservation_error"] > 1.0e-1:
            return "1_residual_localized_above_carrier_state_at_algebra_projection"
        if metrics["GNS_generator_Gram_relative_error"] > 2.5e-1:
            return "1_residual_localized_above_carrier_state_at_GNS_transport"
        if metrics["CE_state_preservation_drift"] > 5.0e-2:
            return "1_residual_localized_at_CE_state_preservation"
        if metrics["K_intertwining_relative_error"] > 1.0e-1:
            return "1_residual_localized_at_modular_preflow_after_operator_drift"
    return "1_no_single_operator_seam_residual_or_upstream_unmet_condition"


def operator_stack_seam_localization_rows(
    gns_maps: Sequence[dict],
    alg_maps: Sequence[dict],
    ce_rows: Sequence[dict],
    mod_rows: Sequence[dict],
    comp_rows: Sequence[dict],
    compressed_state_proj: Sequence[dict],
    compressed_state_comp: Sequence[dict],
    carrier_comp: Sequence[dict],
) -> List[dict]:
    """Localize where the 1 operator-stack residual enters.

    The row contract is deliberately derived_quantity: it does not assert a natural
    operator morphism.  It compares the already residual_le_tolerance carrier/compressed-state
    composition with the current finite label-span operator map seams.
    """
    g = _index(gns_maps)
    a = _index(alg_maps)
    c = _index(ce_rows)
    m = _index(mod_rows)
    s = _index(compressed_state_proj)

    comp_state: Dict[Tuple[int, str, str, int, int, int], dict] = {}
    for r in compressed_state_comp:
        try:
            comp_state[(int(r.get("branching", 0)), str(r.get("mode", "")), str(r.get("state", "")), int(r.get("source_level", 0)), int(r.get("mid_level", 0)), int(r.get("target_level", 0)))] = r
        except (TypeError, ValueError):
            continue

    comp_carrier: Dict[Tuple[int, str, int, int, int], dict] = {}
    for r in carrier_comp:
        try:
            comp_carrier[(int(r.get("branching", 0)), str(r.get("mode", "")), int(r.get("source_level", 0)), int(r.get("mid_level", 0)), int(r.get("target_level", 0)))] = r
        except (TypeError, ValueError):
            continue

    op_comp = _composition_index(comp_rows)
    keys = sorted(set(g) | set(a) | set(c) | set(m) | set(s))
    rows: List[dict] = []
    for key in keys:
        b, mode, state, source, target = key
        gr = g.get(key); ar = a.get(key); cr = c.get(key); mr = m.get(key); sr = s.get(key)
        mid = 5 if source == 6 and target == 4 else 0
        cstate = comp_state.get((b, mode, state, source, mid, target)) if mid else None
        ccar = comp_carrier.get((b, mode, source, mid, target)) if mid else None
        gcomp = op_comp.get((b, mode, state, "GNS_generator_U", source, mid, target)) if mid else None
        acomp = op_comp.get((b, mode, state, "Algebra_Pi", source, mid, target)) if mid else None
        modcomp = op_comp.get((b, mode, state, "ModularPreflow_logD", source, mid, target)) if mid else None
        metrics = {
            "carrier_composition_TV": _metric(ccar, "composition_TV", 0.0 if not mid else math.nan),
            "compressed_state_global_TV": _metric(sr, "state_global_TV"),
            "compressed_response_energy_TV": _metric(sr, "response_energy_global_TV"),
            "compressed_state_composition_TV": _metric(cstate, "state_composition_TV", 0.0 if not mid else math.nan),
            "GNS_generator_Gram_relative_error": _metric(gr, "GNS_generator_Gram_relative_error"),
            "cyclic_vector_error": _metric(gr, "cyclic_vector_error"),
            "unitality_error": _metric(ar, "unitality_error"),
            "star_compatibility_error": _metric(ar, "star_compatibility_error"),
            "product_morphism_residual": _metric(ar, "product_morphism_residual"),
            "product_projection_residual_source_span": _metric(ar, "product_projection_residual_source_span"),
            "center_preservation_error": _metric(ar, "center_preservation_error"),
            "CE_commuting_square_error": _metric(cr, "CE_commuting_square_error"),
            "CE_state_preservation_drift": _metric(cr, "CE_state_preservation_drift"),
            "K_intertwining_relative_error": _metric(mr, "K_intertwining_relative_error"),
            "finite_preflow_delta_commuting_square_error": _metric(mr, "finite_preflow_delta_commuting_square_error"),
            "GNS_direct_vs_composed_residual": _metric(gcomp, "direct_vs_composed_residual"),
            "Algebra_direct_vs_composed_residual": _metric(acomp, "direct_vs_composed_residual"),
            "Modular_direct_vs_composed_residual": _metric(modcomp, "direct_vs_composed_residual"),
        }
        rows.append({
            "branching": b,
            "mode": mode,
            "state": state,
            "reference_model": int(is_reference_model(mode, state)),
            "source_level": source,
            "target_level": target,
            "level_gap": source - target,
            "map_kind": "GNS=" + str((gr or {}).get("map", "missing_GNS_map")) + "; Algebra=" + str((ar or {}).get("map", "missing_algebra_Pi_map")),
            **metrics,
            "dominant_seam": _dominant_seam(metrics),
            "computed_status": _seam_computed_status(metrics),
            "condition_note": "1_localizes_operator_stack_residuals; carrier_state_residual_le_tolerance_does_not_promote_GNS_algebra_CE_modular_to_inverse_system",
        })
    return rows


def operator_stack_live_record_sym_comparison_rows(seam_rows: Sequence[dict]) -> List[dict]:
    metrics = [
        "compressed_state_global_TV",
        "compressed_response_energy_TV",
        "GNS_generator_Gram_relative_error",
        "cyclic_vector_error",
        "product_morphism_residual",
        "center_preservation_error",
        "CE_commuting_square_error",
        "CE_state_preservation_drift",
        "K_intertwining_relative_error",
        "finite_preflow_delta_commuting_square_error",
    ]
    by_base: Dict[Tuple[int, str, int, int], Dict[str, dict]] = {}
    for r in seam_rows:
        base = (int(r.get("branching", 0)), str(r.get("mode", "")), int(r.get("source_level", 0)), int(r.get("target_level", 0)))
        by_base.setdefault(base, {})[str(r.get("state", ""))] = r
    rows: List[dict] = []
    for (b, mode, source, target), states in sorted(by_base.items()):
        live = states.get("live")
        record = states.get("record")
        sym = states.get("sym")
        for name in metrics:
            lv = _metric(live, name)
            rv = _metric(record, name)
            sv = _metric(sym, name)
            live_sym_abs = abs(lv - sv) if math.isfinite(lv) and math.isfinite(sv) else math.nan
            live_record_abs = abs(lv - rv) if math.isfinite(lv) and math.isfinite(rv) else math.nan
            rows.append({
                "branching": b,
                "mode": mode,
                "source_level": source,
                "target_level": target,
                "metric": name,
                "live": lv,
                "record": rv,
                "sym": sv,
                "abs_live_minus_sym": live_sym_abs,
                "abs_live_minus_record": live_record_abs,
                "sym_independent_on_this_metric": int(math.isfinite(live_sym_abs) and live_sym_abs > 1.0e-12),
                "record_separates_live_on_this_metric": int(math.isfinite(live_record_abs) and live_record_abs > 1.0e-12),
                "computed_status": "sym_not_independent_for_positive_operator_stack_metric" if math.isfinite(live_sym_abs) and live_sym_abs <= 1.0e-12 else "sym_metric_separates_live",
                "condition_note": "sym_reference_must_be_constructed_independently_before_positive_DtN_if_this_metric_remains_live_identical",
            })
    return rows


def operator_stack_level_scaling_rows(seam_rows: Sequence[dict]) -> List[dict]:
    metrics = [
        "compressed_state_global_TV",
        "compressed_response_energy_TV",
        "GNS_generator_Gram_relative_error",
        "cyclic_vector_error",
        "product_morphism_residual",
        "center_preservation_error",
        "CE_state_preservation_drift",
        "K_intertwining_relative_error",
    ]
    by_base: Dict[Tuple[int, str, str], Dict[Tuple[int, int], dict]] = {}
    for r in seam_rows:
        base = (int(r.get("branching", 0)), str(r.get("mode", "")), str(r.get("state", "")))
        pair = (int(r.get("source_level", 0)), int(r.get("target_level", 0)))
        by_base.setdefault(base, {})[pair] = r
    out: List[dict] = []
    for (b, mode, state), pairs in sorted(by_base.items()):
        r54 = pairs.get((5, 4))
        r65 = pairs.get((6, 5))
        r64 = pairs.get((6, 4))
        for metric in metrics:
            v54 = _metric(r54, metric)
            v65 = _metric(r65, metric)
            v64 = _metric(r64, metric)
            gap1_max = max([x for x in [v54, v65] if math.isfinite(x)] or [math.nan])
            if math.isfinite(v64) and math.isfinite(gap1_max):
                ratio = v64 / max(gap1_max, EPS)
                if ratio > 1.2:
                    scaling = "gap_amplified"
                elif ratio < 0.8:
                    scaling = "gap_damped"
                else:
                    scaling = "gap_stable"
            else:
                ratio = math.nan
                scaling = "insufficient_level_triple"
            out.append({
                "branching": b,
                "mode": mode,
                "state": state,
                "metric": metric,
                "value_5_to_4": v54,
                "value_6_to_5": v65,
                "value_6_to_4": v64,
                "gap2_over_max_gap1": ratio,
                "scaling_computed_status": scaling,
                "condition_note": "finite_L4_L5_L6_scaling_derived_quantity_only; user_local_larger_levels_needed_for_limit_statement",
            })
    return out


def operator_stack_map_naturality_measurement_rows(seam_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    for r in seam_rows:
        prod = _metric(r, "product_morphism_residual")
        star = _metric(r, "star_compatibility_error")
        center = _metric(r, "center_preservation_error")
        unital = _metric(r, "unitality_error")
        residual = _metric(r, "product_projection_residual_source_span")
        if prod <= 1.0e-6 and star <= 1.0e-8 and center <= 1.0e-6 and unital <= 1.0e-8:
            status = "strict_projective_star_hom_finite_object"
            root = "no_large_naturality_residual_detected"
        elif star <= 1.0e-8 and prod > 1.0e-1:
            status = "linear_star_compatible_but_nonmultiplicative"
            root = "label_span_projection_is_not_an_algebra_morphism"
        elif center > 1.0e-1:
            status = "center_not_preserved"
            root = "operator_projection_does_not_preserve_common_center"
        else:
            status = "finite_linear_projection_with_quantified_residual"
            root = "operator_projection_requires_replacement_or_subalgebra_restriction"
        rows.append({
            "branching": int(r.get("branching", 0)),
            "mode": str(r.get("mode", "")),
            "state": str(r.get("state", "")),
            "reference_model": int(r.get("reference_model", 0)),
            "source_level": int(r.get("source_level", 0)),
            "target_level": int(r.get("target_level", 0)),
            "map_kind": str(r.get("map_kind", "label_span_operator_stack_derived_quantity")),
            "unitality_error": unital,
            "star_compatibility_error": star,
            "product_morphism_residual": prod,
            "product_projection_residual_source_span": residual,
            "center_preservation_error": center,
            "naturality_status": status,
            "root_cause": root,
            "condition_note": "current_Pi_U_are_derived_quantity_label_span_maps_not_derived_effect_pushforward_operator_morphisms",
        })
    return rows


def write_operator_stack_residual_report(outdir: Path, seam_rows: Sequence[dict], comparison_rows: Sequence[dict], scaling_rows: Sequence[dict], naturality_rows: Sequence[dict]) -> None:
    reference = [r for r in seam_rows if int(r.get("reference_model", 0)) == 1]
    reference64 = [r for r in reference if int(r.get("source_level", 0)) == 6 and int(r.get("target_level", 0)) == 4]
    p = reference64[0] if reference64 else (reference[0] if reference else {})
    reference_nat = [r for r in naturality_rows if int(r.get("reference_model", 0)) == 1 and int(r.get("source_level", 0)) == int(p.get("source_level", -1)) and int(r.get("target_level", 0)) == int(p.get("target_level", -1))]
    n = reference_nat[0] if reference_nat else {}
    sym_identical = [r for r in comparison_rows if int(r.get("source_level", 0)) == int(p.get("source_level", -1)) and int(r.get("target_level", 0)) == int(p.get("target_level", -1)) and int(r.get("sym_independent_on_this_metric", 1)) == 0]
    text = f"""# Operator-stack residual localization

## Fixed baseline used by this measurement

The measurement keeps 0 fixed as: carrier/compressed-state projectivity residual_le_tolerance, terminal diagonal state as control only, and GNS/Algebra/CE/Modular as residual-bearing finite derived_quantity rows.

## Reference 1 finding

`{p.get('1_computed_status', 'no_reference_row')}`

Dominant seam:

```text
{p.get('dominant_seam', 'no_dominant_seam')}
```

Reference pair inspected: `{p.get('target_level', '?')}←{p.get('source_level', '?')}`, `b={p.get('branching', '?')}`, `mode={p.get('mode', '?')}`, `state={p.get('state', '?')}`.

Core numbers:

```text
carrier_composition_TV                  = {p.get('carrier_composition_TV', 'n/a')}
compressed_state_global_TV              = {p.get('compressed_state_global_TV', 'n/a')}
compressed_state_composition_TV         = {p.get('compressed_state_composition_TV', 'n/a')}
compressed_response_energy_TV           = {p.get('compressed_response_energy_TV', 'n/a')}
GNS_generator_Gram_relative_error       = {p.get('GNS_generator_Gram_relative_error', 'n/a')}
cyclic_vector_error                     = {p.get('cyclic_vector_error', 'n/a')}
product_morphism_residual                 = {p.get('product_morphism_residual', 'n/a')}
center_preservation_error               = {p.get('center_preservation_error', 'n/a')}
CE_commuting_square_error               = {p.get('CE_commuting_square_error', 'n/a')}
CE_state_preservation_drift             = {p.get('CE_state_preservation_drift', 'n/a')}
K_intertwining_relative_error           = {p.get('K_intertwining_relative_error', 'n/a')}
```

## Natural map status

`{n.get('naturality_status', 'no_naturality_row')}`

Root cause:

```text
{n.get('root_cause', 'no_root_cause')}
```

Interpretation: the current finite map is a label-span derived_quantity map.  It is useful because it exposes the rank_bound, but it is not yet the CNNA-natural effect-pushforward/GNS/operator morphism required for a strict operator inverse system.

## Sym-control condition_not_met

Metrics with live/sym equality at the reference pair: `{len(sym_identical)}`.  If these remain equal at larger local runs, the current positive operator-stack `sym` control has zero separation between these residual classes in that row family.

## Non-statements

This report does not statement a von Neumann algebra, KMS condition, Type-III limit, split property, completed GNS Hilbert space, or strict projective `*`-homomorphism.  It localizes the finite 1 residual that blocks those later statements.
"""
    (outdir / "1_OPERATOR_STACK_DEFECT_REPORT.md").write_text(text, encoding="utf-8")
