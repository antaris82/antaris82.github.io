from __future__ import annotations

from typing import List


def finite_finite_property_inventory_rows() -> List[dict]:
    """Classify current finite property finite_objects without importing old statements."""
    return [
        {
            "finite_object": "finite directed A/J orientation object",
            "object_layer": "directed response skew current",
            "current_core_status": "current_fact",
            "finite_statement_kind": "computed orientation finite_object",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "none_for_entry",
            "condition_note": "finite A/J orientation only; no physical continuum i statement",
        },
        {
            "finite_object": "projective A/J orientation transport",
            "object_layer": "address-prefix transport of signed current plane",
            "current_core_status": "current_fact",
            "finite_statement_kind": "transport/composition derived_quantity",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "none_for_entry",
            "condition_note": "orientation projectivity, not amplitude projectivity",
        },
        {
            "finite_object": "local J sign bound with global flip free",
            "object_layer": "local/global sign sign_relation",
            "current_core_status": "current_fact",
            "finite_statement_kind": "sign-sign_relation derived_quantity",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "none_for_entry",
            "condition_note": "absolute global J sign is not fixed and should remain sign_relational",
        },
        {
            "finite_object": "finite region-net grammar",
            "object_layer": "local region inclusion/complement data",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "definition/poset comparison",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "construct in refactored core",
            "condition_note": "regions must be explicit finite node sets; no implicit AQFT net statement",
        },
        {
            "finite_object": "finite isotony preform",
            "object_layer": "local operator span/algebra assignment",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "inclusion-morphism measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute in refactored core",
            "condition_note": "tests finite span inclusion only unless exact conditions pass",
        },
        {
            "finite_object": "finite locality / commutator preform",
            "object_layer": "separated local operator algebras",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "commutator measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute in refactored core",
            "condition_note": "noncommutation in A/B layer is a result, not automatic failure",
        },
        {
            "finite_object": "finite additivity preform",
            "object_layer": "generated local algebra for unions",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "span-generation measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute in refactored core",
            "condition_note": "boundary correction must be reported explicitly",
        },
        {
            "finite_object": "finite local cyclic/separating Omega preform",
            "object_layer": "finite GNS support of local algebras",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "Hilbert/GNS rank measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute true subregion action on global support",
            "condition_note": "total algebra cyclicity is not enough",
        },
        {
            "finite_object": "finite faithful-state separating test",
            "object_layer": "state Gram form on local algebras",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "Gram nullity measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute local Gram rank/nullity",
            "condition_note": "faithfulness is finite represented faithfulness only",
        },
        {
            "finite_object": "finite Tomita standard-form compatibility comparison",
            "object_layer": "star map on finite GNS support and signed A/J plane",
            "current_core_status": "not_yet_tested",
            "finite_statement_kind": "standard-form compatibility measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute finite star-map support and J-plane compatibility",
            "condition_note": "Tomita conjugation is not identified with linear J orientation",
        },
        {
            "finite_object": "finite commutant / Haag-duality preform",
            "object_layer": "commutants of sibling-local algebras",
            "current_core_status": "partially_machievable",
            "finite_statement_kind": "commutant distance measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute only after complement sign_relation is explicit",
            "condition_note": "finite complement is a CNNA cut sign_relation, not continuum causal complement",
        },
        {
            "finite_object": "finite split / tensor-factorization preform",
            "object_layer": "separated sibling-local algebra join",
            "current_core_status": "partially_machievable",
            "finite_statement_kind": "factorization-rank measurement",
            "strict_property_statement": 0,
            "continuum_statement": 0,
            "required_reproduction_action": "compute after locality/additivity conditions",
            "condition_note": "no AQFT split property statement",
        },
    ]


def previous_reproduction_measurement_rows() -> List[dict]:
    return [
        {
            "previous_finite_object": "old isotony/inclusion derived_quantity rows",
            "old_source_status": "historical_v11_v12_reference_only",
            "current_core_reproduced": 0,
            "reproduction_target": "local_operator_isotony module",
            "safe_report_status": "old_code_needs_reproduction",
        },
        {
            "previous_finite_object": "old split/commutator derived_quantity rows",
            "old_source_status": "historical_v11_v12_reference_only",
            "current_core_reproduced": 0,
            "reproduction_target": "local_operator_commutation and split_factorization modules",
            "safe_report_status": "old_code_needs_reproduction",
        },
        {
            "previous_finite_object": "old cyclic/separating standard-form derived_quantity rows",
            "old_source_status": "historical_v11_v12_reference_only",
            "current_core_reproduced": 0,
            "reproduction_target": "local_vacuum_cyclicity, faithful_state, tomita_standard_form modules",
            "safe_report_status": "old_code_needs_reproduction",
        },
        {
            "previous_finite_object": "C*/vN/KMS/Type-III language",
            "old_source_status": "not_established_by_current_finite_core",
            "current_core_reproduced": 0,
            "reproduction_target": "not_a_computational_target",
            "safe_report_status": "invalid_overstatement_for_current_scope",
        },
    ]


def finite_property_inventory_report() -> str:
    return """# Finite property inventory and reproduction condition_note\n\nThis report classifies property-like CNNA statements before running local-operator property comparisons.  Current finite_core finite directed A/J facts remain available.  Older isotony, split, commutator, cyclic, or separating evidence is treated as historical-only until reproduced by the new `object_checks` modules.\n\nNo C*-completion, von Neumann algebra, KMS property, Type-III statement, full Haag-Kastler net, full Reeh-Schlieder property, or full Tomita-Takesaki property is stated here.\n"""
