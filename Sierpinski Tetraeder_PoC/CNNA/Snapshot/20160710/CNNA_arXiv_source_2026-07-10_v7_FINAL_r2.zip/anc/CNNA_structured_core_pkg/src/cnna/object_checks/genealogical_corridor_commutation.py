from __future__ import annotations

from typing import List

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    local_operator_algebras,
    state_commutator_metric,
)
from cnna.core.operator_test_config import OperatorTestConfig
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


CORRIDOR_LOCALITY_PAIRS = [
    ("left_frontier_response", "right_frontier_response", "frontier_without_shared_lca_anchor"),
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "symmetric_birth_cones_with_shared_lca_anchor"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "directed_birth_cones_with_shared_lca_anchor"),
    ("left_birth_cone_response", "right_birth_cone_response", "mixed_birth_cones_with_shared_lca_anchor"),
]


def _computed_status(max_rel: float, state_abs: float, corridor: int, direct_sibling: int, tol: float, sign_relation: str) -> str:
    if sign_relation == "frontier_without_shared_lca_anchor" and max_rel <= tol and state_abs <= tol:
        return "structurally_commuting_disjoint_frontier_control"
    if corridor == 0 and direct_sibling:
        if max_rel <= tol and state_abs <= tol:
            return "touching_sibling_commutation_control"
        return "touching_sibling_noncommutation_expected"
    if corridor >= 2 and max_rel <= tol and state_abs <= tol:
        return "collared_genealogical_commutation_finite_object"
    if corridor >= 2:
        return "collared_genealogical_noncommutation_observed"
    return "uncollared_genealogical_commutation_derived_quantity"


def genealogical_corridor_commutator_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    from cnna.core.operator_test_config import iter_growth_models
    for b, L, mode, model in iter_growth_models(config):
        for spec in build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        ):
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    rows.append({"branching": b, "level": L, "mode": mode, **meta, "state": state, "corridor_commutation_computed_status": "response_unavailable"})
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                base = {"branching": b, "level": L, "mode": mode, **meta, "state": state, **resp.density_metadata}
                for left_name, right_name, sign_relation in CORRIDOR_LOCALITY_PAIRS:
                    left = algebras[left_name]
                    right = algebras[right_name]
                    met = commutator_metrics(left, right)
                    state_abs = state_commutator_metric(left, right, resp.density)
                    corridor = int(meta["genealogical_corridor_length"])
                    direct = int(meta["direct_sibling_birth_coupling"])
                    rows.append({
                        **base,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "corridor_test_sign_relation": sign_relation,
                        "left_dim": len(left.basis),
                        "right_dim": len(right.basis),
                        **met,
                        "max_state_commutator_abs_no_epsilon": state_abs,
                        "corridor_commutation_computed_status": _computed_status(float(met["max_relative_commutator"]), float(state_abs), corridor, direct, config.algebra_tol, sign_relation),
                    })
    return rows


def genealogical_corridor_commutation_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("corridor_commutation_computed_status", "unknown")) for r in rows})
    return "# Genealogical-corridor commutation report\n\nTests finite locality only where it can be meaningfully tested: touching sibling cones are labelled separately from collared cousin/deeper cones.  Frontier rows without the shared LCA anchor remain structural controls.  The surface asks whether commutator norms decrease or vanish with genealogical corridor length; it does not statement Haag-Kastler locality.\n\nObserved computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n"
