from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import *

@dataclass(frozen=True)
class RuleCoefficients:
    """b-derived deterministic rule coefficients.

    These are not CLI/model parameters.  They are generated from the branching
    arity b so that the reference finite model remains CNNA(b,L).  The constants
    0,1,2 in these expressions are structural arithmetic units, not tunable
    parameters.  The CSV `CNNA_fixed_rule_constants_measurement.csv` records them.
    """
    env_birth_edge_bias: float
    forward_rank_bias: float
    backward_base: float
    backward_rank_bias: float
    ancestor_backreaction: float
    ancestor_node_load: float
    sibling_backreaction: float
    sibling_forward_asym: float
    sibling_backward_asym: float
    sibling_node_load: float
    child_env_load: float


def rule_coefficients(branching: int) -> RuleCoefficients:
    b = float(branching)
    return RuleCoefficients(
        env_birth_edge_bias=1.0 / ((b + 1.0) ** 2),
        forward_rank_bias=1.0 / (b + 3.0),
        backward_base=0.5 + 1.0 / (2.0 * (b + 2.0)),
        backward_rank_bias=1.0 / ((b + 1.0) * (b + 3.0)),
        ancestor_backreaction=1.0 / (b * (b + 1.0)),
        ancestor_node_load=1.0 / ((b + 2.0) ** 2),
        sibling_backreaction=1.0 / (b * (b + 2.0)),
        sibling_forward_asym=1.0 + 1.0 / (b + 1.0),
        sibling_backward_asym=1.0 - 1.0 / (b + 1.0),
        sibling_node_load=1.0 / ((b + 7.0) ** 2),
        child_env_load=1.0 / ((b + 7.0) ** 2),
    )


@dataclass
class Node:
    nid: int
    address: Tuple[int, ...]
    level: int
    parent: Optional[int]
    birth_time: int
    sibling_rank: int
    causal_depth: int
    linearization_index: int
    g: float
    birth_g: float
    lapse_weight: float
    children: List[int] = field(default_factory=list)
    child_by_rank: Dict[int, int] = field(default_factory=dict)


@dataclass
class Event:
    event_id: int
    kind: str
    parent: Optional[int]
    child: Optional[int]
    address: Tuple[int, ...]
    level: int
    causal_depth: int
    sibling_rank: int
    linearization_index: int
    occupied_siblings_before: Tuple[int, ...]
    ancestors: Tuple[int, ...]
    env_load: float
    birth_g: float
    lapse_weight: float
    saturation_before: int
    saturation_after: int

    @property
    def older_siblings(self) -> Tuple[int, ...]:
        return self.occupied_siblings_before


@dataclass(frozen=True)
class OpenBirthSlot:
    parent: int
    sibling_rank: int
    address: Tuple[int, ...]
    causal_depth: int
    occupied_before: int
    capacity: int


@dataclass(frozen=True)
class GrowthStep:
    step_id: int
    slot: OpenBirthSlot
    causal_predecessors: Tuple[int, ...]
    linearization_index: int
    occupied_siblings_before: Tuple[int, ...]
    env_load: float
    birth_g: float
    lapse_weight: float


class EmptySetGrowthModel:
    """Self-contained deterministic CNNA growth model."""

    def __init__(
        self,
        branching: int,
        max_level: int,
        mode: str = "linear",
        reverse_sibling_order: bool = False,
        sibling_linearization: Optional[str] = None,
        growth_schedule: str = "slot_step",
    ):
        if branching < 2:
            raise ValueError("branching must be >= 2")
        if max_level < 0:
            raise ValueError("max_level must be >= 0")
        if mode not in {"linear", "log", "saturating"}:
            raise ValueError("mode must be linear/log/saturating")
        if sibling_linearization is None:
            sibling_linearization = "reverse_rank" if reverse_sibling_order else "rank"
        if sibling_linearization not in {"rank", "reverse_rank"}:
            raise ValueError("sibling_linearization must be rank/reverse_rank")
        if growth_schedule not in {"slot_step", "layer_batch"}:
            raise ValueError("growth_schedule must be slot_step/layer_batch")
        self.b = int(branching)
        self.L = int(max_level)
        self.mode = mode
        self.reverse_sibling_order = bool(reverse_sibling_order)
        self.sibling_linearization = sibling_linearization
        self.growth_schedule = growth_schedule
        self.rc = rule_coefficients(self.b)
        self.nodes: List[Node] = []
        self.addr_to_id: Dict[Tuple[int, ...], int] = {}
        self.events: List[Event] = []
        self.live_edges: Dict[Tuple[int, int], float] = {}
        self.record_edges: Dict[Tuple[int, int], float] = {}
        self._event("empty_state", None, None, tuple(), -1, -1, -1, -1, tuple(), tuple(), 0.0, 0.0, 0.0, 0, 0)
        self._birth_root_from_empty()
        self._grow_to_level()

    def _event(
        self,
        kind: str,
        parent: Optional[int],
        child: Optional[int],
        address: Tuple[int, ...],
        level: int,
        causal_depth: int,
        sibling_rank: int,
        linearization_index: int,
        occupied_siblings_before: Tuple[int, ...],
        ancestors: Tuple[int, ...],
        env_load: float,
        birth_g: float,
        lapse_weight: float,
        saturation_before: int,
        saturation_after: int,
    ) -> None:
        self.events.append(Event(
            len(self.events), kind, parent, child, tuple(address), int(level), int(causal_depth),
            int(sibling_rank), int(linearization_index), tuple(occupied_siblings_before), tuple(ancestors),
            float(env_load), float(birth_g), float(lapse_weight), int(saturation_before), int(saturation_after),
        ))

    def _mode_scale(self, x: float) -> float:
        if self.mode == "linear":
            return float(x)
        if self.mode == "log":
            return float(math.log1p(max(0.0, x)))
        return float(x / (1.0 + abs(x)))

    def _birth_root_from_empty(self) -> None:
        root = Node(
            nid=0,
            address=tuple(),
            level=0,
            parent=None,
            birth_time=len(self.events),
            sibling_rank=0,
            causal_depth=0,
            linearization_index=0,
            g=1.0,
            birth_g=1.0,
            lapse_weight=1.0,
        )
        self.nodes.append(root)
        self.addr_to_id[root.address] = root.nid
        self._event("birth_root_from_empty", None, 0, tuple(), 0, 0, 0, 0, tuple(), tuple(), 0.0, 1.0, 1.0, 0, 1)

    def ancestors(self, nid: int, include_self: bool = False) -> List[int]:
        out: List[int] = []
        cur: Optional[int] = nid if include_self else self.nodes[nid].parent
        while cur is not None:
            out.append(cur)
            cur = self.nodes[cur].parent
        return out

    def descendants(self, nid: int, include_self: bool = True) -> List[int]:
        base = self.nodes[nid].address
        out = []
        for n in self.nodes:
            if len(n.address) >= len(base) and n.address[:len(base)] == base:
                if include_self or n.nid != nid:
                    out.append(n.nid)
        return out

    def terminal_descendants(self, nid: int) -> List[int]:
        return [x for x in self.descendants(nid, include_self=True) if self.nodes[x].level == self.L]

    def add_edge(self, edges: Dict[Tuple[int, int], float], i: int, j: int, w: float) -> None:
        if i == j or abs(w) <= 0:
            return
        edges[(i, j)] = float(edges.get((i, j), 0.0) + w)

    def _children_by_rank(self, parent: int) -> Tuple[int, ...]:
        node = self.nodes[parent]
        return tuple(node.child_by_rank[r] for r in sorted(node.child_by_rank))

    def _refresh_children_order(self, parent: int) -> None:
        self.nodes[parent].children = list(self._children_by_rank(parent))

    def open_birth_slots(self, parent: Node) -> List[OpenBirthSlot]:
        occupied = set(parent.child_by_rank.keys())
        slots: List[OpenBirthSlot] = []
        for rank in range(self.b):
            if rank not in occupied:
                slots.append(OpenBirthSlot(
                    parent=parent.nid,
                    sibling_rank=rank,
                    address=parent.address + (rank,),
                    causal_depth=parent.level + 1,
                    occupied_before=len(occupied),
                    capacity=self.b,
                ))
        return slots

    def _linearize_open_slots(self, slots: Sequence[OpenBirthSlot]) -> List[OpenBirthSlot]:
        if self.sibling_linearization == "reverse_rank":
            return sorted(slots, key=lambda s: (s.causal_depth, s.parent, -s.sibling_rank, s.address))
        return sorted(slots, key=lambda s: (s.causal_depth, s.parent, s.sibling_rank, s.address))

    def _birth_environment_load(self, parent: int, occupied_siblings: Sequence[int], current: bool = True) -> float:
        def ng(x: int) -> float:
            return self.nodes[x].g if current else self.nodes[x].birth_g
        load = ng(parent)
        for depth, a in enumerate(self.ancestors(parent), start=1):
            load += ng(a) / float((depth + 1) ** 2)
        if occupied_siblings:
            load += sum(ng(s) for s in occupied_siblings) / float(len(occupied_siblings) + 1)
        return float(load)

    def _make_growth_step(self, slot: OpenBirthSlot, linearization_index: int) -> GrowthStep:
        occupied = self._children_by_rank(slot.parent)
        env_load = self._birth_environment_load(slot.parent, occupied, current=True)
        parent = self.nodes[slot.parent]
        birth_g = 1.0 + self._mode_scale(env_load) / float(1 + parent.level + self.b)
        return GrowthStep(
            step_id=len(self.events),
            slot=slot,
            causal_predecessors=tuple(self.ancestors(slot.parent, include_self=True)),
            linearization_index=int(linearization_index),
            occupied_siblings_before=tuple(occupied),
            env_load=float(env_load),
            birth_g=float(birth_g),
            lapse_weight=float(birth_g),
        )

    def _base_birth_edge_weights(self, step: GrowthStep) -> Tuple[float, float, float]:
        rank = int(step.slot.sibling_rank)
        w0 = 1.0 + self.rc.env_birth_edge_bias * self._mode_scale(step.env_load)
        rank_bias = (rank + 1) / float(self.b)
        w_forward = w0 * (1.0 + self.rc.forward_rank_bias * rank_bias)
        w_backward = w0 * (self.rc.backward_base + self.rc.backward_rank_bias * rank_bias)
        return float(w0), float(w_forward), float(w_backward)

    def _apply_growth_step(self, step: GrowthStep, add_sibling_edges: bool = True) -> int:
        parent = self.nodes[step.slot.parent]
        rank = int(step.slot.sibling_rank)
        address = tuple(step.slot.address)
        if address in self.addr_to_id:
            raise RuntimeError(f"duplicate growth address {address}")
        saturation_before = len(parent.child_by_rank)
        nid = len(self.nodes)
        child = Node(
            nid=nid,
            address=address,
            level=parent.level + 1,
            parent=parent.nid,
            birth_time=len(self.events),
            sibling_rank=rank,
            causal_depth=step.slot.causal_depth,
            linearization_index=step.linearization_index,
            g=step.birth_g,
            birth_g=step.birth_g,
            lapse_weight=step.lapse_weight,
        )
        self.nodes.append(child)
        self.addr_to_id[address] = nid
        parent.child_by_rank[rank] = nid
        self._refresh_children_order(parent.nid)
        saturation_after = len(parent.child_by_rank)
        self._event(
            "slot_child_birth",
            parent.nid,
            nid,
            address,
            child.level,
            child.causal_depth,
            rank,
            step.linearization_index,
            step.occupied_siblings_before,
            step.causal_predecessors,
            step.env_load,
            step.birth_g,
            step.lapse_weight,
            saturation_before,
            saturation_after,
        )

        w0, w_forward, w_backward = self._base_birth_edge_weights(step)
        self.add_edge(self.record_edges, parent.nid, nid, w_forward)
        self.add_edge(self.record_edges, nid, parent.nid, w_backward)
        self.add_edge(self.live_edges, parent.nid, nid, w_forward)
        self.add_edge(self.live_edges, nid, parent.nid, w_backward)

        for depth, a in enumerate(step.causal_predecessors, start=1):
            wb = self.rc.ancestor_backreaction * w0 / float(depth + 1)
            self.add_edge(self.live_edges, nid, a, wb)
            self.nodes[a].g += self.rc.ancestor_node_load * wb
        if add_sibling_edges:
            self._add_slot_sibling_relations(parent.nid, nid, step.occupied_siblings_before, w0)
        child.g += self.rc.child_env_load * step.env_load
        return nid

    def _add_slot_sibling_relations(self, parent: int, child: int, siblings: Sequence[int], w0: float) -> None:
        child_rank = int(self.nodes[child].sibling_rank)
        for sib in sorted(set(int(s) for s in siblings), key=lambda n: self.nodes[n].sibling_rank):
            sib_rank = int(self.nodes[sib].sibling_rank)
            rank_distance = abs(child_rank - sib_rank) + 1
            ws = self.rc.sibling_backreaction * float(w0) / float(rank_distance + 1)
            if sib_rank <= child_rank:
                src, dst = sib, child
            else:
                src, dst = child, sib
            self.add_edge(self.live_edges, src, dst, self.rc.sibling_forward_asym * ws)
            self.add_edge(self.live_edges, dst, src, self.rc.sibling_backward_asym * ws)
            self.nodes[sib].g += self.rc.sibling_node_load * ws

    def _apply_batch_sibling_relations(self, child_steps: Sequence[Tuple[int, GrowthStep]]) -> None:
        by_parent: Dict[int, List[Tuple[int, GrowthStep]]] = {}
        for nid, step in child_steps:
            by_parent.setdefault(step.slot.parent, []).append((nid, step))
        for parent, pairs in by_parent.items():
            pairs_sorted = sorted(pairs, key=lambda x: self.nodes[x[0]].sibling_rank)
            for i in range(len(pairs_sorted)):
                ni, si = pairs_sorted[i]
                w0_i, _, _ = self._base_birth_edge_weights(si)
                for j in range(i + 1, len(pairs_sorted)):
                    nj, sj = pairs_sorted[j]
                    w0_j, _, _ = self._base_birth_edge_weights(sj)
                    w0 = 0.5 * (w0_i + w0_j)
                    self._add_slot_sibling_relations(parent, nj, [ni], w0)

    def _grow_to_level(self) -> None:
        for depth in range(self.L):
            parents = [n for n in self.nodes if n.level == depth]
            slots: List[OpenBirthSlot] = []
            for parent in parents:
                slots.extend(self.open_birth_slots(parent))
            if not slots:
                continue
            ordered_slots = self._linearize_open_slots(slots)
            if self.growth_schedule == "layer_batch":
                steps = [self._make_growth_step(slot, i) for i, slot in enumerate(ordered_slots)]
                created: List[Tuple[int, GrowthStep]] = []
                for step in steps:
                    created.append((self._apply_growth_step(step, add_sibling_edges=False), step))
                self._apply_batch_sibling_relations(created)
            else:
                for i, slot in enumerate(ordered_slots):
                    step = self._make_growth_step(slot, i)
                    self._apply_growth_step(step, add_sibling_edges=True)

    def node_count_expected(self) -> int:
        return sum(self.b ** k for k in range(self.L + 1))

    def event_log_rows(self) -> List[dict]:
        rows = []
        for ev in self.events:
            rows.append({
                "event_id": ev.event_id,
                "kind": ev.kind,
                "parent": "" if ev.parent is None else ev.parent,
                "child": "" if ev.child is None else ev.child,
                "address": ".".join(map(str, ev.address)),
                "level": ev.level,
                "causal_depth": ev.causal_depth,
                "sibling_rank": ev.sibling_rank,
                "linearization_index": ev.linearization_index,
                "occupied_siblings_before": " ".join(map(str, ev.occupied_siblings_before)),
                "ancestors": " ".join(map(str, ev.ancestors)),
                "env_load": ev.env_load,
                "birth_g": ev.birth_g,
                "lapse_weight": ev.lapse_weight,
                "saturation_before": ev.saturation_before,
                "saturation_after": ev.saturation_after,
            })
        return rows

    def adjacency(self, state: str = "live") -> np.ndarray:
        n = len(self.nodes)
        A = np.zeros((n, n), dtype=float)
        if state == "live":
            edges = self.live_edges
        elif state == "record":
            edges = self.record_edges
        elif state == "sym":
            edges = self.live_edges
        else:
            raise ValueError("state must be live/record/sym")
        for (i, j), w in edges.items():
            A[i, j] += float(w)
        if state == "sym":
            A = 0.5 * (A + A.T)
        return A

    def conductance_matrix(self, state: str = "live") -> np.ndarray:
        A = self.adjacency(state)
        C = 0.5 * (A + A.T)
        C[C < 0] = 0.0
        return C

    def laplacian(self, state: str = "live") -> np.ndarray:
        C = self.conductance_matrix(state)
        K = np.diag(np.sum(C, axis=1)) - C
        return 0.5 * (K + K.T)
