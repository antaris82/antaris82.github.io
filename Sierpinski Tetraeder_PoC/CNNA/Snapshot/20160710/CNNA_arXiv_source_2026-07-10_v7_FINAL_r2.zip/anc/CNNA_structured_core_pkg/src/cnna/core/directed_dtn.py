from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.emptyset_growth import EmptySetGrowthModel
from cnna.core.math_utils import fro
from cnna.core.schur_dtn import RegionSpec


@dataclass
class DirectedSchurResponse:
    ok: bool
    Lambda: Optional[np.ndarray]
    cond_KII: float
    solve_residual: float
    row_sum_residual: float
    error: str = ""
    matrix_sign_relation: str = "out_degree"
    boundary_response_model: str = "open_grounded_directed"


def state_directed_edges(model: EmptySetGrowthModel, state: str) -> Dict[Tuple[int, int], float]:
    """Return the directed edge dictionary for the requested state.

    `sym` is an explicit control state: it replaces the directed live edges by
    their symmetric pair average.  live/record keep the birth/backreaction
    orientation.
    """
    raw = model.record_edges if state == "record" else model.live_edges
    if state != "sym":
        return raw
    keys = set()
    for i, j in raw.keys():
        if i != j:
            keys.add((min(i, j), max(i, j)))
    out: Dict[Tuple[int, int], float] = {}
    for i, j in keys:
        s = 0.5 * (float(raw.get((i, j), 0.0)) + float(raw.get((j, i), 0.0)))
        if abs(s) > 0.0:
            out[(i, j)] = s
            out[(j, i)] = s
    return out


def directed_local_matrix(
    model: EmptySetGrowthModel,
    state: str,
    selected: Sequence[int],
    *,
    include_external_degrees: bool = True,
    matrix_sign_relation: str = "out_degree",
) -> np.ndarray:
    """Build a directed local Laplace/response matrix without symmetrizing edges.

    out_degree sign_relation: K_ii=sum_j W_ij, K_ij=-W_ij.
    in_degree sign_relation:  K_ii=sum_j W_ji, K_ij=-W_ji.

    `include_external_degrees=True` keeps total diagonal load to the full graph
    and only restricts off-diagonal entries to selected nodes.  This is the
    directed analogue of the existing open/grounded regional response.
    """
    if matrix_sign_relation not in {"out_degree", "in_degree"}:
        raise ValueError("matrix_sign_relation must be out_degree or in_degree")
    selected_list = list(dict.fromkeys(selected))
    selected_set = set(selected_list)
    pos = {nid: k for k, nid in enumerate(selected_list)}
    K = np.zeros((len(selected_list), len(selected_list)), dtype=float)
    edges = state_directed_edges(model, state)
    for (i, j), w0 in edges.items():
        if i == j:
            continue
        w = float(w0)
        if abs(w) <= 0.0:
            continue
        if matrix_sign_relation == "out_degree":
            row, col = i, j
        else:
            # In-degree derived_quantity is equivalent to applying the out-degree
            # sign_relation to W^T.  It is not a second theory; it is a sign/
            # sign_relation measurement.
            row, col = j, i
        row_in = row in pos
        col_in = col in pos
        if not row_in:
            continue
        if include_external_degrees or col_in:
            K[pos[row], pos[row]] += w
        if col_in:
            K[pos[row], pos[col]] -= w
    return K


def directed_schur_response(
    K: np.ndarray,
    boundary: Sequence[int],
    interior: Sequence[int],
    *,
    cond_max: float = 1.0e12,
    matrix_sign_relation: str = "out_degree",
    boundary_response_model: str = "open_grounded_directed",
) -> DirectedSchurResponse:
    """Schur/Kron response for a possibly non-symmetric local matrix.

    No symmetrization is applied.  The returned Lambda is the directed response
    Lambda_dir; downstream derived_quantity rows must decompose Lambda_dir into S/A.
    """
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    if not B:
        return DirectedSchurResponse(False, None, math.nan, math.nan, math.nan, "empty_boundary", matrix_sign_relation, boundary_response_model)
    if set(B) & set(I):
        return DirectedSchurResponse(False, None, math.nan, math.nan, math.nan, "boundary_interior_overlap", matrix_sign_relation, boundary_response_model)
    if not I:
        L = K[np.ix_(B, B)].copy()
        rowsum = float(np.max(np.abs(np.sum(L, axis=1)))) if L.size else 0.0
        return DirectedSchurResponse(True, L, 1.0, 0.0, rowsum, "", matrix_sign_relation, boundary_response_model)
    KBB = K[np.ix_(B, B)]
    KBI = K[np.ix_(B, I)]
    KIB = K[np.ix_(I, B)]
    KII = K[np.ix_(I, I)]
    try:
        cond = float(np.linalg.cond(KII)) if KII.size else 1.0
        if not math.isfinite(cond) or cond > cond_max:
            return DirectedSchurResponse(False, None, cond, math.nan, math.nan, "singular_or_ill_conditioned_KII", matrix_sign_relation, boundary_response_model)
        X = np.linalg.solve(KII, KIB)
        residual = fro(KII @ X - KIB) / max(fro(KIB), EPS)
        L = KBB - KBI @ X
        rowsum = float(np.max(np.abs(np.sum(L, axis=1)))) if L.size else 0.0
        return DirectedSchurResponse(True, L, cond, residual, rowsum, "", matrix_sign_relation, boundary_response_model)
    except np.linalg.LinAlgError as exc:
        return DirectedSchurResponse(False, None, math.nan, math.nan, math.nan, f"lin_alg_error:{exc}", matrix_sign_relation, boundary_response_model)


def directed_schur_response_from_model(
    model: EmptySetGrowthModel,
    state: str,
    boundary: Sequence[int],
    interior: Sequence[int],
    *,
    cond_max: float = 1.0e12,
    include_external_degrees: bool = True,
    matrix_sign_relation: str = "out_degree",
) -> DirectedSchurResponse:
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    if not B:
        return DirectedSchurResponse(False, None, math.nan, math.nan, math.nan, "empty_boundary", matrix_sign_relation, "open_grounded_directed")
    if set(B) & set(I):
        return DirectedSchurResponse(False, None, math.nan, math.nan, math.nan, "boundary_interior_overlap", matrix_sign_relation, "open_grounded_directed")
    selected = B + I
    Kloc = directed_local_matrix(
        model,
        state,
        selected,
        include_external_degrees=include_external_degrees,
        matrix_sign_relation=matrix_sign_relation,
    )
    relations = "open_grounded_directed" if include_external_degrees else "closed_internal_directed"
    bidx = list(range(len(B)))
    iidx = list(range(len(B), len(B) + len(I)))
    return directed_schur_response(Kloc, bidx, iidx, cond_max=cond_max, matrix_sign_relation=matrix_sign_relation, boundary_response_model=relations)


def directed_environment_port_response_from_model(
    model: EmptySetGrowthModel,
    state: str,
    boundary: Sequence[int],
    interior: Sequence[int],
    *,
    cond_max: float = 1.0e12,
    matrix_sign_relation: str = "out_degree",
) -> DirectedSchurResponse:
    """Aggregate all outside couplings into one explicit boundary environment port.

    This is an accounting derived_quantity.  It prevents the outside load from being
    silently read as ground, but it is still an aggregated finite proxy rather
    than an infinite environment construction.
    """
    B = list(dict.fromkeys(boundary))
    I = list(dict.fromkeys(interior))
    selected = B + I
    selected_set = set(selected)
    env_index = len(selected)
    Kbase = directed_local_matrix(
        model,
        state,
        selected,
        include_external_degrees=False,
        matrix_sign_relation=matrix_sign_relation,
    )
    K = np.zeros((len(selected) + 1, len(selected) + 1), dtype=float)
    K[: len(selected), : len(selected)] = Kbase
    pos = {nid: k for k, nid in enumerate(selected)}
    edges = state_directed_edges(model, state)
    for (i, j), w0 in edges.items():
        if i == j:
            continue
        w = float(w0)
        if abs(w) <= 0.0:
            continue
        if matrix_sign_relation == "out_degree":
            row, col = i, j
        else:
            row, col = j, i
        row_in = row in selected_set
        col_in = col in selected_set
        if row_in and not col_in:
            r = pos[row]
            K[r, r] += w
            K[r, env_index] -= w
        elif (not row_in) and col_in:
            # Aggregate all external source nodes into the environment row.
            c = pos[col]
            K[env_index, env_index] += w
            K[env_index, c] -= w
    bidx = list(range(len(B))) + [env_index]
    iidx = list(range(len(B), len(B) + len(I)))
    return directed_schur_response(
        K,
        bidx,
        iidx,
        cond_max=cond_max,
        matrix_sign_relation=matrix_sign_relation,
        boundary_response_model="explicit_environment_port_directed",
    )




def _descendants_at_level(model: EmptySetGrowthModel, root: int, level: int) -> List[int]:
    base = tuple(model.nodes[root].address)
    return [
        n.nid for n in model.nodes
        if n.level == level and len(n.address) >= len(base) and tuple(n.address[:len(base)]) == base
    ]


def build_coarse_frontier_sibling_regions(
    model: EmptySetGrowthModel,
    *,
    max_regions: int = 4,
    max_boundary: int = 600,
    max_interior: int = 900,
    max_frontier_level: Optional[int] = 6,
) -> List[RegionSpec]:
    """Sibling-cone regions with a deterministic coarse frontier.

    The original sibling region puts every terminal descendant of the two
    sibling cones on the boundary.  For b=4,L>=7 this exceeds the default
    directed-DtN size condition_notes and produces ``directed_region_missing`` even
    though the CNNA F1/F2 question is still finite and well-defined.

    This constructor keeps the same boundary role columns

        C_lca + B1_front + B2_front,

    but chooses the deepest common frontier level whose boundary and interior
    sizes fit the requested condition_notes.  Nodes below that frontier are not silently
    Schur-eliminated; in the open-grounded response they appear as external
    directed load on the frontier, and in the environment-port derived_quantity they
    are accounted for by an explicit aggregate outside port.

    With the default ``max_frontier_level=6``, full terminal regions are
    returned through L=6.  For L>6 the cut is deliberately multiscale: the
    deepest admissible frontier is capped at level 6 unless the caller raises
    the cap.  This keeps L=7/8 coverage lightweight and prevents large-L
    consistency_check from silently becoming a terminal-boundary performance test.
    """
    specs: List[RegionSpec] = []
    lca_finite_objects = [n.nid for n in model.nodes if n.level == 1 and len(n.children) >= 2]
    if not lca_finite_objects and model.nodes[0].children:
        lca_finite_objects = [0]
    max_regions = max(1, int(max_regions))
    max_boundary = max(3, int(max_boundary))
    max_interior = max(0, int(max_interior))
    for lca in lca_finite_objects:
        children = list(model.nodes[lca].children)
        if len(children) < 2:
            continue
        for idx in range(min(len(children) - 1, max_regions)):
            left = children[idx]
            right = children[idx + 1]
            min_frontier = max(model.nodes[left].level, model.nodes[right].level)
            chosen = None
            # Prefer the deepest admissible frontier.  This is the terminal
            # frontier when it fits and a coarse prefix frontier otherwise.
            frontier_cap = int(model.L if max_frontier_level is None else min(model.L, max_frontier_level))
            frontier_cap = max(frontier_cap, min_frontier)
            for frontier_level in range(frontier_cap, min_frontier - 1, -1):
                left_front = _descendants_at_level(model, left, frontier_level)
                right_front = _descendants_at_level(model, right, frontier_level)
                if not left_front or not right_front:
                    continue
                boundary = [lca] + left_front + right_front
                if len(boundary) > max_boundary:
                    continue
                left_addr = tuple(model.nodes[left].address)
                right_addr = tuple(model.nodes[right].address)
                cone_nodes = [
                    n.nid for n in model.nodes
                    if (
                        (len(n.address) >= len(left_addr) and tuple(n.address[:len(left_addr)]) == left_addr)
                        or (len(n.address) >= len(right_addr) and tuple(n.address[:len(right_addr)]) == right_addr)
                    )
                ]
                boundary_set = set(boundary)
                # Interior is the finite region between the sibling roots and
                # the selected frontier.  Deeper UV nodes are outside this
                # coarse cut and are accounted as external load/port depending
                # on the response relations.
                interior = sorted([
                    nid for nid in cone_nodes
                    if nid not in boundary_set and model.nodes[nid].level < frontier_level
                ])
                if len(interior) > max_interior:
                    continue
                chosen = (frontier_level, boundary, interior)
                break
            if chosen is None:
                continue
            frontier_level, boundary, interior = chosen
            full_terminal = int(frontier_level == model.L)
            suffix = "terminal" if full_terminal else f"coarse_frontierL{frontier_level}_terminalL{model.L}"
            roles = {
                "C_lca": [lca],
                "B1_front": list(boundary[1:1 + (len(boundary) - 1)//2]),
                "B2_front": list(boundary[1 + (len(boundary) - 1)//2:]),
                "F1_root_front": list(boundary),
                "F2_birth_order": list(boundary[1:]),
            }
            specs.append(RegionSpec(
                region_id=f"sibling_cone_pair_{suffix}_lca{lca}_sib{idx}_{idx+1}",
                pair_type="sibling_cone_pair" if full_terminal else "coarse_frontier_sibling_cone_pair",
                lca=lca,
                left_root=left,
                right_root=right,
                level=model.nodes[lca].level,
                boundary=list(boundary),
                interior=list(interior),
                roles=roles,
            ))
            if len(specs) >= max_regions:
                return specs
    return specs


def region_frontier_level(model: EmptySetGrowthModel, spec: RegionSpec) -> int:
    levels = [model.nodes[nid].level for nid in spec.boundary if nid != spec.lca]
    return max(levels) if levels else int(model.nodes[spec.lca].level)


def region_is_coarse_frontier(model: EmptySetGrowthModel, spec: RegionSpec) -> bool:
    return int(region_frontier_level(model, spec)) < int(model.L)

def signed_role_basis_F1F2(boundary: Sequence[int], region: RegionSpec) -> Tuple[np.ndarray, List[str], int]:
    """Build the signed two-axis regional basis directly on F1/F2.

    This intentionally does *not* append F1/F2 after C/B1/B2.  In the old role
    basis F1 was linearly dependent on C,B1,B2 and therefore disappeared under
    Gram-Schmidt.  The current basis asks the CNNA question directly: is the
    root/front axis and the sibling birth-order axis a nondegenerate signed
    regional plane?
    """
    pos = {nid: i for i, nid in enumerate(boundary)}

    def indicator(ids: Sequence[int]) -> np.ndarray:
        v = np.zeros(len(boundary), dtype=float)
        for nid in ids:
            if nid in pos:
                v[pos[nid]] = 1.0
        n = float(np.linalg.norm(v))
        return v / max(n, EPS)

    C = indicator(region.roles.get("C_lca", []))
    Lf = indicator(region.roles.get("B1_front", []))
    Rf = indicator(region.roles.get("B2_front", []))
    F1 = C - 0.5 * (Lf + Rf)
    F2 = Lf - Rf
    raw = [F1, F2]
    names_raw = ["F1_root_front_contrast", "F2_birth_order_contrast"]
    basis: List[np.ndarray] = []
    names: List[str] = []
    for name, v in zip(names_raw, raw):
        u = v.copy()
        for q in basis:
            u -= float(q @ u) * q
        n = float(np.linalg.norm(u))
        if n > 1.0e-10:
            basis.append(u / n)
            names.append(name)
    if not basis:
        basis.append(np.ones(len(boundary), dtype=float) / math.sqrt(max(1, len(boundary))))
        names.append("constant_fallback")
    return np.column_stack(basis), names, len(basis)


def split_symmetric_skew(Lambda: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    S = 0.5 * (Lambda + Lambda.T)
    A = 0.5 * (Lambda - Lambda.T)
    return S, A


def j_finite_object_from_SA(S: np.ndarray, A: np.ndarray, tol: float = 1.0e-10) -> Tuple[Optional[np.ndarray], dict]:
    """Finite J-finite_object comparison on the positive support of S.

    J_raw = S^{-1/2} A S^{-1/2}.  Since J_raw is skew-symmetric, its polar
    orthogonal factor is extracted by SVD.  We test J^2≈-P on the even-rank
    nondegenerate skew support.  This is only a finite derived_quantity, not a property.
    """
    if S.size == 0 or A.size == 0:
        return None, {"available": 0, "reason": "empty_matrix"}
    try:
        vals, U = np.linalg.eigh(0.5 * (S + S.T))
    except np.linalg.LinAlgError:
        return None, {"available": 0, "reason": "S_eigh_failed"}
    maxeig = float(np.max(vals)) if vals.size else 0.0
    support = vals > max(tol, tol * max(1.0, maxeig))
    rankS = int(np.sum(support))
    if rankS < 2:
        return None, {"available": 0, "reason": "positive_support_rank_lt_2", "S_support_rank": rankS}
    Us = U[:, support]
    invsqrt = np.diag(1.0 / np.sqrt(vals[support]))
    Jraw = invsqrt @ (Us.T @ A @ Us) @ invsqrt
    skew_err = fro(Jraw + Jraw.T) / max(fro(Jraw), EPS)
    try:
        W, sing, Vt = np.linalg.svd(Jraw)
    except np.linalg.LinAlgError:
        return None, {"available": 0, "reason": "Jraw_svd_failed", "S_support_rank": rankS, "Jraw_skew_error": skew_err}
    thresh = max(tol, tol * max(1.0, float(np.max(sing)) if sing.size else 0.0))
    mask = sing > thresh
    skew_rank = int(np.sum(mask))
    if skew_rank < 2:
        return None, {"available": 0, "reason": "skew_support_rank_lt_2", "S_support_rank": rankS, "skew_rank": skew_rank, "Jraw_skew_error": skew_err}
    # A real skew matrix has even rank up to numerical tolerance.  Restrict to
    # the nonzero singular subspace using the rectangular polar block.
    Wk = W[:, mask]
    Vk = Vt.T[:, mask]
    Jpolar = Wk @ Vk.T
    P = Wk @ Wk.T
    J2_err = fro(Jpolar @ Jpolar + P) / max(fro(P), EPS)
    return Jpolar, {
        "available": 1,
        "reason": "finite_J_finite_object_polar_comparison_available",
        "S_support_rank": rankS,
        "skew_rank": skew_rank,
        "skew_rank_even": int(skew_rank % 2 == 0),
        "Jraw_skew_error": skew_err,
        "J_square_minus_negative_projector_error": J2_err,
        "skew_singular_values": " ".join(f"{x:.12g}" for x in sing),
    }
