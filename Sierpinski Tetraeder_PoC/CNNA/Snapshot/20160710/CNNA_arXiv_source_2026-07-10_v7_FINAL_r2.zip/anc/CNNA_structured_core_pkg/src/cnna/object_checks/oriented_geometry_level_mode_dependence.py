from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _median(xs: Iterable[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("region_id"),
        row.get("genealogical_corridor_length"),
    )


def _ratio(x: float, scale: float) -> float:
    return float(x / max(scale, 1.0e-300)) if math.isfinite(x) and math.isfinite(scale) and scale > 0.0 else math.nan


def oriented_geometry_level_mode_dependence_rows(
    level_mode_rows: List[dict],
    oriented_geometry_rows: List[dict],
    *,
    tol: float = 1.0e-10,
) -> List[dict]:
    """Push level-/mode-shift controls through the 12 geometry ratio conditions.

    This is stricter than the fixed-measure best-available controls: each time-shifted or
    mode-mismatched record is compared with the true record using the same
    additive scale, and the same locality/split/complement rank_bound is divided
    by both scales.
    """
    controls: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in level_mode_rows:
        if r.get("parameter_dependence_control_family") in ("time_shifted_record", "mode_mismatched_record"):
            controls[_key(r)].append(r)
    rows: List[dict] = []
    threshold = 10.0
    for g in oriented_geometry_rows:
        raw = _finite(g.get("geometry_raw_rank_bound"))
        for c in controls.get(_key(g), []):
            true_scale = _finite(c.get("true_measure_additive_fixed_formula"))
            control_scale = _finite(c.get("control_measure_additive_same_formula"))
            tr = _ratio(raw, true_scale)
            cr = _ratio(raw, control_scale)
            true_contains = int(math.isfinite(tr) and tr < threshold)
            control_contains = int(math.isfinite(cr) and cr < threshold)
            true_tighter = int(math.isfinite(true_scale) and math.isfinite(control_scale) and true_scale < control_scale - max(1.0e-8, 100.0 * tol))
            if true_tighter and true_contains:
                computed_status = "true_level_mode_specific_measure_contains_geometry_finite_object"
            elif control_contains and not true_tighter:
                computed_status = "level_mode_control_measure_as_good_or_tighter_for_geometry_observed"
            elif not true_contains:
                computed_status = "true_level_mode_measure_does_not_contain_geometry_observed"
            else:
                computed_status = "level_mode_geometry_parameter_dependence_unresolved_control"
            rows.append({
                "geometry_surface": g.get("geometry_surface"),
                "branching": g.get("branching"),
                "level": g.get("level"),
                "mode": g.get("mode"),
                "region_id": g.get("region_id"),
                "region_family": g.get("region_family"),
                "genealogical_corridor_length": g.get("genealogical_corridor_length"),
                "geometry_layer": g.get("geometry_layer"),
                "parameter_dependence_control_family": c.get("parameter_dependence_control_family"),
                "control_level": c.get("control_level"),
                "control_delta_level": c.get("control_delta_level"),
                "control_mode": c.get("control_mode"),
                "geometry_raw_rank_bound": raw,
                "true_measure_additive_fixed_formula": true_scale,
                "control_measure_additive_same_formula": control_scale,
                "geometry_ratio_true_additive_measure": tr,
                "geometry_ratio_control_additive_measure": cr,
                "true_measure_tighter_than_level_mode_control": true_tighter,
                "true_measure_contains_geometry_ratio_lt_10": true_contains,
                "control_measure_contains_geometry_ratio_lt_10": control_contains,
                "additive_margin_control_minus_true": _finite(c.get("additive_margin_control_minus_true")),
                "density_margin_control_minus_true": _finite(c.get("density_margin_control_minus_true")),
                "F1F2_profile_margin_control_minus_true": _finite(c.get("F1F2_profile_margin_control_minus_true")),
                "source_level_mode_parameter_dependence_computed_status": c.get("history_measure_level_mode_dependence_computed_status"),
                "oriented_geometry_level_mode_dependence_computed_status": computed_status,
            })
    return rows


def oriented_geometry_level_mode_dependence_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("oriented_geometry_level_mode_dependence_computed_status", "unknown")) for r in rows})
    cand = sum(1 for r in rows if str(r.get("oriented_geometry_level_mode_dependence_computed_status", "")) == "true_level_mode_specific_measure_contains_geometry_finite_object")
    obs = sum(1 for r in rows if str(r.get("oriented_geometry_level_mode_dependence_computed_status", "")) == "level_mode_control_measure_as_good_or_tighter_for_geometry_observed")
    return (
        "# Level/mode oriented-geometry parameter_dependence measurement\n\n"
        "This surface sends time-shifted and mode-mismatched controls through the same locality/split/complement ratio conditions as the true fixed two-component measure, using the same additive formula for true and control records.\n\n"
        f"True level/mode specific finite_objects: {cand}/{len(rows)}.\n\n"
        f"Level/mode controls as good or tighter: {obs}/{len(rows)}.\n\n"
        "Computed statuss: `" + "`, `".join(computed_status_rows) + "`.\n"
    )
