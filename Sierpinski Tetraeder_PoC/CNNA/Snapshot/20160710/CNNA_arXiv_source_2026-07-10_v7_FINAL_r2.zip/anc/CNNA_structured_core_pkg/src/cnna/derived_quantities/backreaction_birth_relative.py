from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

from cnna.config import REFERENCE_MODE


def _to_int(x, default: int = 0) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def _to_float(x, default: float = math.nan) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def _sign(x: float, tol: float = 1.0e-12) -> int:
    if not math.isfinite(x) or abs(x) <= tol:
        return 0
    return 1 if x > 0.0 else -1


def _region_birth_level(row: dict) -> int:
    """Birth level of the sibling-pair carrier used by the region.

    For the current directed sibling-cone region constructor, the two physical
    roots are the sibling children of the LCA.  Their common birth level is one
    level after the LCA.  If future region constructors write an explicit
    `birth_level`, prefer it.
    """
    if "birth_level" in row:
        return _to_int(row.get("birth_level"), default=0)
    # Backward-compatible fallback for rows produced before explicit region
    # birth levels were written.  Current package rows always carry
    # ``birth_level`` from the sibling-root nodes.
    return _to_int(row.get("region_birth_level", 2), default=2)


def birth_relative_backreaction_rows(backreaction_rows: Sequence[dict]) -> List[dict]:
    """Annotate 4 rows by birth-relative age.

    Reference physical path is live-record.  `sym` is not used.  Full-terminal
    rows are eligible for law fitting; coarse-frontier rows are coverage only.
    """
    rows: List[dict] = []
    for r in backreaction_rows:
        if _to_int(r.get("available"), 0) != 1:
            continue
        birth = _region_birth_level(r)
        frontier = _to_int(r.get("frontier_level"), _to_int(r.get("level"), 0))
        observed_L = _to_int(r.get("level"), 0)
        age_frontier = frontier - birth
        age_observed = observed_L - birth
        coarse = _to_int(r.get("coarse_frontier_used"), 0)
        delta = _to_float(r.get("live_minus_record_skew_norm"))
        Bnorm = _to_float(r.get("B_skew_part_norm"))
        row_rel = _to_float(r.get("row_sum_relative_delta"))
        omega = _to_float(r.get("B_F1F2_signed_omega"))
        rows.append({
            "branching": _to_int(r.get("branching")),
            "mode": r.get("mode", ""),
            "region_index": _to_int(r.get("region_index"), -1),
            "region_id": r.get("region_id", ""),
            "region_pair_type": r.get("region_pair_type", ""),
            "reference_model": _to_int(r.get("reference_model"), 0),
            "level": observed_L,
            "frontier_level": frontier,
            "terminal_level": _to_int(r.get("terminal_level"), observed_L),
            "coarse_frontier_used": coarse,
            "birth_level": birth,
            "birth_level_source": r.get("birth_level_source", "legacy_sibling_root_default"),
            "age_observed_level_minus_birth": age_observed,
            "age_frontier_minus_birth": age_frontier,
            "law_fit_eligible": int(coarse == 0),
            "B_skew_part_norm": Bnorm,
            "live_minus_record_skew_norm": delta,
            "live_minus_record_sign": _sign(delta),
            "B_F1F2_signed_omega": omega,
            "B_omega_sign": _sign(omega),
            "row_sum_relative_delta": row_rel,
            "row_sum_condition_note_ok": _to_int(r.get("row_sum_condition_note_ok"), 0),
            "omega_vs_full_skew_condition_note": r.get("omega_vs_full_skew_condition_note", ""),
            "computed_status": "birth_relative_relative_backreaction_row",
            "condition_note": "birth_level_is_explicit_region_sibling_root_level_for_current_rows; age_frontier_minus_birth_is_used_for_law; coarse_frontier_rows_are_coverage_only; sym_is_control_not_physical_path",
        })
    return rows


def _linear_zero_crossing_age(points: List[Tuple[int, float]]) -> float:
    """First linearly interpolated sign crossing age if present."""
    if len(points) < 2:
        return math.nan
    pts = sorted(points)
    for (a0, v0), (a1, v1) in zip(pts[:-1], pts[1:]):
        s0, s1 = _sign(v0), _sign(v1)
        if s0 == 0:
            return float(a0)
        if s1 == 0:
            return float(a1)
        if s0 != s1 and math.isfinite(v0) and math.isfinite(v1) and abs(v1 - v0) > 0.0:
            return float(a0) - float(v0) * float(a1 - a0) / float(v1 - v0)
    return math.nan


def birth_relative_zero_crossing_rows(birth_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({
        (_to_int(r.get("branching")), str(r.get("mode", "")), _to_int(r.get("region_index"), -1))
        for r in birth_rows
    })
    for b, mode, ridx in keys:
        group = [r for r in birth_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode and _to_int(r.get("region_index"), -99) == ridx]
        terminal = sorted([r for r in group if _to_int(r.get("law_fit_eligible"), 0) == 1], key=lambda x: _to_int(x.get("age_frontier_minus_birth")))
        coarse = sorted([r for r in group if _to_int(r.get("law_fit_eligible"), 0) != 1], key=lambda x: _to_int(x.get("level")))
        pts = [(_to_int(r.get("age_frontier_minus_birth")), _to_float(r.get("live_minus_record_skew_norm"))) for r in terminal]
        signs = [_sign(v) for _, v in pts]
        sign_flip = int(any(signs[i] != 0 and signs[j] != 0 and signs[i] != signs[j] for i in range(len(signs)) for j in range(i + 1, len(signs))))
        first_nonnegative_age = math.nan
        for age, val in pts:
            if math.isfinite(val) and val >= 0.0:
                first_nonnegative_age = float(age)
                break
        nearest_zero_age = math.nan
        nearest_zero_abs = math.nan
        if pts:
            age, val = min(pts, key=lambda av: abs(av[1]) if math.isfinite(av[1]) else float("inf"))
            nearest_zero_age = float(age)
            nearest_zero_abs = abs(float(val))
        lin_age = _linear_zero_crossing_age(pts)
        monotone_nondec = int(len(pts) >= 2 and all(pts[i+1][1] >= pts[i][1] - 1e-12 for i in range(len(pts)-1)))
        latest_positive = int(bool(pts) and pts[-1][1] > 0.0)
        unmet_conditions: List[str] = []
        if len(pts) < 3:
            unmet_conditions.append("fewer_than_three_full_terminal_age_points")
        if not sign_flip:
            unmet_conditions.append("no_birth_relative_sign_flip")
        if not latest_positive:
            unmet_conditions.append("latest_full_terminal_age_not_live_dominant")
        if not monotone_nondec:
            unmet_conditions.append("B_delta_not_monotone_non_decreasing_in_terminal_age_window")
        computed_status = "birth_relative_relative_zero_crossing_finite_object" if not unmet_conditions else "birth_relative_relative_zero_crossing_residual_gt_tolerance"
        rows.append({
            "branching": b,
            "mode": mode,
            "region_index": ridx,
            "reference_model": int(mode == REFERENCE_MODE and ridx == 0),
            "region_id": terminal[0].get("region_id", group[0].get("region_id", "")) if group else "",
            "terminal_ages": " ".join(str(a) for a, _ in pts) if pts else "none",
            "terminal_live_minus_record_values": " ".join(f"{v:.12g}" for _, v in pts) if pts else "none",
            "coarse_frontier_levels": " ".join(str(_to_int(r.get("level"))) for r in coarse) if coarse else "none",
            "n_terminal_age_points": len(pts),
            "birth_relative_sign_flip_seen": sign_flip,
            "first_nonnegative_age": first_nonnegative_age,
            "nearest_zero_age": nearest_zero_age,
            "nearest_zero_abs_live_minus_record": nearest_zero_abs,
            "linear_interpolated_zero_crossing_age": lin_age,
            "terminal_delta_monotone_non_decreasing": monotone_nondec,
            "latest_terminal_live_dominant": latest_positive,
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "zero crossing fitted only on full-terminal rows by age_frontier_minus_birth; coarse rows excluded",
        })
    return rows


def birth_relative_mode_branching_rows(zero_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(_to_int(r.get("branching")), str(r.get("mode", ""))) for r in zero_rows})
    for b, mode in keys:
        group = [r for r in zero_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode]
        finite_object = [r for r in group if "finite_object" in str(r.get("computed_status", ""))]
        ages = [_to_float(r.get("first_nonnegative_age")) for r in finite_object if math.isfinite(_to_float(r.get("first_nonnegative_age")))]
        nearest = [_to_float(r.get("nearest_zero_age")) for r in finite_object if math.isfinite(_to_float(r.get("nearest_zero_age")))]
        lin = [_to_float(r.get("linear_interpolated_zero_crossing_age")) for r in finite_object if math.isfinite(_to_float(r.get("linear_interpolated_zero_crossing_age")))]
        if not group:
            computed_status = "birth_relative_mode_branching_no_rows"
        elif len(finite_object) == len(group):
            computed_status = "birth_relative_mode_branching_region_finite_objects_residual_le_tolerance"
        elif finite_object:
            computed_status = "birth_relative_mode_branching_partial_region_finite_objects"
        else:
            computed_status = "birth_relative_mode_branching_residual_gt_tolerance"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "region_count": len(group),
            "finite_object_region_count": len(finite_object),
            "first_nonnegative_age_min": min(ages) if ages else math.nan,
            "first_nonnegative_age_median": float(np.median(ages)) if ages else math.nan,
            "first_nonnegative_age_max": max(ages) if ages else math.nan,
            "nearest_zero_age_median": float(np.median(nearest)) if nearest else math.nan,
            "linear_zero_crossing_age_median": float(np.median(lin)) if lin else math.nan,
            "computed_status": computed_status,
            "condition_note": "mode_branching_comparison_is_only_as_broad_as_requested_branching_and_modes",
        })
    return rows


def birth_relative_region_family_rows(birth_rows: Sequence[dict], zero_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({
        (_to_int(r.get("branching")), str(r.get("mode", "")), str(r.get("region_pair_type", "")))
        for r in birth_rows
    })
    for b, mode, pair_type in keys:
        region_indices = sorted({_to_int(r.get("region_index"), -1) for r in birth_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode and str(r.get("region_pair_type", "")) == pair_type})
        zgroup = [z for z in zero_rows if _to_int(z.get("branching")) == b and str(z.get("mode", "")) == mode and _to_int(z.get("region_index"), -99) in region_indices]
        finite_object = [z for z in zgroup if "finite_object" in str(z.get("computed_status", ""))]
        first_ages = [_to_float(z.get("first_nonnegative_age")) for z in finite_object if math.isfinite(_to_float(z.get("first_nonnegative_age")))]
        computed_status = "birth_relative_region_family_finite_objects_residual_le_tolerance" if zgroup and len(finite_object) == len(zgroup) else ("birth_relative_region_family_partial" if finite_object else "birth_relative_region_family_residual_gt_tolerance")
        rows.append({
            "branching": b,
            "mode": mode,
            "region_pair_type": pair_type,
            "reference_model": int(mode == REFERENCE_MODE and pair_type.startswith("sibling")),
            "region_count": len(region_indices),
            "finite_object_region_count": len(finite_object),
            "first_nonnegative_age_values": " ".join(f"{x:.12g}" for x in first_ages) if first_ages else "none",
            "first_nonnegative_age_spread": (max(first_ages) - min(first_ages)) if len(first_ages) >= 2 else 0.0,
            "computed_status": computed_status,
            "condition_note": "current implementation primarily supplies sibling_cone_pair; other region families require future constructors",
        })
    return rows


def birth_relative_summary_rows(
    birth_rows: Sequence[dict],
    zero_rows: Sequence[dict],
    mode_branching_rows: Sequence[dict],
    region_family_rows: Sequence[dict],
) -> List[dict]:
    rows: List[dict] = []
    keys = sorted({(_to_int(r.get("branching")), str(r.get("mode", ""))) for r in birth_rows})
    for b, mode in keys:
        zgroup = [r for r in zero_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode]
        reference_zero = next((r for r in zgroup if _to_int(r.get("reference_model"), 0) == 1), zgroup[0] if zgroup else {})
        mb = next((r for r in mode_branching_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode), {})
        rf = [r for r in region_family_rows if _to_int(r.get("branching")) == b and str(r.get("mode", "")) == mode]
        unmet_conditions: List[str] = []
        if not zgroup:
            unmet_conditions.append("no_zero_crossing_rows")
        if reference_zero and "finite_object" not in str(reference_zero.get("computed_status", "")):
            unmet_conditions.append("reference_zero_crossing_not_residual_le_tolerance")
        if mb and "residual_gt_tolerance" in str(mb.get("computed_status", "")):
            unmet_conditions.append("mode_branching_not_residual_le_tolerance")
        if not rf:
            unmet_conditions.append("no_region_family_rows")
        if not unmet_conditions:
            computed_status = "birth_relative_relative_backreaction_law_finite_object"
        else:
            computed_status = "birth_relative_relative_backreaction_law_residual_gt_tolerance"
        rows.append({
            "branching": b,
            "mode": mode,
            "reference_model": int(mode == REFERENCE_MODE),
            "birth_relative_rows_available": int(bool(birth_rows)),
            "reference_first_nonnegative_age": reference_zero.get("first_nonnegative_age", math.nan) if reference_zero else math.nan,
            "reference_nearest_zero_age": reference_zero.get("nearest_zero_age", math.nan) if reference_zero else math.nan,
            "reference_linear_zero_crossing_age": reference_zero.get("linear_interpolated_zero_crossing_age", math.nan) if reference_zero else math.nan,
            "reference_terminal_ages": reference_zero.get("terminal_ages", "missing") if reference_zero else "missing",
            "reference_terminal_values": reference_zero.get("terminal_live_minus_record_values", "missing") if reference_zero else "missing",
            "finite_object_region_count": mb.get("finite_object_region_count", 0),
            "region_count": mb.get("region_count", 0),
            "unmet_conditions": ";".join(unmet_conditions) if unmet_conditions else "none",
            "computed_status": computed_status,
            "condition_note": "the birth-relative current law is a finite_object; not an asymptotic property; sym remains control only",
        })
    return rows


def write_birth_relative_backreaction_current_report(
    outdir: Path,
    birth_rows: Sequence[dict],
    zero_rows: Sequence[dict],
    mode_branching_rows: Sequence[dict],
    region_family_rows: Sequence[dict],
    summary_rows: Sequence[dict],
) -> None:
    reference = next((r for r in summary_rows if _to_int(r.get("reference_model"), 0) == 1), summary_rows[0] if summary_rows else {})
    # Report all sibling regions for the reference branching/mode.  The birth-relative
    # statement is a region-parameter_stable sign-flip finite_object, not a single-region fact.
    reference_branching = _to_int(reference.get("branching"), 0)
    reference_mode = str(reference.get("mode", REFERENCE_MODE))
    reference_zero_rows = [
        r for r in zero_rows
        if _to_int(r.get("branching"), 0) == reference_branching and str(r.get("mode", "")) == reference_mode
    ]
    lines = [
        "# Birth-relative backreaction current law measurement",
        "",
        "## Purpose",
        "",
        "The birth-relative current law re-reads the backreaction current by region age rather than by absolute level.",
        "",
        "```text",
        "B_L = A_live,L - A_record,L",
        "age = frontier_level - birth_level(region)",
        "```",
        "",
        "`sym` is only the symmetric-tree control path; the physical comparison remains live versus record.",
        "",
        "## Reference summary",
        "",
        "```text",
        f"computed_status = {reference.get('computed_status', 'missing')}",
        f"unmet_conditions = {reference.get('unmet_conditions', 'missing')}",
        f"reference_terminal_ages = {reference.get('reference_terminal_ages', 'missing')}",
        f"reference_terminal_values = {reference.get('reference_terminal_values', 'missing')}",
        f"first_nonnegative_age = {reference.get('reference_first_nonnegative_age', 'missing')}",
        f"nearest_zero_age = {reference.get('reference_nearest_zero_age', 'missing')}",
        f"linear_zero_crossing_age = {reference.get('reference_linear_zero_crossing_age', 'missing')}",
        "```",
        "",
        "## Zero-crossing rows",
        "",
        "```text",
    ]
    for z in sorted(reference_zero_rows, key=lambda r: (_to_int(r.get("branching")), str(r.get("mode")), _to_int(r.get("region_index")))):
        lines.append(
            f"b={z.get('branching')} mode={z.get('mode')} region={z.get('region_index')} "
            f"ages={z.get('terminal_ages')} values={z.get('terminal_live_minus_record_values')} "
            f"first_nonnegative_age={z.get('first_nonnegative_age')} "
            f"nearest_zero_age={z.get('nearest_zero_age')} "
            f"linear_zero_age={z.get('linear_interpolated_zero_crossing_age')} "
            f"computed_status={z.get('computed_status')} unmet_conditions={z.get('unmet_conditions')}"
        )
    lines.extend([
        "```",
        "",
        "## Interpretation fixed from 4",
        "",
        "For the b=4, linear, sibling-cone test window reported in 4, the physical pattern is a finite current-law finite_object:",
        "record-dominated skew early, a near-zero live-record crossing around the next age window, and live-dominated skew later.",
        "The birth-relative law does not count coarse-frontier L=7/L=8 rows as new terminal convergence points; they are coverage rows only.",
        "",
        "## Conditions",
        "",
        "- Only full-terminal rows are eligible for the zero-crossing law fit.",
        "- Coarse-frontier rows are large-L coverage, not asymptotic evidence.",
        "- The reported age is tied to the sibling-root birth level; future non-sibling region constructors must write explicit birth levels.",
        "- This is not a vN/KMS/Type-III/GNS-limit statement.",
    ])
    (outdir / "4B_BIRTH_RELATIVE_BACKREACTION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
