from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    local_operator_algebras,
    state_commutator_metric,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


DECAY_PAIRS = [
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "symmetric_carrier_birth_cones"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "directed_current_birth_cones"),
    ("left_birth_cone_response", "right_birth_cone_response", "mixed_response_birth_cones"),
]


def _finite(x: object) -> float:
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if math.isfinite(y) else math.nan


def _track_key(row: dict) -> Tuple[object, ...]:
    return (
        row.get("branching"),
        row.get("level"),
        row.get("mode"),
        row.get("state"),
        row.get("operator_layer_pair"),
    )


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c: Dict[int, List[float]] = defaultdict(list)
    by_c_state: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        rel = _finite(r.get("max_relative_commutator"))
        st = _finite(r.get("max_state_commutator_abs_no_epsilon"))
        if c >= 0 and math.isfinite(rel):
            by_c[c].append(rel)
        if c >= 0 and math.isfinite(st):
            by_c_state[c].append(st)
    corridors = sorted(by_c)
    if not corridors:
        return {
            "commutator_decay_corridor_count": 0,
            "commutator_decay_min_corridor": -1,
            "commutator_decay_max_corridor": -1,
            "commutator_decay_first_median_rel": math.nan,
            "commutator_decay_last_median_rel": math.nan,
            "commutator_decay_ratio_last_over_first": math.nan,
            "commutator_decay_log_slope_proxy": math.nan,
            "commutator_decay_monotone_nonincreasing": 0,
            "commutator_decay_track_computed_status": "commutator_decay_no_track_available",
        }
    med = {c: float(sorted(v)[len(v) // 2]) for c, v in by_c.items() if v}
    med_state = {c: float(sorted(v)[len(v) // 2]) for c, v in by_c_state.items() if v}
    ordered = [med[c] for c in corridors if c in med]
    first = ordered[0] if ordered else math.nan
    last = ordered[-1] if ordered else math.nan
    ratio = float(last / max(first, 1.0e-300)) if math.isfinite(first) and math.isfinite(last) and first > 0 else math.nan
    if len(corridors) >= 2 and math.isfinite(first) and math.isfinite(last) and first > 0 and last > 0:
        slope = float((math.log(last) - math.log(first)) / max(1, corridors[-1] - corridors[0]))
    else:
        slope = math.nan
    mono = int(len(ordered) >= 2 and all(ordered[i + 1] <= ordered[i] + max(tol, tol * max(1.0, ordered[i])) for i in range(len(ordered) - 1)))
    zero_all = int(ordered and max(ordered) <= tol)
    if len(corridors) < 2:
        computed_status = "commutator_decay_insufficient_corridor_trajectory"
    elif zero_all:
        computed_status = "commutator_decay_zero_structural_control"
    elif mono and math.isfinite(ratio) and ratio < 1.0:
        computed_status = "commutator_decay_finite_object_over_genealogical_distance"
    elif math.isfinite(ratio) and ratio > 1.0 + 1.0e-8:
        computed_status = "commutator_growth_observed_over_genealogical_distance"
    else:
        computed_status = "commutator_no_monotone_decay_observed"
    state_first = med_state.get(corridors[0], math.nan)
    state_last = med_state.get(corridors[-1], math.nan)
    return {
        "commutator_decay_corridor_count": int(len(corridors)),
        "commutator_decay_min_corridor": int(corridors[0]),
        "commutator_decay_max_corridor": int(corridors[-1]),
        "commutator_decay_first_median_rel": float(first),
        "commutator_decay_last_median_rel": float(last),
        "commutator_decay_ratio_last_over_first": float(ratio) if math.isfinite(ratio) else math.nan,
        "commutator_decay_log_slope_proxy": float(slope) if math.isfinite(slope) else math.nan,
        "commutator_decay_first_median_state_abs": float(state_first) if math.isfinite(state_first) else math.nan,
        "commutator_decay_last_median_state_abs": float(state_last) if math.isfinite(state_last) else math.nan,
        "commutator_decay_monotone_nonincreasing": mono,
        "commutator_decay_track_computed_status": computed_status,
    }


def commutator_decay_by_genealogical_distance_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    for left_name, right_name, pair_label in DECAY_PAIRS:
                        rows.append({
                            "branching": b,
                            "level": L,
                            "mode": mode,
                            **meta,
                            "state": state,
                            "left_operator_system": left_name,
                            "right_operator_system": right_name,
                            "operator_layer_pair": pair_label,
                            "commutator_decay_row_computed_status": "response_unavailable",
                        })
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                for left_name, right_name, pair_label in DECAY_PAIRS:
                    left = algebras[left_name]
                    right = algebras[right_name]
                    metrics = commutator_metrics(left, right)
                    state_abs = state_commutator_metric(left, right, resp.density)
                    corridor = int(meta["genealogical_corridor_length"])
                    if corridor == 0 and int(meta["direct_sibling_birth_coupling"]):
                        row_computed_status = "touching_sibling_reference_row"
                    elif corridor >= 2:
                        row_computed_status = "collared_genealogical_distance_row"
                    else:
                        row_computed_status = "uncollared_distance_row"
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "operator_layer_pair": pair_label,
                        "left_dim": len(left.basis),
                        "right_dim": len(right.basis),
                        **metrics,
                        "max_state_commutator_abs_no_epsilon": float(state_abs),
                        "commutator_decay_row_computed_status": row_computed_status,
                    })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        if "max_relative_commutator" in row:
            tracks[_track_key(row)].append(row)
    summaries = {key: _summarize_track(vals, config.algebra_tol) for key, vals in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def commutator_decay_by_genealogical_distance_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("commutator_decay_track_computed_status", "unknown")) for r in rows if "commutator_decay_track_computed_status" in r})
    row_computed_status_rows = sorted({str(r.get("commutator_decay_row_computed_status", "unknown")) for r in rows})
    return (
        "# Commutator decay by genealogical distance\n\n"
        "This finite scaling surface tracks commutator norms against genealogical corridor length.  "
        "Touching sibling cones are retained only as reference rows; the finite locality question is whether the collared rows show systematic decay.  "
        "No Haag-Kastler locality property is stated.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Row computed_status_rows: `" + "`, `".join(row_computed_status_rows) + "`.\n"
    )
