from __future__ import annotations

import math
from typing import Tuple

import numpy as np

from cnna.config import EPS
from cnna.core.math_utils import fro


def _support_projector_from_density(D: np.ndarray, tol: float) -> Tuple[np.ndarray, int, float]:
    S = 0.5 * (D + D.T)
    vals, U = np.linalg.eigh(S)
    maxeig = float(np.max(vals)) if vals.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxeig))
    mask = vals > cutoff
    P = U[:, mask] @ U[:, mask].T if np.any(mask) else np.zeros_like(S)
    leakage_scale = float(np.trace(S)) if S.size else 0.0
    return 0.5 * (P + P.T), int(np.sum(mask)), leakage_scale


def von_neumann_entropy_no_epsilon(D: np.ndarray, tol: float = 1.0e-10) -> float:
    """Finite entropy on the tolerance-resolved positive spectral support.

    No epsilon is inserted inside the logarithm.  Eigenvalues at or below the
    scale-aware support cutoff are treated as numerical zero.
    """
    S = 0.5 * (D + D.T)
    vals = np.linalg.eigvalsh(S)
    maxeig = float(np.max(vals)) if vals.size else 0.0
    cutoff = max(float(tol), float(tol) * max(1.0, maxeig))
    pos = [float(x) for x in vals if float(x) > cutoff]
    return float(-sum(x * math.log(x) for x in pos)) if pos else 0.0


def quantum_relative_entropy_no_epsilon(rho: np.ndarray, sigma: np.ndarray, tol: float = 1.0e-10) -> Tuple[float, dict]:
    """Compute D(rho||sigma) with a tolerance-resolved support rule and no logarithmic epsilon floor.

    If the resolved support of rho is not contained in the resolved support of
    sigma, the value is +inf and the
    leakage is reported.  This is the implemented finite support relation for using
    record as a birth-history reference: live||record may legitimately be
    infinite when record has lost support.
    """
    R = 0.5 * (rho + rho.T)
    S = 0.5 * (sigma + sigma.T)
    Ps, sigma_rank, _ = _support_projector_from_density(S, tol)
    support_leakage = float(np.trace((np.eye(S.shape[0]) - Ps) @ R)) if S.size else math.nan
    condition = max(float(tol), float(tol) * max(1.0, abs(float(np.trace(R))) if R.size else 1.0))
    meta = {
        "relative_entropy_support_inclusion_ok": int(support_leakage <= condition),
        "relative_entropy_support_leakage": float(support_leakage),
        "relative_entropy_reference_support_rank": int(sigma_rank),
        "relative_entropy_support_rule": "finite_support_no_epsilon_floor",
    }
    if support_leakage > condition:
        return math.inf, meta
    try:
        rvals, rU = np.linalg.eigh(R)
        svals, sU = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return math.nan, {**meta, "relative_entropy_error": "eigh_failed"}
    rmax = float(np.max(rvals)) if rvals.size else 0.0
    smax = float(np.max(svals)) if svals.size else 0.0
    rcut = max(float(tol), float(tol) * max(1.0, rmax))
    scut = max(float(tol), float(tol) * max(1.0, smax))
    # rho log rho via its spectrum; zero eigenvalues contribute zero.
    term_r = float(sum(float(x) * math.log(float(x)) for x in rvals if float(x) > rcut))
    log_s_vals = np.array([math.log(float(x)) if float(x) > scut else 0.0 for x in svals], dtype=float)
    logS = sU @ np.diag(log_s_vals) @ sU.T
    term_s = float(np.trace(R @ logS))
    return float(term_r - term_s), meta


def jensen_shannon_divergence_no_epsilon(rho: np.ndarray, sigma: np.ndarray, tol: float = 1.0e-10) -> Tuple[float, dict]:
    """Finite, symmetric live-record divergence without epsilon flooring.

    The mixture has support containing both arguments, so this stays finite even
    when one one-way relative entropy is infinite.  It is therefore a safer
    finite finite_object for a common history/live distance than D(live||record).
    """
    M = 0.5 * (0.5 * (rho + rho.T) + 0.5 * (sigma + sigma.T))
    d1, m1 = quantum_relative_entropy_no_epsilon(rho, M, tol)
    d2, m2 = quantum_relative_entropy_no_epsilon(sigma, M, tol)
    val = 0.5 * d1 + 0.5 * d2 if math.isfinite(d1) and math.isfinite(d2) else math.inf
    return float(val), {
        "js_divergence_support_rule": "finite_mixture_support_no_epsilon_floor",
        "js_live_to_mixture_support_ok": int(m1.get("relative_entropy_support_inclusion_ok", 0)),
        "js_record_to_mixture_support_ok": int(m2.get("relative_entropy_support_inclusion_ok", 0)),
    }


def record_live_entropy_metrics(live_density: np.ndarray, record_density: np.ndarray, tol: float = 1.0e-10) -> dict:
    """Directed and symmetric entropy derived_quantity rows for live vs birth-record."""
    d_lr, m_lr = quantum_relative_entropy_no_epsilon(live_density, record_density, tol)
    d_rl, m_rl = quantum_relative_entropy_no_epsilon(record_density, live_density, tol)
    js, m_js = jensen_shannon_divergence_no_epsilon(live_density, record_density, tol)
    diff = 0.5 * (live_density + live_density.T) - 0.5 * (record_density + record_density.T)
    trace_norm = float(np.sum(np.linalg.svd(diff, compute_uv=False))) if diff.size else math.nan
    fro_gap = float(fro(diff)) if diff.size else math.nan
    computed_status = "finite_live_record_entropy_available"
    if not math.isfinite(d_lr):
        computed_status = "live_not_absolutely_continuous_wrt_record_history_control"
    elif not math.isfinite(d_rl):
        computed_status = "record_not_absolutely_continuous_wrt_live_control"
    return {
        "live_record_entropy_relations": "live_physics_state_vs_record_birth_history_reference",
        "D_live_given_record_no_epsilon": float(d_lr) if math.isfinite(d_lr) else math.inf,
        "D_record_given_live_no_epsilon": float(d_rl) if math.isfinite(d_rl) else math.inf,
        "live_support_in_record_support": int(m_lr.get("relative_entropy_support_inclusion_ok", 0)),
        "record_support_in_live_support": int(m_rl.get("relative_entropy_support_inclusion_ok", 0)),
        "live_into_record_support_leakage": float(m_lr.get("relative_entropy_support_leakage", math.nan)),
        "record_into_live_support_leakage": float(m_rl.get("relative_entropy_support_leakage", math.nan)),
        "jensen_shannon_live_record_no_epsilon": float(js) if math.isfinite(js) else math.inf,
        "trace_distance_live_record_density": float(0.5 * trace_norm) if math.isfinite(trace_norm) else math.nan,
        "frobenius_density_gap_live_record": fro_gap,
        "entropy_live": float(von_neumann_entropy_no_epsilon(live_density, tol)),
        "entropy_record": float(von_neumann_entropy_no_epsilon(record_density, tol)),
        "record_live_entropy_computed_status": computed_status,
        **m_js,
    }

__all__ = [
    '_support_projector_from_density',
    'von_neumann_entropy_no_epsilon',
    'quantum_relative_entropy_no_epsilon',
    'jensen_shannon_divergence_no_epsilon',
    'record_live_entropy_metrics'
]
