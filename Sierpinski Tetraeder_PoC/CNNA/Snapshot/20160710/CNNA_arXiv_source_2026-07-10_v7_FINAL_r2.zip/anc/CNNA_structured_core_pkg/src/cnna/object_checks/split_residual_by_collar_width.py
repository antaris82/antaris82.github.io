from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Tuple

from cnna.core.algebra_support import (
    build_genealogical_corridor_regions,
    commutator_metrics,
    genealogical_corridor_metadata,
    joined_algebra,
    local_operator_algebras,
)
from cnna.core.operator_test_config import (
    OperatorTestConfig,
    iter_growth_models,
)
from cnna.core.region_response import (
    region_size_meta,
    regional_response,
)


SPLIT_SCALING_PAIRS = [
    ("left_birth_cone_response", "right_birth_cone_response", "mixed_birth_cones_with_lca_anchor"),
    ("symmetric_left_birth_cone_response", "symmetric_right_birth_cone_response", "symmetric_carrier_birth_cones_with_lca_anchor"),
    ("skew_left_birth_cone_response", "skew_right_birth_cone_response", "directed_current_birth_cones_with_lca_anchor"),
]


def _track_key(row: dict) -> Tuple[object, ...]:
    return (row.get("branching"), row.get("level"), row.get("mode"), row.get("state"), row.get("split_layer_pair"))


def _median(xs: List[float]) -> float:
    ys = sorted(float(x) for x in xs if math.isfinite(float(x)))
    return float(ys[len(ys) // 2]) if ys else math.nan


def _summarize_track(rows: List[dict], tol: float) -> dict:
    by_c_def: Dict[int, List[float]] = defaultdict(list)
    by_c_comm: Dict[int, List[float]] = defaultdict(list)
    for r in rows:
        c = int(r.get("genealogical_corridor_length", -1))
        if c < 0:
            continue
        try:
            by_c_def[c].append(float(r.get("tensor_dimension_residual", math.nan)))
            by_c_comm[c].append(float(r.get("max_relative_commutator", math.nan)))
        except Exception:
            pass
    corridors = sorted(by_c_def)
    if not corridors:
        return {
            "split_residual_collar_count": 0,
            "split_residual_track_computed_status": "split_residual_no_track_available",
        }
    residual = {c: _median(v) for c, v in by_c_def.items()}
    comm = {c: _median(v) for c, v in by_c_comm.items()}
    ordered = [residual[c] for c in corridors]
    first = ordered[0]
    last = ordered[-1]
    mono = int(len(ordered) >= 2 and all(ordered[i + 1] <= ordered[i] + max(tol, tol * max(1.0, ordered[i])) for i in range(len(ordered) - 1)))
    if len(corridors) < 2:
        computed_status = "split_residual_insufficient_collar_trajectory"
    elif max(abs(x) for x in ordered if math.isfinite(x)) <= tol:
        computed_status = "finite_tensor_factorization_dimension_finite_object"
    elif mono and math.isfinite(last) and math.isfinite(first) and last < first:
        computed_status = "split_residual_decreases_with_collar_finite_object"
    elif math.isfinite(last) and math.isfinite(first) and last > first + max(tol, tol * max(1.0, first)):
        computed_status = "split_residual_grows_with_collar_observed"
    else:
        computed_status = "split_residual_no_monotone_improvement_observed"
    return {
        "split_residual_collar_count": int(len(corridors)),
        "split_residual_min_collar": int(corridors[0]),
        "split_residual_max_collar": int(corridors[-1]),
        "split_residual_first_median": float(first) if math.isfinite(first) else math.nan,
        "split_residual_last_median": float(last) if math.isfinite(last) else math.nan,
        "split_commutator_first_median": float(comm.get(corridors[0], math.nan)),
        "split_commutator_last_median": float(comm.get(corridors[-1], math.nan)),
        "split_residual_monotone_nonincreasing": mono,
        "split_residual_track_computed_status": computed_status,
    }


def split_residual_by_collar_width_rows(config: OperatorTestConfig) -> List[dict]:
    rows: List[dict] = []
    for b, L, mode, model in iter_growth_models(config):
        specs = build_genealogical_corridor_regions(
            model,
            max_regions=config.max_regions,
            max_boundary=config.max_boundary,
            max_interior=config.max_interior,
            max_frontier_level=config.directed_frontier_cap,
        )
        for spec in specs:
            meta = {**region_size_meta(model, spec), **genealogical_corridor_metadata(model, spec)}
            for state in config.states:
                resp = regional_response(model, spec, state)
                if resp is None:
                    for left_name, right_name, label in SPLIT_SCALING_PAIRS:
                        rows.append({
                            "branching": b,
                            "level": L,
                            "mode": mode,
                            **meta,
                            "state": state,
                            "left_operator_system": left_name,
                            "right_operator_system": right_name,
                            "split_layer_pair": label,
                            "split_residual_row_computed_status": "response_unavailable",
                        })
                    continue
                algebras = local_operator_algebras(resp, tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                for left_name, right_name, label in SPLIT_SCALING_PAIRS:
                    left = algebras[left_name]
                    right = algebras[right_name]
                    join = joined_algebra("split_scaling_join_" + label, [left, right], tol=config.algebra_tol, max_iter=config.max_algebra_iter)
                    met = commutator_metrics(left, right)
                    product_dim = int(len(left.basis) * len(right.basis))
                    shared_floor = int(max(1, len(left.basis) + len(right.basis) - 1))
                    join_dim = int(len(join.basis))
                    tensor_ratio = float(join_dim / max(1, product_dim))
                    floor_ratio = float(join_dim / max(1, shared_floor))
                    tensor_residual = float(max(0.0, 1.0 - tensor_ratio))
                    if int(meta["genealogical_corridor_length"]) == 0 and int(meta["direct_sibling_birth_coupling"]):
                        row_computed_status = "touching_sibling_split_reference_row"
                    elif float(met["max_relative_commutator"]) <= config.algebra_tol and abs(tensor_residual) <= config.algebra_tol:
                        row_computed_status = "collared_tensor_factorization_finite_object_row"
                    elif int(meta["genealogical_corridor_length"]) >= 2:
                        row_computed_status = "collared_split_residual_row"
                    else:
                        row_computed_status = "uncollared_split_residual_row"
                    rows.append({
                        "branching": b,
                        "level": L,
                        "mode": mode,
                        **meta,
                        "state": state,
                        **resp.density_metadata,
                        "left_operator_system": left_name,
                        "right_operator_system": right_name,
                        "split_layer_pair": label,
                        "left_dim": len(left.basis),
                        "right_dim": len(right.basis),
                        "generated_join_dim": join_dim,
                        "tensor_product_dimension_proxy": product_dim,
                        "shared_identity_span_floor_proxy": shared_floor,
                        "join_to_tensor_dimension_ratio": tensor_ratio,
                        "join_to_shared_identity_span_floor_ratio": floor_ratio,
                        "tensor_dimension_residual": tensor_residual,
                        "max_relative_commutator": met["max_relative_commutator"],
                        "split_residual_row_computed_status": row_computed_status,
                    })
    tracks: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for row in rows:
        if "tensor_dimension_residual" in row:
            tracks[_track_key(row)].append(row)
    summaries = {key: _summarize_track(vals, config.algebra_tol) for key, vals in tracks.items()}
    for row in rows:
        row.update(summaries.get(_track_key(row), {}))
    return rows


def split_residual_by_collar_width_report(rows: List[dict]) -> str:
    computed_status_rows = sorted({str(r.get("split_residual_track_computed_status", "unknown")) for r in rows if "split_residual_track_computed_status" in r})
    row_computed_status_rows = sorted({str(r.get("split_residual_row_computed_status", "unknown")) for r in rows})
    return (
        "# Split residual by genealogical collar width\n\n"
        "This finite scaling surface measures tensor-dimension residual and commutator size as collar width changes.  "
        "It keeps the shared-identity floor separate from tensor factorization and does not assert the AQFT split property.\n\n"
        "Track computed_status_rows: `" + "`, `".join(computed_status_rows) + "`.\n\n"
        "Row computed_status_rows: `" + "`, `".join(row_computed_status_rows) + "`.\n"
    )
