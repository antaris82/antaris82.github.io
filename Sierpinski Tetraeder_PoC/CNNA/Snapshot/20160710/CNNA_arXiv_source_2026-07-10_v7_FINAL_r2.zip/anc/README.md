# Ancillary material

`CNNA_structured_core_pkg/` contains the Python source, source manifests,
environment capture, execution documentation, package checks, and MIT license
for the reproducibility package accompanying the article. The LaTeX article
source remains in the arXiv source root, as required for compilation.
