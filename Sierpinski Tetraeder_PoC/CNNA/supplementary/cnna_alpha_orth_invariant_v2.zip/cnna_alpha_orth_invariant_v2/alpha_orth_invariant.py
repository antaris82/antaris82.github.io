#!/usr/bin/env python3
"""
CNNA minimal alpha_orth / scale-control invariant diagnostic.

The script computes the dimensionless orthogonality-defect coupling

    lambda_UV  = b^k * alpha_UV / C_k
    lambda_Env = alpha_Env(d) / C_k
    Xi         = (1 + lambda_Env) * (1 + lambda_UV)
    rho_M      = -1 / sqrt(Xi)
    alpha_orth = |rho_M|

Epistemic status:
- C_k is forced by the finite unit-edge b-ary approximant.
- alpha_UV is forced by the finite unit-edge UV-tail model.
- alpha_Env(d) is not yet derived from the full complement family here.
  It is selected by an explicit environment model.
- alpha_orth is therefore a diagnostic orthogonality-defect coupling,
  not a physical fine-structure constant and not yet a fully derived
  CNNA invariant.

No complex input, no 3D embedding, no epsilon regularization, no
pseudoinverse, and no least-squares fallback are used.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Literal


EnvModel = Literal["ladder", "constant", "power", "exponential", "none"]


def finite_tail_conductance(b: int, depth: int) -> float:
    if depth <= 0:
        return 0.0
    c = float(b)
    for _ in range(2, depth + 1):
        c = b * c / (1.0 + c)
    return c


def radial_core_conductance(b: int, k: int) -> float:
    if k <= 0:
        return math.inf
    if b == 1:
        return 1.0 / k
    return (b - 1.0) / (1.0 - b ** (-k))


def environment_conductance_ladder(address_depth: int, b: int, env_depth: int) -> float:
    """
    Minimal finite trunk/side environment model.

    This is an explicit model assumption, not a complement-family theorem.
    It often saturates with d for fixed b and env_depth.
    """
    d = int(address_depth)
    if d <= 0 or env_depth <= 0 or b <= 1:
        return 0.0

    side_tail = finite_tail_conductance(b, env_depth - 1) if env_depth > 1 else 0.0
    side_shunt = (b - 1) * side_tail

    g_out = side_shunt
    for _ in range(1, d):
        through_parent = g_out / (1.0 + g_out) if g_out > 0.0 else 0.0
        g_out = side_shunt + through_parent

    return g_out / (1.0 + g_out) if g_out > 0.0 else 0.0


def alpha_env_model(
    model: EnvModel,
    depth: int,
    b: int,
    env_depth: int,
    alpha0: float,
    power_p: float,
    exp_q: float,
) -> float:
    if model == "ladder":
        return environment_conductance_ladder(depth, b, env_depth)
    if model == "constant":
        return max(0.0, alpha0)
    if model == "power":
        return max(0.0, alpha0 * (max(depth, 0) ** power_p))
    if model == "exponential":
        return max(0.0, alpha0 * (exp_q ** max(depth, 0)))
    if model == "none":
        return 0.0
    raise ValueError(f"unknown environment model: {model}")


@dataclass(frozen=True)
class InvariantRow:
    b: int
    k: int
    depth: int
    uv_tail_depth: int
    env_tail_depth: int
    env_model: str
    cut_size: int
    C_k: float
    alpha_uv: float
    alpha_env: float
    alpha_env_status: str
    total_uv_load: float
    lambda_uv: float
    lambda_env: float
    uv_env_dominance_ratio: float
    Xi: float
    log_Xi: float
    rho_M: float
    alpha_orth: float
    angle_degrees: float
    angle_defect_degrees: float
    k_log_b: float
    b_power_k: int
    plausible_fine_structure_like: bool


def compute_row(
    b: int,
    k: int,
    depth: int,
    uv_tail_depth: int,
    env_tail_depth: int,
    env_model: EnvModel,
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
) -> InvariantRow:
    if b < 2:
        raise ValueError("This diagnostic expects b >= 2.")
    if k < 1:
        raise ValueError("k must be >= 1.")
    if env_exp_q < 0:
        raise ValueError("--env-exp-q must be non-negative.")

    C_k = radial_core_conductance(b, k)
    alpha_uv = finite_tail_conductance(b, uv_tail_depth)
    alpha_env = alpha_env_model(
        model=env_model,
        depth=depth,
        b=b,
        env_depth=env_tail_depth,
        alpha0=alpha_env_constant,
        power_p=env_power_p,
        exp_q=env_exp_q,
    )

    cut_size = b ** k
    total_uv = cut_size * alpha_uv
    lambda_uv = total_uv / C_k
    lambda_env = alpha_env / C_k
    dominance = lambda_uv / lambda_env if lambda_env > 0 else math.inf

    Xi = (1.0 + lambda_env) * (1.0 + lambda_uv)
    rho = -1.0 / math.sqrt(Xi)
    alpha_orth = abs(rho)
    angle = math.degrees(math.acos(max(-1.0, min(1.0, rho))))
    defect = abs(angle - 90.0)

    if env_model == "ladder":
        status = "model_assumption: finite trunk/side ladder; not yet complement-family derived"
    elif env_model == "none":
        status = "diagnostic_countermodel: no environment load"
    else:
        status = f"diagnostic_countermodel: explicit {env_model} alpha_env(d), not derived"

    return InvariantRow(
        b=b,
        k=k,
        depth=depth,
        uv_tail_depth=uv_tail_depth,
        env_tail_depth=env_tail_depth,
        env_model=env_model,
        cut_size=cut_size,
        C_k=C_k,
        alpha_uv=alpha_uv,
        alpha_env=alpha_env,
        alpha_env_status=status,
        total_uv_load=total_uv,
        lambda_uv=lambda_uv,
        lambda_env=lambda_env,
        uv_env_dominance_ratio=dominance,
        Xi=Xi,
        log_Xi=math.log(Xi),
        rho_M=rho,
        alpha_orth=alpha_orth,
        angle_degrees=angle,
        angle_defect_degrees=defect,
        k_log_b=k * math.log(b),
        b_power_k=cut_size,
        plausible_fine_structure_like=(0.0 < alpha_orth < 0.1),
    )


def matrix(
    b_values: Iterable[int],
    k_values: Iterable[int],
    depth_values: Iterable[int],
    uv_tail_depth: int,
    env_tail_depth: int,
    env_models: Iterable[EnvModel],
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
    max_cut_size: int,
) -> list[InvariantRow]:
    rows: list[InvariantRow] = []
    for model in env_models:
        for b in b_values:
            for k in k_values:
                if b ** k > max_cut_size:
                    continue
                for d in depth_values:
                    rows.append(
                        compute_row(
                            b=b,
                            k=k,
                            depth=d,
                            uv_tail_depth=uv_tail_depth,
                            env_tail_depth=env_tail_depth,
                            env_model=model,
                            alpha_env_constant=alpha_env_constant,
                            env_power_p=env_power_p,
                            env_exp_q=env_exp_q,
                        )
                    )
    return rows


def write_csv(rows: list[InvariantRow], path: Path) -> None:
    if not rows:
        raise ValueError("no rows to write")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def parse_int_list(s: str) -> list[int]:
    return [int(x) for x in s.split(",") if x.strip()]


def parse_model_list(s: str) -> list[EnvModel]:
    raw = [x.strip() for x in s.split(",") if x.strip()]
    allowed = {"ladder", "constant", "power", "exponential", "none"}
    bad = [x for x in raw if x not in allowed]
    if bad:
        raise ValueError(f"unknown env model(s): {bad}; allowed={sorted(allowed)}")
    return raw  # type: ignore[return-value]


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--b", type=int, default=3)
    p.add_argument("--k", type=int, default=4)
    p.add_argument("--depth", type=int, default=2)
    p.add_argument("--uv-tail-depth", type=int, default=2)
    p.add_argument("--env-tail-depth", type=int, default=2)
    p.add_argument(
        "--env-model",
        choices=["ladder", "constant", "power", "exponential", "none"],
        default="ladder",
    )
    p.add_argument("--alpha-env-constant", type=float, default=1.0)
    p.add_argument("--env-power-p", type=float, default=1.0)
    p.add_argument("--env-exp-q", type=float, default=1.2)
    p.add_argument("--matrix", action="store_true")
    p.add_argument("--b-values", type=str, default="2,3,4,5,6")
    p.add_argument("--k-values", type=str, default="2,3,4,5,6,7,8")
    p.add_argument("--depth-values", type=str, default="1,2,3,4,5,6,7,8,9,10")
    p.add_argument("--env-models", type=str, default="ladder")
    p.add_argument("--max-cut-size", type=int, default=200000)
    p.add_argument("--csv", type=str, default="")
    p.add_argument("--quiet", action="store_true", help="Do not print matrix JSON; useful when --csv is set.")
    args = p.parse_args()

    if args.matrix:
        rows = matrix(
            b_values=parse_int_list(args.b_values),
            k_values=parse_int_list(args.k_values),
            depth_values=parse_int_list(args.depth_values),
            uv_tail_depth=args.uv_tail_depth,
            env_tail_depth=args.env_tail_depth,
            env_models=parse_model_list(args.env_models),
            alpha_env_constant=args.alpha_env_constant,
            env_power_p=args.env_power_p,
            env_exp_q=args.env_exp_q,
            max_cut_size=args.max_cut_size,
        )
        if args.csv:
            write_csv(rows, Path(args.csv))
        if not args.quiet:
            print(json.dumps([asdict(r) for r in rows], indent=2))
        return

    row = compute_row(
        b=args.b,
        k=args.k,
        depth=args.depth,
        uv_tail_depth=args.uv_tail_depth,
        env_tail_depth=args.env_tail_depth,
        env_model=args.env_model,  # type: ignore[arg-type]
        alpha_env_constant=args.alpha_env_constant,
        env_power_p=args.env_power_p,
        env_exp_q=args.env_exp_q,
    )
    print(json.dumps(asdict(row), indent=2))


if __name__ == "__main__":
    main()
