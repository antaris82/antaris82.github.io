# CNNA alpha_orth invariant diagnostic

This package computes the dimensionless orthogonality-defect coupling:

```text
lambda_UV  = b^k * alpha_UV / C_k
lambda_Env = alpha_Env(d) / C_k
Xi         = (1 + lambda_Env) * (1 + lambda_UV)
rho_M      = -1 / sqrt(Xi)
alpha_orth = |rho_M|
```

## Epistemic status

- `C_k` is forced by the finite unit-edge b-ary approximant.
- `alpha_UV` is forced by the finite unit-edge UV-tail model.
- `alpha_Env(d)` is **not yet derived from the full complement family**.
- The default `ladder` environment is a finite trunk/side-branch model assumption.
- Alternative environment models are diagnostic countermodels for sensitivity testing.
- `alpha_orth` is a model-internal, dimensionless orthogonality-defect coupling.
- It is not identified with the physical fine-structure constant.

## Single case

```bash
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --uv-tail-depth 2 --env-tail-depth 2
```

## Environment models

```bash
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model ladder
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model constant --alpha-env-constant 1.0
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model power --alpha-env-constant 0.2 --env-power-p 1.0
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model exponential --alpha-env-constant 0.05 --env-exp-q 1.2
```

## Matrix

```bash
python3 alpha_orth_invariant.py --matrix --csv alpha_matrix.csv --quiet
```

Compare environment assumptions:

```bash
python3 alpha_orth_invariant.py --matrix --env-models ladder,constant,power,exponential --csv alpha_matrix_models.csv --quiet
```
