module
public import RequestProject.PlanarStars

/-!
# Comparison with Richter-Gebert, *An Almost Trivial Observation About the Icosahedron*

Formal checks supporting `PaperComparison.md`.

* `paperD_links`, `paperD_cyclic`: the twelve 5-tuples `D` printed on p. 1 of the paper are,
  under the explicit relabelling `paperLabel`, exactly the vertex links of our icosahedron
  graph `Adj`, each listed in a cyclic order of the link.  So the incidence condition of the
  paper is the same as the planar-star condition of the original question.
* `ico_goldConj_eq_linear`, `affEquiv_paperPerm_goldConj`: the paper's second realization
  (the regular icosahedron relabelled by the permutation (1) on p. 2) is a similarity image
  of our `ico ψ` (great-icosahedron realization).
* `D_ico_zero_iff`, `paperND_goldConj`, `paperND_proj`: our two realizations, and all their
  admissible projective images, satisfy the paper's nondegeneracy hypothesis (ND), namely that
  every non-coplanar quadruple of the regular icosahedron stays non-coplanar.
* `paperND_nonflatStars`: (ND) implies our earlier hypothesis `NonflatStars`.
* `ico_opposite_edges`, `ico_planarStars_iff`: the straight-line motion `t ↦ ico t` keeps opposite
  edges parallel, but has planar stars only for `t² = t + 1` (paper, p. 5, last paragraph).
* `perspIco_paperND`, `flat_not_paperND`: the 1-parameter affinely inequivalent family of the
  earlier answer satisfies (ND); the flat-star family violates it.
* `antipodal_coplanar_proj`: in every admissible projective image of `ico t` any two antipodal
  pairs are coplanar (paper, p. 5, "antipodal edges are coplanar").
-/

@[expose] public section
noncomputable section

open Matrix Real Polynomial

namespace PlanarStarIcosahedron

/-! ## The paper's labelling -/

/-- The paper's labels are encoded as `0, …, 5 ↦ 0̄, …, 5̄` and `6, …, 11 ↦ 0̲, …, 5̲`
(over- and underlined labels, `ī` and `i̲` antipodal).  `paperLabel` sends a paper label to
our label. -/
def paperLabel : Fin 12 → Fin 12 := ![0, 1, 2, 6, 5, 7, 9, 10, 11, 3, 8, 4]

/-- The list `D` of twelve 5-tuples, transcribed from p. 1 of the paper (paper labels). -/
def paperD : List (List (Fin 12)) :=
  [[1, 2, 3, 4, 5], [0, 5, 9, 10, 2], [0, 1, 10, 11, 3],
   [0, 2, 11, 7, 4], [0, 3, 7, 8, 5], [0, 4, 8, 9, 1],
   [6, 11, 2, 1, 9], [6, 7, 3, 2, 10], [6, 8, 4, 3, 11],
   [6, 9, 5, 4, 7], [6, 10, 1, 5, 8], [7, 8, 9, 10, 11]]

theorem paperLabel_bijective : Function.Bijective paperLabel := by decide

/-- Every vertex link of our icosahedron graph is one of the paper's 5-tuples. -/
theorem paperD_links : ∀ v : Fin 12, ∃ t ∈ paperD, ∀ w, w ∈ t.map paperLabel ↔ Adj v w := by
  decide

/-- Each of the paper's 5-tuples is a closed 5-cycle of the icosahedron graph. -/
theorem paperD_cyclic : ∀ t ∈ paperD, t.length = 5 ∧
    ∀ i : Fin 5, Adj (paperLabel (t.getD i 0)) (paperLabel (t.getD ((i + 1 : Fin 5) : ℕ) 0)) := by
  decide

/-- The paper's antipodal map `ī ↔ i̲` corresponds to central symmetry `ico t (anti v) = - ico t v`. -/
def anti : Fin 12 → Fin 12 := ![9, 10, 11, 6, 7, 8, 3, 4, 5, 0, 1, 2]

theorem paperLabel_anti : ∀ i : Fin 12, anti (paperLabel i) = paperLabel (i + 6) := by decide

theorem ico_anti (t : ℝ) (v : Fin 12) : ico t (anti v) = - ico t v := by
  ext i; fin_cases v <;> fin_cases i <;> simp [ico, anti]

/-! ## The paper's permutation (1) -/

/-- Permutation (1) of the paper (p. 2), in paper labels:
`0̄ ↦ 0̄, 1̄ ↦ 1̲, 2̄ ↦ 3̲, 3̄ ↦ 5̲, 4̄ ↦ 2̲, 5̄ ↦ 4̲` and
`0̲ ↦ 0̲, 1̲ ↦ 1̄, 2̲ ↦ 3̄, 3̲ ↦ 5̄, 4̲ ↦ 2̄, 5̲ ↦ 4̄`. -/
def paperPerm : Fin 12 → Fin 12 := ![0, 7, 9, 11, 8, 10, 6, 1, 3, 5, 2, 4]

/-- "Under the permutation map, pairs of antipodal vertices are preserved" (paper, p. 2). -/
theorem paperPerm_anti : ∀ i : Fin 12, paperPerm (i + 6) = paperPerm i + 6 := by decide

/-- Permutation (1) transported to our labels. -/
def ourPerm : Fin 12 → Fin 12 := ![0, 10, 3, 7, 5, 11, 4, 8, 2, 9, 1, 6]

theorem ourPerm_spec : ∀ i, ourPerm (paperLabel i) = paperLabel (paperPerm i) := by decide

/-- Permutation (1) is not an automorphism of the icosahedron graph. -/
theorem ourPerm_not_aut : ¬ ∀ v w, Adj v w → Adj (ourPerm v) (ourPerm w) := by decide

/-- The linear map (a scaled rotation/reflection) relating the two golden realizations. -/
def Lmat : Matrix (Fin 3) (Fin 3) ℝ :=
  !![-1/2, goldenConj/2, goldenConj^2/2; -goldenConj^2/2, 1/2, -goldenConj/2;
    goldenConj/2, goldenConj^2/2, -1/2]

/-- `ico ψ` is the linear image of the regular icosahedron relabelled by permutation (1). -/
theorem ico_goldConj_eq_linear (v : Fin 12) :
    ico goldenConj v = Lmat *ᵥ ico goldenRatio (ourPerm v) := by
  have s2 : √5 ^ 2 = 5 := Real.sq_sqrt (by norm_num)
  ext i
  fin_cases v <;> fin_cases i <;>
    simp [ico, Lmat, ourPerm, mulVec, dotProduct, Fin.sum_univ_three, goldenRatio, goldenConj] <;>
    ring_nf <;> simp only [s2] <;> ring

/-- The `4 × 4` matrix of the affine (linear) map `Lmat`. -/
def Lmat4 : Matrix (Fin 4) (Fin 4) ℝ :=
  !![-1/2, goldenConj/2, goldenConj^2/2, 0; -goldenConj^2/2, 1/2, -goldenConj/2, 0;
    goldenConj/2, goldenConj^2/2, -1/2, 0; 0, 0, 0, 1]

theorem Lmat4_det_ne_zero : Lmat4.det ≠ 0 := by
  have s2 : √5 ^ 2 = 5 := Real.sq_sqrt (by norm_num)
  have s3 : √5 ^ 3 = 5 * √5 := by rw [pow_succ, s2]
  have h : Lmat4.det = -(2 * goldenConj + 1) := by
    rw [Matrix.det_succ_row_zero]
    simp [Lmat4, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove, goldenConj]
    ring_nf; simp only [s2, s3]; ring
  rw [h, goldenConj]
  intro h0
  have h5 : √5 = 2 := by linarith
  rw [h5] at s2
  norm_num at s2

/-- **The paper's second realization is our great-icosahedron realization.**  The regular
icosahedron relabelled by permutation (1) is affinely (indeed by a similarity) equivalent to
`ico ψ`. -/
theorem affEquiv_paperPerm_goldConj :
    AffEquiv (ico goldenRatio ∘ ourPerm) (ico goldenConj) := by
  refine ⟨Lmat4, ?_, isUnit_iff_ne_zero.mpr Lmat4_det_ne_zero, ?_⟩
  · ext j; fin_cases j <;> simp [Lmat4]
  · funext v
    rw [Function.comp_apply, Function.comp_apply, ico_goldConj_eq_linear]
    ext i
    have hden : den Lmat4 (ico goldenRatio (ourPerm v)) = 1 :=
      den_of_affine (by ext j; fin_cases j <;> simp [Lmat4]) _
    simp only [proj, hden, div_one]
    fin_cases i <;> simp [Lmat4, Lmat, mulVec, dotProduct, hom, Fin.sum_univ_succ]

/-! ## The paper's nondegeneracy hypothesis (ND) -/

/-- (ND) of the paper (p. 2): every quadruple that is non-coplanar in the regular icosahedron
stays non-coplanar.  (The paper's labelling of `I` and ours differ by a graph automorphism,
which is induced by a symmetry of the regular icosahedron, so the condition is the same.) -/
def PaperND (X : Fin 12 → Pt) : Prop :=
  ∀ a b c d, D (ico goldenRatio a) (ico goldenRatio b) (ico goldenRatio c) (ico goldenRatio d) ≠ 0
    → D (X a) (X b) (X c) (X d) ≠ 0

/-- An integer polynomial vanishing at an irrational root `x` of `X² − X − 1` is divisible by
`X² − X − 1`. -/
theorem rem_zero_of_eval_zero (p : ℤ[X]) (x : ℝ) (hx : x ^ 2 = x + 1) (hirr : Irrational x)
    (h : p.eval₂ (Int.castRingHom ℝ) x = 0) : p %ₘ (X ^ 2 - X - 1) = 0 := by
  have hm : (X ^ 2 - X - 1 : ℤ[X]).Monic := by monicity!
  have hdeg : (X ^ 2 - X - 1 : ℤ[X]).degree = 2 := by compute_degree!
  set r := p %ₘ (X ^ 2 - X - 1)
  have hr : r.degree ≤ 1 := by
    have := degree_modByMonic_lt p hm
    rw [hdeg] at this
    exact Order.le_of_lt_succ this
  have hrep := eq_X_add_C_of_degree_le_one hr
  have hsplit := modByMonic_add_div p hm
  have hq : (X ^ 2 - X - 1 : ℤ[X]).eval₂ (Int.castRingHom ℝ) x = 0 := by
    simp; linarith
  have hr0 : r.eval₂ (Int.castRingHom ℝ) x = 0 := by
    have := congrArg (fun q => q.eval₂ (Int.castRingHom ℝ) x) hsplit
    simp only [eval₂_add, eval₂_mul, hq, zero_mul, add_zero] at this
    rw [this, h]
  have hr1 : (r.coeff 1 : ℝ) * x + (r.coeff 0 : ℝ) = 0 := by
    rw [hrep] at hr0
    rw [eval₂_add, eval₂_mul, eval₂_C, eval₂_C, eval₂_X] at hr0
    simpa using hr0
  have ha : r.coeff 1 = 0 := by
    by_contra hne
    apply hirr.ne_rat ((-(r.coeff 0) : ℤ) / (r.coeff 1 : ℤ) : ℚ)
    push_cast
    have : (r.coeff 1 : ℝ) ≠ 0 := by exact_mod_cast hne
    field_simp
    linarith
  have hb : r.coeff 0 = 0 := by
    rw [ha] at hr1; exact_mod_cast (by simpa using hr1)
  rw [hrep, ha, hb]; simp

/-- Galois conjugation: an integer polynomial vanishes at `φ` iff it vanishes at `ψ`. -/
theorem eval_gold_zero_iff (p : ℤ[X]) :
    p.eval₂ (Int.castRingHom ℝ) goldenRatio = 0 ↔
      p.eval₂ (Int.castRingHom ℝ) goldenConj = 0 := by
  have hm : (X ^ 2 - X - 1 : ℤ[X]).Monic := by monicity!
  have key : ∀ x y : ℝ, x ^ 2 = x + 1 → Irrational x → y ^ 2 = y + 1 →
      p.eval₂ (Int.castRingHom ℝ) x = 0 → p.eval₂ (Int.castRingHom ℝ) y = 0 := by
    intro x y hx hirr hy h
    have h0 := rem_zero_of_eval_zero p x hx hirr h
    have hsplit := modByMonic_add_div p hm
    rw [h0, zero_add] at hsplit
    rw [← hsplit]
    simp; left; linarith
  exact ⟨key _ _ goldenRatio_sq goldenRatio_irrational goldenConj_sq,
    key _ _ goldenConj_sq goldenConj_irrational goldenRatio_sq⟩

/-- `ico` with the parameter as a polynomial variable. -/
def icoP : Fin 12 → Fin 3 → ℤ[X] :=
  ![![0, 1, X], ![1, X, 0], ![X, 0, 1], ![0, 1, -X], ![1, -X, 0], ![-X, 0, 1],
    ![0, -1, X], ![-1, X, 0], ![X, 0, -1], ![0, -1, -X], ![-1, -X, 0], ![-X, 0, -1]]

def homP (v : Fin 12) : Fin 4 → ℤ[X] := ![icoP v 0, icoP v 1, icoP v 2, 1]

/-- The determinant `D` for `ico t` as an integer polynomial in `t`. -/
def Dpoly (a b c d : Fin 12) : ℤ[X] := (Matrix.of ![homP a, homP b, homP c, homP d]).det

theorem D_ico_eq_eval (t : ℝ) (a b c d : Fin 12) :
    D (ico t a) (ico t b) (ico t c) (ico t d) = (Dpoly a b c d).eval₂ (Int.castRingHom ℝ) t := by
  rw [Dpoly, ← coe_eval₂RingHom, RingHom.map_det, D]
  congr 1
  have hv : ∀ v : Fin 12, ∀ j : Fin 4,
      eval₂RingHom (Int.castRingHom ℝ) t (homP v j) = hom (ico t v) j := by
    intro v j
    fin_cases v <;> fin_cases j <;> simp [homP, icoP, hom, ico]
  ext i j
  fin_cases i <;> simp [RingHom.mapMatrix_apply, ← hv]

/-- **Our two realizations have exactly the same coplanar quadruples.** -/
theorem D_ico_zero_iff (a b c d : Fin 12) :
    D (ico goldenRatio a) (ico goldenRatio b) (ico goldenRatio c) (ico goldenRatio d) = 0 ↔
      D (ico goldenConj a) (ico goldenConj b) (ico goldenConj c) (ico goldenConj d) = 0 := by
  rw [D_ico_eq_eval, D_ico_eq_eval]
  exact eval_gold_zero_iff _

theorem paperND_gold : PaperND (ico goldenRatio) := fun _ _ _ _ h => h

/-- The great-icosahedron realization satisfies the paper's (ND). -/
theorem paperND_goldConj : PaperND (ico goldenConj) :=
  fun a b c d h h' => h ((D_ico_zero_iff a b c d).mpr h')

/-- (ND) is invariant under admissible projective transformations. -/
theorem paperND_proj {M : Matrix (Fin 4) (Fin 4) ℝ} {X : Fin 12 → Pt} (hM : Admissible M X)
    (hX : PaperND X) : PaperND (proj M ∘ X) := by
  intro a b c d h
  simp only [Function.comp]
  rw [D_proj M (hM.2 a) (hM.2 b) (hM.2 c) (hM.2 d)]
  have := hX a b c d h
  have hdet := hM.1.ne_zero
  have := hM.2 a; have := hM.2 b; have := hM.2 c; have := hM.2 d
  refine mul_ne_zero (mul_ne_zero hdet ‹D (X a) (X b) (X c) (X d) ≠ 0›) ?_
  exact inv_ne_zero (by
    refine mul_ne_zero (mul_ne_zero (mul_ne_zero ?_ ?_) ?_) ?_ <;> assumption)

/-- Four points on a common plane have vanishing `D`. -/
theorem D_eq_zero_of_coplanar {p q r s n : Pt} {c : ℝ} (hn : n ≠ 0) (hp : n ⬝ᵥ p = c)
    (hq : n ⬝ᵥ q = c) (hr : n ⬝ᵥ r = c) (hs : n ⬝ᵥ s = c) : D p q r s = 0 := by
  rw [D, ← exists_mulVec_eq_zero_iff]
  refine ⟨![n 0, n 1, n 2, -c], ?_, ?_⟩
  · intro h
    apply hn
    ext i
    have h0 := congrFun h 0; have h1 := congrFun h 1; have h2 := congrFun h 2
    fin_cases i <;> simpa using ‹_›
  · ext i
    fin_cases i <;>
      simp [mulVec, dotProduct, hom, Fin.sum_univ_succ] at hp hq hr hs ⊢ <;>
      linarith

set_option maxHeartbeats 1000000 in
/-- For each vertex `v`, the vertex and the first three neighbours in `nbrs v` are not coplanar in
the regular icosahedron. -/
theorem D_ico_star_ne_zero (v : Fin 12) :
    D (ico goldenRatio v) (ico goldenRatio ((nbrs v).getD 0 0))
      (ico goldenRatio ((nbrs v).getD 1 0)) (ico goldenRatio ((nbrs v).getD 2 0)) ≠ 0 := by
  have s2 : √5 ^ 2 = 5 := Real.sq_sqrt (by norm_num)
  have s0 : (0 : ℝ) < √5 := by positivity
  fin_cases v <;>
  · rw [D, Matrix.det_succ_row_zero]
    simp [nbrs, ico, hom, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    ring_nf
    nlinarith

/-- **(ND) implies `NonflatStars`**, the non-degeneracy hypothesis used in our earlier answer. -/
theorem paperND_nonflatStars {X : Fin 12 → Pt} (hX : PaperND X) : NonflatStars X := by
  intro v n c hn hw hv
  apply hX _ _ _ _ (D_ico_star_ne_zero v)
  have hadj : ∀ k : Fin 3, Adj v ((nbrs v).getD k 0) := by
    intro k; fin_cases v <;> fin_cases k <;> decide
  exact D_eq_zero_of_coplanar hn hv (hw _ (hadj 0)) (hw _ (hadj 1)) (hw _ (hadj 2))

/-! ## Antipodal pairs (paper, p. 5) -/

theorem D_neg_neg (p q : Pt) : D p q (-p) (-q) = 0 := by
  rw [D, Matrix.det_succ_row_zero]
  simp [hom, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
  ring

/-- In every admissible projective image of `ico t`, any two antipodal pairs are coplanar
(in particular opposite edges are coplanar). -/
theorem antipodal_coplanar_proj (t : ℝ) {M : Matrix (Fin 4) (Fin 4) ℝ} (hM : Admissible M (ico t))
    (v w : Fin 12) :
    D ((proj M ∘ ico t) v) ((proj M ∘ ico t) w) ((proj M ∘ ico t) (anti v))
      ((proj M ∘ ico t) (anti w)) = 0 := by
  simp only [Function.comp]
  rw [D_proj M (hM.2 v) (hM.2 w) (hM.2 (anti v)) (hM.2 (anti w)), ico_anti, ico_anti, D_neg_neg]
  simp

/-! ## The linear morph of p. 5 -/

theorem D_ico_1256 (t : ℝ) : D (ico t 1) (ico t 2) (ico t 5) (ico t 6) = 2 * t * (t ^ 2 - t - 1) := by
  rw [D, Matrix.det_succ_row_zero]
  simp [ico, hom, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
  ring

/-- Along the linear path `t ↦ ico t` (each vertex moves on a straight line), opposite edges
stay parallel (indeed antiparallel and of equal length) … -/
theorem ico_opposite_edges (t : ℝ) (v w : Fin 12) :
    ico t (anti v) - ico t (anti w) = -(ico t v - ico t w) := by
  rw [ico_anti, ico_anti]; abel

/-- … but the stars are planar only at the two endpoints `t = φ, ψ`.  This realizes the
"linear morph from `G` to `G*`" mentioned on p. 5 of the paper. -/
theorem ico_planarStars_iff {t : ℝ} (ht : t ≠ 0) : PlanarStars (ico t) ↔ t ^ 2 = t + 1 := by
  refine ⟨fun h => ?_, ico_planarStars t⟩
  obtain ⟨n, hn, c, hw⟩ := h 0
  have hD := D_eq_zero_of_coplanar hn (hw 1 (by decide)) (hw 2 (by decide)) (hw 5 (by decide))
    (hw 6 (by decide))
  rw [D_ico_1256] at hD
  have : t ^ 2 - t - 1 = 0 := by
    rcases mul_eq_zero.mp hD with h | h
    · exact absurd (by linarith : t = 0) ht
    · exact h
  linarith

/-! ## Our earlier families measured against (ND) -/

/-- The perspective family `perspIco k` (pairwise affinely inequivalent realizations) satisfies
the paper's (ND). -/
theorem perspIco_paperND {k : ℝ} (hk : |k| < 1 / 2) : PaperND (perspIco k) :=
  paperND_proj (admissible_persp_ico hk) paperND_gold

/-- The flat-star family `flat s` violates (ND); so it lies outside the scope of the paper's
Theorem 1, and there is no conflict with it. -/
theorem flat_not_paperND (s : ℝ) : ¬ PaperND (flat s) :=
  fun h => flat_not_nonflatStars s (paperND_nonflatStars h)

end PlanarStarIcosahedron
