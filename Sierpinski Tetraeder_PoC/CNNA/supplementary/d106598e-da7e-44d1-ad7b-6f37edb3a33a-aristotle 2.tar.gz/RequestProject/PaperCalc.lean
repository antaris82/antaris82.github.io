module
public import Mathlib

/-!
# Re-checking the coordinate computation of Richter-Gebert's paper

This file re-does, in exact arithmetic, the computation in the section
"The Nitty Gritty Calculations" (pp. 4–5) of J. Richter-Gebert,
*An Almost Trivial Observation About the Icosahedron*, Math. Intelligencer (2026).

Points of the projective plane are homogeneous vectors in `ℝ³`; join and meet are both
the cross product; two lines `l₁, l₂` are parallel iff `det (l₁, l₂, l∞) = 0` with
`l∞ = (0, 0, 1)`.  The affine basis is `p₁ = (0,0)`, `p₂ = (1,0)`, `p₅ = (0,1)` and the free
point is `r₁ = (x, y)`.  The construction follows the geometric meaning of the points
(`qᵢ = i*` is the pentagram-map image, `r₁` the vertex of `P²(X)` corresponding to `p₁`).

Findings (see `PaperComparison.md`):
* the stated values of `q₃` and `q₄` are interchanged in the paper
  (`paper_q3_value_wrong`); the correct values are `q3_eq`, `q4_eq`;
* all other stated intermediate values and factorizations are correct up to nonzero
  scalar factors (`q2_eq`, `q5_eq`, `p3_eq`, `p4_eq`, `det_p3p4p5`, `det_p2p3p4`,
  `par1_eq`, `q1_diag_eq`, `par2_diag_eq`);
* the final conclusion `x = y`, `x² + x − 1 = 0` follows from the nondegeneracy
  conditions and the two parallelism conditions used in the paper (`paper_calc_conclusion`),
  and conversely at these values all five parallelisms hold (`all_parallel_at_root`).
-/

@[expose] public section
noncomputable section

open Matrix

namespace PaperCalc

/-- Join of two points / meet of two lines (cross product). -/
def jn (a b : Fin 3 → ℝ) : Fin 3 → ℝ := crossProduct a b

/-- `3 × 3` determinant written as a triple product. -/
def det3 (a b c : Fin 3 → ℝ) : ℝ := a ⬝ᵥ crossProduct b c

def p1 : Fin 3 → ℝ := ![0, 0, 1]
def p2 : Fin 3 → ℝ := ![1, 0, 1]
def p5 : Fin 3 → ℝ := ![0, 1, 1]
/-- Point at infinity in the `x`-direction (direction of `p₁ p₂`). -/
def infX : Fin 3 → ℝ := ![1, 0, 0]
/-- Point at infinity in the `y`-direction (direction of `p₁ p₅`). -/
def infY : Fin 3 → ℝ := ![0, 1, 0]
/-- The line at infinity. -/
def lInf : Fin 3 → ℝ := ![0, 0, 1]
def r1 (x y : ℝ) : Fin 3 → ℝ := ![x, y, 1]

/-- `q₃ = 3* = (p₂ ∨ p₅) ∧ (r₁ ∨ ∞ₓ)`. -/
def q3 (x y : ℝ) := jn (jn p2 p5) (jn (r1 x y) infX)
/-- `q₄ = 4* = (p₂ ∨ p₅) ∧ (r₁ ∨ ∞_y)`. -/
def q4 (x y : ℝ) := jn (jn p2 p5) (jn (r1 x y) infY)
/-- `q₂ = 2* = (p₁ ∨ q₃) ∧ (r₁ ∨ ∞_y)`. -/
def q2 (x y : ℝ) := jn (jn p1 (q3 x y)) (jn (r1 x y) infY)
/-- `q₅ = 5* = (p₁ ∨ q₄) ∧ (r₁ ∨ ∞ₓ)`. -/
def q5 (x y : ℝ) := jn (jn p1 (q4 x y)) (jn (r1 x y) infX)
/-- `p₄ = (p₁ ∨ q₃) ∧ (p₂ ∨ q₅)`. -/
def p4 (x y : ℝ) := jn (jn p1 (q3 x y)) (jn p2 (q5 x y))
/-- `p₃ = (p₁ ∨ q₄) ∧ (p₅ ∨ q₂)`. -/
def p3 (x y : ℝ) := jn (jn p1 (q4 x y)) (jn p5 (q2 x y))
/-- `q₁ = 1* = (p₅ ∨ q₂) ∧ (p₂ ∨ q₅)`. -/
def q1 (x y : ℝ) := jn (jn p5 (q2 x y)) (jn p2 (q5 x y))

/-- Two lines are parallel (meet on the line at infinity). -/
def Par (l m : Fin 3 → ℝ) : Prop := det3 l m lInf = 0

theorem q3_eq (x y : ℝ) : q3 x y = (-1 : ℝ) • ![1 - y, y, 1] := by
  ext i; fin_cases i <;> simp [q3, jn, p2, p5, r1, infX, cross_apply]

theorem q4_eq (x y : ℝ) : q4 x y = (-1 : ℝ) • ![x, 1 - x, 1] := by
  ext i; fin_cases i <;> simp [q4, jn, p2, p5, r1, infY, cross_apply]; ring

/-- The paper states `q₃ = (x, 1 − x, 1)`; this is in fact the value of `q₄`.  The stated
value is not projectively equal to `q₃` (e.g. at `x = y = 0`). -/
theorem paper_q3_value_wrong : ¬ ∀ x y : ℝ, jn (q3 x y) ![x, 1 - x, 1] = 0 := by
  intro h
  have := congrFun (h 0 0) 0
  simp [q3_eq, jn, cross_apply] at this

theorem q2_eq (x y : ℝ) : q2 x y = (-1 : ℝ) • ![x - x * y, x * y, 1 - y] := by
  ext i; fin_cases i <;> simp [q2, q3_eq, jn, p1, r1, infY, cross_apply] <;> ring_nf

theorem q5_eq (x y : ℝ) : q5 x y = ![x * y, y - x * y, 1 - x] := by
  ext i; fin_cases i <;> simp [q5, q4_eq, jn, p1, r1, infX, cross_apply]; ring_nf

theorem p4_eq (x y : ℝ) :
    p4 x y = (-y) • ![(x - 1) * (y - 1), (1 - x) * y, 2 - 2 * x - y] := by
  ext i; fin_cases i <;> simp [p4, q3_eq, q5_eq, jn, p1, p2, cross_apply] <;> (ring_nf; try simp)

theorem p3_eq (x y : ℝ) :
    p3 x y = (-x) • ![(1 - y) * x, (x - 1) * (y - 1), 2 - x - 2 * y] := by
  ext i; fin_cases i <;> simp [p3, q4_eq, q2_eq, jn, p1, p5, cross_apply] <;> (ring_nf; try simp)

/-- The paper's representatives of `p₃, p₄` (without the scalar factors `x`, `y`). -/
def P3 (x y : ℝ) : Fin 3 → ℝ := ![(1 - y) * x, (x - 1) * (y - 1), 2 - x - 2 * y]
def P4 (x y : ℝ) : Fin 3 → ℝ := ![(x - 1) * (y - 1), (1 - x) * y, 2 - 2 * x - y]

/-- `det(p₃, p₄, p₅) = x y (1 − 2x)(y − 1)(x + y − 1)` (paper, p. 4; with the paper's
scaled representatives `x·P₃`, `y·P₄`). -/
theorem det_p3p4p5 (x y : ℝ) :
    det3 (x • P3 x y) (y • P4 x y) p5 = x * y * (1 - 2 * x) * (y - 1) * (x + y - 1) := by
  simp [det3, P3, P4, p5, cross_apply, dotProduct, Fin.sum_univ_three]; ring

/-- `det(p₂, p₃, p₄)` contains the factors `1 − 2y` and `x − 1` (paper, p. 5). -/
theorem det_p2p3p4 (x y : ℝ) :
    det3 p2 (P3 x y) (P4 x y) = (1 - 2 * y) * (x - 1) * (x + y - 1) := by
  simp [det3, P3, P4, p2, cross_apply, dotProduct, Fin.sum_univ_three]; ring

/-- The first parallelism `q₂q₅ ∥ p₃p₄` (paper, p. 5):
`det(l₁, l₂, l∞) = 2 (x − y) x y (x − 1)(y − 1)(x + y − 1)²` with the paper's
representatives. -/
theorem par1_eq (x y : ℝ) :
    det3 (jn ![x - x * y, x * y, 1 - y] ![x * y, y - x * y, 1 - x])
      (jn (x • P3 x y) (y • P4 x y)) lInf
      = 2 * (x - y) * x * y * (x - 1) * (y - 1) * (x + y - 1) ^ 2 := by
  simp [det3, jn, P3, P4, lInf, cross_apply, dotProduct, Fin.sum_univ_three]; ring

/-- On the diagonal `x = y`: `q₁ = (2x − 1) · ((x − 1)x, (x − 1)x, 2x² − 1)` (paper, p. 5). -/
theorem q1_diag_eq (x : ℝ) :
    q1 x x = (2 * x - 1) • ![(x - 1) * x, (x - 1) * x, 2 * x ^ 2 - 1] := by
  ext i; fin_cases i <;> simp [q1, q2_eq, q5_eq, jn, p2, p5, cross_apply] <;> ring

/-- The second parallelism `q₃q₁ ∥ p₅p₄` on the diagonal, with the **correct** `q₃ = (1−x, x, 1)`:
`det = 2 (x − 1)(2x − 1)(x² + x − 1)` (the paper has the opposite sign, which is
immaterial). -/
theorem par2_diag_eq (x : ℝ) :
    det3 (jn ![1 - x, x, 1] ![(x - 1) * x, (x - 1) * x, 2 * x ^ 2 - 1]) (jn p5 (P4 x x)) lInf
      = 2 * (x - 1) * (2 * x - 1) * (x ^ 2 + x - 1) := by
  simp [det3, jn, P4, p5, lInf, cross_apply, dotProduct, Fin.sum_univ_three]; ring

/-- **Conclusion of the computation (paper, p. 5).**  Under the nondegeneracy conditions
`x, y ≠ 0`, `x, y ≠ 1`, `x + y ≠ 1`, `2x ≠ 1` (which the paper derives from "no three of
`p₁, …, p₅` collinear"), the two parallelisms `q₂q₅ ∥ p₃p₄` and `q₁q₃ ∥ p₄p₅` force
`x = y` and `x² + x − 1 = 0`, i.e. `x = (−1 ± √5)/2`. -/
theorem paper_calc_conclusion (x y : ℝ) (hx0 : x ≠ 0) (hy0 : y ≠ 0) (hx1 : x ≠ 1)
    (hy1 : y ≠ 1) (hxy : x + y ≠ 1) (hx2 : 2 * x ≠ 1)
    (hpar1 : Par (jn (q2 x y) (q5 x y)) (jn (p3 x y) (p4 x y)))
    (hpar2 : Par (jn (q1 x y) (q3 x y)) (jn (p4 x y) p5)) :
    x = y ∧ x ^ 2 + x - 1 = 0 := by
  have hxy' : x + y - 1 ≠ 0 := fun h => hxy (by linarith)
  have hx1' : x - 1 ≠ 0 := sub_ne_zero.mpr hx1
  have hy1' : y - 1 ≠ 0 := sub_ne_zero.mpr hy1
  have e1 : x = y := by
    have h := hpar1
    unfold Par det3 at h
    rw [q2_eq, q5_eq, p3_eq, p4_eq] at h
    simp only [jn, cross_apply, dotProduct, Fin.sum_univ_three, Pi.smul_apply, smul_eq_mul,
      Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_two, lInf,
      Matrix.head_cons, Matrix.tail_cons] at h
    have h' : (x - y) * (x * y * (x - 1) * (y - 1) * (x + y - 1) ^ 2) = 0 := by
      linear_combination (-1/2 : ℝ) * h
    rcases mul_eq_zero.mp h' with h' | h'
    · linarith
    · exfalso; revert h'; positivity
  subst e1
  refine ⟨rfl, ?_⟩
  have h := hpar2
  unfold Par det3 at h
  rw [q1_diag_eq, q3_eq, p4_eq] at h
  simp only [jn, cross_apply, dotProduct, Fin.sum_univ_three, Pi.smul_apply, smul_eq_mul,
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_two, lInf, p5,
    Matrix.head_cons, Matrix.tail_cons] at h
  have h2x : 2 * x - 1 ≠ 0 := fun h => hx2 (by linarith)
  have h' : (x ^ 2 + x - 1) * (x * (2 * x - 1) ^ 2 * (x - 1)) = 0 := by
    linear_combination (1/2 : ℝ) * h
  rcases mul_eq_zero.mp h' with h' | h'
  · exact h'
  · exfalso; revert h'; positivity

/-- Conversely, at `x = y` with `x² + x − 1 = 0`, all five parallelisms between the sides
of `P²(X)` (lying on the lines `q₃q₅, q₁q₄, q₂q₅, q₁q₃, q₂q₄`) and the corresponding sides
`p₁p₂, p₂p₃, p₃p₄, p₄p₅, p₅p₁` of `X` hold. -/
theorem all_parallel_at_root (x : ℝ) (hx : x ^ 2 + x - 1 = 0) :
    Par (jn (q3 x x) (q5 x x)) (jn p1 p2) ∧ Par (jn (q1 x x) (q4 x x)) (jn p2 (p3 x x)) ∧
    Par (jn (q2 x x) (q5 x x)) (jn (p3 x x) (p4 x x)) ∧
    Par (jn (q1 x x) (q3 x x)) (jn (p4 x x) p5) ∧ Par (jn (q2 x x) (q4 x x)) (jn p5 p1) := by
  simp only [Par, det3, lInf, q1, q2, q3, q4, q5, p3, p4, jn, p1, p2, p5, r1, infX, infY,
    cross_apply, dotProduct, Fin.sum_univ_three, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.head_cons, Matrix.tail_cons]
  refine ⟨by ring, ?_, by ring, ?_, by ring⟩ <;>
    linear_combination (-2 * x + 10 * x ^ 2 - 16 * x ^ 3 + 8 * x ^ 4) * hx

end PaperCalc
