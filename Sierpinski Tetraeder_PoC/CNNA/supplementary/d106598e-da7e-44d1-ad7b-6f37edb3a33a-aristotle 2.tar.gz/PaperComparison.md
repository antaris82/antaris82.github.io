# Comparison with J. Richter-Gebert, *An Almost Trivial Observation About the Icosahedron*

**Paper:** J. Richter-Gebert, *An Almost Trivial Observation About the Icosahedron*, The Mathematical
Intelligencer (2026), file `s00283-026-10534-1.pdf`, 5 pages. Page numbers below ("p. 3") are the
printed page numbers 1–5 of the article, which are also PDF pages 1–5.

**Previous answer:** `PlanarStarIcosahedra.md` and its summary `ARISTOTLE_SUMMARY.md`. **Neither file
has been changed.** Every correction or refinement is listed explicitly in §6 of this document.

**Status labels used below**

| label | meaning |
|---|---|
| **Lean (earlier)** | machine-checked in the earlier session: `RequestProject/PlanarStars.lean`, `RequestProject/PlanarStarsRelabel.lean` |
| **Lean (new)** | machine-checked in this session: `RequestProject/PaperComparison.lean`, `RequestProject/PaperCalc.lean` |
| **computed** | exact computer calculation in `computations/`, not checked in Lean |
| **paper** | proved in the paper (informal proof), not machine-checked by us in full |
| **informal** | our own argument on paper, not machine-checked |
| **open** | could not be definitively verified |

All Lean files build without `sorry` and use only the standard axioms (`propext`, `Classical.choice`,
`Quot.sound`).

---

## 1. What the paper actually states

* **Set-up (p. 1).** \(I\) is the regular icosahedron with vertices \(p_0,\dots,p_{11}\). For each vertex
  \(p\), \(N(p)=(q_1,\dots,q_5)\) is its list of edge neighbours, a regular pentagon in counter-clockwise
  order seen from \(p\). The combinatorial list
  \(D=\{(a,b,c,d,e)\mid (p_a,\dots,p_e)\in P\}\) records the twelve neighbour pentagons as 5-tuples
  (the explicit list is on p. 1). Labels are \(\bar 0,\dots,\bar 5,\underline 0,\dots,\underline 5\),
  with \(\bar i\) and \(\underline i\) antipodal and \(N(\bar 0)=(\bar1,\dots,\bar5)\).
* **Theorem 1 (pp. 1–2).** Twelve points in \(\mathbb R^3\) satisfying (ND) for which every
  5-tuple of \(D\) is coplanar have, up to projective equivalence, only two realizations. After a
  projective transformation both have the vertex set of \(I\); the second arises from the first by
  the vertex permutation (1) (p. 2).
* **(ND) (p. 2).** "All noncoplanarities of the regular icosahedron also lead to noncoplanar
  situations in the realization", i.e. realizations of the *matroid* of \(I\). Consequences stated
  there: the planes \(A\supset\{\bar1..\bar5\}\) and \(B\supset\{\underline1..\underline5\}\) differ,
  \(\bar0,\underline0\notin A\cup B\), and no three points are collinear.
* **Kepler–Poinsot reading (pp. 2–3).** Reading the twelve pentagons as faces gives the great
  dodecahedron \(G\); the second realization gives the small stellated dodecahedron \(G^*\).
  *Realization space* = set of realizations modulo projective transformations (p. 2).
  **Theorem 2 (p. 3):** the realization space of \(G\) consists of exactly two points, \(G\) and \(G^*\).
* **Pentagram map (p. 3).** With \(A\parallel B\) (normalized by a projective map),
  \(i^*:=(i+1\vee i+3)\wedge(i-1\vee i-3)\) defines \(P\). **Theorem 3 (p. 3):** if
  \(X=(\bar1,\dots,\bar5)\) comes from a realization of \(D\), then \(P^2(X)\sim X\) (\(\sim\) =
  homothety). The paper also mentions Clebsch (1871): \(X\) and \(P(X)\) are projectively equivalent
  for every nondegenerate pentagon. **Theorem 4 (p. 3):** if \(P^2(X)\sim X\), then \(X\) is an affine
  image of a regular pentagon or a regular pentagram. The paper says Theorem 4 "immediately implies
  Theorems 1 and 2 as corollaries" (p. 3).
* **Computation (pp. 4–5).** Affine basis \(p_1=(0,0),p_2=(1,0),p_5=(0,1)\) and a free point
  \(r_1=(x,y)\). The paper computes \(q_2,\dots,q_5,p_3,p_4\), uses
  \(\det(p_3,p_4,p_5)=xy(1-2x)(y-1)(x+y-1)\ne0\) and \(\det(p_2,p_3,p_4)\ne0\), the parallelism
  \(\det(l_1,l_2,l_\infty)=2(x-y)xy(x-1)(y-1)(x+y-1)^2=0\), so \(x=y\), and then
  \(\det(g_1,g_2,l_\infty)=-2(-1+x)(-1+2x)(-1+x+x^2)=0\), so \(x=(-1\pm\sqrt5)/2\).
* **Incidence theorems (p. 5).** Degree-of-freedom count \((12-5)\cdot3=21\) against \(24\)
  incidences, so "three of the incidences are a consequence of the other 21. We have not yet fully
  analyzed the exact interdependencies." There are fifteen further coincidences in every realization
  (antipodal edges coplanar; joins of antipodal points concurrent). A linear morph from \(G\) to \(G^*\)
  keeps all opposite edges parallel but destroys the pentagon coplanarities.

---

## 2. Assumptions: paper versus the original question (Question 2)

| aspect | original question | paper |
|---|---|---|
| incidence data | icosahedron edge pattern; for each point, its five neighbours coplanar | the twelve 5-tuples of \(D\) coplanar (p. 1) |
| points | twelve **distinct** points in \(\mathbb R^3\) | twelve points in \(\mathbb R^3\) with **(ND)** (p. 2) |
| non-degeneracy | none beyond distinctness | (ND): every non-coplanar quadruple of \(I\) stays non-coplanar, i.e. a realization of the matroid of \(I\) |
| equivalence | not specified (the question asked us to distinguish notions) | projective equivalence only; realization space = realizations mod projective maps (pp. 2–3) |
| labelling | edge pattern fixed, labels implicit | fixed labelling by \(D\); Theorem 2 talks about labelled realizations |

**Same incidence condition (Lean (new)).** We checked that the paper's list \(D\) is exactly our
condition. `paperD_links`: under the explicit relabelling `paperLabel`, each vertex link of our graph
`Adj` is one of the paper's 5-tuples. `paperD_cyclic`: each 5-tuple is listed in a cyclic order of
its link. `paperLabel_anti` and `ico_anti`: the paper's antipodal map \(\bar i\leftrightarrow\underline i\)
is central symmetry of our `ico t`.

**Differences.**

1. **(ND) is much stronger than distinctness.** It forbids, among other things, coplanar
   configurations and flat vertex stars. Both occur among the distinct-point solutions of the
   original question (§5 of the previous answer). So the paper answers the original question only
   under an extra hypothesis that the question did not contain.
2. **(ND) is stronger than the hypothesis of our conjecture.** Lean (new) `paperND_nonflatStars`:
   (ND) ⇒ `NonflatStars`. (ND) also forbids three collinear points (p. 2), hence three collinear
   neighbours. The converse fails or is at least unproved: our hypotheses only control vertex stars,
   while (ND) controls all non-coplanar quadruples of \(I\).
3. **Equivalence.** The paper works only modulo projective maps. The original question asked for the
   deformations and for different notions of equivalence. The paper does not discuss congruence,
   similarity or affine equivalence of the 3D configurations. Affine equivalence appears only for the
   planar pentagon \(X\) (Theorem 4).
4. **Labelling (open in the paper).** Theorem 2 talks about labelled realizations. The paper does not
   say whether \(G\) and \(G^*\) could become projectively equivalent after relabelling by a graph
   automorphism. (This is ruled out by our Lean theorem `not_projEquiv_gold_goldConj_aut`, see §3.)
5. A remark on the paper's formulation: (ND) is phrased with the paper's own labelling of \(I\). Our
   `PaperND` uses our labelling of `ico φ`. The two labellings differ by a graph automorphism. Every
   automorphism of the icosahedron graph is induced by a symmetry of the regular icosahedron (standard
   fact, *not* checked in Lean), so the two conditions agree.

---

## 3. Statement-by-statement comparison (Question 1)

### 3a. Statements of the previous answer that the paper confirms

| previous statement (`PlanarStarIcosahedra.md`) | paper | our evidence |
|---|---|---|
| `ico φ` (regular icosahedron) is a realization (§1) | first realization, Theorem 1 (pp. 1–2) | Lean (earlier) `ico_planarStars`, `isRealization_gold` |
| `ico ψ` is a second realization on the same point set, with pentagram stars (§1) | second realization = vertex set of \(I\) relabelled by (1), Theorem 1 (p. 2); its faces are pentagrams, \(G^*\) (p. 2) | Lean (earlier) `isRealization_goldConj`. Lean (new) `affEquiv_paperPerm_goldConj`: \(I\) relabelled by (1) is affinely (indeed by a similarity, `ico_goldConj_eq_linear`) equivalent to `ico ψ` |
| projective images of realizations are realizations (§2) | stated on p. 3 ("every projective image of a realization … is a realization") | Lean (earlier) `planarStars_proj`, `isRealization_proj` |
| the two realizations are not projectively equivalent (§3) | Theorems 1, 2 (pp. 1–3) | Lean (earlier) `not_projEquiv_gold_goldConj` |
| the condition is rigid up to projective maps near both shapes (§4) | follows from Theorem 1 (global), see §4c | computed (`jacobian_rank.py`) + informal |
| the 24 equations are dependent; their rank is 21 (§4) | dof count, 3 dependent incidences (p. 5) | computed |
| some non-degeneracy hypothesis is necessary (§5) | the paper assumes (ND) | Lean (earlier) `planarStars_of_coplanar`, `flat_not_projEquiv` |
| §6 partial reduction: the lower ring is a central projection, from vertex 0, of the inner pentagon of the link | exactly the construction of Fig. 3 and Theorem 3 (p. 3) | informal (ours), paper |
| conjecture: exactly two projective classes (§6) | Theorem 1 under (ND) | paper; hypotheses differ, see §4d |

### 3b. Statements that go beyond the paper

| statement | status |
|---|---|
| explicit dimension count: 15-dimensional family of realizations near each shape; 9 parameters up to congruence, 8 up to similarity, 3 up to affine maps (§2) | informal (elementary consequence of projective invariance and the finite stabilizer); the paper does not discuss metric or affine families |
| one-parameter family `perspIco k` of pairwise **affinely inequivalent** realizations (§2) | Lean (earlier) `perspIco_isRealization`, `perspIco_not_affEquiv`; Lean (new) `perspIco_paperND`: the family satisfies (ND) |
| non-regular **convex** icosahedra with planar vertex stars (§2) | informal; not in the paper |
| the two shapes are projectively inequivalent **even after relabelling by any graph automorphism** (§3) | Lean (earlier) `not_projEquiv_gold_goldConj_aut`, `cr_ico_linkPaths`; the paper does not state it |
| projectively invariant cross ratio equal to \(\varphi\) resp. \(\psi\) at every vertex (§3) | Lean (earlier) `crossRatioAt0_ico`, `cr_ico_linkPaths`; not in the paper |
| Jacobian rank exactly 21 at both shapes, i.e. **infinitesimal** rigidity modulo projective maps (§4) | computed. The paper (p. 5) explicitly leaves the dependencies unanalysed; our computation shows that at both solutions exactly 3 of the 24 equations are dependent to first order |
| solutions without (ND): the 24-parameter coplanar family and the non-coplanar flat-star family, pairwise projectively inequivalent (§5) | Lean (earlier) `planarStars_of_coplanar`, `flat_isRealization`, `flat_not_coplanar`, `flat_not_nonflatStars`, `flat_not_projEquiv`; Lean (new) `flat_not_paperND`. The paper does not consider realizations without (ND) |
| numerical search (§6) | exploratory floating point only, not a proof |

### 3c. Potential contradictions

We found **no contradiction**. Points where the two texts could seem to conflict:

* "Exactly two realizations" (paper) versus "continuous 15-parameter families" (ours). This is not a
  conflict: the paper counts projective classes, we counted actual point configurations and classes
  for finer equivalences. Projectively our families collapse to a point, as in the paper.
* Our flat-star family is a continuum of pairwise projectively inequivalent realizations with
  distinct, non-coplanar points. This would contradict Theorem 1 if (ND) were dropped. But the family
  violates (ND) (Lean (new) `flat_not_paperND`). So it shows that the paper's hypothesis cannot simply
  be replaced by distinctness of the points.
* **Naming.** We called `ico ψ` the "great icosahedron". The paper calls the second realization the
  "small stellated dodecahedron \(G^*\)" and the first the "great dodecahedron \(G\)". The names refer
  to the same configurations seen differently. We named the polyhedron whose edges are the icosahedron
  edges of the realization (for `ico φ` the regular icosahedron, for `ico ψ` the great icosahedron).
  The paper names the polyhedron whose **faces** are the twelve neighbour pentagons (\(G\): pentagonal
  faces; \(G^*\): pentagram faces). The great icosahedron and the small stellated dodecahedron share
  their edge skeleton. Lean (new) `affEquiv_paperPerm_goldConj` checks that the configurations agree.

---

## 4. Validity of the proofs under the paper's assumptions (Question 3)

### 4a. Lean results of the previous answer

All earlier Lean theorems are unconditional statements about explicit configurations, or carry their
own hypotheses. They stay valid verbatim. The new Lean file checks that the paper's assumptions fit
them:

* `paperND_gold`, `paperND_goldConj`: both golden realizations satisfy (ND). For `ico ψ` the proof
  uses Galois conjugation: `D_ico_zero_iff` shows that `ico φ` and `ico ψ` have exactly the same
  coplanar quadruples. The determinant is an integer polynomial in \(t\) (`D_ico_eq_eval`), and such a
  polynomial vanishes at \(\varphi\) iff it vanishes at \(\psi\) (`eval_gold_zero_iff`).
* `paperND_proj`: (ND) is preserved by admissible projective maps, so all realizations in our
  15-dimensional families satisfy (ND), e.g. `perspIco_paperND`.
* `paperND_nonflatStars`: (ND) implies our `NonflatStars`. `flat_not_paperND`: the flat family is
  outside (ND).

### 4b. The Jacobian computation (§4 of the previous answer)

The computation writes each planar star as two equations \(D(n_0,n_1,n_2,n_3)=D(n_0,n_1,n_2,n_4)=0\).
These equations are equivalent to planarity when \(n_0,n_1,n_2\) are not collinear. Under (ND) no
three points are collinear (p. 2), so the reformulation is valid on the whole (ND) locus, not only
near the golden configurations. The computation itself (exact arithmetic in \(\mathbb Q(\sqrt5)\)) is
unaffected. Status unchanged: **computed**, not checked in Lean. The deduction "rank 21 ⇒ local
rigidity" is a standard implicit-function argument and stays **informal**.

### 4c. Local rigidity now also follows from the paper (informal)

(ND) is an open condition: finitely many determinants must be non-zero. So every realization close
enough to `ico φ` satisfies (ND), and by Theorem 1 it is projectively equivalent to `ico φ` or to the
second realization. The cross ratio of Lean (earlier) `crossRatioAt0_ico` is a projective invariant.
It equals \(\varphi\) at `ico φ`, it depends continuously on the configuration, and it equals \(\psi\) on
the other class. So nearby realizations lie in the class of `ico φ`. The same works at `ico ψ`. This
gives a second, independent route to the local statement of §4. It depends on the paper's informal
proof, so it is **paper + informal**. The infinitesimal statement (rank 21) does not follow from the
paper and remains our own **computed** result.

### 4d. The conjecture of §6 and gaps

Our conjecture: if `NonflatStars` holds and no three neighbours of a vertex are collinear, then there
are exactly two projective classes (up to relabelling).

* **Under (ND)** the paper proves this (Theorem 1). Since (ND) implies our hypotheses, this covers the
  conjecture only on the smaller (ND) class.
* **Under our weaker hypotheses: open.** Some of the paper's uses of (ND) can be recovered from our
  hypotheses (informal, not checked in Lean): \(A\ne B\), and \(\bar0\notin B\) via Clebsch-type
  nondegeneracy of the pentagons. We could not exclude other degeneracies allowed by our hypotheses
  but forbidden by (ND), for example a point of the configuration on the line \(A\cap B\), or
  collinearities among the derived points \(p_3,p_4,q_i\) in the plane computation. So the conjecture
  as we stated it remains **open**.
* **Gap in our previous answer:** the "partial reduction" of §6 stopped at a condition on the pentagon.
  The paper closes this step under (ND) with Theorems 3 and 4 and the computation of pp. 4–5. Our
  earlier write-up did not contain this argument.

### 4e. Gaps and errata in the paper's proof (our reading)

We re-checked the coordinate computation of pp. 4–5 in exact arithmetic (Lean (new), file
`RequestProject/PaperCalc.lean`, namespace `PaperCalc`).

| item (page) | finding | Lean |
|---|---|---|
| \(q_3,q_4\) (p. 4) | the stated values are interchanged: correctly \(q_3=(1-y,y,1)\), \(q_4=(x,1-x,1)\) | `q3_eq`, `q4_eq`, `paper_q3_value_wrong` |
| definitions of \(q_2,q_5\) (p. 4) | \(\infty_x\) and \(\infty_y\) are swapped relative to the geometry; the stated *values* are correct | `q2_eq`, `q5_eq` |
| \(p_3,p_4\), \(\det(p_3,p_4,p_5)\) (p. 4), \(\det(p_2,p_3,p_4)\) factors (p. 5) | correct (with the paper's scaled representatives) | `p3_eq`, `p4_eq`, `det_p3p4p5`, `det_p2p3p4` |
| \(\det(l_1,l_2,l_\infty)=2(x-y)xy(x-1)(y-1)(x+y-1)^2\) (p. 5) | correct | `par1_eq` |
| \(q_1\) on the diagonal (p. 5) | correct | `q1_diag_eq` |
| \(\det(g_1,g_2,l_\infty)\) (p. 5) | correct up to sign (immaterial) when the correct \(q_3\) is used | `par2_diag_eq` |
| conclusion \(x=y\), \(x^2+x-1=0\) (p. 5) | correct, under the non-degeneracy factors the paper derives | `paper_calc_conclusion` |
| "final missing parallelism between \(q_4\vee q_1\) and \(p_1\vee p_2\)" (p. 5) | should read \(p_2\vee p_3\); at the solutions all five side parallelisms hold | `all_parallel_at_root` |
| \(i^*=\wedge(A,h_{i-1},h_{i+i})\) (p. 3) | typo; as printed it does not give the intended point. The intended planes are the two \(h\)-planes through \(\bar0\) and the diagonals through the point \(i^*\) | — (reading only) |
| "(up to projective equivalence) only two realizations of \(P^2(X)\sim X\)" (p. 5) | for the planar pentagon the computation gives "up to affine equivalence", in line with Theorem 4 | — |
| "coplanarities of the fifteen pentagons" (p. 5) | presumably "twelve" | — |
| reconstruction "Theorem 4 ⇒ Theorems 1, 2" (p. 3) | **not carried out in the paper.** One still has to show that, once \(X\) is affinely regular, the remaining points (\(\bar0\), the plane \(B\), the lower ring \(Y\), \(\underline0\)) are determined up to projective maps, and that both candidates satisfy (ND). The second part follows from `paperND_gold`, `paperND_goldConj`. The first part is plausible (one normalizes with projective maps fixing \(A\) and use \(Y\sim P(X)\)), but we did not verify it in full | **open** (not verified by us) |
| sufficiency | the parallelism conditions in the computation are only necessary. Sufficiency is supplied by the existence of the two realizations | Lean (earlier) `isRealization_gold`, `isRealization_goldConj` |
| Theorem 3 (p. 3) | the proof relies on Fig. 3 and on index bookkeeping (which vertex of \(P(X)\) corresponds to which vertex of \(Y\)). We found it plausible but did not formalize it | informal |

**Verdict.** The typos do not affect the conclusion. We consider Theorem 1 to be correctly proved in
substance, but the published proof has the omitted reconstruction step above. We therefore record
Theorem 1 as **paper (informal; reconstruction step not verified by us)**, not as machine-checked.

### 4f. Other claims of the paper that we checked

* Permutation (1) preserves antipodal pairs (p. 2): Lean (new) `paperPerm_anti`. It is **not** a
  graph automorphism: `ourPerm_not_aut`.
* "In every realization, antipodal edges are coplanar" (p. 5). For all admissible projective images
  of `ico t`, any two antipodal pairs are coplanar: Lean (new) `antipodal_coplanar_proj`. Under (ND)
  these images are all realizations by Theorem 1 (paper). The concurrency statement of p. 5 was not
  checked.
* Linear morph (p. 5). Each point of `ico t` moves on a straight line as \(t\) goes from \(\varphi\) to
  \(\psi\), and opposite edges stay parallel (`ico_opposite_edges`). For \(t\ne0\) the stars are planar
  only when \(t^2=t+1\), i.e. only at the two endpoints (`ico_planarStars_iff`). Since `ico ψ` is
  similar to the paper's \(G^*\) (`affEquiv_paperPerm_goldConj`), this realizes the morph described on
  p. 5, up to a similarity at the end.

---

## 5. Known mathematics versus possibly new results (Question 4)

We did not search the literature (as instructed). "Not in the paper" therefore does **not** mean
"new".

* **New presentation of known mathematics.**
  * Projective invariance of incidence conditions; the dimension counts 15/9/8/3. These are standard
    and stated in the paper in qualitative form (p. 3).
  * The golden realizations \((0,\pm1,\pm t)\), \(t^2=t+1\), and their Kepler–Poinsot interpretation.
    These are classical, and the paper describes them (pp. 2–3).
  * Our §6 reduction (central projection of the inner pentagon) is the paper's Fig. 3 / Theorem 3
    construction in projective rather than affine normalization.
* **Not in the paper, possibly new (novelty open).**
  * Infinitesimal rigidity: Jacobian rank exactly 21 at both realizations (computed). This answers,
    at the two solutions and to first order, the question left open on p. 5 about the dependencies
    among the 24 incidences.
  * The behaviour without (ND): continuous families of distinct-point, non-coplanar, pairwise
    projectively inequivalent realizations with a flat star (Lean). This shows that some condition
    like (ND) is necessary.
  * Projective inequivalence of \(G\) and \(G^*\) modulo all graph automorphisms, via a cross ratio
    equal to \(\varphi\) or \(\psi\) at every oriented link (Lean).
  * Explicit affinely inequivalent family `perspIco` (Lean). Elementary, but not stated in the paper.
* **New in this session (Lean (new)).** The identification of the paper's \(D\) and permutation (1)
  with our set-up, the (ND) facts, the machine check of the computation of pp. 4–5 with its errata,
  and the formal version of the linear morph remark.

---

## 6. Maintain / refine / retract / re-examine (Question 5) — explicit corrections

The previous files are unchanged. The following list is the documented set of corrections.

| # | previous statement | decision | reason |
|---|---|---|---|
| 1 | Not unique up to congruence, similarity, affine maps; projective invariance; 15/9/8/3 parameters (§2, summary) | **maintain** | Lean (earlier) + informal count; consistent with the paper |
| 2 | Two golden realizations; `ico ψ` has pentagram stars (§1) | **maintain**; **refine the naming** | the paper's \(G\)/\(G^*\) are the same configurations named by faces (see §3c) |
| 3 | The two are projectively inequivalent even after relabelling (§3) | **maintain** | Lean (earlier); goes beyond the paper |
| 4 | Local projective rigidity via Jacobian rank 21 (§4) | **maintain**, **refine** | still computed + informal; now also follows from the paper's Theorem 1 (§4c of this document); our 24-equation encoding is valid on the whole (ND) locus |
| 5 | Degenerate families show a non-degeneracy hypothesis is needed (§5) | **maintain** | Lean; these families violate (ND) (`flat_not_paperND`), so no conflict |
| 6 | "The natural hypothesis is `NonflatStars`" (§5) | **refine** | `NonflatStars` excludes our flat family, but the uniqueness theorem in the literature uses the stronger (ND). Whether `NonflatStars` + no three collinear neighbours suffices is **open** |
| 7 | **Conjecture** (§6, summary table): exactly two projective classes | **correct the status**: under (ND), *proved in the paper* (Theorem 1, pp. 1–2; proof pp. 3–5, informal, reconstruction step not verified by us). Under our weaker hypotheses: **open** | §4d, §4e |
| 8 | §6 "partial reduction … I did not carry this out" | **refine** | the missing step is supplied by the paper's Theorems 3–4 and its computation, whose algebra we machine-checked (`PaperCalc.paper_calc_conclusion`) |
| 9 | Numerical search (§6) | **maintain as exploratory**; it agrees with Theorem 1 | not a proof |
| 10 | "There are no further continuous families through these two configurations" (§4) | **maintain** | consistent with Theorem 1 |

Nothing in the previous answer is **retracted**. Items to **re-examine** (open):

* whether `NonflatStars` + "no three neighbours collinear" already implies (ND) for realizations, or
  at least suffices for the two-class theorem;
* the omitted reconstruction step "Theorem 4 ⇒ Theorem 1" (p. 3);
* the concurrency statement on p. 5 and a full analysis of which 3 of the 24 incidences are
  dependent (the paper leaves this open; our rank-21 computation settles the first-order question at
  the two solutions only).

**Updated answer to the original question.**

* For twelve distinct points with only the stated incidences, there are continuous families. These
  include the degenerate ones of §5, which are not projectively equivalent to each other.
* Under the paper's (ND), the realizations are exactly the admissible projective images of the
  regular icosahedron and of its golden-conjugate relabelling (paper, Theorem 1).
* Hence the possible deformations are exactly the projective ones. They form 15-parameter families,
  with 9 parameters up to congruence, 8 up to similarity and 3 up to affine maps. Up to projective
  equivalence there are exactly two classes.

---

## 7. Lean index

**Earlier session** (`RequestProject/PlanarStars.lean`, `RequestProject/PlanarStarsRelabel.lean`,
namespace `PlanarStarIcosahedron`): `adj_iff_nearest`, `ico_planarStars`, `isRealization_gold`,
`isRealization_goldConj`, `ico_nonflatStars`, `planarStars_proj`, `isRealization_proj`, `D_proj`,
`cr_proj`, `crossRatioAt0_ico`, `not_projEquiv_gold_goldConj`, `cr_ico_linkPaths`,
`not_projEquiv_gold_goldConj_aut`, `planarStars_of_coplanar`, `flat_isRealization`,
`flat_not_coplanar`, `flat_not_nonflatStars`, `flat_not_projEquiv`, `perspIco_isRealization`,
`perspIco_not_affEquiv`, `AffEquiv.D_ratio_eq`.

**This session.**

* `RequestProject/PaperComparison.lean` (namespace `PlanarStarIcosahedron`): `paperLabel_bijective`,
  `paperD_links`, `paperD_cyclic`, `paperLabel_anti`, `ico_anti`, `paperPerm_anti`, `ourPerm_spec`,
  `ourPerm_not_aut`, `ico_goldConj_eq_linear`, `Lmat4_det_ne_zero`, `affEquiv_paperPerm_goldConj`,
  `PaperND` (definition of (ND)), `rem_zero_of_eval_zero`, `eval_gold_zero_iff`, `D_ico_eq_eval`,
  `D_ico_zero_iff`, `paperND_gold`, `paperND_goldConj`, `paperND_proj`, `D_eq_zero_of_coplanar`,
  `D_ico_star_ne_zero`, `paperND_nonflatStars`, `D_neg_neg`, `antipodal_coplanar_proj`, `D_ico_1256`,
  `ico_opposite_edges`, `ico_planarStars_iff`, `perspIco_paperND`, `flat_not_paperND`.
* `RequestProject/PaperCalc.lean` (namespace `PaperCalc`): `q3_eq`, `q4_eq`, `paper_q3_value_wrong`,
  `q2_eq`, `q5_eq`, `p3_eq`, `p4_eq`, `det_p3p4p5`, `det_p2p3p4`, `par1_eq`, `q1_diag_eq`,
  `par2_diag_eq`, `paper_calc_conclusion`, `all_parallel_at_root`.

**Not formalized:** the paper's Theorems 1–4 as such. In particular, the full uniqueness theorem
under (ND) is *not* machine-checked; only its key computation is.
