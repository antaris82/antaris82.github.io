# Summary of changes for run e2d6584c-c406-438f-a79f-83b5a49ae883
I compared Richter-Gebert's paper (*An Almost Trivial Observation About the Icosahedron*, Math. Intelligencer 2026, pp. 1–5) with my previous answer. The full report, with page citations, is in `PaperComparison.md`. I did not change `PlanarStarIcosahedra.md` or `ARISTOTLE_SUMMARY.md`; every correction is listed explicitly in §6 of the report.

**1. Confirmed, beyond the paper, contradictions**
- **Confirmed by the paper:**
  - The two realizations: the regular icosahedron, and its golden-conjugate relabelling, which is the paper's second realization (Theorem 1, pp. 1–2; permutation (1), p. 2).
  - Projective invariance of the condition (p. 3).
  - That the two are projectively inequivalent (Theorems 1–2).
  - That 3 of the 24 equations are dependent (p. 5).
  - My earlier partial reduction is the paper's Fig. 3 / Theorem 3 construction (p. 3).
- **Beyond the paper:**
  - The parameter counts 9/8/3 up to congruence, similarity and affine maps.
  - A family of realizations that are pairwise not affinely equivalent.
  - Inequivalence of the two realizations even after any relabelling by a graph symmetry.
  - The exact Jacobian rank 21 (first-order rigidity). The paper says on p. 5 that it has not analysed the dependencies among the incidences.
  - Degenerate solution families, which the paper does not consider.
- **Contradictions:** none found. My degenerate families violate the paper's nondegeneracy hypothesis (ND), so they do not conflict with Theorem 1. One naming difference: I called the second realization the "great icosahedron" (named by its edges), while the paper calls it the small stellated dodecahedron \(G^*\) (named by its faces). It is the same configuration.

**2. Assumptions.** The incidence condition is the same as in your question; this is checked in Lean (`paperD_links`, `paperD_cyclic`). But the paper assumes (ND), p. 2: every non-coplanar quadruple of the regular icosahedron stays non-coplanar. That is far stronger than "distinct points", and also stronger than the hypothesis of my earlier conjecture (`paperND_nonflatStars`). The paper also works only up to projective equivalence.

**3. Validity of my proofs.** All earlier Lean theorems still hold. New Lean checks show that both realizations and all their projective images satisfy (ND) (`paperND_gold`, `paperND_goldConj`, `paperND_proj`, `perspIco_paperND`), and that the flat family violates it (`flat_not_paperND`). I re-checked the paper's computation on pp. 4–5 in Lean (`PaperCalc.paper_calc_conclusion`, `all_parallel_at_root`). The conclusion \(x=y\), \(x^2+x-1=0\) is correct, but there are typos:
- The stated values of \(q_3\) and \(q_4\) are interchanged (`paper_q3_value_wrong`).
- The symbols \(\infty_x\) and \(\infty_y\) are swapped in the definitions of \(q_2\) and \(q_5\).
- On p. 5, the parallel line should be \(p_2\vee p_3\), not \(p_1\vee p_2\).
- A sign differs (immaterial), and a few slips in the text.

The paper does not carry out the step "Theorem 4 implies Theorem 1" (p. 3). I did not verify that step either, so I mark it **open**.

**4. Known versus new.** The parameter counts and the golden coordinates are a new presentation of known mathematics. Not in the paper, though I make no novelty claim since I did no literature search: the rank-21 computation, the degenerate families, and the inequivalence modulo all relabellings. New Lean results this session:
- the match between the paper's labels and permutation (1) and my set-up (`affEquiv_paperPerm_goldConj`, `paperPerm_anti`, `ourPerm_not_aut`);
- the paper's linear morph on p. 5 (`ico_opposite_edges`, `ico_planarStars_iff`);
- antipodal coplanarity (`antipodal_coplanar_proj`).

**5. Maintain / refine / retract.** Nothing is retracted.
- **Status changed:** my conjecture "exactly two projective classes" is now *proved in the paper under (ND)*. That proof is informal and has the unverified step above. Under my weaker hypotheses it remains **open**.
- **Refined:** local rigidity now also follows from the paper's Theorem 1 (informal argument). The naming is clarified.
- **Maintained:** everything else.

All Lean files build with no `sorry` and only the standard axioms. The paper's Theorems 1–4 themselves are not formalized; only its key computation is.