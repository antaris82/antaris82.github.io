"""Numerical search for realizations of the icosahedral edge pattern with planar vertex stars.

NOT a proof: exploratory floating-point computation (Levenberg-Marquardt from random starts).

Normalisation (uses the projective freedom): vertex 0 is placed at (0,0,1); its five neighbours
(in cyclic order) lie in the plane z = 0 at (0,0), (1,0), (1,1), (0,1), (a,b); the lower ring is
forced onto the lines through vertex 0 and the diagonal intersections of the upper pentagon and
cut by a plane n.x = 1; the remaining 7 conditions (coplanarity + concurrency of the five lower
star planes) are solved for (a, b, n1, n2, n3).

For each converged solution it prints (a,b), the minimal squared distance between two of the 12
points (md ~ 0 means coinciding points, i.e. a degenerate solution) and the cross ratio at each
of the 12 vertices.  Usage: python3 numerical_search.py SEED TRIALS
"""
import math, random, itertools
phi=(1+5**.5)/2
V=[]
for s1 in (1,-1):
  for s2 in (1,-1):
    V+= [(0,s1,s2*phi),(s1,s2*phi,0),(s2*phi,0,s1)]
def d2(a,b): return sum((x-y)**2 for x,y in zip(a,b))
E=[(i,j) for i in range(12) for j in range(i+1,12) if abs(d2(V[i],V[j])-4)<1e-9]
assert len(E)==30
N={i:[j for j in range(12) if (min(i,j),max(i,j)) in E] for i in range(12)}
def det(M):
  M=[r[:] for r in M]; n=len(M); d=1
  for c in range(n):
    p=max(range(c,n),key=lambda r:abs(M[r][c]))
    if abs(M[p][c])<1e-300: return 0
    if p!=c: M[c],M[p]=M[p],M[c]; d=-d
    d*=M[c][c]
    for r in range(c+1,n):
      f=M[r][c]/M[c][c]
      for k in range(c,n): M[r][k]-=f*M[c][k]
  return d
def F(P):
  out=[]
  for v in range(12):
    n=N[v]
    for k in (3,4):
      out.append(det([list(P[n[a]])+[1] for a in (0,1,2,k)]))
  return out
def jac(P,h=1e-6):
  x=[c for p in P for c in p]
  cols=[]
  for i in range(36):
    xp=x[:];xm=x[:];xp[i]+=h;xm[i]-=h
    f=lambda y:F([y[3*j:3*j+3] for j in range(12)])
    cols.append([(a-b)/(2*h) for a,b in zip(f(xp),f(xm))])
  return [[cols[j][i] for j in range(36)] for i in range(24)]
def svals_rank(J,tol=1e-7):
  M=[r[:] for r in J]; m=len(M); n=len(M[0]); r=0
  piv=[]
  for c in range(n):
    p=max(range(r,m),key=lambda i:abs(M[i][c])) if r<m else None
    if p is None or abs(M[p][c])<tol: continue
    M[r],M[p]=M[p],M[r]
    for i in range(m):
      if i!=r:
        f=M[i][c]/M[r][c]
        for k in range(n): M[i][k]-=f*M[r][k]
    piv.append(abs(M[r][c])); r+=1
  return r,piv
import random, sys
# cyclic order of neighbors
def cyc(v):
  n=N[v][:]; order=[n[0]]
  while len(order)<5:
    last=order[-1]
    nxt=[w for w in n if w not in order and (min(w,last),max(w,last)) in E]
    order.append(nxt[0])
  return order
C={v:cyc(v) for v in range(12)}
def F2(P):
  out=[]
  for v in range(12):
    n=C[v]
    for k in (3,4):
      out.append(det([list(P[n[a]])+[1] for a in (0,1,2,k)]))
  return out
anti={v:[w for w in range(12) if abs(d2(V[v],V[w])-4*(1+phi**2))<1e-6][0] for v in range(12)}
a0=anti[0]
fixed=[0,C[0][0],C[0][2],a0,C[a0][0]]
frame=[(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,1)]
free=[v for v in range(12) if v not in fixed]
def build(x):
  P=[None]*12
  for v,f in zip(fixed,frame): P[v]=list(f)
  for i,v in enumerate(free): P[v]=list(x[3*i:3*i+3])
  return P
def res(x): return F2(build(x))
def solve(A,b):
  n=len(A); M=[A[i][:]+[b[i]] for i in range(n)]
  for c in range(n):
    p=max(range(c,n),key=lambda r:abs(M[r][c])); M[c],M[p]=M[p],M[c]
    if abs(M[c][c])<1e-300: return None
    for r in range(n):
      if r!=c:
        f=M[r][c]/M[c][c]
        for k in range(c,n+1): M[r][k]-=f*M[c][k]
  return [M[i][n]/M[i][i] for i in range(n)]
def LM(x,it=200):
  lam=1e-3; r=res(x); c=sum(t*t for t in r)
  for _ in range(it):
    h=1e-7; m=len(x)
    J=[]
    for i in range(m):
      xp=x[:];xp[i]+=h; J.append([(a-b)/h for a,b in zip(res(xp),r)])
    A=[[sum(J[i][k]*J[j][k] for k in range(24))+(lam if i==j else 0) for j in range(m)] for i in range(m)]
    g=[-sum(J[i][k]*r[k] for k in range(24)) for i in range(m)]
    d=solve(A,g)
    if d is None: return x,c
    xn=[a+b for a,b in zip(x,d)]; rn=res(xn); cn=sum(t*t for t in rn)
    if cn<c: x,r,c=xn,rn,cn; lam*=0.3
    else: lam*=10
    if c<1e-26: break
  return x,c
def cross(u,v): return [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
def sub(a,b): return [x-y for x,y in zip(a,b)]
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def inv(P):
  out=[]
  for v in range(12):
    n=[P[w] for w in C[v]]
    p=n[0]; nm=cross(sub(n[1],p),sub(n[2],p))
    ar=lambda a,b: dot(cross(sub(a,p),sub(b,p)),nm)
    a,b,c,d=n[1:]
    out.append(ar(a,c)*ar(b,d)/(ar(b,c)*ar(a,d)))
  return out
top=0; U=C[0]; bot=anti[0]
low=[v for v in range(12) if v not in U and v not in (top,bot)]
def det3(a,b,c): return dot(a,cross(b,c))
def planeof(p,q,r):  # returns (n,d) n.x=d
  n=cross(sub(q,p),sub(r,p)); return n, dot(n,p)
def meet2(pl1,pl2,pl3):
  # intersection of three planes
  (n1,d1),(n2,d2),(n3,d3)=pl1,pl2,pl3
  D=det3(n1,n2,n3)
  x=[d1*a+d2*b+d3*c for a,b,c in zip(cross(n2,n3),cross(n3,n1),cross(n1,n2))]
  return [t/D for t in x]
def config(p):
  a,b,n1,n2,n3=p
  frame2=[(0,0),(1,0),(0,1),(1,1)]  # u ring in projective frame order? labels in cyclic order
  P=[None]*12
  P[top]=[0.,0.,1.]
  pts=[(0.,0.),(1.,0.),(1.,1.),(0.,1.),(a,b)]
  for i,u in enumerate(U): P[u]=[pts[i][0],pts[i][1],0.]
  B=([n1,n2,n3],1.)
  for l in low:
    us=[u for u in U if l in N[u]]
    pls=[]
    for u in us:
      ring=[w for w in N[u] if w in U]
      pls.append(planeof(P[top],P[ring[0]],P[ring[1]]))
    P[l]=meet2(pls[0],pls[1],B)
  return P
def resid(p):
  P=config(p); r=[]; pls=[]
  for l in low:
    nb=[w for w in N[l] if w!=bot]
    r.append(det([P[w]+[1] for w in nb]))
    pl=planeof(P[nb[0]],P[nb[1]],P[nb[2]]); pls.append(pl[0]+[-pl[1]])
  r.append(det([pls[0],pls[1],pls[2],pls[3]])); r.append(det([pls[0],pls[1],pls[2],pls[4]]))
  return r
def fullP(p):
  P=config(p); nb=[w for w in N[low[0]] if w!=bot]
  pls=[]
  for l in low[:3]:
    nb=[w for w in N[l] if w!=bot]; pls.append(planeof(P[nb[0]],P[nb[1]],P[nb[2]]))
  P[bot]=meet2(*pls); return P
def LM(x,it=300):
  lam=1e-3; r=resid(x); c=sum(t*t for t in r)
  for _ in range(it):
    h=1e-7; m=len(x)
    J=[]
    for i in range(m):
      xp=x[:];xp[i]+=h; J.append([(a-b)/h for a,b in zip(resid(xp),r)])
    A=[[sum(J[i][k]*J[j][k] for k in range(len(r)))+(lam if i==j else 0) for j in range(m)] for i in range(m)]
    g=[-sum(J[i][k]*r[k] for k in range(len(r))) for i in range(m)]
    d=solve(A,g)
    if d is None: return x,c
    xn=[a+b for a,b in zip(x,d)]
    try: rn=resid(xn)
    except ZeroDivisionError: lam*=10; continue
    cn=sum(t*t for t in rn)
    if cn<c: x,r,c=xn,rn,cn; lam*=0.3
    else: lam*=10
    if c<1e-28: break
  return x,c
random.seed(int(sys.argv[1]))
for trial in range(int(sys.argv[2])):
  x=[random.uniform(-3,3) for _ in range(5)]
  try:
    x,c=LM(x)
    if c<1e-20:
      P=fullP(x)
      md=min(d2(P[i],P[j]) for i in range(12) for j in range(i))
      print(trial,"ab=%.6f %.6f"%(x[0],x[1]),"md=%.1e"%md,["%.4f"%t for t in inv(P)])
    else: print(trial,"fail %.1e"%c)
  except ZeroDivisionError: print(trial,"zde")
  sys.stdout.flush()
