"""Exact rank of the Jacobian of the planar-star conditions at the two golden realizations.

Exact arithmetic in Q(sqrt 5).  Usage: python3 jacobian_rank.py 1   (regular icosahedron, t = phi)
                                         python3 jacobian_rank.py -1  (great icosahedron,  t = psi)
For each vertex v with neighbours n0..n4, the two equations det[n0,n1,n2,n3;1] = 0 and
det[n0,n1,n2,n4;1] = 0 (24 equations in 36 unknowns) are differentiated exactly (cofactors) and
the rank of the 24 x 36 Jacobian is computed by exact Gaussian elimination.  Result: rank 21,
i.e. the space of first-order deformations has dimension 36 - 21 = 15 = dim PGL(4, R).
This is a computer calculation, it is NOT checked in Lean.
"""
from fractions import Fraction as Fr
class Q5:
  def __init__(s,a,b=0): s.a=Fr(a); s.b=Fr(b)
  def __add__(s,o): o=o if isinstance(o,Q5) else Q5(o); return Q5(s.a+o.a,s.b+o.b)
  __radd__=__add__
  def __neg__(s): return Q5(-s.a,-s.b)
  def __sub__(s,o): return s+(-(o if isinstance(o,Q5) else Q5(o)))
  def __rsub__(s,o): return Q5(o)-s
  def __mul__(s,o): o=o if isinstance(o,Q5) else Q5(o); return Q5(s.a*o.a+5*s.b*o.b,s.a*o.b+s.b*o.a)
  __rmul__=__mul__
  def inv(s): n=s.a*s.a-5*s.b*s.b; return Q5(s.a/n,-s.b/n)
  def __truediv__(s,o): o=o if isinstance(o,Q5) else Q5(o); return s*o.inv()
  def iszero(s): return s.a==0 and s.b==0
  def __repr__(s): return f"{s.a}+{s.b}r5"
import sys
sgn=int(sys.argv[1])
phi=Q5(Fr(1,2),Fr(sgn,2))
V=[]
for s1 in (1,-1):
  for s2 in (1,-1):
    V+= [(Q5(0),Q5(s1),phi*s2),(Q5(s1),phi*s2,Q5(0)),(phi*s2,Q5(0),Q5(s1))]
dot=lambda p,q: sum((x*y for x,y in zip(p,q)),Q5(0))
t=phi
adj=lambda i,j: i!=j and (dot(V[i],V[j])-t).iszero()
N={i:[j for j in range(12) if adj(i,j)] for i in range(12)}
assert all(len(N[i])==5 for i in N)
def det(M):
  n=len(M)
  if n==1: return M[0][0]
  return sum(((-1)**c*M[0][c]*det([r[:c]+r[c+1:] for r in M[1:]]) for c in range(n)),Q5(0))
rows=[]
for v in range(12):
  n=N[v]
  for k in (3,4):
    idx=[n[0],n[1],n[2],n[k]]
    M=[list(V[i])+[Q5(1)] for i in idx]
    row=[Q5(0)]*36
    for r in range(4):
      for c in range(3):
        minor=[M[rr][:c]+M[rr][c+1:] for rr in range(4) if rr!=r]
        row[3*idx[r]+c]=row[3*idx[r]+c]+((-1)**(r+c))*det(minor)
    rows.append(row)
# exact rank
M=[r[:] for r in rows]; rank=0
for c in range(36):
  p=next((i for i in range(rank,24) if not M[i][c].iszero()),None)
  if p is None: continue
  M[rank],M[p]=M[p],M[rank]
  for i in range(24):
    if i!=rank and not M[i][c].iszero():
      f=M[i][c]/M[rank][c]
      M[i]=[x-f*y for x,y in zip(M[i],M[rank])]
  rank+=1
print("rank",rank)
print({i:N[i] for i in N})
def cyc(v):
  n=N[v][:]; order=[n[0]]
  while len(order)<5:
    last=order[-1]
    nxt=[w for w in n if w not in order and adj(w,last)]
    order.append(nxt[0])
  return order
c=cyc(0); print("cyc0",c)
D=lambda *ps: det([list(V[p])+[Q5(1)] for p in ps])
a,b,cc,d,e=c
print("CR", D(0,a,b,d)*D(0,a,cc,e)/(D(0,a,cc,d)*D(0,a,b,e)))
print([ (D(0,a,b,d),D(0,a,cc,e),D(0,a,cc,d),D(0,a,b,e))])
