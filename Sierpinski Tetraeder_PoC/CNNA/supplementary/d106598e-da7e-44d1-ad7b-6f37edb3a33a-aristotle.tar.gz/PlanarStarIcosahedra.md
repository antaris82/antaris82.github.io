# Icosahedra with planar vertex stars

**Problem.** Twelve distinct points \(X_0,\dots,X_{11}\in\mathbb R^3\) are joined by the edges of an
icosahedron, and for every vertex \(v\) its five neighbours lie on a common plane.
Which deformations are possible? Is the configuration unique?

**Short answer.**

* The configuration is **not** unique up to congruence, similarity or affine maps. The condition
  only involves incidences of points and planes, so it is **projectively invariant**. Every
  projective transformation that keeps the twelve points finite turns a solution into another
  solution. Starting from the regular icosahedron this gives a **15‑parameter continuous family**
  (an open subset of \(PGL(4,\mathbb R)\)). That leaves 9 parameters up to congruence,
  8 up to similarity and 3 up to affine maps.
* Up to **projective** equivalence the regular icosahedron is **locally rigid**: all small
  deformations that keep the stars planar are projective. This was shown by an exact computer
  calculation and is *not* checked in Lean (see §4).
* Besides the regular icosahedron there is a second realization, the *great icosahedron*. In it
  every vertex star is a pentagram. It is **not** projectively equivalent to the regular one,
  even after relabelling the vertices (proved in Lean).
* Without a non‑degeneracy assumption there are large continuous families of "flat" solutions.
  These are not projectively equivalent to each other (proved in Lean). The natural assumption
  that excludes them is that **no closed vertex star is flat**.
* **Conjecture (not proved):** if no closed star is flat and no three neighbours of a vertex are
  collinear, every realization is projectively equivalent to the regular icosahedron or to the
  great icosahedron. So there would be exactly two projective classes. Numerical evidence and a
  partial reduction are given in §6.

All Lean statements are in `RequestProject/PlanarStars.lean` and `RequestProject/PlanarStarsRelabel.lean`
(the second uses the machine‑generated case files in `RequestProject/Relabel/`).
They build without `sorry` and use only the standard axioms.

---

## 0. Formal set‑up (Lean)

* `Adj` is the icosahedron graph on the labels `0..11`. `adj_iff_nearest` checks that its edges are
  exactly the nearest‑neighbour pairs of the regular icosahedron.
* `PlanarStars X`: for each `v` there are `n ≠ 0` and `c` with `n ⬝ X w = c` for all neighbours `w`.
* `IsRealization X`: `X` is injective (distinct points) and `PlanarStars X`.
* `NonflatStars X`: no plane contains a vertex together with its five neighbours.
* `proj M`: the projective map \(p\mapsto [M(p,1)]\). `Admissible M X` means \(\det M\neq0\) and no
  point of `X` is sent to infinity. `ProjEquiv X Y` means `Y = proj M ∘ X` for an admissible `M`.
  `AffEquiv` is the same with last row \((0,0,0,1)\).

## 1. Existence: the two "golden" realizations

Let `ico t` be the twelve points \((0,\pm1,\pm t)\) and their cyclic permutations.

**Theorem (`ico_planarStars`, `isRealization_gold`, `isRealization_goldConj`).**
If \(t^2=t+1\), then adjacent points satisfy \(X_v\cdot X_w=t\). So the five neighbours of \(v\)
lie on the plane \(X_v\cdot x=t\), and `ico t` is a realization.
For \(t=\varphi=(1+\sqrt5)/2\) this is the regular icosahedron. For \(t=\psi=(1-\sqrt5)/2\) it is the
Galois‑conjugate configuration. Its point set is again the vertex set of a regular icosahedron,
but the icosahedral edge pattern is now realized by the great icosahedron, so every vertex star
is a pentagram. Both realizations satisfy `NonflatStars` (`ico_nonflatStars`).

## 2. Projective invariance and continuous families

**Theorem (`planarStars_proj`, `proj_injective`, `isRealization_proj`).**
If `X` is a realization and `M` is admissible for `X`, then `proj M ∘ X` is a realization.
*Proof idea:* the plane \(n\cdot x=c\) is the covector \(\ell=(n,-c)\) in homogeneous coordinates.
Then \(\ell M^{-1}\) is a plane containing the image points. Its normal part cannot vanish, because
otherwise \(\ell M^{-1}\), and hence \(\ell\), would be zero.

So every solution comes with the family of its admissible projective images. For the regular
icosahedron the stabilizer in \(PGL(4,\mathbb R)\) is finite (five of the points are in general
position), so the family has dimension 15. What remains depends on the notion of equivalence:

| equivalence | group dimension | remaining parameters of the family |
|---|---|---|
| congruence (isometries) | 6 | 9 |
| similarity | 7 | 8 |
| affine | 12 | 3 |
| projective | 15 | 0 (one point) |

The difference between "affine" and "projective" is shown explicitly:
**Theorem (`perspIco_isRealization`, `perspIco_not_affEquiv`).** The perspective images
`perspIco k` of the regular icosahedron under \((x,y,z)\mapsto(x,y,z)/(1+kz)\), for \(|k|<1/2\), are
realizations, and two of them with different `k` are never affinely equivalent. The proof uses
the affine invariant \(D(0,1,2,5)/D(0,1,2,7)=\varphi/(1+k)\), a ratio of tetrahedron volumes
(`AffEquiv.D_ratio_eq`).

If the plane sent to infinity does not meet the convex hull, the projective image of the convex
regular icosahedron is again a convex icosahedron with planar vertex stars. So the deformation
family contains many non‑regular **convex** polyhedra.

## 3. Two projectively distinct realizations

For six points let \(D(p,q,r,s)=\det\begin{pmatrix}p&q&r&s\\1&1&1&1\end{pmatrix}\) and
\(\mathrm{cr}(p;a;b,c,d,e)=\dfrac{D(p,a,b,d)\,D(p,a,c,e)}{D(p,a,c,d)\,D(p,a,b,e)}\).
This is the cross ratio of the pencil of planes through the line \(pa\).

**Theorem (`D_proj`, `cr_proj`).** Under an admissible projective map,
\(D\mapsto \det M\cdot D/\prod(\text{denominators})\), and `cr` is invariant.

**Theorem (`crossRatioAt0_ico`, `not_projEquiv_gold_goldConj`).** For the vertex \(0\) and its link
\(1,2,6,5,7\) in cyclic order, the cross ratio of `ico t` equals \(t\). Hence the regular
(\(\varphi\)) and the great (\(\psi\)) realizations are not projectively equivalent as labelled
configurations.

**Theorem (`not_projEquiv_gold_goldConj_aut`).** The same holds after relabelling by **any**
automorphism of the icosahedron graph. The cross ratio of `ico t` equals \(t\) at each of the 120
oriented vertex links (`cr_ico_linkPaths`, checked case by case), and every automorphism sends the
link of \(0\) to one of them.

## 4. Local rigidity modulo projective maps (computer calculation, not checked in Lean)

Write the condition as 24 polynomial equations in 36 unknowns: for each vertex,
\(D(n_0,n_1,n_2,n_3)=D(n_0,n_1,n_2,n_4)=0\). Near the golden realizations \(n_0,n_1,n_2\) are not
collinear, so these equations are equivalent to the planarity of the stars.
`computations/jacobian_rank.py` computes the Jacobian at `ico φ` and at `ico ψ` with exact arithmetic in
\(\mathbb Q(\sqrt5)\). In both cases the rank is **21**, so there are exactly
\(36-21=15\) independent first‑order deformations.

*Consequence (standard argument, not formalized):* pick 21 equations with independent
differentials. Near \(X_0\) they cut out a smooth 15‑dimensional manifold \(M\), and the solution set
\(S\) lies inside \(M\). The projective orbit \(O\) of \(X_0\) is a 15‑dimensional submanifold with
\(O\subseteq S\subseteq M\). So \(O\) is open in \(M\), and near \(X_0\) we get \(S=O\). **Every
deformation of the regular icosahedron (or of the great icosahedron) that keeps the vertex stars
planar is, near the start, a projective transformation.** There are no further continuous
families through these two configurations. The naive count \(36-24=12\) is less than 15
because the 24 equations are dependent: at these solutions their rank is only 21.

## 5. Degenerate solutions: which assumptions are needed

* **Coplanar configurations** (`planarStars_of_coplanar`): twelve distinct points in one plane
  satisfy the condition trivially. This is a 24‑parameter family.
* **Non‑coplanar flat‑star solutions** (`flat`, `flat_isRealization`, `flat_not_coplanar`,
  `flat_not_nonflatStars`, `flat_not_projEquiv`). Put vertex 0 above a plane and its link, an
  arbitrary pentagon, in the plane. Put the lower ring at the intersection points of the
  pentagon's diagonals, and put the antipodal vertex 9 anywhere in the plane. All stars are then
  planar: the star of a neighbour of 0 consists of 0 and four collinear points. The Lean family
  moves vertex 9 along a line. It consists of pairwise projectively inequivalent, non‑coplanar
  realizations with distinct points, which shows that some non‑degeneracy hypothesis is
  necessary. Here the star of vertex 9 is flat.

So the natural hypothesis is `NonflatStars`: no vertex lies in the plane of its neighbours.
This also forces the neighbours of each vertex to span a plane.

## 6. Global uniqueness up to projective maps (conjecture, not proved)

> **Conjecture.** Let \(X\) be a realization in which no closed vertex star is flat and no three
> neighbours of any vertex are collinear. Then \(X\) is projectively equivalent, up to relabelling,
> to exactly one of: the regular icosahedron, or the great icosahedron.

What supports it:

1. *Local rigidity* at both known classes (§4).
2. *Partial reduction (informal sketch, not fully proved).* Let \(0\) be a vertex with link
   \(u_1,\dots,u_5\) in the plane \(A\), and let \(l_i\) be the lower vertex adjacent to \(u_i\) and \(u_{i+1}\).
   The star plane of \(u_i\) contains \(0,u_{i-1},u_{i+1}\). Under the hypotheses it is therefore the
   plane through \(0\) and the diagonal \(u_{i-1}u_{i+1}\). So \(l_i\) lies on the line from \(0\) through
   the intersection point \(X_i\) of the diagonals \(u_{i-1}u_{i+1}\) and \(u_iu_{i+2}\). The lower ring is
   then a central projection of the "inner pentagon" of the link. The same argument from the
   antipodal vertex, followed by projection from \(0\) onto \(A\), gives a condition on the
   pentagon \(u_1\dots u_5\) alone: five lines joining \(u_i\) to points of the second inner pentagon
   must be concurrent. Pentagons have 2 projective moduli and this condition imposes 3 equations,
   so only special pentagons qualify. The projectively regular pentagon and pentagram do qualify.
   Proving that they are the only ones, and that the rest of the configuration is then determined
   up to projective maps, would complete the proof. I did not carry this out.
3. *Numerical search* (`computations/numerical_search.py`, exploratory floating point, not a
   proof). The search uses the normalization from item 2. Out of 280 random starts (seeds 1, 11, 12, 13, 14), 135 converged.
   Every converged solution with distinct points had a projectively regular link: 29 times the
   regular pentagon (cross ratio \(\varphi\) at all 12 vertices) and 4 times the regular pentagram
   (cross ratio \(\psi\) at all vertices). All other converged solutions had coinciding points.

## Summary of status

| statement | status |
|---|---|
| regular and great icosahedron are realizations, with non‑flat stars | proved in Lean |
| projective (and affine) images of realizations are realizations | proved in Lean |
| 1‑parameter family of pairwise affinely inequivalent realizations | proved in Lean |
| regular and great icosahedron are projectively inequivalent (even after relabelling) | proved in Lean |
| coplanar and flat‑star degenerate families; flat family pairwise projectively inequivalent | proved in Lean |
| Jacobian rank 21, hence local projective rigidity | exact computer calculation plus a standard argument; **not** checked in Lean |
| exactly two projective classes under non‑degeneracy | **conjecture**, numerical evidence only |
