module
public import RequestProject.Relabel.Basic
public import RequestProject.Relabel.Cases0
public import RequestProject.Relabel.Cases1
public import RequestProject.Relabel.Cases2
public import RequestProject.Relabel.Cases3

/-!
# Inequivalence of the two golden realizations, up to relabelling

At every oriented vertex link of `ico t` (with `t² = t + 1`) the cross ratio equals `t`.
A graph automorphism carries the flag `(0; 1, 2, 6, 5, 7)` to an oriented vertex link,
so the regular icosahedron and the great-icosahedron realization are not projectively
equivalent even after relabelling by an arbitrary automorphism of the icosahedron graph.
-/

@[expose] public section
noncomputable section

open Real

namespace PlanarStarIcosahedron

theorem cr_ico_linkPaths (t : ℝ) (ht : t ^ 2 = t + 1) :
    ∀ x ∈ linkPaths, cr (ico t x.1) (ico t x.2.1) (ico t x.2.2.1) (ico t x.2.2.2.1)
      (ico t x.2.2.2.2.1) (ico t x.2.2.2.2.2) = t := by
  intro x hx
  simp only [linkPaths, List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact cr_ico_0 t ht
  · exact cr_ico_1 t ht
  · exact cr_ico_2 t ht
  · exact cr_ico_3 t ht
  · exact cr_ico_4 t ht
  · exact cr_ico_5 t ht
  · exact cr_ico_6 t ht
  · exact cr_ico_7 t ht
  · exact cr_ico_8 t ht
  · exact cr_ico_9 t ht
  · exact cr_ico_10 t ht
  · exact cr_ico_11 t ht
  · exact cr_ico_12 t ht
  · exact cr_ico_13 t ht
  · exact cr_ico_14 t ht
  · exact cr_ico_15 t ht
  · exact cr_ico_16 t ht
  · exact cr_ico_17 t ht
  · exact cr_ico_18 t ht
  · exact cr_ico_19 t ht
  · exact cr_ico_20 t ht
  · exact cr_ico_21 t ht
  · exact cr_ico_22 t ht
  · exact cr_ico_23 t ht
  · exact cr_ico_24 t ht
  · exact cr_ico_25 t ht
  · exact cr_ico_26 t ht
  · exact cr_ico_27 t ht
  · exact cr_ico_28 t ht
  · exact cr_ico_29 t ht
  · exact cr_ico_30 t ht
  · exact cr_ico_31 t ht
  · exact cr_ico_32 t ht
  · exact cr_ico_33 t ht
  · exact cr_ico_34 t ht
  · exact cr_ico_35 t ht
  · exact cr_ico_36 t ht
  · exact cr_ico_37 t ht
  · exact cr_ico_38 t ht
  · exact cr_ico_39 t ht
  · exact cr_ico_40 t ht
  · exact cr_ico_41 t ht
  · exact cr_ico_42 t ht
  · exact cr_ico_43 t ht
  · exact cr_ico_44 t ht
  · exact cr_ico_45 t ht
  · exact cr_ico_46 t ht
  · exact cr_ico_47 t ht
  · exact cr_ico_48 t ht
  · exact cr_ico_49 t ht
  · exact cr_ico_50 t ht
  · exact cr_ico_51 t ht
  · exact cr_ico_52 t ht
  · exact cr_ico_53 t ht
  · exact cr_ico_54 t ht
  · exact cr_ico_55 t ht
  · exact cr_ico_56 t ht
  · exact cr_ico_57 t ht
  · exact cr_ico_58 t ht
  · exact cr_ico_59 t ht
  · exact cr_ico_60 t ht
  · exact cr_ico_61 t ht
  · exact cr_ico_62 t ht
  · exact cr_ico_63 t ht
  · exact cr_ico_64 t ht
  · exact cr_ico_65 t ht
  · exact cr_ico_66 t ht
  · exact cr_ico_67 t ht
  · exact cr_ico_68 t ht
  · exact cr_ico_69 t ht
  · exact cr_ico_70 t ht
  · exact cr_ico_71 t ht
  · exact cr_ico_72 t ht
  · exact cr_ico_73 t ht
  · exact cr_ico_74 t ht
  · exact cr_ico_75 t ht
  · exact cr_ico_76 t ht
  · exact cr_ico_77 t ht
  · exact cr_ico_78 t ht
  · exact cr_ico_79 t ht
  · exact cr_ico_80 t ht
  · exact cr_ico_81 t ht
  · exact cr_ico_82 t ht
  · exact cr_ico_83 t ht
  · exact cr_ico_84 t ht
  · exact cr_ico_85 t ht
  · exact cr_ico_86 t ht
  · exact cr_ico_87 t ht
  · exact cr_ico_88 t ht
  · exact cr_ico_89 t ht
  · exact cr_ico_90 t ht
  · exact cr_ico_91 t ht
  · exact cr_ico_92 t ht
  · exact cr_ico_93 t ht
  · exact cr_ico_94 t ht
  · exact cr_ico_95 t ht
  · exact cr_ico_96 t ht
  · exact cr_ico_97 t ht
  · exact cr_ico_98 t ht
  · exact cr_ico_99 t ht
  · exact cr_ico_100 t ht
  · exact cr_ico_101 t ht
  · exact cr_ico_102 t ht
  · exact cr_ico_103 t ht
  · exact cr_ico_104 t ht
  · exact cr_ico_105 t ht
  · exact cr_ico_106 t ht
  · exact cr_ico_107 t ht
  · exact cr_ico_108 t ht
  · exact cr_ico_109 t ht
  · exact cr_ico_110 t ht
  · exact cr_ico_111 t ht
  · exact cr_ico_112 t ht
  · exact cr_ico_113 t ht
  · exact cr_ico_114 t ht
  · exact cr_ico_115 t ht
  · exact cr_ico_116 t ht
  · exact cr_ico_117 t ht
  · exact cr_ico_118 t ht
  · exact cr_ico_119 t ht

/-- **The two golden realizations are projectively inequivalent even up to relabelling:**
for no automorphism `σ` of the icosahedron graph is the regular icosahedron projectively
equivalent to the great-icosahedron realization relabelled by `σ`. -/
theorem not_projEquiv_gold_goldConj_aut (σ : Equiv.Perm (Fin 12)) (hσ : IsAut σ) :
    ¬ ProjEquiv (ico goldenRatio) (ico goldenConj ∘ σ) := by
  intro h
  have h1 := h.cr_eq 0 1 2 6 5 7
  have h2 := crossRatioAt0_ico _ goldenRatio_sq
  rw [crossRatioAt0] at h2
  have adj : ∀ v w : Fin 12, Adj v w → Adj (σ v) (σ w) := fun v w hvw => (hσ v w).2 hvw
  have hmem := mem_linkPaths (σ 0) (σ 1) (adj 0 1 (by decide)) (σ 2) (adj 0 2 (by decide))
    (adj 1 2 (by decide)) (σ 6) (adj 0 6 (by decide)) (adj 2 6 (by decide))
    (σ.injective.ne (by decide)) (σ 5) (adj 0 5 (by decide)) (adj 6 5 (by decide))
    (σ.injective.ne (by decide)) (σ.injective.ne (by decide)) (σ 7) (adj 0 7 (by decide))
    (adj 5 7 (by decide)) (σ.injective.ne (by decide)) (σ.injective.ne (by decide))
    (σ.injective.ne (by decide))
  have h3 := cr_ico_linkPaths _ goldenConj_sq _ hmem
  simp only [Function.comp] at h1
  rw [h3, h2] at h1
  have := goldenConj_neg
  have := goldenRatio_pos
  linarith

end PlanarStarIcosahedron
