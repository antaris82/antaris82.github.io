module
public import Mathlib

@[expose] public section
noncomputable section

open Matrix Real

namespace PlanarStarIcosahedron

/-- Points of three-dimensional Euclidean space, in coordinates. -/
abbrev Pt := Fin 3 → ℝ

/-! ## The icosahedral edge pattern -/

/-- Neighbour lists of the icosahedron graph on the labels `0, …, 11`.
(`adj_iff_nearest` below checks that these are exactly the nearest-neighbour pairs of the
regular icosahedron `ico goldenRatio`.) -/
def nbrs : Fin 12 → List (Fin 12) :=
  ![[1, 2, 5, 6, 7], [0, 2, 3, 7, 8], [0, 1, 4, 6, 8], [1, 7, 8, 9, 11], [2, 6, 8, 9, 10],
    [0, 6, 7, 10, 11], [0, 2, 4, 5, 10], [0, 1, 3, 5, 11], [1, 2, 3, 4, 9], [3, 4, 8, 10, 11],
    [4, 5, 6, 9, 11], [3, 5, 7, 9, 10]]

/-- Adjacency in the icosahedron graph. -/
def Adj (v w : Fin 12) : Prop := w ∈ nbrs v

instance : DecidableRel Adj := fun v w => inferInstanceAs (Decidable (w ∈ nbrs v))

theorem adj_symm : ∀ v w, Adj v w → Adj w v := by decide

theorem adj_irrefl : ∀ v, ¬ Adj v v := by decide

theorem exists_adj : ∀ v, ∃ w, Adj v w := by decide

/-- The twelve points `(0, ±1, ±t)` and their cyclic permutations.
For `t = φ` (golden ratio) this is the regular icosahedron; for `t = ψ = 1 - φ`
it is the Galois-conjugate configuration (same 12 points up to scaling, but the
icosahedral edge pattern is then realised by the great icosahedron). -/
def ico (t : ℝ) : Fin 12 → Pt :=
  ![![0, 1, t], ![1, t, 0], ![t, 0, 1], ![0, 1, -t], ![1, -t, 0], ![-t, 0, 1],
    ![0, -1, t], ![-1, t, 0], ![t, 0, -1], ![0, -1, -t], ![-1, -t, 0], ![-t, 0, -1]]

/-- Squared Euclidean distance. -/
def sqDist (p q : Pt) : ℝ := ∑ i, (p i - q i) ^ 2

/-! ## The planar–star condition -/

/-- Every vertex has its five neighbours on a common (affine) plane `n ⬝ x = c`, `n ≠ 0`. -/
def PlanarStars (X : Fin 12 → Pt) : Prop :=
  ∀ v, ∃ n : Pt, n ≠ 0 ∧ ∃ c : ℝ, ∀ w, Adj v w → n ⬝ᵥ X w = c

/-- A realization: twelve *distinct* points with planar vertex stars. -/
def IsRealization (X : Fin 12 → Pt) : Prop :=
  Function.Injective X ∧ PlanarStars X

/-- Non-degeneracy: no closed vertex star is flat, i.e. no plane contains a vertex
together with its five neighbours. -/
def NonflatStars (X : Fin 12 → Pt) : Prop :=
  ∀ v, ∀ n : Pt, ∀ c : ℝ, n ≠ 0 → (∀ w, Adj v w → n ⬝ᵥ X w = c) → n ⬝ᵥ X v ≠ c

/-! ## Projective transformations -/

/-- Homogeneous coordinates `(x, y, z, 1)`. -/
def hom (p : Pt) : Fin 4 → ℝ := ![p 0, p 1, p 2, 1]

/-- The denominator of the projective map given by the `4 × 4` matrix `M` at `p`. -/
def den (M : Matrix (Fin 4) (Fin 4) ℝ) (p : Pt) : ℝ := (M *ᵥ hom p) 3

/-- The projective transformation `p ↦ [M (p,1)]`, in affine coordinates. -/
def proj (M : Matrix (Fin 4) (Fin 4) ℝ) (p : Pt) : Pt :=
  fun i => (M *ᵥ hom p) (Fin.castSucc i) / den M p

/-- `M` is invertible and sends none of the points of `X` to infinity. -/
def Admissible (M : Matrix (Fin 4) (Fin 4) ℝ) (X : Fin 12 → Pt) : Prop :=
  IsUnit M.det ∧ ∀ i, den M (X i) ≠ 0

/-- Labelled projective equivalence. -/
def ProjEquiv (X Y : Fin 12 → Pt) : Prop :=
  ∃ M, Admissible M X ∧ proj M ∘ X = Y

/-- `4 × 4` determinant of homogeneous coordinates (6 × signed volume of the tetrahedron). -/
def D (p q r s : Pt) : ℝ := (Matrix.of ![hom p, hom q, hom r, hom s]).det

/-- Cross ratio of the pencil of planes through the line `pa` and the points `b, c, d, e`. -/
def cr (p a b c d e : Pt) : ℝ := D p a b d * D p a c e / (D p a c d * D p a b e)


/-! ## The two golden realizations -/

set_option maxHeartbeats 2000000 in
/-- Sanity check: the edge pattern `Adj` is exactly the set of nearest-neighbour pairs
(squared distance `4`) of the regular icosahedron `ico φ`. -/
theorem adj_iff_nearest (v w : Fin 12) :
    Adj v w ↔ v ≠ w ∧ sqDist (ico goldenRatio v) (ico goldenRatio w) = 4 := by
  have key : ∀ t : ℝ, t ^ 2 = t + 1 → 1 < t →
      (Adj v w ↔ v ≠ w ∧ sqDist (ico t v) (ico t w) = 4) := by
    intro t ht h1
    fin_cases v <;> fin_cases w <;>
      simp [Adj, nbrs, sqDist, ico, Fin.sum_univ_three] <;> nlinarith
  exact key _ goldenRatio_sq one_lt_goldenRatio

/-- For `t² = t + 1`, adjacent points of `ico t` have scalar product `t`. -/
theorem ico_dot_adj (t : ℝ) (ht : t ^ 2 = t + 1) :
    ∀ v w, Adj v w → ico t v ⬝ᵥ ico t w = t := by
  intro v w h
  fin_cases v <;> fin_cases w <;>
    simp [Adj, nbrs, ico, dotProduct, Fin.sum_univ_three] at h ⊢ <;> linear_combination ht

theorem ico_ne_zero (t : ℝ) (v : Fin 12) : ico t v ≠ 0 := by
  intro h
  have h0 := congrFun h 0
  have h1 := congrFun h 1
  have h2 := congrFun h 2
  fin_cases v <;> simp [ico] at h0 h1 h2

/-- `ico t` has planar vertex stars whenever `t² = t + 1`: the neighbours of `v` lie on the
plane `ico t v ⬝ x = t`. -/
theorem ico_planarStars (t : ℝ) (ht : t ^ 2 = t + 1) : PlanarStars (ico t) :=
  fun v => ⟨ico t v, ico_ne_zero t v, t, ico_dot_adj t ht v⟩

theorem ico_injective (t : ℝ) (ht : t ^ 2 = t + 1) : Function.Injective (ico t) := by
  intro v w h
  have h0 := congrFun h 0
  have h1 := congrFun h 1
  have h2 := congrFun h 2
  fin_cases v <;> fin_cases w <;> simp [ico] at h0 h1 h2 ⊢ <;> nlinarith

/-- The regular icosahedron is a realization. -/
theorem isRealization_gold : IsRealization (ico goldenRatio) :=
  ⟨ico_injective _ goldenRatio_sq, ico_planarStars _ goldenRatio_sq⟩

/-- The Galois-conjugate (great-icosahedron) configuration is a realization. -/
theorem isRealization_goldConj : IsRealization (ico goldenConj) :=
  ⟨ico_injective _ goldenConj_sq, ico_planarStars _ goldenConj_sq⟩

/-! ## Invariance under projective transformations -/

theorem hom_proj {M : Matrix (Fin 4) (Fin 4) ℝ} {p : Pt} (hp : den M p ≠ 0) :
    hom (proj M p) = (den M p)⁻¹ • (M *ᵥ hom p) := by
  ext i
  fin_cases i <;> simp [hom, proj] <;> field_simp
  rfl

/-- **Projective invariance.** The image of a configuration with planar vertex stars under
any projective transformation which keeps all twelve points finite again has planar vertex
stars. (Affine maps are the special case with last row `(0,0,0,1)`.) -/
theorem planarStars_proj {M : Matrix (Fin 4) (Fin 4) ℝ} {X : Fin 12 → Pt}
    (hM : Admissible M X) (hX : PlanarStars X) : PlanarStars (proj M ∘ X) := by
  obtain ⟨hdet, hden⟩ := hM
  intro v
  obtain ⟨n, hn, c, hc⟩ := hX v
  set ℓ : Fin 4 → ℝ := ![n 0, n 1, n 2, -c] with hℓ
  have key : ∀ p : Pt, ℓ ⬝ᵥ hom p = n ⬝ᵥ p - c := by
    intro p; simp [hℓ, hom, dotProduct, Fin.sum_univ_succ]; ring
  set ℓ' := ℓ ᵥ* M⁻¹ with hℓ'
  have key' : ∀ p : Pt, den M p ≠ 0 →
      ℓ' ⬝ᵥ hom (proj M p) = (den M p)⁻¹ * (ℓ ⬝ᵥ hom p) := by
    intro p hp
    rw [hom_proj hp, dotProduct_smul, hℓ', ← dotProduct_mulVec, mulVec_mulVec,
      nonsing_inv_mul _ hdet, one_mulVec, smul_eq_mul]
  have key'' : ∀ q : Pt, ![ℓ' 0, ℓ' 1, ℓ' 2] ⬝ᵥ q = ℓ' ⬝ᵥ hom q - ℓ' 3 := by
    intro q; simp [hom, dotProduct, Fin.sum_univ_succ]; ring
  have hz : ∀ w, Adj v w → ℓ' ⬝ᵥ hom (proj M (X w)) = 0 := by
    intro w hw; rw [key' _ (hden w), key, hc w hw]; ring
  refine ⟨![ℓ' 0, ℓ' 1, ℓ' 2], ?_, -ℓ' 3, ?_⟩
  · intro h0
    obtain ⟨w, hw⟩ := exists_adj v
    have h3 : ℓ' 3 = 0 := by
      have := key'' (proj M (X w))
      rw [h0, zero_dotProduct, hz w hw] at this
      linarith
    have hℓ'0 : ℓ' = 0 := by
      ext i
      fin_cases i
      · simpa using congrFun h0 0
      · simpa using congrFun h0 1
      · simpa using congrFun h0 2
      · simpa using h3
    have hl : ℓ' ᵥ* M = ℓ := by
      rw [hℓ', vecMul_vecMul, nonsing_inv_mul _ hdet, vecMul_one]
    rw [hℓ'0, zero_vecMul] at hl
    apply hn
    ext i
    fin_cases i
    · simpa [hℓ] using (congrFun hl 0).symm
    · simpa [hℓ] using (congrFun hl 1).symm
    · simpa [hℓ] using (congrFun hl 2).symm
  · intro w hw
    simp only [Function.comp]
    rw [key'', hz w hw]
    ring

/-- Admissible projective maps are injective on the configuration. -/
theorem proj_injective {M : Matrix (Fin 4) (Fin 4) ℝ} {X : Fin 12 → Pt}
    (hM : Admissible M X) (hX : Function.Injective X) : Function.Injective (proj M ∘ X) := by
  obtain ⟨hdet, hden⟩ := hM
  intro i j hij
  apply hX
  have h1 : hom (proj M (X i)) = hom (proj M (X j)) := by simp only [Function.comp] at hij; rw [hij]
  rw [hom_proj (hden i), hom_proj (hden j)] at h1
  have h2 : M *ᵥ hom (X i) = (den M (X i) / den M (X j)) • (M *ᵥ hom (X j)) := by
    have := congrArg (fun x => den M (X i) • x) h1
    simp only [smul_smul, mul_inv_cancel₀ (hden i), one_smul] at this
    rw [this, div_eq_mul_inv]
  have h3 : hom (X i) = (den M (X i) / den M (X j)) • hom (X j) := by
    have := congrArg (fun x => M⁻¹ *ᵥ x) h2
    simp only [mulVec_mulVec, nonsing_inv_mul _ hdet, one_mulVec, mulVec_smul] at this
    exact this
  have h4 : den M (X i) / den M (X j) = 1 := by
    have := congrFun h3 3
    simpa [hom] using this.symm
  rw [h4, one_smul] at h3
  ext k
  fin_cases k
  · simpa [hom] using congrFun h3 0
  · simpa [hom] using congrFun h3 1
  · simpa [hom] using congrFun h3 2

/-- Realizations are carried to realizations by admissible projective maps. -/
theorem isRealization_proj {M : Matrix (Fin 4) (Fin 4) ℝ} {X : Fin 12 → Pt}
    (hM : Admissible M X) (hX : IsRealization X) : IsRealization (proj M ∘ X) :=
  ⟨proj_injective hM hX.1, planarStars_proj hM hX.2⟩

/-! ## A projective invariant: cross ratios of pencils of planes -/

theorem D_proj (M : Matrix (Fin 4) (Fin 4) ℝ) {p q r s : Pt} (hp : den M p ≠ 0)
    (hq : den M q ≠ 0) (hr : den M r ≠ 0) (hs : den M s ≠ 0) :
    D (proj M p) (proj M q) (proj M r) (proj M s) =
      M.det * D p q r s / (den M p * den M q * den M r * den M s) := by
  have h : Matrix.of ![hom (proj M p), hom (proj M q), hom (proj M r), hom (proj M s)] =
      Matrix.of (fun i j => (![(den M p)⁻¹, (den M q)⁻¹, (den M r)⁻¹, (den M s)⁻¹] i) *
        ((Matrix.of ![hom p, hom q, hom r, hom s]) * Mᵀ) i j) := by
    ext i j
    fin_cases i <;>
      simp [hom_proj hp, hom_proj hq, hom_proj hr, hom_proj hs, Matrix.mul_apply, mulVec,
        dotProduct, mul_comm]
  rw [D, h, det_mul_column, det_mul, det_transpose, D]
  simp [Fin.prod_univ_four]
  field_simp

theorem cr_proj (M : Matrix (Fin 4) (Fin 4) ℝ) (hM : IsUnit M.det) {p a b c d e : Pt}
    (hp : den M p ≠ 0) (ha : den M a ≠ 0) (hb : den M b ≠ 0) (hc : den M c ≠ 0)
    (hd : den M d ≠ 0) (he : den M e ≠ 0) :
    cr (proj M p) (proj M a) (proj M b) (proj M c) (proj M d) (proj M e) = cr p a b c d e := by
  have hdet : M.det ≠ 0 := hM.ne_zero
  unfold cr
  rw [D_proj M hp ha hb hd, D_proj M hp ha hc he, D_proj M hp ha hc hd, D_proj M hp ha hb he]
  set K : ℝ := M.det ^ 2 / ((den M p) ^ 2 * (den M a) ^ 2 * den M b * den M c * den M d *
    den M e) with hK
  have hK0 : K ≠ 0 := by rw [hK]; positivity
  have e1 : M.det * D p a b d / (den M p * den M a * den M b * den M d) *
      (M.det * D p a c e / (den M p * den M a * den M c * den M e)) =
      K * (D p a b d * D p a c e) := by rw [hK]; field_simp
  have e2 : M.det * D p a c d / (den M p * den M a * den M c * den M d) *
      (M.det * D p a b e / (den M p * den M a * den M b * den M e)) =
      K * (D p a c d * D p a b e) := by rw [hK]; field_simp
  rw [e1, e2, mul_div_mul_left _ _ hK0]

/-- The cross ratio attached to vertex `0` and the cyclically ordered neighbours
`1, 2, 6, 5, 7` of `0`: the pencil of planes through the line `X 0 X 1`. -/
def crossRatioAt0 (X : Fin 12 → Pt) : ℝ := cr (X 0) (X 1) (X 2) (X 6) (X 5) (X 7)

theorem crossRatioAt0_proj {M : Matrix (Fin 4) (Fin 4) ℝ} {X : Fin 12 → Pt}
    (hM : Admissible M X) : crossRatioAt0 (proj M ∘ X) = crossRatioAt0 X :=
  cr_proj M hM.1 (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _)

/-- Labelled projective equivalence preserves `crossRatioAt0`. -/
theorem ProjEquiv.crossRatioAt0_eq {X Y : Fin 12 → Pt} (h : ProjEquiv X Y) :
    crossRatioAt0 Y = crossRatioAt0 X := by
  obtain ⟨M, hM, rfl⟩ := h
  exact crossRatioAt0_proj hM

theorem crossRatioAt0_ico (t : ℝ) (ht : t ^ 2 = t + 1) : crossRatioAt0 (ico t) = t := by
  have ht0 : t ≠ 0 := by rintro rfl; norm_num at ht
  have e1 : D (ico t 0) (ico t 1) (ico t 2) (ico t 5) = -4 * t := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (-2 * t) * ht
  have e2 : D (ico t 0) (ico t 1) (ico t 6) (ico t 7) = -4 * t := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    ring
  have e3 : D (ico t 0) (ico t 1) (ico t 6) (ico t 5) = -4 * t := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (-2 : ℝ) * ht
  have e4 : D (ico t 0) (ico t 1) (ico t 2) (ico t 7) = -4 := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (-2 : ℝ) * ht
  rw [crossRatioAt0, cr, e1, e2, e3, e4]
  field_simp

/-- **Two projectively distinct realizations.** The regular icosahedron and the
Galois-conjugate (great icosahedron) realization are not projectively equivalent
(as labelled configurations): their cross ratios at vertex `0` are `φ` and `ψ`. -/
theorem not_projEquiv_gold_goldConj : ¬ ProjEquiv (ico goldenRatio) (ico goldenConj) := by
  intro h
  have := h.crossRatioAt0_eq
  rw [crossRatioAt0_ico _ goldenRatio_sq, crossRatioAt0_ico _ goldenConj_sq] at this
  have h2 := goldenConj_neg
  have h3 := goldenRatio_pos
  linarith

set_option maxHeartbeats 4000000 in
/-- The golden realizations are non-degenerate: no closed vertex star is flat. -/
theorem ico_nonflatStars (t : ℝ) (ht : t ^ 2 = t + 1) : NonflatStars (ico t) := by
  intro v n c hn h hv
  apply hn
  have h' : ∀ w ∈ nbrs v, n ⬝ᵥ ico t w = c := fun w hw => h w hw
  fin_cases v <;>
  · simp [nbrs, ico, dotProduct, Fin.sum_univ_three] at h' hv
    obtain ⟨e1, e2, e3, e4, e5⟩ := h'
    have a0 : n 0 = 0 := by nlinarith
    have a1 : n 1 = 0 := by nlinarith
    have a2 : n 2 = 0 := by nlinarith
    ext i; fin_cases i <;> simp [a0, a1, a2]

/-- Labelled projective equivalence preserves every cross ratio `cr`. -/
theorem ProjEquiv.cr_eq {X Y : Fin 12 → Pt} (h : ProjEquiv X Y) (i j k l m o : Fin 12) :
    cr (Y i) (Y j) (Y k) (Y l) (Y m) (Y o) = cr (X i) (X j) (X k) (X l) (X m) (X o) := by
  obtain ⟨M, hM, rfl⟩ := h
  exact cr_proj M hM.1 (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _) (hM.2 _)

/-! ## Degenerate solutions: why a non-degeneracy assumption is needed -/

/-- Any twelve points lying in one plane trivially satisfy the condition
(a 24-parameter family of distinct-point "solutions"). -/
theorem planarStars_of_coplanar (X : Fin 12 → Pt) (n : Pt) (hn : n ≠ 0) (c : ℝ)
    (h : ∀ i, n ⬝ᵥ X i = c) : PlanarStars X :=
  fun _ => ⟨n, hn, c, fun w _ => h w⟩

/-- A one-parameter family of *non-coplanar* realizations with flat vertex stars:
vertex `0` is lifted to height `1`, the other eleven points lie in the plane `z = 0`
(the lower ring is the "inner pentagon" of diagonal intersections of the upper ring),
and vertex `9` moves freely along the line `y = 200`. -/
def flat (s : ℝ) : Fin 12 → Pt :=
  ![![0, 0, 1], ![0, 0, 0], ![66, 0, 0], ![12, 36, 0], ![54, 36, 0], ![33, 99, 0],
    ![99, 66, 0], ![-33, 66, 0], ![33, 22, 0], ![s, 200, 0], ![44, 66, 0], ![22, 66, 0]]

/-- Normals of the star planes of `flat s`. -/
def flatN : Fin 12 → Pt :=
  ![![0, 0, 1], ![2, 3, 132], ![2, -3, 0], ![0, 0, 1], ![0, 0, 1], ![0, 1, 66],
    ![3, 1, 198], ![3, -1, 0], ![0, 0, 1], ![0, 0, 1], ![0, 0, 1], ![0, 0, 1]]

/-- Right-hand sides of the star planes of `flat s`. -/
def flatC : Fin 12 → ℝ := ![0, 132, 0, 0, 0, 66, 198, 0, 0, 0, 0, 0]

theorem flat_isRealization (s : ℝ) : IsRealization (flat s) := by
  constructor
  · intro v w h
    have h0 := congrFun h 0
    have h1 := congrFun h 1
    have h2 := congrFun h 2
    fin_cases v <;> fin_cases w <;> simp [flat] at h0 h1 h2 ⊢ <;> linarith
  · intro v
    refine ⟨flatN v, ?_, flatC v, ?_⟩
    · intro h0
      have e0 := congrFun h0 0
      have e2 := congrFun h0 2
      fin_cases v <;> simp [flatN] at e0 e2
    · intro w hw
      fin_cases v <;> fin_cases w <;>
        simp [Adj, nbrs, flat, flatN, flatC, dotProduct, Fin.sum_univ_three] at hw ⊢ <;> norm_num

/-- The family `flat s` is not contained in a plane. -/
theorem flat_not_coplanar (s : ℝ) :
    ¬ ∃ n : Pt, n ≠ 0 ∧ ∃ c : ℝ, ∀ i, n ⬝ᵥ flat s i = c := by
  rintro ⟨n, hn, c, h⟩
  have e0 := h 0
  have e1 := h 1
  have e2 := h 2
  have e3 := h 3
  simp [flat, dotProduct, Fin.sum_univ_three] at e0 e1 e2 e3
  apply hn
  ext i
  fin_cases i <;> simp <;> linarith

/-- … but it violates non-degeneracy: the star of vertex `9` is flat. -/
theorem flat_not_nonflatStars (s : ℝ) : ¬ NonflatStars (flat s) := by
  intro h
  apply h 9 ![0, 0, 1] 0 (by intro h0; simpa using congrFun h0 2)
  · intro w hw
    fin_cases w <;> simp [Adj, nbrs, flat, dotProduct, Fin.sum_univ_three] at hw ⊢
  · simp [flat, dotProduct, Fin.sum_univ_three]

theorem cr_flat (s : ℝ) :
    cr (flat s 0) (flat s 1) (flat s 2) (flat s 6) (flat s 5) (flat s 9) =
      6534 * (19800 - 66 * s) / (7623 * 13200) := by
  unfold cr
  simp [D, hom, flat, Matrix.det_succ_row_zero, Fin.sum_univ_succ, Fin.succAbove]
  ring

/-- **A continuous family of pairwise projectively inequivalent degenerate realizations.**
Distinct parameters give configurations that are not (labelled) projectively equivalent. -/
theorem flat_not_projEquiv {s s' : ℝ} (hs : s ≠ s') : ¬ ProjEquiv (flat s) (flat s') := by
  intro h
  have := h.cr_eq 0 1 2 6 5 9
  rw [cr_flat, cr_flat] at this
  apply hs
  field_simp at this
  linarith

/-! ## Projective versus affine equivalence -/

/-- Labelled affine equivalence (projective maps whose last row is `(0,0,0,1)`). -/
def AffEquiv (X Y : Fin 12 → Pt) : Prop :=
  ∃ M : Matrix (Fin 4) (Fin 4) ℝ, M 3 = ![0, 0, 0, 1] ∧ IsUnit M.det ∧ proj M ∘ X = Y

theorem den_of_affine {M : Matrix (Fin 4) (Fin 4) ℝ} (h : M 3 = ![0, 0, 0, 1]) (p : Pt) :
    den M p = 1 := by
  simp [den, mulVec, h, hom, dotProduct, Fin.sum_univ_succ]

/-- Ratios of tetrahedral volumes are affine invariants. -/
theorem AffEquiv.D_ratio_eq {X Y : Fin 12 → Pt} (h : AffEquiv X Y) (a b c d e f g k : Fin 12) :
    D (Y a) (Y b) (Y c) (Y d) / D (Y e) (Y f) (Y g) (Y k) =
      D (X a) (X b) (X c) (X d) / D (X e) (X f) (X g) (X k) := by
  obtain ⟨M, hM3, hdet, rfl⟩ := h
  have h1 : ∀ p, den M p ≠ 0 := fun p => by rw [den_of_affine hM3]; norm_num
  simp only [Function.comp]
  rw [D_proj M (h1 _) (h1 _) (h1 _) (h1 _), D_proj M (h1 _) (h1 _) (h1 _) (h1 _)]
  simp only [den_of_affine hM3, mul_one, div_one]
  exact mul_div_mul_left _ _ hdet.ne_zero

/-- The perspectivity `(x, y, z) ↦ (x, y, z) / (1 + k z)`. -/
def persp (k : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  !![1, 0, 0, 0; 0, 1, 0, 0; 0, 0, 1, 0; 0, 0, k, 1]

theorem den_persp (k : ℝ) (p : Pt) : den (persp k) p = k * p 2 + 1 := by
  simp [den, persp, mulVec, hom, dotProduct, Fin.sum_univ_succ]

theorem admissible_persp_ico {k : ℝ} (hk : |k| < 1 / 2) :
    Admissible (persp k) (ico goldenRatio) := by
  refine ⟨by simp [persp, Matrix.det_succ_row_zero, Fin.sum_univ_succ], fun i => ?_⟩
  rw [den_persp]
  have h1 := goldenRatio_lt_two
  have h2 := goldenRatio_pos
  have hk' := abs_lt.mp hk
  fin_cases i <;> simp [ico] <;> nlinarith

/-- A one-parameter family of perspective images of the regular icosahedron. -/
def perspIco (k : ℝ) : Fin 12 → Pt := proj (persp k) ∘ ico goldenRatio

theorem perspIco_isRealization {k : ℝ} (hk : |k| < 1 / 2) : IsRealization (perspIco k) :=
  isRealization_proj (admissible_persp_ico hk) isRealization_gold

theorem perspIco_ratio {k : ℝ} (hk : |k| < 1 / 2) :
    D (perspIco k 0) (perspIco k 1) (perspIco k 2) (perspIco k 5) /
      D (perspIco k 0) (perspIco k 1) (perspIco k 2) (perspIco k 7) = goldenRatio / (1 + k) := by
  have hA := admissible_persp_ico hk
  have h1 := goldenRatio_lt_two
  have h2 := goldenRatio_pos
  have hk' := abs_lt.mp hk
  have ht := goldenRatio_sq
  simp only [perspIco, Function.comp]
  rw [D_proj _ (hA.2 _) (hA.2 _) (hA.2 _) (hA.2 _), D_proj _ (hA.2 _) (hA.2 _) (hA.2 _) (hA.2 _)]
  have e1 : D (ico goldenRatio 0) (ico goldenRatio 1) (ico goldenRatio 2) (ico goldenRatio 5) =
      -4 * goldenRatio := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (-2 * goldenRatio) * ht
  have e2 : D (ico goldenRatio 0) (ico goldenRatio 1) (ico goldenRatio 2) (ico goldenRatio 7) =
      -4 := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (-2 : ℝ) * ht
  rw [e1, e2]
  simp only [den_persp]
  have hdet : (persp k).det = 1 := by simp [persp, Matrix.det_succ_row_zero, Fin.sum_univ_succ]
  rw [hdet]
  have hk1 : 1 + k ≠ 0 := by intro h; linarith
  have hk2 : k * goldenRatio + 1 ≠ 0 := by intro h; nlinarith
  generalize goldenRatio = t at *
  simp [ico]
  field_simp
  have hne : (t * k + 1) * (k + 1) ≠ 0 :=
    mul_ne_zero (by rwa [mul_comm]) (by rwa [add_comm])
  rw [div_eq_one_iff_eq hne]
  ring

/-- **Projective deformations are genuinely more than affine ones:** distinct members of the
perspective family `perspIco k` are realizations which are pairwise *not* affinely
equivalent. -/
theorem perspIco_not_affEquiv {k k' : ℝ} (hk : |k| < 1 / 2) (hk' : |k'| < 1 / 2)
    (hne : k ≠ k') : ¬ AffEquiv (perspIco k) (perspIco k') := by
  intro h
  have := h.D_ratio_eq 0 1 2 5 0 1 2 7
  rw [perspIco_ratio hk, perspIco_ratio hk'] at this
  have h2 := goldenRatio_pos
  have a := abs_lt.mp hk
  have b := abs_lt.mp hk'
  have hk1 : 1 + k ≠ 0 := by intro h; linarith
  have hk2 : 1 + k' ≠ 0 := by intro h; linarith
  field_simp at this
  apply hne
  nlinarith

end PlanarStarIcosahedron
