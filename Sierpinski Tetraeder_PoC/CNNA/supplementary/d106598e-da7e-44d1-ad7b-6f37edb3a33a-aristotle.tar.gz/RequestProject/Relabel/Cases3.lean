module
public import RequestProject.PlanarStars

/-!
# Cross ratios of `ico t` at oriented vertex links, part 3

Machine-generated case computations: at each oriented flag the cross ratio equals `t`.
-/

@[expose] public section
noncomputable section

open Matrix

namespace PlanarStarIcosahedron

theorem cr_ico_90 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 3) (ico t 8) (ico t 4) (ico t 10) (ico t 11) = t := by
  have h0 : D (ico t 9) (ico t 3) (ico t 8) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 9) (ico t 3) (ico t 4) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 9) (ico t 3) (ico t 4) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 9) (ico t 3) (ico t 8) (ico t 11) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_91 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 3) (ico t 11) (ico t 10) (ico t 4) (ico t 8) = t := by
  have h0 : D (ico t 9) (ico t 3) (ico t 11) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 9) (ico t 3) (ico t 10) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 9) (ico t 3) (ico t 10) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 9) (ico t 3) (ico t 11) (ico t 8) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_92 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 4) (ico t 8) (ico t 3) (ico t 11) (ico t 10) = t := by
  have h0 : D (ico t 9) (ico t 4) (ico t 8) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 9) (ico t 4) (ico t 3) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 9) (ico t 4) (ico t 3) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 9) (ico t 4) (ico t 8) (ico t 10) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_93 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 4) (ico t 10) (ico t 11) (ico t 3) (ico t 8) = t := by
  have h0 : D (ico t 9) (ico t 4) (ico t 10) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 9) (ico t 4) (ico t 11) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 9) (ico t 4) (ico t 11) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 9) (ico t 4) (ico t 10) (ico t 8) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_94 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 8) (ico t 3) (ico t 11) (ico t 10) (ico t 4) = t := by
  have h0 : D (ico t 9) (ico t 8) (ico t 3) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 9) (ico t 8) (ico t 11) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 9) (ico t 8) (ico t 11) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 9) (ico t 8) (ico t 3) (ico t 4) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_95 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 8) (ico t 4) (ico t 10) (ico t 11) (ico t 3) = t := by
  have h0 : D (ico t 9) (ico t 8) (ico t 4) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 9) (ico t 8) (ico t 10) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 9) (ico t 8) (ico t 10) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 9) (ico t 8) (ico t 4) (ico t 3) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_96 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 10) (ico t 4) (ico t 8) (ico t 3) (ico t 11) = t := by
  have h0 : D (ico t 9) (ico t 10) (ico t 4) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 9) (ico t 10) (ico t 8) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 9) (ico t 10) (ico t 8) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 9) (ico t 10) (ico t 4) (ico t 11) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_97 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 10) (ico t 11) (ico t 3) (ico t 8) (ico t 4) = t := by
  have h0 : D (ico t 9) (ico t 10) (ico t 11) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 9) (ico t 10) (ico t 3) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 9) (ico t 10) (ico t 3) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 9) (ico t 10) (ico t 11) (ico t 4) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_98 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 11) (ico t 3) (ico t 8) (ico t 4) (ico t 10) = t := by
  have h0 : D (ico t 9) (ico t 11) (ico t 3) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 9) (ico t 11) (ico t 8) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 9) (ico t 11) (ico t 8) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 9) (ico t 11) (ico t 3) (ico t 10) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_99 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 9) (ico t 11) (ico t 10) (ico t 4) (ico t 8) (ico t 3) = t := by
  have h0 : D (ico t 9) (ico t 11) (ico t 10) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 9) (ico t 11) (ico t 4) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 9) (ico t 11) (ico t 4) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 9) (ico t 11) (ico t 10) (ico t 3) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_100 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 4) (ico t 6) (ico t 5) (ico t 11) (ico t 9) = t := by
  have h0 : D (ico t 10) (ico t 4) (ico t 6) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 10) (ico t 4) (ico t 5) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 10) (ico t 4) (ico t 5) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 10) (ico t 4) (ico t 6) (ico t 9) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_101 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 4) (ico t 9) (ico t 11) (ico t 5) (ico t 6) = t := by
  have h0 : D (ico t 10) (ico t 4) (ico t 9) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 10) (ico t 4) (ico t 11) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 10) (ico t 4) (ico t 11) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 10) (ico t 4) (ico t 9) (ico t 6) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_102 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 5) (ico t 6) (ico t 4) (ico t 9) (ico t 11) = t := by
  have h0 : D (ico t 10) (ico t 5) (ico t 6) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 10) (ico t 5) (ico t 4) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 10) (ico t 5) (ico t 4) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 10) (ico t 5) (ico t 6) (ico t 11) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_103 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 5) (ico t 11) (ico t 9) (ico t 4) (ico t 6) = t := by
  have h0 : D (ico t 10) (ico t 5) (ico t 11) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 10) (ico t 5) (ico t 9) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 10) (ico t 5) (ico t 9) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 10) (ico t 5) (ico t 11) (ico t 6) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_104 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 6) (ico t 4) (ico t 9) (ico t 11) (ico t 5) = t := by
  have h0 : D (ico t 10) (ico t 6) (ico t 4) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 10) (ico t 6) (ico t 9) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 10) (ico t 6) (ico t 9) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 10) (ico t 6) (ico t 4) (ico t 5) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_105 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 6) (ico t 5) (ico t 11) (ico t 9) (ico t 4) = t := by
  have h0 : D (ico t 10) (ico t 6) (ico t 5) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 10) (ico t 6) (ico t 11) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 10) (ico t 6) (ico t 11) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 10) (ico t 6) (ico t 5) (ico t 4) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_106 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 9) (ico t 4) (ico t 6) (ico t 5) (ico t 11) = t := by
  have h0 : D (ico t 10) (ico t 9) (ico t 4) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 10) (ico t 9) (ico t 6) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 10) (ico t 9) (ico t 6) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 10) (ico t 9) (ico t 4) (ico t 11) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_107 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 9) (ico t 11) (ico t 5) (ico t 6) (ico t 4) = t := by
  have h0 : D (ico t 10) (ico t 9) (ico t 11) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 10) (ico t 9) (ico t 5) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 10) (ico t 9) (ico t 5) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 10) (ico t 9) (ico t 11) (ico t 4) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_108 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 11) (ico t 5) (ico t 6) (ico t 4) (ico t 9) = t := by
  have h0 : D (ico t 10) (ico t 11) (ico t 5) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 10) (ico t 11) (ico t 6) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 10) (ico t 11) (ico t 6) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 10) (ico t 11) (ico t 5) (ico t 9) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_109 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 10) (ico t 11) (ico t 9) (ico t 4) (ico t 6) (ico t 5) = t := by
  have h0 : D (ico t 10) (ico t 11) (ico t 9) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 10) (ico t 11) (ico t 4) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 10) (ico t 11) (ico t 4) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 10) (ico t 11) (ico t 9) (ico t 5) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_110 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 3) (ico t 7) (ico t 5) (ico t 10) (ico t 9) = t := by
  have h0 : D (ico t 11) (ico t 3) (ico t 7) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 11) (ico t 3) (ico t 5) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 11) (ico t 3) (ico t 5) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 11) (ico t 3) (ico t 7) (ico t 9) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_111 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 3) (ico t 9) (ico t 10) (ico t 5) (ico t 7) = t := by
  have h0 : D (ico t 11) (ico t 3) (ico t 9) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 11) (ico t 3) (ico t 10) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 11) (ico t 3) (ico t 10) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 11) (ico t 3) (ico t 9) (ico t 7) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_112 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 5) (ico t 7) (ico t 3) (ico t 9) (ico t 10) = t := by
  have h0 : D (ico t 11) (ico t 5) (ico t 7) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 11) (ico t 5) (ico t 3) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 11) (ico t 5) (ico t 3) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 11) (ico t 5) (ico t 7) (ico t 10) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_113 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 5) (ico t 10) (ico t 9) (ico t 3) (ico t 7) = t := by
  have h0 : D (ico t 11) (ico t 5) (ico t 10) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 11) (ico t 5) (ico t 9) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 11) (ico t 5) (ico t 9) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 11) (ico t 5) (ico t 10) (ico t 7) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_114 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 7) (ico t 3) (ico t 9) (ico t 10) (ico t 5) = t := by
  have h0 : D (ico t 11) (ico t 7) (ico t 3) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 11) (ico t 7) (ico t 9) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 11) (ico t 7) (ico t 9) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 11) (ico t 7) (ico t 3) (ico t 5) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_115 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 7) (ico t 5) (ico t 10) (ico t 9) (ico t 3) = t := by
  have h0 : D (ico t 11) (ico t 7) (ico t 5) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 11) (ico t 7) (ico t 10) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 11) (ico t 7) (ico t 10) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 11) (ico t 7) (ico t 5) (ico t 3) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_116 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 9) (ico t 3) (ico t 7) (ico t 5) (ico t 10) = t := by
  have h0 : D (ico t 11) (ico t 9) (ico t 3) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 11) (ico t 9) (ico t 7) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 11) (ico t 9) (ico t 7) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 11) (ico t 9) (ico t 3) (ico t 10) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_117 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 9) (ico t 10) (ico t 5) (ico t 7) (ico t 3) = t := by
  have h0 : D (ico t 11) (ico t 9) (ico t 10) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 11) (ico t 9) (ico t 5) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 11) (ico t 9) (ico t 5) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 11) (ico t 9) (ico t 10) (ico t 3) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_118 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 10) (ico t 5) (ico t 7) (ico t 3) (ico t 9) = t := by
  have h0 : D (ico t 11) (ico t 10) (ico t 5) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 11) (ico t 10) (ico t 7) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 11) (ico t 10) (ico t 7) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 11) (ico t 10) (ico t 5) (ico t 9) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_119 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 11) (ico t 10) (ico t 9) (ico t 3) (ico t 7) (ico t 5) = t := by
  have h0 : D (ico t 11) (ico t 10) (ico t 9) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 11) (ico t 10) (ico t 3) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 11) (ico t 10) (ico t 3) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 11) (ico t 10) (ico t 9) (ico t 5) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

end PlanarStarIcosahedron
