module
public import RequestProject.PlanarStars

/-!
# Cross ratios of `ico t` at oriented vertex links, part 2

Machine-generated case computations: at each oriented flag the cross ratio equals `t`.
-/

@[expose] public section
noncomputable section

open Matrix

namespace PlanarStarIcosahedron

theorem cr_ico_60 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 0) (ico t 2) (ico t 4) (ico t 10) (ico t 5) = t := by
  have h0 : D (ico t 6) (ico t 0) (ico t 2) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 6) (ico t 0) (ico t 4) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 6) (ico t 0) (ico t 4) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 6) (ico t 0) (ico t 2) (ico t 5) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_61 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 0) (ico t 5) (ico t 10) (ico t 4) (ico t 2) = t := by
  have h0 : D (ico t 6) (ico t 0) (ico t 5) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 6) (ico t 0) (ico t 10) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 6) (ico t 0) (ico t 10) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 6) (ico t 0) (ico t 5) (ico t 2) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_62 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 2) (ico t 0) (ico t 5) (ico t 10) (ico t 4) = t := by
  have h0 : D (ico t 6) (ico t 2) (ico t 0) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 6) (ico t 2) (ico t 5) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 6) (ico t 2) (ico t 5) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 6) (ico t 2) (ico t 0) (ico t 4) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_63 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 2) (ico t 4) (ico t 10) (ico t 5) (ico t 0) = t := by
  have h0 : D (ico t 6) (ico t 2) (ico t 4) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 6) (ico t 2) (ico t 10) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 6) (ico t 2) (ico t 10) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 6) (ico t 2) (ico t 4) (ico t 0) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_64 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 4) (ico t 2) (ico t 0) (ico t 5) (ico t 10) = t := by
  have h0 : D (ico t 6) (ico t 4) (ico t 2) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 6) (ico t 4) (ico t 0) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 6) (ico t 4) (ico t 0) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 6) (ico t 4) (ico t 2) (ico t 10) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_65 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 4) (ico t 10) (ico t 5) (ico t 0) (ico t 2) = t := by
  have h0 : D (ico t 6) (ico t 4) (ico t 10) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 6) (ico t 4) (ico t 5) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 6) (ico t 4) (ico t 5) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 6) (ico t 4) (ico t 10) (ico t 2) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_66 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 5) (ico t 0) (ico t 2) (ico t 4) (ico t 10) = t := by
  have h0 : D (ico t 6) (ico t 5) (ico t 0) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 6) (ico t 5) (ico t 2) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 6) (ico t 5) (ico t 2) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 6) (ico t 5) (ico t 0) (ico t 10) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_67 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 5) (ico t 10) (ico t 4) (ico t 2) (ico t 0) = t := by
  have h0 : D (ico t 6) (ico t 5) (ico t 10) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 6) (ico t 5) (ico t 4) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 6) (ico t 5) (ico t 4) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 6) (ico t 5) (ico t 10) (ico t 0) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_68 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 10) (ico t 4) (ico t 2) (ico t 0) (ico t 5) = t := by
  have h0 : D (ico t 6) (ico t 10) (ico t 4) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 6) (ico t 10) (ico t 2) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 6) (ico t 10) (ico t 2) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 6) (ico t 10) (ico t 4) (ico t 5) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_69 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 6) (ico t 10) (ico t 5) (ico t 0) (ico t 2) (ico t 4) = t := by
  have h0 : D (ico t 6) (ico t 10) (ico t 5) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 6) (ico t 10) (ico t 0) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 6) (ico t 10) (ico t 0) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 6) (ico t 10) (ico t 5) (ico t 4) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_70 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 0) (ico t 1) (ico t 3) (ico t 11) (ico t 5) = t := by
  have h0 : D (ico t 7) (ico t 0) (ico t 1) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 7) (ico t 0) (ico t 3) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 7) (ico t 0) (ico t 3) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 7) (ico t 0) (ico t 1) (ico t 5) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_71 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 0) (ico t 5) (ico t 11) (ico t 3) (ico t 1) = t := by
  have h0 : D (ico t 7) (ico t 0) (ico t 5) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 7) (ico t 0) (ico t 11) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 7) (ico t 0) (ico t 11) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 7) (ico t 0) (ico t 5) (ico t 1) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_72 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 1) (ico t 0) (ico t 5) (ico t 11) (ico t 3) = t := by
  have h0 : D (ico t 7) (ico t 1) (ico t 0) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 7) (ico t 1) (ico t 5) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 7) (ico t 1) (ico t 5) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 7) (ico t 1) (ico t 0) (ico t 3) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_73 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 1) (ico t 3) (ico t 11) (ico t 5) (ico t 0) = t := by
  have h0 : D (ico t 7) (ico t 1) (ico t 3) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 7) (ico t 1) (ico t 11) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 7) (ico t 1) (ico t 11) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 7) (ico t 1) (ico t 3) (ico t 0) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_74 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 3) (ico t 1) (ico t 0) (ico t 5) (ico t 11) = t := by
  have h0 : D (ico t 7) (ico t 3) (ico t 1) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 7) (ico t 3) (ico t 0) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 7) (ico t 3) (ico t 0) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 7) (ico t 3) (ico t 1) (ico t 11) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_75 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 3) (ico t 11) (ico t 5) (ico t 0) (ico t 1) = t := by
  have h0 : D (ico t 7) (ico t 3) (ico t 11) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 7) (ico t 3) (ico t 5) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 7) (ico t 3) (ico t 5) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 7) (ico t 3) (ico t 11) (ico t 1) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_76 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 5) (ico t 0) (ico t 1) (ico t 3) (ico t 11) = t := by
  have h0 : D (ico t 7) (ico t 5) (ico t 0) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 7) (ico t 5) (ico t 1) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 7) (ico t 5) (ico t 1) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 7) (ico t 5) (ico t 0) (ico t 11) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_77 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 5) (ico t 11) (ico t 3) (ico t 1) (ico t 0) = t := by
  have h0 : D (ico t 7) (ico t 5) (ico t 11) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 7) (ico t 5) (ico t 3) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 7) (ico t 5) (ico t 3) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 7) (ico t 5) (ico t 11) (ico t 0) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_78 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 11) (ico t 3) (ico t 1) (ico t 0) (ico t 5) = t := by
  have h0 : D (ico t 7) (ico t 11) (ico t 3) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 7) (ico t 11) (ico t 1) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 7) (ico t 11) (ico t 1) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 7) (ico t 11) (ico t 3) (ico t 5) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_79 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 7) (ico t 11) (ico t 5) (ico t 0) (ico t 1) (ico t 3) = t := by
  have h0 : D (ico t 7) (ico t 11) (ico t 5) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 7) (ico t 11) (ico t 0) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 7) (ico t 11) (ico t 0) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 7) (ico t 11) (ico t 5) (ico t 3) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_80 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 1) (ico t 2) (ico t 4) (ico t 9) (ico t 3) = t := by
  have h0 : D (ico t 8) (ico t 1) (ico t 2) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 8) (ico t 1) (ico t 4) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 8) (ico t 1) (ico t 4) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 8) (ico t 1) (ico t 2) (ico t 3) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_81 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 1) (ico t 3) (ico t 9) (ico t 4) (ico t 2) = t := by
  have h0 : D (ico t 8) (ico t 1) (ico t 3) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 8) (ico t 1) (ico t 9) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 8) (ico t 1) (ico t 9) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 8) (ico t 1) (ico t 3) (ico t 2) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_82 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 2) (ico t 1) (ico t 3) (ico t 9) (ico t 4) = t := by
  have h0 : D (ico t 8) (ico t 2) (ico t 1) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 8) (ico t 2) (ico t 3) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 8) (ico t 2) (ico t 3) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 8) (ico t 2) (ico t 1) (ico t 4) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_83 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 2) (ico t 4) (ico t 9) (ico t 3) (ico t 1) = t := by
  have h0 : D (ico t 8) (ico t 2) (ico t 4) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 8) (ico t 2) (ico t 9) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 8) (ico t 2) (ico t 9) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 8) (ico t 2) (ico t 4) (ico t 1) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_84 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 3) (ico t 1) (ico t 2) (ico t 4) (ico t 9) = t := by
  have h0 : D (ico t 8) (ico t 3) (ico t 1) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 8) (ico t 3) (ico t 2) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 8) (ico t 3) (ico t 2) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 8) (ico t 3) (ico t 1) (ico t 9) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_85 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 3) (ico t 9) (ico t 4) (ico t 2) (ico t 1) = t := by
  have h0 : D (ico t 8) (ico t 3) (ico t 9) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 8) (ico t 3) (ico t 4) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 8) (ico t 3) (ico t 4) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 8) (ico t 3) (ico t 9) (ico t 1) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_86 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 4) (ico t 2) (ico t 1) (ico t 3) (ico t 9) = t := by
  have h0 : D (ico t 8) (ico t 4) (ico t 2) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 8) (ico t 4) (ico t 1) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 8) (ico t 4) (ico t 1) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 8) (ico t 4) (ico t 2) (ico t 9) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_87 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 4) (ico t 9) (ico t 3) (ico t 1) (ico t 2) = t := by
  have h0 : D (ico t 8) (ico t 4) (ico t 9) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 8) (ico t 4) (ico t 3) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 8) (ico t 4) (ico t 3) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 8) (ico t 4) (ico t 9) (ico t 2) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_88 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 9) (ico t 3) (ico t 1) (ico t 2) (ico t 4) = t := by
  have h0 : D (ico t 8) (ico t 9) (ico t 3) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 8) (ico t 9) (ico t 1) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 8) (ico t 9) (ico t 1) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 8) (ico t 9) (ico t 3) (ico t 4) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_89 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 8) (ico t 9) (ico t 4) (ico t 2) (ico t 1) (ico t 3) = t := by
  have h0 : D (ico t 8) (ico t 9) (ico t 4) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 8) (ico t 9) (ico t 2) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 8) (ico t 9) (ico t 2) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 8) (ico t 9) (ico t 4) (ico t 3) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

end PlanarStarIcosahedron
