module
public import RequestProject.PlanarStars

/-!
# Cross ratios of `ico t` at oriented vertex links, part 0

Machine-generated case computations: at each oriented flag the cross ratio equals `t`.
-/

@[expose] public section
noncomputable section

open Matrix

namespace PlanarStarIcosahedron

theorem cr_ico_0 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 1) (ico t 2) (ico t 6) (ico t 5) (ico t 7) = t := by
  have h0 : D (ico t 0) (ico t 1) (ico t 2) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 0) (ico t 1) (ico t 6) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 0) (ico t 1) (ico t 6) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 0) (ico t 1) (ico t 2) (ico t 7) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_1 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 1) (ico t 7) (ico t 5) (ico t 6) (ico t 2) = t := by
  have h0 : D (ico t 0) (ico t 1) (ico t 7) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 0) (ico t 1) (ico t 5) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 0) (ico t 1) (ico t 5) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 0) (ico t 1) (ico t 7) (ico t 2) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_2 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 2) (ico t 1) (ico t 7) (ico t 5) (ico t 6) = t := by
  have h0 : D (ico t 0) (ico t 2) (ico t 1) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 0) (ico t 2) (ico t 7) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 0) (ico t 2) (ico t 7) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 0) (ico t 2) (ico t 1) (ico t 6) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_3 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 2) (ico t 6) (ico t 5) (ico t 7) (ico t 1) = t := by
  have h0 : D (ico t 0) (ico t 2) (ico t 6) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 0) (ico t 2) (ico t 5) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 0) (ico t 2) (ico t 5) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 0) (ico t 2) (ico t 6) (ico t 1) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_4 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 5) (ico t 6) (ico t 2) (ico t 1) (ico t 7) = t := by
  have h0 : D (ico t 0) (ico t 5) (ico t 6) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 0) (ico t 5) (ico t 2) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 0) (ico t 5) (ico t 2) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 0) (ico t 5) (ico t 6) (ico t 7) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_5 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 5) (ico t 7) (ico t 1) (ico t 2) (ico t 6) = t := by
  have h0 : D (ico t 0) (ico t 5) (ico t 7) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 0) (ico t 5) (ico t 1) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 0) (ico t 5) (ico t 1) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 0) (ico t 5) (ico t 7) (ico t 6) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_6 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 6) (ico t 2) (ico t 1) (ico t 7) (ico t 5) = t := by
  have h0 : D (ico t 0) (ico t 6) (ico t 2) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 0) (ico t 6) (ico t 1) (ico t 5) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 0) (ico t 6) (ico t 1) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 0) (ico t 6) (ico t 2) (ico t 5) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_7 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 6) (ico t 5) (ico t 7) (ico t 1) (ico t 2) = t := by
  have h0 : D (ico t 0) (ico t 6) (ico t 5) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 0) (ico t 6) (ico t 7) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 0) (ico t 6) (ico t 7) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 0) (ico t 6) (ico t 5) (ico t 2) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_8 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 7) (ico t 1) (ico t 2) (ico t 6) (ico t 5) = t := by
  have h0 : D (ico t 0) (ico t 7) (ico t 1) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 0) (ico t 7) (ico t 2) (ico t 5) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 0) (ico t 7) (ico t 2) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 0) (ico t 7) (ico t 1) (ico t 5) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_9 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 0) (ico t 7) (ico t 5) (ico t 6) (ico t 2) (ico t 1) = t := by
  have h0 : D (ico t 0) (ico t 7) (ico t 5) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 0) (ico t 7) (ico t 6) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 0) (ico t 7) (ico t 6) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 0) (ico t 7) (ico t 5) (ico t 1) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_10 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 0) (ico t 2) (ico t 8) (ico t 3) (ico t 7) = t := by
  have h0 : D (ico t 1) (ico t 0) (ico t 2) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 1) (ico t 0) (ico t 8) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 1) (ico t 0) (ico t 8) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 1) (ico t 0) (ico t 2) (ico t 7) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_11 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 0) (ico t 7) (ico t 3) (ico t 8) (ico t 2) = t := by
  have h0 : D (ico t 1) (ico t 0) (ico t 7) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 1) (ico t 0) (ico t 3) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 1) (ico t 0) (ico t 3) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 1) (ico t 0) (ico t 7) (ico t 2) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_12 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 2) (ico t 0) (ico t 7) (ico t 3) (ico t 8) = t := by
  have h0 : D (ico t 1) (ico t 2) (ico t 0) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 1) (ico t 2) (ico t 7) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 1) (ico t 2) (ico t 7) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 1) (ico t 2) (ico t 0) (ico t 8) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_13 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 2) (ico t 8) (ico t 3) (ico t 7) (ico t 0) = t := by
  have h0 : D (ico t 1) (ico t 2) (ico t 8) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 1) (ico t 2) (ico t 3) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 1) (ico t 2) (ico t 3) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 1) (ico t 2) (ico t 8) (ico t 0) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_14 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 3) (ico t 7) (ico t 0) (ico t 2) (ico t 8) = t := by
  have h0 : D (ico t 1) (ico t 3) (ico t 7) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 1) (ico t 3) (ico t 0) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 1) (ico t 3) (ico t 0) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 1) (ico t 3) (ico t 7) (ico t 8) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_15 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 3) (ico t 8) (ico t 2) (ico t 0) (ico t 7) = t := by
  have h0 : D (ico t 1) (ico t 3) (ico t 8) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 1) (ico t 3) (ico t 2) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 1) (ico t 3) (ico t 2) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 1) (ico t 3) (ico t 8) (ico t 7) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_16 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 7) (ico t 0) (ico t 2) (ico t 8) (ico t 3) = t := by
  have h0 : D (ico t 1) (ico t 7) (ico t 0) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 1) (ico t 7) (ico t 2) (ico t 3) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 1) (ico t 7) (ico t 2) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 1) (ico t 7) (ico t 0) (ico t 3) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_17 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 7) (ico t 3) (ico t 8) (ico t 2) (ico t 0) = t := by
  have h0 : D (ico t 1) (ico t 7) (ico t 3) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 1) (ico t 7) (ico t 8) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 1) (ico t 7) (ico t 8) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 1) (ico t 7) (ico t 3) (ico t 0) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_18 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 8) (ico t 2) (ico t 0) (ico t 7) (ico t 3) = t := by
  have h0 : D (ico t 1) (ico t 8) (ico t 2) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 1) (ico t 8) (ico t 0) (ico t 3) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 1) (ico t 8) (ico t 0) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 1) (ico t 8) (ico t 2) (ico t 3) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_19 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 1) (ico t 8) (ico t 3) (ico t 7) (ico t 0) (ico t 2) = t := by
  have h0 : D (ico t 1) (ico t 8) (ico t 3) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 1) (ico t 8) (ico t 7) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 1) (ico t 8) (ico t 7) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 1) (ico t 8) (ico t 3) (ico t 2) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_20 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 0) (ico t 1) (ico t 8) (ico t 4) (ico t 6) = t := by
  have h0 : D (ico t 2) (ico t 0) (ico t 1) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 2) (ico t 0) (ico t 8) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 2) (ico t 0) (ico t 8) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 2) (ico t 0) (ico t 1) (ico t 6) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_21 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 0) (ico t 6) (ico t 4) (ico t 8) (ico t 1) = t := by
  have h0 : D (ico t 2) (ico t 0) (ico t 6) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 2) (ico t 0) (ico t 4) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 2) (ico t 0) (ico t 4) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 2) (ico t 0) (ico t 6) (ico t 1) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_22 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 1) (ico t 0) (ico t 6) (ico t 4) (ico t 8) = t := by
  have h0 : D (ico t 2) (ico t 1) (ico t 0) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 2) (ico t 1) (ico t 6) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 2) (ico t 1) (ico t 6) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 2) (ico t 1) (ico t 0) (ico t 8) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_23 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 1) (ico t 8) (ico t 4) (ico t 6) (ico t 0) = t := by
  have h0 : D (ico t 2) (ico t 1) (ico t 8) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 2) (ico t 1) (ico t 4) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 2) (ico t 1) (ico t 4) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 2) (ico t 1) (ico t 8) (ico t 0) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_24 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 4) (ico t 6) (ico t 0) (ico t 1) (ico t 8) = t := by
  have h0 : D (ico t 2) (ico t 4) (ico t 6) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 2) (ico t 4) (ico t 0) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 2) (ico t 4) (ico t 0) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 2) (ico t 4) (ico t 6) (ico t 8) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_25 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 4) (ico t 8) (ico t 1) (ico t 0) (ico t 6) = t := by
  have h0 : D (ico t 2) (ico t 4) (ico t 8) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 2) (ico t 4) (ico t 1) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 2) (ico t 4) (ico t 1) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 2) (ico t 4) (ico t 8) (ico t 6) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_26 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 6) (ico t 0) (ico t 1) (ico t 8) (ico t 4) = t := by
  have h0 : D (ico t 2) (ico t 6) (ico t 0) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 2) (ico t 6) (ico t 1) (ico t 4) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 2) (ico t 6) (ico t 1) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 2) (ico t 6) (ico t 0) (ico t 4) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_27 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 6) (ico t 4) (ico t 8) (ico t 1) (ico t 0) = t := by
  have h0 : D (ico t 2) (ico t 6) (ico t 4) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 2) (ico t 6) (ico t 8) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 2) (ico t 6) (ico t 8) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 2) (ico t 6) (ico t 4) (ico t 0) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_28 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 8) (ico t 1) (ico t 0) (ico t 6) (ico t 4) = t := by
  have h0 : D (ico t 2) (ico t 8) (ico t 1) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 2) (ico t 8) (ico t 0) (ico t 4) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 2) (ico t 8) (ico t 0) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 2) (ico t 8) (ico t 1) (ico t 4) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_29 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 2) (ico t 8) (ico t 4) (ico t 6) (ico t 0) (ico t 1) = t := by
  have h0 : D (ico t 2) (ico t 8) (ico t 4) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 2) (ico t 8) (ico t 6) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 2) (ico t 8) (ico t 6) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 2) (ico t 8) (ico t 4) (ico t 1) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

end PlanarStarIcosahedron
