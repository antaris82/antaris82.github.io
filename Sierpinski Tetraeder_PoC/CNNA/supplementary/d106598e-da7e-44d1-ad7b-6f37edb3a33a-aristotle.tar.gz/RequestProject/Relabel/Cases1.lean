module
public import RequestProject.PlanarStars

/-!
# Cross ratios of `ico t` at oriented vertex links, part 1

Machine-generated case computations: at each oriented flag the cross ratio equals `t`.
-/

@[expose] public section
noncomputable section

open Matrix

namespace PlanarStarIcosahedron

theorem cr_ico_30 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 1) (ico t 7) (ico t 11) (ico t 9) (ico t 8) = t := by
  have h0 : D (ico t 3) (ico t 1) (ico t 7) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 3) (ico t 1) (ico t 11) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 3) (ico t 1) (ico t 11) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 3) (ico t 1) (ico t 7) (ico t 8) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_31 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 1) (ico t 8) (ico t 9) (ico t 11) (ico t 7) = t := by
  have h0 : D (ico t 3) (ico t 1) (ico t 8) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 3) (ico t 1) (ico t 9) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 3) (ico t 1) (ico t 9) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 3) (ico t 1) (ico t 8) (ico t 7) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_32 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 7) (ico t 1) (ico t 8) (ico t 9) (ico t 11) = t := by
  have h0 : D (ico t 3) (ico t 7) (ico t 1) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 3) (ico t 7) (ico t 8) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 3) (ico t 7) (ico t 8) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 3) (ico t 7) (ico t 1) (ico t 11) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_33 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 7) (ico t 11) (ico t 9) (ico t 8) (ico t 1) = t := by
  have h0 : D (ico t 3) (ico t 7) (ico t 11) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 3) (ico t 7) (ico t 9) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 3) (ico t 7) (ico t 9) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 3) (ico t 7) (ico t 11) (ico t 1) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_34 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 8) (ico t 1) (ico t 7) (ico t 11) (ico t 9) = t := by
  have h0 : D (ico t 3) (ico t 8) (ico t 1) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 3) (ico t 8) (ico t 7) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 3) (ico t 8) (ico t 7) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 3) (ico t 8) (ico t 1) (ico t 9) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_35 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 8) (ico t 9) (ico t 11) (ico t 7) (ico t 1) = t := by
  have h0 : D (ico t 3) (ico t 8) (ico t 9) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 3) (ico t 8) (ico t 11) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 3) (ico t 8) (ico t 11) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 3) (ico t 8) (ico t 9) (ico t 1) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_36 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 9) (ico t 8) (ico t 1) (ico t 7) (ico t 11) = t := by
  have h0 : D (ico t 3) (ico t 9) (ico t 8) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 3) (ico t 9) (ico t 1) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 3) (ico t 9) (ico t 1) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 3) (ico t 9) (ico t 8) (ico t 11) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_37 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 9) (ico t 11) (ico t 7) (ico t 1) (ico t 8) = t := by
  have h0 : D (ico t 3) (ico t 9) (ico t 11) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 3) (ico t 9) (ico t 7) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 3) (ico t 9) (ico t 7) (ico t 1) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 3) (ico t 9) (ico t 11) (ico t 8) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_38 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 11) (ico t 7) (ico t 1) (ico t 8) (ico t 9) = t := by
  have h0 : D (ico t 3) (ico t 11) (ico t 7) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 3) (ico t 11) (ico t 1) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 3) (ico t 11) (ico t 1) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 3) (ico t 11) (ico t 7) (ico t 9) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_39 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 3) (ico t 11) (ico t 9) (ico t 8) (ico t 1) (ico t 7) = t := by
  have h0 : D (ico t 3) (ico t 11) (ico t 9) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 3) (ico t 11) (ico t 8) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 3) (ico t 11) (ico t 8) (ico t 1) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 3) (ico t 11) (ico t 9) (ico t 7) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_40 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 2) (ico t 6) (ico t 10) (ico t 9) (ico t 8) = t := by
  have h0 : D (ico t 4) (ico t 2) (ico t 6) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 4) (ico t 2) (ico t 10) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 4) (ico t 2) (ico t 10) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 4) (ico t 2) (ico t 6) (ico t 8) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_41 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 2) (ico t 8) (ico t 9) (ico t 10) (ico t 6) = t := by
  have h0 : D (ico t 4) (ico t 2) (ico t 8) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 4) (ico t 2) (ico t 9) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 4) (ico t 2) (ico t 9) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 4) (ico t 2) (ico t 8) (ico t 6) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_42 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 6) (ico t 2) (ico t 8) (ico t 9) (ico t 10) = t := by
  have h0 : D (ico t 4) (ico t 6) (ico t 2) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 4) (ico t 6) (ico t 8) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 4) (ico t 6) (ico t 8) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 4) (ico t 6) (ico t 2) (ico t 10) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_43 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 6) (ico t 10) (ico t 9) (ico t 8) (ico t 2) = t := by
  have h0 : D (ico t 4) (ico t 6) (ico t 10) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 4) (ico t 6) (ico t 9) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 4) (ico t 6) (ico t 9) (ico t 8) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 4) (ico t 6) (ico t 10) (ico t 2) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_44 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 8) (ico t 2) (ico t 6) (ico t 10) (ico t 9) = t := by
  have h0 : D (ico t 4) (ico t 8) (ico t 2) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 4) (ico t 8) (ico t 6) (ico t 9) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 4) (ico t 8) (ico t 6) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 4) (ico t 8) (ico t 2) (ico t 9) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_45 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 8) (ico t 9) (ico t 10) (ico t 6) (ico t 2) = t := by
  have h0 : D (ico t 4) (ico t 8) (ico t 9) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 4) (ico t 8) (ico t 10) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 4) (ico t 8) (ico t 10) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 4) (ico t 8) (ico t 9) (ico t 2) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_46 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 9) (ico t 8) (ico t 2) (ico t 6) (ico t 10) = t := by
  have h0 : D (ico t 4) (ico t 9) (ico t 8) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 4) (ico t 9) (ico t 2) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 4) (ico t 9) (ico t 2) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 4) (ico t 9) (ico t 8) (ico t 10) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_47 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 9) (ico t 10) (ico t 6) (ico t 2) (ico t 8) = t := by
  have h0 : D (ico t 4) (ico t 9) (ico t 10) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 4) (ico t 9) (ico t 6) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 4) (ico t 9) (ico t 6) (ico t 2) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 4) (ico t 9) (ico t 10) (ico t 8) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_48 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 10) (ico t 6) (ico t 2) (ico t 8) (ico t 9) = t := by
  have h0 : D (ico t 4) (ico t 10) (ico t 6) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 4) (ico t 10) (ico t 2) (ico t 9) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 4) (ico t 10) (ico t 2) (ico t 8) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 4) (ico t 10) (ico t 6) (ico t 9) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_49 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 4) (ico t 10) (ico t 9) (ico t 8) (ico t 2) (ico t 6) = t := by
  have h0 : D (ico t 4) (ico t 10) (ico t 9) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 4) (ico t 10) (ico t 8) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 4) (ico t 10) (ico t 8) (ico t 2) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 4) (ico t 10) (ico t 9) (ico t 6) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_50 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 0) (ico t 6) (ico t 10) (ico t 11) (ico t 7) = t := by
  have h0 : D (ico t 5) (ico t 0) (ico t 6) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 5) (ico t 0) (ico t 10) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 5) (ico t 0) (ico t 10) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 5) (ico t 0) (ico t 6) (ico t 7) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_51 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 0) (ico t 7) (ico t 11) (ico t 10) (ico t 6) = t := by
  have h0 : D (ico t 5) (ico t 0) (ico t 7) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 5) (ico t 0) (ico t 11) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 5) (ico t 0) (ico t 11) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 5) (ico t 0) (ico t 7) (ico t 6) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_52 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 6) (ico t 0) (ico t 7) (ico t 11) (ico t 10) = t := by
  have h0 : D (ico t 5) (ico t 6) (ico t 0) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h1 : D (ico t 5) (ico t 6) (ico t 7) (ico t 10) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 5) (ico t 6) (ico t 7) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h3 : D (ico t 5) (ico t 6) (ico t 0) (ico t 10) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_53 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 6) (ico t 10) (ico t 11) (ico t 7) (ico t 0) = t := by
  have h0 : D (ico t 5) (ico t 6) (ico t 10) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 5) (ico t 6) (ico t 11) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h2 : D (ico t 5) (ico t 6) (ico t 11) (ico t 7) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h3 : D (ico t 5) (ico t 6) (ico t 10) (ico t 0) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_54 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 7) (ico t 0) (ico t 6) (ico t 10) (ico t 11) = t := by
  have h0 : D (ico t 5) (ico t 7) (ico t 0) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h1 : D (ico t 5) (ico t 7) (ico t 6) (ico t 11) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 5) (ico t 7) (ico t 6) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 5) (ico t 7) (ico t 0) (ico t 11) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_55 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 7) (ico t 11) (ico t 10) (ico t 6) (ico t 0) = t := by
  have h0 : D (ico t 5) (ico t 7) (ico t 11) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 5) (ico t 7) (ico t 10) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h2 : D (ico t 5) (ico t 7) (ico t 10) (ico t 6) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 5) (ico t 7) (ico t 11) (ico t 0) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_56 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 10) (ico t 6) (ico t 0) (ico t 7) (ico t 11) = t := by
  have h0 : D (ico t 5) (ico t 10) (ico t 6) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h1 : D (ico t 5) (ico t 10) (ico t 0) (ico t 11) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 5) (ico t 10) (ico t 0) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)*t) * ht
  have h3 : D (ico t 5) (ico t 10) (ico t 6) (ico t 11) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_57 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 10) (ico t 11) (ico t 7) (ico t 0) (ico t 6) = t := by
  have h0 : D (ico t 5) (ico t 10) (ico t 11) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 5) (ico t 10) (ico t 7) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h2 : D (ico t 5) (ico t 10) (ico t 7) (ico t 0) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)*t) * ht
  have h3 : D (ico t 5) (ico t 10) (ico t 11) (ico t 6) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_58 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 11) (ico t 7) (ico t 0) (ico t 6) (ico t 10) = t := by
  have h0 : D (ico t 5) (ico t 11) (ico t 7) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h1 : D (ico t 5) (ico t 11) (ico t 0) (ico t 10) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-2:ℝ)) * ht
  have h2 : D (ico t 5) (ico t 11) (ico t 0) (ico t 6) = ((0:ℝ) + (-4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 5) (ico t 11) (ico t 7) (ico t 10) = ((-4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((-4:ℝ)) * ht
  have n2 : ((0:ℝ) + (-4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(-4:ℝ) - (-4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (-4:ℝ) - (-4:ℝ)*t) * h + (-4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((-4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((-4:ℝ)^2 + (-4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((-4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

theorem cr_ico_59 (t : ℝ) (ht : t ^ 2 = t + 1) :
    cr (ico t 5) (ico t 11) (ico t 10) (ico t 6) (ico t 0) (ico t 7) = t := by
  have h0 : D (ico t 5) (ico t 11) (ico t 10) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h1 : D (ico t 5) (ico t 11) (ico t 6) (ico t 7) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((2:ℝ)) * ht
  have h2 : D (ico t 5) (ico t 11) (ico t 6) (ico t 0) = ((0:ℝ) + (4:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination (0) * ht
  have h3 : D (ico t 5) (ico t 11) (ico t 10) (ico t 7) = ((4:ℝ) + (0:ℝ)*t) := by
    rw [D, Matrix.det_succ_row_zero]
    simp [hom, ico, Fin.sum_univ_succ, Matrix.det_fin_three, Fin.succAbove]
    linear_combination ((4:ℝ)) * ht
  have n2 : ((0:ℝ) + (4:ℝ)*t) ≠ 0 := by
    intro h
    have : ((0:ℝ)^2 + (0:ℝ)*(4:ℝ) - (4:ℝ)^2) = 0 := by
      linear_combination ((0:ℝ) + (4:ℝ) - (4:ℝ)*t) * h + (4:ℝ)^2 * ht
    norm_num at this
  have n3 : ((4:ℝ) + (0:ℝ)*t) ≠ 0 := by
    intro h
    have : ((4:ℝ)^2 + (4:ℝ)*(0:ℝ) - (0:ℝ)^2) = 0 := by
      linear_combination ((4:ℝ) + (0:ℝ) - (0:ℝ)*t) * h + (0:ℝ)^2 * ht
    norm_num at this
  rw [cr, h0, h1, h2, h3, div_eq_iff (mul_ne_zero n2 n3)]
  linear_combination (0) * ht

end PlanarStarIcosahedron
