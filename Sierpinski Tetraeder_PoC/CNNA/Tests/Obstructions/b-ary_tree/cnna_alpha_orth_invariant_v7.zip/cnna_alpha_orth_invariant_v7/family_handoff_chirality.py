#!/usr/bin/env python3
"""
Family handoff chirality diagnostic.

This script corrects the single-graph limitation of the V4 test.

V4 tested that one passive self-adjoint DtN graph p = Lambda q is Lagrangian:
    q^T Lambda r - r^T Lambda q = 0.

V5 tests a small family of real symmetric DtN graphs, connected by canonical
sign-free handoffs.

Tests:
1. Cross-graph Cauchy pairing:
       omega_ij(q,r) = q^T Lambda_j r - r^T Lambda_i q.
2. Sibling permutation behavior:
       a nonzero signal must flip under sibling permutation to count as chiral.
3. Handoff square / holonomy:
       compare A->B_i->C and A->B_j->C using sign-free handoff maps.

No complex input, no epsilon regularization, no pseudoinverse, no least-squares.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path


def finite_tail_conductance(b: int, depth: int) -> float:
    if depth <= 0:
        return 0.0
    c = float(b)
    for _ in range(2, depth + 1):
        c = b * c / (1.0 + c)
    return c


def radial_core_conductance(b: int, k: int) -> float:
    if k <= 0:
        raise ValueError("k must be positive")
    return (b - 1.0) / (1.0 - b ** (-k))


def environment_ladder(depth: int, b: int, env_depth: int) -> float:
    if depth <= 0 or env_depth <= 0:
        return 0.0
    side_tail = finite_tail_conductance(b, env_depth - 1) if env_depth > 1 else 0.0
    side_shunt = (b - 1) * side_tail
    g = side_shunt
    for _ in range(1, depth):
        through_parent = g / (1.0 + g) if g > 0.0 else 0.0
        g = side_shunt + through_parent
    return g / (1.0 + g) if g > 0.0 else 0.0


def env_alpha(depth: int, b: int, env_depth: int, mode: str, child_index: int = 0) -> float:
    if mode == "ladder":
        return environment_ladder(depth, b, env_depth)
    if mode == "none":
        return 0.0
    if mode == "depth_linear":
        return float(depth)
    if mode == "sibling_index":
        # Diagnostic countermodel: breaks sibling symmetry by label.
        # Not canonical for an unordered b-ary tree.
        return 1.0 + float(child_index)
    raise ValueError(f"unknown env mode: {mode}")


def lambda_matrix(b: int, k: int, depth: int, uv_tail_depth: int, env_depth: int, env_mode: str, child_index: int = 0):
    C = radial_core_conductance(b, k)
    a_uv = finite_tail_conductance(b, uv_tail_depth)
    a_env = env_alpha(depth, b, env_depth, env_mode, child_index)
    cut = b ** k
    return [
        [C + a_env, -C],
        [-C, C + cut * a_uv],
    ]


def mat_sub(A, B):
    return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]


def mat_mul(A, B):
    return [[sum(A[i][t] * B[t][j] for t in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]


def det2(A):
    return A[0][0] * A[1][1] - A[0][1] * A[1][0]


def frob(A):
    return math.sqrt(sum(x*x for row in A for x in row))


def sign(x: float, tol: float = 1e-10) -> int:
    if x > tol:
        return 1
    if x < -tol:
        return -1
    return 0


def omega_cross(Li, Lj, q, r):
    left = sum(q[a] * Lj[a][b] * r[b] for a in range(2) for b in range(2))
    right = sum(r[a] * Li[a][b] * q[b] for a in range(2) for b in range(2))
    return left - right


def omega_matrix(Li, Lj):
    e = [[1.0, 0.0], [0.0, 1.0]]
    return [[omega_cross(Li, Lj, e[a], e[b]) for b in range(2)] for a in range(2)]


def canonical_handoff(L_from, L_to):
    """Sign-free positive diagonal normalization handoff."""
    h0 = math.sqrt(max(L_from[0][0], 0.0) / max(L_to[0][0], 1e-300))
    h1 = math.sqrt(max(L_from[1][1], 0.0) / max(L_to[1][1], 1e-300))
    return [[h0, 0.0], [0.0, h1]]


@dataclass(frozen=True)
class GraphSpec:
    label: str
    child_index: int
    depth: int
    k: int
    lambda00: float
    lambda01: float
    lambda10: float
    lambda11: float


@dataclass(frozen=True)
class PairResult:
    i: int
    j: int
    omega_env_uv: float
    omega_uv_env: float
    omega_det: float
    omega_frob: float
    omega_sign_env_uv: int
    reversed_order_sign: int
    sibling_flip_candidate: bool
    diagnosis: str


@dataclass(frozen=True)
class SquareResult:
    i: int
    j: int
    commutator_norm: float
    commutator_sign: int
    diagnosis: str


def graph_spec(b: int, k: int, depth: int, uv_tail_depth: int, env_depth: int, env_mode: str, child_index: int):
    L = lambda_matrix(b, k, depth, uv_tail_depth, env_depth, env_mode, child_index)
    return GraphSpec(
        label=f"child_{child_index}",
        child_index=child_index,
        depth=depth,
        k=k,
        lambda00=L[0][0],
        lambda01=L[0][1],
        lambda10=L[1][0],
        lambda11=L[1][1],
    ), L


def pair_result(i: int, j: int, Li, Lj):
    W = omega_matrix(Li, Lj)
    Wr = omega_matrix(Lj, Li)
    env_uv = W[0][1]
    uv_env = W[1][0]
    rev = Wr[0][1]
    s = sign(env_uv)
    rs = sign(rev)
    flip = s != 0 and s == -rs
    norm = frob(W)

    if norm == 0.0:
        diag = "zero: identical or graph-pairing cancels"
    elif flip:
        # This is only a candidate. For sibling_index it is label-induced.
        diag = "flip_candidate_under_reversal"
    else:
        diag = "nonzero_but_not_chiral: no sibling/reversal flip"

    return PairResult(
        i=i,
        j=j,
        omega_env_uv=env_uv,
        omega_uv_env=uv_env,
        omega_det=det2(W),
        omega_frob=norm,
        omega_sign_env_uv=s,
        reversed_order_sign=rs,
        sibling_flip_candidate=flip,
        diagnosis=diag,
    )


def square_result(i: int, j: int, LA, LBi, LBj, LC):
    HAi = canonical_handoff(LA, LBi)
    HAj = canonical_handoff(LA, LBj)
    HiC = canonical_handoff(LBi, LC)
    HjC = canonical_handoff(LBj, LC)
    path_i = mat_mul(HiC, HAi)
    path_j = mat_mul(HjC, HAj)
    K = mat_sub(path_i, path_j)
    n = frob(K)
    marker = K[0][0] if abs(K[0][0]) >= abs(K[1][1]) else K[1][1]
    return SquareResult(
        i=i,
        j=j,
        commutator_norm=n,
        commutator_sign=sign(marker),
        diagnosis="noncommuting_holonomy_candidate" if n > 1e-10 else "zero_commutator: canonical sign-free handoffs commute",
    )


def run_family(b: int, k: int, parent_depth: int, child_depth: int, common_depth: int, uv_tail_depth: int, env_depth: int, env_mode: str):
    parent_spec, LA = graph_spec(b, k, parent_depth, uv_tail_depth, env_depth, env_mode, -1)

    graphs = []
    mats = []
    for child in range(b):
        spec, L = graph_spec(b, k, child_depth, uv_tail_depth, env_depth, env_mode, child)
        graphs.append(spec)
        mats.append(L)

    pairs = []
    # Parent-child cross-graph pairings: tests that we are no longer only
    # examining one isolated DtN graph. These can be nonzero because parent
    # and child depths/environment loads differ. Nonzero here is not yet
    # chirality; it is family metric difference.
    for i in range(b):
        pairs.append(pair_result(-1, i, LA, mats[i]))

    # Sibling-sibling cross-graph pairings: this is the actual permutation
    # test. For a symmetric unit-edge b-ary tree these should vanish or remain
    # nonchiral unless sibling symmetry is explicitly broken.
    for i in range(b):
        for j in range(b):
            if i != j:
                pairs.append(pair_result(i, j, mats[i], mats[j]))

    common_spec, LC = graph_spec(b, k, common_depth, uv_tail_depth, env_depth, env_mode, 0)
    squares = []
    for i in range(b):
        for j in range(i + 1, b):
            squares.append(square_result(i, j, LA, mats[i], mats[j], LC))

    nonzero_pairs = [p for p in pairs if p.omega_frob > 1e-10]
    flip_detected = any(p.sibling_flip_candidate for p in pairs)
    holonomy_detected = any(s.commutator_norm > 1e-10 for s in squares)

    if env_mode == "sibling_index":
        caveat = "WARNING: sibling_index breaks sibling symmetry by label; any positive signal is noncanonical."
    else:
        caveat = ""

    if not nonzero_pairs and not holonomy_detected:
        status = "achiral_negative: no cross-graph signal and no handoff holonomy"
    elif (flip_detected or holonomy_detected) and env_mode != "sibling_index":
        status = "chiral_candidate: canonical family test produced flip or holonomy"
    elif env_mode == "sibling_index":
        status = "label_induced_positive_control: detector sees noncanonical sibling-label asymmetry"
    else:
        status = "family_difference_only: cross-graph signal exists but no accepted chirality"

    return {
        "input": {
            "b": b,
            "k": k,
            "parent_depth": parent_depth,
            "child_depth": child_depth,
            "common_depth": common_depth,
            "uv_tail_depth": uv_tail_depth,
            "env_depth": env_depth,
            "env_mode": env_mode,
        },
        "parent_graph": asdict(parent_spec),
        "child_graphs": [asdict(g) for g in graphs],
        "cross_graph_pairings": [asdict(p) for p in pairs],
        "handoff_square_tests": [asdict(s) for s in squares],
        "summary": {
            "status": status,
            "nonzero_pair_count": len(nonzero_pairs),
            "sibling_flip_detected": flip_detected,
            "handoff_holonomy_detected": holonomy_detected,
            "caveat": caveat,
        },
        "interpretation": {
            "what_is_tested": "family of symmetric DtN graphs plus canonical sign-free handoffs",
            "positive_requirement": "signal must flip under sibling permutation or appear as noncommuting handoff holonomy",
            "negative_meaning": "the tested family is radial/achiral; this does not rule out richer complement-family structures",
        },
    }


def write_outputs(payload, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "family_handoff_chirality.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    with (outdir / "cross_graph_pairings.csv").open("w", newline="", encoding="utf-8") as f:
        rows = payload["cross_graph_pairings"]
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    with (outdir / "handoff_square_tests.csv").open("w", newline="", encoding="utf-8") as f:
        rows = payload["handoff_square_tests"]
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=3)
    ap.add_argument("--k", type=int, default=4)
    ap.add_argument("--parent-depth", type=int, default=1)
    ap.add_argument("--child-depth", type=int, default=2)
    ap.add_argument("--common-depth", type=int, default=3)
    ap.add_argument("--uv-tail-depth", type=int, default=2)
    ap.add_argument("--env-depth", type=int, default=2)
    ap.add_argument("--env-mode", choices=["ladder", "none", "depth_linear", "sibling_index"], default="ladder")
    ap.add_argument("--outdir", type=str, default="")
    args = ap.parse_args()

    payload = run_family(
        b=args.b,
        k=args.k,
        parent_depth=args.parent_depth,
        child_depth=args.child_depth,
        common_depth=args.common_depth,
        uv_tail_depth=args.uv_tail_depth,
        env_depth=args.env_depth,
        env_mode=args.env_mode,
    )

    if args.outdir:
        write_outputs(payload, Path(args.outdir))

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
