#!/usr/bin/env python3
"""
Two-boundary shell chirality diagnostic for the CNNA minimal b-ary tree tests.

Purpose
-------
This script adds the next diagnostic layer beyond passive one-approximant
conductance and the radial parent->child flow sign.

It tests whether a parent-child *difference shell* can generate an
antisymmetric Cauchy/handoff signal from real Schur/DtN data.

The diagnostic implements:

1. Parent-child difference shell:
   Build a finite shell connecting an outer parent port and one or more
   inner child ports. Compute its two-boundary DtN matrix Lambda_delta.

2. Cauchy boundary form:
   For boundary data x=(q,p), y=(q',p'), compute
      omega(x,y) = q^T p' - p^T q'.
   If both x and y lie on the same self-adjoint DtN graph p=Lambda q,
   omega is identically zero. This is expected: the graph is Lagrangian.
   Therefore a nonzero chirality signal cannot come from one passive
   symmetric DtN graph alone.

3. Sibling comparison:
   Repeat the shell test for all children of the parent. A true chiral
   signal should change sign under an appropriate sibling permutation.
   If the sign remains invariant, the result is radial/achiral.

4. Handoff commutator:
   Construct simple canonical shell transfer maps from outer excitation
   to inner child responses. Test [H_i,H_j]. For a symmetric unit-edge
   b-ary tree, this is expected to vanish or be rank-trivially achiral.

Interpretation
--------------
This is a falsification-oriented diagnostic. A negative result is useful:
it says that the pure symmetric unit-edge ToC plus passive Schur/DtN flows
does not yet contain the antisymmetric structure needed to fix J versus -J.

No complex input, no epsilon regularization, no pseudoinverse, no
least-squares fallback.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path


def add_edge(L, i: int, j: int, w: float = 1.0) -> None:
    L[i][i] += w
    L[j][j] += w
    L[i][j] -= w
    L[j][i] -= w


def matmul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]


def transpose(A):
    return [list(row) for row in zip(*A)]


def submatrix(A, rows, cols):
    return [[A[i][j] for j in cols] for i in rows]


def solve_linear(A, B):
    """
    Solve A X = B by deterministic Gaussian elimination with partial pivoting.
    Raises if singular. No least-squares or pseudoinverse fallback.
    """
    n = len(A)
    m = len(B[0])
    aug = [list(A[i]) + list(B[i]) for i in range(n)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(aug[r][col]))
        if abs(aug[pivot][col]) < 1e-12:
            raise RuntimeError("singular shell interior block")
        if pivot != col:
            aug[col], aug[pivot] = aug[pivot], aug[col]
        piv = aug[col][col]
        for j in range(col, n + m):
            aug[col][j] /= piv
        for r in range(n):
            if r == col:
                continue
            factor = aug[r][col]
            if factor == 0.0:
                continue
            for j in range(col, n + m):
                aug[r][j] -= factor * aug[col][j]
    return [row[n:] for row in aug]


def schur_dtn(L, ports):
    n = len(L)
    pset = set(ports)
    interior = [i for i in range(n) if i not in pset]
    Lpp = submatrix(L, ports, ports)
    if not interior:
        return Lpp
    Lii = submatrix(L, interior, interior)
    Lip = submatrix(L, interior, ports)
    Lpi = submatrix(L, ports, interior)
    X = solve_linear(Lii, Lip)
    corr = matmul(Lpi, X)
    return [[Lpp[i][j] - corr[i][j] for j in range(len(ports))] for i in range(len(ports))]


def build_star_shell(b: int, child_index: int, side_ground_depth: int = 1):
    """
    Minimal parent-child difference shell.

    Ports:
      0 = outer parent port
      1 = selected inner child port

    The shell contains the unit edge parent--child and the sibling branches
    of the parent. Optional finite grounded tails attached to siblings make
    the shell load-sensitive while preserving sibling symmetry.

    This is intentionally canonical and sign-free.
    """
    if not (0 <= child_index < b):
        raise ValueError("child_index out of range")

    # Node ids: 0 parent port, 1 selected child port.
    next_id = 2
    edges = [(0, 1)]
    grounded = set()

    def add_grounded_tail(root_id: int, depth: int):
        nonlocal next_id, edges, grounded
        if depth <= 0:
            grounded.add(root_id)
            return
        for _ in range(b):
            c = next_id
            next_id += 1
            edges.append((root_id, c))
            add_grounded_tail(c, depth - 1)

    for i in range(b):
        if i == child_index:
            continue
        sib = next_id
        next_id += 1
        edges.append((0, sib))
        add_grounded_tail(sib, side_ground_depth)

    variable_nodes = [i for i in range(next_id) if i not in grounded]
    remap = {old: new for new, old in enumerate(variable_nodes)}
    L = [[0.0 for _ in variable_nodes] for _ in variable_nodes]
    for u, v in edges:
        u_var = u in remap
        v_var = v in remap
        if u_var and v_var:
            add_edge(L, remap[u], remap[v])
        elif u_var and v in grounded:
            L[remap[u]][remap[u]] += 1.0
        elif v_var and u in grounded:
            L[remap[v]][remap[v]] += 1.0

    ports = [remap[0], remap[1]]
    return L, ports


def cauchy_pairing(q, p, r, s):
    return sum(q[i] * s[i] - p[i] * r[i] for i in range(len(q)))


def apply(M, q):
    return [sum(M[i][j] * q[j] for j in range(len(q))) for i in range(len(M))]


def det2(M):
    return M[0][0] * M[1][1] - M[0][1] * M[1][0]


def sign(x: float, tol: float = 1e-10) -> int:
    if x > tol:
        return 1
    if x < -tol:
        return -1
    return 0


@dataclass(frozen=True)
class ShellRow:
    b: int
    child_index: int
    side_ground_depth: int
    lambda00: float
    lambda01: float
    lambda10: float
    lambda11: float
    flow_sign_outer_to_inner: int
    graph_omega_e0_e1: float
    graph_omega_sign: int
    dtn_det: float
    diagnosis: str


def shell_row(b: int, child_index: int, side_ground_depth: int) -> ShellRow:
    L, ports = build_star_shell(b, child_index, side_ground_depth)
    Lam = schur_dtn(L, ports)

    e0 = [1.0, 0.0]
    e1 = [0.0, 1.0]
    p0 = apply(Lam, e0)
    p1 = apply(Lam, e1)
    omega = cauchy_pairing(e0, p0, e1, p1)

    if sign(omega) == 0:
        diagnosis = "lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph"
    else:
        diagnosis = "nonzero_omega_candidate"

    return ShellRow(
        b=b,
        child_index=child_index,
        side_ground_depth=side_ground_depth,
        lambda00=Lam[0][0],
        lambda01=Lam[0][1],
        lambda10=Lam[1][0],
        lambda11=Lam[1][1],
        flow_sign_outer_to_inner=sign(Lam[0][1]),
        graph_omega_e0_e1=omega,
        graph_omega_sign=sign(omega),
        dtn_det=det2(Lam),
        diagnosis=diagnosis,
    )


@dataclass(frozen=True)
class SiblingSummary:
    b: int
    side_ground_depth: int
    flow_signs: str
    omega_signs: str
    sibling_permutation_flip: bool
    commutator_norm_max: float
    chirality_status: str


def sibling_summary(rows: list[ShellRow]) -> SiblingSummary:
    flow_signs = [r.flow_sign_outer_to_inner for r in rows]
    omega_signs = [r.graph_omega_sign for r in rows]

    # Transfer maps in this minimal shell are scalar response maps from outer
    # excitation to each child. Scalar maps commute; max commutator is zero.
    comm_norm = 0.0

    nonzero = [s for s in omega_signs if s != 0]
    flip = bool(nonzero) and (min(nonzero) < 0 < max(nonzero))

    if all(s == 0 for s in omega_signs):
        status = "achiral_negative: passive symmetric two-boundary shell gives no antisymmetric signal"
    elif flip:
        status = "chiral_candidate: sibling permutation flips omega sign"
    else:
        status = "radial_or_label_dependent: nonzero sign does not flip under siblings"

    return SiblingSummary(
        b=rows[0].b,
        side_ground_depth=rows[0].side_ground_depth,
        flow_signs=",".join(map(str, flow_signs)),
        omega_signs=",".join(map(str, omega_signs)),
        sibling_permutation_flip=flip,
        commutator_norm_max=comm_norm,
        chirality_status=status,
    )


def run(b: int, side_ground_depth: int):
    rows = [shell_row(b, i, side_ground_depth) for i in range(b)]
    summary = sibling_summary(rows)
    return rows, summary


def write_csv(rows, summary, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    shell_path = outdir / f"two_boundary_shell_rows_b{summary.b}_s{summary.side_ground_depth}.csv"
    with shell_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for r in rows:
            writer.writerow(asdict(r))

    summary_path = outdir / f"two_boundary_shell_summary_b{summary.b}_s{summary.side_ground_depth}.json"
    summary_path.write_text(json.dumps(asdict(summary), indent=2), encoding="utf-8")
    return shell_path, summary_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=3)
    ap.add_argument("--side-ground-depth", type=int, default=1)
    ap.add_argument("--outdir", type=str, default="")
    args = ap.parse_args()

    rows, summary = run(args.b, args.side_ground_depth)
    payload = {
        "rows": [asdict(r) for r in rows],
        "summary": asdict(summary),
        "interpretation": {
            "negative_result_meaning": (
                "For the symmetric unit-edge shell, the DtN matrix is self-adjoint. "
                "Cauchy pairing of two vectors on the same DtN graph vanishes. "
                "Thus no J sign is solved by this passive shell alone."
            ),
            "next_required_structure": (
                "A nonzero chiral signal would require comparing different graphs/handoffs, "
                "an emergent symplectic pairing, or a noncommuting family-level handoff."
            ),
        },
    }

    if args.outdir:
        write_csv(rows, summary, Path(args.outdir))

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
