# V6 triadic interface chirality test report

## b3_flux_difference

- status: `radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved`
- tau signs: `1,1,1`
- nonzero tau count: `3`
- sibling flip detected: `False`

## b3_env_flux_difference

- status: `radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved`
- tau signs: `1,1,1`
- nonzero tau count: `3`
- sibling flip detected: `False`

## b3_uv_flux_difference

- status: `radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved`
- tau signs: `1,1,1`
- nonzero tau count: `3`
- sibling flip detected: `False`

## b3_sibling_index_control

- status: `radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved`
- tau signs: `1,1,1`
- nonzero tau count: `3`
- sibling flip detected: `False`
- caveat: `WARNING: regulator mode inserts noncanonical sibling label/order.`

## b3_cyclic_order_control

- status: `radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved`
- tau signs: `0,1,1`
- nonzero tau count: `2`
- sibling flip detected: `False`
- caveat: `WARNING: regulator mode inserts noncanonical sibling label/order.`


## Interpretation

V6 explicitly tests the triadic idea: UV, Environment, and a Handoff/Regulator channel. In the canonical regulator modes the regulator is derived from real family flux differences. The result can be a nonzero triadic area, but it is not accepted as chirality unless the sign flips under sibling permutation.

The positive-control modes show what happens when sibling labels or cyclic order are inserted by hand. They are useful detector checks but not CNNA-derived chirality.
