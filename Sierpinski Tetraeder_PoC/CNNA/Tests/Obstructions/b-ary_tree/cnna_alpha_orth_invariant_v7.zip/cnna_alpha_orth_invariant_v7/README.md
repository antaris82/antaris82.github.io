# CNNA alpha_orth + flow-derived sign diagnostics v3

This package computes the dimensionless orthogonality-defect coupling

```text
lambda_UV  = b^k * alpha_UV / C_k
lambda_Env = alpha_Env(d) / C_k
Xi         = (1 + lambda_Env) * (1 + lambda_UV)
rho_M      = <e_root,e_cut>_M / (||e_root||_M ||e_cut||_M)
alpha_orth = |rho_M|
```

## Important v3 change

The sign of `rho_M` is no longer inserted as `-1/sqrt(Xi)` by convention.
The script builds the two-port reduced DtN matrix

```text
M = [[C_k + alpha_Env,       -C_k],
     [      -C_k,       C_k + b^k alpha_UV]]
```

and reads the sign from the off-diagonal flux coupling:

```text
rho_M = M[0,1] / sqrt(M[0,0] * M[1,1])
rho_sign_from_flow = sign(M[0,1])
```

For passive unit-edge trees this sign is radial: it records root-to-cut flow direction.
It is not yet a chiral choice between `J` and `-J`.

## Two-approximant test

`two_approximant_flow_sign.py` performs the minimal parent -> child test.
For each child sibling it computes the flow-derived sign for parent and child and
then checks whether the relative sign flips under sibling permutation.

Expected result for the symmetric unit-edge b-ary tree:

```text
relative_sigma_from_flow = +1 for all siblings
sibling_permutation_flip = false
diagnosis = radial_only: sibling permutation leaves sigma invariant; no J sign solved
```

This is an important negative diagnostic: the flow sign is derived, but it is radial,
not chiral.

## Epistemic status

- `C_k` is forced by the finite unit-edge b-ary approximant.
- `alpha_UV` is forced by the finite unit-edge UV-tail model.
- `alpha_Env(d)` is not yet derived from the full complement family.
- `infinite_ladder` is a fixed-point diagnostic approximation, not a proof of the full complement-family flow.
- The canonical Cauchy-data symplectic pairing of two DtN-generated data vectors vanishes for the symmetric two-port model.
- Therefore the package does not prove a canonical `J`; it shows where the sign remains radial and achiral.

## Examples

Single invariant:

```bash
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model ladder
```

Infinite-ladder diagnostic:

```bash
python3 alpha_orth_invariant.py --b 3 --k 4 --depth 2 --env-model infinite_ladder
```

Two-approximant flow sign:

```bash
python3 two_approximant_flow_sign.py --b 3 --k 4 --parent-depth 2 --env-model infinite_ladder
```


## V4: two-boundary shell chirality diagnostic

`two_boundary_shell_chirality.py` tests the next step after passive one-approximant conductance:

1. Build a parent-child difference shell.
2. Compute its two-boundary real DtN matrix.
3. Evaluate the Cauchy boundary form
   `omega((q,p),(q',p')) = q^T p' - p^T q'`.
4. Compare all siblings.
5. Report whether the sign is chiral, radial, or zero.

Expected result for the pure symmetric unit-edge b-ary shell:

```text
achiral_negative: passive symmetric two-boundary shell gives no antisymmetric signal
```

This is not a failure of the diagnostic. It means the pure passive symmetric shell still supplies only radial/self-adjoint DtN data. A genuine \(J\)-orientation would require an additional CNNA-derived antisymmetric Cauchy/handoff structure, a comparison of different DtN graphs, or a noncommuting family-level handoff.

Example:

```bash
python3 two_boundary_shell_chirality.py --b 3 --side-ground-depth 1 --outdir results
```


## V5: family handoff chirality diagnostic

`family_handoff_chirality.py` corrects the V4 limitation. V4 tested isolated
passive DtN graphs and simple shells. V5 tests a small family of symmetric DtN
graphs connected by canonical sign-free handoffs.

It implements:

1. Cross-graph Cauchy pairing
   `omega_ij(q,r) = q^T Lambda_j r - r^T Lambda_i q`.

2. Sibling/reversal behavior
   A nonzero signal is not accepted as `J`-orientation unless it flips under
   sibling reversal/permutation. Otherwise it is radial/family-difference only.

3. Handoff square / holonomy check
   It compares canonical sign-free paths `A -> B_i -> C` and `A -> B_j -> C`.

Example:

```bash
python3 family_handoff_chirality.py --b 3 --k 4 --env-mode ladder --outdir v5_results
```

Diagnostic countermodel:

```bash
python3 family_handoff_chirality.py --b 3 --k 4 --env-mode sibling_index
```

`sibling_index` intentionally breaks sibling symmetry by labels. Any positive
signal there is noncanonical and only verifies that the detector can see
label-induced asymmetry.


## V6: triadic interface chirality diagnostic

`triadic_interface_chirality.py` tests the CNNA triad explicitly:

```text
UV-channel, Environment-channel, Handoff/Regulator-channel
```

The regulator channel is derived by default from a real family flux difference:

```text
r_i = (Lambda_child_i - Lambda_parent)(e_env + e_uv)
```

The triadic orientation candidate is:

```text
tau_i = det[e_uv - e_env, r_i - e_env]
```

Acceptance rule:

```text
nonzero tau is not enough;
tau must flip under sibling permutation and must not come from a noncanonical
label/order insertion.
```

Canonical examples:

```bash
python3 triadic_interface_chirality.py --b 3 --k 4 --regulator-mode flux_difference --outdir v6_results
python3 triadic_interface_chirality.py --b 3 --k 4 --regulator-mode env_flux_difference
python3 triadic_interface_chirality.py --b 3 --k 4 --regulator-mode uv_flux_difference
```

Positive controls:

```bash
python3 triadic_interface_chirality.py --b 3 --k 4 --regulator-mode sibling_index
python3 triadic_interface_chirality.py --b 3 --k 4 --regulator-mode cyclic_order
```

The positive controls intentionally insert noncanonical sibling labels/order and
therefore do not count as CNNA-derived chirality.


## V7: oriented UV/Environment Cauchy shell gate

`oriented_cauchy_shell_gate.py` restores the relevant older structure that
V5/V6 did not test correctly:

```text
UV-tail and Environment-tail are oppositely directed boundary sides of one shell.
```

This is not a sibling-chirality test. It builds the doubled Cauchy data space

```text
(q_env, q_uv, p_env, p_uv)
```

with oriented boundary form

```text
omega_boundary = omega_env - omega_uv
```

and positive metric

```text
g = diag(k_env, k_uv, 1/k_env, 1/k_uv)
```

where

```text
k_env = C_k + alpha_env
k_uv  = C_k + b^k alpha_uv
```

It then constructs

```text
J = -g^{-1} omega_boundary
```

and verifies:

```text
J^2 = -I
J^T g J = g
J^T omega J = omega
Env/UV boundary swap reverses coorientation
```

Example:

```bash
python3 oriented_cauchy_shell_gate.py --b 3 --k 4 --depth 2 --env-mode ladder --outdir v7_results
```

Interpretation:

```text
This fixes J relative to the oriented UV/Env cut coorientation.
It does not solve sibling chirality and does not claim an absolute orientation
independent of the chosen oriented shell.
```
