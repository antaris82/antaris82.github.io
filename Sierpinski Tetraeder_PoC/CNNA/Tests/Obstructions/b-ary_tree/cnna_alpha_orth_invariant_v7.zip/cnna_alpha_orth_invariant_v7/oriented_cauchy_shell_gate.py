#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path

def finite_tail_conductance(b: int, depth: int) -> float:
    if depth <= 0:
        return 0.0
    c = float(b)
    for _ in range(2, depth + 1):
        c = b * c / (1.0 + c)
    return c

def radial_core_conductance(b: int, k: int) -> float:
    if k <= 0:
        raise ValueError("k must be positive")
    return (b - 1.0) / (1.0 - b ** (-k))

def environment_ladder(depth: int, b: int, env_depth: int) -> float:
    if depth <= 0 or env_depth <= 0:
        return 0.0
    side_tail = finite_tail_conductance(b, env_depth - 1) if env_depth > 1 else 0.0
    side_shunt = (b - 1) * side_tail
    g = side_shunt
    for _ in range(1, depth):
        through_parent = g / (1.0 + g) if g > 0.0 else 0.0
        g = side_shunt + through_parent
    return g / (1.0 + g) if g > 0.0 else 0.0

def env_alpha(depth: int, b: int, env_depth: int, mode: str) -> float:
    if mode == "ladder":
        return environment_ladder(depth, b, env_depth)
    if mode == "none":
        return 0.0
    if mode == "constant":
        return 1.0
    if mode == "depth_linear":
        return float(depth)
    raise ValueError(f"unknown env mode: {mode}")

def shell_weights(b: int, k: int, depth: int, uv_tail_depth: int, env_depth: int, env_mode: str):
    C = radial_core_conductance(b, k)
    a_uv = finite_tail_conductance(b, uv_tail_depth)
    a_env = env_alpha(depth, b, env_depth, env_mode)
    cut = b ** k
    k_env = C + a_env
    k_uv = C + cut * a_uv
    rho = -C / math.sqrt(k_env * k_uv)
    return {
        "C_k": C,
        "alpha_uv": a_uv,
        "alpha_env": a_env,
        "cut_size": cut,
        "k_env": k_env,
        "k_uv": k_uv,
        "rho_M": rho,
        "alpha_orth": abs(rho),
    }

def zeros(n, m):
    return [[0.0 for _ in range(m)] for _ in range(n)]

def eye(n):
    M = zeros(n, n)
    for i in range(n):
        M[i][i] = 1.0
    return M

def diag(v):
    M = zeros(len(v), len(v))
    for i, x in enumerate(v):
        M[i][i] = x
    return M

def matmul(A, B):
    return [[sum(A[i][t] * B[t][j] for t in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]

def transpose(A):
    return [list(row) for row in zip(*A)]

def matadd(A, B):
    return [[A[i][j] + B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def matsub(A, B):
    return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def scalar_mul(c, A):
    return [[c * x for x in row] for row in A]

def frob(A):
    return math.sqrt(sum(x*x for row in A for x in row))

def oriented_omega_matrix(orientation: int = 1):
    # Coordinates: q_env, q_uv, p_env, p_uv.
    # orientation=+1: omega_env - omega_uv.
    O = zeros(4, 4)
    O[0][2] = 1.0
    O[2][0] = -1.0
    O[1][3] = -1.0
    O[3][1] = 1.0
    return scalar_mul(float(orientation), O)

def metric_matrix(k_env: float, k_uv: float):
    return diag([k_env, k_uv, 1.0 / k_env, 1.0 / k_uv])

def cauchy_J(k_env: float, k_uv: float, orientation: int = 1):
    # J = -G^{-1}Omega for the chosen oriented boundary form.
    J = zeros(4, 4)
    s = float(orientation)
    J[0][2] = -s / k_env
    J[1][3] = s / k_uv
    J[2][0] = s * k_env
    J[3][1] = -s * k_uv
    return J

def swap_env_uv_matrix():
    S = zeros(4, 4)
    S[0][1] = 1.0
    S[1][0] = 1.0
    S[2][3] = 1.0
    S[3][2] = 1.0
    return S

@dataclass(frozen=True)
class GateResult:
    b: int
    k: int
    depth: int
    env_mode: str
    C_k: float
    alpha_uv: float
    alpha_env: float
    cut_size: int
    k_env: float
    k_uv: float
    rho_M: float
    alpha_orth: float
    J_square_error: float
    metric_compat_error: float
    omega_compat_error: float
    swap_to_minus_J_error: float
    status: str
    caveat: str

def run_gate(b: int, k: int, depth: int, uv_tail_depth: int, env_depth: int, env_mode: str):
    w = shell_weights(b, k, depth, uv_tail_depth, env_depth, env_mode)
    k_env = w["k_env"]
    k_uv = w["k_uv"]
    G = metric_matrix(k_env, k_uv)
    O = oriented_omega_matrix(+1)
    J = cauchy_J(k_env, k_uv, +1)
    I = eye(4)
    JT = transpose(J)
    J2 = matmul(J, J)
    J_square_error = frob(matadd(J2, I))
    metric_compat_error = frob(matsub(matmul(matmul(JT, G), J), G))
    omega_compat_error = frob(matsub(matmul(matmul(JT, O), J), O))
    S = swap_env_uv_matrix()
    J_swapped_conjugated = matmul(matmul(S, J), S)
    # Under Env/UV swap, the shell coorientation reverses. The target is the
    # reversed-orientation J with exchanged weights.
    J_reversed = cauchy_J(k_uv, k_env, -1)
    swap_to_minus_J_error = frob(matsub(J_swapped_conjugated, J_reversed))
    ok = max(J_square_error, metric_compat_error, omega_compat_error, swap_to_minus_J_error) < 1e-9
    status = (
        "oriented_cauchy_shell_pass: UV/Env opposite boundary orientation yields exact compatible J"
        if ok else
        "fail: oriented Cauchy shell identities did not close numerically"
    )
    caveat = (
        "This fixes J relative to the UV/Env cut coorientation. It does not solve sibling chirality "
        "and does not claim an absolute orientation independent of the chosen oriented shell."
    )
    return GateResult(
        b=b, k=k, depth=depth, env_mode=env_mode,
        C_k=w["C_k"], alpha_uv=w["alpha_uv"], alpha_env=w["alpha_env"],
        cut_size=w["cut_size"], k_env=k_env, k_uv=k_uv,
        rho_M=w["rho_M"], alpha_orth=w["alpha_orth"],
        J_square_error=J_square_error,
        metric_compat_error=metric_compat_error,
        omega_compat_error=omega_compat_error,
        swap_to_minus_J_error=swap_to_minus_J_error,
        status=status, caveat=caveat,
    )

def write_outputs(result: GateResult, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "oriented_cauchy_shell_gate.json").write_text(json.dumps(asdict(result), indent=2), encoding="utf-8")
    with (outdir / "oriented_cauchy_shell_gate.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(result).keys()))
        writer.writeheader()
        writer.writerow(asdict(result))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=3)
    ap.add_argument("--k", type=int, default=4)
    ap.add_argument("--depth", type=int, default=2)
    ap.add_argument("--uv-tail-depth", type=int, default=2)
    ap.add_argument("--env-depth", type=int, default=2)
    ap.add_argument("--env-mode", choices=["ladder", "none", "constant", "depth_linear"], default="ladder")
    ap.add_argument("--outdir", type=str, default="")
    args = ap.parse_args()
    result = run_gate(args.b, args.k, args.depth, args.uv_tail_depth, args.env_depth, args.env_mode)
    if args.outdir:
        write_outputs(result, Path(args.outdir))
    print(json.dumps(asdict(result), indent=2))

if __name__ == "__main__":
    main()
