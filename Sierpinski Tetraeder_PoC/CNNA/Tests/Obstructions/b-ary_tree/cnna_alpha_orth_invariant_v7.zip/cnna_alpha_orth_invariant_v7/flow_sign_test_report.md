# Flow-derived sign test report

## What was changed

The old scalar formula used the sign convention

```text
rho = -1 / sqrt(Xi)
```

The revised code derives the sign from the off-diagonal flux coupling of the real two-port DtN matrix:

```text
M01_flow_coupling = -C_k
rho_M = M01_flow_coupling / sqrt(M00_root_root * M11_cut_cut)
```

Thus the sign is not hard-coded. It is read from the real flux relation between root and equipotential cut.

## Result for b=3, k=4, parent depth 2, infinite_ladder environment

All three children give the same flow sign:

```text
parent_flow_sign = -1
child_flow_sign  = -1
relative_sigma_from_flow = +1
sibling_permutation_flip = false
```

Diagnosis:

```text
radial_only: sibling permutation leaves sigma invariant; no J sign solved
```

## Interpretation

The flow-derived sign exists, but in this symmetric unit-edge two-port reduction it is radial rather than chiral.
It records the passive root-to-cut direction of flux, not a canonical orientation of a complex structure.

The canonical Cauchy-data symplectic pairing between two DtN-generated data vectors is zero because the DtN matrix is symmetric:

```text
omega((q,Mq),(r,Mr)) = q^T M r - r^T M q = 0.
```

Therefore the two-approximant test, in this minimal symmetric setting, does not yet derive the sign of `J` versus `-J`.
It confirms the methodological warning: flux signs can be derived, but they may only be radial unless a genuinely antisymmetric/chiral structure appears.
