#!/usr/bin/env python3
"""
Triadic interface chirality diagnostic.

V6 explicitly tests the CNNA triad:

    UV-channel, Environment-channel, Handoff/Regulator-channel.

The regulator channel is not inserted as a sign. In the canonical modes it is
derived from real family flux differences:

    r_i = (Lambda_child_i - Lambda_parent) a

with sign-free excitations a. The oriented-area candidate is

    tau_i = det[e_uv - e_env, r_i - e_env].

A nonzero tau is not accepted as chirality by itself. It must flip under sibling
permutation and must not come from a noncanonical label/order insertion.

No complex input, no epsilon regularization, no pseudoinverse, no least-squares.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path


def finite_tail_conductance(b: int, depth: int) -> float:
    if depth <= 0:
        return 0.0
    c = float(b)
    for _ in range(2, depth + 1):
        c = b * c / (1.0 + c)
    return c


def radial_core_conductance(b: int, k: int) -> float:
    if k <= 0:
        raise ValueError("k must be positive")
    return (b - 1.0) / (1.0 - b ** (-k))


def environment_ladder(depth: int, b: int, env_depth: int) -> float:
    if depth <= 0 or env_depth <= 0:
        return 0.0
    side_tail = finite_tail_conductance(b, env_depth - 1) if env_depth > 1 else 0.0
    side_shunt = (b - 1) * side_tail
    g = side_shunt
    for _ in range(1, depth):
        through_parent = g / (1.0 + g) if g > 0.0 else 0.0
        g = side_shunt + through_parent
    return g / (1.0 + g) if g > 0.0 else 0.0


def env_alpha(depth: int, b: int, env_depth: int, env_mode: str, child_index: int = 0) -> float:
    if env_mode == "ladder":
        return environment_ladder(depth, b, env_depth)
    if env_mode == "none":
        return 0.0
    if env_mode == "depth_linear":
        return float(depth)
    if env_mode == "sibling_index":
        return 1.0 + float(child_index)
    raise ValueError(f"unknown env mode: {env_mode}")


def lambda_matrix(b: int, k: int, depth: int, uv_tail_depth: int, env_depth: int, env_mode: str, child_index: int = 0):
    C = radial_core_conductance(b, k)
    a_uv = finite_tail_conductance(b, uv_tail_depth)
    a_env = env_alpha(depth, b, env_depth, env_mode, child_index)
    cut = b ** k
    return [
        [C + a_env, -C],
        [-C, C + cut * a_uv],
    ]


def mv(M, v):
    return [M[0][0] * v[0] + M[0][1] * v[1],
            M[1][0] * v[0] + M[1][1] * v[1]]


def mat_sub(A, B):
    return [[A[i][j] - B[i][j] for j in range(2)] for i in range(2)]


def det2_cols(a, b):
    return a[0] * b[1] - a[1] * b[0]


def sign(x: float, tol: float = 1e-10) -> int:
    if x > tol:
        return 1
    if x < -tol:
        return -1
    return 0


def regulator_vector(L_parent, L_child, mode: str, child_index: int, b: int):
    e_env = [1.0, 0.0]
    e_uv = [0.0, 1.0]
    a = [1.0, 1.0]

    if mode == "flux_difference":
        D = mat_sub(L_child, L_parent)
        return mv(D, a), "derived: (Lambda_child - Lambda_parent)(e_env + e_uv)"

    if mode == "env_flux_difference":
        D = mat_sub(L_child, L_parent)
        return mv(D, e_env), "derived: (Lambda_child - Lambda_parent)e_env"

    if mode == "uv_flux_difference":
        D = mat_sub(L_child, L_parent)
        return mv(D, e_uv), "derived: (Lambda_child - Lambda_parent)e_uv"

    if mode == "sibling_index":
        scale = child_index - (b - 1) / 2.0
        return [scale, -scale], "NONCANONICAL positive control: sibling label inserted"

    if mode == "cyclic_order":
        angle = 2.0 * math.pi * child_index / max(1, b)
        return [math.cos(angle), math.sin(angle)], "NONCANONICAL positive control: external cyclic order inserted"

    raise ValueError(f"unknown regulator mode: {mode}")


@dataclass(frozen=True)
class TriadRow:
    child_index: int
    lambda_parent_00: float
    lambda_child_00: float
    regulator_x: float
    regulator_y: float
    tau_oriented_area: float
    tau_sign: int
    regulator_status: str
    diagnosis: str


@dataclass(frozen=True)
class TriadSummary:
    b: int
    k: int
    env_mode: str
    regulator_mode: str
    tau_signs: str
    nonzero_tau_count: int
    sibling_flip_detected: bool
    status: str
    caveat: str


def run_triadic(
    b: int,
    k: int,
    parent_depth: int,
    child_depth: int,
    uv_tail_depth: int,
    env_depth: int,
    env_mode: str,
    regulator_mode: str,
):
    Lp = lambda_matrix(b, k, parent_depth, uv_tail_depth, env_depth, env_mode, -1)
    e_env = [1.0, 0.0]
    e_uv = [0.0, 1.0]
    base = [e_uv[0] - e_env[0], e_uv[1] - e_env[1]]

    rows = []
    for child in range(b):
        Lc = lambda_matrix(b, k, child_depth, uv_tail_depth, env_depth, env_mode, child)
        r, r_status = regulator_vector(Lp, Lc, regulator_mode, child, b)
        rel = [r[0] - e_env[0], r[1] - e_env[1]]
        tau = det2_cols(base, rel)
        s = sign(tau)
        diag = "zero: triadic area vanishes" if s == 0 else "nonzero_triadic_area_candidate"
        rows.append(TriadRow(
            child_index=child,
            lambda_parent_00=Lp[0][0],
            lambda_child_00=Lc[0][0],
            regulator_x=r[0],
            regulator_y=r[1],
            tau_oriented_area=tau,
            tau_sign=s,
            regulator_status=r_status,
            diagnosis=diag,
        ))

    signs = [r.tau_sign for r in rows]
    nonzero = [s for s in signs if s != 0]
    flip = bool(nonzero) and (min(nonzero) < 0 < max(nonzero))

    caveat_parts = []
    if regulator_mode in {"sibling_index", "cyclic_order"}:
        caveat_parts.append("WARNING: regulator mode inserts noncanonical sibling label/order.")
    if env_mode == "sibling_index":
        caveat_parts.append("WARNING: env_mode=sibling_index breaks sibling symmetry by label.")
    caveat = " ".join(caveat_parts)

    if not nonzero:
        status = "achiral_negative: triadic regulator candidate gives zero oriented area"
    elif flip and not caveat:
        status = "chiral_candidate: derived triadic signal flips under siblings"
    elif flip and caveat:
        status = "noncanonical_positive_control: flip caused by inserted label/order"
    else:
        status = "radial_triadic_signal: nonzero triadic area but sibling-invariant, so no J sign solved"

    summary = TriadSummary(
        b=b,
        k=k,
        env_mode=env_mode,
        regulator_mode=regulator_mode,
        tau_signs=",".join(str(s) for s in signs),
        nonzero_tau_count=len(nonzero),
        sibling_flip_detected=flip,
        status=status,
        caveat=caveat,
    )

    return {
        "input": {
            "b": b,
            "k": k,
            "parent_depth": parent_depth,
            "child_depth": child_depth,
            "uv_tail_depth": uv_tail_depth,
            "env_depth": env_depth,
            "env_mode": env_mode,
            "regulator_mode": regulator_mode,
        },
        "definition": {
            "channels": "e_env=(1,0), e_uv=(0,1), r_i=(Lambda_i-Lambda_parent)a",
            "triadic_area": "tau_i = det[e_uv-e_env, r_i-e_env]",
            "acceptance_rule": "Only sibling sign flip without noncanonical caveat is accepted as chirality candidate.",
        },
        "rows": [asdict(r) for r in rows],
        "summary": asdict(summary),
        "interpretation": {
            "negative_meaning": "The tested triadic structure is still radial/achiral; richer complement-family/regulator structure is not ruled out.",
            "positive_control_meaning": "Noncanonical modes verify detector sensitivity but do not prove derived chirality.",
        },
    }


def write_outputs(payload, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "triadic_interface_chirality.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    rows = payload["rows"]
    with (outdir / "triadic_rows.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=3)
    ap.add_argument("--k", type=int, default=4)
    ap.add_argument("--parent-depth", type=int, default=1)
    ap.add_argument("--child-depth", type=int, default=2)
    ap.add_argument("--uv-tail-depth", type=int, default=2)
    ap.add_argument("--env-depth", type=int, default=2)
    ap.add_argument("--env-mode", choices=["ladder", "none", "depth_linear", "sibling_index"], default="ladder")
    ap.add_argument(
        "--regulator-mode",
        choices=["flux_difference", "env_flux_difference", "uv_flux_difference", "sibling_index", "cyclic_order"],
        default="flux_difference",
    )
    ap.add_argument("--outdir", type=str, default="")
    args = ap.parse_args()

    payload = run_triadic(
        b=args.b,
        k=args.k,
        parent_depth=args.parent_depth,
        child_depth=args.child_depth,
        uv_tail_depth=args.uv_tail_depth,
        env_depth=args.env_depth,
        env_mode=args.env_mode,
        regulator_mode=args.regulator_mode,
    )
    if args.outdir:
        write_outputs(payload, Path(args.outdir))
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
