# V4 two-boundary shell chirality test report

## b=2, side_ground_depth=1

- flow signs: `-1,-1`
- omega signs: `0,0`
- sibling permutation flip: `False`
- commutator norm max: `0.0`
- status: `achiral_negative: passive symmetric two-boundary shell gives no antisymmetric signal`

Rows:

| child | Lambda01 | omega(e0,e1) | flow sign | omega sign | diagnosis |
|---:|---:|---:|---:|---:|---|
| 0 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 1 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |

## b=3, side_ground_depth=1

- flow signs: `-1,-1,-1`
- omega signs: `0,0,0`
- sibling permutation flip: `False`
- commutator norm max: `0.0`
- status: `achiral_negative: passive symmetric two-boundary shell gives no antisymmetric signal`

Rows:

| child | Lambda01 | omega(e0,e1) | flow sign | omega sign | diagnosis |
|---:|---:|---:|---:|---:|---|
| 0 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 1 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 2 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |

## b=4, side_ground_depth=2

- flow signs: `-1,-1,-1,-1`
- omega signs: `0,0,0,0`
- sibling permutation flip: `False`
- commutator norm max: `0.0`
- status: `achiral_negative: passive symmetric two-boundary shell gives no antisymmetric signal`

Rows:

| child | Lambda01 | omega(e0,e1) | flow sign | omega sign | diagnosis |
|---:|---:|---:|---:|---:|---|
| 0 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 1 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 2 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |
| 3 | -1 | 0 | -1 | 0 | lagrangian_graph: symmetric shell DtN gives zero Cauchy pairing on one graph |


## Interpretation

The shell DtN matrices are self-adjoint. Therefore the Cauchy pairing of two
vectors on the same DtN graph is zero:
\[
q^T \Lambda r - (\Lambda q)^T r = 0.
\]

The passive two-boundary shell therefore does not yet solve the sign of \(J\).
It confirms the expected negative result: the pure symmetric unit-edge ToC is
radial/achiral at this diagnostic level. The next admissible positive path
would have to compare different handoff graphs, derive an antisymmetric
Cauchy pairing, or detect a noncommuting family-level handoff.
