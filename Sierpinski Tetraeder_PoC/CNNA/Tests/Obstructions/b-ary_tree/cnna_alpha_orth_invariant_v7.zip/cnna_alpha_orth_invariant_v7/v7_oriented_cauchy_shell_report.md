# V7 oriented UV/Environment Cauchy shell gate report

## b3_k4_ladder

- status: `oriented_cauchy_shell_pass: UV/Env opposite boundary orientation yields exact compatible J`
- rho_M: `-0.08763206858271307`
- alpha_orth: `0.08763206858271307`
- J_square_error: `0.0`
- metric_compat_error: `0.0`
- omega_compat_error: `0.0`
- swap_to_minus_J_error: `0.0`
- caveat: `This fixes J relative to the UV/Env cut coorientation. It does not solve sibling chirality and does not claim an absolute orientation independent of the chosen oriented shell.`

## b2_k6_ladder

- status: `oriented_cauchy_shell_pass: UV/Env opposite boundary orientation yields exact compatible J`
- rho_M: `-0.08268982305947231`
- alpha_orth: `0.08268982305947231`
- J_square_error: `0.0`
- metric_compat_error: `0.0`
- omega_compat_error: `0.0`
- swap_to_minus_J_error: `0.0`
- caveat: `This fixes J relative to the UV/Env cut coorientation. It does not solve sibling chirality and does not claim an absolute orientation independent of the chosen oriented shell.`

## b4_k3_constant

- status: `oriented_cauchy_shell_pass: UV/Env opposite boundary orientation yields exact compatible J`
- rho_M: `-0.1050723236793641`
- alpha_orth: `0.1050723236793641`
- J_square_error: `0.0`
- metric_compat_error: `0.0`
- omega_compat_error: `0.0`
- swap_to_minus_J_error: `0.0`
- caveat: `This fixes J relative to the UV/Env cut coorientation. It does not solve sibling chirality and does not claim an absolute orientation independent of the chosen oriented shell.`


## Interpretation

V7 does not try to solve sibling chirality. Instead, it tests the older
UV/Environment insight: the two tails are oppositely directed boundary sides
of one shell. In the doubled Cauchy data space this gives the oriented boundary
form

omega_boundary = omega_env - omega_uv.

With the positive metric derived from the same finite Schur/DtN weights, the
standard compatible Cauchy complex structure closes exactly:

J^2 = -I.

This means the J sign is fixed relative to the oriented UV/Env cut
coorientation, not by an arbitrary hard-coded sign. The remaining theoretical
burden is to justify this coorientation as CNNA-derived, rather than merely a
boundary convention.
