#!/usr/bin/env python3
"""
CNNA minimal alpha_orth / flow-derived sign diagnostic.

This script computes the dimensionless orthogonality-defect coupling
of the two-port reduction of a finite b-ary approximant, but the sign
of rho is no longer inserted by convention. It is read from the real
flux coupling of the reduced port-DtN matrix.

Two-port model
--------------
Ports are (root, equipotential UV cut). The real reduced operator is

    M = [[C_k + alpha_Env,       -C_k],
         [      -C_k,       C_k + b^k alpha_UV]]

where C_k is the radial core conductance, alpha_UV is the projected
finite UV-tail conductance per cut node, and alpha_Env is the projected
environment conductance at the root.

The UV/environment channel overlap is computed as

    rho_M = <e_root, e_cut>_M / (||e_root||_M ||e_cut||_M)
          = M[0,1] / sqrt(M[0,0] M[1,1]).

Thus the sign is derived from the off-diagonal flux coupling M[0,1],
not hard-coded.

Epistemic status
----------------
- C_k is forced by the finite unit-edge b-ary approximant.
- alpha_UV is forced by the finite unit-edge UV-tail model.
- alpha_Env(d) is selected by an explicit environment model here; it is
  not yet derived from the full complement family.
- The passive symmetric DtN matrix has no antisymmetric/chiral part.
  The canonical Cauchy-data symplectic pairing of two DtN-generated
  Cauchy data vectors vanishes for this symmetric two-port model.
- Therefore alpha_orth is still a diagnostic orthogonality-defect
  coupling, not a physical fine-structure constant and not a proof of J.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Literal

EnvModel = Literal["ladder", "infinite_ladder", "constant", "power", "exponential", "none"]


def sign(x: float, tol: float = 1e-14) -> int:
    if x > tol:
        return 1
    if x < -tol:
        return -1
    return 0


def finite_tail_conductance(b: int, depth: int) -> float:
    if depth <= 0:
        return 0.0
    c = float(b)
    for _ in range(2, depth + 1):
        c = b * c / (1.0 + c)
    return c


def infinite_tail_conductance(b: int) -> float:
    if b < 1:
        raise ValueError("b must be >= 1")
    if b == 1:
        return 0.0
    return float(b - 1)


def radial_core_conductance(b: int, k: int) -> float:
    if k <= 0:
        return math.inf
    if b == 1:
        return 1.0 / k
    return (b - 1.0) / (1.0 - b ** (-k))


def environment_conductance_ladder(depth: int, b: int, env_depth: int) -> float:
    """Finite trunk/side ladder model. Assumption, not full-family theorem."""
    d = int(depth)
    if d <= 0 or env_depth <= 0 or b <= 1:
        return 0.0
    side_tail = finite_tail_conductance(b, env_depth - 1) if env_depth > 1 else 0.0
    side_shunt = (b - 1) * side_tail
    g_out = side_shunt
    for _ in range(1, d):
        through_parent = g_out / (1.0 + g_out) if g_out > 0.0 else 0.0
        g_out = side_shunt + through_parent
    return g_out / (1.0 + g_out) if g_out > 0.0 else 0.0


def environment_conductance_infinite_ladder(b: int) -> float:
    """
    Fixed-point approximation to an infinite trunk/side complement ladder.

    This is a stronger diagnostic model than the finite ladder, not a proof
    of the full complement-family DtN. Each side branch is an infinite b-ary
    tail with conductance b-1. The outward trunk conductance g satisfies

        g = s + g/(1+g),     s = (b-1)^2.

    The load seen through the parent edge is g/(1+g).
    """
    if b <= 1:
        return 0.0
    s = float((b - 1) ** 2)
    g = 0.5 * (s + math.sqrt(s * s + 4.0 * s))
    return g / (1.0 + g)


def alpha_env_model(
    model: EnvModel,
    depth: int,
    b: int,
    env_depth: int,
    alpha0: float,
    power_p: float,
    exp_q: float,
) -> float:
    if model == "ladder":
        return environment_conductance_ladder(depth, b, env_depth)
    if model == "infinite_ladder":
        return environment_conductance_infinite_ladder(b)
    if model == "constant":
        return max(0.0, alpha0)
    if model == "power":
        return max(0.0, alpha0 * (max(depth, 0) ** power_p))
    if model == "exponential":
        return max(0.0, alpha0 * (exp_q ** max(depth, 0)))
    if model == "none":
        return 0.0
    raise ValueError(f"unknown environment model: {model}")


def env_status(model: str) -> str:
    if model == "ladder":
        return "model_assumption: finite trunk/side ladder; not yet complement-family derived"
    if model == "infinite_ladder":
        return "diagnostic_fixed_point: infinite ladder approximation; not yet full complement-family derived"
    if model == "none":
        return "diagnostic_countermodel: no environment load"
    return f"diagnostic_countermodel: explicit {model} alpha_env(d), not derived"


@dataclass(frozen=True)
class InvariantRow:
    b: int
    k: int
    depth: int
    uv_tail_depth: int
    env_tail_depth: int
    env_model: str
    cut_size: int
    C_k: float
    alpha_uv: float
    alpha_env: float
    alpha_env_status: str
    total_uv_load: float
    lambda_uv: float
    lambda_env: float
    uv_env_dominance_ratio: float
    M00_root_root: float
    M01_flow_coupling: float
    M11_cut_cut: float
    rho_M: float
    rho_sign_from_flow: int
    alpha_orth: float
    Xi: float
    log_Xi: float
    angle_degrees: float
    angle_defect_degrees: float
    k_log_b: float
    b_power_k: int
    cauchy_symplectic_pairing: float
    chiral_signal_present: bool
    plausible_fine_structure_like: bool


def compute_row(
    b: int,
    k: int,
    depth: int,
    uv_tail_depth: int,
    env_tail_depth: int,
    env_model: EnvModel,
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
) -> InvariantRow:
    if b < 2:
        raise ValueError("This diagnostic expects b >= 2.")
    if k < 1:
        raise ValueError("k must be >= 1.")

    C_k = radial_core_conductance(b, k)
    alpha_uv = finite_tail_conductance(b, uv_tail_depth)
    alpha_env = alpha_env_model(env_model, depth, b, env_tail_depth, alpha_env_constant, env_power_p, env_exp_q)
    cut_size = b ** k
    total_uv = cut_size * alpha_uv

    M00 = C_k + alpha_env
    M01 = -C_k
    M11 = C_k + total_uv

    rho = M01 / math.sqrt(M00 * M11)
    rho_s = sign(rho)
    alpha_orth = abs(rho)
    Xi = 1.0 / (rho * rho) if rho != 0 else math.inf
    angle = math.degrees(math.acos(max(-1.0, min(1.0, rho))))

    # For Cauchy data x=(q,Mq), y=(r,Mr), the canonical symplectic pairing
    # q·Mr - r·Mq vanishes because M is symmetric. This is the key diagnostic:
    # the passive two-port flow gives a signed coupling, but no chiral 2-form.
    # Use root and cut basis potentials.
    cauchy_omega = M01 - M01

    lambda_uv = total_uv / C_k
    lambda_env = alpha_env / C_k
    dominance = lambda_uv / lambda_env if lambda_env > 0 else math.inf

    return InvariantRow(
        b=b,
        k=k,
        depth=depth,
        uv_tail_depth=uv_tail_depth,
        env_tail_depth=env_tail_depth,
        env_model=env_model,
        cut_size=cut_size,
        C_k=C_k,
        alpha_uv=alpha_uv,
        alpha_env=alpha_env,
        alpha_env_status=env_status(env_model),
        total_uv_load=total_uv,
        lambda_uv=lambda_uv,
        lambda_env=lambda_env,
        uv_env_dominance_ratio=dominance,
        M00_root_root=M00,
        M01_flow_coupling=M01,
        M11_cut_cut=M11,
        rho_M=rho,
        rho_sign_from_flow=rho_s,
        alpha_orth=alpha_orth,
        Xi=Xi,
        log_Xi=math.log(Xi) if math.isfinite(Xi) else math.inf,
        angle_degrees=angle,
        angle_defect_degrees=abs(angle - 90.0),
        k_log_b=k * math.log(b),
        b_power_k=cut_size,
        cauchy_symplectic_pairing=cauchy_omega,
        chiral_signal_present=abs(cauchy_omega) > 1e-14,
        plausible_fine_structure_like=(0.0 < alpha_orth < 0.1),
    )


def matrix(
    b_values: Iterable[int],
    k_values: Iterable[int],
    depth_values: Iterable[int],
    uv_tail_depth: int,
    env_tail_depth: int,
    env_models: Iterable[EnvModel],
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
    max_cut_size: int,
) -> list[InvariantRow]:
    rows = []
    for model in env_models:
        for b in b_values:
            for k in k_values:
                if b ** k > max_cut_size:
                    continue
                for d in depth_values:
                    rows.append(compute_row(b, k, d, uv_tail_depth, env_tail_depth, model, alpha_env_constant, env_power_p, env_exp_q))
    return rows


def write_csv(rows: list[InvariantRow], path: Path) -> None:
    if not rows:
        raise ValueError("no rows to write")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def parse_int_list(s: str) -> list[int]:
    return [int(x) for x in s.split(",") if x.strip()]


def parse_model_list(s: str) -> list[EnvModel]:
    raw = [x.strip() for x in s.split(",") if x.strip()]
    allowed = {"ladder", "infinite_ladder", "constant", "power", "exponential", "none"}
    bad = [x for x in raw if x not in allowed]
    if bad:
        raise ValueError(f"unknown env model(s): {bad}; allowed={sorted(allowed)}")
    return raw  # type: ignore[return-value]


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--b", type=int, default=3)
    p.add_argument("--k", type=int, default=4)
    p.add_argument("--depth", type=int, default=2)
    p.add_argument("--uv-tail-depth", type=int, default=2)
    p.add_argument("--env-tail-depth", type=int, default=2)
    p.add_argument("--env-model", choices=["ladder", "infinite_ladder", "constant", "power", "exponential", "none"], default="ladder")
    p.add_argument("--alpha-env-constant", type=float, default=1.0)
    p.add_argument("--env-power-p", type=float, default=1.0)
    p.add_argument("--env-exp-q", type=float, default=1.2)
    p.add_argument("--matrix", action="store_true")
    p.add_argument("--b-values", type=str, default="2,3,4,5,6")
    p.add_argument("--k-values", type=str, default="2,3,4,5,6,7,8")
    p.add_argument("--depth-values", type=str, default="1,2,3,4,5,6,7,8,9,10")
    p.add_argument("--env-models", type=str, default="ladder")
    p.add_argument("--max-cut-size", type=int, default=200000)
    p.add_argument("--csv", type=str, default="")
    p.add_argument("--quiet", action="store_true")
    args = p.parse_args()

    if args.matrix:
        rows = matrix(parse_int_list(args.b_values), parse_int_list(args.k_values), parse_int_list(args.depth_values), args.uv_tail_depth, args.env_tail_depth, parse_model_list(args.env_models), args.alpha_env_constant, args.env_power_p, args.env_exp_q, args.max_cut_size)
        if args.csv:
            write_csv(rows, Path(args.csv))
        if not args.quiet:
            print(json.dumps([asdict(r) for r in rows], indent=2))
        return

    row = compute_row(args.b, args.k, args.depth, args.uv_tail_depth, args.env_tail_depth, args.env_model, args.alpha_env_constant, args.env_power_p, args.env_exp_q)  # type: ignore[arg-type]
    print(json.dumps(asdict(row), indent=2))


if __name__ == "__main__":
    main()
