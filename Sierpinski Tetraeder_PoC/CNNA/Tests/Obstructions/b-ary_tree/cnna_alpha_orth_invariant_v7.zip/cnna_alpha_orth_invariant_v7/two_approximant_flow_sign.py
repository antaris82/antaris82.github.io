#!/usr/bin/env python3
"""
Two-approximant flow-sign / chirality diagnostic.

This script tests the minimal parent -> child step. It does NOT model the
full infinite complement family. It uses the same two-port flow reduction as
alpha_orth_invariant.py, with the optional infinite_ladder fixed-point
environment as a diagnostic approximation to an infinite complement ladder.

Core question
-------------
Does the relative sign between parent and child come from fluxes, and is it
chiral or merely radial?

For each approximant the sign of rho is read from the off-diagonal DtN flux
coupling M[0,1]. For a passive unit-edge tree this sign is negative. The
relative sign between parent and child is therefore usually +1: same radial
orientation.

The sibling-permutation test then checks whether this relative sign changes
when the child index is permuted. In the symmetric unit-edge b-ary tree it
should not flip. This is an important negative diagnostic: it means the
parent-child flow sign is radial, not a chiral J vs -J orientation.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

from alpha_orth_invariant import compute_row, EnvModel, sign


@dataclass(frozen=True)
class ChildSignRow:
    b: int
    k: int
    parent_depth: int
    child_depth: int
    child_index: int
    env_model: str
    parent_rho: float
    child_rho: float
    parent_flow_sign: int
    child_flow_sign: int
    relative_sigma_from_flow: int
    parent_cauchy_symplectic_pairing: float
    child_cauchy_symplectic_pairing: float
    chiral_signal_present: bool
    sibling_permutation_flip: bool
    diagnosis: str


def child_row(
    b: int,
    k: int,
    parent_depth: int,
    child_index: int,
    uv_tail_depth: int,
    env_tail_depth: int,
    env_model: EnvModel,
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
) -> ChildSignRow:
    parent = compute_row(b, k, parent_depth, uv_tail_depth, env_tail_depth, env_model, alpha_env_constant, env_power_p, env_exp_q)
    child = compute_row(b, k, parent_depth + 1, uv_tail_depth, env_tail_depth, env_model, alpha_env_constant, env_power_p, env_exp_q)
    rel = parent.rho_sign_from_flow * child.rho_sign_from_flow
    chiral = parent.chiral_signal_present or child.chiral_signal_present
    return ChildSignRow(
        b=b,
        k=k,
        parent_depth=parent_depth,
        child_depth=parent_depth + 1,
        child_index=child_index,
        env_model=env_model,
        parent_rho=parent.rho_M,
        child_rho=child.rho_M,
        parent_flow_sign=parent.rho_sign_from_flow,
        child_flow_sign=child.rho_sign_from_flow,
        relative_sigma_from_flow=rel,
        parent_cauchy_symplectic_pairing=parent.cauchy_symplectic_pairing,
        child_cauchy_symplectic_pairing=child.cauchy_symplectic_pairing,
        chiral_signal_present=chiral,
        sibling_permutation_flip=False,
        diagnosis="pending_sibling_comparison",
    )


def run_test(
    b: int,
    k: int,
    parent_depth: int,
    uv_tail_depth: int,
    env_tail_depth: int,
    env_model: EnvModel,
    alpha_env_constant: float,
    env_power_p: float,
    env_exp_q: float,
) -> list[ChildSignRow]:
    raw = [child_row(b, k, parent_depth, i, uv_tail_depth, env_tail_depth, env_model, alpha_env_constant, env_power_p, env_exp_q) for i in range(b)]
    sigmas = {r.relative_sigma_from_flow for r in raw}
    flip = len(sigmas) > 1
    diagnosis = (
        "chiral_candidate: sibling permutation changes sigma"
        if flip else
        "radial_only: sibling permutation leaves sigma invariant; no J sign solved"
    )
    return [ChildSignRow(**{**asdict(r), "sibling_permutation_flip": flip, "diagnosis": diagnosis}) for r in raw]


def write_csv(rows: list[ChildSignRow], path: Path) -> None:
    if not rows:
        raise ValueError("no rows")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for r in rows:
            writer.writerow(asdict(r))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--b", type=int, default=3)
    p.add_argument("--k", type=int, default=4)
    p.add_argument("--parent-depth", type=int, default=2)
    p.add_argument("--uv-tail-depth", type=int, default=2)
    p.add_argument("--env-tail-depth", type=int, default=2)
    p.add_argument("--env-model", choices=["ladder", "infinite_ladder", "constant", "power", "exponential", "none"], default="infinite_ladder")
    p.add_argument("--alpha-env-constant", type=float, default=1.0)
    p.add_argument("--env-power-p", type=float, default=1.0)
    p.add_argument("--env-exp-q", type=float, default=1.2)
    p.add_argument("--csv", type=str, default="")
    args = p.parse_args()

    rows = run_test(args.b, args.k, args.parent_depth, args.uv_tail_depth, args.env_tail_depth, args.env_model, args.alpha_env_constant, args.env_power_p, args.env_exp_q)  # type: ignore[arg-type]
    if args.csv:
        write_csv(rows, Path(args.csv))
    print(json.dumps([asdict(r) for r in rows], indent=2))


if __name__ == "__main__":
    main()
