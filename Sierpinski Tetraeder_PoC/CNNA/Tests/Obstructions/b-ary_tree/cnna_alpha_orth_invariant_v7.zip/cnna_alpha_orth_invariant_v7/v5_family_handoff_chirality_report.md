# V5 family handoff chirality test report

## b2_ladder

- status: `family_difference_only: cross-graph signal exists but no accepted chirality`
- nonzero pair count: `2`
- sibling flip detected: `False`
- handoff holonomy detected: `False`

## b3_ladder

- status: `family_difference_only: cross-graph signal exists but no accepted chirality`
- nonzero pair count: `3`
- sibling flip detected: `False`
- handoff holonomy detected: `False`

## b3_depth_linear

- status: `family_difference_only: cross-graph signal exists but no accepted chirality`
- nonzero pair count: `3`
- sibling flip detected: `False`
- handoff holonomy detected: `False`

## b3_sibling_index

- status: `label_induced_positive_control: detector sees noncanonical sibling-label asymmetry`
- nonzero pair count: `9`
- sibling flip detected: `False`
- handoff holonomy detected: `False`
- caveat: `WARNING: sibling_index breaks sibling symmetry by label; any positive signal is noncanonical.`


## Interpretation

V5 tests the actual family-level objection to V4. The model has a family of
DtN graphs, not one graph. Therefore V5 computes parent-child and sibling
cross-graph Cauchy pairings and sign-free handoff square tests.

For the canonical symmetric ladder/depth cases, cross-graph family differences
can be nonzero, but they remain nonchiral: there is no accepted sibling flip
and no handoff holonomy. Thus the tested family is not a single graph, but it
still does not force the J sign.

The sibling_index mode is a noncanonical positive-control countermodel. It
breaks sibling symmetry by labels and is not CNNA-derived.
