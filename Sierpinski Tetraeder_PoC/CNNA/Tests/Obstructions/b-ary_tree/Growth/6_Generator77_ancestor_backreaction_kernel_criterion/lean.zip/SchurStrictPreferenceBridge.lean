import CNNA.CutStrictPreferenceBridge
import CNNA.SchurDtnSummary

namespace SchurStrictPreferenceBridge

abbrev SchurSummary := SchurDtnSummary.SchurSummary
abbrev DefectSystem := SectorResolutionGate.DefectSystem


def schurCutHandoffDefectSystem {V : Type}
    (before plusAfter minusAfter : SchurSummary V) : DefectSystem Bool :=
  CutStrictPreferenceBridge.cutHandoffDefectSystem
    (SchurDtnSummary.toCutSummary before)
    (SchurDtnSummary.toCutSummary plusAfter)
    (SchurDtnSummary.toCutSummary minusAfter)


def schurSectorMap : GrowthSectorResolutionBridge.GrowthSectorMap Bool :=
  CutStrictPreferenceBridge.cutSectorMap


structure SchurStrictPreference {V : Type}
    (before plusAfter minusAfter : SchurSummary V) where
  minSet_singleton :
    (schurCutHandoffDefectSystem before plusAfter minusAfter).minSet = [false]


def SchurStrictPreference.toCutStrictPreference {V : Type}
    {before plusAfter minusAfter : SchurSummary V}
    (p : SchurStrictPreference before plusAfter minusAfter) :
    CutStrictPreferenceBridge.CutStrictPreference
      (SchurDtnSummary.toCutSummary before)
      (SchurDtnSummary.toCutSummary plusAfter)
      (SchurDtnSummary.toCutSummary minusAfter) :=
  { minSet_singleton := p.minSet_singleton }


theorem resolved_of_schur_strict_preference {V : Type}
    (before plusAfter minusAfter : SchurSummary V)
    (p : SchurStrictPreference before plusAfter minusAfter) :
    schurSectorMap.hasResolvedJSign
      (schurCutHandoffDefectSystem before plusAfter minusAfter) :=
  CutStrictPreferenceBridge.resolved_of_cut_strict_preference
    (SchurDtnSummary.toCutSummary before)
    (SchurDtnSummary.toCutSummary plusAfter)
    (SchurDtnSummary.toCutSummary minusAfter)
    p.toCutStrictPreference


def schurStrictPreferenceStillRequiresConcreteSchurData : Prop := True


theorem schur_strict_preference_still_requires_concrete_schur_data :
    schurStrictPreferenceStillRequiresConcreteSchurData :=
  True.intro

end SchurStrictPreferenceBridge
