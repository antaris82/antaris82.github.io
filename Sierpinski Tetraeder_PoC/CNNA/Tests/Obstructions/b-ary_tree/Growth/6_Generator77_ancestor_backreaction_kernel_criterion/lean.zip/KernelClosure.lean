/-
  KernelClosure.lean
  ------------------
  Schliessung der Gates K2-K4 fuer den effektiven CNNA-Kernel.
  Aufbauend auf EffectiveKernel.lean (K1, gruen) und Circulation.lean (gruen).
  Selbststaendig kompilierbar (kein Import, kein Mathlib, lean4:v4.28.0).

  ZIEL: Eliminierung der freien Parameter durch kanonische Ableitung.

  (P1) Fasermass μ_y      -> NICHT frei: auf homogenen Gauge-Orbits ist JEDES
       invariante Gewicht konstant; der gewichtete Kern kollabiert auf
       (Gesamtskala) x (Zaehlkern). Gleichzaehlung ist die einzige
       relabeling-invariante Wahl.        [weighted_kernel_canonical]
  (P2) Gewicht W          -> gleicher Satz: W geht nur als Skala W(x₀) ein.
                                           [countW_const, selector_kernel_parameterfree]
  (P3) Selektor S         -> NICHT frei: Aequivarianz erzwingt an
       symmetrischen Zustaenden stabilisator-fixe Attachments; existiert kein
       Fixpunkt, existiert KEIN aequivarianter Selektor -- die Theorie ist
       dort sektoriell (S_b-No-Go in Selektorform).
                                           [selector_fixes_attachment,
                                            no_equivariant_selector_of_no_fixed_point,
                                            sector_example]
  (P4) Projektivitaet     -> der Zwei-Stufen-Schritt ist bewiesen: unter
       uniformer Verfeinerung (Multiplizitaet k) und stufenkompatiblem
       Selektor pushen die Zaehlkerne konsistent (count_{L+1} = k·count_L).
                                           [projective_consistency]

  OFFEN bleibt (ehrlich, am Dateiende): die CNNA-ABLEITUNG von S und W aus
  Schur-DtN-Komplementdaten (der eigentliche Forschungskern), die relativen
  Orbitgewichte bei inhomogenen Fasern, und der unendliche projektive Limes
  (hier nur der Einzelschritt).
-/

namespace KernelClosure

variable {X Y A : Type}

/-! ## 0. Basis (Kopien der gruen kompilierten Helfer aus EffectiveKernel) -/

/-- Faser der Projektion `π` ueber `y` (bright-unsichtbarer Komplementanteil). -/
def fiber [DecidableEq Y] (π : X → Y) (Xs : List X) (y : Y) : List X :=
  Xs.filter (fun x => π x == y)

/-- Summe einer konstant-0-Map ist 0. -/
theorem sum_map_const_zero {B : Type} (Bs : List B) :
    (Bs.map (fun _ => (0 : Nat))).sum = 0 := by
  induction Bs with
  | nil => rfl
  | cons a Bs ih => rw [List.map_cons, List.sum_cons, ih]

/-- Summen-Splitting `Σ (q + w) = Σ q + Σ w` (allgemeine Form). -/
theorem sum_map_add_split {B : Type} (Bs : List B) (q w : B → Nat) :
    (Bs.map (fun b => q b + w b)).sum = (Bs.map q).sum + (Bs.map w).sum := by
  induction Bs with
  | nil => rfl
  | cons a Bs ih =>
      rw [List.map_cons, List.map_cons, List.map_cons,
          List.sum_cons, List.sum_cons, List.sum_cons, ih]
      omega

/-- Ist `v` NICHT in `Bs`, summieren die 1-Indikatoren zu 0. -/
theorem sum_indicator_eq_zero {B : Type} [DecidableEq B]
    (Bs : List B) (v : B) (hnotmem : ¬ v ∈ Bs) :
    (Bs.map (fun b => if (v == b) = true then 1 else 0)).sum = 0 := by
  induction Bs with
  | nil => rfl
  | cons a Bs ih =>
      have hva : ¬ v = a := by
        intro he; exact hnotmem (he ▸ List.mem_cons_self ..)
      have hnm : ¬ v ∈ Bs := by
        intro hm; exact hnotmem (List.mem_cons_of_mem _ hm)
      have hne : (v == a) = false := by
        simp [beq_eq_false_iff_ne, hva]
      rw [List.map_cons, List.sum_cons, hne, ih hnm]
      decide

/-- Summe der 1-Indikatoren ueber eine nodup-Liste, die `v` enthaelt, ist 1. -/
theorem sum_indicator_eq_one {B : Type} [DecidableEq B]
    (Bs : List B) (v : B) (hmem : v ∈ Bs) (hnodup : Bs.Nodup) :
    (Bs.map (fun b => if (v == b) = true then 1 else 0)).sum = 1 := by
  induction Bs with
  | nil => exact absurd hmem (List.not_mem_nil)
  | cons a Bs ih =>
      rw [List.nodup_cons] at hnodup
      obtain ⟨hane, hnd⟩ := hnodup
      rw [List.map_cons, List.sum_cons]
      by_cases h : v = a
      · subst h
        have hone : (v == v) = true := by simp
        rw [hone, sum_indicator_eq_zero Bs v hane]
        decide
      · have hmem' : v ∈ Bs := by
          cases List.mem_cons.mp hmem with
          | inl he => exact absurd he h
          | inr ht => exact ht
        have hne : (v == a) = false := by
          simp [beq_eq_false_iff_ne, h]
        rw [hne, ih hmem' hnd]
        decide

/-! ## K1'. Verallgemeinerte Massenerhaltung (Partitionssatz)

    Verallgemeinert `mass_conservation` aus EffectiveKernel.lean von der
    speziellen Klassifikation `π ∘ F` auf eine BELIEBIGE Klassifikation
    `f : X → B`. Daraus folgen Massenerhaltung des Dynamik-Kerns (f = π∘F)
    UND des Selektor-Kerns (f = S) als Instanzen EINES Satzes. -/

theorem countP_partition {B : Type} [DecidableEq B]
    (f : X → B) (Bs : List B) (hnodup : Bs.Nodup) :
    ∀ l : List X, (∀ x ∈ l, f x ∈ Bs) →
      (Bs.map (fun b => l.countP (fun x => f x == b))).sum = l.length := by
  intro l hl
  induction l with
  | nil =>
      simp only [List.countP_nil]
      exact sum_map_const_zero Bs
  | cons a l ih =>
      have hmem : f a ∈ Bs := hl a (List.mem_cons_self ..)
      have htail : ∀ x ∈ l, f x ∈ Bs := fun x hx => hl x (List.mem_cons_of_mem _ hx)
      show (Bs.map (fun b => (a :: l).countP (fun x => f x == b))).sum
            = l.length + 1
      simp only [List.countP_cons]
      rw [sum_map_add_split Bs
            (fun b => l.countP (fun x => f x == b))
            (fun b => if (f a == b) = true then 1 else 0),
          ih htail,
          sum_indicator_eq_one Bs (f a) hmem hnodup]

/-! ## K2. Gewichteter Kern und seine Kanonisierung

    Gewichtetes Zaehlen `countW` (Bruecke zu Schur-DtN-Gewichten), gewichtete
    Massenerhaltung, und der KANONIZITAETSSATZ: auf homogenen Gauge-Orbits
    kollabiert jedes invariante Gewicht auf eine Gesamtskala -- der freie
    Parameter W ist eliminiert, Gleichzaehlung ist die einzige invariante Wahl. -/

/-- Gewichteter Zaehler: Summe der Gewichte der Elemente, die `p` erfuellen. -/
def countW (W : X → Nat) (p : X → Bool) : List X → Nat
  | []     => 0
  | x :: l => countW W p l + (if p x = true then W x else 0)

@[simp] theorem countW_nil (W : X → Nat) (p : X → Bool) :
    countW W p ([] : List X) = 0 := rfl

@[simp] theorem countW_cons (W : X → Nat) (p : X → Bool) (a : X) (l : List X) :
    countW W p (a :: l) = countW W p l + (if p a = true then W a else 0) := rfl

/-- Gesamtgewicht einer Liste. -/
def totalW (W : X → Nat) : List X → Nat
  | []     => 0
  | x :: l => W x + totalW W l

/-- Gewichteter Uebergangs-Count des effektiven Kerns. -/
def wcount [DecidableEq Y] (π : X → Y) (F : X → X) (W : X → Nat)
    (Xs : List X) (y y' : Y) : Nat :=
  countW W (fun x => π (F x) == y') (fiber π Xs y)

/-- Gewichtete Indikatorsumme: `v ∉ Bs` ⇒ 0. -/
theorem sum_windicator_zero {B : Type} [DecidableEq B]
    (Bs : List B) (v : B) (w : Nat) (hnotmem : ¬ v ∈ Bs) :
    (Bs.map (fun b => if (v == b) = true then w else 0)).sum = 0 := by
  induction Bs with
  | nil => rfl
  | cons a Bs ih =>
      have hva : ¬ v = a := by
        intro he; exact hnotmem (he ▸ List.mem_cons_self ..)
      have hnm : ¬ v ∈ Bs := by
        intro hm; exact hnotmem (List.mem_cons_of_mem _ hm)
      have hne : (v == a) = false := by
        simp [beq_eq_false_iff_ne, hva]
      rw [List.map_cons, List.sum_cons, hne,
          if_neg (by decide : ¬ (false = true)), ih hnm]

/-- Gewichtete Indikatorsumme: `v ∈ Bs` nodup ⇒ genau `w`. -/
theorem sum_windicator_eq {B : Type} [DecidableEq B]
    (Bs : List B) (v : B) (w : Nat) (hmem : v ∈ Bs) (hnodup : Bs.Nodup) :
    (Bs.map (fun b => if (v == b) = true then w else 0)).sum = w := by
  induction Bs with
  | nil => exact absurd hmem (List.not_mem_nil)
  | cons a Bs ih =>
      rw [List.nodup_cons] at hnodup
      obtain ⟨hane, hnd⟩ := hnodup
      rw [List.map_cons, List.sum_cons]
      by_cases h : v = a
      · subst h
        have hone : (v == v) = true := by simp
        rw [hone, if_pos (rfl : (true = true)), sum_windicator_zero Bs v w hane]
        rw [Nat.add_zero]
      · have hmem' : v ∈ Bs := by
          cases List.mem_cons.mp hmem with
          | inl he => exact absurd he h
          | inr ht => exact ht
        have hne : (v == a) = false := by
          simp [beq_eq_false_iff_ne, h]
        rw [hne, if_neg (by decide : ¬ (false = true)), ih hmem' hnd]
        rw [Nat.zero_add]

/-- K2-Massenerhaltung: die gewichteten Uebergangs-Counts einer bright-Zeile
    summieren zum Gesamtgewicht der Faser. -/
theorem wmass_conservation [DecidableEq Y]
    (π : X → Y) (F : X → X) (W : X → Nat) (Xs : List X) (y : Y) (Ys : List Y)
    (hcover : ∀ x ∈ fiber π Xs y, π (F x) ∈ Ys)
    (hnodup : Ys.Nodup) :
    (Ys.map (fun y' => wcount π F W Xs y y')).sum = totalW W (fiber π Xs y) := by
  unfold wcount
  have key : ∀ (l : List X), (∀ x ∈ l, π (F x) ∈ Ys) →
      (Ys.map (fun y' => countW W (fun x => π (F x) == y') l)).sum
        = totalW W l := by
    intro l hl
    induction l with
    | nil =>
        simp only [countW_nil]
        exact sum_map_const_zero Ys
    | cons a l ih =>
        have hmem : π (F a) ∈ Ys := hl a (List.mem_cons_self ..)
        have htail : ∀ x ∈ l, π (F x) ∈ Ys :=
          fun x hx => hl x (List.mem_cons_of_mem _ hx)
        show (Ys.map (fun y' => countW W (fun x => π (F x) == y') (a :: l))).sum
              = W a + totalW W l
        simp only [countW_cons]
        rw [sum_map_add_split Ys
              (fun y' => countW W (fun x => π (F x) == y') l)
              (fun y' => if (π (F a) == y') = true then W a else 0),
            ih htail,
            sum_windicator_eq Ys (π (F a)) (W a) hmem hnodup,
            Nat.add_comm (totalW W l) (W a)]
  exact key (fiber π Xs y) hcover

/-- Spezialfall: konstantes Gewicht 1 reduziert auf den Zaehl-Count
    (Anschluss an EffectiveKernel.count). -/
theorem countW_one_eq_countP (p : X → Bool) :
    ∀ l : List X, countW (fun _ => 1) p l = l.countP p := by
  intro l
  induction l with
  | nil => rfl
  | cons a l ih => rw [countW_cons, List.countP_cons, ih]

/-- Konstantes Gewicht c auf l ⇒ gewichteter Count = c · Zaehl-Count. -/
theorem countW_const (W : X → Nat) (p : X → Bool) :
    ∀ (l : List X) (c : Nat), (∀ x ∈ l, W x = c) →
      countW W p l = c * l.countP p := by
  intro l c h
  induction l with
  | nil => rfl
  | cons a l ih =>
      have ha : W a = c := h a (List.mem_cons_self ..)
      have hl : ∀ x ∈ l, W x = c := fun x hx => h x (List.mem_cons_of_mem _ hx)
      rw [countW_cons, List.countP_cons, ih hl, ha, Nat.mul_add]
      by_cases hp : p a = true
      · rw [if_pos hp, if_pos hp, Nat.mul_one]
      · rw [if_neg hp, if_neg hp, Nat.mul_zero]

/-- Transitive Gauge-Wirkung auf einer Liste: je zwei Elemente sind durch eine
    W-invariante Symmetrie verbunden (homogener Orbit). -/
def TransitiveInvariant (W : X → Nat) (l : List X) : Prop :=
  ∀ x₁ ∈ l, ∀ x₂ ∈ l, ∃ σ : X → X, (∀ x, W (σ x) = W x) ∧ σ x₁ = x₂

/-- Auf einem homogenen Orbit ist jedes invariante Gewicht konstant. -/
theorem weight_const_of_transitive (W : X → Nat) (l : List X)
    (h : TransitiveInvariant W l) (x₀ : X) (hx₀ : x₀ ∈ l) :
    ∀ x ∈ l, W x = W x₀ := by
  intro x hx
  obtain ⟨σ, hinv, hmap⟩ := h x hx x₀ hx₀
  rw [← hmap, hinv x]

/-- KANONIZITAETSSATZ (P1/P2, Eliminierung des freien Parameters W):
    Ist die Komplementfaser ein homogener Gauge-Orbit und W gauge-invariant,
    so ist der gewichtete Kern W(x₀) · Zaehlkern. Jedes invariante Gewicht
    unterscheidet sich vom uniformen Zaehlmass nur um die Gesamtskala --
    die normalisierte Gleichzaehlung ist die EINZIGE invariante Wahl. -/
theorem weighted_kernel_canonical [DecidableEq Y]
    (π : X → Y) (F : X → X) (W : X → Nat) (Xs : List X) (y y' : Y)
    (x₀ : X) (hx₀ : x₀ ∈ fiber π Xs y)
    (htrans : TransitiveInvariant W (fiber π Xs y)) :
    wcount π F W Xs y y'
      = W x₀ * ((fiber π Xs y).countP (fun x => π (F x) == y')) := by
  unfold wcount
  exact countW_const W (fun x => π (F x) == y') (fiber π Xs y) (W x₀)
        (weight_const_of_transitive W (fiber π Xs y) htrans x₀ hx₀)

/-! ## K3. Deterministischer Selektor und Sektoren-Obstruktion

    Die Einzelrealisierung wird nicht gewuerfelt: α = S(X) ist
    dark-complement-determiniert. Der bright-effektive Attachment-Kernel ist
    der Pushforward des Fasermasses unter S (hier definitionell, 5.4).
    Die Kanonizitaet von S wird durch Aequivarianz erzwungen -- inklusive der
    Obstruktion: an symmetrischen Zustaenden ohne fixes Attachment existiert
    KEIN aequivarianter Selektor (Sektorstruktur, 5.3). -/

/-- Selektor-Count: Pushforward des Zaehlmasses unter S — wie viele
    Komplementzustaende der Faser waehlen Attachment α (Gate 5.4,
    hier per Definition erfuellt). -/
def selCount [DecidableEq Y] [DecidableEq A] (π : X → Y) (S : X → A)
    (Xs : List X) (y : Y) (α : A) : Nat :=
  (fiber π Xs y).countP (fun x => S x == α)

/-- K3-Massenerhaltung: Instanz des Partitionssatzes mit f = S. -/
theorem sel_mass_conservation [DecidableEq Y] [DecidableEq A]
    (π : X → Y) (S : X → A) (Xs : List X) (y : Y) (As : List A)
    (hcover : ∀ x ∈ fiber π Xs y, S x ∈ As) (hnodup : As.Nodup) :
    (As.map (fun α => selCount π S Xs y α)).sum = (fiber π Xs y).length := by
  unfold selCount
  exact countP_partition S As hnodup (fiber π Xs y) hcover

/-- Singleton-Faser ⇒ deterministischer Selektor-Kern (Punktmass). -/
theorem selCount_singleton [DecidableEq Y] [DecidableEq A]
    (π : X → Y) (S : X → A) (Xs : List X) (y : Y) (α : A) (x₀ : X)
    (h : fiber π Xs y = [x₀]) :
    selCount π S Xs y α = (if S x₀ == α then 1 else 0) := by
  unfold selCount
  rw [h]
  simp [List.countP_cons]

/-- Relabeling-Natuerlichkeit des Selektor-Kerns (Spiegel des gruen
    kompilierten `count_equivariant`, mit S statt π∘F). -/
theorem selCount_equivariant [DecidableEq Y] [DecidableEq A]
    (π : X → Y) (S : X → A) (σ : X → X) (g : Y → Y) (gA : A → A)
    (hgA : Function.Injective gA)
    (hS : ∀ x, S (σ x) = gA (S x))
    (Xs : List X) (y : Y) (α : A)
    (hperm : (Xs.filter (fun x => π x == g y))
              = (Xs.filter (fun x => π x == y)).map σ) :
    selCount π S Xs (g y) (gA α) = selCount π S Xs y α := by
  unfold selCount fiber
  rw [hperm, List.countP_map]
  apply List.countP_congr
  intro x _
  rw [Function.comp_apply, hS x]
  by_cases h : S x = α
  · simp [h]
  · have hne : gA (S x) ≠ gA α := fun he => h (hgA he)
    simp [h, hne]

/-- Aequivarianter Selektor (Gate 5.1): S(σ x) = g(S x). -/
def SelectorEquivariant (S : X → A) (σ : X → X) (g : A → A) : Prop :=
  ∀ x, S (σ x) = g (S x)

/-- DEGENERATIE-ZWANG (Gate 5.3): Fixiert eine Symmetrie σ den Zustand x,
    so muss ein aequivarianter Selektor ein g-fixes Attachment waehlen. -/
theorem selector_fixes_attachment (S : X → A) (σ : X → X) (g : A → A)
    (heq : SelectorEquivariant S σ g) (x : X) (hfix : σ x = x) :
    g (S x) = S x := by
  have h := heq x
  rw [hfix] at h
  exact h.symm

/-- SEKTOREN-OBSTRUKTION (P3): Existiert an einem σ-fixen Zustand kein
    g-Fixpunkt unter den Attachments, so existiert KEIN aequivarianter
    Selektor. Die Theorie ist dort zwingend sektoriell -- der S_b-No-Go in
    Selektorform: keine lexikographische, keine links/rechts-Wahl moeglich. -/
theorem no_equivariant_selector_of_no_fixed_point
    (σ : X → X) (g : A → A) (x : X) (hfix : σ x = x)
    (hnofix : ∀ α : A, g α ≠ α) :
    ¬ ∃ S : X → A, SelectorEquivariant S σ g := by
  intro ⟨S, heq⟩
  exact hnofix (S x) (selector_fixes_attachment S σ g heq x hfix)

/-- Konkretes Z₂-Beispiel: zwei vertauschbare Attachments. -/
def swapA : Fin 2 → Fin 2
  | 0 => 1
  | 1 => 0
  | _ => 0

theorem swapA_no_fixed : ∀ α : Fin 2, swapA α ≠ α := by decide

/-- SEKTOR-ZEUGE: Ein exakt symmetrischer Zustand (σ = id fixiert alles) mit
    zwei vertauschbaren Attachments laesst KEINEN aequivarianten
    deterministischen Selektor zu. Genau hier beginnt die Sektorstruktur. -/
theorem sector_example :
    ¬ ∃ S : Unit → Fin 2, SelectorEquivariant S id swapA :=
  no_equivariant_selector_of_no_fixed_point id swapA () rfl swapA_no_fixed

/-- Gewichteter Selektor-Kern (K2 x K3). -/
def selWCount [DecidableEq Y] [DecidableEq A] (π : X → Y) (S : X → A)
    (W : X → Nat) (Xs : List X) (y : Y) (α : A) : Nat :=
  countW W (fun x => S x == α) (fiber π Xs y)

/-- VOLLSTAENDIGE K2/K3-SCHLIESSUNG (parameterfrei): Auf homogenem Gauge-Orbit
    ist der gewichtete Selektor-Kern W(x₀) · Zaehl-Selektor-Kern. Mit
    sel_mass_conservation und selCount_equivariant ist der effektive
    Attachment-Kernel damit durch (X, F, π, S) und eine Gesamtskala
    VOLLSTAENDIG bestimmt -- keine freien Masse, keine freien Gewichte. -/
theorem selector_kernel_parameterfree [DecidableEq Y] [DecidableEq A]
    (π : X → Y) (S : X → A) (W : X → Nat) (Xs : List X) (y : Y) (α : A)
    (x₀ : X) (hx₀ : x₀ ∈ fiber π Xs y)
    (htrans : TransitiveInvariant W (fiber π Xs y)) :
    selWCount π S W Xs y α = W x₀ * selCount π S Xs y α := by
  unfold selWCount selCount
  exact countW_const W (fun x => S x == α) (fiber π Xs y) (W x₀)
        (weight_const_of_transitive W (fiber π Xs y) htrans x₀ hx₀)

/-! ## K4. Projektive Konsistenz (Zwei-Stufen-Schritt)

    Verfeinert jeder Faserzustand der Stufe L zu genau k Zustaenden der
    Stufe L+1 und ist der Selektor stufenkompatibel, so pushen die
    Attachment-Counts konsistent: count_{L+1} = k · count_L. Das Zaehlmass
    erfuellt die Projektivitaetsbedingung; der Grenzuebergang ist auf
    Count-Ebene wohldefiniert. -/

/-- Hilfssatz: erfuellt jedes Element das Praedikat, ist countP = Laenge. -/
theorem countP_const_true {Z : Type} (q : Z → Bool) :
    ∀ l : List Z, (∀ z ∈ l, q z = true) → l.countP q = l.length := by
  intro l h
  induction l with
  | nil => rfl
  | cons a l ih =>
      have ha : q a = true := h a (List.mem_cons_self ..)
      have hl : ∀ z ∈ l, q z = true := fun z hz => h z (List.mem_cons_of_mem _ hz)
      show (a :: l).countP q = l.length + 1
      rw [List.countP_cons, ih hl, if_pos ha]

/-- Hilfssatz: erfuellt kein Element das Praedikat, ist countP = 0. -/
theorem countP_const_false {Z : Type} (q : Z → Bool) :
    ∀ l : List Z, (∀ z ∈ l, q z = false) → l.countP q = 0 := by
  intro l h
  induction l with
  | nil => rfl
  | cons a l ih =>
      have ha : q a = false := h a (List.mem_cons_self ..)
      have hl : ∀ z ∈ l, q z = false := fun z hz => h z (List.mem_cons_of_mem _ hz)
      rw [List.countP_cons, ih hl, if_neg (by rw [ha]; decide)]

/-- K4-Kernlemma: countP auf uniform verfeinerter Liste (jeder Basispunkt
    durch k Verfeinerungen ersetzt, Praedikat blockkonstant)
    = k · countP der Basis. -/
theorem countP_flatMap_const {X₁ X₂ : Type}
    (r : X₁ → List X₂) (q₂ : X₂ → Bool) (q₁ : X₁ → Bool) (k : Nat) :
    ∀ l : List X₁,
      (∀ x ∈ l, (r x).length = k) →
      (∀ x ∈ l, ∀ z ∈ r x, q₂ z = q₁ x) →
      (l.flatMap r).countP q₂ = k * l.countP q₁ := by
  intro l hlen hpred
  induction l with
  | nil => rfl
  | cons a l ih =>
      have hla : (r a).length = k := hlen a (List.mem_cons_self ..)
      have hpa : ∀ z ∈ r a, q₂ z = q₁ a :=
        fun z hz => hpred a (List.mem_cons_self ..) z hz
      have hlent : ∀ x ∈ l, (r x).length = k :=
        fun x hx => hlen x (List.mem_cons_of_mem _ hx)
      have hpredt : ∀ x ∈ l, ∀ z ∈ r x, q₂ z = q₁ x :=
        fun x hx => hpred x (List.mem_cons_of_mem _ hx)
      rw [List.flatMap_cons, List.countP_append, ih hlent hpredt,
          List.countP_cons, Nat.mul_add]
      by_cases hq : q₁ a = true
      · have hall : ∀ z ∈ r a, q₂ z = true := fun z hz => by rw [hpa z hz, hq]
        rw [countP_const_true q₂ (r a) hall, hla, if_pos hq, Nat.mul_one,
            Nat.add_comm k (k * l.countP q₁)]
      · have hall : ∀ z ∈ r a, q₂ z = false := by
          intro z hz
          rw [hpa z hz]
          cases hqa : q₁ a with
          | true => exact absurd hqa hq
          | false => rfl
        rw [countP_const_false q₂ (r a) hall, if_neg hq, Nat.mul_zero,
            Nat.add_zero, Nat.zero_add]

/-- PROJEKTIVE KONSISTENZ (P4): Stimmen Stufenfaser, Verfeinerungslaenge und
    Selektor zusammen (S₂ = S₁ auf den Bloecken), so gilt
    selCount_{L+1} = k · selCount_L. Das normalisierte Zaehlmass ist unter
    Verfeinerung invariant -- die Projektivitaetsbedingung des Dokuments,
    bewiesen fuer den Einzelschritt. -/
theorem projective_consistency {X₁ X₂ : Type} [DecidableEq Y] [DecidableEq A]
    (π₁ : X₁ → Y) (π₂ : X₂ → Y) (S₁ : X₁ → A) (S₂ : X₂ → A)
    (Xs₁ : List X₁) (Xs₂ : List X₂) (y : Y) (α : A)
    (r : X₁ → List X₂) (k : Nat)
    (hfib : fiber π₂ Xs₂ y = (fiber π₁ Xs₁ y).flatMap r)
    (hlen : ∀ x ∈ fiber π₁ Xs₁ y, (r x).length = k)
    (hsel : ∀ x ∈ fiber π₁ Xs₁ y, ∀ z ∈ r x, S₂ z = S₁ x) :
    selCount π₂ S₂ Xs₂ y α = k * selCount π₁ S₁ Xs₁ y α := by
  unfold selCount
  rw [hfib]
  exact countP_flatMap_const r (fun z => S₂ z == α) (fun x => S₁ x == α) k
        (fiber π₁ Xs₁ y) hlen
        (fun x hx z hz => by simp [hsel x hx z hz])

end KernelClosure

/-
  OPEN (ehrlich ausgewiesen, der eigentliche Forschungskern):

  (C-O1) Schur-DtN ⇒ W und S: Die Saetze hier zeigen, WELCHE Eigenschaften
         jedes zulaessige (W, S) haben muss (Invarianz, Aequivarianz,
         Fixpunkt-Zwang) und dass W auf homogenen Orbits zur Skala kollabiert.
         Die konstruktive Ableitung eines nichttrivialen S (z.B. minimaler
         Handoff-Defekt, maximaler Komplementausgleich) aus Schur-DtN-Daten
         ist offen -- inkl. Degeneratiebehandlung per Sektorstruktur statt
         willkuerlichem Bruch (sector_example zeigt, dass der Bruch
         unmoeglich, nicht nur unschoen ist).

  (C-O2) Inhomogene Fasern: Zerfaellt die Faser in mehrere Gauge-Orbits
         O_i, sind die internen Verteilungen kanonisch (weighted_kernel_
         canonical orbitweise), die relativen Gewichte w_i aber nicht --
         sie muessten aus CNNA-Daten (z.B. DtN-Kapazitaeten) kommen.

  (C-O3) Unendlicher projektiver Limes: Bewiesen ist der Einzelschritt
         (projective_consistency). Der Limes lim_L μ_{y,L} braucht eine
         Grenzkonstruktion (Kolmogorov-artig) -> spaeter, ggf. Mathlib.

  (C-O4) Markov-Schliessung: bleibt wie in EffectiveKernel.lean (Gate S7)
         eine Zusatzannahme; hier nicht beruehrt.
-/
