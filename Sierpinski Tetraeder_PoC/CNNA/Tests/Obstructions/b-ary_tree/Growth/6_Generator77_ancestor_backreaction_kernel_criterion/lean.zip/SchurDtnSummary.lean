import CNNA.FiniteCutCombinatorics

/-
  SchurDtnSummary.lean
  --------------------
  Abstrakte Schur-DtN-Summary-Schicht.

  Diese Datei fuehrt noch keine allgemeine Matrixinverse ein. Sie bindet
  stattdessen einen bereits berechneten endlichen Schur-DtN-Trace und einen
  Schur-Cut-Defekt an die vorhandene FiniteCut-Schicht an.

  Zweck:

    FiniteCut
      -> SchurSummary
      -> CutSummary
      -> HandoffData
      -> DefectVector.

  Damit wird der fruehere Proxy-Trace aus FiniteCutCombinatorics durch einen
  expliziten Schur-DtN-Summary-Port ersetzt, ohne einen freien Selector, ein
  freies Gewicht, eine Temperatur oder ein Inversen-Orakel einzufuehren.
-/

namespace SchurDtnSummary

/-- Ein endlicher Cut zusammen mit einer bereits berechneten Schur-DtN-Summary.
    `schurDtnTrace` ist der Summary-Port fuer die naechste, tiefere Schicht.
    `schurCutDefect` misst, ob der Schur-Interiorblock auf Summary-Ebene
    als zulaessig gilt. -/
structure SchurSummary (V : Type) where
  cut : FiniteCutCombinatorics.FiniteCut V
  schurDtnTrace : Nat
  schurCutDefect : Nat

/-- Proxy-Einbettung: die fruehere rein kombinatorische Cut-Summary wird als
    SchurSummary gelesen. Dieser Konstruktor setzt nichts Neues, sondern nutzt
    genau die bisherigen Proxy-Werte. -/
def fromFiniteCutProxy {V : Type}
    (c : FiniteCutCombinatorics.FiniteCut V) : SchurSummary V :=
  { cut := c,
    schurDtnTrace := FiniteCutCombinatorics.dtnTraceProxy c,
    schurCutDefect := FiniteCutCombinatorics.cutKernelDefect c }

/-- Der Schur-DtN-Summary-Adapter ueberschreibt nur den DtN-Trace und den
    Cut-Defekt. Alle uebrigen Summary-Felder stammen weiter kanonisch aus der
    endlichen Cut-Kombinatorik. -/
def toCutSummary {V : Type} (s : SchurSummary V) :
    FiniteHandoffSummary.CutSummary :=
  { boundarySize := s.cut.boundary.length,
    interiorSize := s.cut.interior.length,
    dtnTrace := s.schurDtnTrace,
    uvBoundaryLoad := s.cut.uvBoundary.length,
    envBoundaryLoad := s.cut.envBoundary.length,
    cutKernelDefect := s.schurCutDefect,
    recordSignature := FiniteCutCombinatorics.recordSignature s.cut,
    complementSignature := FiniteCutCombinatorics.complementSignature s.cut }

/-- Paarweiser Handoff aus zwei Schur-Summaries. -/
def toHandoffData {V : Type} (before after : SchurSummary V) :
    FiniteHandoffSummary.HandoffData :=
  FiniteHandoffSummary.toHandoffData
    (toCutSummary before) (toCutSummary after)

/-- Defektvektor des Schur-Summary-Handoffs. -/
def toDefectVector {V : Type} (before after : SchurSummary V) : List Nat :=
  FiniteHandoffSummary.toDefectVector
    (toCutSummary before) (toCutSummary after)

/-! ## Definitorische Link-Saetze -/

theorem toCutSummary_boundarySize {V : Type} (s : SchurSummary V) :
    (toCutSummary s).boundarySize = s.cut.boundary.length := rfl

theorem toCutSummary_interiorSize {V : Type} (s : SchurSummary V) :
    (toCutSummary s).interiorSize = s.cut.interior.length := rfl

theorem toCutSummary_dtnTrace {V : Type} (s : SchurSummary V) :
    (toCutSummary s).dtnTrace = s.schurDtnTrace := rfl

theorem toCutSummary_cutDefect {V : Type} (s : SchurSummary V) :
    (toCutSummary s).cutKernelDefect = s.schurCutDefect := rfl

theorem toCutSummary_uvLoad {V : Type} (s : SchurSummary V) :
    (toCutSummary s).uvBoundaryLoad = s.cut.uvBoundary.length := rfl

theorem toCutSummary_envLoad {V : Type} (s : SchurSummary V) :
    (toCutSummary s).envBoundaryLoad = s.cut.envBoundary.length := rfl

/-- Die Proxy-Einbettung reproduziert exakt die bisherige FiniteCut-Summary. -/
theorem toCutSummary_fromFiniteCutProxy {V : Type}
    (c : FiniteCutCombinatorics.FiniteCut V) :
    toCutSummary (fromFiniteCutProxy c) =
      FiniteCutCombinatorics.toCutSummary c := rfl

/-- Der neue Schur-Pfad reduziert im Proxyfall auf den alten FiniteCut-Pfad. -/
theorem toDefectVector_fromFiniteCutProxy {V : Type}
    (before after : FiniteCutCombinatorics.FiniteCut V) :
    toDefectVector (fromFiniteCutProxy before) (fromFiniteCutProxy after) =
      FiniteCutCombinatorics.toDefectVector before after := rfl

/-- Link zur vorherigen Summary-Schicht. -/
theorem toDefectVector_link {V : Type}
    (before after : SchurSummary V) :
    toDefectVector before after =
      FiniteHandoffSummary.toDefectVector
        (toCutSummary before) (toCutSummary after) := rfl

/-- Explizite Gestalt des parameterfreien Defektvektors. -/
theorem toDefectVector_unfold {V : Type}
    (before after : SchurSummary V) :
    toDefectVector before after =
      [after.schurCutDefect,
       FiniteHandoffSummary.absDiff before.schurDtnTrace after.schurDtnTrace,
       FiniteHandoffSummary.absDiff
         (FiniteCutCombinatorics.recordSignature before.cut)
         (FiniteCutCombinatorics.recordSignature after.cut),
       FiniteHandoffSummary.absDiff
         after.cut.uvBoundary.length after.cut.envBoundary.length,
       FiniteHandoffSummary.absDiff
         (FiniteCutCombinatorics.complementSignature before.cut)
         (FiniteCutCombinatorics.complementSignature after.cut)] := by
  unfold toDefectVector
  exact FiniteHandoffSummary.toDefectVector_unfold
    (toCutSummary before) (toCutSummary after)

/-! ## Null-Defekt-Gates -/

def SameSchurTrace {V : Type} (before after : SchurSummary V) : Prop :=
  before.schurDtnTrace = after.schurDtnTrace

def SchurCutOk {V : Type} (s : SchurSummary V) : Prop :=
  s.schurCutDefect = 0

def LoadsBalanced {V : Type} (s : SchurSummary V) : Prop :=
  s.cut.uvBoundary.length = s.cut.envBoundary.length

/-- Stabiler Schur-DtN-Trace erzeugt keinen DtN-Defekt. -/
theorem dtn_defect_zero_of_same_schur_trace {V : Type}
    (before after : SchurSummary V) (h : SameSchurTrace before after) :
    FiniteHandoffSummary.dtnDefect (toHandoffData before after) = 0 := by
  unfold SameSchurTrace at h
  exact FiniteHandoffSummary.dtnDefect_zero_of_stable
    (toCutSummary before) (toCutSummary after) h

/-- Ein Schur-zulaessiger After-Cut erzeugt keinen Cut-Defekt. -/
theorem cut_defect_zero_of_schur_ok {V : Type}
    (before after : SchurSummary V) (h : SchurCutOk after) :
    (toHandoffData before after).cutDefect = 0 := by
  unfold SchurCutOk at h
  exact h

/-- Balancierte UV- und Environment-Loads erzeugen keinen Balance-Defekt. -/
theorem balance_defect_zero_of_loads_balanced {V : Type}
    (before after : SchurSummary V) (h : LoadsBalanced after) :
    FiniteHandoffSummary.balanceDefect (toHandoffData before after) = 0 := by
  unfold LoadsBalanced at h
  unfold toHandoffData toCutSummary
  exact FiniteHandoffSummary.balanceDefect_zero_of_balanced
    (toCutSummary before) (toCutSummary after) h

/-- Der reine Proxy-Fall ist exakt die alte kombinatorische Summary-Schicht. -/
theorem proxy_handoff_link {V : Type}
    (before after : FiniteCutCombinatorics.FiniteCut V) :
    toHandoffData (fromFiniteCutProxy before) (fromFiniteCutProxy after) =
      FiniteCutCombinatorics.toHandoffData before after := rfl

end SchurDtnSummary
