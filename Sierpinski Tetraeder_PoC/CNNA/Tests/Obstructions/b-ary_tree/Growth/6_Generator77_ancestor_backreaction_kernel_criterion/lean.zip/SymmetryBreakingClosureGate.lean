import CNNA.SymmetrySectorNoGo

/-
  SymmetryBreakingClosureGate.lean
  --------------------------------
  Positives Gegen-Gate zum SymmetrySectorNoGo.

  Diese Datei setzt keine Symmetriebrechung. Sie formuliert nur das Gate:

    Wenn ein CNNA-derived Datum das Pareto-Minset auf genau einen Sektor
    reduziert, dann ist der Lock-Pushforward ein singleton-Sektor und das
    formale J-Sign-Closure-Kriterium ist erfuellt.

  Die eigentliche Ableitung dieses Datums aus Schur-DtN-Komplementdaten bleibt
  offen. Kein freier Selector, kein Tie-Break, keine freie Orientierung.
-/

namespace SymmetryBreakingClosureGate

abbrev DefectSystem := SectorResolutionGate.DefectSystem
abbrev LockCandidate := JLockingGate.LockCandidate

/-- Ein symmetry-breaking datum ist hier kein gesetzter Selector, sondern nur
    ein Zeuge, dass das bereits kanonisch berechnete Minset ein Singleton ist. -/
structure SymmetryBreakingDatum {A : Type} (D : DefectSystem A) where
  selected : A
  minSet_singleton : D.minSet = [selected]

/-- Das Datum resolved das J-Sign fuer jeden gegebenen Lock-Pushforward. -/
theorem resolved_of_symmetry_breaking_datum {A : Type}
    (D : DefectSystem A) (lockOf : A -> LockCandidate)
    (datum : SymmetryBreakingDatum D) :
    SectorResolutionGate.hasResolvedJSign D lockOf :=
  UniqueLockSectorClosure.resolved_of_minSet_singleton
    D lockOf datum.selected datum.minSet_singleton

/-- GrowthSectorMap-Variante desselben Gates. -/
theorem growth_resolved_of_symmetry_breaking_datum {A : Type}
    (M : GrowthSectorResolutionBridge.GrowthSectorMap A)
    (D : DefectSystem A) (datum : SymmetryBreakingDatum D) :
    M.hasResolvedJSign D :=
  UniqueLockSectorClosure.growth_resolved_of_minSet_singleton
    M D datum.selected datum.minSet_singleton

/-- Das aktuelle eindeutige Miniport-Minset liefert ein symmetry-breaking datum
    im rein formalen Sinn: Das kanonische Minset ist ein Singleton. -/
def oneInteriorBreakingDatum :
    SymmetryBreakingDatum OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  { selected := OneInteriorGrowthKernelExample.onlyAttachment,
    minSet_singleton := OneInteriorGrowthKernelExample.oneInterior_minSet_singleton }

/-- Der eindeutige Miniport-Sektor resolved das J-Sign ueber das
    symmetry-breaking-datum-Gate. -/
theorem oneInterior_resolved_by_breaking_datum :
    GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  growth_resolved_of_symmetry_breaking_datum
    GrowthSectorResolutionBridge.oneInteriorSectorMap
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem
    oneInteriorBreakingDatum

/-- Der konkrete Miniport-Growth-Kernel ist der singleton-Fall. -/
theorem oneInterior_kernel_and_breaking_datum_closure :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    oneInterior_resolved_by_breaking_datum

/-- Plus-Singleton ist nicht unter dem Sign-Flip abgeschlossen. -/
theorem plusSector_not_closed_under_flip :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      JSignClosureCriterion.plusSector := by
  intro hclosed
  have hminus : JLockingGate.minusLock ∈ JSignClosureCriterion.plusSector := by
    have hflip := hclosed JLockingGate.plusLock (by
      unfold JSignClosureCriterion.plusSector
      exact List.mem_cons_self)
    rw [SymmetrySectorNoGo.flip_plusLock] at hflip
    exact hflip
  unfold JSignClosureCriterion.plusSector at hminus
  cases List.mem_cons.mp hminus with
  | inl he =>
      have hne : JLockingGate.minusLock ≠ JLockingGate.plusLock := by
        intro hEq
        have hj := congrArg JLockingGate.LockCandidate.j hEq
        exact JLockingGate.plusLock_j_ne_minusLock_j (Eq.symm hj)
      exact hne he
  | inr hnil =>
      cases hnil

/-- Der aktuelle eindeutige Growth-Pushforward bricht die Flip-Abgeschlossenheit
    im rein formalen Sinn: seine Lock-Liste ist ein Plus-Singleton. -/
theorem oneInterior_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (GrowthSectorResolutionBridge.oneInteriorSectorMap.lockCandidates
        OneInteriorGrowthKernelExample.oneInteriorDefectSystem) := by
  intro hclosed
  rw [GrowthSectorResolutionBridge.oneInterior_growth_locks_eq_plusSector] at hclosed
  exact plusSector_not_closed_under_flip hclosed

/-- Statusmarker: Dieses Gate zeigt nur, was aus einem derived Singleton-Minset
    folgen wuerde. Es leitet das symmetry-breaking datum noch nicht aus den
    Schur-DtN-Komplementdaten ab. -/
def derivedBreakingDatumStillOpen : Prop := True

theorem derived_breaking_datum_still_open : derivedBreakingDatumStillOpen :=
  True.intro

end SymmetryBreakingClosureGate
