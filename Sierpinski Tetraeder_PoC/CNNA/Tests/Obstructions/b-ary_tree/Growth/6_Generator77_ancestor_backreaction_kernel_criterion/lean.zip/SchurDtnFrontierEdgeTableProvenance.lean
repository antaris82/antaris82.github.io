import CNNA.SchurDtnFrontierEventActivationProvenance

namespace SchurDtnFrontierEdgeTableProvenance

abbrev Node := Fin 3
abbrev CutGraphExtensionRecord :=
  SchurDtnFrontierEventActivationProvenance.CutGraphExtensionRecord
abbrev CutFrontierExtensionData :=
  SchurDtnGraphFrontierExtensionProvenance.CutFrontierExtensionData
abbrev CutGraphUniverseData :=
  SchurDtnCutGraphUniverseProvenance.CutGraphUniverseData
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure DirectedEdge where
  source : Node
  target : Node

structure CutGraphEdgeTableRecord where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  boundaryPort : Node
  sourcePort : Node
  targetNode : Node
  edgeTable : List DirectedEdge
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def edgeMatches (source target : Node) (e : DirectedEdge) : Bool :=
  (e.source == source) && (e.target == target)


def edgePresentFromTable (source target : Node) : List DirectedEdge -> Bool
  | [] => false
  | e :: es =>
      if edgeMatches source target e then true
      else edgePresentFromTable source target es


def edgePresent (p : CutGraphEdgeTableRecord) : Bool :=
  edgePresentFromTable p.sourcePort p.targetNode p.edgeTable


def toCutGraphExtensionRecord (p : CutGraphEdgeTableRecord) :
    CutGraphExtensionRecord :=
  { boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    boundaryPort := p.boundaryPort,
    sourcePort := p.sourcePort,
    targetNode := p.targetNode,
    edgePresent := edgePresent p,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    frontierAdjacent := p.frontierAdjacent,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toCutGraphExtensionRecord_edgePresent
    (p : CutGraphEdgeTableRecord) :
    (toCutGraphExtensionRecord p).edgePresent = edgePresent p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnFrontierEventActivationProvenance.eqAdj


def edge22 : DirectedEdge :=
  { source := 2, target := 2 }


def edge21 : DirectedEdge :=
  { source := 2, target := 1 }


def inactiveEdgeTableRecordNode2 : CutGraphEdgeTableRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    edgeTable := [],
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def wrongTargetEdgeTableRecordNode2 : CutGraphEdgeTableRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    edgeTable := [edge21],
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualEdgeTableRecordNode2 : CutGraphEdgeTableRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    edgeTable := [edge22],
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem inactive_edge_table_no_edge_present_node2 :
    edgePresent inactiveEdgeTableRecordNode2 = false := rfl


theorem wrong_target_edge_table_no_edge_present_node2 :
    edgePresent wrongTargetEdgeTableRecordNode2 = false := rfl


theorem residual_edge_table_edge_present_node2 :
    edgePresent residualEdgeTableRecordNode2 = true := rfl


theorem inactive_edge_table_record_eq_previous_node2 :
    toCutGraphExtensionRecord inactiveEdgeTableRecordNode2 =
      SchurDtnFrontierEventActivationProvenance.inactiveEdgeRecordNode2 := rfl


theorem residual_edge_table_record_eq_previous_node2 :
    toCutGraphExtensionRecord residualEdgeTableRecordNode2 =
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 := rfl


theorem inactive_edge_table_event_not_active_node2 :
    SchurDtnFrontierEventActivationProvenance.eventActive
      (toCutGraphExtensionRecord inactiveEdgeTableRecordNode2) = false := rfl


theorem wrong_target_edge_table_event_not_active_node2 :
    SchurDtnFrontierEventActivationProvenance.eventActive
      (toCutGraphExtensionRecord wrongTargetEdgeTableRecordNode2) = false := rfl


theorem residual_edge_table_event_active_node2 :
    SchurDtnFrontierEventActivationProvenance.eventActive
      (toCutGraphExtensionRecord residualEdgeTableRecordNode2) = true := rfl


def inactiveCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEventActivationProvenance.toCutFrontierExtensionData
    (toCutGraphExtensionRecord inactiveEdgeTableRecordNode2)


def wrongTargetCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEventActivationProvenance.toCutFrontierExtensionData
    (toCutGraphExtensionRecord wrongTargetEdgeTableRecordNode2)


def residualCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  SchurDtnFrontierEventActivationProvenance.toCutFrontierExtensionData
    (toCutGraphExtensionRecord residualEdgeTableRecordNode2)


theorem inactive_edge_table_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      inactiveCutFrontierExtensionNode2 = [] := rfl


theorem wrong_target_edge_table_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      wrongTargetCutFrontierExtensionNode2 = [] := rfl


theorem residual_edge_table_frontier_candidates_node2 :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      residualCutFrontierExtensionNode2 = [2] := rfl


def residualCutGraphUniverseNode2 : CutGraphUniverseData :=
  SchurDtnGraphFrontierExtensionProvenance.toCutGraphUniverseData
    residualCutFrontierExtensionNode2


theorem residual_universe_nodes_node2_from_edge_table :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      residualCutGraphUniverseNode2 = [0, 1, 2] := rfl


def residualBoundarySupportNode2 : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    residualCutGraphUniverseNode2


theorem residual_support_nodes_node2_from_edge_table :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualBoundarySupportNode2 = [2] := rfl


theorem residual_candidate_load_nodes_node2_from_edge_table :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualBoundarySupportNode2) = [1, 2] := rfl


def cutFrontierEdgeTableDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEventActivationProvenance.cutFrontierActivationDefectSystem


theorem cut_frontier_edge_table_closure_status :
    cutFrontierEdgeTableDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutFrontierEdgeTableDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutFrontierEdgeTableDefectSystem) :=
  SchurDtnFrontierEventActivationProvenance.cut_frontier_activation_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierEventActivationProvenance.symmetricDefectSystem


theorem symmetric_frontier_edge_table_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnFrontierEventActivationProvenance.symmetric_frontier_activation_status


def edgeTableStillNeedsCutGraphDerivation : Prop := True


theorem edge_table_still_needs_cut_graph_derivation :
    edgeTableStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnFrontierEdgeTableProvenance
