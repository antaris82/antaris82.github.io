/-
  EffectiveKernel.lean
  --------------------
  Formaler Kern der CNNA-These: effektive Stochastik entsteht NICHT ontisch,
  sondern als bright-seitige Effektbeschreibung einer DETERMINISTISCHEN
  Gesamtdynamik unter einer NICHT-INJEKTIVEN Handoff-Projektion.

  Aufbau (vgl. Begleitdokument, Abschnitte 1-9):
    X            voller (deterministischer) Zustandsraum
    F : X → X    deterministische Gesamtdynamik           [Gate S1: kein externes ξ]
    π : X → Y    bright/Handoff-Projektion (nicht injektiv) [Gate S2: |π⁻¹(y)|>1]
    Faser π⁻¹(y) Komplement, das bright nicht sieht
    count y y'   = |{ x ∈ Faser(y) : π(F x) = y' }|        effektiver Kern (Counts)

  Bewiesen (vollstaendig, `sorry`-frei, Mathlib-frei, lean4:v4.28.0):
    (T1) Massenerhaltung: Σ_{y'} count y y' = |Faser y|       [stochastisch]
    (T2) Gate S2: leere Faser ⇒ Kern null (keine eff. Stochastik ohne Faser)
    (T3) Determinismus bei Injektivitaet: |Faser y| = 1 auf einem y'
         konzentriert ⇒ Punktmass (nicht-injektiv ist NOTWENDIG)
    (T4) Gate S4: Relabeling-Natuerlichkeit unter aequivariantem F, π
    (T5) Gate S7: Markov ist NICHT automatisch (Gegenbeispiel)

  Die einzelne Realisierung (dark-seeded, Mglk. A) und das derived-Mass μ_y
  (Gate S3) sind als OPEN markiert -- sie erfordern Zusatzstruktur.

  Maßfreier Trick: "stochastisch" wird als NAT-Gleichung (Erhaltung der
  Fasermasse) bewiesen, nicht ueber Wahrscheinlichkeitsmaße. Das haelt die
  Datei im selben Toolchain-Regime wie Circulation.lean.
-/

namespace EffectiveKernel

variable {X Y : Type}

/-! ## 1. Faser und effektiver Kern (Counts) -/

/-- Faser der Projektion `π` ueber `y`, eingeschraenkt auf eine endliche
    Zustandsliste `Xs`. Das ist der bright-unsichtbare Komplement. -/
def fiber [DecidableEq Y] (π : X → Y) (Xs : List X) (y : Y) : List X :=
  Xs.filter (fun x => π x == y)

/-- Effektiver Uebergangs-COUNT: wie viele Komplementzustaende der Faser von `y`
    unter `F` nach `y'` projizieren. Die maßfreie Form des Kerns `K(y,y')`. -/
def count [DecidableEq Y] (π : X → Y) (F : X → X) (Xs : List X) (y y' : Y) : Nat :=
  (fiber π Xs y).countP (fun x => π (F x) == y')

/-! ## 2. (T1) Massenerhaltung: der Kern ist stochastisch

    `Σ_{y'} count y y' = |Faser y|`. In Worten: die effektiven
    Uebergangsgewichte einer bright-Zeile summieren zur Fasermasse --
    die maßfreie Aussage "Zeilensumme = 1 nach Normierung". -/

/-- Hilfssatz: Summe einer konstant-0-Map ist 0. -/
theorem sum_map_const_zero {Y : Type} (Ys : List Y) :
    (Ys.map (fun _ => (0 : Nat))).sum = 0 := by
  induction Ys with
  | nil => rfl
  | cons a Ys ih => rw [List.map_cons, List.sum_cons, ih]

/-- Hilfssatz: Summen-Splitting `Σ (q + Indikator) = Σ q + Σ Indikator`
    (vermeidet unbekannte Bibliotheksnamen wie `List.sum_map_add`). -/
theorem sum_map_countP_cons_split [DecidableEq Y]
    (Ys : List Y) (q : Y → Nat) (w : Y) :
    (Ys.map (fun y' => q y' + if (w == y') = true then 1 else 0)).sum
      = (Ys.map q).sum
        + (Ys.map (fun y' => if (w == y') = true then 1 else 0)).sum := by
  induction Ys with
  | nil => rfl
  | cons a Ys ih =>
      rw [List.map_cons, List.map_cons, List.map_cons,
          List.sum_cons, List.sum_cons, List.sum_cons, ih]
      omega

/-- Hilfssatz: ist `v` NICHT in `Ys`, summieren die Indikatoren zu 0. -/
theorem sum_indicator_eq_zero [DecidableEq Y]
    (Ys : List Y) (v : Y) (hnotmem : ¬ v ∈ Ys) :
    (Ys.map (fun y' => if (v == y') = true then 1 else 0)).sum = 0 := by
  induction Ys with
  | nil => rfl
  | cons a Ys ih =>
      have hva : ¬ v = a := by
        intro he; exact hnotmem (he ▸ List.mem_cons_self ..)
      have hnm : ¬ v ∈ Ys := by
        intro hm; exact hnotmem (List.mem_cons_of_mem _ hm)
      have hne : (v == a) = false := by
        simp [beq_eq_false_iff_ne, hva]
      rw [List.map_cons, List.sum_cons, hne, ih hnm]
      decide

/-- Hilfssatz: Summe der Indikatoren `[y' ↦ if v==y' then 1 else 0]` ueber eine
    nodup-Liste, die `v` enthaelt, ist genau 1. (Vor `mass_conservation`, da
    dort benutzt.) -/
theorem sum_indicator_eq_one [DecidableEq Y]
    (Ys : List Y) (v : Y) (hmem : v ∈ Ys) (hnodup : Ys.Nodup) :
    (Ys.map (fun y' => if (v == y') = true then 1 else 0)).sum = 1 := by
  induction Ys with
  | nil => exact absurd hmem (List.not_mem_nil)
  | cons a Ys ih =>
      rw [List.nodup_cons] at hnodup
      obtain ⟨hane, hnd⟩ := hnodup
      rw [List.map_cons, List.sum_cons]
      by_cases h : v = a
      · subst h
        have hone : (v == v) = true := by simp
        rw [hone, sum_indicator_eq_zero Ys v hane]
        decide
      · have hmem' : v ∈ Ys := by
          cases List.mem_cons.mp hmem with
          | inl he => exact absurd he h
          | inr ht => exact ht
        have hne : (v == a) = false := by
          simp [beq_eq_false_iff_ne, h]
        rw [hne, ih hmem' hnd]
        decide

/-- Massenerhaltung als Summe ueber eine Liste `Ys` von Ziel-Handoffs, die ALLE
    tatsaechlich auftretenden Bilder enthaelt: die Counts summieren zur
    Fasergroesse. Formuliert als Erhaltung unter Partition. -/
theorem mass_conservation [DecidableEq Y]
    (π : X → Y) (F : X → X) (Xs : List X) (y : Y) (Ys : List Y)
    (hcover : ∀ x ∈ fiber π Xs y, π (F x) ∈ Ys)
    (hnodup : Ys.Nodup) :
    (Ys.map (fun y' => count π F Xs y y')).sum = (fiber π Xs y).length := by
  unfold count
  have key : ∀ (l : List X), (∀ x ∈ l, π (F x) ∈ Ys) →
      (Ys.map (fun y' => l.countP (fun x => π (F x) == y'))).sum = l.length := by
    intro l hl
    induction l with
    | nil =>
        simp only [List.countP_nil]
        exact sum_map_const_zero Ys
    | cons a l ih =>
        have hmem : π (F a) ∈ Ys := hl a (List.mem_cons_self ..)
        have htail : ∀ x ∈ l, π (F x) ∈ Ys := fun x hx => hl x (List.mem_cons_of_mem _ hx)
        -- Ziel mit defeq-Laenge umformulieren, damit der Schlussschritt
        -- syntaktisch per rfl schliesst (kein nachlaufendes Taktik-Risiko):
        show (Ys.map (fun y' => (a :: l).countP (fun x => π (F x) == y'))).sum
              = l.length + 1
        -- countP auf (a :: l) spaltet unter dem Binder in countP(l) + Indikator(a):
        simp only [List.countP_cons]
        rw [sum_map_countP_cons_split Ys
              (fun y' => l.countP (fun x => π (F x) == y')) (π (F a)),
            ih htail,
            sum_indicator_eq_one Ys (π (F a)) hmem hnodup]
  exact key (fiber π Xs y) hcover

/-! ## 3. (T2) Gate S2: ohne nicht-triviale Faser keine effektive Stochastik -/

/-- Ist die Faser leer, so ist jeder Uebergangs-Count null: ohne unsichtbares
    Komplement gibt es keine effektive Stochastik. -/
theorem count_empty_fiber [DecidableEq Y]
    (π : X → Y) (F : X → X) (Xs : List X) (y y' : Y)
    (h : fiber π Xs y = []) :
    count π F Xs y y' = 0 := by
  unfold count
  rw [h]
  rfl

/-! ## 4. (T3) Nicht-Injektivitaet ist notwendig: Singleton-Faser ⇒ Punktmass -/

/-- Hat die Faser genau ein Element `x₀`, so konzentriert sich der Kern auf
    `π (F x₀)`: der Count ist 1 dort und 0 sonst. Effektive Stochastik (ein
    Count > 1 auf mehreren Zielen) verlangt also |Faser| > 1 -- Gate S2. -/
theorem singleton_fiber_deterministic [DecidableEq Y]
    (π : X → Y) (F : X → X) (Xs : List X) (y y' : Y) (x₀ : X)
    (h : fiber π Xs y = [x₀]) :
    count π F Xs y y' = (if π (F x₀) == y' then 1 else 0) := by
  unfold count
  rw [h]
  simp [List.countP_cons]

/-! ## 5. (T4) Gate S4: Relabeling-Natuerlichkeit

    Unter einem Relabeling `g : Y → Y` mit aequivariantem `F`, `π` und einer
    relabel-vertraeglichen Zustandsliste ist der Count invariant:
    `count (g∘π…) … (g y) (g y') = count … y y'`. Wir fassen die saubere,
    direkt beweisbare Form: ist `π'` das relabelte `π` und stimmen die Fasern
    via einer Bijektion ueberein, so stimmen die Counts. -/

/-- Aequivarianz-Hypothese in operativer Form: eine Zustands-Bijektion `σ : X→X`
    realisiert das Relabeling `g` mit `π (σ x) = g (π x)` und `F (σ x) = σ (F x)`. -/
structure Equivariant [DecidableEq Y] (π : X → Y) (F : X → X)
    (σ : X → X) (g : Y → Y) : Prop where
  piEq : ∀ x, π (σ x) = g (π x)
  FEq  : ∀ x, F (σ x) = σ (F x)

/-- Unter Aequivarianz und passender Relabel-Invarianz der Zustandsliste
    (`Xs.map σ` ist als Multimenge `Xs`, hier: `σ` permutiert `Xs`) gilt
    Count-Invarianz. Wir beweisen die Kernidentitaet punktweise auf der Faser. -/
theorem count_equivariant [DecidableEq Y] [DecidableEq X]
    (π : X → Y) (F : X → X) (σ : X → X) (g : Y → Y)
    (hg : Function.Injective g)
    (he : Equivariant π F σ g)
    (Xs : List X) (y y' : Y)
    (hperm : (Xs.filter (fun x => π x == g y))
              = (Xs.filter (fun x => π x == y)).map σ) :
    count π F Xs (g y) (g y') = count π F Xs y y' := by
  unfold count fiber
  rw [hperm, List.countP_map]
  apply List.countP_congr
  intro x _
  -- (π (F (σ x)) == g y') ↔ (π (F x) == y')
  rw [Function.comp_apply, he.FEq x, he.piEq (F x)]
  by_cases h : π (F x) = y'
  · simp [h]
  · have : g (π (F x)) ≠ g y' := fun he2 => h (hg he2)
    simp [h, this]

/-! ## 6. (T5) Gate S7: Markov ist NICHT automatisch

    Die exakte Projektion ist im Allgemeinen kein Markov-Prozess: der
    Zwei-Schritt-Count stimmt nicht mit der Komposition der Ein-Schritt-Counts
    ueberein, weil das Komplement (dark) Gedaechtnis traegt. Wir geben ein
    explizites endliches Gegenbeispiel. -/

/-- Gegenbeispiel-Zustandsraum: `Fin 2 × Fin 2` (bright × dark). -/
abbrev GX := Fin 2 × Fin 2
def gpi (x : GX) : Fin 2 := x.1
/-- Dynamik mit dark-Gedaechtnis (aus verify_eff_logic, T5). -/
def gF : GX → GX
  | (0, 0) => (1, 1)
  | (0, 1) => (0, 0)
  | (1, 0) => (0, 1)
  | (1, 1) => (1, 0)
  | _      => (0, 0)
def gXs : List GX := [(0,0),(0,1),(1,0),(1,1)]

/-- Ein-Schritt-Count und Zwei-Schritt-Count fuer `y=0` nach `y'=0`. -/
def twoStepExact : Nat :=
  (fiber gpi gXs 0).countP (fun x => gpi (gF (gF x)) == 0)

/-- Markov-Komposition (ueber den Zwischenwert): Σ_{m} count(0,m)·count(m,0),
    hier explizit fuer die zwei moeglichen Zwischenwerte. -/
def twoStepMarkov : Nat :=
  let c0m0 := count gpi gF gXs 0 0 * count gpi gF gXs 0 0
  let c0m1 := count gpi gF gXs 0 1 * count gpi gF gXs 1 0
  c0m0 + c0m1

/-- Markov scheitert: exakte Zwei-Schritt-Statistik ≠ Markov-Komposition
    (auf der mit |Faser|² skalierten Ebene). Das bestaetigt Gate S7:
    die Markov-Eigenschaft ist eine ZUSATZannahme (Faser-Refresh), kein
    automatisches Resultat der Projektion. -/
theorem markov_not_automatic :
    twoStepExact * ((fiber gpi gXs 0).length) ≠ twoStepMarkov := by
  decide

end EffectiveKernel

/-
  OPEN (ehrlich ausgewiesen, vgl. Begleitdokument):

  (E-O1) Derived-Mass (Gate S3): μ_y -- hier implizit Gleichverteilung ueber die
         Faser (Counts). Die CNNA-Ableitung (relabeling-invariante Orbitzaehlung,
         projektive Cut-Grenzverteilung, MaxEnt unter Schur-DtN-Daten) ist offen.

  (E-O2) Einzelrealisierung (Mglk. A): α_n = S(X_n) dark-seeded, mit S
         relabeling-natuerlich (S(gX)=gS(X)). Numerisch plausibel, aber die
         Existenz einer kanonischen, port-ordnungsfreien Auswahlfunktion S ist
         offen.

  (E-O3) Markov-Schliessung (Gate S7): unter welcher Faser-Refresh-Bedingung
         wird K(Y_n,Y_{n+1}) tatsaechlich Markovsch? (markov_not_automatic
         zeigt: nicht ohne Zusatzannahme.)

  (E-O4) Kopplung an F2: dass der erzeugte Komplex echte ClosedWalks mit
         nichtgradientiellen Zirkulations-Cochains traegt (Handoff zu
         Circulation.lean).
-/
