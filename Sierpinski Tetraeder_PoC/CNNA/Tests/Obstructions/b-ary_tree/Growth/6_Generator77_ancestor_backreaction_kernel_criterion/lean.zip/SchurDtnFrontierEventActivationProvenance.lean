import CNNA.SchurDtnGraphFrontierExtensionProvenance

namespace SchurDtnFrontierEventActivationProvenance

abbrev Node := Fin 3
abbrev FrontierExtensionEvent :=
  SchurDtnGraphFrontierExtensionProvenance.FrontierExtensionEvent
abbrev CutFrontierExtensionData :=
  SchurDtnGraphFrontierExtensionProvenance.CutFrontierExtensionData
abbrev CutGraphUniverseData :=
  SchurDtnCutGraphUniverseProvenance.CutGraphUniverseData
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure CutGraphExtensionRecord where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  boundaryPort : Node
  sourcePort : Node
  targetNode : Node
  edgePresent : Bool
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def contains (x : Node) : List Node -> Bool
  | [] => false
  | y :: ys => if x == y then true else contains x ys


def roleNodes (p : CutGraphExtensionRecord) : List Node :=
  p.boundaryRoleNodes ++ p.interiorRoleNodes ++ p.uvBoundaryRoleNodes ++
    p.envBoundaryRoleNodes ++ p.recordRoleNodes


def targetOutsideRoles (p : CutGraphExtensionRecord) : Bool :=
  if contains p.targetNode (roleNodes p) then false else true


def eventActive (p : CutGraphExtensionRecord) : Bool :=
  p.edgePresent && (p.sourcePort == p.boundaryPort) && targetOutsideRoles p


def toFrontierExtensionEvent (p : CutGraphExtensionRecord) :
    FrontierExtensionEvent :=
  { sourcePort := p.sourcePort,
    targetNode := p.targetNode,
    active := eventActive p }


def toCutFrontierExtensionData (p : CutGraphExtensionRecord) :
    CutFrontierExtensionData :=
  { boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    extensionEvents := [toFrontierExtensionEvent p],
    boundaryPort := p.boundaryPort,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    frontierAdjacent := p.frontierAdjacent,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toCutFrontierExtensionData_events
    (p : CutGraphExtensionRecord) :
    (toCutFrontierExtensionData p).extensionEvents =
      [toFrontierExtensionEvent p] := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnGraphFrontierExtensionProvenance.eqAdj


def inactiveEdgeRecordNode2 : CutGraphExtensionRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    edgePresent := false,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def insideTargetRecordNode2 : CutGraphExtensionRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 1,
    edgePresent := true,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualExtensionRecordNode2 : CutGraphExtensionRecord :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    boundaryPort := 2,
    sourcePort := 2,
    targetNode := 2,
    edgePresent := true,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem inactive_edge_target_outside_roles_node2 :
    targetOutsideRoles inactiveEdgeRecordNode2 = true := rfl


theorem inside_target_not_outside_roles_node2 :
    targetOutsideRoles insideTargetRecordNode2 = false := rfl


theorem residual_target_outside_roles_node2 :
    targetOutsideRoles residualExtensionRecordNode2 = true := rfl


theorem inactive_edge_event_not_active_node2 :
    eventActive inactiveEdgeRecordNode2 = false := rfl


theorem inside_target_event_not_active_node2 :
    eventActive insideTargetRecordNode2 = false := rfl


theorem residual_extension_event_active_node2 :
    eventActive residualExtensionRecordNode2 = true := rfl


theorem residual_extension_event_eq_previous_node2 :
    toFrontierExtensionEvent residualExtensionRecordNode2 =
      SchurDtnGraphFrontierExtensionProvenance.residualExtensionEventNode2 := rfl


def inactiveCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  toCutFrontierExtensionData inactiveEdgeRecordNode2


def insideTargetCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  toCutFrontierExtensionData insideTargetRecordNode2


def residualCutFrontierExtensionNode2 : CutFrontierExtensionData :=
  toCutFrontierExtensionData residualExtensionRecordNode2


theorem inactive_frontier_candidate_nodes_from_activation :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      inactiveCutFrontierExtensionNode2 = [] := rfl


theorem inside_target_frontier_candidate_nodes_from_activation :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      insideTargetCutFrontierExtensionNode2 = [] := rfl


theorem residual_frontier_candidate_nodes_from_activation :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      residualCutFrontierExtensionNode2 = [2] := rfl


def residualCutGraphUniverseNode2 : CutGraphUniverseData :=
  SchurDtnGraphFrontierExtensionProvenance.toCutGraphUniverseData
    residualCutFrontierExtensionNode2


theorem residual_universe_nodes_node2_from_event_activation :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      residualCutGraphUniverseNode2 = [0, 1, 2] := rfl


def residualBoundarySupportNode2 : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    residualCutGraphUniverseNode2


theorem residual_support_nodes_node2_from_event_activation :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualBoundarySupportNode2 = [2] := rfl


theorem residual_candidate_load_nodes_node2_from_event_activation :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualBoundarySupportNode2) = [1, 2] := rfl


def cutFrontierActivationDefectSystem : DefectSystem Bool :=
  SchurDtnGraphFrontierExtensionProvenance.cutFrontierExtensionDefectSystem


theorem cut_frontier_activation_closure_status :
    cutFrontierActivationDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutFrontierActivationDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutFrontierActivationDefectSystem) :=
  SchurDtnGraphFrontierExtensionProvenance.cut_frontier_extension_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnGraphFrontierExtensionProvenance.symmetricDefectSystem


theorem symmetric_frontier_activation_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnGraphFrontierExtensionProvenance.symmetric_frontier_extension_status


def edgePresentStillNeedsCutGraphDerivation : Prop := True


theorem edge_present_still_needs_cut_graph_derivation :
    edgePresentStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnFrontierEventActivationProvenance
