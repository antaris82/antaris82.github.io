namespace SchurCutSpectralTowerCriterion

structure BinarySchurCutStage where
  depth : Nat
  frontierCount : Nat
  minEigenvalueNumerator : Nat
  minEigenvalueDenominator : Nat
  conditionNumber : Nat
  softBelowTenthCount : Nat
  softBelowTenthDenominator : Nat
  kappaPreservesSymmetricShells : Bool
  kappaPreservesSoftProjectorSurrogate : Bool
deriving DecidableEq, Repr

def binaryFrontierCount (L : Nat) : Nat := 2 ^ L

def binaryMinEigenvalueDenominator (L : Nat) : Nat := 2 ^ L - 1

def binaryConditionNumber (L : Nat) : Nat := 2 ^ L - 1

def binaryStage (L softCount : Nat) : BinarySchurCutStage :=
  { depth := L
    frontierCount := binaryFrontierCount L
    minEigenvalueNumerator := 1
    minEigenvalueDenominator := binaryMinEigenvalueDenominator L
    conditionNumber := binaryConditionNumber L
    softBelowTenthCount := softCount
    softBelowTenthDenominator := binaryConditionNumber L
    kappaPreservesSymmetricShells := true
    kappaPreservesSoftProjectorSurrogate := true }

def stage1 : BinarySchurCutStage := binaryStage 1 0

def stage2 : BinarySchurCutStage := binaryStage 2 0

def stage3 : BinarySchurCutStage := binaryStage 3 0

def stage4 : BinarySchurCutStage := binaryStage 4 1

def stage5 : BinarySchurCutStage := binaryStage 5 3

def stage6 : BinarySchurCutStage := binaryStage 6 7

def stage7 : BinarySchurCutStage := binaryStage 7 15

def stage8 : BinarySchurCutStage := binaryStage 8 31

def conditionNumberProfile : List Nat :=
  [stage1.conditionNumber, stage2.conditionNumber, stage3.conditionNumber,
   stage4.conditionNumber, stage5.conditionNumber, stage6.conditionNumber,
   stage7.conditionNumber, stage8.conditionNumber]

def minEigenDenominatorProfile : List Nat :=
  [stage1.minEigenvalueDenominator, stage2.minEigenvalueDenominator,
   stage3.minEigenvalueDenominator, stage4.minEigenvalueDenominator,
   stage5.minEigenvalueDenominator, stage6.minEigenvalueDenominator,
   stage7.minEigenvalueDenominator, stage8.minEigenvalueDenominator]

def softBelowTenthCountProfile : List Nat :=
  [stage1.softBelowTenthCount, stage2.softBelowTenthCount,
   stage3.softBelowTenthCount, stage4.softBelowTenthCount,
   stage5.softBelowTenthCount, stage6.softBelowTenthCount,
   stage7.softBelowTenthCount, stage8.softBelowTenthCount]

def softBelowTenthDenominatorProfile : List Nat :=
  [stage1.softBelowTenthDenominator, stage2.softBelowTenthDenominator,
   stage3.softBelowTenthDenominator, stage4.softBelowTenthDenominator,
   stage5.softBelowTenthDenominator, stage6.softBelowTenthDenominator,
   stage7.softBelowTenthDenominator, stage8.softBelowTenthDenominator]

theorem condition_number_profile_matches_binary_schur_cut_register :
    conditionNumberProfile = [1, 3, 7, 15, 31, 63, 127, 255] := by
  decide

theorem min_eigen_denominator_profile_matches_condition_profile :
    minEigenDenominatorProfile = conditionNumberProfile := by
  decide

theorem soft_below_tenth_count_profile_matches_register :
    softBelowTenthCountProfile = [0, 0, 0, 1, 3, 7, 15, 31] := by
  decide

theorem soft_below_tenth_denominator_profile_matches_condition_profile :
    softBelowTenthDenominatorProfile = conditionNumberProfile := by
  decide

theorem stage7_min_denominator_eq_condition_number :
    stage7.minEigenvalueDenominator = stage7.conditionNumber := by
  decide

theorem stage8_condition_number_refines_stage7 :
    stage8.conditionNumber = 2 * stage7.conditionNumber + 1 := by
  decide

theorem stage8_soft_below_tenth_fraction_one_eighth_surrogate :
    stage8.softBelowTenthCount * 8 = stage8.softBelowTenthDenominator - 7 := by
  decide

theorem symmetric_kappa_preserves_stage7_shells :
    stage7.kappaPreservesSymmetricShells = true ∧
    stage7.kappaPreservesSoftProjectorSurrogate = true := by
  decide

theorem symmetric_kappa_preserves_stage8_shells :
    stage8.kappaPreservesSymmetricShells = true ∧
    stage8.kappaPreservesSoftProjectorSurrogate = true := by
  decide

def schurCutSpectrumStillFiniteDtNRegister : Prop := True

theorem schur_cut_spectrum_still_finite_dtn_register :
    schurCutSpectrumStillFiniteDtNRegister :=
  True.intro

def schurCutSpectrumStillPreVonNeumann : Prop := True

theorem schur_cut_spectrum_still_pre_von_neumann :
    schurCutSpectrumStillPreVonNeumann :=
  True.intro

def symmetricSoftSectorStillKappaBlind : Prop := True

theorem symmetric_soft_sector_still_kappa_blind :
    symmetricSoftSectorStillKappaBlind :=
  True.intro

end SchurCutSpectralTowerCriterion
