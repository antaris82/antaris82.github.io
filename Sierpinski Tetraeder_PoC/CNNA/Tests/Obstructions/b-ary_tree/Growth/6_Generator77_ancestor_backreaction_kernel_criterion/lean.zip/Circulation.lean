/-
  Circulation.lean
  ----------------
  Formaler Kern der Alters-Zirkulations-Konstruktion (NGF / dekorierter ToC).

  Ziel dieser Datei (bewusst eng gefasst, dafuer vollstaendig und `sorry`-frei):
  Wir formalisieren die ALGEBRAISCHE BASIS des Arguments, dass die aus der
  Provenienz-Halbordnung gewonnene Zirkulation
    (1) unter Relabeling der Knoten invariant ist        [S_b-Gauge],
    (2) auf unvergleichbaren Kanten verschwindet         [respektiert S_b-No-Go],
    (3) unter Ordnungsumkehr ihr Vorzeichen kippt        [die Involution],
    (4) und dass diese Ordnungsumkehr KEINE Symmetrie einer strikten
        Ordnung ist                                      [keine Gauge],
  zusammen mit
    (5) J^2 = -I auf der orientierten 2-Ebene            [die komplexe Struktur].

  NICHT formalisiert (ehrlich ausgewiesen, s. Abschnitt OPEN am Ende):
  die kohomologische Globalisierung (J auf ganz H^1 eines Simplizialkomplexes)
  und die generische Nichtdegeneriertheit der Zirkulation ueber eine Zyklenbasis.

  Mathlib wird NICHT benoetigt; nur der Kern-Toolchain (lean4:v4.28.0).
-/

namespace Circulation

/-! ## 1. Vorzeichen-Cochain und Zirkulation -/

/-- Eine Kantenliste eines (geschlossenen) Weges, als Liste von Knotenpaaren. -/
abbrev Edges (V : Type) := List (V × V)

/-- Zirkulation: Summe einer antisymmetrischen Vergleichsfunktion `cmp`
    ueber eine Kantenliste. `cmp a b = +1` heisst "b juenger als a" usw. -/
def csum {V : Type} (cmp : V → V → Int) : Edges V → Int
  | []            => 0
  | (a, b) :: es  => cmp a b + csum cmp es

@[simp] theorem csum_nil {V} (cmp : V → V → Int) : csum cmp [] = 0 := rfl

@[simp] theorem csum_cons {V} (cmp : V → V → Int) (a b : V) (es : Edges V) :
    csum cmp ((a, b) :: es) = cmp a b + csum cmp es := rfl

/-! ## 2. Lemma (1): Relabeling-Invarianz  [S_b-Gauge] -/

/-- Knoten-Relabeling durch `σ`, angewandt auf eine Kantenliste. -/
def relabel {V W : Type} (σ : V → W) : Edges V → Edges W :=
  List.map (fun e => (σ e.1, σ e.2))

/-- Die Zirkulation der relabelten Kanten unter `cmp` ist gleich der
    Zirkulation der Originalkanten unter der zurueckgezogenen Vergleichsfunktion.
    Damit haengt die Zirkulation nicht von der Adress-Benennung ab. -/
theorem csum_relabel {V W : Type} (cmp : W → W → Int) (σ : V → W) :
    ∀ es : Edges V,
      csum cmp (relabel σ es) = csum (fun a b => cmp (σ a) (σ b)) es := by
  intro es
  induction es with
  | nil => rfl
  | cons e es ih =>
      cases e with
      | mk a b =>
        -- relabel σ ((a,b)::es) = (σ a, σ b) :: relabel σ es  (definitionell via List.map)
        have hrel : relabel σ ((a, b) :: es) = (σ a, σ b) :: relabel σ es := rfl
        rw [hrel, csum_cons, csum_cons, ih]

/-! ## 3. Lemma (2): Unvergleichbare Kanten tragen 0 bei  [S_b-No-Go] -/

/-- Verschwindet `cmp` auf jeder Kante (z.B. weil alle Endpunkte
    unvergleichbar sind), so ist die Zirkulation 0. Geschwister sind in der
    Provenienz-Halbordnung unvergleichbar; ein Geschwisterzyklus traegt 0. -/
theorem csum_zero_of_all_incomparable {V} (cmp : V → V → Int) :
    ∀ es : Edges V, (∀ e ∈ es, cmp e.1 e.2 = 0) → csum cmp es = 0 := by
  intro es
  induction es with
  | nil => intro _; rfl
  | cons e es ih =>
      intro h
      cases e with
      | mk a b =>
        have hhead : cmp a b = 0 := by
          have := h (a, b) (by simp); simpa using this
        have htail : ∀ e ∈ es, cmp e.1 e.2 = 0 := by
          intro e he; exact h e (by simp [he])
        rw [csum_cons, hhead, ih htail]; omega

/-! ## 4. Lemma (3): Ordnungsumkehr kippt das Vorzeichen  [die Involution] -/

/-- Negiert man die Vergleichsfunktion (das ist die Wirkung der Ordnungsumkehr
    auf eine antisymmetrische `cmp`), so kippt die Zirkulation ihr Vorzeichen. -/
theorem csum_neg {V} (cmp : V → V → Int) :
    ∀ es : Edges V, csum (fun a b => - cmp a b) es = - csum cmp es := by
  intro es
  induction es with
  | nil => rfl
  | cons e es ih =>
      cases e with
      | mk a b =>
        simp only [csum_cons, ih]
        omega

/-- Ordnungsumkehr als `cmp a b ↦ cmp b a`. Fuer eine ANTISYMMETRISCHE `cmp`
    (d.h. `cmp a b = - cmp b a`) faellt dies mit der Negation zusammen und
    kippt daher die Zirkulation. -/
theorem csum_orderReversal {V} (cmp : V → V → Int)
    (anti : ∀ a b, cmp a b = - cmp b a) :
    ∀ es : Edges V, csum (fun a b => cmp b a) es = - csum cmp es := by
  intro es
  have hpt : (fun a b => cmp b a) = (fun a b => - cmp a b) := by
    funext a b; rw [anti b a]
  rw [hpt]; exact csum_neg cmp es

/-! ## 5. Lemma (4): Ordnungsumkehr ist KEINE Symmetrie einer strikten Ordnung -/

/-- Kernpunkt des gesamten Arguments: Die Involution, die das Vorzeichen kippt
    (Ordnungsumkehr), ist keine Symmetrie einer nichtleeren strikten Ordnung.
    Damit ist die Obstruktions-Hypothese "Datum invariant unter der Involution"
    fuer dieses Datum ECHT verletzt -- anders als bei Spiegelung/Relabeling. -/
theorem reversal_not_symmetry {V} (lt : V → V → Prop)
    (asymm : ∀ a b, lt a b → ¬ lt b a) {a b : V} (h : lt a b) :
    (fun x y => lt y x) ≠ lt := by
  intro heq
  -- Aus heq folgt punktweise (fun x y => lt y x) a b = lt a b, also lt b a = lt a b.
  have hab : lt b a = lt a b := congrFun (congrFun heq a) b
  have hba : lt b a := by rw [hab]; exact h
  exact (asymm a b h) hba

/-! ## 6. Lemma (5): J^2 = -I auf der orientierten 2-Ebene  [komplexe Struktur] -/

/-- Punkte der orientierten 2-Ebene (Zyklusraum-Koordinaten). -/
structure Vec2 where
  x : Int
  y : Int
deriving DecidableEq, Repr

/-- Negation. -/
def Vec2.neg (v : Vec2) : Vec2 := ⟨-v.x, -v.y⟩

/-- Die durch die Orientierung gegebene Vierteldrehung `J(x,y) = (-y, x)`. -/
def Vec2.J (v : Vec2) : Vec2 := ⟨-v.y, v.x⟩

/-- `J^2 = -I`: die Vierteldrehung ist eine komplexe Struktur. -/
theorem J_sq (v : Vec2) : v.J.J = v.neg := by
  cases v with
  | mk x y => simp [Vec2.J, Vec2.neg]

/-- `J` kippt unter Orientierungsumkehr in `-J` (die andere komplexe Struktur),
    konsistent mit Lemma (3): die Orientierung waehlt zwischen `J` und `-J`. -/
def Vec2.Jrev (v : Vec2) : Vec2 := ⟨v.y, -v.x⟩

theorem Jrev_eq_negJ (v : Vec2) : v.Jrev = (v.J).neg := by
  cases v with
  | mk x y => simp [Vec2.Jrev, Vec2.J, Vec2.neg]

theorem Jrev_sq (v : Vec2) : v.Jrev.Jrev = v.neg := by
  cases v with
  | mk x y => simp [Vec2.Jrev, Vec2.neg]

/-! ## 7. Konkreter Zeuge: nichttriviale Zirkulation existiert

    Vier Knoten mit Provenienz-"Geburtshoehen" b0=b1=0, b3=1, b4=2.
    `cmp a b = sign(height b - height a)`. Der 4-Zyklus 0→1→3→4→0 hat
    Zirkulation +1 (nicht 0): die Konstruktion ist nicht trivial. -/

def height : Fin 5 → Int
  | 0 => 0 | 1 => 0 | 2 => 0 | 3 => 1 | 4 => 2
  | _ => 0

def cmpH (a b : Fin 5) : Int :=
  let d := height b - height a
  if d > 0 then 1 else if d < 0 then -1 else 0

/-- `cmpH` ist antisymmetrisch. -/
theorem cmpH_anti : ∀ a b : Fin 5, cmpH a b = - cmpH b a := by
  decide

/-- Der konkrete 4-Zyklus traegt Zirkulation +1. -/
def witnessCycle : Edges (Fin 5) := [(0,1),(1,3),(3,4),(4,0)]

theorem witness_circulation : csum cmpH witnessCycle = 1 := by
  decide

/-- ...und unter Ordnungsumkehr exakt -1 (Vorzeichen kippt). -/
theorem witness_circulation_reversed :
    csum (fun a b => cmpH b a) witnessCycle = -1 := by
  decide

/-! ## 8. Zusammenfuehrung

    Die Zirkulation `circ := csum cmpH` ist:
      • relabeling-invariant            (csum_relabel),
      • null auf unvergleichbaren Kanten (csum_zero_of_all_incomparable),
      • vorzeichen-kippend nur unter Ordnungsumkehr (csum_orderReversal),
      • und Ordnungsumkehr ist keine Symmetrie der strikten Ordnung
        (reversal_not_symmetry),
    waehrend die orientierte 2-Ebene eine echte komplexe Struktur traegt
      • J_sq : J^2 = -I.
    Die strikte Provenienzordnung "juenger als" auf den Fin 5 erfuellt die
    Asymmetrie-Hypothese: -/

def youngerThan (a b : Fin 5) : Prop := height a < height b

theorem youngerThan_asymm : ∀ a b, youngerThan a b → ¬ youngerThan b a := by
  intro a b hab hba
  unfold youngerThan at hab hba
  omega

/-- Beispielinstanz von Lemma (4) fuer die konkrete Provenienzordnung:
    Die Ordnungsumkehr ist keine Symmetrie (Zeuge: 0 juenger als 3). -/
theorem reversal_not_symmetry_concrete :
    (fun x y => youngerThan y x) ≠ youngerThan := by
  have h03 : youngerThan 0 3 := by unfold youngerThan height; decide
  exact reversal_not_symmetry youngerThan youngerThan_asymm h03

end Circulation

/-
  OPEN (nicht in dieser Datei formalisiert, fuer das Inventar ehrlich notiert):

  (O1) Globalisierung: Konstruktion von J auf H^1(K; ℝ) eines wachsenden
       Simplizialkomplexes K aus den Kantenorientierungen der Zirkulation,
       inkl. Wohldefiniertheit auf Kohomologieklassen (Unabhaengigkeit vom
       Repraesentanten). Erfordert simpliziale (Ko-)Homologie -> Mathlib.

  (O2) Nichtdegeneriertheit: dass die Zirkulation auf einer Basis von H^1
       generisch (mass-theoretisch fast sicher) nicht verschwindet, sodass J
       auf ganz H^1 invertierbar ist. Erfordert das stochastische NGF-Mass.

  (O3) Konsistenz/F2-Kohomologie: dass die lokalen Orientierungswahlen global
       widerspruchsfrei zusammenpassen (verschwindende Obstruktionsklasse in
       H^*(-; F2)).

  Die hier bewiesenen Lemmata (1)-(5) sind die algebraische Voraussetzung
  dieser drei offenen Punkte, nicht ihr Ersatz.
-/
