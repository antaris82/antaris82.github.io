import CNNA.HandoffStrictPreferenceBridge
import CNNA.FiniteHandoffSummary

namespace CutStrictPreferenceBridge

abbrev CutSummary := FiniteHandoffSummary.CutSummary
abbrev StrictHandoffData := HandoffDefectSystem.HandoffData
abbrev DefectSystem := SectorResolutionGate.DefectSystem


def absDiff_to_handoff_absDiff (a b : Nat) : Prop :=
  HandoffDefectSystem.absDiff a b = FiniteHandoffSummary.absDiff a b

theorem absDiff_bridge (a b : Nat) : absDiff_to_handoff_absDiff a b := by
  unfold absDiff_to_handoff_absDiff
  unfold HandoffDefectSystem.absDiff FiniteHandoffSummary.absDiff
  rfl


def toStrictHandoffData (before after : CutSummary) : StrictHandoffData :=
  { dtnBefore := before.dtnTrace,
    dtnAfter := after.dtnTrace,
    uvLoad := after.uvBoundaryLoad,
    envLoad := after.envBoundaryLoad,
    cutDefect := after.cutKernelDefect,
    recordDefect := FiniteHandoffSummary.recordDefect before after,
    complementDefect := FiniteHandoffSummary.complementDefect before after }


def cutHandoffDefectSystem
    (before plusAfter minusAfter : CutSummary) : DefectSystem Bool :=
  HandoffStrictPreferenceBridge.handoffDefectSystem
    (toStrictHandoffData before plusAfter)
    (toStrictHandoffData before minusAfter)


def cutSectorMap : GrowthSectorResolutionBridge.GrowthSectorMap Bool :=
  HandoffStrictPreferenceBridge.handoffSectorMap


structure CutStrictPreference
    (before plusAfter minusAfter : CutSummary) where
  minSet_singleton :
    (cutHandoffDefectSystem before plusAfter minusAfter).minSet = [false]


def CutStrictPreference.toHandoffStrictPreference
    {before plusAfter minusAfter : CutSummary}
    (p : CutStrictPreference before plusAfter minusAfter) :
    HandoffStrictPreferenceBridge.HandoffStrictPreference
      (toStrictHandoffData before plusAfter)
      (toStrictHandoffData before minusAfter) :=
  { minSet_singleton := p.minSet_singleton }


theorem resolved_of_cut_strict_preference
    (before plusAfter minusAfter : CutSummary)
    (p : CutStrictPreference before plusAfter minusAfter) :
    cutSectorMap.hasResolvedJSign
      (cutHandoffDefectSystem before plusAfter minusAfter) :=
  HandoffStrictPreferenceBridge.resolved_of_handoff_strict_preference
    (toStrictHandoffData before plusAfter)
    (toStrictHandoffData before minusAfter)
    p.toHandoffStrictPreference


def cutBeforePerfect : CutSummary :=
  { boundarySize := 1,
    interiorSize := 1,
    dtnTrace := 0,
    uvBoundaryLoad := 0,
    envBoundaryLoad := 0,
    cutKernelDefect := 0,
    recordSignature := 0,
    complementSignature := 0 }


def cutPlusAfterPerfect : CutSummary :=
  FiniteHandoffSummary.perfectAfter cutBeforePerfect 0


def cutMinusAfterWorse : CutSummary :=
  { boundarySize := 1,
    interiorSize := 1,
    dtnTrace := 0,
    uvBoundaryLoad := 0,
    envBoundaryLoad := 0,
    cutKernelDefect := 1,
    recordSignature := 0,
    complementSignature := 0 }


def strictCutDefectSystem : DefectSystem Bool :=
  cutHandoffDefectSystem cutBeforePerfect cutPlusAfterPerfect cutMinusAfterWorse


theorem strictCut_minSet_singleton :
    strictCutDefectSystem.minSet = [false] := rfl


theorem strictCut_kernel_one :
    strictCutDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    strictCutDefectSystem false strictCut_minSet_singleton


def strictCutPreference :
    CutStrictPreference cutBeforePerfect cutPlusAfterPerfect cutMinusAfterWorse :=
  { minSet_singleton := strictCut_minSet_singleton }


theorem strictCut_resolved_j_sign :
    cutSectorMap.hasResolvedJSign strictCutDefectSystem :=
  resolved_of_cut_strict_preference
    cutBeforePerfect cutPlusAfterPerfect cutMinusAfterWorse strictCutPreference


theorem strict_cut_preference_closure_status :
    strictCutDefectSystem.kernel = 1 ∧
    cutSectorMap.hasResolvedJSign strictCutDefectSystem :=
  And.intro strictCut_kernel_one strictCut_resolved_j_sign


def schurDtnToCutStrictPreferenceGapStillOpen : Prop := True


theorem schur_dtn_to_cut_strict_preference_gap_still_open :
    schurDtnToCutStrictPreferenceGapStillOpen :=
  True.intro

end CutStrictPreferenceBridge
