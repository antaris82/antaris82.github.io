import CNNA.GrowthEdgeProvenance

namespace LocalGrowthEdgeCriterion

abbrev LocalGrowthRule := GrowthEdgeProvenance.LocalGrowthRule

structure Criterion (r : LocalGrowthRule) where
  source_zero : GrowthEdgeProvenance.sourceNode r = 0
  target_two : GrowthEdgeProvenance.targetNode r = 2
  rank_increases : GrowthEdgeProvenance.rankIncreases r = true
  target_outside_roles : GrowthEdgeProvenance.targetOutsideRoles r = true


theorem growth_active_of_criterion {r : LocalGrowthRule}
    (c : Criterion r) :
    GrowthEdgeProvenance.growthActive r = true := by
  unfold GrowthEdgeProvenance.growthActive
  rw [c.rank_increases, c.target_outside_roles]
  rfl


theorem frontier_edge_forward_of_criterion {r : LocalGrowthRule}
    (c : Criterion r) :
    GrowthEdgeProvenance.frontierGrowthEdge r 0 2 = true := by
  unfold GrowthEdgeProvenance.frontierGrowthEdge
  rw [growth_active_of_criterion c, c.source_zero, c.target_two]
  rfl


theorem frontier_edge_backward_of_criterion {r : LocalGrowthRule}
    (c : Criterion r) :
    GrowthEdgeProvenance.frontierGrowthEdge r 2 0 = true := by
  unfold GrowthEdgeProvenance.frontierGrowthEdge
  rw [growth_active_of_criterion c, c.source_zero, c.target_two]
  rfl


theorem growth_edge_forward_of_criterion {r : LocalGrowthRule}
    (c : Criterion r) :
    GrowthEdgeProvenance.growthAdjacent r 0 2 = true := by
  unfold GrowthEdgeProvenance.growthAdjacent
  rw [frontier_edge_forward_of_criterion c]
  rfl


theorem growth_edge_backward_of_criterion {r : LocalGrowthRule}
    (c : Criterion r) :
    GrowthEdgeProvenance.growthAdjacent r 2 0 = true := by
  unfold GrowthEdgeProvenance.growthAdjacent
  rw [frontier_edge_backward_of_criterion c]
  rfl


def activeCriterion :
    Criterion GrowthEdgeProvenance.activeAddressGrowthRule :=
  { source_zero := GrowthEdgeProvenance.active_rule_source_node_zero,
    target_two := GrowthEdgeProvenance.active_rule_target_node_two,
    rank_increases := GrowthEdgeProvenance.active_rule_rank_increases,
    target_outside_roles :=
      GrowthEdgeProvenance.active_rule_target_outside_roles }


theorem active_criterion_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 0 2 = true :=
  growth_edge_forward_of_criterion activeCriterion


theorem active_criterion_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      GrowthEdgeProvenance.activeAddressGrowthRule 2 0 = true :=
  growth_edge_backward_of_criterion activeCriterion


theorem active_criterion_recovers_local_growth_edge :
    GrowthEdgeProvenance.localGrowthEdgeDerivedFromAddressRule :=
  And.intro GrowthEdgeProvenance.active_rule_rank_increases
    (And.intro GrowthEdgeProvenance.active_rule_target_outside_roles
      (And.intro active_criterion_forward_edge
        active_criterion_backward_edge))


theorem active_criterion_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def criterionStillLocalNode2 : Prop := True


theorem criterion_still_local_node2 :
    criterionStillLocalNode2 :=
  True.intro

end LocalGrowthEdgeCriterion
