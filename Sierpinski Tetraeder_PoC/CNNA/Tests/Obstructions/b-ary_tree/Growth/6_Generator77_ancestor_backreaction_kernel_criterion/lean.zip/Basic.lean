namespace CNNA

def projectName : String := "CNNA"

def buildPathPolicy : String :=
  "active path: CNNA/PillarA only; archived inactive source trees are outside the active build; CNNA/PillarB-E remain dormant BuildAll stubs"

end CNNA
