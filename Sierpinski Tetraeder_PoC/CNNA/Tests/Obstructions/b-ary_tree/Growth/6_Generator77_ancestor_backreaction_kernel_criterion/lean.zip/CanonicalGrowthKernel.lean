/-
  CanonicalGrowthKernel.lean
  --------------------------
  Parameterfreier Growth-Kernel aus einem kanonischen Defektsystem.

  Status: selbststaendig kompilierbar angelegt, ohne Mathlib-Import.

  Idee:

    X  ->  A_X  ->  D_X  ->  ParetoMin(X)  ->  Growth-Kernel.

  Es wird kein freier Selector gesetzt. Ein deterministischer Selector entsteht
  nur im Spezialfall einer eindeutigen Pareto-Minimierermenge. Bei mehreren
  Minima ist die kanonische Antwort ein Sektorkernel.

  Diese Datei schliesst nicht die CNNA-Ableitung des konkreten Defekts aus
  Schur-DtN-Komplementdaten. Sie kapselt aber die parameterfreie Selektionslogik:
  keine Gewichte, keine Temperatur, kein Bias, keine lexikographische Labelwahl.
-/

namespace CanonicalGrowthKernel

/-! ## 0. Boolesche Listen-Helfer -/

/-- Boolesches Existenzquantor ueber endliche Listen. -/
def anyP {A : Type} (p : A -> Bool) : List A -> Bool
  | [] => false
  | a :: as => p a || anyP p as

/-- Wenn `p` auf allen Listenelementen falsch ist, ist `anyP p` falsch. -/
theorem anyP_eq_false_of_forall {A : Type} (p : A -> Bool) :
    forall xs : List A, (forall x, x ∈ xs -> p x = false) -> anyP p xs = false
  | [], _ => rfl
  | a :: as, h => by
      have ha : p a = false := h a (by simp)
      have ht : anyP p as = false :=
        anyP_eq_false_of_forall p as
          (fun x hx => h x (List.mem_cons_of_mem a hx))
      unfold anyP
      rw [ha, ht]
      rfl

/-- Wenn `p` an einem Listenelement wahr ist, ist `anyP p` wahr. -/
theorem anyP_eq_true_of_exists {A : Type} (p : A -> Bool) :
    forall xs : List A, (exists x, x ∈ xs ∧ p x = true) -> anyP p xs = true
  | [], h => by
      cases h with
      | intro x hx => exact absurd hx.1 List.not_mem_nil
  | a :: as, h => by
      cases h with
      | intro x hx =>
          cases List.mem_cons.mp hx.1 with
          | inl he =>
              subst he
              unfold anyP
              rw [hx.2]
              rfl
          | inr ht =>
              have ih : anyP p as = true :=
                anyP_eq_true_of_exists p as ⟨x, ht, hx.2⟩
              unfold anyP
              rw [ih]
              cases p a <;> rfl

/-! ## 1. Parameterfreie Mehrdefekt-Pareto-Ordnung -/

/-- Komponentenweise `<=` fuer Defektvektoren. Unterschiedliche Laengen gelten
    hier nicht als vergleichbar, ausser die linke Liste ist leer und die rechte
    nichtleer. In CNNA-Anwendungen sollen Defektvektoren gleich lange Tupel sein. -/
def leAll : List Nat -> List Nat -> Bool
  | [], [] => true
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: as, b :: bs => decide (a <= b) && leAll as bs

/-- Mindestens eine strikte Verbesserung. -/
def ltAny : List Nat -> List Nat -> Bool
  | [], [] => false
  | [], _ :: _ => false
  | _ :: _, [] => false
  | a :: as, b :: bs => decide (a < b) || ltAny as bs

/-- Pareto-Dominanz: `u` ist in allen Komponenten nicht schlechter als `v` und
    in mindestens einer Komponente strikt besser. -/
def dominates (u v : List Nat) : Bool :=
  leAll u v && ltAny u v

/-- Kein Defektvektor dominiert sich selbst. -/
theorem ltAny_self : forall xs : List Nat, ltAny xs xs = false
  | [] => rfl
  | a :: as => by
      unfold ltAny
      have hlt : (decide (a < a) : Bool) = false := by simp
      rw [hlt, ltAny_self as]
      rfl

/-- Pareto-Dominanz ist irreflexiv. -/
theorem dominates_self_false (xs : List Nat) : dominates xs xs = false := by
  unfold dominates
  rw [ltAny_self xs]
  cases leAll xs xs <;> rfl

/-! ## 2. Kanonische Minimierermenge -/

/-- `a` ist Pareto-minimal unter den Kandidaten `As`, falls kein Kandidat einen
    strikt besseren Defektvektor besitzt. -/
def isParetoMin {A : Type} (defect : A -> List Nat) (As : List A) (a : A) : Bool :=
  !(anyP (fun b => dominates (defect b) (defect a)) As)

/-- Kanonische Sektormenge: alle minimal-defektiven Attachments. -/
def paretoMin {A : Type} (defect : A -> List Nat) (As : List A) : List A :=
  As.filter (fun a => isParetoMin defect As a)

/-- Effektiver Growth-Kernel als Masse der kanonischen Sektormenge. -/
def paretoKernel {A : Type} (defect : A -> List Nat) (As : List A) : Nat :=
  (paretoMin defect As).length

/-- Attachment-Indikator des Sektorkernels. -/
def sectorKernel {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A) : Nat :=
  if a ∈ paretoMin defect As then 1 else 0

/-- Leere Kandidatenmenge liefert leere Minimierermenge. -/
theorem paretoMin_nil {A : Type} (defect : A -> List Nat) :
    paretoMin defect [] = [] := rfl

/-- Leere Kandidatenmenge liefert Kernelmasse 0. -/
theorem paretoKernel_nil {A : Type} (defect : A -> List Nat) :
    paretoKernel defect [] = 0 := rfl

/-- Definitionsexpansion des Kernels. -/
theorem paretoKernel_def {A : Type} (defect : A -> List Nat) (As : List A) :
    paretoKernel defect As = (paretoMin defect As).length := rfl

/-- Die Minimierermenge ist eine Teilliste der Kandidatenliste. -/
theorem paretoMin_sublist {A : Type} (defect : A -> List Nat) (As : List A) :
    (paretoMin defect As).Sublist As := by
  unfold paretoMin
  exact List.filter_sublist

/-- Ein Kandidat in der Minimierermenge gehoert zur Kandidatenliste und erfuellt
    das boolesche Pareto-Minimalitaetskriterium. -/
theorem mem_paretoMin_iff {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A) :
    a ∈ paretoMin defect As <-> a ∈ As ∧ isParetoMin defect As a = true := by
  unfold paretoMin
  simp

/-- Wenn kein Kandidat `a` dominiert, dann ist `a` Pareto-minimal. -/
theorem isParetoMin_of_no_dominator {A : Type} (defect : A -> List Nat)
    (As : List A) (a : A)
    (h : forall b, b ∈ As -> dominates (defect b) (defect a) = false) :
    isParetoMin defect As a = true := by
  unfold isParetoMin
  have hAny : anyP (fun b => dominates (defect b) (defect a)) As = false :=
    anyP_eq_false_of_forall (fun b => dominates (defect b) (defect a)) As h
  rw [hAny]
  rfl

/-- Wenn ein Kandidat `b` den Kandidaten `a` dominiert, dann ist `a` nicht
    Pareto-minimal. -/
theorem not_paretoMin_of_dominator {A : Type} (defect : A -> List Nat)
    (As : List A) (a b : A)
    (hb : b ∈ As) (hdom : dominates (defect b) (defect a) = true) :
    isParetoMin defect As a = false := by
  unfold isParetoMin
  have hAny : anyP (fun c => dominates (defect c) (defect a)) As = true :=
    anyP_eq_true_of_exists (fun c => dominates (defect c) (defect a)) As
      ⟨b, hb, hdom⟩
  rw [hAny]
  rfl

/-! ## 3. Sektorkernel statt freier Einzelwahl -/

/-- Auf der kanonischen Sektormenge hat der Indikatorkernel Wert 1. -/
theorem sectorKernel_one_of_mem {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A)
    (h : a ∈ paretoMin defect As) :
    sectorKernel defect As a = 1 := by
  unfold sectorKernel
  simp [h]

/-- Ausserhalb der kanonischen Sektormenge hat der Indikatorkernel Wert 0. -/
theorem sectorKernel_zero_of_not_mem {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A)
    (h : ¬ a ∈ paretoMin defect As) :
    sectorKernel defect As a = 0 := by
  unfold sectorKernel
  simp [h]

/-- Eindeutiges Minimum: der Kernel hat Masse 1. Das ist der Fall, in dem ein
    deterministischer Selector ohne freie Wahl existiert. -/
theorem unique_min_kernel_one {A : Type} (defect : A -> List Nat)
    (As : List A) (a : A) (h : paretoMin defect As = [a]) :
    paretoKernel defect As = 1 := by
  unfold paretoKernel
  rw [h]
  rfl

/-- Eindeutiges Minimum: der eindeutige Kandidat hat Sektorgewicht 1. -/
theorem unique_min_sector_one {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A)
    (h : paretoMin defect As = [a]) :
    sectorKernel defect As a = 1 := by
  unfold sectorKernel
  rw [h]
  simp

/-- Eindeutiges Minimum: jeder andere Kandidat hat Sektorgewicht 0. -/
theorem unique_min_sector_zero {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a b : A)
    (h : paretoMin defect As = [a]) (hne : b ≠ a) :
    sectorKernel defect As b = 0 := by
  unfold sectorKernel
  rw [h]
  simp [hne]

/-- Mehrere Minima bedeuten keinen freien Selector, sondern eine Sektormasse. -/
theorem multi_min_kernel_two {A : Type} (defect : A -> List Nat)
    (As : List A) (a b : A) (h : paretoMin defect As = [a, b]) :
    paretoKernel defect As = 2 := by
  unfold paretoKernel
  rw [h]
  rfl

/-! ## 4. Relabeling-Natuerlichkeit als Gleichheitsgate -/

/-- Wenn Relabeling die kanonische Minimierermenge exakt auf die relabelte
    Minimierermenge schickt, bleibt die Kernelmasse invariant. Dieses Gate ist
    absichtlich nicht als Labelregel formuliert: Die Gleichheit der Minsets muss
    aus Defekt-Natuerlichkeit bewiesen werden, nicht aus Labelordnung. -/
theorem paretoKernel_relabel_of_minset_eq {A B : Type}
    (defA : A -> List Nat) (defB : B -> List Nat)
    (As : List A) (g : A -> B)
    (h : paretoMin defB (As.map g) = (paretoMin defA As).map g) :
    paretoKernel defB (As.map g) = paretoKernel defA As := by
  unfold paretoKernel
  rw [h]
  simp

/-- Relabeling-Gate fuer eindeutige Minima: ein eindeutig minimales Attachment
    wird durch jedes Minset-kompatible Relabeling wieder eindeutig minimal. -/
theorem unique_min_relabel_of_minset_eq {A B : Type}
    (defA : A -> List Nat) (defB : B -> List Nat)
    (As : List A) (g : A -> B) (a : A)
    (hA : paretoMin defA As = [a])
    (hRel : paretoMin defB (As.map g) = (paretoMin defA As).map g) :
    paretoMin defB (As.map g) = [g a] := by
  rw [hRel, hA]
  rfl

/-! ## 5. Defektsystem als CNNA-Schnittstelle -/

/-- Ein Defektsystem enthaelt nur die endliche Kandidatenliste und eine
    parameterfreie Mehrdefekt-Funktion. Es enthaelt keinen Selector. -/
structure DefectSystem (A : Type) where
  candidates : List A
  defect : A -> List Nat

namespace DefectSystem

/-- Kanonische Sektormenge eines Defektsystems. -/
def minSet {A : Type} (D : DefectSystem A) : List A :=
  paretoMin D.defect D.candidates

/-- Kanonische Kernelmasse eines Defektsystems. -/
def kernel {A : Type} (D : DefectSystem A) : Nat :=
  paretoKernel D.defect D.candidates

/-- Indikatorkernel eines Defektsystems. -/
def sector {A : Type} [DecidableEq A] (D : DefectSystem A) (a : A) : Nat :=
  sectorKernel D.defect D.candidates a

/-- Defektsystem-Kernel ist die Laenge der kanonischen Sektormenge. -/
theorem kernel_eq_minSet_length {A : Type} (D : DefectSystem A) :
    D.kernel = D.minSet.length := rfl

/-- Eindeutige Sektormenge schliesst zum deterministischen Selector-Fall. -/
theorem unique_kernel_one {A : Type} (D : DefectSystem A) (a : A)
    (h : D.minSet = [a]) : D.kernel = 1 := by
  unfold kernel minSet at *
  exact unique_min_kernel_one D.defect D.candidates a h

/-- Zwei gleichwertige Minima schliessen zum Sektorkernel der Masse 2. -/
theorem two_sector_kernel {A : Type} (D : DefectSystem A) (a b : A)
    (h : D.minSet = [a, b]) : D.kernel = 2 := by
  unfold kernel minSet at *
  exact multi_min_kernel_two D.defect D.candidates a b h

end DefectSystem

end CanonicalGrowthKernel

/-
  OFFEN, bewusst nicht behauptet:

  (O1) Schur-DtN-Komplementdaten -> konkrete DefectSystem.candidates.
  (O2) Schur-DtN-Komplementdaten -> konkrete DefectSystem.defect.
  (O3) Beweis, dass ein realer CNNA-Handoff nicht nur SG-ST-symmetrische
       Mehrfachminima, sondern in bestimmten Regimen eindeutige Minima oder
       stabile Sektorkerne erzeugt.

  Geschlossen ist hier die no-free-parameters-Logik:

    Defektfunktor -> Pareto-Minset -> Sektorkernel,

  und der Selector ist nur der Spezialfall einer eindeutigen Minimierermenge.
-/
