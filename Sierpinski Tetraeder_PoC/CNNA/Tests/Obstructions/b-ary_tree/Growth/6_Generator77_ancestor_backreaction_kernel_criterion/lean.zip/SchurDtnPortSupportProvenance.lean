import CNNA.SchurDtnComplementProvenance

namespace SchurDtnPortSupportProvenance

abbrev Node := Fin 3
abbrev PortCutProvenance (V : Type) :=
  SchurDtnComplementProvenance.PortCutProvenance V
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure SchurDtnPortData (V : Type) where
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  dtnPortNodes : List V
  adjacent : V -> V -> Bool


def roleInputNodes {V : Type} (p : SchurDtnPortData V) : List V :=
  p.boundary ++ p.interior ++ p.uvBoundary ++ p.envBoundary ++ p.recordNodes


def addFresh {V : Type} [BEq V] (x : V) (xs : List V) : List V :=
  if SchurDtnComplementProvenance.contains x xs then xs else xs ++ [x]


def uniqueAppend {V : Type} [BEq V] : List V -> List V -> List V
  | [], acc => acc
  | x :: xs, acc => uniqueAppend xs (addFresh x acc)


def supportNodes {V : Type} [BEq V] (p : SchurDtnPortData V) : List V :=
  uniqueAppend (roleInputNodes p ++ p.dtnPortNodes) []


def toPortCutProvenance {V : Type} [BEq V] (p : SchurDtnPortData V) :
    PortCutProvenance V :=
  { supportNodes := supportNodes p,
    boundary := p.boundary,
    interior := p.interior,
    uvBoundary := p.uvBoundary,
    envBoundary := p.envBoundary,
    recordNodes := p.recordNodes,
    adjacent := p.adjacent }


def toFiniteCut {V : Type} [BEq V] (p : SchurDtnPortData V) :
    FiniteCutCombinatorics.FiniteCut V :=
  SchurDtnComplementProvenance.toFiniteCut (toPortCutProvenance p)


theorem toPortCutProvenance_supportNodes {V : Type} [BEq V]
    (p : SchurDtnPortData V) :
    (toPortCutProvenance p).supportNodes = supportNodes p := rfl


theorem toFiniteCut_complementNodes {V : Type} [BEq V]
    (p : SchurDtnPortData V) :
    (toFiniteCut p).complementNodes =
      SchurDtnComplementProvenance.complementNodes
        (toPortCutProvenance p) := rfl


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def beforePortData : SchurDtnPortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    dtnPortNodes := [],
    adjacent := edge01 }


def plusAfterPortData : SchurDtnPortData Node :=
  beforePortData


def minusAfterPortData : SchurDtnPortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    dtnPortNodes := [2],
    adjacent := edge01 }


theorem before_support_nodes_derived :
    supportNodes beforePortData = [0, 1] := rfl


theorem plus_support_nodes_derived :
    supportNodes plusAfterPortData = [0, 1] := rfl


theorem minus_support_nodes_from_port_data :
    supportNodes minusAfterPortData = [0, 1, 2] := rfl


def beforeProvenance : PortCutProvenance Node :=
  toPortCutProvenance beforePortData


def plusAfterProvenance : PortCutProvenance Node :=
  toPortCutProvenance plusAfterPortData


def minusAfterProvenance : PortCutProvenance Node :=
  toPortCutProvenance minusAfterPortData


theorem before_complement_nodes_empty :
    SchurDtnComplementProvenance.complementNodes beforeProvenance = [] := rfl


theorem plus_complement_nodes_empty :
    SchurDtnComplementProvenance.complementNodes plusAfterProvenance = [] := rfl


theorem minus_complement_nodes_derived_from_port_data :
    SchurDtnComplementProvenance.complementNodes minusAfterProvenance = [2] := rfl


def beforeCut : FiniteCut :=
  toFiniteCut beforePortData


def plusAfterCut : FiniteCut :=
  toFiniteCut plusAfterPortData


def minusAfterCut : FiniteCut :=
  toFiniteCut minusAfterPortData


theorem before_cut_complement_empty :
    beforeCut.complementNodes = [] := rfl


theorem plus_cut_complement_empty :
    plusAfterCut.complementNodes = [] := rfl


theorem minus_cut_complement_derived_from_port_data :
    minusAfterCut.complementNodes = [2] := rfl


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterCut = 1 := rfl


def certifiedBlocks (c : FiniteCut) : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks c
    c.boundary.length
    (FiniteGraphLaplacianBlocks.LBBTrace c)
    (FiniteGraphLaplacianBlocks.couplingTrace c)
    (FiniteGraphLaplacianBlocks.graphCutDefect c)


def beforeBlocks : CertifiedSchurBlocks :=
  certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks minusAfterCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_from_port_data :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def portSupportDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem port_support_false_defect :
    portSupportDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem port_support_true_defect :
    portSupportDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem port_support_minSet_singleton :
    portSupportDefectSystem.minSet = [false] := rfl


theorem port_support_kernel_one :
    portSupportDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    portSupportDefectSystem false port_support_minSet_singleton


def portSupportSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := port_support_minSet_singleton }


theorem port_support_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      portSupportDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    portSupportSchurStrictPreference


theorem port_support_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      portSupportDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [port_support_minSet_singleton]
  rfl


theorem port_support_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        portSupportDefectSystem) := by
  intro hclosed
  rw [port_support_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem port_support_closure_status :
    portSupportDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      portSupportDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        portSupportDefectSystem) :=
  And.intro port_support_kernel_one
    (And.intro port_support_resolved_j_sign port_support_not_flip_closed)


def symmetricMinusAfterPortData : SchurDtnPortData Node :=
  plusAfterPortData


def symmetricMinusAfterCut : FiniteCut :=
  toFiniteCut symmetricMinusAfterPortData


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_minSet_pair


theorem symmetric_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_minSet_pair]
  rfl


theorem symmetric_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_kernel_two symmetric_not_resolved_j_sign


def portResidualNodeProvenanceStillOpen : Prop := True


theorem port_residual_node_provenance_still_open :
    portResidualNodeProvenanceStillOpen :=
  True.intro

end SchurDtnPortSupportProvenance
