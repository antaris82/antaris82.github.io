import CNNA.SectorResolutionGate

/-
  GrowthSectorResolutionBridge.lean
  ---------------------------------
  Strukturierter Adapter:

    Growth-Sektor -> Zirkulationssignatur -> LockCandidate -> J-Sign-Closure.

  Diese Datei ersetzt die manuelle Abbildung `A -> LockCandidate` nicht durch
  einen freien Tie-Break. Sie faktorisiert sie ueber eine kleine Signatur des
  Zirkulationszeugen. Damit wird der Pfad enger:

    Growth -> Zirkulation -> Lock -> J-Sign resolved?

  Kein J-Vorzeichen wird global behauptet. Der symmetrische Zwei-Sektorenfall
  bleibt nicht resolved.
-/

namespace GrowthSectorResolutionBridge

abbrev DefectSystem := CanonicalGrowthKernel.DefectSystem
abbrev LockCandidate := JLockingGate.LockCandidate

/-- Die reine Signatur des angebundenen Zirkulationszeugen. -/
inductive CirculationSign where
  | plus
  | minus
  deriving DecidableEq

/-- Der Lock-Adapter aus der Zirkulationssignatur. -/
def signToLock : CirculationSign -> LockCandidate
  | CirculationSign.plus => JLockingGate.plusLock
  | CirculationSign.minus => JLockingGate.minusLock

/-- Ein Growth-Signatur-Adapter ordnet einem Sektor nur sein
    Zirkulationsvorzeichen zu. -/
structure GrowthSectorMap (A : Type) where
  signOf : A -> CirculationSign

/-- Der daraus induzierte Lock-Adapter. -/
def GrowthSectorMap.lockOf {A : Type} (M : GrowthSectorMap A) : A -> LockCandidate :=
  fun a => signToLock (M.signOf a)

/-- Die aus dem kanonischen Minset gepushte Lock-Liste. -/
def GrowthSectorMap.lockCandidates {A : Type} (M : GrowthSectorMap A)
    (D : DefectSystem A) : List LockCandidate :=
  SectorResolutionGate.lockCandidates D M.lockOf

/-- J-Sign-Resolution nach dem strukturierten Growth->Sign->Lock-Adapter. -/
def GrowthSectorMap.hasResolvedJSign {A : Type} (M : GrowthSectorMap A)
    (D : DefectSystem A) : Prop :=
  SectorResolutionGate.hasResolvedJSign D M.lockOf

/-! ## Konkrete Spine-Adapter -/

/-- Der eindeutige Miniport-Sektor besitzt den positiven Zirkulationszeugen. -/
def oneInteriorSectorMap :
    GrowthSectorMap OneInteriorGrowthKernelExample.Attachment :=
  { signOf := fun _ => CirculationSign.plus }

/-- Im symmetrischen Zwei-Sektorenfall tragen die beiden Sektoren
    entgegengesetzte Zirkulationssignaturen. -/
def symmetricSectorMap : GrowthSectorMap Bool :=
  { signOf := fun b =>
      match b with
      | false => CirculationSign.plus
      | true => CirculationSign.minus }

/-- Der eindeutige Miniport-Minset pusht ueber Growth->Sign->Lock genau auf
    den positiven Lock-Sektor. -/
theorem oneInterior_growth_locks_eq_plusSector :
    oneInteriorSectorMap.lockCandidates
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem =
      JSignClosureCriterion.plusSector := by
  unfold GrowthSectorMap.lockCandidates SectorResolutionGate.lockCandidates
    GrowthSectorMap.lockOf oneInteriorSectorMap signToLock
    JSignClosureCriterion.plusSector
  rw [OneInteriorGrowthKernelExample.oneInterior_minSet_singleton]
  rfl

/-- Der eindeutige Miniport ist nach dem strukturierten Adapter resolved. -/
theorem oneInterior_growth_resolved_j_sign :
    oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem := by
  change JSignClosureCriterion.hasClosedJSign
    (oneInteriorSectorMap.lockCandidates
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem)
  rw [oneInterior_growth_locks_eq_plusSector]
  exact JSignClosureCriterion.plusSector_has_closed_j_sign

/-- Der symmetrische Minset pusht ueber Growth->Sign->Lock genau auf das
    Plus/Minus-Sektorpaar. -/
theorem symmetric_growth_locks_eq_twoSectors :
    symmetricSectorMap.lockCandidates
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem =
      JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorMap.lockCandidates SectorResolutionGate.lockCandidates
    GrowthSectorMap.lockOf symmetricSectorMap signToLock
    JSignClosureCriterion.twoSectors
  rw [OneInteriorGrowthKernelExample.symmetricTwo_minSet]
  rfl

/-- Der symmetrische Zwei-Sektorenfall ist auch nach dem strukturierten
    Growth->Sign->Lock-Adapter nicht resolved. -/
theorem symmetric_growth_not_resolved_j_sign :
    ¬ symmetricSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (symmetricSectorMap.lockCandidates
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem)
  rw [symmetric_growth_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign

/-- Direkter Spine-Satz: eindeutiger Growth-Kernel, positiver
    Zirkulationszeuge und resolved J-Sign fallen zusammen. -/
theorem oneInterior_growth_kernel_circulation_and_resolved :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    GrowthToCirculationBridge.oneInteriorCirculation
      OneInteriorGrowthKernelExample.onlyAttachment = 1 ∧
    oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    (And.intro GrowthToCirculationBridge.oneInterior_circulation_one
      oneInterior_growth_resolved_j_sign)

/-- Direkter Spine-Satz: der symmetrische Sektorkernel traegt das
    entgegengesetzte Zirkulationspaar und bleibt nicht resolved. -/
theorem symmetric_growth_kernel_circulations_and_not_resolved :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges false) = 1 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges true) = -1 ∧
    ¬ symmetricSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    (And.intro GrowthToCirculationBridge.symmetric_false_circulation
      (And.intro GrowthToCirculationBridge.symmetric_true_circulation
        symmetric_growth_not_resolved_j_sign))

end GrowthSectorResolutionBridge
