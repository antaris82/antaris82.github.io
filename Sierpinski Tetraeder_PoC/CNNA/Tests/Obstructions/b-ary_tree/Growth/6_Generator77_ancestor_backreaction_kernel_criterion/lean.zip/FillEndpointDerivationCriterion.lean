import CNNA.CanonicalFillOrderCriterion

namespace FillEndpointDerivationCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev InterfaceRole := CanonicalRoleOrderCriterion.InterfaceRole
abbrev InterfaceRoleAssignment :=
  CanonicalRoleOrderCriterion.InterfaceRoleAssignment
abbrev FillEndpoint := CanonicalFillOrderCriterion.FillEndpoint
abbrev AbstractAddressSeed := AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion := AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion

structure CutFillEndpointData (A : Type) where
  sourceAddress : A
  selectedAddress : A
  targetAddress : A
  visibleRoles : List A
  beforeRank : Nat
  afterRank : Nat


def toCutFillEndpointData {A : Type}
    (s : AbstractAddressSeed A) : CutFillEndpointData A :=
  { sourceAddress := s.sourceAddress,
    selectedAddress := s.selectedAddress,
    targetAddress := s.targetAddress,
    visibleRoles := s.visibleRoles,
    beforeRank := s.beforeRank,
    afterRank := s.afterRank }


def endpointFromCutFillData {A : Type} [BEq A]
    (d : CutFillEndpointData A) (a : A) : FillEndpoint :=
  if a == d.sourceAddress then
    CanonicalFillOrderCriterion.FillEndpoint.repeller
  else if (a == d.targetAddress) &&
      decide (d.beforeRank < d.afterRank) &&
      AbstractAddressTypeGrowthCriterion.outsideVisible d.visibleRoles a then
    CanonicalFillOrderCriterion.FillEndpoint.attractor
  else
    CanonicalFillOrderCriterion.FillEndpoint.transit


def addressOfInterfaceRole {A : Type}
    (r : InterfaceRoleAssignment A) : InterfaceRole -> A
  | CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor =>
      r.boundaryAnchorAddress
  | CanonicalRoleOrderCriterion.InterfaceRole.brightSelected =>
      r.brightSelectedAddress
  | CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual =>
      r.frontierResidualAddress


def derivedEndpointOfRole {A : Type} [BEq A]
    (d : CutFillEndpointData A) (r : InterfaceRoleAssignment A)
    (role : InterfaceRole) : FillEndpoint :=
  endpointFromCutFillData d (addressOfInterfaceRole r role)


def derivedFillRankOfRole {A : Type} [BEq A]
    (d : CutFillEndpointData A) (r : InterfaceRoleAssignment A)
    (role : InterfaceRole) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (derivedEndpointOfRole d r role)


def nodeOfFromCutFillData {A : Type} [BEq A]
    (d : CutFillEndpointData A) (a : A) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (endpointFromCutFillData d a)


def currentCutFillEndpointData : CutFillEndpointData CurrentAddress :=
  toCutFillEndpointData CanonicalFillOrderCriterion.currentFillAbstractSeed


theorem current_cut_fill_source_is_cut_root :
    currentCutFillEndpointData.sourceAddress =
      SchurDtnDerivedAddressSeed.cutRoot := rfl


theorem current_cut_fill_target_is_frontier :
    currentCutFillEndpointData.targetAddress =
      SchurDtnDerivedAddressSeed.frontierPortAddress := rfl


theorem current_cut_fill_rank_increases :
    decide (currentCutFillEndpointData.beforeRank <
      currentCutFillEndpointData.afterRank) = true := rfl


theorem current_cut_fill_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentCutFillEndpointData.visibleRoles
      currentCutFillEndpointData.targetAddress = true := rfl


theorem current_endpoint_cut_root_repeller :
    endpointFromCutFillData currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.cutRoot =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_endpoint_selected_transit :
    endpointFromCutFillData currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.selectedChild =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_endpoint_frontier_attractor :
    endpointFromCutFillData currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := by
  change endpointFromCutFillData currentCutFillEndpointData
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  rfl


def currentDerivedEndpointOfRole : InterfaceRole -> FillEndpoint :=
  derivedEndpointOfRole currentCutFillEndpointData
    CanonicalRoleOrderCriterion.currentInterfaceRoleAssignment


theorem current_derived_endpoint_boundary_repeller :
    currentDerivedEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_derived_endpoint_bright_transit :
    currentDerivedEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.brightSelected =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_derived_endpoint_frontier_attractor :
    currentDerivedEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := rfl


theorem current_derived_endpoint_eq_fill_endpoint :
    currentDerivedEndpointOfRole =
      CanonicalFillOrderCriterion.fillEndpointOfRole := by
  funext r
  cases r <;> rfl


def currentDerivedFillRankOfRole : InterfaceRole -> Node :=
  derivedFillRankOfRole currentCutFillEndpointData
    CanonicalRoleOrderCriterion.currentInterfaceRoleAssignment


theorem current_derived_fill_rank_boundary_zero :
    currentDerivedFillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor = 0 := rfl


theorem current_derived_fill_rank_bright_one :
    currentDerivedFillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.brightSelected = 1 := rfl


theorem current_derived_fill_rank_frontier_two :
    currentDerivedFillRankOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 2 := rfl


theorem current_derived_fill_rank_eq_fill_rank :
    currentDerivedFillRankOfRole =
      CanonicalFillOrderCriterion.fillRankOfRole := by
  funext r
  cases r <;> rfl


def currentDerivedFillRankNodeOf : CurrentAddress -> Node :=
  nodeOfFromCutFillData currentCutFillEndpointData


theorem current_derived_fill_nodeOf_eq_fill_order_nodeOf :
    currentDerivedFillRankNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_derived_fill_cut_root_node_zero :
    currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_derived_fill_selected_node_one :
    currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_derived_fill_frontier_node_two :
    currentDerivedFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentDerivedFillRankNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentDerivedFillAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentDerivedFillRankNodeOf }


theorem current_derived_fill_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentDerivedFillAbstractSeed.visibleRoles
      currentDerivedFillAbstractSeed.frontierAddress = true := rfl


def currentDerivedFillSeedCriterion :
    CurrentSeedCriterion currentDerivedFillAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible :=
      current_derived_fill_frontier_outside_visible,
    source_node_zero := current_derived_fill_cut_root_node_zero,
    frontier_node_two := current_derived_fill_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_derived_fill_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentDerivedFillAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem derived_fill_endpoint_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDerivedFillAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentDerivedFillSeedCriterion


theorem derived_fill_endpoint_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDerivedFillAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentDerivedFillSeedCriterion


theorem derived_fill_endpoint_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDerivedFillAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentDerivedFillSeedCriterion


theorem derived_fill_endpoint_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def derivedFillReversalRejectsFrontierZero : Prop :=
  CanonicalRoleOrderCriterion.roleNumberFromOrder
    CanonicalFillOrderCriterion.reversedInterfaceRoleOrder
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 ∧
  currentDerivedFillRankOfRole
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 2


theorem derived_fill_reversal_rejects_frontier_zero :
    derivedFillReversalRejectsFrontierZero :=
  And.intro
    CanonicalFillOrderCriterion.reversed_order_frontier_zero
    current_derived_fill_rank_frontier_two


def endpointDerivationStillLocalCutFillData : Prop := True


theorem endpoint_derivation_still_local_cut_fill_data :
    endpointDerivationStillLocalCutFillData :=
  True.intro

end FillEndpointDerivationCriterion
