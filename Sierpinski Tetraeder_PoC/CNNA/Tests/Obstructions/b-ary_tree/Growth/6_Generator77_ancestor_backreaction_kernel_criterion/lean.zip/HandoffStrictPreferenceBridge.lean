import CNNA.DefectStrictPreferenceGate
import CNNA.HandoffDefectSystem

/-
  HandoffStrictPreferenceBridge.lean
  ----------------------------------
  Gate von konkreten HandoffData-Paaren zu strikter Defektpraeferenz.

  Diese Datei setzt kein J-Vorzeichen, keinen Selector und kein Gewicht.
  Sie zeigt nur:

    Wenn zwei HandoffData-Sektoren ueber das fixierte Defekt-Tupel einen
    kanonischen Singleton-Minset erzeugen, dann resolved der bereits
    strukturierte Growth->Sign->Lock-Pushforward das formale J-Sign-Kriterium.

  Die eigentliche offene CNNA-Frage bleibt: konkrete Schur-DtN- und
  Komplementdaten muessen ein solches striktes Defektgefaelle liefern.
-/

namespace HandoffStrictPreferenceBridge

abbrev HandoffData := HandoffDefectSystem.HandoffData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

/-- Zwei HandoffData-Varianten werden als Plus- und Minus-Sektor gelesen.
    Die Bool-Werte sind nur Sektoretiketten. -/
def handoffDefectSystem (hPlus hMinus : HandoffData) : DefectSystem Bool :=
  { candidates := [false, true],
    defect := fun b =>
      match b with
      | false => HandoffDefectSystem.defectVector hPlus
      | true => HandoffDefectSystem.defectVector hMinus }

/-- Der feste Growth-Sign-Adapter: `false` traegt Plus, `true` traegt Minus.
    Dies ist derselbe Adapter wie im strikten Bool-Gate; der Unterschied kommt
    nur aus den Handoff-Defektvektoren. -/
def handoffSectorMap : GrowthSectorResolutionBridge.GrowthSectorMap Bool :=
  { signOf := fun b =>
      match b with
      | false => GrowthSectorResolutionBridge.CirculationSign.plus
      | true => GrowthSectorResolutionBridge.CirculationSign.minus }

/-- Ein HandoffStrictPreference-Datum ist kein freier Selector. Es ist ein
    Zeuge, dass das kanonisch berechnete Minset des HandoffData-Paars ein
    Singleton ist. -/
structure HandoffStrictPreference (hPlus hMinus : HandoffData) where
  minSet_singleton : (handoffDefectSystem hPlus hMinus).minSet = [false]

/-- Ein striktes Handoff-Praeferenzdatum ist genau ein symmetry-breaking datum
    auf dem bereits berechneten DefectSystem. -/
def HandoffStrictPreference.toBreakingDatum {hPlus hMinus : HandoffData}
    (p : HandoffStrictPreference hPlus hMinus) :
    SymmetryBreakingClosureGate.SymmetryBreakingDatum
      (handoffDefectSystem hPlus hMinus) :=
  { selected := false,
    minSet_singleton := p.minSet_singleton }

/-- Allgemeines Closure-Gate: Wenn HandoffData ein Singleton-Minset erzeugt,
    dann resolved der strukturierte Handoff->Growth->Lock-Pushforward das
    formale J-Sign-Kriterium. -/
theorem resolved_of_handoff_strict_preference
    (hPlus hMinus : HandoffData)
    (p : HandoffStrictPreference hPlus hMinus) :
    handoffSectorMap.hasResolvedJSign
      (handoffDefectSystem hPlus hMinus) :=
  SymmetryBreakingClosureGate.growth_resolved_of_symmetry_breaking_datum
    handoffSectorMap
    (handoffDefectSystem hPlus hMinus)
    p.toBreakingDatum

/-! ## Minimaler HandoffData-Test: Plus perfekt, Minus mit Cut-Defekt 1 -/

/-- Perfekter Plus-Handoff: alle Defektkomponenten verschwinden. -/
def plusPreferredData : HandoffData :=
  { dtnBefore := 0,
    dtnAfter := 0,
    uvLoad := 0,
    envLoad := 0,
    cutDefect := 0,
    recordDefect := 0,
    complementDefect := 0 }

/-- Minus-Handoff mit strikt schlechterem Cut-Defekt. -/
def minusWorseCutData : HandoffData :=
  { dtnBefore := 0,
    dtnAfter := 0,
    uvLoad := 0,
    envLoad := 0,
    cutDefect := 1,
    recordDefect := 0,
    complementDefect := 0 }

theorem plusPreferred_defect_zero :
    HandoffDefectSystem.defectVector plusPreferredData = [0, 0, 0, 0, 0] := rfl

theorem minusWorseCut_defect_one :
    HandoffDefectSystem.defectVector minusWorseCutData = [1, 0, 0, 0, 0] := rfl

/-- Das konkrete HandoffData-Paar als DefectSystem. -/
def strictHandoffDefectSystem : DefectSystem Bool :=
  handoffDefectSystem plusPreferredData minusWorseCutData

/-- Der Handoff-Defektabstand kollabiert das kanonische Minset auf den
    Plus-Sektor. -/
theorem strictHandoff_minSet_singleton :
    strictHandoffDefectSystem.minSet = [false] := rfl

/-- Daher hat der kanonische Growth-Kernel Masse 1. -/
theorem strictHandoff_kernel_one :
    strictHandoffDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    strictHandoffDefectSystem false strictHandoff_minSet_singleton

/-- Das konkrete HandoffData-Paar liefert ein striktes Handoff-Praeferenzdatum. -/
def strictHandoffPreference :
    HandoffStrictPreference plusPreferredData minusWorseCutData :=
  { minSet_singleton := strictHandoff_minSet_singleton }

/-- Der Lock-Pushforward des strikten HandoffData-Paars ist der positive
    Singleton-Sektor. -/
theorem strictHandoff_locks_eq_plusSector :
    handoffSectorMap.lockCandidates strictHandoffDefectSystem =
      JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    handoffSectorMap GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [strictHandoff_minSet_singleton]
  rfl

/-- Strikte HandoffData-Praeferenz resolved das formale J-Sign-Kriterium. -/
theorem strictHandoff_resolved_j_sign :
    handoffSectorMap.hasResolvedJSign strictHandoffDefectSystem :=
  resolved_of_handoff_strict_preference
    plusPreferredData minusWorseCutData strictHandoffPreference

/-- Der strikte Handoff-Pushforward ist nicht flip-geschlossen. -/
theorem strictHandoff_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (handoffSectorMap.lockCandidates strictHandoffDefectSystem) := by
  intro hclosed
  rw [strictHandoff_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed

/-- Kompakter Status des Handoff-Gates. -/
theorem strict_handoff_preference_closure_status :
    strictHandoffDefectSystem.kernel = 1 ∧
    handoffSectorMap.hasResolvedJSign strictHandoffDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (handoffSectorMap.lockCandidates strictHandoffDefectSystem) :=
  And.intro strictHandoff_kernel_one
    (And.intro strictHandoff_resolved_j_sign strictHandoff_not_flip_closed)

/-- Statusmarker: Die konkrete Ableitung eines solchen Defektgefaelles aus
    Schur-DtN-Komplementdaten bleibt offen. -/
def schurDtnToStrictHandoffGapStillOpen : Prop := True

theorem schur_dtn_to_strict_handoff_gap_still_open :
    schurDtnToStrictHandoffGapStillOpen :=
  True.intro

end HandoffStrictPreferenceBridge
