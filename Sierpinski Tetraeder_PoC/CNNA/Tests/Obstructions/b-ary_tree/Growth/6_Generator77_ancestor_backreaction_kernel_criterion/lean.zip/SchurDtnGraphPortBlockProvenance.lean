import CNNA.SchurDtnPortTraceArithmetic

namespace SchurDtnGraphPortBlockProvenance

abbrev Node := Fin 3
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure GraphScalarPortBlock (V : Type) where
  boundaryPort : V
  interiorPort : V
  boundaryLoadNodes : List V
  interiorLoadNodes : List V
  adjacent : V -> V -> Bool
  interiorUnit :
    FiniteCutCombinatorics.countP
      (fun y => adjacent interiorPort y) interiorLoadNodes = 1


def boundaryTrace {V : Type} (b : GraphScalarPortBlock V) : Nat :=
  FiniteCutCombinatorics.countP
    (fun y => b.adjacent b.boundaryPort y) b.boundaryLoadNodes


def interiorTrace {V : Type} (b : GraphScalarPortBlock V) : Nat :=
  FiniteCutCombinatorics.countP
    (fun y => b.adjacent b.interiorPort y) b.interiorLoadNodes


def boundaryInteriorTrace {V : Type} (b : GraphScalarPortBlock V) : Nat :=
  if b.adjacent b.boundaryPort b.interiorPort then 1 else 0


def interiorBoundaryTrace {V : Type} (b : GraphScalarPortBlock V) : Nat :=
  if b.adjacent b.interiorPort b.boundaryPort then 1 else 0


def toScalarPortBlock {V : Type} (b : GraphScalarPortBlock V) :
    SchurDtnPortTraceArithmetic.ScalarPortBlock :=
  { LBB := boundaryTrace b,
    LBI := boundaryInteriorTrace b,
    R := 1,
    LIB := interiorBoundaryTrace b,
    LII := interiorTrace b,
    leftWitness := by
      unfold interiorTrace
      rw [b.interiorUnit],
    rightWitness := by
      unfold interiorTrace
      rw [b.interiorUnit] }


theorem toScalarPortBlock_LBB {V : Type} (b : GraphScalarPortBlock V) :
    (toScalarPortBlock b).LBB = boundaryTrace b := rfl


theorem toScalarPortBlock_LBI {V : Type} (b : GraphScalarPortBlock V) :
    (toScalarPortBlock b).LBI = boundaryInteriorTrace b := rfl


theorem toScalarPortBlock_LIB {V : Type} (b : GraphScalarPortBlock V) :
    (toScalarPortBlock b).LIB = interiorBoundaryTrace b := rfl


theorem toScalarPortBlock_LII {V : Type} (b : GraphScalarPortBlock V) :
    (toScalarPortBlock b).LII = interiorTrace b := rfl


def eqAdj (x y : Node) : Bool :=
  x == y


def zeroGraphPortBlockAt (x : Node) : GraphScalarPortBlock Node :=
  { boundaryPort := x,
    interiorPort := 1,
    boundaryLoadNodes := [],
    interiorLoadNodes := [1],
    adjacent := eqAdj,
    interiorUnit := rfl }


def residualGraphPortBlockAt (x : Node) : GraphScalarPortBlock Node :=
  { boundaryPort := x,
    interiorPort := 1,
    boundaryLoadNodes := [x],
    interiorLoadNodes := [1],
    adjacent := eqAdj,
    interiorUnit := rfl }


theorem zero_graph_node2_boundary_trace_zero :
    boundaryTrace (zeroGraphPortBlockAt 2) = 0 := rfl


theorem zero_graph_node2_boundary_interior_trace_zero :
    boundaryInteriorTrace (zeroGraphPortBlockAt 2) = 0 := rfl


theorem zero_graph_node2_interior_boundary_trace_zero :
    interiorBoundaryTrace (zeroGraphPortBlockAt 2) = 0 := rfl


theorem zero_graph_node2_scalar_trace_zero :
    SchurDtnPortTraceArithmetic.schurDtnTrace
      (toScalarPortBlock (zeroGraphPortBlockAt 2)) = 0 := rfl


theorem residual_graph_node2_boundary_trace_one :
    boundaryTrace (residualGraphPortBlockAt 2) = 1 := rfl


theorem residual_graph_node2_boundary_interior_trace_zero :
    boundaryInteriorTrace (residualGraphPortBlockAt 2) = 0 := rfl


theorem residual_graph_node2_interior_boundary_trace_zero :
    interiorBoundaryTrace (residualGraphPortBlockAt 2) = 0 := rfl


theorem residual_graph_node2_scalar_trace_one :
    SchurDtnPortTraceArithmetic.schurDtnTrace
      (toScalarPortBlock (residualGraphPortBlockAt 2)) = 1 := rfl


structure SchurDtnGraphTracePortData (V : Type) where
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  candidatePortNodes : List V
  beforeGraphPortBlock : V -> GraphScalarPortBlock V
  afterGraphPortBlock : V -> GraphScalarPortBlock V
  adjacent : V -> V -> Bool


def beforePortBlock {V : Type} (p : SchurDtnGraphTracePortData V)
    (x : V) : SchurDtnPortTraceArithmetic.ScalarPortBlock :=
  toScalarPortBlock (p.beforeGraphPortBlock x)


def afterPortBlock {V : Type} (p : SchurDtnGraphTracePortData V)
    (x : V) : SchurDtnPortTraceArithmetic.ScalarPortBlock :=
  toScalarPortBlock (p.afterGraphPortBlock x)


def toTracePortData {V : Type} (p : SchurDtnGraphTracePortData V) :
    SchurDtnPortTraceArithmetic.SchurDtnTracePortData V :=
  { boundary := p.boundary,
    interior := p.interior,
    uvBoundary := p.uvBoundary,
    envBoundary := p.envBoundary,
    recordNodes := p.recordNodes,
    candidatePortNodes := p.candidatePortNodes,
    beforePortBlock := beforePortBlock p,
    afterPortBlock := afterPortBlock p,
    adjacent := p.adjacent }


theorem toTrace_beforePortBlock {V : Type}
    (p : SchurDtnGraphTracePortData V) :
    (toTracePortData p).beforePortBlock = beforePortBlock p := rfl


theorem toTrace_afterPortBlock {V : Type}
    (p : SchurDtnGraphTracePortData V) :
    (toTracePortData p).afterPortBlock = afterPortBlock p := rfl


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def zeroGraphBlockAt (x : Node) : GraphScalarPortBlock Node :=
  zeroGraphPortBlockAt x


def minusAfterGraphBlockAt (x : Node) : GraphScalarPortBlock Node :=
  if x == 2 then residualGraphPortBlockAt x else zeroGraphPortBlockAt x


def beforeGraphTracePortData : SchurDtnGraphTracePortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeGraphPortBlock := zeroGraphBlockAt,
    afterGraphPortBlock := zeroGraphBlockAt,
    adjacent := edge01 }


def plusAfterGraphTracePortData : SchurDtnGraphTracePortData Node :=
  beforeGraphTracePortData


def minusAfterGraphTracePortData : SchurDtnGraphTracePortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeGraphPortBlock := zeroGraphBlockAt,
    afterGraphPortBlock := minusAfterGraphBlockAt,
    adjacent := edge01 }


def beforeTracePortData :
    SchurDtnPortTraceArithmetic.SchurDtnTracePortData Node :=
  toTracePortData beforeGraphTracePortData


def plusAfterTracePortData :
    SchurDtnPortTraceArithmetic.SchurDtnTracePortData Node :=
  toTracePortData plusAfterGraphTracePortData


def minusAfterTracePortData :
    SchurDtnPortTraceArithmetic.SchurDtnTracePortData Node :=
  toTracePortData minusAfterGraphTracePortData


theorem before_trace_port_blocks_from_graph :
    beforeTracePortData.beforePortBlock =
      beforePortBlock beforeGraphTracePortData := rfl


theorem minus_trace_port_block_node2_from_graph :
    SchurDtnPortTraceArithmetic.schurDtnTrace
      (minusAfterTracePortData.afterPortBlock 2) = 1 := rfl


theorem before_trace_port_block_node2_from_graph :
    SchurDtnPortTraceArithmetic.schurDtnTrace
      (beforeTracePortData.beforePortBlock 2) = 0 := rfl


def beforeResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  SchurDtnPortTraceArithmetic.toResidualPortData beforeTracePortData


def plusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  SchurDtnPortTraceArithmetic.toResidualPortData plusAfterTracePortData


def minusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  SchurDtnPortTraceArithmetic.toResidualPortData minusAfterTracePortData


theorem before_residual_port_nodes_empty :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      beforeResidualPortData = [] := rfl


theorem plus_residual_port_nodes_empty :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      plusAfterResidualPortData = [] := rfl


theorem minus_residual_port_nodes_from_graph_schur_provenance :
    SchurDtnPortResidualArithmetic.dtnPortNodes
      minusAfterResidualPortData = [2] := rfl


def beforePortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData beforeResidualPortData


def plusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData plusAfterResidualPortData


def minusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData minusAfterResidualPortData


theorem before_dtn_port_nodes_from_graph_schur_provenance :
    beforePortData.dtnPortNodes = [] := rfl


theorem plus_dtn_port_nodes_from_graph_schur_provenance :
    plusAfterPortData.dtnPortNodes = [] := rfl


theorem minus_dtn_port_nodes_from_graph_schur_provenance :
    minusAfterPortData.dtnPortNodes = [2] := rfl


theorem before_support_nodes_from_graph_schur_provenance :
    SchurDtnPortSupportProvenance.supportNodes beforePortData = [0, 1] := rfl


theorem plus_support_nodes_from_graph_schur_provenance :
    SchurDtnPortSupportProvenance.supportNodes plusAfterPortData = [0, 1] := rfl


theorem minus_support_nodes_from_graph_schur_provenance :
    SchurDtnPortSupportProvenance.supportNodes minusAfterPortData =
      [0, 1, 2] := rfl


def beforeCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut beforePortData


def plusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut plusAfterPortData


def minusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut minusAfterPortData


theorem before_cut_complement_empty :
    beforeCut.complementNodes = [] := rfl


theorem plus_cut_complement_empty :
    plusAfterCut.complementNodes = [] := rfl


theorem minus_cut_complement_from_graph_schur_provenance :
    minusAfterCut.complementNodes = [2] := rfl


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterCut = 1 := rfl


def beforeBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks minusAfterCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_from_graph_schur_provenance :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def graphSchurProvenanceDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem graph_schur_provenance_false_defect :
    graphSchurProvenanceDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem graph_schur_provenance_true_defect :
    graphSchurProvenanceDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem graph_schur_provenance_minSet_singleton :
    graphSchurProvenanceDefectSystem.minSet = [false] := rfl


theorem graph_schur_provenance_kernel_one :
    graphSchurProvenanceDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    graphSchurProvenanceDefectSystem false
    graph_schur_provenance_minSet_singleton


def graphSchurProvenanceStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := graph_schur_provenance_minSet_singleton }


theorem graph_schur_provenance_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      graphSchurProvenanceDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    graphSchurProvenanceStrictPreference


theorem graph_schur_provenance_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      graphSchurProvenanceDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [graph_schur_provenance_minSet_singleton]
  rfl


theorem graph_schur_provenance_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        graphSchurProvenanceDefectSystem) := by
  intro hclosed
  rw [graph_schur_provenance_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem graph_schur_provenance_closure_status :
    graphSchurProvenanceDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      graphSchurProvenanceDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        graphSchurProvenanceDefectSystem) :=
  And.intro graph_schur_provenance_kernel_one
    (And.intro graph_schur_provenance_resolved_j_sign
      graph_schur_provenance_not_flip_closed)


def symmetricMinusAfterGraphTracePortData : SchurDtnGraphTracePortData Node :=
  plusAfterGraphTracePortData


def symmetricMinusAfterTracePortData :
    SchurDtnPortTraceArithmetic.SchurDtnTracePortData Node :=
  toTracePortData symmetricMinusAfterGraphTracePortData


def symmetricMinusAfterResidualPortData :
    SchurDtnPortResidualArithmetic.SchurDtnResidualPortData Node :=
  SchurDtnPortTraceArithmetic.toResidualPortData
    symmetricMinusAfterTracePortData


def symmetricMinusAfterPortData :
    SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  SchurDtnPortResidualArithmetic.toPortData symmetricMinusAfterResidualPortData


def symmetricMinusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut symmetricMinusAfterPortData


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_graph_schur_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_graph_schur_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_graph_schur_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_graph_schur_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_graph_schur_minSet_pair


theorem symmetric_graph_schur_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_graph_schur_minSet_pair]
  rfl


theorem symmetric_graph_schur_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_graph_schur_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_graph_schur_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_graph_schur_kernel_two
    symmetric_graph_schur_not_resolved_j_sign


def graphPortLoadProvenanceStillNeedsCutDerivation : Prop := True


theorem graph_port_load_provenance_still_needs_cut_derivation :
    graphPortLoadProvenanceStillNeedsCutDerivation :=
  True.intro

end SchurDtnGraphPortBlockProvenance
