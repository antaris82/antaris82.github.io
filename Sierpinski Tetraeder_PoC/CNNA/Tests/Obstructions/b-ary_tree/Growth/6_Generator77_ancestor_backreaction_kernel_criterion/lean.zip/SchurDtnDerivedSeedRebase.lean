import CNNA.SchurDtnDerivedAddressSeed

namespace SchurDtnDerivedSeedRebase

abbrev DefectSystem := SectorResolutionGate.DefectSystem

def primaryDefectSystem : DefectSystem Bool :=
  SchurDtnDerivedAddressSeed.derivedAddressSeedDefectSystem


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnDerivedAddressSeed.symmetricDefectSystem


theorem primary_target_record_eq_legacy :
    SchurDtnDerivedAddressSeed.residualAddressTargetRecord =
      SchurDtnFrontierTargetProvenance.residualTargetProvenanceNode2 :=
  SchurDtnDerivedAddressSeed.residual_address_target_record_eq_previous


theorem primary_zero_target_record_eq_legacy :
    SchurDtnDerivedAddressSeed.zeroAddressTargetRecord =
      SchurDtnFrontierTargetProvenance.zeroTargetProvenanceNode2 :=
  SchurDtnDerivedAddressSeed.zero_address_target_record_eq_previous


theorem primary_defect_system_eq_legacy :
    primaryDefectSystem =
      SchurDtnFrontierTargetProvenance.cutFrontierTargetProvenanceDefectSystem :=
  rfl


theorem primary_candidate_targets :
    SchurDtnFrontierTargetProvenance.candidateEdgeTargets
      SchurDtnDerivedAddressSeed.residualAddressTargetRecord = [2] :=
  SchurDtnDerivedAddressSeed.residual_address_candidate_edge_targets


theorem primary_edge_present :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (SchurDtnFrontierEdgeDerivationProvenance.toEdgeTableRecord
        (SchurDtnFrontierTargetProvenance.toEdgeDerivationRecord
          SchurDtnDerivedAddressSeed.residualAddressTargetRecord)) = true :=
  SchurDtnDerivedAddressSeed.residual_address_edge_present


theorem primary_closure_status :
    primaryDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      primaryDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        primaryDefectSystem) :=
  SchurDtnDerivedAddressSeed.derived_address_seed_closure_status


theorem symmetric_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnDerivedAddressSeed.symmetric_derived_address_seed_status

end SchurDtnDerivedSeedRebase
