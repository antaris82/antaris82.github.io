import CNNA.SchurDtnBoundaryResidualSupportProvenance

namespace SchurDtnCutGraphUniverseProvenance

abbrev Node := Fin 3
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure CutGraphUniverseData where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  frontierCandidateNodes : List Node
  boundaryPort : Node
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def baseUniverseNodes (p : CutGraphUniverseData) : List Node :=
  p.boundaryRoleNodes ++ p.interiorRoleNodes


def selectedFrontierNodes (p : CutGraphUniverseData) : List Node -> List Node
  | [] => []
  | x :: xs =>
      if p.frontierAdjacent p.boundaryPort x then
        x :: selectedFrontierNodes p xs
      else
        selectedFrontierNodes p xs


def graphFrontierNodes (p : CutGraphUniverseData) : List Node :=
  selectedFrontierNodes p p.frontierCandidateNodes


def universeNodes (p : CutGraphUniverseData) : List Node :=
  baseUniverseNodes p ++ graphFrontierNodes p


def toBoundaryResidualSupportData (p : CutGraphUniverseData) :
    BoundaryResidualSupportData :=
  { universeNodes := universeNodes p,
    boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    boundaryPort := p.boundaryPort,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toBoundaryResidualSupportData_universeNodes
    (p : CutGraphUniverseData) :
    (toBoundaryResidualSupportData p).universeNodes = universeNodes p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnBoundaryResidualSupportProvenance.eqAdj


def zeroCutGraphUniverseAt (x : Node) : CutGraphUniverseData :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    frontierCandidateNodes := [],
    boundaryPort := x,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualCutGraphUniverseNode2 : CutGraphUniverseData :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    frontierCandidateNodes := [2],
    boundaryPort := 2,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_base_universe_nodes_node2 :
    baseUniverseNodes (zeroCutGraphUniverseAt 2) = [0, 1] := rfl


theorem residual_base_universe_nodes_node2 :
    baseUniverseNodes residualCutGraphUniverseNode2 = [0, 1] := rfl


theorem zero_graph_frontier_nodes_node2 :
    graphFrontierNodes (zeroCutGraphUniverseAt 2) = [] := rfl


theorem residual_graph_frontier_nodes_node2 :
    graphFrontierNodes residualCutGraphUniverseNode2 = [2] := rfl


theorem zero_universe_nodes_node2_from_cut_graph :
    universeNodes (zeroCutGraphUniverseAt 2) = [0, 1] := rfl


theorem residual_universe_nodes_node2_from_cut_graph :
    universeNodes residualCutGraphUniverseNode2 = [0, 1, 2] := rfl


def zeroBoundarySupportAt (x : Node) : BoundaryResidualSupportData :=
  toBoundaryResidualSupportData (zeroCutGraphUniverseAt x)


def residualBoundarySupportNode2 : BoundaryResidualSupportData :=
  toBoundaryResidualSupportData residualCutGraphUniverseNode2


theorem zero_boundary_support_eq_previous_node2 :
    zeroBoundarySupportAt 2 =
      SchurDtnBoundaryResidualSupportProvenance.zeroBoundarySupportAt 2 := rfl


theorem residual_boundary_support_eq_previous_node2 :
    residualBoundarySupportNode2 =
      SchurDtnBoundaryResidualSupportProvenance.residualBoundarySupportNode2 := rfl


theorem residual_support_nodes_node2_from_cut_graph_universe :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualBoundarySupportNode2 = [2] := rfl


theorem residual_candidate_load_nodes_node2_from_cut_graph_universe :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualBoundarySupportNode2) = [1, 2] := rfl


def cutGraphUniverseDefectSystem : DefectSystem Bool :=
  SchurDtnBoundaryResidualSupportProvenance.boundaryResidualSupportDefectSystem


theorem cut_graph_universe_closure_status :
    cutGraphUniverseDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutGraphUniverseDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutGraphUniverseDefectSystem) :=
  SchurDtnBoundaryResidualSupportProvenance.boundary_residual_support_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnBoundaryResidualSupportProvenance.symmetricDefectSystem


theorem symmetric_cut_graph_universe_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnBoundaryResidualSupportProvenance.symmetric_boundary_residual_support_status


def graphFrontierStillNeedsCutGraphDerivation : Prop := True


theorem graph_frontier_still_needs_cut_graph_derivation :
    graphFrontierStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnCutGraphUniverseProvenance
