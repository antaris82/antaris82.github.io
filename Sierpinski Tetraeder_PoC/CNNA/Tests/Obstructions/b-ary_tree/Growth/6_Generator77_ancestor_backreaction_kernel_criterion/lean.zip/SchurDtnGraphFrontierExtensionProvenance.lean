import CNNA.SchurDtnCutGraphUniverseProvenance

namespace SchurDtnGraphFrontierExtensionProvenance

abbrev Node := Fin 3
abbrev CutGraphUniverseData :=
  SchurDtnCutGraphUniverseProvenance.CutGraphUniverseData
abbrev BoundaryResidualSupportData :=
  SchurDtnBoundaryResidualSupportProvenance.BoundaryResidualSupportData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure FrontierExtensionEvent where
  sourcePort : Node
  targetNode : Node
  active : Bool


structure CutFrontierExtensionData where
  boundaryRoleNodes : List Node
  interiorRoleNodes : List Node
  uvBoundaryRoleNodes : List Node
  envBoundaryRoleNodes : List Node
  recordRoleNodes : List Node
  extensionEvents : List FrontierExtensionEvent
  boundaryPort : Node
  interiorPort : Node
  interiorLoadNode : Node
  frontierAdjacent : Node -> Node -> Bool
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def selectedExtensionTargets (p : CutFrontierExtensionData) :
    List FrontierExtensionEvent -> List Node
  | [] => []
  | e :: es =>
      if e.active && (e.sourcePort == p.boundaryPort) then
        e.targetNode :: selectedExtensionTargets p es
      else
        selectedExtensionTargets p es


def frontierCandidateNodes (p : CutFrontierExtensionData) : List Node :=
  selectedExtensionTargets p p.extensionEvents


def toCutGraphUniverseData (p : CutFrontierExtensionData) :
    CutGraphUniverseData :=
  { boundaryRoleNodes := p.boundaryRoleNodes,
    interiorRoleNodes := p.interiorRoleNodes,
    uvBoundaryRoleNodes := p.uvBoundaryRoleNodes,
    envBoundaryRoleNodes := p.envBoundaryRoleNodes,
    recordRoleNodes := p.recordRoleNodes,
    frontierCandidateNodes := frontierCandidateNodes p,
    boundaryPort := p.boundaryPort,
    interiorPort := p.interiorPort,
    interiorLoadNode := p.interiorLoadNode,
    frontierAdjacent := p.frontierAdjacent,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toCutGraphUniverseData_frontierCandidateNodes
    (p : CutFrontierExtensionData) :
    (toCutGraphUniverseData p).frontierCandidateNodes =
      frontierCandidateNodes p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnCutGraphUniverseProvenance.eqAdj


def residualExtensionEventNode2 : FrontierExtensionEvent :=
  { sourcePort := 2,
    targetNode := 2,
    active := true }


def inactiveExtensionEventNode2 : FrontierExtensionEvent :=
  { sourcePort := 2,
    targetNode := 2,
    active := false }


def zeroFrontierExtensionAt (x : Node) : CutFrontierExtensionData :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    extensionEvents := [],
    boundaryPort := x,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualFrontierExtensionNode2 : CutFrontierExtensionData :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    extensionEvents := [residualExtensionEventNode2],
    boundaryPort := 2,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def inactiveFrontierExtensionNode2 : CutFrontierExtensionData :=
  { boundaryRoleNodes := [0],
    interiorRoleNodes := [1],
    uvBoundaryRoleNodes := [1],
    envBoundaryRoleNodes := [0],
    recordRoleNodes := [],
    extensionEvents := [inactiveExtensionEventNode2],
    boundaryPort := 2,
    interiorPort := 1,
    interiorLoadNode := 1,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_frontier_candidate_nodes_node2 :
    frontierCandidateNodes (zeroFrontierExtensionAt 2) = [] := rfl


theorem inactive_frontier_candidate_nodes_node2 :
    frontierCandidateNodes inactiveFrontierExtensionNode2 = [] := rfl


theorem residual_frontier_candidate_nodes_node2 :
    frontierCandidateNodes residualFrontierExtensionNode2 = [2] := rfl


def zeroCutGraphUniverseAt (x : Node) : CutGraphUniverseData :=
  toCutGraphUniverseData (zeroFrontierExtensionAt x)


def residualCutGraphUniverseNode2 : CutGraphUniverseData :=
  toCutGraphUniverseData residualFrontierExtensionNode2


def inactiveCutGraphUniverseNode2 : CutGraphUniverseData :=
  toCutGraphUniverseData inactiveFrontierExtensionNode2


theorem zero_cut_graph_frontier_candidates_node2 :
    (zeroCutGraphUniverseAt 2).frontierCandidateNodes = [] := rfl


theorem inactive_cut_graph_frontier_candidates_node2 :
    inactiveCutGraphUniverseNode2.frontierCandidateNodes = [] := rfl


theorem residual_cut_graph_frontier_candidates_node2 :
    residualCutGraphUniverseNode2.frontierCandidateNodes = [2] := rfl


theorem zero_graph_frontier_nodes_node2 :
    SchurDtnCutGraphUniverseProvenance.graphFrontierNodes
      (zeroCutGraphUniverseAt 2) = [] := rfl


theorem inactive_graph_frontier_nodes_node2 :
    SchurDtnCutGraphUniverseProvenance.graphFrontierNodes
      inactiveCutGraphUniverseNode2 = [] := rfl


theorem residual_graph_frontier_nodes_node2 :
    SchurDtnCutGraphUniverseProvenance.graphFrontierNodes
      residualCutGraphUniverseNode2 = [2] := rfl


theorem zero_universe_nodes_node2_from_extension :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      (zeroCutGraphUniverseAt 2) = [0, 1] := rfl


theorem residual_universe_nodes_node2_from_extension :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      residualCutGraphUniverseNode2 = [0, 1, 2] := rfl


def zeroBoundarySupportAt (x : Node) : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    (zeroCutGraphUniverseAt x)


def residualBoundarySupportNode2 : BoundaryResidualSupportData :=
  SchurDtnCutGraphUniverseProvenance.toBoundaryResidualSupportData
    residualCutGraphUniverseNode2


theorem residual_support_nodes_node2_from_extension :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      residualBoundarySupportNode2 = [2] := rfl


theorem residual_candidate_load_nodes_node2_from_extension :
    SchurDtnCutCandidateLoadProvenance.candidateLoadNodes
      (SchurDtnBoundaryResidualSupportProvenance.toCutCandidateLoadSupportData
        residualBoundarySupportNode2) = [1, 2] := rfl


def cutFrontierExtensionDefectSystem : DefectSystem Bool :=
  SchurDtnCutGraphUniverseProvenance.cutGraphUniverseDefectSystem


theorem cut_frontier_extension_closure_status :
    cutFrontierExtensionDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      cutFrontierExtensionDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        cutFrontierExtensionDefectSystem) :=
  SchurDtnCutGraphUniverseProvenance.cut_graph_universe_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnCutGraphUniverseProvenance.symmetricDefectSystem


theorem symmetric_frontier_extension_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnCutGraphUniverseProvenance.symmetric_cut_graph_universe_status


def frontierExtensionEventStillNeedsCutGraphDerivation : Prop := True


theorem frontier_extension_event_still_needs_cut_graph_derivation :
    frontierExtensionEventStillNeedsCutGraphDerivation :=
  True.intro

end SchurDtnGraphFrontierExtensionProvenance
