/-
  HandoffDefectSystem.lean
  ------------------------
  CNNA-Handoffdaten -> parameterfreies Defektsystem.

  Status: naechster Baustein nach CanonicalGrowthKernel.lean.
  Diese Datei setzt keinen Selector, keine Gewichte, keine Temperatur und
  keinen Label-Tie-Break. Sie konstruiert aus endlichen Handoff-Summaries
  einen Defektvektor. Die kanonische Auswahl bleibt die Pareto- oder Sektormenge.

  Der noch offen bleibende physikalische Schritt ist: konkrete Schur-DtN-Komplementrechnungen muessen die Nat-Summaries dieser Struktur liefern.
-/

namespace HandoffDefectSystem

/-! ## 0. Kleine boolesche Pareto-Basis, selbststaendig -/

def anyP {A : Type} (p : A -> Bool) : List A -> Bool
  | [] => false
  | a :: as => p a || anyP p as

def leAll : List Nat -> List Nat -> Bool
  | [], [] => true
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: as, b :: bs => decide (a <= b) && leAll as bs

def ltAny : List Nat -> List Nat -> Bool
  | [], [] => false
  | [], _ :: _ => false
  | _ :: _, [] => false
  | a :: as, b :: bs => decide (a < b) || ltAny as bs

def dominates (u v : List Nat) : Bool :=
  leAll u v && ltAny u v

def isParetoMin {A : Type} (defect : A -> List Nat) (As : List A) (a : A) : Bool :=
  !(anyP (fun b => dominates (defect b) (defect a)) As)

def paretoMin {A : Type} (defect : A -> List Nat) (As : List A) : List A :=
  As.filter (fun a => isParetoMin defect As a)

def sectorKernel {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A) : Nat :=
  if a ∈ paretoMin defect As then 1 else 0

theorem sectorKernel_one_of_mem {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A)
    (h : a ∈ paretoMin defect As) :
    sectorKernel defect As a = 1 := by
  unfold sectorKernel
  simp [h]

theorem sectorKernel_zero_of_not_mem {A : Type} [DecidableEq A]
    (defect : A -> List Nat) (As : List A) (a : A)
    (h : ¬ a ∈ paretoMin defect As) :
    sectorKernel defect As a = 0 := by
  unfold sectorKernel
  simp [h]

theorem paretoMin_sublist {A : Type} (defect : A -> List Nat) (As : List A) :
    (paretoMin defect As).Sublist As := by
  unfold paretoMin
  exact List.filter_sublist

/-! ## 1. Handoffdaten ohne freie Parameter -/

def absDiff (a b : Nat) : Nat :=
  if a <= b then b - a else a - b

theorem absDiff_self (a : Nat) : absDiff a a = 0 := by
  unfold absDiff
  simp

structure HandoffData where
  dtnBefore : Nat
  dtnAfter : Nat
  uvLoad : Nat
  envLoad : Nat
  cutDefect : Nat
  recordDefect : Nat
  complementDefect : Nat

def dtnDefect (h : HandoffData) : Nat :=
  absDiff h.dtnBefore h.dtnAfter

def balanceDefect (h : HandoffData) : Nat :=
  absDiff h.uvLoad h.envLoad

def defectVector (h : HandoffData) : List Nat :=
  [h.cutDefect,
   dtnDefect h,
   h.recordDefect,
   balanceDefect h,
   h.complementDefect]

theorem defectVector_unfold (h : HandoffData) :
    defectVector h =
      [h.cutDefect,
       absDiff h.dtnBefore h.dtnAfter,
       h.recordDefect,
       absDiff h.uvLoad h.envLoad,
       h.complementDefect] := rfl

theorem dtnDefect_zero_of_equal (a u e c r k : Nat) :
    dtnDefect
      { dtnBefore := a, dtnAfter := a, uvLoad := u, envLoad := e,
        cutDefect := c, recordDefect := r, complementDefect := k } = 0 := by
  unfold dtnDefect
  exact absDiff_self a

theorem balanceDefect_zero_of_equal (d₁ d₂ u c r k : Nat) :
    balanceDefect
      { dtnBefore := d₁, dtnAfter := d₂, uvLoad := u, envLoad := u,
        cutDefect := c, recordDefect := r, complementDefect := k } = 0 := by
  unfold balanceDefect
  exact absDiff_self u

theorem perfect_handoff_defect (d u : Nat) :
    defectVector
      { dtnBefore := d, dtnAfter := d, uvLoad := u, envLoad := u,
        cutDefect := 0, recordDefect := 0, complementDefect := 0 } =
      [0, 0, 0, 0, 0] := by
  simp [defectVector, dtnDefect, balanceDefect, absDiff]

/-! ## 2. Konkretes Defektsystem aus Handoffdaten -/

structure DefectSystem (A : Type) where
  candidates : List A
  defect : A -> List Nat

structure HandoffSystem (A : Type) where
  candidates : List A
  data : A -> HandoffData

def HandoffSystem.defect {A : Type} (s : HandoffSystem A) (a : A) : List Nat :=
  defectVector (s.data a)

def HandoffSystem.toDefectSystem {A : Type} (s : HandoffSystem A) : DefectSystem A :=
  { candidates := s.candidates, defect := s.defect }

def HandoffSystem.minSet {A : Type} (s : HandoffSystem A) : List A :=
  paretoMin s.defect s.candidates

def HandoffSystem.kernel {A : Type} [DecidableEq A] (s : HandoffSystem A) (a : A) : Nat :=
  sectorKernel s.defect s.candidates a

theorem HandoffSystem.toDefectSystem_defect {A : Type}
    (s : HandoffSystem A) (a : A) :
    s.toDefectSystem.defect a = defectVector (s.data a) := rfl

theorem HandoffSystem.toDefectSystem_candidates {A : Type}
    (s : HandoffSystem A) :
    s.toDefectSystem.candidates = s.candidates := rfl

theorem HandoffSystem.minSet_sublist {A : Type} (s : HandoffSystem A) :
    s.minSet.Sublist s.candidates := by
  unfold HandoffSystem.minSet
  exact paretoMin_sublist s.defect s.candidates

theorem HandoffSystem.kernel_one_of_mem {A : Type} [DecidableEq A]
    (s : HandoffSystem A) (a : A) (h : a ∈ s.minSet) :
    s.kernel a = 1 := by
  unfold HandoffSystem.kernel HandoffSystem.minSet at *
  exact sectorKernel_one_of_mem s.defect s.candidates a h

theorem HandoffSystem.kernel_zero_of_not_mem {A : Type} [DecidableEq A]
    (s : HandoffSystem A) (a : A) (h : ¬ a ∈ s.minSet) :
    s.kernel a = 0 := by
  unfold HandoffSystem.kernel HandoffSystem.minSet at *
  exact sectorKernel_zero_of_not_mem s.defect s.candidates a h

/-! ## 3. Keine Gewichtung: Defekt ist ein fixiertes Tupel -/

theorem HandoffSystem.defect_is_fixed_tuple {A : Type}
    (s : HandoffSystem A) (a : A) :
    s.defect a =
      [(s.data a).cutDefect,
       absDiff (s.data a).dtnBefore (s.data a).dtnAfter,
       (s.data a).recordDefect,
       absDiff (s.data a).uvLoad (s.data a).envLoad,
       (s.data a).complementDefect] := rfl

end HandoffDefectSystem
