import CNNA.FrontierEventPhaseBridgeCriterion

namespace FillOrbitBasinCriterion

abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev Node := Fin 3
abbrev FillEndpoint := CanonicalFillOrderCriterion.FillEndpoint
abbrev AbstractAddressSeed :=
  AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion

inductive LocalFillOrbitClass where
  | fixedZero
  | fixedOne
  | flowsTwoToOne
  | uncheckedOther
  deriving BEq, DecidableEq


def currentFillValue : CurrentAddress -> Nat
  | SchurDtnDerivedAddressSeed.Address.root => 0
  | SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.left => 1
  | SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right => 2


def orbitClassOfFillValue : Nat -> LocalFillOrbitClass
  | 0 => LocalFillOrbitClass.fixedZero
  | 1 => LocalFillOrbitClass.fixedOne
  | 2 => LocalFillOrbitClass.flowsTwoToOne
  | _ => LocalFillOrbitClass.uncheckedOther


def currentOrbitClass (a : CurrentAddress) : LocalFillOrbitClass :=
  orbitClassOfFillValue (currentFillValue a)


def orbitEndpointDiagnostic : LocalFillOrbitClass -> FillEndpoint
  | LocalFillOrbitClass.fixedZero =>
      CanonicalFillOrderCriterion.FillEndpoint.repeller
  | LocalFillOrbitClass.fixedOne =>
      CanonicalFillOrderCriterion.FillEndpoint.transit
  | LocalFillOrbitClass.flowsTwoToOne =>
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  | LocalFillOrbitClass.uncheckedOther =>
      CanonicalFillOrderCriterion.FillEndpoint.transit


def currentOrbitEndpointDiagnostic (a : CurrentAddress) : FillEndpoint :=
  orbitEndpointDiagnostic (currentOrbitClass a)


def currentOrbitNodeOf (a : CurrentAddress) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (currentOrbitEndpointDiagnostic a)


theorem local_fill_map_two_zero_fixed :
    CanonicalFillOrderCriterion.localFillMap 2 0 = 0 := rfl


theorem local_fill_map_two_one_fixed :
    CanonicalFillOrderCriterion.localFillMap 2 1 = 1 := rfl


theorem local_fill_map_two_two_flows_to_one :
    CanonicalFillOrderCriterion.localFillMap 2 2 = 1 := rfl


theorem local_fill_map_two_two_stays_one_after_second_step :
    CanonicalFillOrderCriterion.localFillMap 2
      (CanonicalFillOrderCriterion.localFillMap 2 2) = 1 := rfl


theorem current_cut_root_fill_value_zero :
    currentFillValue SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_selected_fill_value_one :
    currentFillValue SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_frontier_fill_value_two :
    currentFillValue SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentFillValue
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


theorem current_frontier_fill_value_flows_to_selected_value :
    CanonicalFillOrderCriterion.localFillMap 2
      (currentFillValue SchurDtnDerivedAddressSeed.frontierPortAddress) =
      currentFillValue SchurDtnDerivedAddressSeed.selectedChild := by
  change CanonicalFillOrderCriterion.localFillMap 2
      (currentFillValue
        (SchurDtnDerivedAddressSeed.Address.child
          SchurDtnDerivedAddressSeed.Branch.right)) =
      currentFillValue
        (SchurDtnDerivedAddressSeed.Address.child
          SchurDtnDerivedAddressSeed.Branch.left)
  rfl


theorem current_cut_root_orbit_class_fixed_zero :
    currentOrbitClass SchurDtnDerivedAddressSeed.cutRoot =
      LocalFillOrbitClass.fixedZero := rfl


theorem current_selected_orbit_class_fixed_one :
    currentOrbitClass SchurDtnDerivedAddressSeed.selectedChild =
      LocalFillOrbitClass.fixedOne := rfl


theorem current_frontier_orbit_class_flows_two_to_one :
    currentOrbitClass SchurDtnDerivedAddressSeed.frontierPortAddress =
      LocalFillOrbitClass.flowsTwoToOne := by
  change currentOrbitClass
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      LocalFillOrbitClass.flowsTwoToOne
  rfl


theorem current_orbit_endpoint_cut_root_repeller :
    currentOrbitEndpointDiagnostic SchurDtnDerivedAddressSeed.cutRoot =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_orbit_endpoint_selected_transit :
    currentOrbitEndpointDiagnostic SchurDtnDerivedAddressSeed.selectedChild =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_orbit_endpoint_frontier_attractor_code :
    currentOrbitEndpointDiagnostic
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := by
  change currentOrbitEndpointDiagnostic
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  rfl


theorem current_orbit_endpoint_eq_dynamic_endpoint :
    currentOrbitEndpointDiagnostic =
      FillDynamicsRankCriterion.dynamicEndpointFromCutFillData
        FillEndpointDerivationCriterion.currentCutFillEndpointData := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_orbit_nodeOf_eq_event_backed_nodeOf :
    currentOrbitNodeOf =
      FrontierEventPhaseBridgeCriterion.currentEventBackedNodeOf := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_orbit_nodeOf_eq_fill_order_nodeOf :
    currentOrbitNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_orbit_nodeOf_eq_event_backed_nodeOf]
  exact FrontierEventPhaseBridgeCriterion.current_event_backed_nodeOf_eq_fill_order_nodeOf


theorem current_orbit_cut_root_node_zero :
    currentOrbitNodeOf SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_orbit_selected_node_one :
    currentOrbitNodeOf SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_orbit_frontier_node_two :
    currentOrbitNodeOf SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentOrbitNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def frontierFlowsToSelectedButEndpointCodeIsTwo : Prop :=
  CanonicalFillOrderCriterion.localFillMap 2
      (currentFillValue SchurDtnDerivedAddressSeed.frontierPortAddress) =
      currentFillValue SchurDtnDerivedAddressSeed.selectedChild ∧
  currentOrbitNodeOf SchurDtnDerivedAddressSeed.frontierPortAddress = 2


theorem frontier_flows_to_selected_but_endpoint_code_is_two :
    frontierFlowsToSelectedButEndpointCodeIsTwo :=
  And.intro
    current_frontier_fill_value_flows_to_selected_value
    current_orbit_frontier_node_two


def residualEventHasOrbitWitness : Prop :=
  SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
      true ∧
  CanonicalFillOrderCriterion.localFillMap 2
      (currentFillValue SchurDtnDerivedAddressSeed.frontierPortAddress) =
      currentFillValue SchurDtnDerivedAddressSeed.selectedChild


theorem residual_event_has_orbit_witness :
    residualEventHasOrbitWitness :=
  And.intro
    FrontierEventPhaseBridgeCriterion.residual_event_active
    current_frontier_fill_value_flows_to_selected_value


def currentOrbitAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentOrbitNodeOf }


theorem current_orbit_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentOrbitAbstractSeed.visibleRoles
      currentOrbitAbstractSeed.frontierAddress = true := rfl


def currentOrbitSeedCriterion :
    CurrentSeedCriterion currentOrbitAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := current_orbit_frontier_outside_visible,
    source_node_zero := current_orbit_cut_root_node_zero,
    frontier_node_two := current_orbit_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem orbit_basin_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentOrbitAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentOrbitSeedCriterion


theorem orbit_basin_closes_g1_path :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


theorem orbit_basin_keeps_inactive_event_gap :
    FrontierEventPhaseBridgeCriterion.inactiveEventShowsEdgePresentNotInPhase :=
  FrontierEventPhaseBridgeCriterion.inactive_event_shows_edge_present_not_in_phase


def fillOrbitBasinStillLocalDiagnostic : Prop := True


theorem fill_orbit_basin_still_local_diagnostic :
    fillOrbitBasinStillLocalDiagnostic :=
  True.intro

end FillOrbitBasinCriterion
