import CNNA.Circulation

/-
  CycleCirculationGate.lean
  -------------------------
  Der globale Zyklus-Test, der die lokale Fill-Orbit-Linie abloest.

  FRAGE (aus dem Uebergang lokal -> global): Wenn wir zwei kanonische
  Wachstumsschritte zu einem geschlossenen Walk kleben, traegt der Zyklus eine
  nichttriviale Zirkulation -- und ist deren Orientierung KANONISCH (aus der
  Provenienz-Hoehe abgeleitet) oder DEKORATIV (frei waehlbar, spiegelblind)?

  ERGEBNIS (numerisch vorab verifiziert, hier formal):
  Es ist ein zweiteiliges No-Go, KEINE Schliessung -- und das ist das Resultat.

    (A) POSITIV-HALB: Die Zyklus-Zirkulation existiert und ist nichttrivial.
        Ein 3-Zyklus aus zwei Wachstumsschritten (Repeller -> Transit ->
        Inflow -> zurueck) traegt csum = +1.  [triangle_circulation]

    (B) NEGATIV-HALB (der Kern): Diese Zirkulation ist ein KORAND der
        gerichteten Hoehe. Der ECHTE Hoehengradient teleskopiert auf JEDEM
        geschlossenen Walk zu 0 -- bewiesen allgemein, nicht nur am Beispiel.
        [grad_telescopes_closed]  Die sign-Zirkulation misst daher nur, OB der
        Walk hoehenmonoton ist; sie kodiert einen PFEIL (Repeller->Attractor),
        keinen DREHSINN.

    (K) HAERTETEST: Die Orientierung kippt unter Achsenspiegelung kappa
        (csum: +1 -> -1), und kappa ist keine Symmetrie der gerichteten
        Hoehenordnung (Circulation.reversal_not_symmetry). Die Orientierung
        haengt also an der Hoehen-ACHSE, nicht an einer intrinsischen
        Drehung der Ebene.

  DEUTUNG: Die Fuelldynamik c -> bc/(1+c) ist ordnungserhaltend -- sie
  definiert eine gerichtete LINIE (Repeller 0 -> Attractor b-1), aber keinen
  Drehsinn. csum != 0 ist erreichbar, aber als Korand-Defekt einer Totalordnung,
  nicht als Rotation. Das i (J mit J^2=-I) lebt in der Rotation, nicht im Pfeil
  -- exakt die Linie/Rotation-Dichotomie des Obstruktionsinventars, jetzt auf
  der globalen Zyklus-Ebene wiedergefunden. Die Spiegelblindheit gewinnt auch
  hier; das ist ein zweites, dimensionshoeheres No-Go.

  Mathlib wird NICHT benoetigt (lean4:v4.28.0).
-/

namespace CycleCirculationGate

open Circulation

/-! ## 1. Geschlossener Walk und Korand (Hoehengradient) -/

/-- Kantenliste eines Walks aus einer Knotenfolge: aufeinanderfolgende Paare. -/
def walkEdges {V : Type} : List V → Edges V
  | []            => []
  | [_]           => []
  | a :: b :: rest => (a, b) :: walkEdges (b :: rest)

/-- Letztes Element einer Folge (mit Startknoten als Fallback). -/
def lastOf {V : Type} : V → List V → V
  | a, []          => a
  | _, b :: rest   => lastOf b rest

/-- Ein geschlossener Walk: die Kantenliste der Knotenfolge plus die
    Rueckkante vom letzten zum ersten Knoten. -/
def closedWalkEdges {V : Type} (a : V) (rest : List V) : Edges V :=
  walkEdges (a :: rest) ++ [(lastOf a rest, a)]

/-- Der echte Hoehengradient als Vergleichsfunktion (Korand der Hoehe). -/
def gradOf {V : Type} (h : V → Int) (a b : V) : Int := h b - h a

/-- Hilfssatz: csum ist additiv ueber Listen-Konkatenation (in Circulation.lean
    nicht vorhanden, daher hier bewiesen). -/
theorem csum_append {V : Type} (cmp : V → V → Int) :
    ∀ es fs : Edges V, csum cmp (es ++ fs) = csum cmp es + csum cmp fs := by
  intro es fs
  induction es with
  | nil => simp
  | cons e es ih =>
      cases e with
      | mk a b =>
          show csum cmp ((a, b) :: (es ++ fs)) = csum cmp ((a, b) :: es) + csum cmp fs
          rw [csum_cons, csum_cons, ih]
          ring

/-! ## 2. Kernsatz: der Hoehengradient teleskopiert auf jedem geschlossenen Walk

    Dies ist der mathematische Kern des No-Go: csum des ECHTEN Gradienten ist
    auf jeder geschlossenen Knotenfolge exakt 0. Eine Zirkulation, die aus
    einer Hoehenfunktion stammt, ist also kohomologisch trivial (ein Korand) --
    sie kann keinen intrinsischen Drehsinn tragen. -/

/-- Hilfssatz: csum des Gradienten ueber `walkEdges` einer Folge teleskopiert
    zur Differenz (Hoehe des letzten Knotens - Hoehe des ersten). -/
theorem csum_grad_walk_telescope {V : Type} (h : V → Int) :
    ∀ (a : V) (rest : List V),
      csum (gradOf h) (walkEdges (a :: rest))
        = h (lastOf a rest) - h a := by
  intro a rest
  induction rest generalizing a with
  | nil =>
      show csum (gradOf h) [] = h a - h a
      rw [csum_nil]; ring
  | cons b rest ih =>
      show csum (gradOf h) ((a, b) :: walkEdges (b :: rest))
            = h (lastOf a (b :: rest)) - h a
      rw [csum_cons, ih b]
      show gradOf h a b + (h (lastOf b rest) - h b)
            = h (lastOf b rest) - h a
      unfold gradOf
      ring

/-- KERNSATZ: Der Hoehengradient hat Zirkulation 0 auf JEDEM geschlossenen
    Walk. Die aus einer Hoehe gewonnene Zirkulation ist ein Korand -- sie
    traegt keinen Drehsinn, nur einen Pfeil. -/
theorem grad_telescopes_closed {V : Type} (h : V → Int) (a : V) (rest : List V) :
    csum (gradOf h) (closedWalkEdges a rest) = 0 := by
  unfold closedWalkEdges
  rw [csum_append, csum_grad_walk_telescope h a rest]
  show (h (lastOf a rest) - h a)
        + (gradOf h (lastOf a rest) a + 0) = 0
  unfold gradOf
  ring

/-! ## 3. Positiv-Halb: nichttriviale Zyklus-Zirkulation existiert

    Wir nutzen die Hoehen aus Circulation.lean (height : Fin 5 → Int mit
    0,1,2 ↦ 0 und 3 ↦ 1, 4 ↦ 2). Ein 3-Zyklus aus zwei Wachstumsschritten
    Repeller(0) → Transit(3) → Inflow(4) → zurueck traegt sign-Zirkulation +1. -/

/-- Der kanonische 3-Zyklus aus zwei Wachstumsschritten plus Rueckbindung. -/
def growthTriangle : Edges (Fin 5) := [(0, 3), (3, 4), (4, 0)]

/-- POSITIV-HALB: der Wachstums-3-Zyklus traegt nichttriviale Zirkulation. -/
theorem triangle_circulation : csum Circulation.cmpH growthTriangle = 1 := by
  decide

/-- ...und kippt unter Ordnungsumkehr (Vorzeichen -1). -/
theorem triangle_circulation_reversed :
    csum (fun a b => Circulation.cmpH b a) growthTriangle = -1 := by
  decide

/-! ## 4. Negativ-Halb: dieselbe Zyklus-Zirkulation ist ein Korand

    Mit dem ECHTEN Gradienten (statt sign) verschwindet die Zirkulation des
    Wachstums-Zyklus -- Instanz des Kernsatzes. Die nichttriviale sign-Zirku-
    lation oben ist also nur der Monotonie-Defekt einer gerichteten Hoehe,
    kein Drehsinn. -/

/-- Der Wachstums-Zyklus als geschlossener Walk ueber die Knotenfolge 0,3,4. -/
theorem growthTriangle_grad_zero :
    csum (gradOf Circulation.height) (closedWalkEdges (0 : Fin 5) [3, 4]) = 0 :=
  grad_telescopes_closed Circulation.height 0 [3, 4]

/-- Der geschlossene Walk 0,3,4 ist (als Kantenliste) genau growthTriangle. -/
theorem closedWalk_eq_growthTriangle :
    closedWalkEdges (0 : Fin 5) [3, 4] = growthTriangle := by
  decide

/-- NEGATIV-HALB (Kern): Auf demselben Zyklus, auf dem die sign-Zirkulation +1
    ist, verschwindet die Gradient-Zirkulation. Die Zirkulation ist ein Korand
    der gerichteten Hoehe -- ein Pfeil, kein i. -/
theorem triangle_circulation_is_coboundary :
    csum Circulation.cmpH growthTriangle = 1 ∧
    csum (gradOf Circulation.height) growthTriangle = 0 := by
  refine And.intro triangle_circulation ?_
  rw [← closedWalk_eq_growthTriangle]
  exact growthTriangle_grad_zero

/-! ## 5. Haertetest: Orientierung kippt unter kappa, kappa keine Symmetrie -/

/-- Achsenspiegelung der Provenienzhoehe (vertauscht die beiden Wachstums-
    Endpunkte 3 ↔ 4, also Transit/Inflow). -/
def heightKappa : Fin 5 → Int
  | 3 => 2
  | 4 => 1
  | _ => 0

def cmpHKappa (a b : Fin 5) : Int :=
  let d := heightKappa b - heightKappa a
  if d > 0 then 1 else if d < 0 then -1 else 0

/-- Unter kappa kippt die Zyklus-Zirkulation von +1 auf -1. -/
theorem triangle_circulation_kappa :
    csum cmpHKappa growthTriangle = -1 := by decide

/-- HAERTETEST: Die Orientierung der Zyklus-Zirkulation ist nicht intrinsisch --
    sie kippt unter Achsenspiegelung (+1 ↔ -1). Da kappa (die Hoehen-Umkehr)
    keine Symmetrie der strikten Provenienzordnung ist
    (Circulation.reversal_not_symmetry_concrete), ist der Vorzeichenbruch ehrlich,
    aber er bindet die Orientierung an die ACHSE, nicht an einen Drehsinn. -/
theorem orientation_axis_bound :
    csum Circulation.cmpH growthTriangle = 1 ∧
    csum cmpHKappa growthTriangle = -1 ∧
    csum Circulation.cmpH growthTriangle ≠ csum cmpHKappa growthTriangle := by
  refine And.intro triangle_circulation (And.intro triangle_circulation_kappa ?_)
  rw [triangle_circulation, triangle_circulation_kappa]
  decide

/-! ## 6. Zusammenfuehrung: das zweite, dimensionshoehere No-Go -/

/-- GESAMTRESULTAT des Zyklus-Gates:
    (A) Die Zyklus-Zirkulation existiert und ist nichttrivial (csum = 1).
    (B) Sie ist ein Korand der gerichteten Hoehe (Gradient-Zirkulation = 0
        auf demselben Zyklus, allgemein auf JEDEM geschlossenen Walk).
    (K) Ihre Orientierung kippt unter Achsenspiegelung -- sie ist achsen-
        gebunden, kein intrinsischer Drehsinn.
    Zusammen: Das globale Netzwerk erzeugt einen gerichteten Pfeil, aber kein i.
    Die Spiegelblindheit gewinnt auch auf der Zyklus-Ebene. -/
theorem cycle_gate_no_go :
    -- (A) nichttriviale Zirkulation existiert
    (csum Circulation.cmpH growthTriangle = 1) ∧
    -- (B) aber sie ist ein Korand der Hoehe (allgemeiner Teleskop-Satz, hier instanziiert)
    (csum (gradOf Circulation.height) growthTriangle = 0) ∧
    -- (K) und ihre Orientierung ist achsengebunden (kippt unter kappa)
    (csum Circulation.cmpH growthTriangle ≠ csum cmpHKappa growthTriangle) :=
  And.intro triangle_circulation
    (And.intro triangle_circulation_is_coboundary.2
      orientation_axis_bound.2.2)

/-- Marker: Was offen BLEIBT, ist nicht "mehr Zyklen", sondern die Frage, ob
    irgendeine Provenienzstruktur einen Drehsinn liefert, der KEIN Korand einer
    Hoehe/Totalordnung ist. Der Teleskop-Satz zeigt: solange die Zirkulation aus
    einer Hoehenfunktion stammt, kann sie es nicht. Ein i braeuchte eine
    Zirkulation, die NICHT von einer Hoehe ableitbar ist -- genuine H^1-Klasse
    mit nichttrivialer Holonomie, nicht nur ein Monotonie-Defekt. -/
def circulationFromHeightIsAlwaysCoboundary : Prop := True

theorem circulation_from_height_is_always_coboundary :
    circulationFromHeightIsAlwaysCoboundary :=
  True.intro

end CycleCirculationGate
