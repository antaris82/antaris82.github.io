import CNNA.ConcreteMatrixArithmetic
import CNNA.SchurStrictPreferenceBridge

namespace ConcreteSymmetricCutG1Test

abbrev Node := Fin 2
abbrev FiniteCut := FiniteCutCombinatorics.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def symmetricTwoNodeCut : FiniteCut :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    complementNodes := [],
    adjacent := edge01 }


theorem symmetric_lbb_trace_one :
    FiniteGraphLaplacianBlocks.LBBTrace symmetricTwoNodeCut = 1 := rfl


theorem symmetric_coupling_trace_one :
    FiniteGraphLaplacianBlocks.couplingTrace symmetricTwoNodeCut = 1 := rfl


theorem symmetric_graph_cut_defect_zero :
    FiniteGraphLaplacianBlocks.graphCutDefect symmetricTwoNodeCut = 0 := rfl


def symmetricConcreteBlocks : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks symmetricTwoNodeCut
    1
    (FiniteGraphLaplacianBlocks.LBBTrace symmetricTwoNodeCut)
    (FiniteGraphLaplacianBlocks.couplingTrace symmetricTwoNodeCut)
    (FiniteGraphLaplacianBlocks.graphCutDefect symmetricTwoNodeCut)


theorem symmetric_concrete_lbb_trace_one :
    symmetricConcreteBlocks.raw.LBBTrace = 1 := rfl


theorem symmetric_concrete_coupling_trace_one :
    symmetricConcreteBlocks.raw.couplingTrace = 1 := rfl


theorem symmetric_concrete_cut_defect_zero :
    symmetricConcreteBlocks.raw.cutDefect = 0 := rfl


theorem symmetric_concrete_schur_trace_zero :
    FiniteMatrixSchurPort.schurTrace
      (DirichletInverseWitness.toInvertibleSchurBlocks symmetricConcreteBlocks) = 0 := rfl


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricConcreteBlocks


def plusAfterSummary : SchurSummary :=
  beforeSummary


def minusAfterSummary : SchurSummary :=
  beforeSummary


def symmetricConcreteDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem symmetric_concrete_false_defect_zero :
    symmetricConcreteDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_concrete_true_defect_zero :
    symmetricConcreteDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_concrete_minSet_pair :
    symmetricConcreteDefectSystem.minSet = [false, true] := rfl


theorem symmetric_concrete_kernel_two :
    symmetricConcreteDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricConcreteDefectSystem false true symmetric_concrete_minSet_pair


theorem symmetric_concrete_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricConcreteDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_concrete_minSet_pair]
  rfl


theorem symmetric_concrete_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricConcreteDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricConcreteDefectSystem)
  rw [symmetric_concrete_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_concrete_status :
    symmetricConcreteDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricConcreteDefectSystem :=
  And.intro symmetric_concrete_kernel_two symmetric_concrete_not_resolved_j_sign


def staticSymmetricConcreteCutDoesNotBreakSign : Prop :=
  symmetricConcreteDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricConcreteDefectSystem


theorem static_symmetric_concrete_cut_does_not_break_sign :
    staticSymmetricConcreteCutDoesNotBreakSign :=
  symmetric_concrete_status

end ConcreteSymmetricCutG1Test
