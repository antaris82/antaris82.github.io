import CNNA.SchurDtnProvenanceCycleBoundary

namespace SchurDtnDerivedAddressSeed

abbrev Node := Fin 3
abbrev CutGraphTargetProvenanceRecord :=
  SchurDtnFrontierTargetProvenance.CutGraphTargetProvenanceRecord
abbrev DefectSystem := SectorResolutionGate.DefectSystem

inductive Branch where
  | left
  | right
  deriving BEq, DecidableEq

inductive Address where
  | root
  | child (b : Branch)
  deriving BEq, DecidableEq


def addressNode : Address -> Node
  | Address.root => 0
  | Address.child Branch.left => 1
  | Address.child Branch.right => 2


def cutRoot : Address :=
  Address.root


def selectedChild : Address :=
  Address.child Branch.left


def childAddresses : Address -> List Address
  | Address.root => [Address.child Branch.left, Address.child Branch.right]
  | Address.child _ => []


def boundaryAddresses : List Address :=
  [cutRoot]


def interiorAddresses : List Address :=
  [selectedChild]


def uvBoundaryAddresses : List Address :=
  [selectedChild]


def envBoundaryAddresses : List Address :=
  [cutRoot]


def recordAddresses : List Address :=
  []


def roleAddresses : List Address :=
  boundaryAddresses ++ interiorAddresses ++ uvBoundaryAddresses ++
    envBoundaryAddresses ++ recordAddresses


def containsAddress (x : Address) : List Address -> Bool
  | [] => false
  | y :: ys => if x == y then true else containsAddress x ys


def outsideRoleAddress (x : Address) : Bool :=
  if containsAddress x roleAddresses then false else true


def residualAddresses : List Address -> List Address
  | [] => []
  | x :: xs =>
      if outsideRoleAddress x then
        x :: residualAddresses xs
      else
        residualAddresses xs


def frontierAddressCandidates : List Address :=
  residualAddresses (childAddresses cutRoot)


def visibleAddressUniverse : List Address :=
  boundaryAddresses ++ interiorAddresses


def residualAddressUniverse : List Address :=
  visibleAddressUniverse ++ frontierAddressCandidates


def addressNodes : List Address -> List Node
  | [] => []
  | x :: xs => addressNode x :: addressNodes xs


def zeroUniverseNodes : List Node :=
  addressNodes visibleAddressUniverse


def residualUniverseNodes : List Node :=
  addressNodes residualAddressUniverse


def frontierPortAddress : Address :=
  match frontierAddressCandidates with
  | [] => cutRoot
  | x :: _ => x


def frontierPortNode : Node :=
  addressNode frontierPortAddress


theorem child_addresses_root :
    childAddresses cutRoot =
      [Address.child Branch.left, Address.child Branch.right] := rfl


theorem role_addresses_raw :
    roleAddresses =
      [Address.root, Address.child Branch.left,
        Address.child Branch.left, Address.root] := rfl


theorem frontier_address_candidates_derived :
    frontierAddressCandidates = [Address.child Branch.right] := rfl


theorem frontier_port_address_derived :
    frontierPortAddress = Address.child Branch.right := rfl


theorem frontier_port_node_derived :
    frontierPortNode = 2 := rfl


theorem zero_universe_nodes_from_addresses :
    zeroUniverseNodes = [0, 1] := rfl


theorem residual_universe_nodes_from_addresses :
    residualUniverseNodes = [0, 1, 2] := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnFrontierTargetProvenance.eqAdj


def zeroAddressTargetRecord : CutGraphTargetProvenanceRecord :=
  { boundaryRoleNodes := addressNodes boundaryAddresses,
    interiorRoleNodes := addressNodes interiorAddresses,
    uvBoundaryRoleNodes := addressNodes uvBoundaryAddresses,
    envBoundaryRoleNodes := addressNodes envBoundaryAddresses,
    recordRoleNodes := addressNodes recordAddresses,
    universeNodes := zeroUniverseNodes,
    boundaryPort := frontierPortNode,
    sourcePort := frontierPortNode,
    graphAdjacent := eqAdj,
    interiorPort := addressNode selectedChild,
    interiorLoadNode := addressNode selectedChild,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualAddressTargetRecord : CutGraphTargetProvenanceRecord :=
  { boundaryRoleNodes := addressNodes boundaryAddresses,
    interiorRoleNodes := addressNodes interiorAddresses,
    uvBoundaryRoleNodes := addressNodes uvBoundaryAddresses,
    envBoundaryRoleNodes := addressNodes envBoundaryAddresses,
    recordRoleNodes := addressNodes recordAddresses,
    universeNodes := residualUniverseNodes,
    boundaryPort := frontierPortNode,
    sourcePort := frontierPortNode,
    graphAdjacent := eqAdj,
    interiorPort := addressNode selectedChild,
    interiorLoadNode := addressNode selectedChild,
    frontierAdjacent := eqAdj,
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_address_target_record_eq_previous :
    zeroAddressTargetRecord =
      SchurDtnFrontierTargetProvenance.zeroTargetProvenanceNode2 := rfl


theorem residual_address_target_record_eq_previous :
    residualAddressTargetRecord =
      SchurDtnFrontierTargetProvenance.residualTargetProvenanceNode2 := rfl


theorem zero_address_candidate_edge_targets :
    SchurDtnFrontierTargetProvenance.candidateEdgeTargets
      zeroAddressTargetRecord = [] := rfl


theorem residual_address_candidate_edge_targets :
    SchurDtnFrontierTargetProvenance.candidateEdgeTargets
      residualAddressTargetRecord = [2] := rfl


theorem residual_address_edge_table :
    SchurDtnFrontierEdgeDerivationProvenance.edgeTable
      (SchurDtnFrontierTargetProvenance.toEdgeDerivationRecord
        residualAddressTargetRecord) =
        [SchurDtnFrontierTargetProvenance.edge22] := rfl


theorem residual_address_edge_present :
    SchurDtnFrontierEdgeTableProvenance.edgePresent
      (SchurDtnFrontierEdgeDerivationProvenance.toEdgeTableRecord
        (SchurDtnFrontierTargetProvenance.toEdgeDerivationRecord
          residualAddressTargetRecord)) = true := rfl


theorem residual_address_frontier_candidates :
    SchurDtnGraphFrontierExtensionProvenance.frontierCandidateNodes
      SchurDtnFrontierTargetProvenance.residualTargetCutFrontierExtensionNode2 =
        [2] :=
  SchurDtnFrontierTargetProvenance.residual_target_frontier_candidates_node2


theorem residual_address_cut_graph_universe_nodes :
    SchurDtnCutGraphUniverseProvenance.universeNodes
      SchurDtnFrontierTargetProvenance.residualTargetCutGraphUniverseNode2 =
        [0, 1, 2] :=
  SchurDtnFrontierTargetProvenance.residual_target_universe_nodes_node2


theorem residual_address_support_nodes :
    SchurDtnBoundaryResidualSupportProvenance.residualSupportNodes
      SchurDtnFrontierTargetProvenance.residualTargetBoundarySupportNode2 =
        [2] :=
  SchurDtnFrontierTargetProvenance.residual_target_support_nodes_node2


def derivedAddressSeedDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierTargetProvenance.cutFrontierTargetProvenanceDefectSystem


theorem derived_address_seed_closure_status :
    derivedAddressSeedDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      derivedAddressSeedDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        derivedAddressSeedDefectSystem) :=
  SchurDtnFrontierTargetProvenance.cut_frontier_target_provenance_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnFrontierTargetProvenance.symmetricDefectSystem


theorem symmetric_derived_address_seed_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnFrontierTargetProvenance.symmetric_frontier_target_provenance_status


def addressSeedStillMinimalLocalModel : Prop := True


theorem address_seed_still_minimal_local_model :
    addressSeedStillMinimalLocalModel :=
  True.intro

end SchurDtnDerivedAddressSeed
