import CNNA.UniqueLockSectorClosure

/-
  SymmetrySectorNoGo.lean
  -----------------------
  Formalisiert den alten Symmetrie-No-Go im neuen Sector-Resolution-Spine.

  Wenn eine sign-flipping Symmetrie die Lock-Kandidatenliste invariant haelt
  und ein Plus-Lock-Sektor vorkommt, dann kommt auch der Minus-Lock-Sektor vor.
  Damit greift OppositeSectorNoGo und das J-Sign ist nicht geschlossen.

  Das ist der formale Anschluss:

    aktive Symmetrie -> Opposite-Pair -> kein J-Sign-Closure.

  Kein Tie-Break, keine freie Orientierung, kein versteckter Zufall.
-/

namespace SymmetrySectorNoGo

abbrev LockCandidate := JLockingGate.LockCandidate
abbrev Sign := JLockingGate.Sign

/-- Flip aller drei Lock-Vorzeichen. -/
def flipLock (c : LockCandidate) : LockCandidate :=
  { j := JLockingGate.flip c.j,
    f2 := JLockingGate.flip c.f2,
    tau := JLockingGate.flip c.tau }

/-- Der Plus-Lock wird unter dem Sign-Flip zum Minus-Lock. -/
theorem flip_plusLock : flipLock JLockingGate.plusLock = JLockingGate.minusLock := by
  rfl

/-- Der Minus-Lock wird unter dem Sign-Flip zum Plus-Lock. -/
theorem flip_minusLock : flipLock JLockingGate.minusLock = JLockingGate.plusLock := by
  rfl

/-- Der Sign-Flip ist involutiv. -/
theorem flipLock_involutive (c : LockCandidate) : flipLock (flipLock c) = c := by
  cases c with
  | mk j f2 tau =>
      cases j <;> cases f2 <;> cases tau <;> rfl

/-- Eine Kandidatenliste ist unter Sign-Flip abgeschlossen. -/
def sectorClosedUnderFlip (cs : List LockCandidate) : Prop :=
  ∀ c, c ∈ cs -> flipLock c ∈ cs

/-- Wenn Plus vorkommt und der Sektor unter Sign-Flip abgeschlossen ist,
    dann kommt auch Minus vor. -/
theorem minus_mem_of_plus_mem_and_flip_closed (cs : List LockCandidate)
    (hplus : JLockingGate.plusLock ∈ cs) (hclosed : sectorClosedUnderFlip cs) :
    JLockingGate.minusLock ∈ cs := by
  have hflip : flipLock JLockingGate.plusLock ∈ cs :=
    hclosed JLockingGate.plusLock hplus
  rw [flip_plusLock] at hflip
  exact hflip

/-- Sign-flipping Symmetrie plus vorhandener Plus-Sektor erzeugt ein Opposite-Pair. -/
theorem contains_opposite_of_flip_closed_and_plus (cs : List LockCandidate)
    (hplus : JLockingGate.plusLock ∈ cs) (hclosed : sectorClosedUnderFlip cs) :
    OppositeSectorNoGo.containsOppositePair cs := by
  unfold OppositeSectorNoGo.containsOppositePair
  exact And.intro hplus (minus_mem_of_plus_mem_and_flip_closed cs hplus hclosed)

/-- Haupt-No-Go: Eine aktive sign-flipping Symmetrie, die den Sektor erhaelt,
    blockiert J-Sign-Closure. -/
theorem no_closed_of_flip_closed_and_plus (cs : List LockCandidate)
    (hplus : JLockingGate.plusLock ∈ cs) (hclosed : sectorClosedUnderFlip cs) :
    ¬ JSignClosureCriterion.hasClosedJSign cs :=
  OppositeSectorNoGo.no_closed_of_contains_opposite cs
    (contains_opposite_of_flip_closed_and_plus cs hplus hclosed)

/-- DefectSystem-Variante: Wenn der Lock-Pushforward einen Plus-Sektor enthaelt
    und unter Sign-Flip abgeschlossen ist, ist das J-Sign nicht resolved. -/
theorem not_resolved_of_flip_closed_lockCandidates {A : Type}
    (D : SectorResolutionGate.DefectSystem A)
    (lockOf : A -> LockCandidate)
    (hplus : JLockingGate.plusLock ∈ SectorResolutionGate.lockCandidates D lockOf)
    (hclosed : sectorClosedUnderFlip (SectorResolutionGate.lockCandidates D lockOf)) :
    ¬ SectorResolutionGate.hasResolvedJSign D lockOf := by
  unfold SectorResolutionGate.hasResolvedJSign
  exact no_closed_of_flip_closed_and_plus
    (SectorResolutionGate.lockCandidates D lockOf) hplus hclosed

/-- GrowthSectorMap-Variante des gleichen Symmetrie-No-Go. -/
theorem growth_not_resolved_of_flip_closed_lockCandidates {A : Type}
    (M : GrowthSectorResolutionBridge.GrowthSectorMap A)
    (D : SectorResolutionGate.DefectSystem A)
    (hplus : JLockingGate.plusLock ∈ M.lockCandidates D)
    (hclosed : sectorClosedUnderFlip (M.lockCandidates D)) :
    ¬ M.hasResolvedJSign D := by
  change ¬ SectorResolutionGate.hasResolvedJSign D M.lockOf
  exact not_resolved_of_flip_closed_lockCandidates D M.lockOf hplus hclosed

/-! ## Aktueller symmetrischer Growth-Sektor -/

/-- Der bisherige symmetrische Growth-Pushforward ist unter Sign-Flip abgeschlossen. -/
theorem symmetric_growth_closed_under_flip :
    sectorClosedUnderFlip
      (GrowthSectorResolutionBridge.symmetricSectorMap.lockCandidates
        OneInteriorGrowthKernelExample.symmetricTwoDefectSystem) := by
  intro c hc
  rw [GrowthSectorResolutionBridge.symmetric_growth_locks_eq_twoSectors] at hc
  rw [GrowthSectorResolutionBridge.symmetric_growth_locks_eq_twoSectors]
  unfold JSignClosureCriterion.twoSectors at hc ⊢
  cases List.mem_cons.mp hc with
  | inl hp =>
      rw [hp, flip_plusLock]
      exact List.mem_cons_of_mem _ List.mem_cons_self
  | inr hrest =>
      cases List.mem_cons.mp hrest with
      | inl hm =>
          rw [hm, flip_minusLock]
          exact List.mem_cons_self
      | inr hnil =>
          cases hnil

/-- Im symmetrischen Growth-Pushforward kommt Plus vor. -/
theorem symmetric_growth_plus_mem :
    JLockingGate.plusLock ∈
      GrowthSectorResolutionBridge.symmetricSectorMap.lockCandidates
        OneInteriorGrowthKernelExample.symmetricTwoDefectSystem := by
  rw [GrowthSectorResolutionBridge.symmetric_growth_locks_eq_twoSectors]
  unfold JSignClosureCriterion.twoSectors
  exact List.mem_cons_self

/-- Der symmetrische Growth-Sektor ist nicht resolved, weil die sign-flipping
    Symmetrie den Sektor erhaelt. -/
theorem symmetric_growth_not_resolved_by_flip_symmetry :
    ¬ GrowthSectorResolutionBridge.symmetricSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem :=
  growth_not_resolved_of_flip_closed_lockCandidates
    GrowthSectorResolutionBridge.symmetricSectorMap
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem
    symmetric_growth_plus_mem
    symmetric_growth_closed_under_flip

/-- Statusmarker: aktive sign-flipping Symmetrie ist im neuen Spine ein harter
    Grund fuer Nicht-Closure des J-Signs. -/
def activeSignFlipSymmetryBlocksClosure : Prop := True

theorem active_sign_flip_symmetry_blocks_closure :
    activeSignFlipSymmetryBlocksClosure :=
  True.intro

end SymmetrySectorNoGo
