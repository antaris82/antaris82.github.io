import CNNA.GrowthSectorResolutionBridge

/-
  GeneratorEndToEndTheorem.lean
  -----------------------------
  End-to-end result layer for the current CNNA generator mini-spine.

  The file does not add a new selector, weight, random source, or J-sign
  convention. It only bundles the already green chain into two explicit
  endpoint statements:

    concrete mini cut -> unique growth sector -> resolved J-sign criterion
    symmetric two-sector mini cut -> opposite signs -> not resolved J-sign

  The second statement is essential: symmetric sector degeneracy is not closed
  by fiat. It remains an unresolved plus/minus sector pair.
-/

namespace GeneratorEndToEndTheorem

/-- Positive endpoint of the current toy-spine: the concrete one-interior
    mini cut has kernel mass 1, carries the positive circulation witness, and
    resolves the formal J-sign closure criterion through the structured
    Growth-sector adapter. -/
theorem concrete_mini_cut_resolves_j_sign :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    GrowthToCirculationBridge.oneInteriorCirculation
      OneInteriorGrowthKernelExample.onlyAttachment = 1 ∧
    GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.oneInteriorDefectSystem :=
  GrowthSectorResolutionBridge.oneInterior_growth_kernel_circulation_and_resolved

/-- Negative endpoint of the symmetric toy-spine: the two-sector case has
    kernel mass 2, carries opposite circulation signs, and does not resolve the
    formal J-sign closure criterion. -/
theorem symmetric_two_sector_does_not_resolve_j_sign :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges false) = 1 ∧
    Circulation.csum Circulation.cmpH
      (GrowthToCirculationBridge.symmetricSectorEdges true) = -1 ∧
    ¬ GrowthSectorResolutionBridge.symmetricSectorMap.hasResolvedJSign
      OneInteriorGrowthKernelExample.symmetricTwoDefectSystem :=
  GrowthSectorResolutionBridge.symmetric_growth_kernel_circulations_and_not_resolved

/-- The current mini-spine has an explicit resolved endpoint. -/
def hasConcreteResolvedEndpoint : Prop :=
  OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
  GrowthSectorResolutionBridge.oneInteriorSectorMap.hasResolvedJSign
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem

/-- The concrete endpoint follows from the end-to-end theorem. -/
theorem concrete_endpoint_resolved : hasConcreteResolvedEndpoint := by
  unfold hasConcreteResolvedEndpoint
  exact And.intro
    concrete_mini_cut_resolves_j_sign.left
    concrete_mini_cut_resolves_j_sign.right.right

/-- The current mini-spine also has an explicit unresolved symmetric endpoint. -/
def hasSymmetricUnresolvedEndpoint : Prop :=
  OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
  ¬ GrowthSectorResolutionBridge.symmetricSectorMap.hasResolvedJSign
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem

/-- The symmetric unresolved endpoint follows from the end-to-end theorem. -/
theorem symmetric_endpoint_unresolved : hasSymmetricUnresolvedEndpoint := by
  unfold hasSymmetricUnresolvedEndpoint
  exact And.intro
    symmetric_two_sector_does_not_resolve_j_sign.left
    symmetric_two_sector_does_not_resolve_j_sign.right.right.right

/-- Compact combined status: the same formal spine contains both the resolved
    unique-sector endpoint and the unresolved symmetric-sector endpoint. -/
theorem end_to_end_status :
    hasConcreteResolvedEndpoint ∧ hasSymmetricUnresolvedEndpoint :=
  And.intro concrete_endpoint_resolved symmetric_endpoint_unresolved

end GeneratorEndToEndTheorem
