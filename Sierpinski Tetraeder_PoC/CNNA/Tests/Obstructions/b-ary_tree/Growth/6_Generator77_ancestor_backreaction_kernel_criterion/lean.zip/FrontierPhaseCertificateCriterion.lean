import CNNA.FrontierRankProfileCriterion

namespace FrontierPhaseCertificateCriterion

abbrev Node := FrontierRankProfileCriterion.Node
abbrev CurrentAddress := FrontierRankProfileCriterion.CurrentAddress
abbrev FillPhase := FrontierRankProfileCriterion.FillPhase
abbrev FrontierRankProfile := FrontierRankProfileCriterion.FrontierRankProfile
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion
abbrev AbstractAddressSeed :=
  AbstractAddressTypeGrowthCriterion.AbstractAddressSeed

structure FrontierPhaseCertificate (A : Type) [BEq A] where
  profile : FrontierRankProfile A
  cutRootAddress : A
  selectedAddress : A
  frontierAddress : A
  cutRootSourcePhase :
    FrontierRankProfileCriterion.sourcePhase
      profile cutRootAddress = true
  selectedSourcePhase :
    FrontierRankProfileCriterion.sourcePhase
      profile selectedAddress = false
  selectedActiveFrontierPhase :
    FrontierRankProfileCriterion.activeFrontierPhase
      profile selectedAddress = false
  frontierSourcePhase :
    FrontierRankProfileCriterion.sourcePhase
      profile frontierAddress = false
  frontierActiveFrontierPhase :
    FrontierRankProfileCriterion.activeFrontierPhase
      profile frontierAddress = true


def certifiedPhase {A : Type} [BEq A]
    (c : FrontierPhaseCertificate A) (a : A) : FillPhase :=
  FrontierRankProfileCriterion.phaseFromFrontierProfile c.profile a


def certifiedRank {A : Type} [BEq A]
    (c : FrontierPhaseCertificate A) (a : A) : Nat :=
  FrontierRankProfileCriterion.rankFromFrontierProfile c.profile a


def certifiedEndpoint {A : Type} [BEq A]
    (c : FrontierPhaseCertificate A) (a : A) :
    CanonicalFillOrderCriterion.FillEndpoint :=
  FrontierRankProfileCriterion.endpointFromFrontierProfile c.profile a


def certifiedNodeOf {A : Type} [BEq A]
    (c : FrontierPhaseCertificate A) (a : A) : Node :=
  FrontierRankProfileCriterion.nodeOfFromFrontierProfile c.profile a


theorem certificate_cut_root_phase_source
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedPhase c c.cutRootAddress = FrontierRankProfileCriterion.FillPhase.source := by
  unfold certifiedPhase
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.cutRootSourcePhase]
  rfl


theorem certificate_selected_phase_transit
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedPhase c c.selectedAddress = FrontierRankProfileCriterion.FillPhase.transit := by
  unfold certifiedPhase
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.selectedSourcePhase]
  rw [c.selectedActiveFrontierPhase]
  rfl


theorem certificate_frontier_phase_active
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedPhase c c.frontierAddress = FrontierRankProfileCriterion.FillPhase.activeFrontier := by
  unfold certifiedPhase
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.frontierSourcePhase]
  rw [c.frontierActiveFrontierPhase]
  rfl


theorem certificate_cut_root_rank_before
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedRank c c.cutRootAddress = c.profile.beforeRank := by
  unfold certifiedRank
  unfold FrontierRankProfileCriterion.rankFromFrontierProfile
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.cutRootSourcePhase]
  rfl


theorem certificate_selected_rank_after
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedRank c c.selectedAddress = c.profile.afterRank := by
  unfold certifiedRank
  unfold FrontierRankProfileCriterion.rankFromFrontierProfile
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.selectedSourcePhase]
  rw [c.selectedActiveFrontierPhase]
  rfl


theorem certificate_frontier_rank_after_succ
    {A : Type} [BEq A] (c : FrontierPhaseCertificate A) :
    certifiedRank c c.frontierAddress = c.profile.afterRank + 1 := by
  unfold certifiedRank
  unfold FrontierRankProfileCriterion.rankFromFrontierProfile
  unfold FrontierRankProfileCriterion.phaseFromFrontierProfile
  rw [c.frontierSourcePhase]
  rw [c.frontierActiveFrontierPhase]
  rfl


def currentFrontierPhaseCertificate :
    FrontierPhaseCertificate CurrentAddress :=
  { profile := FrontierRankProfileCriterion.currentFrontierRankProfile,
    cutRootAddress := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    cutRootSourcePhase :=
      FrontierRankProfileCriterion.current_source_phase_cut_root,
    selectedSourcePhase :=
      FrontierRankProfileCriterion.current_source_phase_selected_false,
    selectedActiveFrontierPhase :=
      FrontierRankProfileCriterion.current_active_frontier_phase_selected_false,
    frontierSourcePhase :=
      FrontierRankProfileCriterion.current_source_phase_frontier_false,
    frontierActiveFrontierPhase :=
      FrontierRankProfileCriterion.current_active_frontier_phase_frontier_true }


theorem current_certificate_phase_cut_root_source :
    certifiedPhase currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.cutRoot = FrontierRankProfileCriterion.FillPhase.source :=
  certificate_cut_root_phase_source currentFrontierPhaseCertificate


theorem current_certificate_phase_selected_transit :
    certifiedPhase currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.selectedChild = FrontierRankProfileCriterion.FillPhase.transit :=
  certificate_selected_phase_transit currentFrontierPhaseCertificate


theorem current_certificate_phase_frontier_active :
    certifiedPhase currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      FrontierRankProfileCriterion.FillPhase.activeFrontier :=
  certificate_frontier_phase_active currentFrontierPhaseCertificate


theorem current_certificate_rank_cut_root_zero :
    certifiedRank currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.cutRoot = 0 :=
  certificate_cut_root_rank_before currentFrontierPhaseCertificate


theorem current_certificate_rank_selected_one :
    certifiedRank currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.selectedChild = 1 :=
  certificate_selected_rank_after currentFrontierPhaseCertificate


theorem current_certificate_rank_frontier_two :
    certifiedRank currentFrontierPhaseCertificate
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  certificate_frontier_rank_after_succ currentFrontierPhaseCertificate


def currentCertifiedNodeOf : CurrentAddress -> Node :=
  certifiedNodeOf currentFrontierPhaseCertificate


theorem current_certified_nodeOf_eq_frontier_profile_nodeOf :
    currentCertifiedNodeOf =
      FrontierRankProfileCriterion.currentFrontierProfileNodeOf := rfl


theorem current_certified_nodeOf_eq_fill_order_nodeOf :
    currentCertifiedNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_certified_nodeOf_eq_frontier_profile_nodeOf]
  exact FrontierRankProfileCriterion.current_frontier_profile_nodeOf_eq_fill_order_nodeOf


theorem current_certificate_cut_root_node_zero :
    currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 :=
  FrontierRankProfileCriterion.current_frontier_profile_cut_root_node_zero


theorem current_certificate_selected_node_one :
    currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 :=
  FrontierRankProfileCriterion.current_frontier_profile_selected_node_one


theorem current_certificate_frontier_node_two :
    currentCertifiedNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  FrontierRankProfileCriterion.current_frontier_profile_frontier_node_two


def currentCertificateAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentCertifiedNodeOf }


theorem current_certificate_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentCertificateAbstractSeed.visibleRoles
      currentCertificateAbstractSeed.frontierAddress = true := rfl


def currentCertificateSeedCriterion :
    CurrentSeedCriterion currentCertificateAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible :=
      current_certificate_frontier_outside_visible,
    source_node_zero := current_certificate_cut_root_node_zero,
    frontier_node_two := current_certificate_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem certificate_profile_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCertificateAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentCertificateSeedCriterion


theorem certificate_profile_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCertificateAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentCertificateSeedCriterion


theorem certificate_profile_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentCertificateAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentCertificateSeedCriterion


def frontierPhaseCertificateReversalRejectsFrontierZero : Prop :=
  CanonicalRoleOrderCriterion.roleNumberFromOrder
    CanonicalFillOrderCriterion.reversedInterfaceRoleOrder
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 ∧
  currentCertifiedNodeOf
    SchurDtnDerivedAddressSeed.frontierPortAddress = 2


theorem frontier_phase_certificate_reversal_rejects_frontier_zero :
    frontierPhaseCertificateReversalRejectsFrontierZero :=
  And.intro
    CanonicalFillOrderCriterion.reversed_order_frontier_zero
    current_certificate_frontier_node_two


theorem frontier_phase_certificate_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def frontierPhaseCertificateStillLocalWitnessRecord : Prop := True


theorem frontier_phase_certificate_still_local_witness_record :
    frontierPhaseCertificateStillLocalWitnessRecord :=
  True.intro

end FrontierPhaseCertificateCriterion
