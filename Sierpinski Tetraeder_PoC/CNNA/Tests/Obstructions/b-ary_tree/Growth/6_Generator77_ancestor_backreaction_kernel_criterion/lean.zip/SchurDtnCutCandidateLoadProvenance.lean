import CNNA.SchurDtnGraphPortLoadProvenance

namespace SchurDtnCutCandidateLoadProvenance

abbrev Node := Fin 3
abbrev GraphPortLoadCutData :=
  SchurDtnGraphPortLoadProvenance.GraphPortLoadCutData
abbrev LoadTraceData :=
  SchurDtnGraphPortLoadProvenance.SchurDtnGraphPortLoadTraceData
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure CutCandidateLoadSupportData where
  boundaryPort : Node
  interiorPort : Node
  interiorLoadNode : Node
  residualSupportNodes : List Node
  loadAdjacent : Node -> Node -> Bool
  adjacent : Node -> Node -> Bool


def candidateLoadNodes (p : CutCandidateLoadSupportData) : List Node :=
  p.interiorLoadNode :: p.residualSupportNodes


def toGraphPortLoadCutData (p : CutCandidateLoadSupportData) :
    GraphPortLoadCutData :=
  { boundaryPort := p.boundaryPort,
    interiorPort := p.interiorPort,
    candidateLoadNodes := candidateLoadNodes p,
    loadAdjacent := p.loadAdjacent,
    adjacent := p.adjacent }


theorem toGraphPortLoadCutData_candidateLoadNodes
    (p : CutCandidateLoadSupportData) :
    (toGraphPortLoadCutData p).candidateLoadNodes =
      candidateLoadNodes p := rfl


def eqAdj : Node -> Node -> Bool :=
  SchurDtnGraphPortLoadProvenance.eqAdj


def edge01 : Node -> Node -> Bool :=
  SchurDtnGraphPortLoadProvenance.edge01


def zeroCandidateLoadSupportAt (x : Node) : CutCandidateLoadSupportData :=
  { boundaryPort := x,
    interiorPort := 1,
    interiorLoadNode := 1,
    residualSupportNodes := [],
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


def residualCandidateLoadSupportNode2 : CutCandidateLoadSupportData :=
  { boundaryPort := 2,
    interiorPort := 1,
    interiorLoadNode := 1,
    residualSupportNodes := [2],
    loadAdjacent := eqAdj,
    adjacent := eqAdj }


theorem zero_candidate_load_nodes_node2 :
    candidateLoadNodes (zeroCandidateLoadSupportAt 2) = [1] := rfl


theorem residual_candidate_load_nodes_node2 :
    candidateLoadNodes residualCandidateLoadSupportNode2 = [1, 2] := rfl


def zeroLoadCutBlockAt (x : Node) : GraphPortLoadCutData :=
  toGraphPortLoadCutData (zeroCandidateLoadSupportAt x)


def residualLoadCutBlockNode2 : GraphPortLoadCutData :=
  toGraphPortLoadCutData residualCandidateLoadSupportNode2


theorem zero_load_cut_block_candidate_nodes_node2 :
    (zeroLoadCutBlockAt 2).candidateLoadNodes = [1] := rfl


theorem residual_load_cut_block_candidate_nodes_node2 :
    residualLoadCutBlockNode2.candidateLoadNodes = [1, 2] := rfl


theorem residual_load_cut_block_boundary_load_nodes_node2 :
    SchurDtnGraphPortLoadProvenance.boundaryLoadNodes
      residualLoadCutBlockNode2 = [2] := rfl


theorem residual_load_cut_block_interior_load_nodes_node2 :
    SchurDtnGraphPortLoadProvenance.interiorLoadNodes
      residualLoadCutBlockNode2 = [1] := rfl


def beforeLoadTraceData : LoadTraceData :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeLoadCutBlock := zeroLoadCutBlockAt,
    afterLoadCutBlock := zeroLoadCutBlockAt,
    adjacent := edge01 }


def plusAfterLoadTraceData : LoadTraceData :=
  beforeLoadTraceData


def minusAfterLoadTraceData : LoadTraceData :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforeLoadCutBlock := zeroLoadCutBlockAt,
    afterLoadCutBlock := fun _ => residualLoadCutBlockNode2,
    adjacent := edge01 }


theorem minus_after_candidate_load_nodes_node2 :
    (minusAfterLoadTraceData.afterLoadCutBlock 2).candidateLoadNodes =
      [1, 2] := rfl


theorem minus_after_boundary_load_nodes_node2 :
    SchurDtnGraphPortLoadProvenance.boundaryLoadNodes
      (minusAfterLoadTraceData.afterLoadCutBlock 2) = [2] := rfl


def candidateLoadDefectSystem : DefectSystem Bool :=
  SchurDtnGraphPortLoadProvenance.cutPortLoadDefectSystem


theorem candidate_load_closure_status :
    candidateLoadDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      candidateLoadDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        candidateLoadDefectSystem) :=
  SchurDtnGraphPortLoadProvenance.cut_port_load_closure_status


def symmetricDefectSystem : DefectSystem Bool :=
  SchurDtnGraphPortLoadProvenance.symmetricDefectSystem


theorem symmetric_candidate_load_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  SchurDtnGraphPortLoadProvenance.symmetric_cut_port_load_status


def residualSupportNodesStillNeedCutDerivation : Prop := True


theorem residual_support_nodes_still_need_cut_derivation :
    residualSupportNodesStillNeedCutDerivation :=
  True.intro

end SchurDtnCutCandidateLoadProvenance
