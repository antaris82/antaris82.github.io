import CNNA.FillEndpointDerivationCriterion

namespace FillDynamicsRankCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev InterfaceRole := CanonicalRoleOrderCriterion.InterfaceRole
abbrev FillEndpoint := CanonicalFillOrderCriterion.FillEndpoint
abbrev CutFillEndpointData :=
  FillEndpointDerivationCriterion.CutFillEndpointData
abbrev InterfaceRoleAssignment :=
  CanonicalRoleOrderCriterion.InterfaceRoleAssignment
abbrev AbstractAddressSeed :=
  AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion


def endpointOfNatRank : Nat -> FillEndpoint
  | 0 => CanonicalFillOrderCriterion.FillEndpoint.repeller
  | 2 => CanonicalFillOrderCriterion.FillEndpoint.attractor
  | _ => CanonicalFillOrderCriterion.FillEndpoint.transit


def dynamicRankFromCutFillData {A : Type} [BEq A]
    (d : CutFillEndpointData A) (a : A) : Nat :=
  if a == d.sourceAddress then
    d.beforeRank
  else if (a == d.targetAddress) &&
      decide (d.beforeRank < d.afterRank) &&
      AbstractAddressTypeGrowthCriterion.outsideVisible d.visibleRoles a then
    d.afterRank + 1
  else
    d.afterRank


def dynamicEndpointFromCutFillData {A : Type} [BEq A]
    (d : CutFillEndpointData A) (a : A) : FillEndpoint :=
  endpointOfNatRank (dynamicRankFromCutFillData d a)


def dynamicEndpointOfRole {A : Type} [BEq A]
    (d : CutFillEndpointData A) (r : InterfaceRoleAssignment A)
    (role : InterfaceRole) : FillEndpoint :=
  dynamicEndpointFromCutFillData d
    (FillEndpointDerivationCriterion.addressOfInterfaceRole r role)


def dynamicFillRankNodeOf {A : Type} [BEq A]
    (d : CutFillEndpointData A) (a : A) : Node :=
  CanonicalFillOrderCriterion.fillEndpointRank
    (dynamicEndpointFromCutFillData d a)


def currentDynamicEndpointOfRole : InterfaceRole -> FillEndpoint :=
  dynamicEndpointOfRole
    FillEndpointDerivationCriterion.currentCutFillEndpointData
    CanonicalRoleOrderCriterion.currentInterfaceRoleAssignment


theorem endpoint_of_nat_rank_zero_repeller :
    endpointOfNatRank 0 =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem endpoint_of_nat_rank_one_transit :
    endpointOfNatRank 1 =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem endpoint_of_nat_rank_two_attractor :
    endpointOfNatRank 2 =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := rfl


theorem current_dynamic_rank_cut_root_zero :
    dynamicRankFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_dynamic_rank_selected_one :
    dynamicRankFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_dynamic_rank_frontier_two :
    dynamicRankFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change dynamicRankFromCutFillData
    FillEndpointDerivationCriterion.currentCutFillEndpointData
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


theorem current_dynamic_endpoint_cut_root_repeller :
    dynamicEndpointFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.cutRoot =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_dynamic_endpoint_selected_transit :
    dynamicEndpointFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.selectedChild =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_dynamic_endpoint_frontier_address_attractor :
    dynamicEndpointFromCutFillData
      FillEndpointDerivationCriterion.currentCutFillEndpointData
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := by
  change dynamicEndpointFromCutFillData
    FillEndpointDerivationCriterion.currentCutFillEndpointData
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      CanonicalFillOrderCriterion.FillEndpoint.attractor
  rfl


theorem current_dynamic_endpoint_boundary_repeller :
    currentDynamicEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.boundaryAnchor =
      CanonicalFillOrderCriterion.FillEndpoint.repeller := rfl


theorem current_dynamic_endpoint_bright_transit :
    currentDynamicEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.brightSelected =
      CanonicalFillOrderCriterion.FillEndpoint.transit := rfl


theorem current_dynamic_endpoint_frontier_attractor :
    currentDynamicEndpointOfRole
      CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual =
      CanonicalFillOrderCriterion.FillEndpoint.attractor := rfl


theorem current_dynamic_endpoint_eq_cut_fill_endpoint :
    currentDynamicEndpointOfRole =
      FillEndpointDerivationCriterion.currentDerivedEndpointOfRole := by
  funext r
  cases r <;> rfl


theorem current_dynamic_endpoint_eq_fill_endpoint :
    currentDynamicEndpointOfRole =
      CanonicalFillOrderCriterion.fillEndpointOfRole := by
  rw [current_dynamic_endpoint_eq_cut_fill_endpoint]
  exact FillEndpointDerivationCriterion.current_derived_endpoint_eq_fill_endpoint


def currentDynamicFillRankNodeOf : CurrentAddress -> Node :=
  dynamicFillRankNodeOf
    FillEndpointDerivationCriterion.currentCutFillEndpointData


theorem current_dynamic_fill_nodeOf_eq_derived_nodeOf :
    currentDynamicFillRankNodeOf =
      FillEndpointDerivationCriterion.currentDerivedFillRankNodeOf := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


theorem current_dynamic_fill_nodeOf_eq_fill_order_nodeOf :
    currentDynamicFillRankNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_dynamic_fill_nodeOf_eq_derived_nodeOf]
  exact FillEndpointDerivationCriterion.current_derived_fill_nodeOf_eq_fill_order_nodeOf


theorem current_dynamic_fill_cut_root_node_zero :
    currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_dynamic_fill_selected_node_one :
    currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_dynamic_fill_frontier_node_two :
    currentDynamicFillRankNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentDynamicFillRankNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


def currentDynamicFillAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentDynamicFillRankNodeOf }


theorem current_dynamic_fill_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentDynamicFillAbstractSeed.visibleRoles
      currentDynamicFillAbstractSeed.frontierAddress = true := rfl


def currentDynamicFillSeedCriterion :
    CurrentSeedCriterion currentDynamicFillAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible :=
      current_dynamic_fill_frontier_outside_visible,
    source_node_zero := current_dynamic_fill_cut_root_node_zero,
    frontier_node_two := current_dynamic_fill_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_dynamic_fill_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentDynamicFillAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem dynamic_fill_rank_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDynamicFillAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentDynamicFillSeedCriterion


theorem dynamic_fill_rank_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDynamicFillAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentDynamicFillSeedCriterion


theorem dynamic_fill_rank_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentDynamicFillAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentDynamicFillSeedCriterion


theorem dynamic_fill_rank_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def dynamicFillRankReversalRejectsFrontierZero : Prop :=
  CanonicalRoleOrderCriterion.roleNumberFromOrder
    CanonicalFillOrderCriterion.reversedInterfaceRoleOrder
    CanonicalRoleOrderCriterion.InterfaceRole.frontierResidual = 0 ∧
  currentDynamicFillRankNodeOf
    SchurDtnDerivedAddressSeed.frontierPortAddress = 2


theorem dynamic_fill_rank_reversal_rejects_frontier_zero :
    dynamicFillRankReversalRejectsFrontierZero :=
  And.intro
    CanonicalFillOrderCriterion.reversed_order_frontier_zero
    current_dynamic_fill_frontier_node_two


def dynamicRankStillLocalThreePhaseProfile : Prop := True


theorem dynamic_rank_still_local_three_phase_profile :
    dynamicRankStillLocalThreePhaseProfile :=
  True.intro

end FillDynamicsRankCriterion
