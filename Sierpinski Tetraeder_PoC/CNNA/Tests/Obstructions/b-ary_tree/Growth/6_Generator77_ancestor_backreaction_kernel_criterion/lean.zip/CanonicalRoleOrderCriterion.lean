import CNNA.CanonicalPortNumberingCriterion

namespace CanonicalRoleOrderCriterion

abbrev Node := Fin 3
abbrev CurrentAddress := SchurDtnDerivedAddressSeed.Address
abbrev AbstractAddressSeed := AbstractAddressTypeGrowthCriterion.AbstractAddressSeed
abbrev CurrentSeedCriterion := AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion
abbrev LocalPortRoles := CanonicalPortNumberingCriterion.LocalPortRoles

inductive InterfaceRole where
  | boundaryAnchor
  | brightSelected
  | frontierResidual
  deriving BEq, DecidableEq


def canonicalRoleNumber : InterfaceRole -> Node
  | InterfaceRole.boundaryAnchor => 0
  | InterfaceRole.brightSelected => 1
  | InterfaceRole.frontierResidual => 2


theorem boundary_anchor_role_zero :
    canonicalRoleNumber InterfaceRole.boundaryAnchor = 0 := rfl


theorem bright_selected_role_one :
    canonicalRoleNumber InterfaceRole.brightSelected = 1 := rfl


theorem frontier_residual_role_two :
    canonicalRoleNumber InterfaceRole.frontierResidual = 2 := rfl


structure InterfaceRoleOrder where
  first : InterfaceRole
  second : InterfaceRole
  third : InterfaceRole


def canonicalInterfaceRoleOrder : InterfaceRoleOrder :=
  { first := InterfaceRole.boundaryAnchor,
    second := InterfaceRole.brightSelected,
    third := InterfaceRole.frontierResidual }


def roleNumberFromOrder (o : InterfaceRoleOrder) (r : InterfaceRole) : Node :=
  if r == o.first then 0
  else if r == o.second then 1
  else if r == o.third then 2
  else 0


theorem canonical_order_boundary_zero :
    roleNumberFromOrder canonicalInterfaceRoleOrder
      InterfaceRole.boundaryAnchor = 0 := rfl


theorem canonical_order_bright_one :
    roleNumberFromOrder canonicalInterfaceRoleOrder
      InterfaceRole.brightSelected = 1 := rfl


theorem canonical_order_frontier_two :
    roleNumberFromOrder canonicalInterfaceRoleOrder
      InterfaceRole.frontierResidual = 2 := rfl


structure InterfaceRoleAssignment (A : Type) where
  boundaryAnchorAddress : A
  brightSelectedAddress : A
  frontierResidualAddress : A


def roleOfAddress {A : Type} [BEq A]
    (r : InterfaceRoleAssignment A) (a : A) : InterfaceRole :=
  if a == r.boundaryAnchorAddress then InterfaceRole.boundaryAnchor
  else if a == r.brightSelectedAddress then InterfaceRole.brightSelected
  else if a == r.frontierResidualAddress then InterfaceRole.frontierResidual
  else InterfaceRole.boundaryAnchor


def nodeOfFromInterfaceRoles {A : Type} [BEq A]
    (o : InterfaceRoleOrder) (r : InterfaceRoleAssignment A) (a : A) : Node :=
  roleNumberFromOrder o (roleOfAddress r a)


def toLocalPortRoles {A : Type}
    (r : InterfaceRoleAssignment A) : LocalPortRoles A :=
  { cutRoot := r.boundaryAnchorAddress,
    selectedVisible := r.brightSelectedAddress,
    frontierResidual := r.frontierResidualAddress }


def currentInterfaceRoleAssignment : InterfaceRoleAssignment CurrentAddress :=
  { boundaryAnchorAddress := SchurDtnDerivedAddressSeed.cutRoot,
    brightSelectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierResidualAddress := SchurDtnDerivedAddressSeed.frontierPortAddress }


def currentRoleOrderNodeOf : CurrentAddress -> Node :=
  nodeOfFromInterfaceRoles canonicalInterfaceRoleOrder
    currentInterfaceRoleAssignment


theorem current_boundary_role_is_anchor :
    roleOfAddress currentInterfaceRoleAssignment
      SchurDtnDerivedAddressSeed.cutRoot =
      InterfaceRole.boundaryAnchor := rfl


theorem current_selected_role_is_bright :
    roleOfAddress currentInterfaceRoleAssignment
      SchurDtnDerivedAddressSeed.selectedChild =
      InterfaceRole.brightSelected := rfl


theorem current_frontier_role_is_residual :
    roleOfAddress currentInterfaceRoleAssignment
      SchurDtnDerivedAddressSeed.frontierPortAddress =
      InterfaceRole.frontierResidual := by
  change roleOfAddress currentInterfaceRoleAssignment
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) =
      InterfaceRole.frontierResidual
  rfl


theorem current_role_order_cut_root_node_zero :
    currentRoleOrderNodeOf SchurDtnDerivedAddressSeed.cutRoot = 0 := rfl


theorem current_role_order_selected_node_one :
    currentRoleOrderNodeOf SchurDtnDerivedAddressSeed.selectedChild = 1 := rfl


theorem current_role_order_frontier_node_two :
    currentRoleOrderNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 := by
  change currentRoleOrderNodeOf
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = 2
  rfl


theorem current_role_order_nodes :
    currentRoleOrderNodeOf SchurDtnDerivedAddressSeed.cutRoot = 0 ∧
    currentRoleOrderNodeOf SchurDtnDerivedAddressSeed.selectedChild = 1 ∧
    currentRoleOrderNodeOf SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  And.intro current_role_order_cut_root_node_zero
    (And.intro current_role_order_selected_node_one
      current_role_order_frontier_node_two)


theorem current_interface_roles_to_port_roles :
    toLocalPortRoles currentInterfaceRoleAssignment =
      CanonicalPortNumberingCriterion.currentPortRoles := rfl


theorem current_role_order_nodeOf_eq_canonical_nodeOf :
    currentRoleOrderNodeOf =
      CanonicalPortNumberingCriterion.canonicalNodeOfCurrent := by
  funext a
  cases a with
  | root => rfl
  | child b =>
      cases b <;> rfl


def currentRoleOrderAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentRoleOrderNodeOf }


theorem current_role_order_abstract_seed_eq_canonical :
    currentRoleOrderAbstractSeed =
      CanonicalPortNumberingCriterion.currentCanonicalAbstractSeed := by
  unfold currentRoleOrderAbstractSeed
    CanonicalPortNumberingCriterion.currentCanonicalAbstractSeed
  rw [current_role_order_nodeOf_eq_canonical_nodeOf]


theorem current_role_order_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentRoleOrderAbstractSeed.visibleRoles
      currentRoleOrderAbstractSeed.frontierAddress = true := rfl


theorem current_role_order_source_node_zero :
    currentRoleOrderAbstractSeed.nodeOf
      currentRoleOrderAbstractSeed.cutRoot = 0 := rfl


theorem current_role_order_frontier_node_two_in_seed :
    currentRoleOrderAbstractSeed.nodeOf
      currentRoleOrderAbstractSeed.frontierAddress = 2 :=
  current_role_order_frontier_node_two


def currentRoleOrderSeedCriterion :
    CurrentSeedCriterion currentRoleOrderAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible := current_role_order_frontier_outside_visible,
    source_node_zero := current_role_order_source_node_zero,
    frontier_node_two := current_role_order_frontier_node_two_in_seed,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem current_role_order_seed_to_local_rule :
    AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
      currentRoleOrderAbstractSeed =
      GrowthEdgeProvenance.activeAddressGrowthRule := rfl


theorem canonical_role_order_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentRoleOrderAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentRoleOrderSeedCriterion


theorem canonical_role_order_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentRoleOrderAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentRoleOrderSeedCriterion


theorem canonical_role_order_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentRoleOrderAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentRoleOrderSeedCriterion


theorem canonical_role_order_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def canonicalRoleOrderStillLocalInterfaceRoles : Prop := True


theorem canonical_role_order_still_local_interface_roles :
    canonicalRoleOrderStillLocalInterfaceRoles :=
  True.intro

end CanonicalRoleOrderCriterion
