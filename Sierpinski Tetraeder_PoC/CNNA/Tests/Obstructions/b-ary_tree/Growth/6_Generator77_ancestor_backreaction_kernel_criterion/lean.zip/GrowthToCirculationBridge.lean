import CNNA.OneInteriorGrowthKernelExample
import CNNA.Circulation

/-
  GrowthToCirculationBridge.lean
  -------------------------------
  Erster direkter Anschluss des konkreten Growth-Sektorkernels an den
  algebraischen Zirkulationskern aus Circulation.lean.

  Diese Datei beweist nicht das J-Vorzeichen. Sie zeigt nur, wie ein
  kanonischer Growth-Kandidat bzw. ein kanonischer Sektorkernel in eine
  geschlossene Kantenliste eingespeist werden kann, auf der die bereits
  gruene Zirkulationsrechnung laeuft.

  Wichtig:
    eindeutiger Kernel  -> ein Zirkulationszeuge
    symmetrischer Zwei-Sektoren-Kernel -> Paar aus + und - Zirkulation

  Das ist der korrekte Zwischenstatus: F2-Zirkulation kann angebunden werden,
  aber der absolute J-Sign ist weiterhin nicht geschlossen.
-/

namespace GrowthToCirculationBridge

abbrev Attachment := OneInteriorGrowthKernelExample.Attachment

/-- Der eindeutige Miniport-Attachment-Kandidat wird in den konkreten
    Zirkulationszeugen aus Circulation.lean eingespeist. -/
def oneInteriorEdges (_ : Attachment) : Circulation.Edges (Fin 5) :=
  Circulation.witnessCycle

/-- Vergleichs-Cochain des konkreten Zirkulationszeugen. -/
def oneInteriorCmp : Fin 5 -> Fin 5 -> Int :=
  Circulation.cmpH

/-- Zirkulation des eindeutigen Growth-Kandidaten. -/
def oneInteriorCirculation (a : Attachment) : Int :=
  Circulation.csum oneInteriorCmp (oneInteriorEdges a)

/-- Der konkrete eindeutige Growth-Kandidat traegt die nichtverschwindende
    Zirkulation +1. -/
theorem oneInterior_circulation_one :
    oneInteriorCirculation OneInteriorGrowthKernelExample.onlyAttachment = 1 := by
  unfold oneInteriorCirculation oneInteriorCmp oneInteriorEdges
  exact Circulation.witness_circulation

/-- Der eindeutige Growth-Kernel und der Zirkulationszeuge sind gekoppelt. -/
theorem oneInterior_kernel_and_circulation :
    OneInteriorGrowthKernelExample.oneInteriorDefectSystem.kernel = 1 ∧
    oneInteriorCirculation OneInteriorGrowthKernelExample.onlyAttachment = 1 :=
  And.intro OneInteriorGrowthKernelExample.oneInterior_kernel_one
    oneInterior_circulation_one

/-! ## Symmetrischer Zwei-Sektoren-Test

Der folgende Kontrollblock ist absichtlich kein J-Sign-Beweis. Er zeigt:
Wenn der Growth-Kernel zwei gleichwertige Sektoren hat, darf die Theorie
keinen davon willkuerlich waehlen. Die kanonische Antwort ist dann ein
Sektorpaar. Das Paar kann in entgegengesetzte Zirkulationsrichtungen gelesen
werden, aber die absolute Auswahl bleibt offen.
-/

/-- Explizit umgedrehter 4-Zyklus zum vorhandenen Zeugen. -/
def reversedWitnessCycle : Circulation.Edges (Fin 5) :=
  [(1, 0), (3, 1), (4, 3), (0, 4)]

/-- Der umgedrehte Zyklus traegt die Zirkulation -1. -/
theorem reversedWitness_circulation :
    Circulation.csum Circulation.cmpH reversedWitnessCycle = -1 := by
  decide

/-- Zwei gleichwertige Sektoren werden als entgegengesetzte Zirkulationszeugen
    gelesen. `false` ist der positive Zeuge, `true` der umgekehrte Zeuge. -/
def symmetricSectorEdges : Bool -> Circulation.Edges (Fin 5)
  | false => Circulation.witnessCycle
  | true  => reversedWitnessCycle

/-- Der erste symmetrische Sektor hat Zirkulation +1. -/
theorem symmetric_false_circulation :
    Circulation.csum Circulation.cmpH (symmetricSectorEdges false) = 1 := by
  exact Circulation.witness_circulation

/-- Der zweite symmetrische Sektor hat Zirkulation -1. -/
theorem symmetric_true_circulation :
    Circulation.csum Circulation.cmpH (symmetricSectorEdges true) = -1 := by
  exact reversedWitness_circulation

/-- Der Zwei-Sektoren-Kernel koppelt an das Paar der entgegengesetzten
    Zirkulationszeugen. Keine Seite wird kanonisch bevorzugt. -/
theorem symmetric_two_kernel_and_opposite_circulations :
    OneInteriorGrowthKernelExample.symmetricTwoDefectSystem.kernel = 2 ∧
    Circulation.csum Circulation.cmpH (symmetricSectorEdges false) = 1 ∧
    Circulation.csum Circulation.cmpH (symmetricSectorEdges true) = -1 :=
  And.intro OneInteriorGrowthKernelExample.symmetricTwo_kernel_two
    (And.intro symmetric_false_circulation symmetric_true_circulation)

/-- Marker: Dieser Baustein schliesst die Bridge Growth -> Zirkulationszeuge,
    aber nicht das absolute J-Vorzeichen. -/
def jSignStillOpen : Prop := True

theorem j_sign_gate_not_closed_here : jSignStillOpen := True.intro

end GrowthToCirculationBridge
