import CNNA.SchurStrictPreferenceBridge
import CNNA.OneInteriorDirichletExample
import CNNA.ConcreteMatrixArithmetic

namespace SchurDtnStrictPreferenceCriterion

abbrev Node := OneInteriorDirichletExample.Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

def beforeBlocks : CertifiedSchurBlocks :=
  OneInteriorDirichletExample.oneInteriorBlocks


def plusAfterBlocks : CertifiedSchurBlocks :=
  OneInteriorDirichletExample.oneInteriorBlocks


def minusAfterCutDefectOneBlocks : CertifiedSchurBlocks :=
  ConcreteMatrixArithmetic.certifiedOne1Blocks
    OneInteriorDirichletExample.oneInteriorCut 1 1 0 1


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterCutDefectOneBlocks


theorem plus_defect_vector_zero :
    DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks =
      [0, 0, 0, 0, 0] := rfl


theorem minus_defect_vector_one :
    DirichletInverseWitness.toDefectVector
      beforeBlocks minusAfterCutDefectOneBlocks = [1, 0, 0, 0, 0] := rfl


def strictCriterionDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem strictCriterion_false_defect :
    strictCriterionDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem strictCriterion_true_defect :
    strictCriterionDefectSystem.defect true = [1, 0, 0, 0, 0] := rfl


theorem strictCriterion_minSet_singleton :
    strictCriterionDefectSystem.minSet = [false] := rfl


theorem strictCriterion_kernel_one :
    strictCriterionDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    strictCriterionDefectSystem false strictCriterion_minSet_singleton


def strictSchurDtnPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := strictCriterion_minSet_singleton }


theorem strictCriterion_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      strictCriterionDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [strictCriterion_minSet_singleton]
  rfl


theorem strictCriterion_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      strictCriterionDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary strictSchurDtnPreference


theorem strictCriterion_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        strictCriterionDefectSystem) := by
  intro hclosed
  rw [strictCriterion_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem strict_criterion_closure_status :
    strictCriterionDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      strictCriterionDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        strictCriterionDefectSystem) :=
  And.intro strictCriterion_kernel_one
    (And.intro strictCriterion_resolved_j_sign strictCriterion_not_flip_closed)


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  OneInteriorDirichletExample.oneInteriorBlocks


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricCriterionDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetricCriterion_false_defect :
    symmetricCriterionDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetricCriterion_true_defect :
    symmetricCriterionDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetricCriterion_minSet_pair :
    symmetricCriterionDefectSystem.minSet = [false, true] := rfl


theorem symmetricCriterion_kernel_two :
    symmetricCriterionDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricCriterionDefectSystem false true symmetricCriterion_minSet_pair


theorem symmetricCriterion_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricCriterionDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetricCriterion_minSet_pair]
  rfl


theorem symmetricCriterion_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricCriterionDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricCriterionDefectSystem)
  rw [symmetricCriterion_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_criterion_status :
    symmetricCriterionDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricCriterionDefectSystem :=
  And.intro symmetricCriterion_kernel_two symmetricCriterion_not_resolved_j_sign


def concreteSchurDtnAsymmetryStillModelLevel : Prop := True


theorem concrete_schur_dtn_asymmetry_still_model_level :
    concreteSchurDtnAsymmetryStillModelLevel :=
  True.intro

end SchurDtnStrictPreferenceCriterion
