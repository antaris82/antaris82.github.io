import CNNA.SchurDtnSummary

/-
  FiniteMatrixSchurPort.lean
  --------------------------
  Vorsichtige finite Matrix-Schur-Port-Schicht.

  Diese Datei fuehrt keine freie Matrixinverse ein. Der Interior-Inversenanteil
  wird nur akzeptiert, wenn ein expliziter TwoSidedInverseWitness mitgeliefert
  wird. Der konkrete arithmetische Matrixbeweis bleibt eine tiefere Schicht.

  Zweck:

    finite blocks + provided inverse witness
      -> SchurSummary
      -> CutSummary
      -> HandoffData
      -> DefectVector.

  Damit bleibt der Schur-DtN-Port derived-only-kompatibel: Die Invertierbarkeit
  ist kein Orakel der Consumer-Schicht, sondern ein Strukturzeuge des Ports.
-/

namespace FiniteMatrixSchurPort

/-- Eine endliche Matrix als reine Indexfunktion. -/
abbrev Matrix (m n : Nat) := Fin m -> Fin n -> Nat

/-- Abstrakter beidseitiger Inversen-Zeuge fuer den Interiorblock.
    Die tatsaechliche Gleichung LII * R = I und R * LII = I wird in dieser
    portnahen Schicht noch nicht ausmultipliziert, sondern als Zertifikat
    uebergeben. Eine spaetere arithmetische Schicht darf diese Zertifikate
    aus konkreten Matrixrechnungen erzeugen. -/
structure TwoSidedInverseWitness (n : Nat) (LII R : Matrix n n) where
  leftCertified : Bool
  rightCertified : Bool
  left_ok : leftCertified = true
  right_ok : rightCertified = true

/-- Rohe finite Schur-Bloecke ohne Inversen-Zeuge. Diese Struktur allein darf
    noch keinen SchurSummary-Port erzeugen. -/
structure RawSchurBlocks (V : Type) where
  cut : FiniteCutCombinatorics.FiniteCut V
  boundaryDim : Nat
  interiorDim : Nat
  LBBTrace : Nat
  couplingTrace : Nat
  cutDefect : Nat
  LII : Matrix interiorDim interiorDim
  candidateInverse : Matrix interiorDim interiorDim

/-- InvertibleSchurBlocks ist RawSchurBlocks plus expliziter beidseitiger
    Inversen-Zeuge. Nur diese Struktur darf in eine SchurSummary uebersetzt
    werden. -/
structure InvertibleSchurBlocks (V : Type) where
  raw : RawSchurBlocks V
  inv : TwoSidedInverseWitness raw.interiorDim raw.LII raw.candidateInverse

/-- Parameterfreier Trace-Defekt des Schur-DtN-Ports. In dieser Summary-Schicht
    wird die ausmultiplizierte Schur-Korrektur durch `couplingTrace` angeliefert;
    die Differenz zum Boundary-Trace ist der portnahe DtN-Trace. -/
def schurTrace {V : Type} (b : InvertibleSchurBlocks V) : Nat :=
  FiniteHandoffSummary.absDiff b.raw.LBBTrace b.raw.couplingTrace

/-- Der Cut-Defekt wird aus dem Schur-Port uebernommen. -/
def schurCutDefect {V : Type} (b : InvertibleSchurBlocks V) : Nat :=
  b.raw.cutDefect

/-- Uebersetzung des matrixnahen Ports in die vorhandene SchurSummary-Schicht. -/
def toSchurSummary {V : Type} (b : InvertibleSchurBlocks V) :
    SchurDtnSummary.SchurSummary V :=
  { cut := b.raw.cut,
    schurDtnTrace := schurTrace b,
    schurCutDefect := schurCutDefect b }

/-- Weiterleitung in die CutSummary-Schicht. -/
def toCutSummary {V : Type} (b : InvertibleSchurBlocks V) :
    FiniteHandoffSummary.CutSummary :=
  SchurDtnSummary.toCutSummary (toSchurSummary b)

/-- Weiterleitung in die HandoffData-Schicht. -/
def toHandoffData {V : Type} (before after : InvertibleSchurBlocks V) :
    FiniteHandoffSummary.HandoffData :=
  SchurDtnSummary.toHandoffData
    (toSchurSummary before) (toSchurSummary after)

/-- Weiterleitung in den parameterfreien Defektvektor. -/
def toDefectVector {V : Type} (before after : InvertibleSchurBlocks V) :
    List Nat :=
  SchurDtnSummary.toDefectVector
    (toSchurSummary before) (toSchurSummary after)

/-! ## Definitorische Link-Saetze -/

theorem toSchurSummary_trace {V : Type} (b : InvertibleSchurBlocks V) :
    (toSchurSummary b).schurDtnTrace = schurTrace b := rfl

theorem toSchurSummary_cutDefect {V : Type} (b : InvertibleSchurBlocks V) :
    (toSchurSummary b).schurCutDefect = b.raw.cutDefect := rfl

theorem toSchurSummary_cut {V : Type} (b : InvertibleSchurBlocks V) :
    (toSchurSummary b).cut = b.raw.cut := rfl

/-- Der Matrix-Schur-Port fuehrt exakt durch die vorhandene SchurSummary-Schicht. -/
theorem toDefectVector_link {V : Type}
    (before after : InvertibleSchurBlocks V) :
    toDefectVector before after =
      SchurDtnSummary.toDefectVector
        (toSchurSummary before) (toSchurSummary after) := rfl

/-- Explizite Gestalt des DtN-Trace aus den gelieferten Block-Summarydaten. -/
theorem schurTrace_unfold {V : Type} (b : InvertibleSchurBlocks V) :
    schurTrace b =
      FiniteHandoffSummary.absDiff b.raw.LBBTrace b.raw.couplingTrace := rfl

/-- Wenn Boundary-Trace und Schur-Korrekturtrace uebereinstimmen, ist der
    Schur-Trace der Summary-Schicht null. -/
theorem schurTrace_zero_of_eq {V : Type} (b : InvertibleSchurBlocks V)
    (h : b.raw.LBBTrace = b.raw.couplingTrace) : schurTrace b = 0 := by
  unfold schurTrace
  rw [h]
  exact FiniteHandoffSummary.absDiff_self b.raw.couplingTrace

/-- Der Inversen-Zeuge ist links zertifiziert. -/
theorem inverse_left_certified {V : Type} (b : InvertibleSchurBlocks V) :
    b.inv.leftCertified = true :=
  b.inv.left_ok

/-- Der Inversen-Zeuge ist rechts zertifiziert. -/
theorem inverse_right_certified {V : Type} (b : InvertibleSchurBlocks V) :
    b.inv.rightCertified = true :=
  b.inv.right_ok

/-- Ein After-Port mit Schur-Cut-Defekt null erzeugt keinen Cut-Defekt im
    HandoffData. -/
theorem cut_defect_zero_of_after_ok {V : Type}
    (before after : InvertibleSchurBlocks V) (h : after.raw.cutDefect = 0) :
    (toHandoffData before after).cutDefect = 0 := by
  exact SchurDtnSummary.cut_defect_zero_of_schur_ok
    (toSchurSummary before) (toSchurSummary after) h

/-- Gleicher Schur-Trace erzeugt keinen DtN-Defekt. -/
theorem dtn_defect_zero_of_same_trace {V : Type}
    (before after : InvertibleSchurBlocks V)
    (h : schurTrace before = schurTrace after) :
    FiniteHandoffSummary.dtnDefect (toHandoffData before after) = 0 := by
  exact SchurDtnSummary.dtn_defect_zero_of_same_schur_trace
    (toSchurSummary before) (toSchurSummary after) h

/-- Voller Link bis zur FiniteHandoffSummary-Schicht. -/
theorem toDefectVector_summary_link {V : Type}
    (before after : InvertibleSchurBlocks V) :
    toDefectVector before after =
      FiniteHandoffSummary.toDefectVector
        (toCutSummary before) (toCutSummary after) := rfl

end FiniteMatrixSchurPort
