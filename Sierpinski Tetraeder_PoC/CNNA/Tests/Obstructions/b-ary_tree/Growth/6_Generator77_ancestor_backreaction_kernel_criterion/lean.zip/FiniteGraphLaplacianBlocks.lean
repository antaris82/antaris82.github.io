import CNNA.FiniteMatrixSchurPort

/-
  FiniteGraphLaplacianBlocks.lean
  --------------------------------
  Endliche Graph- und Cut-Daten -> rohe Laplace-Schur-Blocksummary.

  Diese Schicht bleibt bewusst vor der echten arithmetischen Inversenrechnung.
  Sie erzeugt RawSchurBlocks aus einem FiniteCut und einer Bool-Adjazenz.
  Der Uebergang zu InvertibleSchurBlocks bleibt weiterhin nur mit einem
  expliziten TwoSidedInverseWitness erlaubt.

  Zweck:

    FiniteCut + adjacency
      -> graph Laplacian block summaries
      -> RawSchurBlocks
      -> with inverse witness
      -> InvertibleSchurBlocks
      -> SchurSummary
      -> DefectVector.

  Damit ist der J-Vorzeichenpfad nicht verlassen: diese Schicht liefert die
  endliche reale Schur-DtN-Provenienz, an der spaeter getestet wird, ob eine
  zweite Achse, Nichtkommutativitaet oder ein Locking-Datum wirklich entsteht.
-/

namespace FiniteGraphLaplacianBlocks

/-! ## 0. Kleine endliche Summen -/

def sumMap {A : Type} (f : A -> Nat) : List A -> Nat
  | [] => 0
  | a :: as => f a + sumMap f as

theorem sumMap_nil {A : Type} (f : A -> Nat) :
    sumMap f [] = 0 := rfl

theorem sumMap_cons {A : Type} (f : A -> Nat) (a : A) (as : List A) :
    sumMap f (a :: as) = f a + sumMap f as := rfl

/-! ## 1. Graph-Laplace-Summaries aus einem FiniteCut -/

abbrev FiniteCut (V : Type) := FiniteCutCombinatorics.FiniteCut V

/-- Die Knoten, die in dieser Summary-Schicht als sichtbarer endlicher Graph
    gelesen werden: Boundary plus Interior. -/
def visibleNodes {V : Type} (c : FiniteCut V) : List V :=
  c.boundary ++ c.interior

/-- Bool-Grad eines Knotens relativ zum sichtbaren Cut-Graphen. -/
def degree {V : Type} (c : FiniteCut V) (v : V) : Nat :=
  FiniteCutCombinatorics.countP (fun w => c.adjacent v w) (visibleNodes c)

/-- Laplace-Trace auf einer angegebenen Knotenliste: Summe der Grade. -/
def traceOn {V : Type} (c : FiniteCut V) (xs : List V) : Nat :=
  sumMap (degree c) xs

/-- Boundary-Block-Trace. -/
def LBBTrace {V : Type} (c : FiniteCut V) : Nat :=
  traceOn c c.boundary

/-- Interior-Block-Trace. Diese Groesse ist ein Summary-Gate fuer spaetere
    Dirichlet-Inversen-Zeugen, wird im RawSchurBlocks-Port aber noch nicht als
    freie Inverse benutzt. -/
def LIITrace {V : Type} (c : FiniteCut V) : Nat :=
  traceOn c c.interior

/-- Boundary-Interior-Kopplungs-Trace als reine Inzidenzzaehlung. -/
def couplingTrace {V : Type} (c : FiniteCut V) : Nat :=
  FiniteCutCombinatorics.boundaryInteriorIncidence c

/-- Reziprozitaetsbedingung zwischen zwei Knotenlisten. Dies ist ein Gate, kein
    importierter Chiralitaets- oder Orientierungsdatensatz. -/
def ReciprocalOn {V : Type} (c : FiniteCut V) (xs ys : List V) : Prop :=
  forall x, x ∈ xs -> forall y, y ∈ ys -> c.adjacent x y = c.adjacent y x

/-- Boundary-Interior-Reziprozitaet. -/
def BoundaryInteriorReciprocal {V : Type} (c : FiniteCut V) : Prop :=
  ReciprocalOn c c.boundary c.interior

/-- Graph-Cut-Defekt: noch kein Interiorblock, falls der Interior leer ist.
    Spaetere arithmetische Schichten duerfen diesen Defekt verfeinern. -/
def graphCutDefect {V : Type} (c : FiniteCut V) : Nat :=
  FiniteCutCombinatorics.cutKernelDefect c

/-! ## 2. Matrix-Port ohne freie Inverse -/

/-- Nullmatrix als Platzhalter fuer die reine Port-Schicht. Sie ist keine
    behauptete Inverse. -/
def zeroMatrix (m n : Nat) : FiniteMatrixSchurPort.Matrix m n :=
  fun _ _ => 0

/-- Aus endlichen Graph-Cut-Daten werden rohe Schur-Bloecke. Diese Struktur
    allein erzeugt noch keinen SchurSummary-Port. -/
def toRawSchurBlocks {V : Type} (c : FiniteCut V) :
    FiniteMatrixSchurPort.RawSchurBlocks V :=
  { cut := c,
    boundaryDim := c.boundary.length,
    interiorDim := c.interior.length,
    LBBTrace := LBBTrace c,
    couplingTrace := couplingTrace c,
    cutDefect := graphCutDefect c,
    LII := zeroMatrix c.interior.length c.interior.length,
    candidateInverse := zeroMatrix c.interior.length c.interior.length }

/-- Erst ein expliziter beidseitiger Inversen-Zeuge macht aus den rohen
    Graphbloecken einen zulaessigen Matrix-Schur-Port. -/
def withInverseWitness {V : Type} (c : FiniteCut V)
    (w : FiniteMatrixSchurPort.TwoSidedInverseWitness
      c.interior.length
      (zeroMatrix c.interior.length c.interior.length)
      (zeroMatrix c.interior.length c.interior.length)) :
    FiniteMatrixSchurPort.InvertibleSchurBlocks V :=
  { raw := toRawSchurBlocks c,
    inv := w }

/-! ## 3. Definitorische Link-Saetze -/

theorem visibleNodes_unfold {V : Type} (c : FiniteCut V) :
    visibleNodes c = c.boundary ++ c.interior := rfl

theorem degree_unfold {V : Type} (c : FiniteCut V) (v : V) :
    degree c v =
      FiniteCutCombinatorics.countP
        (fun w => c.adjacent v w) (c.boundary ++ c.interior) := rfl

theorem LBBTrace_unfold {V : Type} (c : FiniteCut V) :
    LBBTrace c = traceOn c c.boundary := rfl

theorem LIITrace_unfold {V : Type} (c : FiniteCut V) :
    LIITrace c = traceOn c c.interior := rfl

theorem couplingTrace_unfold {V : Type} (c : FiniteCut V) :
    couplingTrace c = FiniteCutCombinatorics.boundaryInteriorIncidence c := rfl

theorem toRawSchurBlocks_boundaryDim {V : Type} (c : FiniteCut V) :
    (toRawSchurBlocks c).boundaryDim = c.boundary.length := rfl

theorem toRawSchurBlocks_interiorDim {V : Type} (c : FiniteCut V) :
    (toRawSchurBlocks c).interiorDim = c.interior.length := rfl

theorem toRawSchurBlocks_LBBTrace {V : Type} (c : FiniteCut V) :
    (toRawSchurBlocks c).LBBTrace = LBBTrace c := rfl

theorem toRawSchurBlocks_couplingTrace {V : Type} (c : FiniteCut V) :
    (toRawSchurBlocks c).couplingTrace = couplingTrace c := rfl

theorem toRawSchurBlocks_cutDefect {V : Type} (c : FiniteCut V) :
    (toRawSchurBlocks c).cutDefect = graphCutDefect c := rfl

/-- Der mit Zeuge erzeugte Port nutzt exakt die rohen Graph-Schur-Bloecke. -/
theorem withInverseWitness_raw {V : Type} (c : FiniteCut V)
    (w : FiniteMatrixSchurPort.TwoSidedInverseWitness
      c.interior.length
      (zeroMatrix c.interior.length c.interior.length)
      (zeroMatrix c.interior.length c.interior.length)) :
    (withInverseWitness c w).raw = toRawSchurBlocks c := rfl

/-- Link zum Matrix-Schur-Port: mit einem expliziten Zeugen geht der Graphcut
    durch die bereits gruene FiniteMatrixSchurPort-Schicht. -/
theorem toDefectVector_link {V : Type} (cBefore cAfter : FiniteCut V)
    (wBefore : FiniteMatrixSchurPort.TwoSidedInverseWitness
      cBefore.interior.length
      (zeroMatrix cBefore.interior.length cBefore.interior.length)
      (zeroMatrix cBefore.interior.length cBefore.interior.length))
    (wAfter : FiniteMatrixSchurPort.TwoSidedInverseWitness
      cAfter.interior.length
      (zeroMatrix cAfter.interior.length cAfter.interior.length)
      (zeroMatrix cAfter.interior.length cAfter.interior.length)) :
    FiniteMatrixSchurPort.toDefectVector
      (withInverseWitness cBefore wBefore)
      (withInverseWitness cAfter wAfter)
    =
    FiniteMatrixSchurPort.toDefectVector
      { raw := toRawSchurBlocks cBefore, inv := wBefore }
      { raw := toRawSchurBlocks cAfter, inv := wAfter } := rfl

/-- Wenn der Interior nicht leer ist, verschwindet der reine Graph-Cut-Defekt. -/
theorem graphCutDefect_zero_of_nonempty {V : Type} (c : FiniteCut V)
    (h : c.interior.length ≠ 0) :
    graphCutDefect c = 0 := by
  unfold graphCutDefect
  exact FiniteCutCombinatorics.cutKernelDefect_zero_of_nonempty c h

/-- Wenn der Interior leer ist, ist der reine Graph-Cut-Defekt eins. -/
theorem graphCutDefect_one_of_empty {V : Type} (c : FiniteCut V)
    (h : c.interior.length = 0) :
    graphCutDefect c = 1 := by
  unfold graphCutDefect
  exact FiniteCutCombinatorics.cutKernelDefect_one_of_empty c h

end FiniteGraphLaplacianBlocks
