import CNNA.SchurDtnPortSupportProvenance

namespace SchurDtnPortResidualArithmetic

abbrev Node := Fin 3
abbrev FiniteCut := FiniteGraphLaplacianBlocks.FiniteCut Node
abbrev CertifiedSchurBlocks := DirichletInverseWitness.CertifiedSchurBlocks Node
abbrev SchurSummary := SchurDtnSummary.SchurSummary Node
abbrev DefectSystem := SectorResolutionGate.DefectSystem

structure SchurDtnResidualPortData (V : Type) where
  boundary : List V
  interior : List V
  uvBoundary : List V
  envBoundary : List V
  recordNodes : List V
  candidatePortNodes : List V
  beforePortTrace : V -> Nat
  afterPortTrace : V -> Nat
  adjacent : V -> V -> Bool


def residualPortNodes {V : Type} (p : SchurDtnResidualPortData V) :
    List V -> List V
  | [] => []
  | x :: xs =>
      if p.beforePortTrace x = p.afterPortTrace x then
        residualPortNodes p xs
      else
        x :: residualPortNodes p xs


def dtnPortNodes {V : Type} (p : SchurDtnResidualPortData V) : List V :=
  residualPortNodes p p.candidatePortNodes


def toPortData {V : Type} (p : SchurDtnResidualPortData V) :
    SchurDtnPortSupportProvenance.SchurDtnPortData V :=
  { boundary := p.boundary,
    interior := p.interior,
    uvBoundary := p.uvBoundary,
    envBoundary := p.envBoundary,
    recordNodes := p.recordNodes,
    dtnPortNodes := dtnPortNodes p,
    adjacent := p.adjacent }


theorem toPortData_dtnPortNodes {V : Type}
    (p : SchurDtnResidualPortData V) :
    (toPortData p).dtnPortNodes = dtnPortNodes p := rfl


def toFiniteCut {V : Type} [BEq V] (p : SchurDtnResidualPortData V) :
    FiniteCutCombinatorics.FiniteCut V :=
  SchurDtnPortSupportProvenance.toFiniteCut (toPortData p)


theorem toFiniteCut_complementNodes {V : Type} [BEq V]
    (p : SchurDtnResidualPortData V) :
    (toFiniteCut p).complementNodes =
      SchurDtnComplementProvenance.complementNodes
        (SchurDtnPortSupportProvenance.toPortCutProvenance
          (toPortData p)) := rfl


def edge01 (x y : Node) : Bool :=
  ((x == 0) && (y == 1)) || ((x == 1) && (y == 0))


def zeroTrace (_x : Node) : Nat :=
  0


def minusResidualTrace (x : Node) : Nat :=
  if x == 2 then 1 else 0


def beforeResidualPortData : SchurDtnResidualPortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforePortTrace := zeroTrace,
    afterPortTrace := zeroTrace,
    adjacent := edge01 }


def plusAfterResidualPortData : SchurDtnResidualPortData Node :=
  beforeResidualPortData


def minusAfterResidualPortData : SchurDtnResidualPortData Node :=
  { boundary := [0],
    interior := [1],
    uvBoundary := [1],
    envBoundary := [0],
    recordNodes := [],
    candidatePortNodes := [0, 1, 2],
    beforePortTrace := zeroTrace,
    afterPortTrace := minusResidualTrace,
    adjacent := edge01 }


theorem before_residual_port_nodes_empty :
    dtnPortNodes beforeResidualPortData = [] := rfl


theorem plus_residual_port_nodes_empty :
    dtnPortNodes plusAfterResidualPortData = [] := rfl


theorem minus_residual_port_nodes_from_trace_arithmetic :
    dtnPortNodes minusAfterResidualPortData = [2] := rfl


def beforePortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  toPortData beforeResidualPortData


def plusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  toPortData plusAfterResidualPortData


def minusAfterPortData : SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  toPortData minusAfterResidualPortData


theorem before_port_data_residual_nodes_empty :
    beforePortData.dtnPortNodes = [] := rfl


theorem plus_port_data_residual_nodes_empty :
    plusAfterPortData.dtnPortNodes = [] := rfl


theorem minus_port_data_residual_nodes_from_trace_arithmetic :
    minusAfterPortData.dtnPortNodes = [2] := rfl


theorem before_support_nodes_from_residual_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes beforePortData = [0, 1] := rfl


theorem plus_support_nodes_from_residual_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes plusAfterPortData = [0, 1] := rfl


theorem minus_support_nodes_from_residual_arithmetic :
    SchurDtnPortSupportProvenance.supportNodes minusAfterPortData = [0, 1, 2] := rfl


def beforeCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut beforePortData


def plusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut plusAfterPortData


def minusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut minusAfterPortData


theorem before_cut_complement_empty :
    beforeCut.complementNodes = [] := rfl


theorem plus_cut_complement_empty :
    plusAfterCut.complementNodes = [] := rfl


theorem minus_cut_complement_from_residual_arithmetic :
    minusAfterCut.complementNodes = [2] := rfl


theorem before_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature beforeCut = 0 := rfl


theorem plus_complement_signature_zero :
    FiniteCutCombinatorics.complementSignature plusAfterCut = 0 := rfl


theorem minus_complement_signature_one :
    FiniteCutCombinatorics.complementSignature minusAfterCut = 1 := rfl


def beforeBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks beforeCut


def plusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks plusAfterCut


def minusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks minusAfterCut


def beforeSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary beforeBlocks


def plusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary plusAfterBlocks


def minusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary minusAfterBlocks


def plusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks plusAfterBlocks


def minusComputedDefectVector : List Nat :=
  DirichletInverseWitness.toDefectVector beforeBlocks minusAfterBlocks


theorem plus_computed_defect_vector_zero :
    plusComputedDefectVector = [0, 0, 0, 0, 0] := rfl


theorem minus_computed_defect_vector_from_residual_arithmetic :
    minusComputedDefectVector = [0, 0, 0, 0, 1] := rfl


def residualArithmeticDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary minusAfterSummary


theorem residual_arithmetic_false_defect :
    residualArithmeticDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem residual_arithmetic_true_defect :
    residualArithmeticDefectSystem.defect true = [0, 0, 0, 0, 1] := rfl


theorem residual_arithmetic_minSet_singleton :
    residualArithmeticDefectSystem.minSet = [false] := rfl


theorem residual_arithmetic_kernel_one :
    residualArithmeticDefectSystem.kernel = 1 :=
  CanonicalGrowthKernel.DefectSystem.unique_kernel_one
    residualArithmeticDefectSystem false residual_arithmetic_minSet_singleton


def residualArithmeticSchurStrictPreference :
    SchurStrictPreferenceBridge.SchurStrictPreference
      beforeSummary plusAfterSummary minusAfterSummary :=
  { minSet_singleton := residual_arithmetic_minSet_singleton }


theorem residual_arithmetic_resolved_j_sign :
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      residualArithmeticDefectSystem :=
  SchurStrictPreferenceBridge.resolved_of_schur_strict_preference
    beforeSummary plusAfterSummary minusAfterSummary
    residualArithmeticSchurStrictPreference


theorem residual_arithmetic_locks_eq_plusSector :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      residualArithmeticDefectSystem = JSignClosureCriterion.plusSector := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.plusSector
  rw [residual_arithmetic_minSet_singleton]
  rfl


theorem residual_arithmetic_not_flip_closed :
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        residualArithmeticDefectSystem) := by
  intro hclosed
  rw [residual_arithmetic_locks_eq_plusSector] at hclosed
  exact SymmetryBreakingClosureGate.plusSector_not_closed_under_flip hclosed


theorem residual_arithmetic_closure_status :
    residualArithmeticDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      residualArithmeticDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        residualArithmeticDefectSystem) :=
  And.intro residual_arithmetic_kernel_one
    (And.intro residual_arithmetic_resolved_j_sign
      residual_arithmetic_not_flip_closed)


def symmetricMinusAfterResidualPortData : SchurDtnResidualPortData Node :=
  plusAfterResidualPortData


def symmetricMinusAfterPortData :
    SchurDtnPortSupportProvenance.SchurDtnPortData Node :=
  toPortData symmetricMinusAfterResidualPortData


def symmetricMinusAfterCut : FiniteCut :=
  SchurDtnPortSupportProvenance.toFiniteCut symmetricMinusAfterPortData


def symmetricMinusAfterBlocks : CertifiedSchurBlocks :=
  SchurDtnPortSupportProvenance.certifiedBlocks symmetricMinusAfterCut


def symmetricMinusAfterSummary : SchurSummary :=
  DirichletInverseWitness.toSchurSummary symmetricMinusAfterBlocks


def symmetricDefectSystem : DefectSystem Bool :=
  SchurStrictPreferenceBridge.schurCutHandoffDefectSystem
    beforeSummary plusAfterSummary symmetricMinusAfterSummary


theorem symmetric_residual_false_defect :
    symmetricDefectSystem.defect false = [0, 0, 0, 0, 0] := rfl


theorem symmetric_residual_true_defect :
    symmetricDefectSystem.defect true = [0, 0, 0, 0, 0] := rfl


theorem symmetric_residual_minSet_pair :
    symmetricDefectSystem.minSet = [false, true] := rfl


theorem symmetric_residual_kernel_two :
    symmetricDefectSystem.kernel = 2 :=
  CanonicalGrowthKernel.DefectSystem.two_sector_kernel
    symmetricDefectSystem false true symmetric_residual_minSet_pair


theorem symmetric_residual_locks_eq_twoSectors :
    SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem = JSignClosureCriterion.twoSectors := by
  unfold GrowthSectorResolutionBridge.GrowthSectorMap.lockCandidates
    SectorResolutionGate.lockCandidates
    GrowthSectorResolutionBridge.GrowthSectorMap.lockOf
    SchurStrictPreferenceBridge.schurSectorMap
    CutStrictPreferenceBridge.cutSectorMap
    HandoffStrictPreferenceBridge.handoffSectorMap
    GrowthSectorResolutionBridge.signToLock
    JSignClosureCriterion.twoSectors
  rw [symmetric_residual_minSet_pair]
  rfl


theorem symmetric_residual_not_resolved_j_sign :
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem := by
  change ¬ JSignClosureCriterion.hasClosedJSign
    (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
      symmetricDefectSystem)
  rw [symmetric_residual_locks_eq_twoSectors]
  exact JSignClosureCriterion.twoSectors_no_closed_j_sign


theorem symmetric_residual_status :
    symmetricDefectSystem.kernel = 2 ∧
    ¬ SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      symmetricDefectSystem :=
  And.intro symmetric_residual_kernel_two
    symmetric_residual_not_resolved_j_sign


def portTraceResidualArithmeticStillNeedsSchurDtnDerivation : Prop := True


theorem port_trace_residual_arithmetic_still_needs_schur_dtn_derivation :
    portTraceResidualArithmeticStillNeedsSchurDtnDerivation :=
  True.intro

end SchurDtnPortResidualArithmetic
