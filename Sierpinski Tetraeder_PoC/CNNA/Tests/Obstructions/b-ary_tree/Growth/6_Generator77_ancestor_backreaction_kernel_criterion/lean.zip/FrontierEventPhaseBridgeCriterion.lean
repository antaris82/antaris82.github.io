import CNNA.FrontierPhaseCertificateCriterion
import CNNA.SchurDtnFrontierEventActivationProvenance

namespace FrontierEventPhaseBridgeCriterion

abbrev CurrentAddress := FrontierPhaseCertificateCriterion.CurrentAddress
abbrev FrontierPhaseCertificate :=
  FrontierPhaseCertificateCriterion.FrontierPhaseCertificate
abbrev FillPhase := FrontierRankProfileCriterion.FillPhase
abbrev CurrentSeedCriterion :=
  AbstractAddressTypeGrowthCriterion.CurrentSeedCriterion
abbrev AbstractAddressSeed :=
  AbstractAddressTypeGrowthCriterion.AbstractAddressSeed


theorem residual_event_active :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
      true :=
  SchurDtnFrontierEventActivationProvenance.residual_extension_event_active_node2


theorem inactive_event_not_active :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.inactiveEdgeRecordNode2 =
      false :=
  SchurDtnFrontierEventActivationProvenance.inactive_edge_event_not_active_node2


theorem inside_target_event_not_active :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.insideTargetRecordNode2 =
      false :=
  SchurDtnFrontierEventActivationProvenance.inside_target_event_not_active_node2


theorem residual_event_target_outside_roles :
    SchurDtnFrontierEventActivationProvenance.targetOutsideRoles
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
      true :=
  SchurDtnFrontierEventActivationProvenance.residual_target_outside_roles_node2


theorem current_phase_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      FrontierRankProfileCriterion.currentFrontierRankProfile.visibleRoles
      SchurDtnDerivedAddressSeed.frontierPortAddress = true := by
  change AbstractAddressTypeGrowthCriterion.outsideVisible
    SchurDtnDerivedAddressSeed.roleAddresses
    (SchurDtnDerivedAddressSeed.Address.child
      SchurDtnDerivedAddressSeed.Branch.right) = true
  rfl


theorem current_phase_rank_growth_true :
    decide
      (FrontierRankProfileCriterion.currentFrontierRankProfile.beforeRank <
        FrontierRankProfileCriterion.currentFrontierRankProfile.afterRank) =
      true := rfl


theorem residual_event_outside_visible_matches_current_frontier :
    SchurDtnFrontierEventActivationProvenance.targetOutsideRoles
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
    AbstractAddressTypeGrowthCriterion.outsideVisible
      FrontierRankProfileCriterion.currentFrontierRankProfile.visibleRoles
      SchurDtnDerivedAddressSeed.frontierPortAddress := by
  rw [residual_event_target_outside_roles]
  rw [current_phase_frontier_outside_visible]


theorem residual_event_matches_current_active_frontier_phase :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress := by
  rw [residual_event_active]
  rw [FrontierRankProfileCriterion.current_active_frontier_phase_frontier_true]


theorem inside_event_matches_current_selected_non_frontier_phase :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.insideTargetRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild := by
  rw [inside_target_event_not_active]
  rw [FrontierRankProfileCriterion.current_active_frontier_phase_selected_false]


def inactiveEventShowsEdgePresentNotInPhase : Prop :=
  SchurDtnFrontierEventActivationProvenance.eventActive
    SchurDtnFrontierEventActivationProvenance.inactiveEdgeRecordNode2 = false ∧
  FrontierRankProfileCriterion.activeFrontierPhase
    FrontierRankProfileCriterion.currentFrontierRankProfile
    SchurDtnDerivedAddressSeed.frontierPortAddress = true


theorem inactive_event_shows_edge_present_not_in_phase :
    inactiveEventShowsEdgePresentNotInPhase :=
  And.intro
    inactive_event_not_active
    FrontierRankProfileCriterion.current_active_frontier_phase_frontier_true


structure EventBackedFrontierPhaseCertificate where
  phaseCertificate : FrontierPhaseCertificate CurrentAddress
  residualEventActive :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
      true
  residualEventMatchesFrontierPhase :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.residualExtensionRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.frontierPortAddress
  insideEventMatchesSelectedNonFrontier :
    SchurDtnFrontierEventActivationProvenance.eventActive
      SchurDtnFrontierEventActivationProvenance.insideTargetRecordNode2 =
    FrontierRankProfileCriterion.activeFrontierPhase
      FrontierRankProfileCriterion.currentFrontierRankProfile
      SchurDtnDerivedAddressSeed.selectedChild
  inactiveEdgePresentControl : inactiveEventShowsEdgePresentNotInPhase


def currentEventBackedFrontierPhaseCertificate :
    EventBackedFrontierPhaseCertificate :=
  { phaseCertificate :=
      FrontierPhaseCertificateCriterion.currentFrontierPhaseCertificate,
    residualEventActive := residual_event_active,
    residualEventMatchesFrontierPhase :=
      residual_event_matches_current_active_frontier_phase,
    insideEventMatchesSelectedNonFrontier :=
      inside_event_matches_current_selected_non_frontier_phase,
    inactiveEdgePresentControl :=
      inactive_event_shows_edge_present_not_in_phase }


def currentEventBackedNodeOf : CurrentAddress -> FrontierPhaseCertificateCriterion.Node :=
  FrontierPhaseCertificateCriterion.certifiedNodeOf
    currentEventBackedFrontierPhaseCertificate.phaseCertificate


theorem current_event_backed_nodeOf_eq_certified_nodeOf :
    currentEventBackedNodeOf =
      FrontierPhaseCertificateCriterion.currentCertifiedNodeOf := rfl


theorem current_event_backed_nodeOf_eq_fill_order_nodeOf :
    currentEventBackedNodeOf =
      CanonicalFillOrderCriterion.currentFillRankNodeOf := by
  rw [current_event_backed_nodeOf_eq_certified_nodeOf]
  exact FrontierPhaseCertificateCriterion.current_certified_nodeOf_eq_fill_order_nodeOf


theorem current_event_backed_frontier_node_two :
    currentEventBackedNodeOf
      SchurDtnDerivedAddressSeed.frontierPortAddress = 2 :=
  FrontierPhaseCertificateCriterion.current_certificate_frontier_node_two


def currentEventBackedAbstractSeed : AbstractAddressSeed CurrentAddress :=
  { cutRoot := SchurDtnDerivedAddressSeed.cutRoot,
    selectedAddress := SchurDtnDerivedAddressSeed.selectedChild,
    frontierAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    sourceAddress := SchurDtnDerivedAddressSeed.cutRoot,
    targetAddress := SchurDtnDerivedAddressSeed.frontierPortAddress,
    visibleRoles := SchurDtnDerivedAddressSeed.roleAddresses,
    beforeRank := 0,
    afterRank := 1,
    nodeOf := currentEventBackedNodeOf }


theorem current_event_backed_frontier_outside_visible :
    AbstractAddressTypeGrowthCriterion.outsideVisible
      currentEventBackedAbstractSeed.visibleRoles
      currentEventBackedAbstractSeed.frontierAddress = true := rfl


def currentEventBackedSeedCriterion :
    CurrentSeedCriterion currentEventBackedAbstractSeed :=
  { source_is_cut_root := rfl,
    target_is_frontier := rfl,
    rank_increases := rfl,
    frontier_outside_visible :=
      current_event_backed_frontier_outside_visible,
    source_node_zero :=
      FrontierPhaseCertificateCriterion.current_certificate_cut_root_node_zero,
    frontier_node_two := current_event_backed_frontier_node_two,
    cut_root_is_local := rfl,
    frontier_is_local := rfl }


theorem event_backed_phase_growth_active :
    GrowthEdgeProvenance.growthActive
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentEventBackedAbstractSeed) = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_growth_active
    currentEventBackedSeedCriterion


theorem event_backed_phase_forward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentEventBackedAbstractSeed) 0 2 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_forward_edge
    currentEventBackedSeedCriterion


theorem event_backed_phase_backward_edge :
    GrowthEdgeProvenance.growthAdjacent
      (AbstractAddressTypeGrowthCriterion.toLocalGrowthRule
        currentEventBackedAbstractSeed) 2 0 = true :=
  AbstractAddressTypeGrowthCriterion.generic_seed_backward_edge
    currentEventBackedSeedCriterion


theorem event_backed_phase_closes_g1 :
    GrowthEdgeProvenance.derivedGrowthDefectSystem.kernel = 1 ∧
    SchurStrictPreferenceBridge.schurSectorMap.hasResolvedJSign
      GrowthEdgeProvenance.derivedGrowthDefectSystem ∧
    ¬ SymmetrySectorNoGo.sectorClosedUnderFlip
      (SchurStrictPreferenceBridge.schurSectorMap.lockCandidates
        GrowthEdgeProvenance.derivedGrowthDefectSystem) :=
  GrowthEdgeProvenance.derived_growth_status


def eventPhaseBridgeStillCurrentCompatibilityLayer : Prop := True


theorem event_phase_bridge_still_current_compatibility_layer :
    eventPhaseBridgeStillCurrentCompatibilityLayer :=
  True.intro

end FrontierEventPhaseBridgeCriterion
