#!/usr/bin/env python3
"""
CNNA v10.1 — Projective Provenance Carrier Test with Tower-Pushforward Safeguards.

This script is a deterministic Python diagnostic derived from the v9 dynamic-birth
Schur/backreaction model.  It deliberately removes the v9 geometry/entropy/
two-ended-quotient claims and tests only the next lower-layer question:

    Does the asymmetric dynamic provenance boundary carry a projectively
    consistent positive carrier, and does a separate signed orientation/current
    survive over that carrier?

Guardrails
----------
- The object is the asymmetric dynamic provenance tree, not the strict symmetric
  control tree.  The uniform/count carrier is only a neutral cylinder carrier on
  the dynamic boundary.
- The S-response carrier is built only from the symmetric matrix part S of the
  local response Lambda=S+A, after mean-zero projection.
- The antisymmetric part A, helicity/omega/current J, and F1/F2-like orientation
  diagnostics are never used to define a measure.  They are reported only as
  separate signed currents over a valid positive carrier.
- M3 mode-universality is never a standalone success.  It is interpreted only
  after M2c has classified nontriviality versus the uniform/count carrier.
- No spectral dimension, no Laplacian geometry, no AQFT algebra, and no new
  bridge/embedding is constructed here.
- All Schur complements use np.linalg.solve, never np.linalg.inv.

The local S-response energy is a local event/shell density.  It is not
identified directly with a cylinder measure.  A cylinder carrier is built by
pushing deepest available S-response density forward along prefix maps.

The local S-response density for a node w is computed from a one-step
root/front shell response when children are available:

    boundary = [parent(w)] + children(w)       for non-root internal nodes
    boundary = children(root)                 for the root
    interior = [w]

Therefore local S-response density levels are available only up to max_level-1
in a finite approximant.  The primary v10.1 carrier is the terminal-shell
pushforward of this density to all shallower cylinder levels.
"""

from __future__ import annotations

import argparse
import csv
import math
from dataclasses import dataclass, field
from collections import defaultdict
from pathlib import Path
from typing import DefaultDict, Dict, List, Optional, Sequence, Tuple, Iterable

import numpy as np

EPS = 1e-12
DEFAULT_TOL = 1e-9
DEFAULT_COND_MAX = 1e12

Edge = Tuple[int, int]


@dataclass
class Node:
    id: int
    parent: Optional[int]
    level: int
    birth_order: int
    birth_time: int
    birth_g: float
    g: float
    children: List[int] = field(default_factory=list)


@dataclass(frozen=True)
class LiveEnvSource:
    kind: str
    source: int
    factor: float


@dataclass(frozen=True)
class LiveEnvRelationGroup:
    child: int
    sources: Tuple[LiveEnvSource, ...]


@dataclass(frozen=True)
class LiveBackreactionRelation:
    kind: str
    source_child: int
    target: int
    factor: float


@dataclass
class SchurResult:
    ok: bool
    Lambda: Optional[np.ndarray] = None
    cond_KII: float = math.nan
    solve_residual: float = math.nan
    row_sum_residual: float = math.nan
    error: str = ""


class DynamicBirthProvenanceModel:
    """v9 growth/live-backreaction core, generalized in branching for v10.

    The old v9 F1/F2 projection bases were ternary and are intentionally not
    used here.  v10 keeps only the growth, live relation rebuild, directed
    Laplacian, and Schur-response mechanisms.
    """

    def __init__(
        self,
        mode: str = "linear",
        branching: int = 3,
        base: float = 1.0,
        alpha_env: float = 0.22,
        ancestor_decay: float = 0.55,
        br_ancestor: float = 0.045,
        br_sibling: float = 0.035,
        eps: float = EPS,
        tol: float = DEFAULT_TOL,
        cond_max: float = DEFAULT_COND_MAX,
        relational_live_update: bool = True,
        live_relation_target_scale: str = "current_g",
        ancestor_kernel: str = "shell_norm_inverse_square",
    ) -> None:
        if branching < 2:
            raise ValueError("branching must be >= 2")
        if mode not in {"linear", "log", "saturating"}:
            raise ValueError("mode must be one of: linear, log, saturating")
        if live_relation_target_scale not in {"current_g", "birth_g"}:
            raise ValueError("live_relation_target_scale must be 'current_g' or 'birth_g'")
        if ancestor_kernel not in {"inverse_square", "shell_norm_inverse_square"}:
            raise ValueError("ancestor_kernel must be inverse_square or shell_norm_inverse_square")
        self.mode = mode
        self.branching = int(branching)
        self.base = float(base)
        self.alpha_env = float(alpha_env)
        self.ancestor_decay = float(ancestor_decay)
        self.br_ancestor = float(br_ancestor)
        self.br_sibling = float(br_sibling)
        self.eps = float(eps)
        self.tol = float(tol)
        self.cond_max = float(cond_max)
        self.relational_live_update = bool(relational_live_update)
        self.live_relation_target_scale = live_relation_target_scale
        self.ancestor_kernel = ancestor_kernel

        self.nodes: Dict[int, Node] = {}
        self.t = 0
        self.next_id = 0

        self.directed_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.directed_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }
        self.live_env_relation_groups: List[LiveEnvRelationGroup] = []
        self.live_backreaction_relations: List[LiveBackreactionRelation] = []
        self.relational_rebuild_count = 0

        self.sym_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.record_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.record_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "record_env_ancestor_to_child": defaultdict(float),
            "record_env_sibling_to_child": defaultdict(float),
            "record_uv_child_to_ancestor": defaultdict(float),
            "record_sibling_backreaction": defaultdict(float),
        }
        self.event_rows: List[dict] = []

        root = self._new_node(parent=None, level=0, birth_order=0, birth_g=1.0)
        self.root = root.id

    def _new_node(self, parent: Optional[int], level: int, birth_order: int, birth_g: float) -> Node:
        n = Node(
            id=self.next_id,
            parent=parent,
            level=int(level),
            birth_order=int(birth_order),
            birth_time=self.t,
            birth_g=float(birth_g),
            g=float(birth_g),
        )
        self.nodes[n.id] = n
        self.next_id += 1
        if parent is not None:
            self.nodes[parent].children.append(n.id)
        return n

    def add_directed_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.directed_edges[(u, v)] += w
        self.directed_edges_by_kind[kind][(u, v)] += w

    def add_record_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.record_edges[(u, v)] += w
        self.record_edges_by_kind[kind][(u, v)] += w

    def add_sym_edge(self, u: int, v: int, weight: float) -> None:
        w = float(weight)
        self.sym_edges[(u, v)] += w
        self.sym_edges[(v, u)] += w

    def live_target_amplitude(self, child: int) -> float:
        if self.live_relation_target_scale == "birth_g":
            return float(self.nodes[child].birth_g)
        return float(self.nodes[child].g)

    def register_live_env_group(self, child: int, sources: Sequence[LiveEnvSource]) -> None:
        self.live_env_relation_groups.append(LiveEnvRelationGroup(child=int(child), sources=tuple(sources)))

    def register_live_backreaction(self, kind: str, source_child: int, target: int, factor: float) -> None:
        self.live_backreaction_relations.append(
            LiveBackreactionRelation(kind=str(kind), source_child=int(source_child), target=int(target), factor=float(factor))
        )

    def rebuild_live_directed_edges_from_relations(self) -> None:
        new_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }
        for group in self.live_env_relation_groups:
            current_total = 0.0
            for src in group.sources:
                current_total += float(self.nodes[src.source].g) * float(src.factor)
            total = current_total + self.eps
            target_amp = self.live_target_amplitude(group.child)
            for src in group.sources:
                contrib = float(self.nodes[src.source].g) * float(src.factor)
                weight = self.alpha_env * contrib / total * target_amp
                if abs(weight) > 0.0:
                    new_by_kind[src.kind][(src.source, group.child)] += float(weight)

        for rel in self.live_backreaction_relations:
            weight = float(rel.factor) * float(self.nodes[rel.source_child].g)
            if abs(weight) > 0.0:
                new_by_kind[rel.kind][(rel.source_child, rel.target)] += float(weight)

        self.directed_edges_by_kind = new_by_kind
        self.directed_edges = defaultdict(float)
        for edge_map in self.directed_edges_by_kind.values():
            for e, w in edge_map.items():
                self.directed_edges[e] += float(w)
        self.relational_rebuild_count += 1

    def parent_line(self, parent: int) -> List[int]:
        line: List[int] = []
        cur: Optional[int] = parent
        while cur is not None:
            line.append(cur)
            cur = self.nodes[cur].parent
        return line

    def ancestor_kernel_value(self, d: int) -> float:
        # Scripts 12--21 established that the shell-normalized inverse-square
        # kernel is the controlled infinite-shell default: K(d)=1/(b^(d-1)d^2).
        if self.ancestor_kernel == "shell_norm_inverse_square":
            return 1.0 / ((self.branching ** (d - 1)) * (d * d))
        return 1.0 / (d * d)

    def birth_environment_load(self, parent: int, older_siblings: Sequence[int], current: bool = True) -> float:
        env = 0.0
        for d, a in enumerate(self.parent_line(parent), start=1):
            g = self.nodes[a].g if current else self.nodes[a].birth_g
            env += g * (self.ancestor_decay ** (d - 1))
        for s in older_siblings:
            g = self.nodes[s].g if current else self.nodes[s].birth_g
            env += g
        return float(env)

    def child_conductance_from_env(self, env_load: float) -> float:
        if self.mode == "linear":
            return self.base + self.alpha_env * env_load
        if self.mode == "log":
            return self.base + self.alpha_env * math.log1p(env_load)
        if self.mode == "saturating":
            return self.base + self.alpha_env * (env_load / (1.0 + env_load))
        raise ValueError(f"unknown mode: {self.mode}")

    def add_child(self, parent: int, order: int) -> int:
        self.t += 1
        older = list(self.nodes[parent].children)
        env_load = self.birth_environment_load(parent, older, current=True)
        birth_g = self.child_conductance_from_env(env_load)
        child = self._new_node(parent, self.nodes[parent].level + 1, order, birth_g)
        c = child.id

        self.add_sym_edge(parent, c, birth_g)

        live_sources: List[LiveEnvSource] = []
        for d, a in enumerate(self.parent_line(parent), start=1):
            live_sources.append(LiveEnvSource("env_ancestor_to_child", a, self.ancestor_decay ** (d - 1)))
        for s in older:
            live_sources.append(LiveEnvSource("env_sibling_to_child", s, 1.0))
        self.register_live_env_group(c, live_sources)

        total_env = env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].g
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_sibling_to_child", s, c, weight)

        record_env_load = self.birth_environment_load(parent, older, current=False)
        total_record_env = record_env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].birth_g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].birth_g
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_sibling_to_child", s, c, weight)

        for d, a in enumerate(self.parent_line(parent), start=1):
            kd = self.ancestor_kernel_value(d)
            delta = self.br_ancestor * birth_g * kd
            self.nodes[a].g += delta
            self.add_directed_edge("uv_child_to_ancestor", c, a, delta)
            self.register_live_backreaction("uv_child_to_ancestor", c, a, self.br_ancestor * kd)
            self.add_record_edge("record_uv_child_to_ancestor", c, a, delta)

        for s in older:
            delta = self.br_sibling * birth_g
            self.nodes[s].g += delta
            self.add_directed_edge("sibling_backreaction", c, s, delta)
            self.register_live_backreaction("sibling_backreaction", c, s, self.br_sibling)
            self.add_record_edge("record_sibling_backreaction", c, s, delta)

        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()

        children = self.nodes[parent].children
        self.event_rows.append(
            {
                "mode": self.mode,
                "t": self.t,
                "parent": parent,
                "child": c,
                "child_level": child.level,
                "child_order": order,
                "older_siblings": " ".join(map(str, older)),
                "env_load_live": env_load,
                "env_load_record": record_env_load,
                "child_birth_g": birth_g,
                "parent_g_after": self.nodes[parent].g,
                "sibling_current_g": " ".join(f"{self.nodes[x].g:.12g}" for x in children),
                "branching": self.branching,
                "parent_children_after": len(children),
                "parent_completed": int(len(children) == self.branching),
                "relational_live_update": int(self.relational_live_update),
                "live_relation_target_scale": self.live_relation_target_scale,
                "ancestor_kernel": self.ancestor_kernel,
                "live_env_relation_groups": len(self.live_env_relation_groups),
                "live_backreaction_relations": len(self.live_backreaction_relations),
                "relational_rebuild_count": self.relational_rebuild_count,
            }
        )
        return c

    def grow_level(self, frontier: Sequence[int]) -> List[int]:
        next_frontier: List[int] = []
        for p in frontier:
            for k in range(1, self.branching + 1):
                next_frontier.append(self.add_child(p, k))
        return next_frontier

    def run_growth(self, max_level: int) -> None:
        frontier = [self.root]
        for _level in range(1, max_level + 1):
            frontier = self.grow_level(frontier)
        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()

    def directed_laplacian(self, edges: Dict[Edge, float]) -> np.ndarray:
        n = self.next_id
        K = np.zeros((n, n), dtype=float)
        for (u, v), w in edges.items():
            if u == v or abs(w) <= 0.0:
                continue
            K[u, u] += w
            K[u, v] -= w
        return K

    @staticmethod
    def symmetrized_edges(edges: Dict[Edge, float]) -> DefaultDict[Edge, float]:
        out: DefaultDict[Edge, float] = defaultdict(float)
        unordered = {tuple(sorted((u, v))) for (u, v) in edges.keys() if u != v}
        for a, b in unordered:
            w = 0.5 * (edges.get((a, b), 0.0) + edges.get((b, a), 0.0))
            if abs(w) > 0.0:
                out[(a, b)] += w
                out[(b, a)] += w
        return out

    def build_live_laplacian(self) -> np.ndarray:
        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()
        return self.directed_laplacian(self.directed_edges)

    def schur_response(self, K: np.ndarray, boundary: Sequence[int], interior: Sequence[int]) -> SchurResult:
        if len(boundary) == 0:
            return SchurResult(ok=False, error="empty_boundary")
        if len(interior) == 0:
            return SchurResult(ok=False, error="empty_interior")
        if set(boundary).intersection(interior):
            return SchurResult(ok=False, error="boundary_interior_overlap")
        B = np.array(boundary, dtype=int)
        I = np.array(interior, dtype=int)
        K_BB = K[np.ix_(B, B)]
        K_BI = K[np.ix_(B, I)]
        K_IB = K[np.ix_(I, B)]
        K_II = K[np.ix_(I, I)]
        try:
            cond = float(np.linalg.cond(K_II))
            if not np.isfinite(cond) or cond > self.cond_max:
                return SchurResult(ok=False, cond_KII=cond, error="singular_or_ill_conditioned_KII")
            X = np.linalg.solve(K_II, K_IB)
            Lambda = K_BB - K_BI @ X
            solve_residual = float(np.linalg.norm(K_II @ X - K_IB, ord="fro"))
            row_sum_residual = float(np.linalg.norm(Lambda @ np.ones(len(boundary))))
            return SchurResult(True, Lambda, cond, solve_residual, row_sum_residual, "")
        except np.linalg.LinAlgError as exc:
            return SchurResult(ok=False, error=f"lin_alg_error:{exc}")

    def address_orders(self, node_id: int) -> List[int]:
        orders: List[int] = []
        cur: Optional[int] = node_id
        while cur is not None and cur != self.root:
            n = self.nodes[cur]
            orders.append(n.birth_order)
            cur = n.parent
        return list(reversed(orders))

    def word(self, node_id: int) -> str:
        orders = self.address_orders(node_id)
        return "" if not orders else ".".join(map(str, orders))

    def parent_word(self, node_id: int) -> str:
        p = self.nodes[node_id].parent
        return "" if p is None else self.word(p)

    def nodes_at_level(self, level: int) -> List[int]:
        return sorted([n.id for n in self.nodes.values() if n.level == level], key=lambda x: self.address_orders(x))

    def address_rows(self) -> List[dict]:
        rows: List[dict] = []
        for nid in sorted(self.nodes, key=lambda x: (self.nodes[x].level, self.address_orders(x))):
            n = self.nodes[nid]
            children = sorted(n.children, key=lambda c: self.nodes[c].birth_order)
            rows.append(
                {
                    "node_id": nid,
                    "level": n.level,
                    "word": self.word(nid),
                    "parent_node": "" if n.parent is None else n.parent,
                    "parent_word": self.parent_word(nid),
                    "birth_order": n.birth_order,
                    "birth_order_path": self.word(nid),
                    "child_nodes": " ".join(map(str, children)),
                    "child_words": " ".join(self.word(c) for c in children),
                    "n_children": len(children),
                    "branching": self.branching,
                    "record_flag": 1,
                    "live_flag": 1,
                    "root_relation": "root" if nid == self.root else "descendant",
                    "front_relation": "front" if len(children) == 0 else "interior",
                    "F1_label": "root_front_prefix_depth",
                    "F2_label": "birth_order_rank",
                    "birth_g": n.birth_g,
                    "live_g": n.g,
                    "birth_time": n.birth_time,
                }
            )
        return rows

    def prefix_check_rows(self, max_level: int) -> List[dict]:
        rows: List[dict] = []
        for level in range(0, max_level):
            parents = self.nodes_at_level(level)
            for p in parents:
                children = sorted(self.nodes[p].children, key=lambda c: self.nodes[c].birth_order)
                child_parent_words = [self.parent_word(c) for c in children]
                expected_parent_word = self.word(p)
                rows.append(
                    {
                        "level": level,
                        "parent_node": p,
                        "parent_word": expected_parent_word,
                        "n_children": len(children),
                        "expected_branching": self.branching,
                        "children_complete": int(len(children) == self.branching),
                        "child_words": " ".join(self.word(c) for c in children),
                        "all_children_project_to_parent": int(all(w == expected_parent_word for w in child_parent_words)),
                        "child_birth_orders": " ".join(str(self.nodes[c].birth_order) for c in children),
                        "child_orders_are_1_to_b": int([self.nodes[c].birth_order for c in children] == list(range(1, self.branching + 1))),
                    }
                )
        return rows

    def birth_order_prefix_check_rows(self) -> List[dict]:
        rows: List[dict] = []
        for nid, n in sorted(self.nodes.items(), key=lambda kv: (kv[1].level, self.address_orders(kv[0]))):
            if n.parent is None:
                continue
            child_path = self.address_orders(nid)
            parent_path = self.address_orders(n.parent)
            rows.append(
                {
                    "node_id": nid,
                    "word": self.word(nid),
                    "parent_node": n.parent,
                    "parent_word": self.word(n.parent),
                    "child_path": ".".join(map(str, child_path)),
                    "parent_path": ".".join(map(str, parent_path)),
                    "prefix_stable": int(child_path[:-1] == parent_path),
                    "last_birth_order": child_path[-1] if child_path else "",
                    "node_birth_order": n.birth_order,
                }
            )
        return rows


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: List[str] = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                keys.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def safe_float(x: object, default: float = math.nan) -> float:
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def mean_zero_basis(n: int) -> np.ndarray:
    """Return Q with Q.T @ 1=0 and Q.T @ Q=I, shape n x (n-1)."""
    if n <= 1:
        return np.zeros((n, 0), dtype=float)
    M = np.zeros((n, n - 1), dtype=float)
    for j in range(n - 1):
        M[j, j] = 1.0
        M[n - 1, j] = -1.0
    Q, _ = np.linalg.qr(M, mode="reduced")
    return Q


def S_response_energy_and_current(
    model: DynamicBirthProvenanceModel,
    K: np.ndarray,
    node_id: int,
) -> dict:
    """Compute S-response energy and separate current for one internal node.

    The local shell is rootward+frontward:
      root:      boundary=children, interior=[root]
      non-root:  boundary=[parent]+children, interior=[node]

    Leaves do not have children in the finite approximant and return invalid.
    """
    n = model.nodes[node_id]
    children = sorted(n.children, key=lambda c: model.nodes[c].birth_order)
    if len(children) != model.branching:
        return {
            "valid_response": 0,
            "response_error": "node_has_no_complete_child_shell",
            "n_boundary": 0,
            "energy_positive": math.nan,
            "psd_defect": math.nan,
            "zero_energy_degenerate": 1,
            "J_signed": math.nan,
            "J_abs": math.nan,
            "rel_skew": math.nan,
        }
    if n.parent is None:
        boundary = list(children)
        child_start = 0
        has_rootward = 0
    else:
        boundary = [n.parent] + list(children)
        child_start = 1
        has_rootward = 1
    interior = [node_id]
    res = model.schur_response(K, boundary=boundary, interior=interior)
    if not res.ok or res.Lambda is None:
        return {
            "valid_response": 0,
            "response_error": res.error,
            "cond_KII": res.cond_KII,
            "solve_residual": res.solve_residual,
            "row_sum_residual": res.row_sum_residual,
            "n_boundary": len(boundary),
            "boundary_nodes": " ".join(map(str, boundary)),
            "interior_nodes": str(node_id),
            "energy_positive": math.nan,
            "psd_defect": math.nan,
            "zero_energy_degenerate": 1,
            "J_signed": math.nan,
            "J_abs": math.nan,
            "rel_skew": math.nan,
        }
    Lambda = res.Lambda
    S = 0.5 * (Lambda + Lambda.T)
    A = 0.5 * (Lambda - Lambda.T)
    Q = mean_zero_basis(S.shape[0])
    if Q.shape[1] == 0:
        eigs = np.array([], dtype=float)
    else:
        S_perp = Q.T @ S @ Q
        eigs = np.linalg.eigvalsh(S_perp)
    energy_positive = float(np.sum(np.maximum(eigs, 0.0)))
    psd_defect = float(np.sum(np.maximum(-eigs, 0.0)))
    zero_energy_degenerate = int(energy_positive <= model.tol)

    # Separate signed current.  This is intentionally not used for μ.
    # For non-root shells, rank-weight the rootward-child skew entries by birth order.
    # For root shell, use the cyclic sibling current as a fallback.
    centered = np.array([k - (model.branching + 1) / 2.0 for k in range(1, model.branching + 1)], dtype=float)
    if has_rootward:
        root_child_entries = np.array([A[0, child_start + i] for i in range(model.branching)], dtype=float)
        J_signed = float(np.dot(centered, root_child_entries))
        reverse_centered = -centered
        J_reversed = float(np.dot(reverse_centered, root_child_entries))
    else:
        J_signed = 0.0
        for i in range(model.branching):
            j = (i + 1) % model.branching
            J_signed += float(A[child_start + i, child_start + j])
        J_reversed = -J_signed
    A_norm = float(np.linalg.norm(A, ord="fro"))
    L_norm = float(np.linalg.norm(Lambda, ord="fro"))
    return {
        "valid_response": 1,
        "response_error": "",
        "cond_KII": res.cond_KII,
        "solve_residual": res.solve_residual,
        "row_sum_residual": res.row_sum_residual,
        "n_boundary": len(boundary),
        "boundary_nodes": " ".join(map(str, boundary)),
        "interior_nodes": str(node_id),
        "mean_zero_dim": int(Q.shape[1]),
        "S_perp_eigs": " ".join(f"{x:.12g}" for x in eigs),
        "energy_positive": energy_positive,
        "psd_defect": psd_defect,
        "psd_defect_rel": float(psd_defect / max(energy_positive + psd_defect, EPS)),
        "zero_energy_degenerate": zero_energy_degenerate,
        "J_signed": J_signed,
        "J_reversed_rank_signed": J_reversed,
        "kappa_reversal_flips_sign": int(np.sign(J_signed) == -np.sign(J_reversed) and abs(J_signed) > model.tol),
        "J_abs": abs(J_signed),
        "A_fro": A_norm,
        "S_fro": float(np.linalg.norm(S, ord="fro")),
        "Lambda_fro": L_norm,
        "rel_skew": float(A_norm / max(L_norm, EPS)),
    }


def normalize_level(rows: List[dict], raw_key: str, out_key: str = "mu") -> None:
    by_level: DefaultDict[int, List[dict]] = defaultdict(list)
    for r in rows:
        by_level[int(r["level"])].append(r)
    for level, level_rows in by_level.items():
        vals = [max(0.0, safe_float(r.get(raw_key), 0.0)) for r in level_rows]
        total = float(sum(vals))
        for r, v in zip(level_rows, vals):
            r["raw_value_nonnegative"] = v
            r["level_raw_total"] = total
            if total > EPS:
                r[out_key] = v / total
                r["measure_valid_on_level"] = 1
            else:
                r[out_key] = math.nan
                r["measure_valid_on_level"] = 0


def make_count_measure_rows(model: DynamicBirthProvenanceModel, max_level: int) -> List[dict]:
    rows: List[dict] = []
    for level in range(0, max_level + 1):
        nodes = model.nodes_at_level(level)
        m = len(nodes)
        for nid in nodes:
            rows.append(
                {
                    "mode": model.mode,
                    "candidate": "count",
                    "level": level,
                    "node_id": nid,
                    "word": model.word(nid),
                    "parent_word": model.parent_word(nid),
                    "raw_value": 1.0,
                    "mu": 1.0 / max(m, 1),
                    "formula": "uniform cylinder carrier on dynamic provenance boundary",
                    "measure_valid_on_level": 1,
                }
            )
    return rows


def make_conductance_measure_rows(model: DynamicBirthProvenanceModel, max_level: int, kind: str) -> List[dict]:
    if kind not in {"g_live", "g_birth"}:
        raise ValueError(kind)
    rows: List[dict] = []
    for level in range(0, max_level + 1):
        for nid in model.nodes_at_level(level):
            n = model.nodes[nid]
            raw = n.g if kind == "g_live" else n.birth_g
            rows.append(
                {
                    "mode": model.mode,
                    "candidate": kind,
                    "level": level,
                    "node_id": nid,
                    "word": model.word(nid),
                    "parent_word": model.parent_word(nid),
                    "raw_value": raw,
                    "source": "live_g" if kind == "g_live" else "birth_g",
                }
            )
    normalize_level(rows, "raw_value")
    return rows


def make_energy_measure_rows(model: DynamicBirthProvenanceModel, max_level: int) -> Tuple[List[dict], List[dict], List[dict]]:
    K_live = model.build_live_laplacian()
    rows: List[dict] = []
    psd_rows: List[dict] = []
    current_rows: List[dict] = []
    # S-response needs a complete child shell, therefore levels 0..max_level-1 only.
    for level in range(0, max_level):
        for nid in model.nodes_at_level(level):
            metrics = S_response_energy_and_current(model, K_live, nid)
            base = {
                "mode": model.mode,
                "candidate": "energy_S_response",
                "level": level,
                "node_id": nid,
                "word": model.word(nid),
                "parent_word": model.parent_word(nid),
                "raw_value": metrics.get("energy_positive", math.nan),
                "formula": "sum positive eigs of Q^T S Q; A/current excluded from μ",
                "valid_response": metrics.get("valid_response", 0),
                "response_error": metrics.get("response_error", ""),
            }
            row = dict(base)
            row.update(metrics)
            rows.append(row)
            psd_rows.append(
                {
                    "mode": model.mode,
                    "level": level,
                    "node_id": nid,
                    "word": model.word(nid),
                    "valid_response": metrics.get("valid_response", 0),
                    "energy_positive": metrics.get("energy_positive", math.nan),
                    "psd_defect": metrics.get("psd_defect", math.nan),
                    "psd_defect_rel": metrics.get("psd_defect_rel", math.nan),
                    "zero_energy_degenerate": metrics.get("zero_energy_degenerate", 1),
                    "mean_zero_dim": metrics.get("mean_zero_dim", math.nan),
                    "S_perp_eigs": metrics.get("S_perp_eigs", ""),
                }
            )
            current_rows.append(
                {
                    "mode": model.mode,
                    "level": level,
                    "node_id": nid,
                    "word": model.word(nid),
                    "valid_response": metrics.get("valid_response", 0),
                    "J_signed": metrics.get("J_signed", math.nan),
                    "J_abs": metrics.get("J_abs", math.nan),
                    "J_reversed_rank_signed": metrics.get("J_reversed_rank_signed", math.nan),
                    "kappa_reversal_flips_sign": metrics.get("kappa_reversal_flips_sign", 0),
                    "A_fro": metrics.get("A_fro", math.nan),
                    "S_fro": metrics.get("S_fro", math.nan),
                    "Lambda_fro": metrics.get("Lambda_fro", math.nan),
                    "rel_skew": metrics.get("rel_skew", math.nan),
                }
            )
    # Invalid local responses are not allowed to create carrier mass.
    for r in rows:
        if int(r.get("valid_response", 0)) != 1 or not math.isfinite(safe_float(r.get("raw_value"))):
            r["raw_value"] = 0.0
    normalize_level(rows, "raw_value")
    mu_by_key = {(r["level"], r["word"]): safe_float(r.get("mu")) for r in rows}
    for cr in current_rows:
        mu = mu_by_key.get((cr["level"], cr["word"]), math.nan)
        J = safe_float(cr.get("J_signed"))
        cr["mu_E"] = mu
        cr["J_over_mu_eps"] = float(J / (mu + EPS)) if math.isfinite(mu) and math.isfinite(J) else math.nan
    return rows, psd_rows, current_rows


def word_is_descendant_or_equal(desc_word: str, anc_word: str) -> bool:
    if anc_word == "":
        return True
    return desc_word == anc_word or desc_word.startswith(anc_word + ".")


def make_terminal_pushforward_measure_rows(
    model: DynamicBirthProvenanceModel,
    source_rows: Sequence[dict],
    source_level: Optional[int] = None,
    candidate: str = "energy_S_response_terminal_pushforward",
) -> List[dict]:
    """Build a cylinder carrier by pushing deepest local density forward.

    This corrects the v10.0 category error: a local shell/event density is not
    itself a cylinder measure.  For a finite terminal source level M, define

        raw_L(w) = sum_{|v|=M, v extends w} raw_M(v).

    This is exactly projective inside the finite approximant.  Limes content is
    then tested by comparing terminal-source levels / max-level runs, not by
    asking local node density to be additive by itself.
    """
    valid_source = [
        r for r in source_rows
        if int(r.get("valid_response", 0)) == 1
        and math.isfinite(safe_float(r.get("raw_value")))
        and safe_float(r.get("raw_value"), 0.0) > 0.0
    ]
    if not valid_source:
        return []
    if source_level is None:
        source_level = max(int(r["level"]) for r in valid_source)
    source = [r for r in valid_source if int(r["level"]) == int(source_level)]
    if not source:
        return []
    source_words = [(str(r["word"]), max(0.0, safe_float(r.get("raw_value"), 0.0))) for r in source]
    rows: List[dict] = []
    for level in range(0, int(source_level) + 1):
        vals: List[Tuple[int, str, float]] = []
        for nid in model.nodes_at_level(level):
            w = model.word(nid)
            raw = sum(v for sw, v in source_words if word_is_descendant_or_equal(sw, w))
            vals.append((nid, w, raw))
        total = float(sum(v for _, _, v in vals))
        for nid, w, raw in vals:
            rows.append({
                "mode": model.mode,
                "candidate": candidate,
                "level": level,
                "node_id": nid,
                "word": w,
                "parent_word": model.parent_word(nid),
                "raw_value": raw,
                "source_level": int(source_level),
                "source_candidate": "energy_S_response_local_density",
                "formula": "prefix pushforward of terminal S-response density; A/current excluded from mu",
                "mu": raw / total if total > EPS else math.nan,
                "measure_valid_on_level": 1 if total > EPS else 0,
            })
    return rows


def make_source_ladder_pushforward_rows(
    model: DynamicBirthProvenanceModel,
    source_rows: Sequence[dict],
    min_source_level: int = 1,
    candidate: str = "energy_S_response_source_ladder_pushforward",
) -> List[dict]:
    out: List[dict] = []
    levels = sorted({int(r["level"]) for r in source_rows if int(r.get("valid_response", 0)) == 1})
    for src in levels:
        if src < min_source_level:
            continue
        rows = make_terminal_pushforward_measure_rows(model, source_rows, source_level=src, candidate=candidate)
        for r in rows:
            out.append(r)
    return out


def pushforward_ladder_stability_rows(ladder_rows: Sequence[dict]) -> List[dict]:
    """Compare μ^{M} and μ^{M+1} on common prefix levels."""
    by_source: DefaultDict[int, List[dict]] = defaultdict(list)
    for r in ladder_rows:
        by_source[int(r.get("source_level", -1))].append(r)
    out: List[dict] = []
    sources = sorted(s for s in by_source if s >= 0)
    for a, b in zip(sources, sources[1:]):
        A = rows_by_level_word(by_source[a])
        B = rows_by_level_word(by_source[b])
        common_levels = sorted({l for l, _ in A}.intersection({l for l, _ in B}))
        for level in common_levels:
            words = sorted({w for l, w in A if l == level}.intersection({w for l, w in B if l == level}))
            tv = 0.0
            for w in words:
                tv += abs(safe_float(A[(level, w)].get("mu"), 0.0) - safe_float(B[(level, w)].get("mu"), 0.0))
            out.append({
                "mode": by_source[a][0].get("mode", "") if by_source[a] else "",
                "candidate": "energy_S_response_source_ladder_pushforward",
                "source_left": a,
                "source_right": b,
                "level": level,
                "d_TV": 0.5 * tv,
                "n_common_words": len(words),
            })
    return out


def rows_by_level_word(rows: Sequence[dict]) -> Dict[Tuple[int, str], dict]:
    return {(int(r["level"]), str(r["word"])): r for r in rows}


def projective_defect_rows(model: DynamicBirthProvenanceModel, rows: Sequence[dict], candidate: str) -> List[dict]:
    table = rows_by_level_word(rows)
    levels = sorted({int(r["level"]) for r in rows})
    out: List[dict] = []
    for level in levels:
        if level + 1 not in levels:
            continue
        defect = 0.0
        valid_terms = 0
        invalid_terms = 0
        max_parent_abs = 0.0
        for nid in model.nodes_at_level(level):
            w = model.word(nid)
            parent_row = table.get((level, w))
            if parent_row is None or int(parent_row.get("measure_valid_on_level", 0)) != 1:
                invalid_terms += 1
                continue
            parent_mu = safe_float(parent_row.get("mu"))
            child_sum = 0.0
            child_valid = True
            for c in sorted(model.nodes[nid].children, key=lambda x: model.nodes[x].birth_order):
                cw = model.word(c)
                cr = table.get((level + 1, cw))
                if cr is None or int(cr.get("measure_valid_on_level", 0)) != 1:
                    child_valid = False
                    break
                child_sum += safe_float(cr.get("mu"), 0.0)
            if not child_valid:
                invalid_terms += 1
                continue
            term = abs(parent_mu - child_sum)
            defect += term
            max_parent_abs = max(max_parent_abs, term)
            valid_terms += 1
        out.append(
            {
                "mode": rows[0].get("mode", "") if rows else "",
                "candidate": candidate,
                "level": level,
                "projective_defect": defect,
                "valid_parent_terms": valid_terms,
                "invalid_parent_terms": invalid_terms,
                "max_parent_defect": max_parent_abs,
            }
        )
    return out


def rate_fit_rows(defect_rows: Sequence[dict], candidate: str, mode: str, tail_window: int = 4) -> List[dict]:
    vals = [(int(r["level"]), safe_float(r.get("projective_defect"))) for r in defect_rows]
    vals = [(l, d) for l, d in vals if math.isfinite(d)]
    if not vals:
        return [{"mode": mode, "candidate": candidate, "verdict": "insufficient_depth"}]
    levels = np.array([l for l, _ in vals], dtype=float)
    deltas = np.array([max(d, EPS) for _, d in vals], dtype=float)
    rho = []
    for i in range(len(deltas) - 1):
        rho.append(float(deltas[i + 1] / max(deltas[i], EPS)))
    tw = min(tail_window, max(1, len(deltas)))
    tail_levels = levels[-tw:]
    tail_logs = np.log(deltas[-tw:])
    if len(tail_levels) >= 2 and np.std(tail_levels) > 0:
        slope, intercept = np.polyfit(tail_levels, tail_logs, 1)
        pred = slope * tail_levels + intercept
        ss_res = float(np.sum((tail_logs - pred) ** 2))
        ss_tot = float(np.sum((tail_logs - np.mean(tail_logs)) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > EPS else 1.0
    else:
        slope = math.nan
        r2 = math.nan
    median_rho_tail = float(np.median(rho[-max(1, min(len(rho), tail_window - 1)):])) if rho else math.nan
    if len(vals) < 2:
        verdict = "insufficient_depth"
    elif deltas[0] <= 10 * EPS and deltas[-1] <= 10 * EPS:
        verdict = "exact_control"
    elif math.isfinite(median_rho_tail) and math.isfinite(slope) and median_rho_tail < 0.85 and slope < -0.05 and (not math.isfinite(r2) or r2 >= 0.50):
        verdict = "rate_candidate_strong"
    elif math.isfinite(median_rho_tail) and math.isfinite(slope) and median_rho_tail < 1.0 and slope < 0.0:
        verdict = "rate_candidate_weak"
    elif len(deltas) >= 2 and deltas[-1] > 1.25 * deltas[0]:
        verdict = "unstable"
    else:
        verdict = "no_rate"
    return [
        {
            "mode": mode,
            "candidate": candidate,
            "delta_first": float(deltas[0]),
            "delta_last": float(deltas[-1]),
            "rho_values": " ".join(f"{x:.12g}" for x in rho),
            "median_rho_tail": median_rho_tail,
            "log_delta_slope": float(slope),
            "log_delta_fit_R2": float(r2),
            "tail_window_used": int(tw),
            "n_defect_levels": len(vals),
            "verdict": verdict,
        }
    ]


def tv_distance_rows(rows_a: Sequence[dict], rows_b: Sequence[dict], label_a: str, label_b: str) -> List[dict]:
    A = rows_by_level_word(rows_a)
    B = rows_by_level_word(rows_b)
    levels = sorted({l for l, _ in A.keys()}.intersection({l for l, _ in B.keys()}))
    out: List[dict] = []
    for level in levels:
        words = sorted({w for l, w in A.keys() if l == level}.intersection({w for l, w in B.keys() if l == level}))
        tv = 0.0
        missing = 0
        for w in words:
            a = safe_float(A[(level, w)].get("mu"))
            b = safe_float(B[(level, w)].get("mu"))
            if not math.isfinite(a) or not math.isfinite(b):
                missing += 1
                continue
            tv += abs(a - b)
        out.append(
            {
                "level": level,
                "left": label_a,
                "right": label_b,
                "d_TV": 0.5 * tv,
                "n_common_words": len(words),
                "missing_or_invalid_terms": missing,
            }
        )
    return out


def classify_nontriviality(tv_rows: Sequence[dict], rate_verdict: str, zero_tol: float, nontrivial_tol: float) -> dict:
    tvs = [safe_float(r.get("d_TV")) for r in tv_rows]
    tvs = [x for x in tvs if math.isfinite(x)]
    if rate_verdict not in {"exact_control", "rate_candidate_strong", "rate_candidate_weak"}:
        return {"M2c_class": "unstable", "M2c_verdict": "dynamic_carrier_unstable", "tv_tail_median": math.nan, "tv_last": math.nan}
    if not tvs:
        return {"M2c_class": "ambiguous", "M2c_verdict": "finite_diagnostic_only", "tv_tail_median": math.nan, "tv_last": math.nan}
    tail = tvs[-min(4, len(tvs)):]
    tail_median = float(np.median(tail))
    last = float(tvs[-1])
    first = float(tvs[0])
    if tail_median <= zero_tol or (last <= zero_tol and last <= 0.5 * max(first, EPS)):
        verdict = "uniform_carrier_on_dynamic_provenance"
        cls = "uniform"
    elif tail_median >= nontrivial_tol and last >= zero_tol:
        verdict = "dynamic_nontrivial_carrier_candidate"
        cls = "nontrivial"
    else:
        verdict = "finite_diagnostic_only"
        cls = "ambiguous"
    return {"M2c_class": cls, "M2c_verdict": verdict, "tv_tail_median": tail_median, "tv_last": last, "tv_first": first}


def summarize_current(current_rows: Sequence[dict], tol: float) -> List[dict]:
    by_level: DefaultDict[int, List[dict]] = defaultdict(list)
    for r in current_rows:
        if int(r.get("valid_response", 0)) == 1:
            by_level[int(r["level"])].append(r)
    out: List[dict] = []
    for level in sorted(by_level):
        rows = by_level[level]
        Js = np.array([safe_float(r.get("J_signed"), 0.0) for r in rows], dtype=float)
        Aabs = np.array([safe_float(r.get("A_fro"), 0.0) for r in rows], dtype=float)
        rel = np.array([safe_float(r.get("rel_skew"), 0.0) for r in rows], dtype=float)
        flips = np.array([int(r.get("kappa_reversal_flips_sign", 0)) for r in rows], dtype=int)
        nonzero = np.abs(Js) > tol
        out.append(
            {
                "mode": rows[0].get("mode", ""),
                "level": level,
                "n_valid_current_rows": len(rows),
                "J_nonzero_fraction": float(np.mean(nonzero)) if len(rows) else math.nan,
                "J_signed_mean": float(np.mean(Js)) if len(rows) else math.nan,
                "J_abs_mean": float(np.mean(np.abs(Js))) if len(rows) else math.nan,
                "A_fro_mean": float(np.mean(Aabs)) if len(rows) else math.nan,
                "rel_skew_mean": float(np.mean(rel)) if len(rows) else math.nan,
                "kappa_reversal_flip_fraction": float(np.mean(flips)) if len(rows) else math.nan,
                "J_positive_fraction": float(np.mean(Js > tol)) if len(rows) else math.nan,
                "J_negative_fraction": float(np.mean(Js < -tol)) if len(rows) else math.nan,
            }
        )
    return out


def classify_current(current_summary: Sequence[dict], tol: float) -> dict:
    if not current_summary:
        return {"M4_verdict": "no_stable_current", "current_tail_abs_mean": math.nan, "current_tail_nonzero_fraction": math.nan}
    tail = list(current_summary)[-min(4, len(current_summary)):]
    abs_mean = float(np.median([safe_float(r.get("J_abs_mean"), 0.0) for r in tail]))
    nz_frac = float(np.median([safe_float(r.get("J_nonzero_fraction"), 0.0) for r in tail]))
    flip_frac = float(np.median([safe_float(r.get("kappa_reversal_flip_fraction"), 0.0) for r in tail]))
    rel_skew = float(np.median([safe_float(r.get("rel_skew_mean"), 0.0) for r in tail]))
    if abs_mean > 10 * tol and nz_frac > 0.5 and flip_frac > 0.5:
        verdict = "stable_dynamic_current"
    elif abs_mean > tol and nz_frac > 0.1:
        verdict = "weak_current"
    else:
        verdict = "no_stable_current"
    return {
        "M4_verdict": verdict,
        "current_tail_abs_mean": abs_mean,
        "current_tail_nonzero_fraction": nz_frac,
        "current_tail_kappa_flip_fraction": flip_frac,
        "current_tail_rel_skew_mean": rel_skew,
    }


def conditional_mode_universality(
    energy_rows_by_mode: Dict[str, List[dict]],
    outdir: Path,
    tv_small_tol: float,
) -> Tuple[List[dict], dict]:
    modes = sorted(energy_rows_by_mode)
    all_rows: List[dict] = []
    pair_tails: List[float] = []
    for i in range(len(modes)):
        for j in range(i + 1, len(modes)):
            a, b = modes[i], modes[j]
            rows = tv_distance_rows(energy_rows_by_mode[a], energy_rows_by_mode[b], f"energy_S_response_terminal_pushforward_{a}", f"energy_S_response_terminal_pushforward_{b}")
            for r in rows:
                r["candidate"] = "energy_S_response_terminal_pushforward"
                r["mode_pair"] = f"{a}_vs_{b}"
            all_rows.extend(rows)
            vals = [safe_float(r.get("d_TV")) for r in rows]
            vals = [x for x in vals if math.isfinite(x)]
            if vals:
                pair_tails.append(float(np.median(vals[-min(4, len(vals)):])) )
    tail_max = max(pair_tails) if pair_tails else math.nan
    if not pair_tails:
        verdict = "insufficient_mode_pairs"
    elif tail_max <= tv_small_tol:
        verdict = "mode_distance_small"
    else:
        verdict = "mode_distance_large"
    return all_rows, {"M3_raw_verdict": verdict, "cross_mode_tail_max": tail_max, "n_mode_pairs": len(pair_tails)}


def combine_final_verdict(
    prefix_ok: bool,
    positive_energy_status: str,
    m2c_classes: Dict[str, dict],
    m3: dict,
    m4_by_mode: Dict[str, dict],
) -> dict:
    if not prefix_ok:
        return {"final_verdict": "control_failed", "reason": "prefix/count-control failed"}
    if positive_energy_status == "positive_energy_invalid":
        return {"final_verdict": "positive_energy_invalid", "reason": "S-response PSD defect too large or energy carrier invalid"}

    classes = [v.get("M2c_class") for v in m2c_classes.values()]
    current_verdicts = [v.get("M4_verdict") for v in m4_by_mode.values()]
    any_current = any(v in {"stable_dynamic_current", "weak_current"} for v in current_verdicts)
    all_uniform = bool(classes) and all(c == "uniform" for c in classes)
    all_nontrivial = bool(classes) and all(c == "nontrivial" for c in classes)
    any_unstable = any(c == "unstable" for c in classes)
    mode_small = m3.get("M3_raw_verdict") == "mode_distance_small"

    if all_uniform:
        if any_current:
            return {
                "final_verdict": "uniform_carrier_with_nontrivial_dynamic_current",
                "conditional_M3": "uniform_carrier_mode_collapse" if mode_small else "uniform_carrier_mode_variation",
                "reason": "positive carrier collapses to uniform/count on dynamic provenance; separate current survives",
            }
        return {
            "final_verdict": "uniform_carrier_on_dynamic_provenance",
            "conditional_M3": "uniform_carrier_mode_collapse" if mode_small else "uniform_carrier_mode_variation",
            "reason": "positive carrier collapses to uniform/count on dynamic provenance",
        }
    if all_nontrivial:
        if mode_small:
            return {
                "final_verdict": "dynamic_nontrivial_mode_universal_carrier",
                "conditional_M3": "dynamic_nontrivial_mode_universal_carrier",
                "reason": "nontrivial positive carrier appears projectively stable and mode-close",
            }
        return {
            "final_verdict": "dynamic_nontrivial_mode_dependent_carrier",
            "conditional_M3": "dynamic_nontrivial_mode_dependent_carrier",
            "reason": "nontrivial positive carrier appears but mode distances are not small",
        }
    if any_unstable:
        return {
            "final_verdict": "dynamic_carrier_unstable",
            "conditional_M3": "mode_similarity_without_measure" if mode_small else "finite_diagnostic_only",
            "reason": "one or more modes lack projective carrier stability",
        }
    return {"final_verdict": "finite_diagnostic_only", "reason": "mixed/ambiguous M2c classes"}


def run_one_mode(args: argparse.Namespace, mode: str, outdir: Path) -> dict:
    model = DynamicBirthProvenanceModel(
        mode=mode,
        branching=args.branching,
        base=args.base,
        alpha_env=args.alpha_env,
        ancestor_decay=args.ancestor_decay,
        br_ancestor=args.br_ancestor,
        br_sibling=args.br_sibling,
        eps=args.eps,
        tol=args.tol,
        cond_max=args.cond_max,
        relational_live_update=not args.no_relational_live_update,
        live_relation_target_scale=args.live_relation_target_scale,
        ancestor_kernel=args.ancestor_kernel,
    )
    model.run_growth(args.max_level)

    # Address / prefix controls.
    address_rows = model.address_rows()
    prefix_rows = model.prefix_check_rows(args.max_level)
    birth_prefix_rows = model.birth_order_prefix_check_rows()
    write_csv(outdir / f"address_tree_levels_{mode}.csv", address_rows)
    write_csv(outdir / f"prefix_projection_checks_{mode}.csv", prefix_rows)
    write_csv(outdir / f"birth_order_prefix_checks_{mode}.csv", birth_prefix_rows)
    write_csv(outdir / f"events_{mode}.csv", model.event_rows)

    count_rows = make_count_measure_rows(model, args.max_level)
    g_live_rows = make_conductance_measure_rows(model, args.max_level, "g_live")
    g_birth_rows = make_conductance_measure_rows(model, args.max_level, "g_birth")
    energy_rows, psd_rows, current_rows = make_energy_measure_rows(model, args.max_level)
    energy_push_rows = make_terminal_pushforward_measure_rows(model, energy_rows)
    energy_ladder_rows = make_source_ladder_pushforward_rows(model, energy_rows)
    ladder_stability_rows = pushforward_ladder_stability_rows(energy_ladder_rows)

    write_csv(outdir / f"measure_candidates_count_{mode}.csv", count_rows)
    write_csv(outdir / f"measure_candidates_g_live_{mode}.csv", g_live_rows)
    write_csv(outdir / f"measure_candidates_g_birth_{mode}.csv", g_birth_rows)
    write_csv(outdir / f"measure_candidates_energy_S_response_local_density_{mode}.csv", energy_rows)
    write_csv(outdir / f"measure_candidates_energy_S_response_terminal_pushforward_{mode}.csv", energy_push_rows)
    write_csv(outdir / f"measure_candidates_energy_S_response_source_ladder_pushforward_{mode}.csv", energy_ladder_rows)
    write_csv(outdir / f"measure_pushforward_source_ladder_stability_{mode}.csv", ladder_stability_rows)
    write_csv(outdir / f"S_response_psd_defects_{mode}.csv", psd_rows)
    write_csv(outdir / f"orientation_current_over_carrier_{mode}.csv", current_rows)

    # Projective defects / rate fits for all measure candidates.
    candidate_rows = {
        "count": count_rows,
        "g_live": g_live_rows,
        "g_birth": g_birth_rows,
        "energy_S_response_local_density": energy_rows,
        "energy_S_response_terminal_pushforward": energy_push_rows,
    }
    defects_all: List[dict] = []
    rates_all: List[dict] = []
    for cand, rows in candidate_rows.items():
        drows = projective_defect_rows(model, rows, cand)
        defects_all.extend(drows)
        rates_all.extend(rate_fit_rows(drows, cand, mode, tail_window=args.tail_window))
        write_csv(outdir / f"measure_projective_defects_{cand}_{mode}.csv", drows)
        write_csv(outdir / f"measure_rate_fits_{cand}_{mode}.csv", rate_fit_rows(drows, cand, mode, tail_window=args.tail_window))

    # M2c primary carrier vs count.  The local density is audited separately;
    # the cylinder measure candidate is the terminal-shell prefix pushforward.
    tv_energy_count = tv_distance_rows(energy_push_rows, count_rows, "energy_S_response_terminal_pushforward", "count")
    write_csv(outdir / f"measure_nontriviality_vs_count_energy_S_response_terminal_pushforward_{mode}.csv", tv_energy_count)
    local_energy_rate = next((r for r in rates_all if r.get("candidate") == "energy_S_response_local_density"), {})
    energy_rate = next((r for r in rates_all if r.get("candidate") == "energy_S_response_terminal_pushforward"), {})
    m2c = classify_nontriviality(
        tv_energy_count,
        str(energy_rate.get("verdict", "insufficient_depth")),
        zero_tol=args.tv_zero_tol,
        nontrivial_tol=args.tv_nontrivial_tol,
    )
    m2c["local_density_rate_verdict"] = local_energy_rate.get("verdict", "insufficient_depth")
    m2c["local_density_not_measure"] = 1

    # M1 status.
    invalid_norm = (not energy_push_rows) or any(int(r.get("measure_valid_on_level", 1)) != 1 for r in energy_push_rows)
    psd_rels = [safe_float(r.get("psd_defect_rel")) for r in psd_rows if int(r.get("valid_response", 0)) == 1]
    psd_tail = float(np.median(psd_rels[-min(len(psd_rels), args.tail_window):])) if psd_rels else math.nan
    if invalid_norm:
        m1 = "normalization_failed"
    elif math.isfinite(psd_tail) and psd_tail > args.psd_rel_warning:
        m1 = "positive_with_psd_warning"
    else:
        m1 = "positive_valid"
    if math.isfinite(psd_tail) and psd_tail > args.psd_rel_invalid:
        m1 = "positive_energy_invalid"

    current_summary = summarize_current(current_rows, tol=args.current_tol)
    write_csv(outdir / f"v10_gate_M4_current_over_carrier_{mode}.csv", current_summary)
    m4 = classify_current(current_summary, tol=args.current_tol)

    prefix_ok = all(int(r.get("children_complete", 0)) == 1 and int(r.get("all_children_project_to_parent", 0)) == 1 and int(r.get("child_orders_are_1_to_b", 0)) == 1 for r in prefix_rows)
    count_rate = next((r for r in rates_all if r.get("candidate") == "count"), {})
    count_control_exact = str(count_rate.get("verdict", "")) == "exact_control"
    if not count_control_exact:
        # Count should be exactly projective.  This catches address/normalization defects.
        prefix_ok = False

    gate_rows = [
        {"mode": mode, "gate": "P0_prefix", "status": "prefix_system_valid" if prefix_ok else "prefix_system_invalid"},
        {"mode": mode, "gate": "M1_positive_carrier", "status": m1, "psd_tail_rel": psd_tail},
        {"mode": mode, "gate": "M2a_count_control", "status": "count_control_exact" if count_control_exact else "count_control_failed"},
        {"mode": mode, "gate": "M2b_primary_pushforward_rate", "status": energy_rate.get("verdict", "insufficient_depth")},
        {"mode": mode, "gate": "M2b_local_density_audit", "status": local_energy_rate.get("verdict", "insufficient_depth"), "interpretation": "local event density is not a cylinder measure"},
        {"mode": mode, "gate": "M2c_nontriviality", **m2c},
        {"mode": mode, "gate": "M4_current", **m4},
    ]
    write_csv(outdir / f"v10_gate_M1_M2_M4_{mode}.csv", gate_rows)

    return {
        "mode": mode,
        "model": model,
        "prefix_ok": prefix_ok,
        "address_rows": address_rows,
        "prefix_rows": prefix_rows,
        "birth_prefix_rows": birth_prefix_rows,
        "m1_status": m1,
        "count_control_exact": count_control_exact,
        "count_rows": count_rows,
        "g_live_rows": g_live_rows,
        "g_birth_rows": g_birth_rows,
        "energy_rows": energy_rows,
        "energy_push_rows": energy_push_rows,
        "energy_ladder_rows": energy_ladder_rows,
        "ladder_stability_rows": ladder_stability_rows,
        "psd_rows": psd_rows,
        "current_rows": current_rows,
        "current_summary": current_summary,
        "defects_all": defects_all,
        "rates_all": rates_all,
        "m2c": m2c,
        "m4": m4,
        "n_nodes": len(model.nodes),
        "n_events": len(model.event_rows),
    }


def render_summary(args: argparse.Namespace, mode_results: Dict[str, dict], m3: dict, final: dict) -> str:
    lines: List[str] = []
    lines.append("# SUMMARY v10.2 — Projective Provenance Carrier Test")
    lines.append("")
    lines.append("Status: deterministic finite diagnostic; not a geometry/AQFT/spectral claim.")
    lines.append("")
    lines.append("## Guardrails")
    lines.append("- Target object: asymmetric dynamic provenance boundary, not the strict symmetric tree.")
    lines.append("- Uniform/count carrier is a neutral cylinder carrier on the dynamic boundary.")
    lines.append("- Local S-response density uses only Q^T S Q; the cylinder carrier is its terminal-shell prefix pushforward. A/omega/J are never used to define μ.")
    lines.append("- M3 mode-universality is conditional on M2c nontriviality-vs-count.")
    lines.append("- v10.1 does not compute spectral dimension, Laplacian geometry, AQFT algebras, or disk embeddings.")
    lines.append("")
    lines.append("## Run parameters")
    lines.append(f"- branching b = {args.branching}")
    lines.append(f"- max_level = {args.max_level}")
    lines.append(f"- modes = {', '.join(args.modes)}")
    lines.append(f"- alpha_env = {args.alpha_env}")
    lines.append(f"- ancestor_decay = {args.ancestor_decay}")
    lines.append(f"- br_ancestor = {args.br_ancestor}")
    lines.append(f"- br_sibling = {args.br_sibling}")
    lines.append(f"- ancestor_kernel = {args.ancestor_kernel}")
    lines.append("")
    lines.append("## Per-mode gate status")
    lines.append("")
    lines.append("| mode | nodes | P0/M2a | M1 | M2b primary pushforward rate | M2c | M4 current |")
    lines.append("|---|---:|---|---|---|---|---|")
    for mode, res in mode_results.items():
        energy_rate = next((r for r in res["rates_all"] if r.get("candidate") == "energy_S_response_terminal_pushforward"), {})
        local_energy_rate = next((r for r in res["rates_all"] if r.get("candidate") == "energy_S_response_local_density"), {})
        lines.append(
            f"| {mode} | {res['n_nodes']} | "
            f"{'ok' if res['prefix_ok'] and res['count_control_exact'] else 'FAILED'} | "
            f"{res['m1_status']} | {energy_rate.get('verdict','')} "
            f"(local density: {local_energy_rate.get('verdict','')}) | "
            f"{res['m2c'].get('M2c_verdict','')} | {res['m4'].get('M4_verdict','')} |"
        )
    lines.append("")
    lines.append("## Conditional mode-universality")
    lines.append(f"- raw M3 status: {m3.get('M3_raw_verdict')}")
    lines.append(f"- cross-mode tail max d_TV: {m3.get('cross_mode_tail_max')}")
    lines.append("- Interpretation rule: M3 small + M2c uniform = mode collapse to uniform carrier, not dynamic universality.")
    lines.append("")
    lines.append("## Final combined verdict")
    lines.append(f"- **{final.get('final_verdict')}**")
    if final.get("conditional_M3"):
        lines.append(f"- conditional M3: {final.get('conditional_M3')}")
    lines.append(f"- reason: {final.get('reason')}")
    lines.append("")
    lines.append("## Reading the main outcomes")
    lines.append("- `uniform_carrier_with_nontrivial_dynamic_current` means `(∂T_b^dyn, μ_count, J)`: neutral positive carrier produced by pushforward, directed provenance current survives.")
    lines.append("- `dynamic_nontrivial_mode_universal_carrier` is the strongest carrier result: nontrivial μ_E, projective rate, and small cross-mode distances.")
    lines.append("- `dynamic_nontrivial_mode_dependent_carrier` is not intrinsic yet: the weighting mode still matters.")
    lines.append("- `dynamic_carrier_unstable` blocks geometry/AQFT interpretation; data remain finite diagnostics.")
    lines.append("")
    return "\n".join(lines)


def render_results(args: argparse.Namespace, mode_results: Dict[str, dict], m3: dict, final: dict) -> str:
    lines: List[str] = []
    lines.append("# RESULTS — v10.2 Projective Provenance Carrier")
    lines.append("")
    lines.append("This package implements the v10 carrier/measure layer on top of the v9 dynamic-birth live-backreaction rule.")
    lines.append("")
    lines.append("## What changed from v9")
    lines.append("- v9's two-ended inverse-symmetry/geometric diagnostics are not evaluated here.")
    lines.append("- v10 adds first-class address/prefix/cylinder tables.")
    lines.append("- v10.2 computes projective defects for count, conductance, local S-response density, and terminal pushforward S-response carriers.")
    lines.append("- v10 keeps antisymmetric orientation as current diagnostics only.")
    lines.append("- Branching is generalized to b>=2 for the growth/carrier layer; old ternary F1/F2 projection bases are not imported.")
    lines.append("")
    lines.append("## Output files")
    lines.append("- `address_tree_levels_<mode>.csv`")
    lines.append("- `prefix_projection_checks_<mode>.csv`")
    lines.append("- `birth_order_prefix_checks_<mode>.csv`")
    lines.append("- `dynamic_boundary_metadata.csv`")
    lines.append("- `v10_gate_P0_prefix_system.csv`")
    lines.append("- `v10_gate_M2a_count_control.csv`")
    lines.append("- `measure_candidates_count_<mode>.csv`")
    lines.append("- `measure_candidates_g_live_<mode>.csv`")
    lines.append("- `measure_candidates_g_birth_<mode>.csv`")
    lines.append("- `measure_candidates_energy_S_response_local_density_<mode>.csv`")
    lines.append("- `measure_candidates_energy_S_response_terminal_pushforward_<mode>.csv`")
    lines.append("- `measure_candidates_energy_S_response_source_ladder_pushforward_<mode>.csv`")
    lines.append("- `measure_projective_defects_<candidate>_<mode>.csv`")
    lines.append("- `measure_rate_fits_<candidate>_<mode>.csv`")
    lines.append("- `measure_nontriviality_vs_count_energy_S_response_terminal_pushforward_<mode>.csv`")
    lines.append("- `measure_mode_distance_energy_S_response_terminal_pushforward.csv`")
    lines.append("- `S_response_psd_defects_<mode>.csv`")
    lines.append("- `orientation_current_over_carrier_<mode>.csv`")
    lines.append("- `v10_combined_verdicts.csv`")
    lines.append("")
    lines.append("## Final verdict")
    lines.append(f"`{final.get('final_verdict')}` — {final.get('reason')}")
    lines.append("")
    lines.append("No file named `measure_candidates_skew_norm.csv`, `measure_candidates_abs_helicity.csv`, or `measure_candidates_abs_omega.csv` is produced, by design.")
    lines.append("")
    return "\n".join(lines)



def dynamic_boundary_metadata_rows(address_rows: List[dict]) -> List[dict]:
    """Compact metadata table required by the v10 plan.

    It separates dynamic-provenance boundary annotations from the full address table.
    """
    keep = [
        "mode", "node_id", "level", "word", "parent_node", "parent_word",
        "record_flag", "live_flag", "root_relation", "front_relation",
        "F1_label", "F2_label", "birth_order_path", "birth_time",
    ]
    rows: List[dict] = []
    for r in address_rows:
        rows.append({k: r.get(k, "") for k in keep})
    return rows


def prefix_gate_rows(mode_results: Dict[str, dict]) -> List[dict]:
    rows: List[dict] = []
    for mode, res in mode_results.items():
        prefix_rows = res.get("prefix_rows", [])
        birth_rows = res.get("birth_prefix_rows", [])
        addr_rows = res.get("address_rows", [])
        children_complete = all(int(r.get("children_complete", 0)) == 1 for r in prefix_rows)
        child_project = all(int(r.get("all_children_project_to_parent", 0)) == 1 for r in prefix_rows)
        child_orders = all(int(r.get("child_orders_are_1_to_b", 0)) == 1 for r in prefix_rows)
        birth_prefix = all(int(r.get("prefix_stable", 0)) == 1 for r in birth_rows)
        # Check injectivity of node_id ↔ word at each level for the generated address table.
        injective = True
        by_level: Dict[str, dict] = {}
        for r in addr_rows:
            lvl = str(r.get("level"))
            by_level.setdefault(lvl, {"ids": set(), "words": set()})
            nid = str(r.get("node_id"))
            word = str(r.get("word"))
            if nid in by_level[lvl]["ids"] or word in by_level[lvl]["words"]:
                injective = False
            by_level[lvl]["ids"].add(nid)
            by_level[lvl]["words"].add(word)
        status = "prefix_system_valid" if (children_complete and child_project and child_orders and birth_prefix and injective and res.get("prefix_ok")) else "prefix_system_invalid"
        rows.append({
            "mode": mode,
            "P0_status": status,
            "children_complete_all": int(children_complete),
            "all_children_project_to_parent_all": int(child_project),
            "child_orders_are_1_to_b_all": int(child_orders),
            "birth_order_prefix_stable_all": int(birth_prefix),
            "node_id_word_injective_by_level": int(injective),
        })
    return rows


def count_control_gate_rows(mode_results: Dict[str, dict]) -> List[dict]:
    rows: List[dict] = []
    for mode, res in mode_results.items():
        count_rate = next((r for r in res.get("rates_all", []) if r.get("candidate") == "count"), {})
        count_defects = [r for r in res.get("defects_all", []) if r.get("candidate") == "count"]
        max_defect = max([safe_float(r.get("projective_defect")) for r in count_defects] or [math.nan])
        rows.append({
            "mode": mode,
            "M2a_status": "count_control_exact" if res.get("count_control_exact") else "count_control_failed",
            "count_rate_verdict": count_rate.get("verdict", ""),
            "count_delta_first": count_rate.get("delta_first", ""),
            "count_delta_last": count_rate.get("delta_last", ""),
            "count_max_projective_defect": max_defect,
            "interpretation": "uniform/count carrier is a prefix/address control, not the symmetric target object",
        })
    return rows


def positive_carrier_gate_rows(mode_results: Dict[str, dict], tail_window: int) -> List[dict]:
    rows: List[dict] = []
    for mode, res in mode_results.items():
        psd_rows = res.get("psd_rows", [])
        push_rows = res.get("energy_push_rows", [])
        psd_vals = [safe_float(r.get("psd_defect_rel")) for r in psd_rows if int(r.get("valid_response", 0)) == 1]
        zero_flags = [int(r.get("zero_energy_degenerate", 0)) for r in psd_rows if int(r.get("valid_response", 0)) == 1]
        mean_zero_dims = [safe_float(r.get("mean_zero_dim")) for r in psd_rows if int(r.get("valid_response", 0)) == 1]
        norm_ok = bool(push_rows) and all(int(r.get("measure_valid_on_level", 1)) == 1 for r in push_rows)
        rows.append({
            "mode": mode,
            "M1_status": res.get("m1_status", ""),
            "normalization_valid_all_levels": int(norm_ok),
            "psd_defect_tail_median_rel": float(np.median(psd_vals[-min(len(psd_vals), tail_window):])) if psd_vals else math.nan,
            "psd_defect_max_rel": max(psd_vals) if psd_vals else math.nan,
            "zero_energy_degeneracy_count": sum(zero_flags),
            "mean_zero_projection_success": int(bool(mean_zero_dims) and min(mean_zero_dims) >= 1),
            "measure_source": "terminal prefix pushforward of Q^T S Q energy; A/current excluded",
        })
    return rows

def run_suite(args: argparse.Namespace) -> dict:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    mode_results: Dict[str, dict] = {}
    energy_rows_by_mode: Dict[str, List[dict]] = {}
    all_defects: List[dict] = []
    all_rates: List[dict] = []
    all_gate_m1: List[dict] = []
    all_gate_m2c: List[dict] = []
    all_gate_m4: List[dict] = []
    all_address_rows: List[dict] = []
    all_prefix_rows: List[dict] = []
    all_birth_prefix_rows: List[dict] = []

    for mode in args.modes:
        res = run_one_mode(args, mode, outdir)
        mode_results[mode] = res
        energy_rows_by_mode[mode] = res["energy_push_rows"]
        all_defects.extend(res["defects_all"])
        all_rates.extend(res["rates_all"])
        all_gate_m1.append({"mode": mode, "M1_status": res["m1_status"]})
        m2crow = {"mode": mode, **res["m2c"]}
        all_gate_m2c.append(m2crow)
        all_gate_m4.append({"mode": mode, **res["m4"]})
        # Duplicate the per-mode address/prefix metadata into consolidated files.
        # The per-mode files remain the authoritative detailed artifacts.
        all_address_rows.extend({"mode": mode, **r} for r in res.get("address_rows", []))
        all_prefix_rows.extend({"mode": mode, **r} for r in res.get("prefix_rows", []))
        all_birth_prefix_rows.extend({"mode": mode, **r} for r in res.get("birth_prefix_rows", []))

    write_csv(outdir / "address_tree_levels.csv", all_address_rows)
    write_csv(outdir / "prefix_projection_checks.csv", all_prefix_rows)
    write_csv(outdir / "birth_order_prefix_checks.csv", all_birth_prefix_rows)
    write_csv(outdir / "dynamic_boundary_metadata.csv", dynamic_boundary_metadata_rows(all_address_rows))
    write_csv(outdir / "v10_gate_P0_prefix_system.csv", prefix_gate_rows(mode_results))
    write_csv(outdir / "v10_gate_M1_positive_carrier.csv", positive_carrier_gate_rows(mode_results, args.tail_window))
    write_csv(outdir / "v10_gate_M2a_count_control.csv", count_control_gate_rows(mode_results))
    write_csv(outdir / "v10_gate_M2_projective_rate.csv", all_rates)
    write_csv(outdir / "v10_gate_M2c_nontriviality.csv", all_gate_m2c)
    write_csv(outdir / "v10_gate_M4_current_over_carrier.csv", all_gate_m4)

    mode_distance_rows, m3 = conditional_mode_universality(
        energy_rows_by_mode,
        outdir=outdir,
        tv_small_tol=args.tv_mode_small_tol,
    )
    write_csv(outdir / "measure_mode_distance_energy_S_response_terminal_pushforward.csv", mode_distance_rows)
    write_csv(outdir / "v10_gate_M3_conditional_mode_universality.csv", [{**m3}])

    prefix_ok = all(res["prefix_ok"] and res["count_control_exact"] for res in mode_results.values())
    positive_statuses = [res["m1_status"] for res in mode_results.values()]
    positive_energy_status = "positive_energy_invalid" if any(s == "positive_energy_invalid" for s in positive_statuses) else "positive_valid"
    final = combine_final_verdict(
        prefix_ok=prefix_ok,
        positive_energy_status=positive_energy_status,
        m2c_classes={mode: res["m2c"] for mode, res in mode_results.items()},
        m3=m3,
        m4_by_mode={mode: res["m4"] for mode, res in mode_results.items()},
    )
    verdict_row = {
        "branching": args.branching,
        "max_level": args.max_level,
        "modes": " ".join(args.modes),
        **m3,
        **final,
    }
    for mode, res in mode_results.items():
        verdict_row[f"{mode}_M1"] = res["m1_status"]
        verdict_row[f"{mode}_M2c"] = res["m2c"].get("M2c_verdict")
        verdict_row[f"{mode}_M4"] = res["m4"].get("M4_verdict")
    write_csv(outdir / "v10_combined_verdicts.csv", [verdict_row])

    summary = render_summary(args, mode_results, m3, final)
    (outdir / "SUMMARY_v10.md").write_text(summary, encoding="utf-8")
    results = render_results(args, mode_results, m3, final)
    (outdir / "RESULTS_projective_provenance_carrier.md").write_text(results, encoding="utf-8")
    return {"mode_results": mode_results, "m3": m3, "final": final, "outdir": outdir}


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-level", type=int, default=6, help="Finite approximant depth. S-response carrier is available through max_level-1.")
    ap.add_argument("--branching", type=int, default=3, help="Branching b>=2. b=3 SG-like control, b=4 ST-like control.")
    ap.add_argument("--modes", nargs="+", default=["linear", "log", "saturating"], choices=["linear", "log", "saturating"])
    ap.add_argument("--outdir", type=Path, default=Path("projective_provenance_measure_out_v10"))
    ap.add_argument("--base", type=float, default=1.0)
    ap.add_argument("--alpha-env", type=float, default=0.22)
    ap.add_argument("--ancestor-decay", type=float, default=0.55)
    ap.add_argument("--br-ancestor", type=float, default=0.045)
    ap.add_argument("--br-sibling", type=float, default=0.035)
    ap.add_argument("--eps", type=float, default=EPS)
    ap.add_argument("--tol", type=float, default=DEFAULT_TOL)
    ap.add_argument("--cond-max", type=float, default=DEFAULT_COND_MAX)
    ap.add_argument("--no-relational-live-update", action="store_true")
    ap.add_argument("--live-relation-target-scale", choices=["current_g", "birth_g"], default="current_g")
    ap.add_argument("--ancestor-kernel", choices=["inverse_square", "shell_norm_inverse_square"], default="shell_norm_inverse_square", help="Ancestor backreaction kernel; scripts 12-21 select shell_norm_inverse_square as the infinite-shell default.")
    ap.add_argument("--tail-window", type=int, default=4)
    ap.add_argument("--tv-zero-tol", type=float, default=0.025)
    ap.add_argument("--tv-nontrivial-tol", type=float, default=0.05)
    ap.add_argument("--tv-mode-small-tol", type=float, default=0.05)
    ap.add_argument("--psd-rel-warning", type=float, default=1e-7)
    ap.add_argument("--psd-rel-invalid", type=float, default=1e-3)
    ap.add_argument("--current-tol", type=float, default=1e-10)
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    if args.max_level < 1:
        raise SystemExit("--max-level must be >=1")
    if args.branching < 2:
        raise SystemExit("--branching must be >=2")
    run_suite(args)


if __name__ == "__main__":
    main()
