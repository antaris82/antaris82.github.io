# CNNA v10.2 — Projective Provenance Carrier Test

This package implements the full Phase-v10 gate/output structure on top of the v9 dynamic-birth live-backreaction rule, with the v10.1 correction retained:

- a local `Q^T S Q` shell value is an event/local density, not directly a cylinder measure;
- the primary cylinder carrier is built by terminal-shell prefix pushforward;
- `A`, `omega`, helicity and `J` remain separate signed current diagnostics and never define `mu`;
- the target object is the asymmetric dynamic provenance boundary, not the strict symmetric control tree.

## Main script

```bash
python3 test_dynamic_birth_projective_provenance_measure_v10_2.py \
  --max-level 6 \
  --branching 3 \
  --outdir csv_outputs_L6_v10_2
```

Optional ST-like check:

```bash
python3 test_dynamic_birth_projective_provenance_measure_v10_2.py \
  --max-level 5 \
  --branching 4 \
  --outdir csv_outputs_b4_L5_v10_2
```

## Phase-v10 completion relative to v10.1

v10.2 adds explicit audit artifacts that were only implicit/folded in v10.1:

- `dynamic_boundary_metadata.csv`
- `v10_gate_P0_prefix_system.csv`
- `v10_gate_M2a_count_control.csv`
- expanded `v10_gate_M1_positive_carrier.csv` with PSD/zero-energy/mean-zero information

The previous combined files remain available.

## Guardrails

No spectral dimension, no Laplacian geometry, no disk embedding, no AQFT algebra.

`S` means the symmetric matrix part of the response. It does **not** mean the symmetric tree.
