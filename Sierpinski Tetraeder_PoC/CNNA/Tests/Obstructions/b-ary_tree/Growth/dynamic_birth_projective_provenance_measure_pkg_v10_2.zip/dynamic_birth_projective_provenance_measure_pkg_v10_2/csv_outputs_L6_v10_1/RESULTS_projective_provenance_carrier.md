# RESULTS — v10.1 Projective Provenance Carrier

This package implements the v10 carrier/measure layer on top of the v9 dynamic-birth live-backreaction rule.

## What changed from v9
- v9's two-ended inverse-symmetry/geometric diagnostics are not evaluated here.
- v10 adds first-class address/prefix/cylinder tables.
- v10.1 computes projective defects for count, conductance, local S-response density, and terminal pushforward S-response carriers.
- v10 keeps antisymmetric orientation as current diagnostics only.
- Branching is generalized to b>=2 for the growth/carrier layer; old ternary F1/F2 projection bases are not imported.

## Output files
- `address_tree_levels_<mode>.csv`
- `prefix_projection_checks_<mode>.csv`
- `birth_order_prefix_checks_<mode>.csv`
- `measure_candidates_count_<mode>.csv`
- `measure_candidates_g_live_<mode>.csv`
- `measure_candidates_g_birth_<mode>.csv`
- `measure_candidates_energy_S_response_local_density_<mode>.csv`
- `measure_candidates_energy_S_response_terminal_pushforward_<mode>.csv`
- `measure_candidates_energy_S_response_source_ladder_pushforward_<mode>.csv`
- `measure_projective_defects_<candidate>_<mode>.csv`
- `measure_rate_fits_<candidate>_<mode>.csv`
- `measure_nontriviality_vs_count_energy_S_response_terminal_pushforward_<mode>.csv`
- `measure_mode_distance_energy_S_response_terminal_pushforward.csv`
- `S_response_psd_defects_<mode>.csv`
- `orientation_current_over_carrier_<mode>.csv`
- `v10_combined_verdicts.csv`

## Final verdict
`uniform_carrier_with_nontrivial_dynamic_current` — positive carrier collapses to uniform/count on dynamic provenance; separate current survives

No file named `measure_candidates_skew_norm.csv`, `measure_candidates_abs_helicity.csv`, or `measure_candidates_abs_omega.csv` is produced, by design.
