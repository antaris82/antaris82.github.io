# SUMMARY v10.1 — Projective Provenance Carrier Test

Status: deterministic finite diagnostic; not a geometry/AQFT/spectral claim.

## Guardrails
- Target object: asymmetric dynamic provenance boundary, not the strict symmetric tree.
- Uniform/count carrier is a neutral cylinder carrier on the dynamic boundary.
- Local S-response density uses only Q^T S Q; the cylinder carrier is its terminal-shell prefix pushforward. A/omega/J are never used to define μ.
- M3 mode-universality is conditional on M2c nontriviality-vs-count.
- v10.1 does not compute spectral dimension, Laplacian geometry, AQFT algebras, or disk embeddings.

## Run parameters
- branching b = 3
- max_level = 6
- modes = linear, log, saturating
- alpha_env = 0.22
- ancestor_decay = 0.55
- br_ancestor = 0.045
- br_sibling = 0.035
- ancestor_kernel = shell_norm_inverse_square

## Per-mode gate status

| mode | nodes | P0/M2a | M1 | M2b primary pushforward rate | M2c | M4 current |
|---|---:|---|---|---|---|---|
| linear | 1093 | ok | positive_valid | exact_control (local density: unstable) | uniform_carrier_on_dynamic_provenance | stable_dynamic_current |
| log | 1093 | ok | positive_valid | exact_control (local density: unstable) | uniform_carrier_on_dynamic_provenance | stable_dynamic_current |
| saturating | 1093 | ok | positive_valid | exact_control (local density: unstable) | uniform_carrier_on_dynamic_provenance | stable_dynamic_current |

## Conditional mode-universality
- raw M3 status: mode_distance_small
- cross-mode tail max d_TV: 0.02198985893070637
- Interpretation rule: M3 small + M2c uniform = mode collapse to uniform carrier, not dynamic universality.

## Final combined verdict
- **uniform_carrier_with_nontrivial_dynamic_current**
- conditional M3: uniform_carrier_mode_collapse
- reason: positive carrier collapses to uniform/count on dynamic provenance; separate current survives

## Reading the main outcomes
- `uniform_carrier_with_nontrivial_dynamic_current` means `(∂T_b^dyn, μ_count, J)`: neutral positive carrier produced by pushforward, directed provenance current survives.
- `dynamic_nontrivial_mode_universal_carrier` is the strongest carrier result: nontrivial μ_E, projective rate, and small cross-mode distances.
- `dynamic_nontrivial_mode_dependent_carrier` is not intrinsic yet: the weighting mode still matters.
- `dynamic_carrier_unstable` blocks geometry/AQFT interpretation; data remain finite diagnostics.
