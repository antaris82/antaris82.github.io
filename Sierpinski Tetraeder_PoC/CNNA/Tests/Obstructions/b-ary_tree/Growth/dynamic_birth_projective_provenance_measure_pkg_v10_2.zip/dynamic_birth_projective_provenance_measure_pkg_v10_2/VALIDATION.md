# Validation notes for v10.2

Validated in the sandbox with Python 3.13.

## b=3, L=6

Command:

```bash
python3 test_dynamic_birth_projective_provenance_measure_v10_2.py --max-level 6 --branching 3 --outdir csv_outputs_L6_v10_2
```

Result:

```text
final_verdict = uniform_carrier_with_nontrivial_dynamic_current
conditional_M3 = uniform_carrier_mode_collapse
P0 = prefix_system_valid for all modes
M2a = count_control_exact for all modes
```

Interpretation:

```text
The terminal-pushforward S-response carrier collapses to the uniform/count carrier
on the asymmetric dynamic provenance boundary, while a separate signed dynamic
current remains stable.
```

This is not a failure. It is the clean outcome anticipated by the corrected planning:

```text
(∂T_b^dyn, μ_count, J)
```

## b=4, L=5

Command:

```bash
python3 test_dynamic_birth_projective_provenance_measure_v10_2.py --max-level 5 --branching 4 --outdir csv_outputs_b4_L5_v10_2
```

Result:

```text
final_verdict = finite_diagnostic_only
P0 = prefix_system_valid for all modes
M2a = count_control_exact for all modes
```

Reason: the linear mode is borderline/ambiguous in nontriviality-vs-count at this shallow depth, while log and saturating collapse to the uniform/count carrier. The current still survives in all modes. Treat b=4 L5 as a finite diagnostic requiring deeper or mode-specific follow-up.
