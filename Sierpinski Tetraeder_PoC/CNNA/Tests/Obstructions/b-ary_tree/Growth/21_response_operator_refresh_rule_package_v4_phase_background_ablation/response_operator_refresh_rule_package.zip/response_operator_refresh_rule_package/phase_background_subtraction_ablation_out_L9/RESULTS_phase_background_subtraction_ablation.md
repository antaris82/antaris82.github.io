# Phase background subtraction ablation

## Purpose

This test checks whether response-loop residual curvature is robust under multiple background subtractions or whether the residual is created by a special clock/background choice.

This is only a detector-calibration test. It does not prove physical `i`, time, modular flow, AQFT, or Type III behavior.

## Setup

- max level: `9`
- nodes: `29524`
- completed local response parents: `9841`
- loops: `16400`
- kernel: `K(d)=1/(3^(d-1)d^2)`
- methods: `polar`, `eigen`, `G_weighted`

## Verdict

```text
background_sensitive
```

Reasons:

- non-overfit structural backgrounds change polar residual scale strongly
- global-vs-level residual ranking has low Spearman correlation

## Polar residual scale by background

```text
raw_mean_abs_deg                  = 124.288270687749
theta_inf_mean_abs_deg            = 1.111206851701
global_mean_abs_deg               = 0.440124924804
level_mean_abs_deg                = 0.124682856572
age_mean_abs_deg                  = 0.124682856572
parent_family_mean_abs_deg        = 0.050387734553
randomized_level_mean_abs_deg     = 0.537738424364
overfit_per_loop_abs_deg          = 0.000000000000
randomized / level_mean ratio     = 4.312850
global / level_mean ratio         = 3.529955
family / level_mean ratio         = 0.404127
```

## Stability relative to level-mean residuals

```text
polar global abs Spearman         = 0.084096
polar age abs Spearman            = 1.000000
polar family abs Spearman         = 0.453295
polar randomized abs Spearman     = 0.194503
```

## Interpretation

The residual is not accepted merely because it is small. The relevant checks are:

1. non-overfit backgrounds should give comparable residual scales and similar localization/ranking;
2. randomized background assignment should alter or damage the residual structure;
3. the overfit control must collapse residuals to zero and is therefore marked as invalid;
4. raw loop phase must remain large enough to distinguish phase-density removal from trivial zero phase.

The result does not fully clear the anti-smuggling test. The response-phase residual should not be used as a hard defect observable without further controls or a more derived background rule.

## Next test

```text
test_provenance_identification_double_history_holonomy.py
```

Goal: build a controlled effective gluing/quotient where the same effective port is reached by two different birth-history paths, then test whether Record/Live layers produce a nontrivial handoff cocycle/defect.

Why next: the present test calibrates the phase-background subtraction detector. The next obstruction is whether genuine provenance double-history creates a CNNA-internal holonomy source or whether it also telescopes away.