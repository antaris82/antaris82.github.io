# CNNA single-layer role obstruction test

## Purpose

This test checks whether a single local response operator can simultaneously serve as an immutable birth/provenance record and as a current live response state under later descendant/ancestor backreaction.

The obstruction quantity is not the static record/live mismatch at completion. The decisive quantity is:

```text
live_aging(p) = || W_live(p, t_final) - W_live(p, t_complete) ||_F
```

If `live_aging(p) > eps` while `record_drift(p) ≈ 0`, then a single-layer identification forces either loss of record invariance or loss of live covariance.

## Parameters

- `max_level`: 9
- branching: `3`
- kernel: `shell_norm_inverse_square = 1/(3^(d-1) d^2)`
- obstruction epsilon: `1e-09`

## Main numerical result

```text
conclusion: single_layer_obstructed
parents total: 9841
aged parents: 3280
record_drift_abs max: 0.000000000000e+00
live_aging_abs mean aged: 3.242530093937e-02
live_aging_abs max aged: 5.682712838643e-02
fraction obstructed aged: 1.000000000
no_backreaction live_aging_abs max aged: 0.000000000000e+00
```

## Why this supports two-layer semantics

Under nontrivial backreaction, the live response of old completed parents changes after completion, while the birth/provenance record remains fixed. Therefore:

```text
record_as_single:
  W_single := W_record
  -> keeps provenance invariant
  -> fails to track live aging

live_as_single:
  W_single := W_live(t)
  -> tracks current state
  -> rewrites the historical record

two_layer:
  W_record := W_birth
  W_state(t) := W_live(t)
  -> separates the two roles
```

## Controls

```text
same_time_recompute max main: 0.000000000000e+00
no_backreaction record_drift_abs max: 0.000000000000e+00
no_backreaction live_aging_abs max aged: 0.000000000000e+00
```

The no-backreaction control is essential: when later births do not update old conductances, the obstruction disappears. This localizes the obstruction to nontrivial dynamic backreaction rather than to CSV handling, recomputation noise, or a static record/live convention.

## Interior versus frontier

```text
frontier parents count: 6561
frontier live_aging_abs mean: 2.991893742147e-04
old interior parents count distance>=3: 364
old interior live_aging_abs mean: 4.126552768619e-02
old interior single_layer_violation_rel mean: 2.535666842530e-01
```

Global-level age-zero frontier parents have no deeper descendant-level aging yet, but they can already show same-level environment aging because later sequential births may update shared ancestors. The stronger obstruction is visible in already completed local records after subsequent network extension.

## Reasons

- record_drift is numerically zero within tolerance
- live response ages under nontrivial backreaction
- no-backreaction control removes live aging
- most aged parents are single-layer obstructed

## Interpretation guard

This is a CNNA-internal role/provenance obstruction test. It does not establish AQFT additivity, the physical complex unit, modular flow, physical time, or Type III structure. It only supports the provisional model object `ResponseRecord x LiveResponseState` under nontrivial aging.
