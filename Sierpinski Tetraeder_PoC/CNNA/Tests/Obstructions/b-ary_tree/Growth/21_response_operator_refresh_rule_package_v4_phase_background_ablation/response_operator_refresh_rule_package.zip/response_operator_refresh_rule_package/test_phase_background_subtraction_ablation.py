#!/usr/bin/env python3
"""
CNNA / growing real complement network
Phase-background-subtraction ablation test.

Purpose
-------
Tests whether the residual response curvature reported after phase-density / clock
subtraction is robust under several background choices, or whether it is produced
by a special subtraction scheme.

This is an anti-smuggling detector calibration. It is intentionally modest:
- It does not prove physical i, modular flow, AQFT, or Type III behavior.
- It checks whether the response-phase residual is stable enough to be used as a
  defect observable in the later double-history provenance-identification test.

Core comparisons
----------------
For shell-normalized inverse-square growth K(d)=1/(3^(d-1)d^2), compute local
response phases for completed parents and synthetic response loops. For each
loop, compare residuals under:

  raw
  fixed theta_inf subtraction
  global mean subtraction
  level mean subtraction
  local shell/age mean subtraction
  parent-family mean subtraction
  randomized background assignment control
  overfit per-loop control

Acceptance is not "small residual". The residual observable is trusted only if
structural localization is stable across non-overfit backgrounds and destroyed or
substantially changed by randomized/overfit controls.
"""

from __future__ import annotations

import argparse
import csv
import math
import random
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np

EPS = 1e-12
METHODS = ["polar", "eigen", "G_weighted"]
DEFAULT_THETA_INF = {
    "polar": 168.027421321,
    "eigen": 172.552820014,
    "G_weighted": 167.890861027,
}
STRUCTURAL_BACKGROUNDS = [
    "theta_inf",
    "global_mean",
    "level_mean",
    "age_mean",
    "parent_family_mean",
]
ALL_BACKGROUNDS = ["raw"] + STRUCTURAL_BACKGROUNDS + ["randomized_level_mean", "overfit_per_loop"]


@dataclass
class Node:
    id: int
    parent: Optional[int]
    level: int
    birth_order: int
    birth_time: int
    birth_g: float
    g: float
    children: List[int] = field(default_factory=list)


class ShellGrowth:
    def __init__(self, backreaction: bool = True):
        self.b = 3
        self.base = 1.0
        self.alpha_env = 0.22
        self.ancestor_env_decay = 0.55
        self.br_ancestor = 0.045 if backreaction else 0.0
        self.br_sibling = 0.035 if backreaction else 0.0
        self.backreaction = backreaction
        self.nodes: Dict[int, Node] = {}
        self.local_w: Dict[int, Dict[Tuple[int, int], float]] = defaultdict(lambda: defaultdict(float))
        self.next_id = 0
        self.t = 0
        root = self._new_node(None, 0, 0, 1.0)
        self.root = root.id

    def _new_node(self, parent: Optional[int], level: int, birth_order: int, birth_g: float) -> Node:
        n = Node(self.next_id, parent, level, birth_order, self.t, birth_g, birth_g)
        self.nodes[n.id] = n
        self.next_id += 1
        if parent is not None:
            self.nodes[parent].children.append(n.id)
        return n

    def kernel(self, d: int) -> float:
        return 1.0 / ((self.b ** (d - 1)) * d * d)

    def parent_line(self, parent: int) -> List[int]:
        out: List[int] = []
        cur: Optional[int] = parent
        while cur is not None:
            out.append(cur)
            cur = self.nodes[cur].parent
        return out

    def birth_env(self, parent: int, older: List[int]) -> float:
        env = 0.0
        for d, a in enumerate(self.parent_line(parent), start=1):
            env += self.nodes[a].g * (self.ancestor_env_decay ** (d - 1))
        for s in older:
            env += self.nodes[s].g
        return env

    def child_g(self, env: float) -> float:
        return self.base + self.alpha_env * math.log1p(env)

    def add_child(self, parent: int, order: int) -> int:
        self.t += 1
        older = list(self.nodes[parent].children)
        env = self.birth_env(parent, older)
        bg = self.child_g(env)
        child = self._new_node(parent, self.nodes[parent].level + 1, order, bg)
        c = child.id

        for s in older:
            i = self.nodes[s].birth_order
            j = order
            self.local_w[parent][(i, j)] += self.alpha_env * self.nodes[s].g / (env + EPS) * bg

        for d, a in enumerate(self.parent_line(parent), start=1):
            self.nodes[a].g += self.br_ancestor * bg * self.kernel(d)

        for s in older:
            i = order
            j = self.nodes[s].birth_order
            delta = self.br_sibling * bg
            self.nodes[s].g += delta
            self.local_w[parent][(i, j)] += delta

        return c

    def grow_one_level(self, frontier: List[int]) -> List[int]:
        out: List[int] = []
        for p in frontier:
            for k in range(1, 4):
                out.append(self.add_child(p, k))
        return out

    def grow_to_level(self, max_level: int) -> None:
        frontier = [self.root]
        for _ in range(1, max_level + 1):
            frontier = self.grow_one_level(frontier)

    def local_matrix(self, parent: int) -> Optional[np.ndarray]:
        if len(self.nodes[parent].children) != 3:
            return None
        M = np.zeros((3, 3), float)
        w = self.local_w[parent]
        for i in range(1, 4):
            for j in range(1, 4):
                if i != j:
                    M[j - 1, i - 1] = w.get((i, j), 0.0)
        return M


def wrap_deg(x: float) -> float:
    return ((float(x) + 180.0) % 360.0) - 180.0


def finite(vals: Iterable[float]) -> List[float]:
    return [float(v) for v in vals if np.isfinite(float(v))]


def mean(vals: Iterable[float]) -> float:
    xs = finite(vals)
    return float(np.mean(xs)) if xs else float("nan")


def std(vals: Iterable[float]) -> float:
    xs = finite(vals)
    return float(np.std(xs)) if xs else float("nan")


def perc(vals: Iterable[float], q: float) -> float:
    xs = finite(vals)
    return float(np.percentile(xs, q)) if xs else float("nan")


def safe_min(vals: Iterable[float]) -> float:
    xs = finite(vals)
    return float(np.min(xs)) if xs else float("nan")


def safe_max(vals: Iterable[float]) -> float:
    xs = finite(vals)
    return float(np.max(xs)) if xs else float("nan")


def column_stochastic(M: np.ndarray) -> np.ndarray:
    P = M.copy().astype(float)
    for j in range(3):
        s = P[:, j].sum()
        if s > EPS:
            P[:, j] /= s
        else:
            P[j, j] = 1.0
    return P


def skew_axis(A: np.ndarray) -> np.ndarray:
    return np.array([A[2, 1], A[0, 2], A[1, 0]], float)


def plane_basis(axis: np.ndarray) -> np.ndarray:
    a = axis / (np.linalg.norm(axis) + EPS)
    h = np.array([1.0, 0.0, 0.0])
    if abs(float(np.dot(a, h))) > 0.9:
        h = np.array([0.0, 1.0, 0.0])
    u = h - np.dot(h, a) * a
    u = u / (np.linalg.norm(u) + EPS)
    v = np.cross(a, u)
    v = v / (np.linalg.norm(v) + EPS)
    return np.vstack([u, v]).T


def polar_so2(A2: np.ndarray) -> Tuple[np.ndarray, np.ndarray, int]:
    U, s, Vt = np.linalg.svd(A2)
    Q = U @ Vt
    refl = 0
    if np.linalg.det(Q) < 0:
        refl = 1
        U[:, -1] *= -1
        Q = U @ Vt
    return Q, s, refl


def angle_so2_deg(Q: np.ndarray) -> float:
    cosv = float((Q[0, 0] + Q[1, 1]) / 2.0)
    sinv = float((Q[1, 0] - Q[0, 1]) / 2.0)
    return math.degrees(math.atan2(sinv, cosv))


def local_phase(model: ShellGrowth, parent: int) -> Optional[dict]:
    M = model.local_matrix(parent)
    if M is None:
        return None
    P = column_stochastic(M)
    A = 0.5 * (P - P.T)
    axis = skew_axis(A)
    if np.linalg.norm(axis) <= EPS:
        return None
    c = np.ones(3) / math.sqrt(3)
    if np.dot(axis, c) < 0:
        axis = -axis
    axis = axis / (np.linalg.norm(axis) + EPS)
    B = plane_basis(axis)
    R2 = B.T @ P @ B

    Q, s, refl = polar_so2(R2)
    theta_polar = angle_so2_deg(Q)

    ev = np.linalg.eigvals(P)
    ces = [z for z in ev if abs(z.imag) > 1e-9]
    theta_eigen = float("nan")
    if ces:
        z = max(ces, key=lambda z: z.imag)
        theta_eigen = math.degrees(math.atan2(z.imag, z.real))

    S2 = 0.5 * (R2 + R2.T)
    theta_G = float("nan")
    for _, cand in [(-1, -S2), (1, S2)]:
        eig = np.linalg.eigvalsh(cand)
        if np.all(eig > 1e-10):
            try:
                L = np.linalg.cholesky(cand)
                C = L.T
                Rg = C @ R2 @ np.linalg.inv(C)
                Qg, _, _ = polar_so2(Rg)
                theta_G = angle_so2_deg(Qg)
                break
            except np.linalg.LinAlgError:
                pass

    return {
        "parent": parent,
        "level": model.nodes[parent].level,
        "age": None,
        "parent_of_parent": model.nodes[parent].parent,
        "birth_order": model.nodes[parent].birth_order,
        "polar": theta_polar,
        "eigen": theta_eigen,
        "G_weighted": theta_G,
        "axis_x": float(axis[0]),
        "axis_y": float(axis[1]),
        "axis_z": float(axis[2]),
        "polar_cond": float(max(s) / (min(s) + EPS)),
    }


def completed_parent_ids(model: ShellGrowth) -> List[int]:
    return [n.id for n in model.nodes.values() if len(n.children) == 3]


def build_data(model: ShellGrowth, max_level: int) -> Dict[int, dict]:
    data: Dict[int, dict] = {}
    for p in completed_parent_ids(model):
        d = local_phase(model, p)
        if d is not None:
            d["age"] = max_level - d["level"]
            data[p] = d
    return data


def build_loops(model: ShellGrowth, data: Dict[int, dict]) -> List[dict]:
    loops: List[dict] = []
    loop_id = 0
    for p in data:
        cs = [c for c in model.nodes[p].children if c in data]
        if len(cs) == 3:
            c1, c2, c3 = cs
            specs = [
                ("sibling_cycle", model.nodes[p].level + 1, p, [c1, c2, c3]),
                ("parent_child_ring", model.nodes[p].level, p, [p, c1, c2, c3]),
                ("parent_fan_triangle", model.nodes[p].level, p, [p, c1, c2]),
                ("parent_fan_triangle", model.nodes[p].level, p, [p, c2, c3]),
                ("parent_fan_triangle", model.nodes[p].level, p, [p, c3, c1]),
            ]
            for mode, lvl, base, nodes in specs:
                loops.append({
                    "loop_id": loop_id,
                    "mode": mode,
                    "loop_level": lvl,
                    "base": base,
                    "nodes": nodes,
                    "length": len(nodes),
                    "min_node_level": min(data[u]["level"] for u in nodes),
                    "max_node_level": max(data[u]["level"] for u in nodes),
                    "mean_age": mean(data[u]["age"] for u in nodes),
                })
                loop_id += 1
    return loops


def rankdata(xs: List[float]) -> np.ndarray:
    arr = np.array(xs, dtype=float)
    order = np.argsort(arr, kind="mergesort")
    ranks = np.empty(len(arr), dtype=float)
    i = 0
    while i < len(arr):
        j = i + 1
        while j < len(arr) and arr[order[j]] == arr[order[i]]:
            j += 1
        avg = (i + j - 1) / 2.0
        ranks[order[i:j]] = avg
        i = j
    return ranks


def pearson(x: List[float], y: List[float]) -> float:
    a = np.array(x, dtype=float)
    b = np.array(y, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]
    b = b[mask]
    if len(a) < 3:
        return float("nan")
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def spearman(x: List[float], y: List[float]) -> float:
    a = np.array(x, dtype=float)
    b = np.array(y, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]
    b = b[mask]
    if len(a) < 3:
        return float("nan")
    return pearson(rankdata(a.tolist()).tolist(), rankdata(b.tolist()).tolist())


def fit_decay_by_level(level_rows: List[dict], col: str) -> dict:
    L = np.array([r["loop_level"] for r in level_rows], dtype=float)
    y = np.array([r[col] for r in level_rows], dtype=float)
    mask = np.isfinite(L) & np.isfinite(y) & (y > 0)
    L = L[mask]
    y = y[mask]
    if len(y) < 4:
        return {"model": "insufficient", "r": float("nan"), "alpha": float("nan"), "rmse": float("nan")}
    logy = np.log(y)
    X = np.vstack([np.ones_like(L), L]).T
    beta, *_ = np.linalg.lstsq(X, logy, rcond=None)
    yhat = np.exp(X @ beta)
    rmse_exp = float(np.sqrt(np.mean((y - yhat) ** 2)))
    expfit = {"model": "C_r_pow_L", "C": float(math.exp(beta[0])), "r": float(math.exp(beta[1])), "alpha": float("nan"), "rmse": rmse_exp}
    N = (3.0 ** (L + 1) - 1.0) / 2.0
    X = np.vstack([np.ones_like(N), np.log(N)]).T
    beta, *_ = np.linalg.lstsq(X, logy, rcond=None)
    yhat = np.exp(X @ beta)
    rmse_pow = float(np.sqrt(np.mean((y - yhat) ** 2)))
    powfit = {"model": "C_N_minus_alpha", "C": float(math.exp(beta[0])), "r": float("nan"), "alpha": float(-beta[1]), "rmse": rmse_pow}
    return expfit if expfit["rmse"] <= powfit["rmse"] else powfit


def compute_background_maps(data: Dict[int, dict], method: str, max_level: int, theta_inf: Dict[str, float], rng: random.Random) -> Dict[str, Dict[int, float]]:
    node_ids = list(data.keys())
    vals = {u: data[u][method] for u in node_ids}
    global_mu = mean(vals.values())

    by_level: Dict[int, List[float]] = defaultdict(list)
    by_age: Dict[int, List[float]] = defaultdict(list)
    by_family: Dict[Optional[int], List[float]] = defaultdict(list)
    for u, d in data.items():
        by_level[d["level"]].append(d[method])
        by_age[d["age"]].append(d[method])
        by_family[d["parent_of_parent"]].append(d[method])

    level_mu = {k: mean(v) for k, v in by_level.items()}
    age_mu = {k: mean(v) for k, v in by_age.items()}
    family_mu = {k: mean(v) for k, v in by_family.items()}

    maps: Dict[str, Dict[int, float]] = {}
    maps["raw"] = {u: 0.0 for u in node_ids}
    maps["theta_inf"] = {u: theta_inf[method] for u in node_ids}
    maps["global_mean"] = {u: global_mu for u in node_ids}
    maps["level_mean"] = {u: level_mu[data[u]["level"]] for u in node_ids}
    maps["age_mean"] = {u: age_mu[data[u]["age"]] for u in node_ids}
    maps["parent_family_mean"] = {u: family_mu[data[u]["parent_of_parent"]] for u in node_ids}

    level_values = list(maps["level_mean"].values())
    rng.shuffle(level_values)
    maps["randomized_level_mean"] = {u: level_values[i] for i, u in enumerate(node_ids)}
    return maps


def residual_rows_for_method(data: Dict[int, dict], loops: List[dict], method: str, max_level: int, theta_inf: Dict[str, float], seed: int) -> List[dict]:
    rng = random.Random(seed + 1009 * METHODS.index(method))
    maps = compute_background_maps(data, method, max_level, theta_inf, rng)
    rows: List[dict] = []
    for lp in loops:
        nodes = lp["nodes"]
        vals = [data[u][method] for u in nodes]
        if not all(np.isfinite(vals)):
            continue
        raw_sum = sum(vals)
        for bg in ALL_BACKGROUNDS:
            if bg == "overfit_per_loop":
                # This deliberately invalid control subtracts the loop's own mean phase.
                bg_sum = raw_sum
            else:
                bg_sum = sum(maps[bg][u] for u in nodes)
            signed = wrap_deg(raw_sum - bg_sum)
            rows.append({
                "method": method,
                "background": bg,
                "loop_id": lp["loop_id"],
                "mode": lp["mode"],
                "loop_level": lp["loop_level"],
                "base": lp["base"],
                "length": lp["length"],
                "mean_age": lp["mean_age"],
                "min_node_level": lp["min_node_level"],
                "max_node_level": lp["max_node_level"],
                "raw_sum_deg": raw_sum,
                "background_sum_deg": bg_sum,
                "signed_residual_deg": signed,
                "abs_residual_deg": abs(signed),
            })
    return rows


def summarize(rows: List[dict]) -> Tuple[List[dict], List[dict], List[dict], List[dict], List[dict]]:
    global_rows: List[dict] = []
    mode_rows: List[dict] = []
    level_rows: List[dict] = []
    age_rows: List[dict] = []
    for method in METHODS:
        for bg in ALL_BACKGROUNDS:
            rs = [r for r in rows if r["method"] == method and r["background"] == bg]
            vals = [r["abs_residual_deg"] for r in rs]
            signed = [r["signed_residual_deg"] for r in rs]
            global_rows.append({
                "method": method,
                "background": bg,
                "loop_count": len(rs),
                "abs_mean_deg": mean(vals),
                "abs_std_deg": std(vals),
                "abs_median_deg": perc(vals, 50),
                "abs_p90_deg": perc(vals, 90),
                "abs_p95_deg": perc(vals, 95),
                "abs_max_deg": safe_max(vals),
                "signed_mean_deg": mean(signed),
                "signed_std_deg": std(signed),
            })
            for mode in sorted({r["mode"] for r in rs}):
                ms = [r for r in rs if r["mode"] == mode]
                mode_rows.append({
                    "method": method,
                    "background": bg,
                    "mode": mode,
                    "loop_count": len(ms),
                    "abs_mean_deg": mean(r["abs_residual_deg"] for r in ms),
                    "abs_p95_deg": perc([r["abs_residual_deg"] for r in ms], 95),
                })
            for lvl in sorted({r["loop_level"] for r in rs}):
                ls = [r for r in rs if r["loop_level"] == lvl]
                level_rows.append({
                    "method": method,
                    "background": bg,
                    "loop_level": lvl,
                    "loop_count": len(ls),
                    "abs_mean_deg": mean(r["abs_residual_deg"] for r in ls),
                    "abs_p95_deg": perc([r["abs_residual_deg"] for r in ls], 95),
                })
            for age in sorted({round(float(r["mean_age"]), 6) for r in rs}):
                ages = [r for r in rs if round(float(r["mean_age"]), 6) == age]
                age_rows.append({
                    "method": method,
                    "background": bg,
                    "mean_age": age,
                    "loop_count": len(ages),
                    "abs_mean_deg": mean(r["abs_residual_deg"] for r in ages),
                    "abs_p95_deg": perc([r["abs_residual_deg"] for r in ages], 95),
                })

    corr_rows: List[dict] = []
    for method in METHODS:
        ref = [r for r in rows if r["method"] == method and r["background"] == "level_mean"]
        ref_by_id = {r["loop_id"]: r for r in ref}
        for bg in ALL_BACKGROUNDS:
            if bg == "level_mean":
                continue
            rs = [r for r in rows if r["method"] == method and r["background"] == bg and r["loop_id"] in ref_by_id]
            x_abs = [ref_by_id[r["loop_id"]]["abs_residual_deg"] for r in rs]
            y_abs = [r["abs_residual_deg"] for r in rs]
            x_sgn = [ref_by_id[r["loop_id"]]["signed_residual_deg"] for r in rs]
            y_sgn = [r["signed_residual_deg"] for r in rs]
            corr_rows.append({
                "method": method,
                "reference_background": "level_mean",
                "background": bg,
                "loop_count": len(rs),
                "abs_pearson_vs_level_mean": pearson(x_abs, y_abs),
                "abs_spearman_vs_level_mean": spearman(x_abs, y_abs),
                "signed_pearson_vs_level_mean": pearson(x_sgn, y_sgn),
                "signed_spearman_vs_level_mean": spearman(x_sgn, y_sgn),
            })
    return global_rows, mode_rows, level_rows, age_rows, corr_rows


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = sorted({k for r in rows for k in r.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def write_markdown(outdir: Path, max_level: int, model: ShellGrowth, data: Dict[int, dict], loops: List[dict], global_rows: List[dict], corr_rows: List[dict], fit_rows: List[dict]) -> None:
    def g(method: str, bg: str, col: str) -> float:
        for r in global_rows:
            if r["method"] == method and r["background"] == bg:
                return float(r[col])
        return float("nan")

    def c(method: str, bg: str, col: str) -> float:
        for r in corr_rows:
            if r["method"] == method and r["background"] == bg:
                return float(r[col])
        return float("nan")

    polar_level = g("polar", "level_mean", "abs_mean_deg")
    polar_global = g("polar", "global_mean", "abs_mean_deg")
    polar_family = g("polar", "parent_family_mean", "abs_mean_deg")
    polar_rand = g("polar", "randomized_level_mean", "abs_mean_deg")
    polar_overfit = g("polar", "overfit_per_loop", "abs_mean_deg")
    rand_ratio = polar_rand / (polar_level + EPS)
    family_ratio = polar_family / (polar_level + EPS)
    global_ratio = polar_global / (polar_level + EPS)

    verdict = "usable_with_caution"
    reasons = []
    if polar_level <= 1e-9 or polar_overfit > 1e-9:
        verdict = "detector_bug"
        reasons.append("overfit or level residual sanity check failed")
    if rand_ratio < 1.10:
        verdict = "subtraction_artifact_risk_high"
        reasons.append("randomized background does not substantially change polar residual scale")
    if min(global_ratio, family_ratio) < 0.50 or max(global_ratio, family_ratio) > 1.75:
        if verdict == "usable_with_caution":
            verdict = "background_sensitive"
        reasons.append("non-overfit structural backgrounds change polar residual scale strongly")
    if abs(c("polar", "global_mean", "abs_spearman_vs_level_mean")) < 0.60:
        if verdict == "usable_with_caution":
            verdict = "structure_not_stable"
        reasons.append("global-vs-level residual ranking has low Spearman correlation")

    lines = [
        "# Phase background subtraction ablation",
        "",
        "## Purpose",
        "",
        "This test checks whether response-loop residual curvature is robust under multiple background subtractions or whether the residual is created by a special clock/background choice.",
        "",
        "This is only a detector-calibration test. It does not prove physical `i`, time, modular flow, AQFT, or Type III behavior.",
        "",
        "## Setup",
        "",
        f"- max level: `{max_level}`",
        f"- nodes: `{len(model.nodes)}`",
        f"- completed local response parents: `{len(data)}`",
        f"- loops: `{len(loops)}`",
        "- kernel: `K(d)=1/(3^(d-1)d^2)`",
        "- methods: `polar`, `eigen`, `G_weighted`",
        "",
        "## Verdict",
        "",
        f"```text\n{verdict}\n```",
        "",
    ]
    if reasons:
        lines += ["Reasons:", ""]
        for r in reasons:
            lines.append(f"- {r}")
        lines.append("")

    lines += [
        "## Polar residual scale by background",
        "",
        "```text",
        f"raw_mean_abs_deg                  = {g('polar','raw','abs_mean_deg'):.12f}",
        f"theta_inf_mean_abs_deg            = {g('polar','theta_inf','abs_mean_deg'):.12f}",
        f"global_mean_abs_deg               = {polar_global:.12f}",
        f"level_mean_abs_deg                = {polar_level:.12f}",
        f"age_mean_abs_deg                  = {g('polar','age_mean','abs_mean_deg'):.12f}",
        f"parent_family_mean_abs_deg        = {polar_family:.12f}",
        f"randomized_level_mean_abs_deg     = {polar_rand:.12f}",
        f"overfit_per_loop_abs_deg          = {polar_overfit:.12f}",
        f"randomized / level_mean ratio     = {rand_ratio:.6f}",
        f"global / level_mean ratio         = {global_ratio:.6f}",
        f"family / level_mean ratio         = {family_ratio:.6f}",
        "```",
        "",
        "## Stability relative to level-mean residuals",
        "",
        "```text",
        f"polar global abs Spearman         = {c('polar','global_mean','abs_spearman_vs_level_mean'):.6f}",
        f"polar age abs Spearman            = {c('polar','age_mean','abs_spearman_vs_level_mean'):.6f}",
        f"polar family abs Spearman         = {c('polar','parent_family_mean','abs_spearman_vs_level_mean'):.6f}",
        f"polar randomized abs Spearman     = {c('polar','randomized_level_mean','abs_spearman_vs_level_mean'):.6f}",
        "```",
        "",
        "## Interpretation",
        "",
        "The residual is not accepted merely because it is small. The relevant checks are:",
        "",
        "1. non-overfit backgrounds should give comparable residual scales and similar localization/ranking;",
        "2. randomized background assignment should alter or damage the residual structure;",
        "3. the overfit control must collapse residuals to zero and is therefore marked as invalid;",
        "4. raw loop phase must remain large enough to distinguish phase-density removal from trivial zero phase.",
        "",
    ]

    if verdict == "usable_with_caution":
        lines += [
            "The result supports using the response-phase residual as a provisional defect observable for the next double-history test, but only with background choice recorded explicitly. It is not a theorem and not yet a canonical CNNA phase.",
            "",
        ]
    else:
        lines += [
            "The result does not fully clear the anti-smuggling test. The response-phase residual should not be used as a hard defect observable without further controls or a more derived background rule.",
            "",
        ]

    lines += [
        "## Next test",
        "",
        "```text",
        "test_provenance_identification_double_history_holonomy.py",
        "```",
        "",
        "Goal: build a controlled effective gluing/quotient where the same effective port is reached by two different birth-history paths, then test whether Record/Live layers produce a nontrivial handoff cocycle/defect.",
        "",
        "Why next: the present test calibrates the phase-background subtraction detector. The next obstruction is whether genuine provenance double-history creates a CNNA-internal holonomy source or whether it also telescopes away.",
    ]

    (outdir / "RESULTS_phase_background_subtraction_ablation.md").write_text("\n".join(lines), encoding="utf-8")


def run(max_level: int, outdir: Path, seed: int, theta_inf: Dict[str, float]) -> str:
    outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    model = ShellGrowth(backreaction=True)
    model.grow_to_level(max_level)
    data = build_data(model, max_level)
    loops = build_loops(model, data)

    all_rows: List[dict] = []
    for method in METHODS:
        all_rows.extend(residual_rows_for_method(data, loops, method, max_level, theta_inf, seed))

    global_rows, mode_rows, level_rows, age_rows, corr_rows = summarize(all_rows)

    fit_rows: List[dict] = []
    for method in METHODS:
        for bg in ALL_BACKGROUNDS:
            lrows = [r for r in level_rows if r["method"] == method and r["background"] == bg]
            fit = fit_decay_by_level(lrows, "abs_mean_deg")
            fit.update({"method": method, "background": bg, "column": "abs_mean_deg"})
            fit_rows.append(fit)

    write_csv(outdir / "phase_background_loop_residuals.csv", all_rows)
    write_csv(outdir / "phase_background_global_summary.csv", global_rows)
    write_csv(outdir / "phase_background_mode_summary.csv", mode_rows)
    write_csv(outdir / "phase_background_level_summary.csv", level_rows)
    write_csv(outdir / "phase_background_age_summary.csv", age_rows)
    write_csv(outdir / "phase_background_correlation_summary.csv", corr_rows)
    write_csv(outdir / "phase_background_decay_fits.csv", fit_rows)

    write_markdown(outdir, max_level, model, data, loops, global_rows, corr_rows, fit_rows)

    def get(method: str, bg: str, col: str) -> float:
        for r in global_rows:
            if r["method"] == method and r["background"] == bg:
                return float(r[col])
        return float("nan")

    def get_corr(method: str, bg: str, col: str) -> float:
        for r in corr_rows:
            if r["method"] == method and r["background"] == bg:
                return float(r[col])
        return float("nan")

    lines = [
        "PHASE BACKGROUND SUBTRACTION ABLATION",
        f"  max_level={max_level}",
        f"  seed={seed}",
        f"  nodes={len(model.nodes)}",
        f"  completed={len(data)}",
        f"  loops={len(loops)}",
        f"  elapsed_sec={time.time() - t0:.3f}",
        "",
        "POLAR GLOBAL SUMMARY",
    ]
    for bg in ALL_BACKGROUNDS:
        lines.append(
            f"  {bg:28s} mean_abs={get('polar', bg, 'abs_mean_deg'):.12f} "
            f"p95={get('polar', bg, 'abs_p95_deg'):.12f} max={get('polar', bg, 'abs_max_deg'):.12f}"
        )
    lines += [
        "",
        "CORRELATION VS LEVEL-MEAN RESIDUALS",
    ]
    for bg in ["theta_inf", "global_mean", "age_mean", "parent_family_mean", "randomized_level_mean", "overfit_per_loop"]:
        lines.append(
            f"  polar {bg:24s} abs_spearman={get_corr('polar', bg, 'abs_spearman_vs_level_mean'):.6f} "
            f"signed_spearman={get_corr('polar', bg, 'signed_spearman_vs_level_mean'):.6f}"
        )
    lines += [
        "",
        "INTERPRETIVE FLAG",
        "  See RESULTS_phase_background_subtraction_ablation.md",
    ]
    summary = "\n".join(lines)
    (outdir / "SUMMARY.txt").write_text(summary, encoding="utf-8")
    return summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-level", type=int, default=9)
    ap.add_argument("--outdir", type=Path, default=Path("phase_background_subtraction_ablation_out_L9"))
    ap.add_argument("--seed", type=int, default=20260616)
    ap.add_argument("--polar-theta-inf", type=float, default=DEFAULT_THETA_INF["polar"])
    ap.add_argument("--eigen-theta-inf", type=float, default=DEFAULT_THETA_INF["eigen"])
    ap.add_argument("--g-theta-inf", type=float, default=DEFAULT_THETA_INF["G_weighted"])
    args = ap.parse_args()
    theta_inf = {"polar": args.polar_theta_inf, "eigen": args.eigen_theta_inf, "G_weighted": args.g_theta_inf}
    print(run(args.max_level, args.outdir, args.seed, theta_inf))


if __name__ == "__main__":
    main()
