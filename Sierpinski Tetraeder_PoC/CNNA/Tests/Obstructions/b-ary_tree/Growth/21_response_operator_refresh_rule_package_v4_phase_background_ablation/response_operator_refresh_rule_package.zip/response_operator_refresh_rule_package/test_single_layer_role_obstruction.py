#!/usr/bin/env python3
"""
CNNA / growing real complement network
Single-layer role obstruction test.

Purpose
-------
Test whether one local response object can carry both roles at once:

1. Record role
   Future-extension-invariant birth/provenance handoff record.

2. Live role
   Future-extension-covariant current response state under later
   descendant/ancestor backreaction.

The obstruction is not defined as the static mismatch between record and live at
completion.  The decisive quantity is live aging:

    || W_live(p, t_final) - W_live(p, t_complete) ||.

If this is nonzero for an old completed parent, then identifying the live state
with an immutable record forces one of two failures:

    record_as_single: violates live covariance
    live_as_single:   violates record invariance

Two-layer semantics avoids this role collision by keeping:

    W_record(p)      = immutable birth/provenance record
    W_state(p, t)    = current live response state

Hard limitation
---------------
This is a numerical role/provenance obstruction test.  It does not prove AQFT,
physical i, physical time, modular flow, additivity, or Type III structure.
"""

from __future__ import annotations

import argparse
import csv
import math
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

from test_response_operator_refresh_rule import ShellNormGrowth, matrix_diagnostics

EPS = 1e-12


def mean(xs: Iterable[float]) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.mean(vals)) if vals else float("nan")


def std(xs: Iterable[float]) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.std(vals)) if vals else float("nan")


def perc(xs: Iterable[float], q: float) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.percentile(vals, q)) if vals else float("nan")


def fro_norm(M: np.ndarray) -> float:
    return float(np.linalg.norm(M, ord="fro"))


def rel_norm_delta(A: np.ndarray, B: np.ndarray) -> float:
    return fro_norm(A - B) / (fro_norm(B) + EPS)


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        return
    keys = sorted({k for r in rows for k in r.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def summarize(rows: List[dict], group_keys: List[str], value_keys: List[str]) -> List[dict]:
    groups: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        groups[tuple(r[k] for k in group_keys)].append(r)
    out = []
    for key, rs in sorted(groups.items()):
        row = {group_keys[i]: key[i] for i in range(len(group_keys))}
        row["count"] = len(rs)
        for vk in value_keys:
            vals = [r[vk] for r in rs if vk in r]
            row[f"{vk}_mean"] = mean(vals)
            row[f"{vk}_std"] = std(vals)
            row[f"{vk}_p50"] = perc(vals, 50)
            row[f"{vk}_p95"] = perc(vals, 95)
            row[f"{vk}_max"] = max([float(v) for v in vals], default=float("nan"))
        out.append(row)
    return out


@dataclass
class RunResult:
    model: ShellNormGrowth
    rows: List[dict]
    same_time_recompute_max: float


def grow_model(max_level: int, backreaction: bool) -> ShellNormGrowth:
    if backreaction:
        model = ShellNormGrowth()
    else:
        model = ShellNormGrowth(br_ancestor=0.0, br_sibling=0.0)
    frontier = [model.root]
    for _gl in range(1, max_level + 1):
        frontier = model.grow_one_level(frontier)
    return model


def collect_rows(model: ShellNormGrowth, max_level: int, label: str, obstruction_eps: float) -> RunResult:
    rows: List[dict] = []
    same_time_recompute_max = 0.0

    for p in model.completed_parent_ids():
        if p not in model.record_completion_matrix or p not in model.live_completion_matrix:
            continue
        R0 = model.record_completion_matrix[p]
        L0 = model.live_completion_matrix[p]
        R1 = model.local_record_matrix(p)
        L1a = model.live_replay_matrix(p)
        L1b = model.live_replay_matrix(p)
        if R1 is None or L1a is None or L1b is None:
            continue

        same_time = fro_norm(L1a - L1b)
        same_time_recompute_max = max(same_time_recompute_max, same_time)

        record_drift_abs = fro_norm(R1 - R0)
        record_drift_rel = rel_norm_delta(R1, R0)
        live_aging_abs = fro_norm(L1a - L0)
        live_aging_rel = rel_norm_delta(L1a, L0)

        # Static mismatch is reported for audit only; it is not the obstruction definition.
        mismatch_completion_abs = fro_norm(R0 - L0)
        mismatch_final_abs = fro_norm(R1 - L1a)
        mismatch_growth_abs = abs(mismatch_final_abs - mismatch_completion_abs)

        # Role-violation diagnostics under single-layer identifications.
        record_as_single_live_violation = live_aging_abs
        live_as_single_record_violation = live_aging_abs

        age = max_level - int(model.completion_level[p])
        parent_level = int(model.nodes[p].level)
        distance_to_frontier = max(0, max_level - 1 - parent_level)
        child_g = model.child_g_vector(p)
        child_g0 = model.completion_child_g[p]
        child_delta = child_g - child_g0

        dL = matrix_diagnostics(L1a)
        dR = matrix_diagnostics(R1)
        theta_live = float(dL["theta_deg"]) if dL is not None else float("nan")
        theta_record = float(dR["theta_deg"]) if dR is not None else float("nan")
        J2_live = float(dL["J2_resid"]) if dL is not None else float("nan")
        J2_record = float(dR["J2_resid"]) if dR is not None else float("nan")
        axis_live_norm = float(dL["axis_norm_raw"]) if dL is not None else float("nan")
        axis_record_norm = float(dR["axis_norm_raw"]) if dR is not None else float("nan")

        rows.append({
            "run_label": label,
            "max_level": max_level,
            "parent": p,
            "parent_level": parent_level,
            "completion_level": int(model.completion_level[p]),
            "age": age,
            "distance_to_frontier": distance_to_frontier,
            "record_drift_abs": record_drift_abs,
            "record_drift_rel": record_drift_rel,
            "live_aging_abs": live_aging_abs,
            "live_aging_rel": live_aging_rel,
            "single_layer_violation_abs": live_aging_abs,
            "single_layer_violation_rel": live_aging_rel,
            "record_as_single_live_violation_abs": record_as_single_live_violation,
            "live_as_single_record_violation_abs": live_as_single_record_violation,
            "mismatch_completion_abs": mismatch_completion_abs,
            "mismatch_final_abs": mismatch_final_abs,
            "mismatch_growth_abs": mismatch_growth_abs,
            "obstructed_abs": float(live_aging_abs > obstruction_eps),
            "obstructed_rel": float(live_aging_rel > obstruction_eps),
            "same_time_recompute_abs": same_time,
            "child_g_delta_mean": float(np.mean(child_delta)),
            "child_g_delta_max": float(np.max(np.abs(child_delta))),
            "child_g_rel_std": float(np.std(child_g) / (np.mean(child_g) + EPS)),
            "descendant_count": int(model.descendant_count(p)),
            "desc_shell_load": float(model.descendant_shell_birth_load(p)),
            "ancestor_env_delta": float(model.ancestor_env_load(p) - model.completion_ancestor_env[p]),
            "theta_live_deg": theta_live,
            "theta_record_deg": theta_record,
            "J2_live_resid": J2_live,
            "J2_record_resid": J2_record,
            "axis_live_norm_raw": axis_live_norm,
            "axis_record_norm_raw": axis_record_norm,
        })

    return RunResult(model=model, rows=rows, same_time_recompute_max=same_time_recompute_max)


def conclusion_from_rows(main_rows: List[dict], control_rows: List[dict], obstruction_eps: float) -> Tuple[str, List[str]]:
    aged = [r for r in main_rows if r["age"] > 0]
    aged_control = [r for r in control_rows if r["age"] > 0]
    main_live_max = max([r["live_aging_abs"] for r in aged], default=0.0)
    main_live_mean = mean([r["live_aging_abs"] for r in aged])
    control_live_max = max([r["live_aging_abs"] for r in aged_control], default=0.0)
    record_max = max([r["record_drift_abs"] for r in main_rows], default=0.0)
    frac_obstructed_aged = mean([r["obstructed_abs"] for r in aged])

    reasons = []
    if record_max <= obstruction_eps:
        reasons.append("record_drift is numerically zero within tolerance")
    else:
        reasons.append("record_drift is not zero; record layer implementation must be audited")
    if main_live_max > obstruction_eps and main_live_mean > obstruction_eps:
        reasons.append("live response ages under nontrivial backreaction")
    else:
        reasons.append("live response does not age significantly under the tested dynamics")
    if control_live_max <= obstruction_eps:
        reasons.append("no-backreaction control removes live aging")
    else:
        reasons.append("no-backreaction control still ages; live replay rule must be audited")
    if frac_obstructed_aged > 0.5:
        reasons.append("most aged parents are single-layer obstructed")
    else:
        reasons.append("only a minority of aged parents are obstructed")

    if record_max <= obstruction_eps and main_live_max > obstruction_eps and control_live_max <= obstruction_eps and frac_obstructed_aged > 0.5:
        return "single_layer_obstructed", reasons
    return "single_layer_not_obstructed_by_this_test", reasons


def write_markdown_report(path: Path, max_level: int, obstruction_eps: float, main_rows: List[dict], control_rows: List[dict], conclusion: str, reasons: List[str]) -> None:
    aged = [r for r in main_rows if r["age"] > 0]
    aged_control = [r for r in control_rows if r["age"] > 0]
    old = [r for r in main_rows if r["distance_to_frontier"] >= 3]
    frontier = [r for r in main_rows if r["distance_to_frontier"] == 0]

    md = []
    md.append("# CNNA single-layer role obstruction test")
    md.append("")
    md.append("## Purpose")
    md.append("")
    md.append("This test checks whether a single local response operator can simultaneously serve as an immutable birth/provenance record and as a current live response state under later descendant/ancestor backreaction.")
    md.append("")
    md.append("The obstruction quantity is not the static record/live mismatch at completion. The decisive quantity is:")
    md.append("")
    md.append("```text")
    md.append("live_aging(p) = || W_live(p, t_final) - W_live(p, t_complete) ||_F")
    md.append("```")
    md.append("")
    md.append("If `live_aging(p) > eps` while `record_drift(p) ≈ 0`, then a single-layer identification forces either loss of record invariance or loss of live covariance.")
    md.append("")
    md.append("## Parameters")
    md.append("")
    md.append(f"- `max_level`: {max_level}")
    md.append("- branching: `3`")
    md.append("- kernel: `shell_norm_inverse_square = 1/(3^(d-1) d^2)`")
    md.append(f"- obstruction epsilon: `{obstruction_eps}`")
    md.append("")
    md.append("## Main numerical result")
    md.append("")
    md.append("```text")
    md.append(f"conclusion: {conclusion}")
    md.append(f"parents total: {len(main_rows)}")
    md.append(f"aged parents: {len(aged)}")
    md.append(f"record_drift_abs max: {max([r['record_drift_abs'] for r in main_rows], default=float('nan')):.12e}")
    md.append(f"live_aging_abs mean aged: {mean([r['live_aging_abs'] for r in aged]):.12e}")
    md.append(f"live_aging_abs max aged: {max([r['live_aging_abs'] for r in aged], default=float('nan')):.12e}")
    md.append(f"fraction obstructed aged: {mean([r['obstructed_abs'] for r in aged]):.9f}")
    md.append(f"no_backreaction live_aging_abs max aged: {max([r['live_aging_abs'] for r in aged_control], default=float('nan')):.12e}")
    md.append("```")
    md.append("")
    md.append("## Why this supports two-layer semantics")
    md.append("")
    md.append("Under nontrivial backreaction, the live response of old completed parents changes after completion, while the birth/provenance record remains fixed. Therefore:")
    md.append("")
    md.append("```text")
    md.append("record_as_single:")
    md.append("  W_single := W_record")
    md.append("  -> keeps provenance invariant")
    md.append("  -> fails to track live aging")
    md.append("")
    md.append("live_as_single:")
    md.append("  W_single := W_live(t)")
    md.append("  -> tracks current state")
    md.append("  -> rewrites the historical record")
    md.append("")
    md.append("two_layer:")
    md.append("  W_record := W_birth")
    md.append("  W_state(t) := W_live(t)")
    md.append("  -> separates the two roles")
    md.append("```")
    md.append("")
    md.append("## Controls")
    md.append("")
    md.append("```text")
    md.append(f"same_time_recompute max main: {max([r['same_time_recompute_abs'] for r in main_rows], default=float('nan')):.12e}")
    md.append(f"no_backreaction record_drift_abs max: {max([r['record_drift_abs'] for r in control_rows], default=float('nan')):.12e}")
    md.append(f"no_backreaction live_aging_abs max aged: {max([r['live_aging_abs'] for r in aged_control], default=float('nan')):.12e}")
    md.append("```")
    md.append("")
    md.append("The no-backreaction control is essential: when later births do not update old conductances, the obstruction disappears. This localizes the obstruction to nontrivial dynamic backreaction rather than to CSV handling, recomputation noise, or a static record/live convention.")
    md.append("")
    md.append("## Interior versus frontier")
    md.append("")
    md.append("```text")
    md.append(f"frontier parents count: {len(frontier)}")
    md.append(f"frontier live_aging_abs mean: {mean([r['live_aging_abs'] for r in frontier]):.12e}")
    md.append(f"old interior parents count distance>=3: {len(old)}")
    md.append(f"old interior live_aging_abs mean: {mean([r['live_aging_abs'] for r in old]):.12e}")
    md.append(f"old interior single_layer_violation_rel mean: {mean([r['single_layer_violation_rel'] for r in old]):.12e}")
    md.append("```")
    md.append("")
    md.append("Global-level age-zero frontier parents have no deeper descendant-level aging yet, but they can already show same-level environment aging because later sequential births may update shared ancestors. The stronger obstruction is visible in already completed local records after subsequent network extension.")
    md.append("")
    md.append("## Reasons")
    md.append("")
    for reason in reasons:
        md.append(f"- {reason}")
    md.append("")
    md.append("## Interpretation guard")
    md.append("")
    md.append("This is a CNNA-internal role/provenance obstruction test. It does not establish AQFT additivity, the physical complex unit, modular flow, physical time, or Type III structure. It only supports the provisional model object `ResponseRecord x LiveResponseState` under nontrivial aging.")
    md.append("")
    path.write_text("\n".join(md), encoding="utf-8")


def run(max_level: int, outdir: Path, obstruction_eps: float) -> str:
    outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    main_model = grow_model(max_level=max_level, backreaction=True)
    main = collect_rows(main_model, max_level=max_level, label="main_backreaction", obstruction_eps=obstruction_eps)

    control_model = grow_model(max_level=max_level, backreaction=False)
    control = collect_rows(control_model, max_level=max_level, label="no_backreaction_control", obstruction_eps=obstruction_eps)

    all_rows = main.rows + control.rows
    conclusion, reasons = conclusion_from_rows(main.rows, control.rows, obstruction_eps)

    by_age = summarize(
        all_rows,
        ["run_label", "age"],
        ["record_drift_abs", "live_aging_abs", "live_aging_rel", "single_layer_violation_abs", "mismatch_growth_abs", "obstructed_abs", "ancestor_env_delta", "desc_shell_load", "child_g_delta_max"],
    )
    by_distance = summarize(
        all_rows,
        ["run_label", "distance_to_frontier"],
        ["record_drift_abs", "live_aging_abs", "live_aging_rel", "single_layer_violation_abs", "mismatch_growth_abs", "obstructed_abs", "ancestor_env_delta", "desc_shell_load", "child_g_delta_max"],
    )
    by_parent_level = summarize(
        all_rows,
        ["run_label", "parent_level"],
        ["record_drift_abs", "live_aging_abs", "live_aging_rel", "single_layer_violation_abs", "mismatch_growth_abs", "obstructed_abs", "ancestor_env_delta", "desc_shell_load", "child_g_delta_max"],
    )
    global_summary = summarize(
        all_rows,
        ["run_label"],
        ["record_drift_abs", "live_aging_abs", "live_aging_rel", "single_layer_violation_abs", "mismatch_growth_abs", "obstructed_abs", "same_time_recompute_abs", "J2_live_resid", "J2_record_resid"],
    )

    write_csv(outdir / "parent_obstruction_table.csv", all_rows)
    write_csv(outdir / "obstruction_by_age.csv", by_age)
    write_csv(outdir / "obstruction_by_distance.csv", by_distance)
    write_csv(outdir / "obstruction_by_parent_level.csv", by_parent_level)
    write_csv(outdir / "obstruction_global_summary.csv", global_summary)

    report = outdir / "RESULTS_single_layer_role_obstruction.md"
    write_markdown_report(report, max_level, obstruction_eps, main.rows, control.rows, conclusion, reasons)

    aged_main = [r for r in main.rows if r["age"] > 0]
    aged_control = [r for r in control.rows if r["age"] > 0]
    lines = []
    lines.append("SINGLE-LAYER ROLE OBSTRUCTION TEST")
    lines.append(f"  max_level={max_level}")
    lines.append("  kernel=shell_norm_inverse_square = 1/(3^(d-1) d^2)")
    lines.append(f"  obstruction_eps={obstruction_eps:.3e}")
    lines.append("")
    lines.append("HYPOTHESIS")
    lines.append("  nontrivial aging + record invariance + live covariance obstructs single-layer identification")
    lines.append("")
    lines.append("MAIN BACKREACTION RUN")
    lines.append(f"  parents_total={len(main.rows)}")
    lines.append(f"  aged_parents={len(aged_main)}")
    lines.append(f"  record_drift_abs_mean={mean([r['record_drift_abs'] for r in main.rows]):.12e}")
    lines.append(f"  record_drift_abs_max={max([r['record_drift_abs'] for r in main.rows], default=float('nan')):.12e}")
    lines.append(f"  live_aging_abs_mean_aged={mean([r['live_aging_abs'] for r in aged_main]):.12e}")
    lines.append(f"  live_aging_abs_max_aged={max([r['live_aging_abs'] for r in aged_main], default=float('nan')):.12e}")
    lines.append(f"  live_aging_rel_mean_aged={mean([r['live_aging_rel'] for r in aged_main]):.12e}")
    lines.append(f"  fraction_obstructed_aged={mean([r['obstructed_abs'] for r in aged_main]):.9f}")
    lines.append(f"  same_time_recompute_abs_max={main.same_time_recompute_max:.12e}")
    lines.append("")
    lines.append("NO-BACKREACTION CONTROL")
    lines.append(f"  parents_total={len(control.rows)}")
    lines.append(f"  aged_parents={len(aged_control)}")
    lines.append(f"  record_drift_abs_max={max([r['record_drift_abs'] for r in control.rows], default=float('nan')):.12e}")
    lines.append(f"  live_aging_abs_max_aged={max([r['live_aging_abs'] for r in aged_control], default=float('nan')):.12e}")
    lines.append(f"  fraction_obstructed_aged={mean([r['obstructed_abs'] for r in aged_control]):.9f}")
    lines.append(f"  same_time_recompute_abs_max={control.same_time_recompute_max:.12e}")
    lines.append("")
    lines.append("ROLE DIAGNOSIS")
    lines.append("  record_as_single_violation = live_aging_abs")
    lines.append("  live_as_single_violation   = live_aging_abs")
    lines.append("  two_layer separates W_record and W_state(t)")
    lines.append("")
    lines.append(f"CONCLUSION: {conclusion}")
    for reason in reasons:
        lines.append(f"  - {reason}")
    lines.append("")
    lines.append(f"elapsed_seconds={time.time() - t0:.3f}")

    summary = "\n".join(lines)
    (outdir / "SUMMARY.txt").write_text(summary, encoding="utf-8")
    return summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-level", type=int, default=9)
    ap.add_argument("--outdir", type=Path, default=Path("single_layer_role_obstruction_out_L9"))
    ap.add_argument("--obstruction-eps", type=float, default=1e-9)
    args = ap.parse_args()
    print(run(args.max_level, args.outdir, args.obstruction_eps))


if __name__ == "__main__":
    main()
