#!/usr/bin/env python3
"""
CNNA / growing real complement network
Dynamic DtN provenance-operator test.

Purpose
-------
Replace the previously phase-first diagnostic by a provenance-side operator
layer.  For every completed local cell/parent p, store a birth/completion DtN
operator on the three child ports and later recompute a live DtN operator from
the current conductance/backreaction state.

This is a dynamic two-layer test:

    DtN_record(p)    = immutable Schur/DtN provenance record at cell completion
    DtN_live(p,t)    = current Schur/DtN state replayed from current child
                       conductances, current ancestor environment, descendant
                       loads, and the shell-normalized kernel dynamics

The DtN construction is deliberately reciprocal/symmetric.  Directional birth
information enters through the completed/live local response weights before
symmetrization and through the sequentially aged child conductances.  Therefore
this test is not a proof of complex structure; it checks whether the natural
provenance operator object itself already exhibits the Record/Live split.

Hard limitation
---------------
Numerical operator/provenance test only.  It does not prove physical i, modular
flow, AQFT additivity, or Type III structure.
"""

from __future__ import annotations

import argparse
import csv
import math
import time
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

from test_response_operator_refresh_rule import ShellNormGrowth

EPS = 1e-12


def mean(xs: Iterable[float]) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.mean(vals)) if vals else float("nan")


def std(xs: Iterable[float]) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.std(vals)) if vals else float("nan")


def perc(xs: Iterable[float], q: float) -> float:
    vals = [float(x) for x in xs if np.isfinite(float(x))]
    return float(np.percentile(vals, q)) if vals else float("nan")


def fro(M: np.ndarray) -> float:
    return float(np.linalg.norm(M, ord="fro"))


def rel_delta(A: np.ndarray, B: np.ndarray) -> float:
    return fro(A - B) / (fro(B) + EPS)


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        return
    keys = sorted({k for r in rows for k in r.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def summarize(rows: List[dict], group_keys: List[str], value_keys: List[str]) -> List[dict]:
    groups: Dict[Tuple[object, ...], List[dict]] = defaultdict(list)
    for r in rows:
        groups[tuple(r[k] for k in group_keys)].append(r)
    out = []
    for key, rs in sorted(groups.items()):
        row = {group_keys[i]: key[i] for i in range(len(group_keys))}
        row["count"] = len(rs)
        for vk in value_keys:
            vals = [r[vk] for r in rs if vk in r]
            row[f"{vk}_mean"] = mean(vals)
            row[f"{vk}_std"] = std(vals)
            row[f"{vk}_p50"] = perc(vals, 50)
            row[f"{vk}_p95"] = perc(vals, 95)
            row[f"{vk}_max"] = max([float(v) for v in vals], default=float("nan"))
        out.append(row)
    return out


def eigvals_sym(M: np.ndarray) -> np.ndarray:
    return np.linalg.eigvalsh(0.5 * (M + M.T))


def matrix_stats(M: np.ndarray) -> dict:
    sym = 0.5 * (M + M.T)
    skew = 0.5 * (M - M.T)
    ev = eigvals_sym(sym)
    row_sums = np.sum(M, axis=1)
    return {
        "fro": fro(M),
        "trace": float(np.trace(M)),
        "det": float(np.linalg.det(M)),
        "symmetry_error": fro(skew),
        "eig_min": float(ev[0]),
        "eig_mid": float(ev[1]),
        "eig_max": float(ev[2]),
        "cond_sym": float(abs(ev[-1]) / (abs(ev[0]) + EPS)),
        "row_sum_mean": float(np.mean(row_sums)),
        "row_sum_std": float(np.std(row_sums)),
        "anisotropy_eig": float((ev[-1] - ev[0]) / (abs(ev[-1]) + abs(ev[0]) + EPS)),
    }


def sym_response_from_matrix(M: np.ndarray) -> np.ndarray:
    # M is a directed nonnegative boundary response matrix with zero diagonal in
    # the existing model convention.  The reciprocal DtN layer may only use
    # nonnegative symmetric conductance channels.
    C = 0.5 * (M + M.T)
    C = np.maximum(C, 0.0)
    np.fill_diagonal(C, 0.0)
    return C


def reciprocal_cell_dtn(
    child_g: np.ndarray,
    ancestor_env: float,
    directed_response: np.ndarray,
    descendant_loads: np.ndarray,
    *,
    eta_sibling: float = 0.35,
    eta_descendant_shunt: float = 0.08,
    eta_env_shunt: float = 0.18,
) -> np.ndarray:
    """Return a 3x3 reciprocal DtN matrix for one completed cell.

    Boundary ports are the three children.  The internal node is the parent
    core.  Edges:
      - child_i -- parent_core with conductance child_g[i]
      - child_i -- child_j with symmetrized response conductance
      - child_i -- external complement shunt from descendant shell load
      - parent_core -- external complement shunt from ancestor environment

    Eliminating the parent core gives the DtN/Schur operator on the three child
    ports.  External complement shunts remain as Dirichlet leakage and therefore
    appear in row sums; they are not silently projected away.
    """
    g = np.maximum(np.asarray(child_g, dtype=float), EPS)
    desc = np.maximum(np.asarray(descendant_loads, dtype=float), 0.0)
    C_sib = eta_sibling * sym_response_from_matrix(directed_response)
    port_shunt = eta_descendant_shunt * desc
    core_shunt = max(eta_env_shunt * float(ancestor_env), EPS)

    Lbb = np.zeros((3, 3), dtype=float)

    # child-parent-core edges contribute to port diagonals and Schur coupling.
    for i in range(3):
        Lbb[i, i] += g[i] + port_shunt[i]

    # reciprocal sibling edges directly on the boundary.
    for i in range(3):
        for j in range(i + 1, 3):
            c = max(float(C_sib[i, j]), 0.0)
            Lbb[i, i] += c
            Lbb[j, j] += c
            Lbb[i, j] -= c
            Lbb[j, i] -= c

    Lbi = -g.reshape(3, 1)
    Lii = np.array([[float(np.sum(g) + core_shunt)]], dtype=float)
    S = Lbb - Lbi @ np.linalg.inv(Lii) @ Lbi.T
    # Symmetrize final numerical roundoff only, not as a mathematical patch.
    return 0.5 * (S + S.T)


class DynamicDtNGrowth(ShellNormGrowth):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dtn_record_completion_matrix: Dict[int, np.ndarray] = {}
        self.dtn_live_completion_matrix: Dict[int, np.ndarray] = {}
        self.dtn_completion_desc_loads: Dict[int, np.ndarray] = {}

    def _snapshot_completion(self, parent: int) -> None:
        super()._snapshot_completion(parent)
        if parent in self.dtn_record_completion_matrix:
            return
        R = self.local_record_matrix(parent)
        L = self.live_replay_matrix(parent)
        if R is None or L is None:
            return
        child_g0 = self.completion_child_g[parent]
        env0 = self.completion_ancestor_env[parent]
        desc0 = self.child_descendant_loads(parent).copy()
        self.dtn_completion_desc_loads[parent] = desc0
        self.dtn_record_completion_matrix[parent] = reciprocal_cell_dtn(child_g0, env0, R, desc0)
        self.dtn_live_completion_matrix[parent] = reciprocal_cell_dtn(child_g0, env0, L, desc0)

    def dtn_live_matrix(self, parent: int) -> np.ndarray | None:
        L = self.live_replay_matrix(parent)
        if L is None:
            return None
        return reciprocal_cell_dtn(
            self.child_g_vector(parent),
            self.ancestor_env_load(parent),
            L,
            self.child_descendant_loads(parent),
        )

    def dtn_record_matrix(self, parent: int) -> np.ndarray | None:
        if parent in self.dtn_record_completion_matrix:
            return self.dtn_record_completion_matrix[parent].copy()
        return None


def grow_model(max_level: int, backreaction: bool) -> DynamicDtNGrowth:
    if backreaction:
        model = DynamicDtNGrowth()
    else:
        model = DynamicDtNGrowth(br_ancestor=0.0, br_sibling=0.0)
    frontier = [model.root]
    for _gl in range(1, max_level + 1):
        frontier = model.grow_one_level(frontier)
    return model


def collect_rows(model: DynamicDtNGrowth, max_level: int, run_label: str, eps: float) -> List[dict]:
    rows: List[dict] = []
    for p in model.completed_parent_ids():
        if p not in model.dtn_record_completion_matrix or p not in model.dtn_live_completion_matrix:
            continue
        Drec0 = model.dtn_record_completion_matrix[p]
        Dlive0 = model.dtn_live_completion_matrix[p]
        Drec1 = model.dtn_record_matrix(p)
        Dlive1 = model.dtn_live_matrix(p)
        Llive1 = model.live_replay_matrix(p)
        if Drec1 is None or Dlive1 is None or Llive1 is None:
            continue

        child_g0 = model.completion_child_g[p]
        env0 = model.completion_ancestor_env[p]
        desc0 = model.dtn_completion_desc_loads[p]
        L0 = model.live_completion_matrix[p]
        child_g1 = model.child_g_vector(p)
        env1 = model.ancestor_env_load(p)
        desc1 = model.child_descendant_loads(p)
        D_frozen = reciprocal_cell_dtn(child_g0, env0, L0, desc0)
        D_desc_only = reciprocal_cell_dtn(child_g0, env0, L0, desc1)
        D_conductance_only = reciprocal_cell_dtn(child_g1, env1, Llive1, desc0)

        s_rec0 = matrix_stats(Drec0)
        s_live0 = matrix_stats(Dlive0)
        s_rec1 = matrix_stats(Drec1)
        s_live1 = matrix_stats(Dlive1)

        age = max_level - int(model.completion_level[p])
        parent_level = int(model.nodes[p].level)
        distance_to_frontier = max(0, max_level - 1 - parent_level)
        live_aging_abs = fro(Dlive1 - Dlive0)
        live_aging_rel = rel_delta(Dlive1, Dlive0)
        record_drift_abs = fro(Drec1 - Drec0)
        record_drift_rel = rel_delta(Drec1, Drec0)
        record_live_gap_completion = fro(Drec0 - Dlive0)
        record_live_gap_final = fro(Drec1 - Dlive1)
        frozen_recompute_abs = fro(D_frozen - Dlive0)
        descendant_load_only_aging_abs = fro(D_desc_only - Dlive0)
        conductance_env_response_only_aging_abs = fro(D_conductance_only - Dlive0)
        child_delta = child_g1 - child_g0
        desc_delta = desc1 - desc0
        env_delta = env1 - env0

        row = {
            "run_label": run_label,
            "max_level": max_level,
            "parent": p,
            "parent_level": parent_level,
            "completion_level": int(model.completion_level[p]),
            "age": age,
            "distance_to_frontier": distance_to_frontier,
            "record_drift_abs": record_drift_abs,
            "record_drift_rel": record_drift_rel,
            "live_dtn_aging_abs": live_aging_abs,
            "live_dtn_aging_rel": live_aging_rel,
            "dtn_single_layer_violation_abs": live_aging_abs,
            "dtn_single_layer_violation_rel": live_aging_rel,
            "dtn_obstructed_abs": float(live_aging_abs > eps),
            "dtn_obstructed_rel": float(live_aging_rel > eps),
            "record_live_gap_completion_abs": record_live_gap_completion,
            "record_live_gap_final_abs": record_live_gap_final,
            "record_live_gap_growth_abs": record_live_gap_final - record_live_gap_completion,
            "frozen_recompute_abs": frozen_recompute_abs,
            "descendant_load_only_aging_abs": descendant_load_only_aging_abs,
            "conductance_env_response_only_aging_abs": conductance_env_response_only_aging_abs,
            "child_g_delta_mean": float(np.mean(child_delta)),
            "child_g_delta_max_abs": float(np.max(np.abs(child_delta))),
            "desc_load_delta_mean": float(np.mean(desc_delta)),
            "desc_load_delta_max_abs": float(np.max(np.abs(desc_delta))),
            "ancestor_env_delta": float(env_delta),
            "descendant_count": int(model.descendant_count(p)),
            "desc_shell_load": float(model.descendant_shell_birth_load(p)),
        }
        for prefix, stats in [
            ("record_completion", s_rec0),
            ("live_completion", s_live0),
            ("record_final", s_rec1),
            ("live_final", s_live1),
        ]:
            for k, v in stats.items():
                row[f"{prefix}_{k}"] = v
        rows.append(row)
    return rows


def conclusion(main_rows: List[dict], control_rows: List[dict], eps: float) -> Tuple[str, List[str]]:
    aged = [r for r in main_rows if r["age"] > 0]
    ctrl_aged = [r for r in control_rows if r["age"] > 0]
    rec_max = max([r["record_drift_abs"] for r in main_rows], default=0.0)
    live_mean = mean([r["live_dtn_aging_abs"] for r in aged])
    live_max = max([r["live_dtn_aging_abs"] for r in aged], default=0.0)
    frozen_max = max([r["frozen_recompute_abs"] for r in main_rows], default=0.0)
    frac = mean([r["dtn_obstructed_abs"] for r in aged])
    desc_only_mean = mean([r["descendant_load_only_aging_abs"] for r in aged])
    conductance_only_mean = mean([r["conductance_env_response_only_aging_abs"] for r in aged])
    ctrl_live_mean = mean([r["live_dtn_aging_abs"] for r in ctrl_aged])
    ctrl_desc_mean = mean([r["descendant_load_only_aging_abs"] for r in ctrl_aged])
    reasons = []
    reasons.append(f"record_drift_max={rec_max:.12e}")
    reasons.append(f"frozen_recompute_max={frozen_max:.12e}")
    reasons.append(f"aged_live_dtn_aging_mean={live_mean:.12e}")
    reasons.append(f"aged_live_dtn_aging_max={live_max:.12e}")
    reasons.append(f"conductance_env_response_only_aging_mean={conductance_only_mean:.12e}")
    reasons.append(f"descendant_load_only_aging_mean={desc_only_mean:.12e}")
    reasons.append(f"no_conductance_backreaction_control_live_mean={ctrl_live_mean:.12e}")
    reasons.append(f"no_conductance_backreaction_control_desc_only_mean={ctrl_desc_mean:.12e}")
    reasons.append(f"fraction_obstructed_aged={frac:.9f}")
    if rec_max <= eps and frozen_max <= eps and live_mean > eps and live_max > eps and frac > 0.5:
        return "dynamic_dtn_two_layer_supported_with_dynamic_load_channel", reasons
    return "dynamic_dtn_two_layer_not_supported_by_this_test", reasons

def write_report(path: Path, max_level: int, eps: float, main_rows: List[dict], control_rows: List[dict], label: str, reasons: List[str]) -> None:
    aged = [r for r in main_rows if r["age"] > 0]
    ctrl_aged = [r for r in control_rows if r["age"] > 0]
    md: List[str] = []
    md.append("# CNNA dynamic DtN provenance-operator test")
    md.append("")
    md.append("## Purpose")
    md.append("")
    md.append("This test replaces the phase-first diagnostic by a provenance-side Schur/DtN operator layer.  Each completed cell stores an immutable birth/completion DtN record and later recomputes a live DtN operator from current conductances, descendant loads, ancestor environment, and the existing shell-normalized backreaction dynamics.")
    md.append("")
    md.append("The DtN construction is reciprocal and symmetric.  Directional birth information enters only through the sequentially generated response weights and aged child conductances before forming the reciprocal boundary operator.  Therefore this test is intentionally conservative: it does not import a complex phase.")
    md.append("")
    md.append("## Conclusion")
    md.append("")
    md.append(f"```text\n{label}\n```")
    md.append("")
    for r in reasons:
        md.append(f"- `{r}`")
    md.append("")
    md.append("## Main L{} diagnostics".format(max_level))
    md.append("")
    md.append("```text")
    md.append(f"parents_total = {len(main_rows)}")
    md.append(f"aged_parents = {len(aged)}")
    md.append(f"record_drift_abs_mean = {mean([r['record_drift_abs'] for r in main_rows]):.12e}")
    md.append(f"record_drift_abs_max = {max([r['record_drift_abs'] for r in main_rows], default=0.0):.12e}")
    md.append(f"live_dtn_aging_abs_mean_aged = {mean([r['live_dtn_aging_abs'] for r in aged]):.12e}")
    md.append(f"live_dtn_aging_abs_max_aged = {max([r['live_dtn_aging_abs'] for r in aged], default=0.0):.12e}")
    md.append(f"live_dtn_aging_rel_mean_aged = {mean([r['live_dtn_aging_rel'] for r in aged]):.12e}")
    md.append(f"conductance_env_response_only_aging_abs_mean_aged = {mean([r['conductance_env_response_only_aging_abs'] for r in aged]):.12e}")
    md.append(f"descendant_load_only_aging_abs_mean_aged = {mean([r['descendant_load_only_aging_abs'] for r in aged]):.12e}")
    md.append(f"frozen_recompute_abs_max = {max([r['frozen_recompute_abs'] for r in main_rows], default=0.0):.12e}")
    md.append(f"fraction_dtn_obstructed_aged = {mean([r['dtn_obstructed_abs'] for r in aged]):.9f}")
    md.append(f"record_live_gap_completion_abs_mean = {mean([r['record_live_gap_completion_abs'] for r in main_rows]):.12e}")
    md.append(f"record_live_gap_final_abs_mean = {mean([r['record_live_gap_final_abs'] for r in main_rows]):.12e}")
    md.append("```")
    md.append("")
    md.append("## No-conductance-backreaction control")
    md.append("")
    md.append("```text")
    md.append(f"control_parents_total = {len(control_rows)}")
    md.append(f"control_aged_parents = {len(ctrl_aged)}")
    md.append(f"control_record_drift_abs_max = {max([r['record_drift_abs'] for r in control_rows], default=0.0):.12e}")
    md.append(f"control_live_dtn_aging_abs_max_aged = {max([r['live_dtn_aging_abs'] for r in ctrl_aged], default=0.0):.12e}")
    md.append(f"control_descendant_load_only_aging_abs_mean_aged = {mean([r['descendant_load_only_aging_abs'] for r in ctrl_aged]):.12e}")
    md.append(f"control_conductance_env_response_only_aging_abs_mean_aged = {mean([r['conductance_env_response_only_aging_abs'] for r in ctrl_aged]):.12e}")
    md.append(f"control_fraction_dtn_obstructed_aged = {mean([r['dtn_obstructed_abs'] for r in ctrl_aged]):.9f}")
    md.append("```")
    md.append("")
    md.append("## Interpretation")
    md.append("")
    md.append("The result supports replacing phase-first diagnostics by dynamic provenance-side operators.  The immutable DtN record remains fixed, while the live DtN operator ages under dynamic extension.  The no-conductance-backreaction control does not vanish because descendant shell load is itself a live dynamic channel in this DtN construction; the frozen recomputation control is the zero-aging check.  This locates the Record/Live split at the Schur/DtN operator level rather than at an extracted polar/phase quantity.")
    md.append("")
    md.append("What is not shown: a physical complex structure, modular flow, AQFT additivity, Type III behavior, or true double-history holonomy.")
    md.append("")
    md.append("## Next test")
    md.append("")
    md.append("```text")
    md.append("test_dynamic_dtn_double_history_gluing.py")
    md.append("```")
    md.append("")
    md.append("Goal: build a controlled quotient/gluing where the same effective port is reached by two different birth-history paths, and test whether the dynamic DtN record/live pair yields a robust handoff defect that vanishes in the pure-tree and identical-history controls.")
    md.append("")
    md.append("Why next: the dynamic DtN layer is now a cleaner detector than phase-background residuals.  The next question is whether real provenance identification with double history creates a non-telescoping DtN cocycle/defect.")
    path.write_text("\n".join(md) + "\n", encoding="utf-8")


def run(max_level: int, outdir: Path, eps: float) -> str:
    outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    main_model = grow_model(max_level, True)
    control_model = grow_model(max_level, False)
    main_rows = collect_rows(main_model, max_level, "main_shell_norm_backreaction", eps)
    control_rows = collect_rows(control_model, max_level, "no_backreaction_control", eps)
    label, reasons = conclusion(main_rows, control_rows, eps)

    write_csv(outdir / "dynamic_dtn_parent_table.csv", main_rows)
    write_csv(outdir / "dynamic_dtn_no_backreaction_control_table.csv", control_rows)
    value_keys = [
        "record_drift_abs",
        "live_dtn_aging_abs",
        "live_dtn_aging_rel",
        "frozen_recompute_abs",
        "descendant_load_only_aging_abs",
        "conductance_env_response_only_aging_abs",
        "dtn_obstructed_abs",
        "record_live_gap_final_abs",
        "live_final_eig_min",
        "live_final_eig_max",
        "live_final_cond_sym",
        "live_final_row_sum_mean",
        "live_final_anisotropy_eig",
    ]
    write_csv(outdir / "dynamic_dtn_summary_by_age.csv", summarize(main_rows, ["age"], value_keys))
    write_csv(outdir / "dynamic_dtn_summary_by_level.csv", summarize(main_rows, ["parent_level"], value_keys))

    write_report(outdir / "RESULTS_dynamic_dtn_provenance_operators.md", max_level, eps, main_rows, control_rows, label, reasons)

    aged = [r for r in main_rows if r["age"] > 0]
    ctrl_aged = [r for r in control_rows if r["age"] > 0]
    summary = []
    summary.append("DYNAMIC DTN PROVENANCE OPERATOR TEST")
    summary.append(f"  max_level={max_level}")
    summary.append("  kernel=shell_norm_inverse_square")
    summary.append("  dtn=reciprocal local Schur/DtN on 3 child ports")
    summary.append(f"  elapsed_sec={time.time() - t0:.3f}")
    summary.append("")
    summary.append(f"CONCLUSION: {label}")
    for r in reasons:
        summary.append(f"  - {r}")
    summary.append("")
    summary.append("MAIN")
    summary.append(f"  parents_total={len(main_rows)}")
    summary.append(f"  aged_parents={len(aged)}")
    summary.append(f"  record_drift_abs_max={max([r['record_drift_abs'] for r in main_rows], default=0.0):.12e}")
    summary.append(f"  live_dtn_aging_abs_mean_aged={mean([r['live_dtn_aging_abs'] for r in aged]):.12e}")
    summary.append(f"  live_dtn_aging_abs_max_aged={max([r['live_dtn_aging_abs'] for r in aged], default=0.0):.12e}")
    summary.append(f"  live_dtn_aging_rel_mean_aged={mean([r['live_dtn_aging_rel'] for r in aged]):.12e}")
    summary.append(f"  conductance_env_response_only_aging_abs_mean_aged={mean([r['conductance_env_response_only_aging_abs'] for r in aged]):.12e}")
    summary.append(f"  descendant_load_only_aging_abs_mean_aged={mean([r['descendant_load_only_aging_abs'] for r in aged]):.12e}")
    summary.append(f"  frozen_recompute_abs_max={max([r['frozen_recompute_abs'] for r in main_rows], default=0.0):.12e}")
    summary.append(f"  fraction_dtn_obstructed_aged={mean([r['dtn_obstructed_abs'] for r in aged]):.9f}")
    summary.append("")
    summary.append("NO-CONDUCTANCE-BACKREACTION CONTROL")
    summary.append(f"  control_record_drift_abs_max={max([r['record_drift_abs'] for r in control_rows], default=0.0):.12e}")
    summary.append(f"  control_live_dtn_aging_abs_max_aged={max([r['live_dtn_aging_abs'] for r in ctrl_aged], default=0.0):.12e}")
    summary.append(f"  control_descendant_load_only_aging_abs_mean_aged={mean([r['descendant_load_only_aging_abs'] for r in ctrl_aged]):.12e}")
    summary.append(f"  control_conductance_env_response_only_aging_abs_mean_aged={mean([r['conductance_env_response_only_aging_abs'] for r in ctrl_aged]):.12e}")
    summary.append(f"  control_fraction_dtn_obstructed_aged={mean([r['dtn_obstructed_abs'] for r in ctrl_aged]):.9f}")
    summary.append("")
    summary.append("NEXT TEST")
    summary.append("  test_dynamic_dtn_double_history_gluing.py")
    summary.append("  Goal: quotient/gluing with two birth-history paths to the same effective port; measure DtN record/live handoff defect with pure-tree and identical-history controls.")
    text = "\n".join(summary) + "\n"
    (outdir / "SUMMARY.txt").write_text(text, encoding="utf-8")
    return text


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--level", type=int, default=9)
    ap.add_argument("--outdir", type=Path, default=Path("dynamic_dtn_provenance_operators_out_L9"))
    ap.add_argument("--eps", type=float, default=1e-10)
    args = ap.parse_args()
    print(run(args.level, args.outdir, args.eps))


if __name__ == "__main__":
    main()
