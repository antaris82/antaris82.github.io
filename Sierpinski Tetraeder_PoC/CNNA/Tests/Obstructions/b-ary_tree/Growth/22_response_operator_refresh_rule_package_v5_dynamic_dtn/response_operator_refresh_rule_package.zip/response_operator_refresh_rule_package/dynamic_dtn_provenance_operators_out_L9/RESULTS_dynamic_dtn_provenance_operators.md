# CNNA dynamic DtN provenance-operator test

## Purpose

This test replaces the phase-first diagnostic by a provenance-side Schur/DtN operator layer.  Each completed cell stores an immutable birth/completion DtN record and later recomputes a live DtN operator from current conductances, descendant loads, ancestor environment, and the existing shell-normalized backreaction dynamics.

The DtN construction is reciprocal and symmetric.  Directional birth information enters only through the sequentially generated response weights and aged child conductances before forming the reciprocal boundary operator.  Therefore this test is intentionally conservative: it does not import a complex phase.

## Conclusion

```text
dynamic_dtn_two_layer_supported_with_dynamic_load_channel
```

- `record_drift_max=0.000000000000e+00`
- `frozen_recompute_max=0.000000000000e+00`
- `aged_live_dtn_aging_mean=9.041473777200e-01`
- `aged_live_dtn_aging_max=1.219748209375e+00`
- `conductance_env_response_only_aging_mean=3.082591442397e-01`
- `descendant_load_only_aging_mean=6.318282964866e-01`
- `no_conductance_backreaction_control_live_mean=6.221574913988e-01`
- `no_conductance_backreaction_control_desc_only_mean=6.221574913988e-01`
- `fraction_obstructed_aged=1.000000000`

## Main L9 diagnostics

```text
parents_total = 9841
aged_parents = 3280
record_drift_abs_mean = 0.000000000000e+00
record_drift_abs_max = 0.000000000000e+00
live_dtn_aging_abs_mean_aged = 9.041473777200e-01
live_dtn_aging_abs_max_aged = 1.219748209375e+00
live_dtn_aging_rel_mean_aged = 4.252050836203e-01
conductance_env_response_only_aging_abs_mean_aged = 3.082591442397e-01
descendant_load_only_aging_abs_mean_aged = 6.318282964866e-01
frozen_recompute_abs_max = 0.000000000000e+00
fraction_dtn_obstructed_aged = 1.000000000
record_live_gap_completion_abs_mean = 2.585641258552e-03
record_live_gap_final_abs_mean = 3.036885162856e-01
```

## No-conductance-backreaction control

```text
control_parents_total = 9841
control_aged_parents = 3280
control_record_drift_abs_max = 0.000000000000e+00
control_live_dtn_aging_abs_max_aged = 8.407516388606e-01
control_descendant_load_only_aging_abs_mean_aged = 6.221574913988e-01
control_conductance_env_response_only_aging_abs_mean_aged = 0.000000000000e+00
control_fraction_dtn_obstructed_aged = 1.000000000
```

## Interpretation

The result supports replacing phase-first diagnostics by dynamic provenance-side operators.  The immutable DtN record remains fixed, while the live DtN operator ages under dynamic extension.  The no-conductance-backreaction control does not vanish because descendant shell load is itself a live dynamic channel in this DtN construction; the frozen recomputation control is the zero-aging check.  This locates the Record/Live split at the Schur/DtN operator level rather than at an extracted polar/phase quantity.

What is not shown: a physical complex structure, modular flow, AQFT additivity, Type III behavior, or true double-history holonomy.

## Next test

```text
test_dynamic_dtn_double_history_gluing.py
```

Goal: build a controlled quotient/gluing where the same effective port is reached by two different birth-history paths, and test whether the dynamic DtN record/live pair yields a robust handoff defect that vanishes in the pure-tree and identical-history controls.

Why next: the dynamic DtN layer is now a cleaner detector than phase-background residuals.  The next question is whether real provenance identification with double history creates a non-telescoping DtN cocycle/defect.
