# Dynamic Birth Two-Ended Bulk Inverse-Symmetry Diagnostic — v9

This package extends the v8 two-ended bulk quotient with the correction suggested by the audit insight:

```text
rootward direction: many middle/bulk channels coalesce toward the root
frontward direction: middle/bulk channels branch toward the front
```

Therefore the end comparison is not ordinary mirror symmetry.  It is an **inverse symmetry** between coalescence and refinement.  The v8 same-direction check

```text
D(bulk || root_anchor) ≈ D(bulk || front_anchor)
```

is retained only as a deprecated diagnostic.  v9 adds directed inverse comparisons.

## Core construction

For a completed ternary parent `p` whose children are themselves complete, the two-ended h=2 window is:

```text
root_cap  = [parent(p)]
measure   = children(p) = [c1,c2,c3]
front_cap = children(c1) + children(c2) + children(c3)
interior  = [p]
boundary  = root_cap + measure + front_cap
```

First the extended Schur/DtN response is formed:

```text
Lambda_{M∪E}
```

where `M = measure` and `E = root_cap ∪ front_cap`.  Then the end caps are eliminated:

```text
Lambda_M^bulk = Lambda_MM - Lambda_ME solve(Lambda_EE, Lambda_EM)
```

No matrix inverse is used.  The primary path uses `np.linalg.solve`; if the cap block is singular/ill-conditioned, the script attempts a mean-zero gauge-fixed augmented solve and records the method in CSV.

## v9 inverse-symmetry correction

v9 computes four directed entropy proxies on the same three-port measurement sector:

```text
D(bulk || root_anchor)
D(root_anchor || bulk)
D(bulk || front_anchor)
D(front_anchor || bulk)
```

and reports two inverse pairings:

```text
collapse_vs_branch:
  D(bulk || root_anchor)  vs  D(front_anchor || bulk)

expand_vs_coarsen:
  D(root_anchor || bulk)  vs  D(bulk || front_anchor)
```

The preferred v9 Gate C uses the branch-normalized grouped-front version of this inverse comparison.

## Front-group compression

The front cap has nine ports while the root cap has one.  To avoid comparing cardinality rather than inverse symmetry, v9 also projects the front cap to normalized child-group modes:

```text
front_group[j] = normalized uniform mode over grandchildren of child c_j
```

Algebraically, if `x_old = P x_grouped`, the grouped response is:

```text
Lambda_grouped = P.T @ Lambda @ P
```

This is a canonical branching-channel projection, not an inverse and not a fitted normalization.

## Gates

The hard gates are reported in `two_ended_bulk_verdict_<mode>.csv`:

```text
Gate A: local J/skew magnitude survives in the two-ended quotient
Gate B: signed helicity becomes conventional
Gate C: inverse root/front reference symmetry using grouped-front entropy gaps
Gate D: root-anchored signal remains nonzero
All:    A ∧ B ∧ C ∧ D
```

The old same-direction Gate C is now written as:

```text
gate_C_DEPRECATED_same_direction_root_front_reference_symmetry
```

## Outputs

Per mode:

```text
events_<mode>.csv
regions_<mode>.csv
levels_<mode>.csv
depth_trajectory_<mode>.csv
front_bulk_verdict_<mode>.csv
cohort_trajectory_<mode>.csv
cohort_verdict_<mode>.csv
spiral_order_<mode>.csv
spiral_verdict_<mode>.csv
two_ended_bulk_<mode>.csv
two_ended_bulk_verdict_<mode>.csv
```

Global:

```text
all_level_summaries.csv
SUMMARY.txt
RESULTS_dynamic_birth_front_bulk_directed_entropy.md
```

## Default run

```bash
python3 test_dynamic_birth_two_ended_bulk_inverse_symmetry.py --max-level 6 --branching 3 --outdir csv_outputs_L6_v9
```

The included L6 run is finite and diagnostic only.  It is not a Lean proof, not an AQFT construction, not a Type-III/Araki entropy result, and not a quantization claim.
