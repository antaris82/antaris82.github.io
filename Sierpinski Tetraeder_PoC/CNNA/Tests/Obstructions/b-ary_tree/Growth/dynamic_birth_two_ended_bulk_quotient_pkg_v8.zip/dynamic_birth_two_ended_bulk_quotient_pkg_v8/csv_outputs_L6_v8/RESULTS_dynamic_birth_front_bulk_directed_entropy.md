# Dynamic birth two-ended bulk quotient diagnostic v8-b3

## What changed after the audit

The v3 front/bulk verdict used `omega / ||Lambda||` as its primary orientation metric.  The audit found that this can be misleading: raw orientation can rise into the bulk while `||Lambda||` rises even faster, making the normalized ratio fall.  v8 therefore separates the observables:

```text
raw orientation:        |omega|
response scale:         ||Lambda||_F
scale-share diagnostic: |omega| / ||Lambda||_F
finite entropy proxies:  D(rho_live || rho_ref), D(rho_ref || rho_live), and their directed gap
```

A normalization-artifact flag is raised when the normalized profile decays while raw omega does not decay and the total response norm grows with the distance from the front.

## Relative-entropy proxy

This is still not the full AQFT/Araki relative entropy.  It is a finite diagnostic scaffold:

```text
Lambda = S + A,  S^T=S, A^T=-A
H_R = [[S, A], [-A, S]]
rho = exp(-beta * centered/shape-normalized H_R) / Tr(...)
D(rho_live || rho_ref) = Tr rho_live (log rho_live - log rho_ref)
D(rho_ref || rho_live) = Tr rho_ref (log rho_ref - log rho_live)
Delta_D = D(rho_live || rho_ref) - D(rho_ref || rho_live)
```

The reference states currently are the reciprocal symmetric tree control and the symmetrized-live control.  v8 writes both Umegaki directions and the signed/absolute directed gap to CSV.  This implements the missing operator-to-state step as a finite proxy and keeps it explicitly labeled as such.

## What is shown

This package still tests whether deterministic Script-2 sequential birth rules generate a non-symmetric regional Schur/DtN response with antisymmetric local 2D skew-block candidates.  It now also tests whether the front/bulk conclusion survives when raw omega, Lambda scale, normalized ratio, both Umegaki directions, and the directed entropy gap are separated.

## What is not shown

This run does not prove canonical quantization, an AQFT net, Tomita-Takesaki modular dynamics, Type-III behavior, a physical time evolution, or a Schrödinger equation.  The entropy computation is finite-dimensional Umegaki entropy of a constructed proxy state, not Araki relative entropy.

## Generated CSV files

Per mode:

- `events_<mode>.csv`
- `regions_<mode>.csv`
- `levels_<mode>.csv`
- `depth_trajectory_<mode>.csv`
- `front_bulk_verdict_<mode>.csv`
- `cohort_trajectory_<mode>.csv`
- `cohort_verdict_<mode>.csv`
- `spiral_order_<mode>.csv`
- `spiral_verdict_<mode>.csv`
- `two_ended_bulk_<mode>.csv`
- `two_ended_bulk_verdict_<mode>.csv`

Global:

- `all_level_summaries.csv`
- `SUMMARY.txt`
- `RESULTS_dynamic_birth_front_bulk_directed_entropy.md`

## Default run

The included output was generated with `--max-level 6 --branching 3`.

```text
MODE linear
  branching=3
  relational live update=1
  live relation target scale=current_g
  live env relation groups=1092, live backreaction relations=7107
  relational rebuild count=1102
  final nodes=1093, completed triples=364
  regions tested=847, valid=847
  mean rel skew live=0.0506579824044
  mean |omega sibling|=0.0306377057933
  mean |omega F1/F2|=0.0371015915796
  F1/F2 omega nonzero fraction=1.000
  F1/F2 J2-ok fraction=1.000
  F1/F2 orientation positive fraction=1.000
  mean block dominance=0.848610869258
  one-skew-pair fraction=0.430
  max rel skew symmetric control=4.715e-17
  max rel skew symdir control=2.523e-17
  mean |omega F1-only control|=0.00748213882634
  F1-only control nonzero fraction=0.858
  mean |omega F2-only control|=0.0306352583912
  F2-only control nonzero fraction=1.000
  kappa flips fraction=0.858
  kappa preserves birth order fraction=0.000
  FRONT/BULK PROFILE rootward_sibling_cone
    front mean raw |omega|=0.0404267735451
    raw |omega| log-slope vs distance=0.195536617352
    Lambda-norm log-slope vs distance=0.600575814966
    normalized omega/Lambda log-slope=-0.405601470865
    entropy-shape D(live||sym) log-slope=2.1948500198
    entropy-shape D(sym||live) log-slope=2.44630024716
    abs directional entropy log-slope=4.15080648647
    signed directional entropy linear-slope=-0.354789963846
    normalization artifact suspected=1
    artifact level fraction=1.000
    raw front/bulk ratio=0.738141987819
    normalized front/bulk ratio=2.18540004788
  FRONT/BULK PROFILE sibling_star
    front mean raw |omega|=0.033590829892
    raw |omega| log-slope vs distance=0.216396425605
    Lambda-norm log-slope vs distance=0.737247884632
    normalized omega/Lambda log-slope=-0.521319954863
    entropy-shape D(live||sym) log-slope=0.342002008827
    entropy-shape D(sym||live) log-slope=0.348410759717
    abs directional entropy log-slope=0.449950719873
    signed directional entropy linear-slope=-0.00223566998318
    normalization artifact suspected=1
  COHORT/AGING rootward_sibling_cone
    cohorts=120
    scenario A raw relaxation fraction=0.108
    scenario B accumulated spiral-memory fraction=1.000
  SPIRAL ORDER rootward_sibling_cone
    mean |H|=0.00112565999778
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.067
    address-phase shuffle suppressed fraction=0.600
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  COHORT/AGING sibling_star
    cohorts=121
    scenario A raw relaxation fraction=0.248
    scenario B accumulated spiral-memory fraction=0.835
  SPIRAL ORDER sibling_star
    mean |H|=0.000420704076094
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.333
    address-phase shuffle suppressed fraction=0.619
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  TWO-ENDED BULK QUOTIENT
    windows=120
    mean two-end |omega|=0.031713164462
    mean two-end rel skew=0.0363058513858
    signed helicity convention ratio=0.040080441912
    root/front ref entropy gap rel=0.985557724712
    root anchored |H|=0.029598773371
    front anchored |H|=0.0295618322817
    kappa reversal flip fraction=1.000
    symdir near-zero fraction=1.000
    gate A local J magnitude survives=1
    gate B signed helicity conventional=1
    gate C root/front reference symmetry=0
    gate D root-anchored signal nonzero=1
    two-ended sign-convention gate all=0

MODE log
  branching=3
  relational live update=1
  live relation target scale=current_g
  live env relation groups=1092, live backreaction relations=7107
  relational rebuild count=1102
  final nodes=1093, completed triples=364
  regions tested=847, valid=847
  mean rel skew live=0.0490700463134
  mean |omega sibling|=0.0110228719277
  mean |omega F1/F2|=0.0213349893037
  F1/F2 omega nonzero fraction=1.000
  F1/F2 J2-ok fraction=1.000
  F1/F2 orientation positive fraction=1.000
  mean block dominance=0.888454726981
  one-skew-pair fraction=0.430
  max rel skew symmetric control=4.412e-17
  max rel skew symdir control=2.662e-17
  mean |omega F1-only control|=0.00618416794478
  F1-only control nonzero fraction=0.858
  mean |omega F2-only control|=0.0112471044171
  F2-only control nonzero fraction=1.000
  kappa flips fraction=0.858
  kappa preserves birth order fraction=0.000
  FRONT/BULK PROFILE rootward_sibling_cone
    front mean raw |omega|=0.0273430630052
    raw |omega| log-slope vs distance=0.272872744238
    Lambda-norm log-slope vs distance=0.665289702947
    normalized omega/Lambda log-slope=-0.393053211231
    entropy-shape D(live||sym) log-slope=2.39384626226
    entropy-shape D(sym||live) log-slope=2.61097564728
    abs directional entropy log-slope=4.73569427944
    signed directional entropy linear-slope=-0.29094606425
    normalization artifact suspected=1
    artifact level fraction=1.000
    raw front/bulk ratio=0.646218155932
    normalized front/bulk ratio=2.199831236
  FRONT/BULK PROFILE sibling_star
    front mean raw |omega|=0.0165373068201
    raw |omega| log-slope vs distance=0.402285022597
    Lambda-norm log-slope vs distance=0.829694933462
    normalized omega/Lambda log-slope=-0.427402310737
    entropy-shape D(live||sym) log-slope=0.352687885102
    entropy-shape D(sym||live) log-slope=0.346792606921
    abs directional entropy log-slope=-0.0651600836208
    signed directional entropy linear-slope=7.23767948227e-05
    normalization artifact suspected=1
  COHORT/AGING rootward_sibling_cone
    cohorts=120
    scenario A raw relaxation fraction=0.100
    scenario B accumulated spiral-memory fraction=1.000
  SPIRAL ORDER rootward_sibling_cone
    mean |H|=0.00104107497564
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.000
    address-phase shuffle suppressed fraction=0.800
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  COHORT/AGING sibling_star
    cohorts=121
    scenario A raw relaxation fraction=0.000
    scenario B accumulated spiral-memory fraction=1.000
  SPIRAL ORDER sibling_star
    mean |H|=8.35312704782e-05
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.286
    address-phase shuffle suppressed fraction=0.952
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  TWO-ENDED BULK QUOTIENT
    windows=120
    mean two-end |omega|=0.0128697447156
    mean two-end rel skew=0.0382973824346
    signed helicity convention ratio=0.00409908655508
    root/front ref entropy gap rel=0.80495892676
    root anchored |H|=0.0119153974293
    front anchored |H|=0.0119162167995
    kappa reversal flip fraction=1.000
    symdir near-zero fraction=1.000
    gate A local J magnitude survives=1
    gate B signed helicity conventional=1
    gate C root/front reference symmetry=0
    gate D root-anchored signal nonzero=1
    two-ended sign-convention gate all=0

MODE saturating
  branching=3
  relational live update=1
  live relation target scale=current_g
  live env relation groups=1092, live backreaction relations=7107
  relational rebuild count=1102
  final nodes=1093, completed triples=364
  regions tested=847, valid=847
  mean rel skew live=0.150946918534
  mean |omega sibling|=0.118423103646
  mean |omega F1/F2|=0.212293779737
  F1/F2 omega nonzero fraction=1.000
  F1/F2 J2-ok fraction=1.000
  F1/F2 orientation positive fraction=1.000
  mean block dominance=0.854051347176
  one-skew-pair fraction=0.430
  max rel skew symmetric control=3.778e-17
  max rel skew symdir control=2.169e-17
  mean |omega F1-only control|=0.041295268037
  F1-only control nonzero fraction=0.858
  mean |omega F2-only control|=0.120533023503
  F2-only control nonzero fraction=1.000
  kappa flips fraction=0.858
  kappa preserves birth order fraction=0.000
  FRONT/BULK PROFILE rootward_sibling_cone
    front mean raw |omega|=0.245663661466
    raw |omega| log-slope vs distance=0.17929226484
    Lambda-norm log-slope vs distance=0.661532429756
    normalized omega/Lambda log-slope=-0.484818386209
    entropy-shape D(live||sym) log-slope=1.81837529774
    entropy-shape D(sym||live) log-slope=2.02443777596
    abs directional entropy log-slope=3.53518866603
    signed directional entropy linear-slope=-0.287509140355
    normalization artifact suspected=1
    artifact level fraction=1.000
    raw front/bulk ratio=0.748642127637
    normalized front/bulk ratio=2.59616783386
  FRONT/BULK PROFILE sibling_star
    front mean raw |omega|=0.150044355297
    raw |omega| log-slope vs distance=0.328927079664
    Lambda-norm log-slope vs distance=0.985273261501
    normalized omega/Lambda log-slope=-0.656334626298
    entropy-shape D(live||sym) log-slope=0.0208398897978
    entropy-shape D(sym||live) log-slope=0.0161921150339
    abs directional entropy log-slope=0.447070610416
    signed directional entropy linear-slope=0.00146697137535
    normalization artifact suspected=1
  COHORT/AGING rootward_sibling_cone
    cohorts=120
    scenario A raw relaxation fraction=0.000
    scenario B accumulated spiral-memory fraction=1.000
  SPIRAL ORDER rootward_sibling_cone
    mean |H|=0.00548040835801
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.000
    address-phase shuffle suppressed fraction=0.800
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  COHORT/AGING sibling_star
    cohorts=121
    scenario A raw relaxation fraction=0.000
    scenario B accumulated spiral-memory fraction=1.000
  SPIRAL ORDER sibling_star
    mean |H|=0.000556219763853
    first-last reversal flip fraction=1.000
    sibling-rank shuffle suppressed fraction=0.286
    address-phase shuffle suppressed fraction=0.810
    symdir near-zero fraction=1.000
    spiral controls pass majority=0
  TWO-ENDED BULK QUOTIENT
    windows=120
    mean two-end |omega|=0.135267453793
    mean two-end rel skew=0.150922660264
    signed helicity convention ratio=0.00148504154663
    root/front ref entropy gap rel=0.875438840401
    root anchored |H|=0.125377773443
    front anchored |H|=0.125396853969
    kappa reversal flip fraction=1.000
    symdir near-zero fraction=1.000
    gate A local J magnitude survives=1
    gate B signed helicity conventional=1
    gate C root/front reference symmetry=0
    gate D root-anchored signal nonzero=1
    two-ended sign-convention gate all=0

```

## Conservative interpretation

A favorable result now requires more than a falling `omega/||Lambda||` curve.  At minimum, the raw-orientation slope and/or a directed finite entropy-proxy slope must support the claimed front/bulk relaxation, and `normalization_artifact_suspected` must be false.  If raw omega rises while only `omega/||Lambda||` falls, the script reports that as a normalization artifact rather than a passed front/bulk gate.

## v8 two-ended bulk quotient gate

v8 adds the missing bulk-internal perspective.  For each h=2 window it first builds an extended boundary response on

```text
rootward cap + bulk measurement ports + frontward cap
```

and then Schur-eliminates both caps.  The resulting bulk response should retain sign-blind local J/skew magnitude, while the signed helicity should become conventional if the bulk really cannot use either end as a canonical orientation anchor.

The subsequent measure gate remains weight robustness: vary `alpha_env`, `ancestor_decay`, `br_ancestor`, `br_sibling`, and the conductance law, then test whether the quotient sign-convention profile is invariant or merely borrowed from the selected weights.
