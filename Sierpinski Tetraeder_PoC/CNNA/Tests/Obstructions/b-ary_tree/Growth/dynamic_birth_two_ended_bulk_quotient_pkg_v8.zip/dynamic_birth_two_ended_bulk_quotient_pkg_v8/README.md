# Dynamic Birth Two-Ended Bulk Quotient Diagnostic — v8

This package extends the v7 relational-live CNNA growth diagnostic with a **two-ended bulk quotient**.

The prior tests were still mostly root-anchored: they measured orientation relative to the actual root/front structure of the whole growing tree.  v8 adds a second perspective: a local bulk subsystem whose rootward and frontward end caps are present in the extended Schur response but are then eliminated as unobserved environment.

## Core construction

For a completed ternary parent `p` whose children are themselves complete, v8 builds an h=2 bulk window:

```text
root_cap  = [parent(p)]
measure   = children(p) = [c1,c2,c3]
front_cap = children(c1) + children(c2) + children(c3)
interior  = [p]
boundary  = root_cap + measure + front_cap
```

First it forms the extended regional Schur/DtN response:

```text
Lambda_{M∪E}
```

where `M = measure` and `E = root_cap ∪ front_cap`.

Then it eliminates the two caps:

```text
Lambda_M^bulk = Lambda_MM - Lambda_ME solve(Lambda_EE, Lambda_EM)
```

No matrix inverse is used.  The primary path uses `np.linalg.solve`; if the cap block is singular/ill-conditioned, the script attempts a mean-zero gauge-fixed augmented solve and records the method in CSV.

## Interpretation gate

The target is not `A_M^bulk = 0`.  That would erase the local J/skew structure.  The intended diagnostic is:

```text
local sign-blind J/skew magnitude survives,
but signed helicity becomes conventional when root/front caps are not observable.
```

The hard gates are reported in `two_ended_bulk_verdict_<mode>.csv`:

```text
Gate A: local J magnitude survives
Gate B: signed helicity is conventional
Gate C: root/front reference entropy symmetry
Gate D: root-anchored signal remains nonzero
All:    A ∧ B ∧ C ∧ D
```

## Outputs

Per mode:

```text
events_<mode>.csv
regions_<mode>.csv
levels_<mode>.csv
depth_trajectory_<mode>.csv
front_bulk_verdict_<mode>.csv
cohort_trajectory_<mode>.csv
cohort_verdict_<mode>.csv
spiral_order_<mode>.csv
spiral_verdict_<mode>.csv
two_ended_bulk_<mode>.csv
two_ended_bulk_verdict_<mode>.csv
```

Global:

```text
all_level_summaries.csv
SUMMARY.txt
RESULTS_dynamic_birth_front_bulk_directed_entropy.md
```

## Default run

```bash
python3 test_dynamic_birth_two_ended_bulk_quotient.py --max-level 6 --branching 3 --outdir csv_outputs_L6_v8
```

The included L6 run is finite and diagnostic only.  It is not a Lean proof, not an AQFT construction, not a Type-III/Araki entropy result, and not a quantization claim.
