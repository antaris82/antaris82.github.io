#!/usr/bin/env python3
"""
Dynamic birth Schur gyroscopic-block, front/bulk trajectory, directed finite entropy-proxy, spiral/cohort diagnostic, relational live-backreaction, and two-ended bulk quotient test for the CNNA provenance-growth picture.

Purpose
-------
This is a deterministic Python diagnostic surrogate, not a Lean theorem and not a
physics claim.  It takes the sequential growth rules of Script 2
(`test_dynamic_birth_monodromy.py`) and tests the next mathematical target:

    directed live response
        -> non-symmetric regional DtN/Schur response Lambda_R
        -> A_R = 1/2 (Lambda_R - Lambda_R.T)
        -> local skew/J-like 2D block candidates.

Reference target
----------------
The comparison target is the established circuit-quantization structure where a
skew-symmetric nonreciprocal matrix G produces gyroscopic terms of the form

    1/2 dot(Phi)^T G Phi
    Q - 1/2 G Phi.

This script does NOT import a gyrator.  It asks whether the Script-2 sequential
birth/live-backreaction rules produce an analogous *mathematical* skew block after
regional Schur reduction.

Guardrails
----------
- The reciprocal and symmetrized-live controls must stay Schur-symmetric.
- Axis-isolation controls are split explicitly:
  * F1-only removes every directed sibling family and keeps only longitudinal
    ancestor<->child influence/backreaction.
  * F2-only removes every longitudinal directed family and diagnoses only the
    sibling boundary block, because the regional interior is disconnected by
    construction when all longitudinal edges are removed.
- Kappa reversal is a named orientation/provenance control.
- Front/bulk trajectory is measured in the front-anchored depth coordinate
  distance_to_front = current_growth_level - max(boundary_node_level).
  The audit-critical distinction is explicit:
    * raw orientation omega is reported and verdict-tested separately;
    * omega/||Lambda|| is retained only as a scale-share diagnostic;
    * a normalization-artifact flag is raised when omega/||Lambda|| decays only
      because ||Lambda|| grows faster than raw omega.
- A finite-state relative-entropy proxy is included.  It maps a Schur response
  Lambda=S+A to a real doubled symmetric operator [[S,A],[-A,S]], then to a
  Gibbs density matrix.  This is a finite diagnostic proxy only, not an Araki
  Type-III construction.
- Cohort/aging trajectories follow the same regional cut over later growth levels.
- v8 relational-live correction: after every birth, live directed edge weights are
  recomputed from the current scalar conductances of already existing source/target
  nodes.  Regions are therefore not frozen after completion; their Schur responses
  are re-pulled from the updated relational layer at every analyzed level.
- Birth-rank-resolved spiral order keeps the accumulated address/rank phase instead
  of averaging it away in purely radial front/bulk bins.
- v8 two-ended bulk quotient: a bulk measurement window M is surrounded by a
  rootward cap E_- and a frontward cap E_+.  The end caps are Schur-eliminated
  from the regional boundary response so the measured subsystem cannot use the
  root or the current growth front as an explicit orientation anchor:
      Lambda_bulk_M = Lambda_MM - Lambda_ME solve(Lambda_EE, Lambda_EM).
  The test asks whether sign-sensitive helicity becomes conventional while
  sign-blind local J/skew magnitude remains nonzero.
- Spiral controls: deterministic sibling-rank shuffle, address-phase shuffle,
  first-last/kappa reversal, and symmetrized-live twin.
- All Schur complements and quotient eliminations use np.linalg.solve, never np.linalg.inv.
"""

from __future__ import annotations

import argparse
import csv
import math
from dataclasses import dataclass, field
from collections import defaultdict
from pathlib import Path
from typing import DefaultDict, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


EPS = 1e-12
DEFAULT_TOL = 1e-9
DEFAULT_COND_MAX = 1e12

Edge = Tuple[int, int]


@dataclass
class Node:
    id: int
    parent: Optional[int]
    level: int
    birth_order: int
    birth_time: int
    birth_g: float
    g: float
    children: List[int] = field(default_factory=list)


@dataclass
class RegionSpec:
    region_type: str
    parent: int
    boundary: List[int]
    interior: List[int]
    children: List[int]
    rootward: Optional[int] = None


@dataclass
class TwoEndedBulkSpec:
    """Bulk window with two non-observed end caps.

    boundary ordering is always
        root_cap + measure + front_cap

    `measure` is the internal bulk measurement boundary M.  The rootward and
    frontward caps are present in the first Schur response but are then
    eliminated by a second quotient Schur step.
    """
    parent: int
    measure: List[int]
    root_cap: List[int]
    front_cap: List[int]
    boundary: List[int]
    interior: List[int]
    children: List[int]
    window_type: str = "two_ended_bulk_window"


@dataclass
class SchurResult:
    ok: bool
    Lambda: Optional[np.ndarray] = None
    cond_KII: float = math.nan
    solve_residual: float = math.nan
    row_sum_residual: float = math.nan
    error: str = ""


@dataclass(frozen=True)
class LiveEnvSource:
    kind: str
    source: int
    factor: float


@dataclass(frozen=True)
class LiveEnvRelationGroup:
    child: int
    sources: Tuple[LiveEnvSource, ...]


@dataclass(frozen=True)
class LiveBackreactionRelation:
    kind: str
    source_child: int
    target: int
    factor: float


class DynamicBirthGyroscopicSchurModel:
    def __init__(
        self,
        mode: str = "linear",
        branching: int = 3,
        base: float = 1.0,
        alpha_env: float = 0.22,
        ancestor_decay: float = 0.55,
        br_ancestor: float = 0.045,
        br_sibling: float = 0.035,
        eps: float = EPS,
        tol: float = DEFAULT_TOL,
        cond_max: float = DEFAULT_COND_MAX,
        include_shell_h2: bool = True,
        relational_live_update: bool = True,
        live_relation_target_scale: str = "current_g",
    ):
        if branching != 3:
            raise ValueError("This diagnostic currently supports explicit ternary branching only: --branching 3. The b=2 generalization needs a different sibling-sector basis and separate controls.")
        self.mode = mode
        self.branching = branching
        self.base = base
        self.alpha_env = alpha_env
        self.ancestor_decay = ancestor_decay
        self.br_ancestor = br_ancestor
        self.br_sibling = br_sibling
        self.eps = eps
        self.tol = tol
        self.cond_max = cond_max
        self.include_shell_h2 = include_shell_h2
        self.relational_live_update = bool(relational_live_update)
        if live_relation_target_scale not in {"current_g", "birth_g"}:
            raise ValueError("live_relation_target_scale must be 'current_g' or 'birth_g'")
        self.live_relation_target_scale = live_relation_target_scale

        self.nodes: Dict[int, Node] = {}
        self.t = 0
        self.next_id = 0

        # Live directed response layer: the Script-2 nonreciprocal influence graph.
        self.directed_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.directed_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }

        # v8 source-of-truth for the live relation layer.  The old event-time
        # weights are still written during add_child, but when
        # relational_live_update=True they are overwritten by a recomputation
        # from these relation records and the current node.g values.  This is
        # the audit-critical correction: already completed regions are not
        # relationally frozen after their birth; every analysis pass re-pulls
        # their directed edges from current live conductances.
        self.live_env_relation_groups: List[LiveEnvRelationGroup] = []
        self.live_backreaction_relations: List[LiveBackreactionRelation] = []
        self.relational_rebuild_count = 0

        # Symmetric tree-control layer: reciprocal parent-child birth conductances only.
        self.sym_edges: DefaultDict[Edge, float] = defaultdict(float)

        # Record-only directed layer: same event topology but source amplitudes use frozen birth_g.
        self.record_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.record_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "record_env_ancestor_to_child": defaultdict(float),
            "record_env_sibling_to_child": defaultdict(float),
            "record_uv_child_to_ancestor": defaultdict(float),
            "record_sibling_backreaction": defaultdict(float),
        }

        self.event_rows: List[dict] = []
        self.region_rows: List[dict] = []
        self.level_rows: List[dict] = []
        self.two_ended_bulk_rows: List[dict] = []

        root = self._new_node(parent=None, level=0, birth_order=0, birth_g=1.0)
        self.root = root.id

    # ------------------------------------------------------------------
    # Growth layer: inherited from Script 2, with extra edge bookkeeping.
    # ------------------------------------------------------------------

    def _new_node(self, parent: Optional[int], level: int, birth_order: int, birth_g: float) -> Node:
        n = Node(
            id=self.next_id,
            parent=parent,
            level=level,
            birth_order=birth_order,
            birth_time=self.t,
            birth_g=float(birth_g),
            g=float(birth_g),
        )
        self.nodes[n.id] = n
        self.next_id += 1
        if parent is not None:
            self.nodes[parent].children.append(n.id)
        return n

    def add_directed_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.directed_edges[(u, v)] += w
        self.directed_edges_by_kind[kind][(u, v)] += w

    def add_record_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.record_edges[(u, v)] += w
        self.record_edges_by_kind[kind][(u, v)] += w

    def live_target_amplitude(self, child: int) -> float:
        if self.live_relation_target_scale == "birth_g":
            return float(self.nodes[child].birth_g)
        return float(self.nodes[child].g)

    def register_live_env_group(self, child: int, sources: Sequence[LiveEnvSource]) -> None:
        self.live_env_relation_groups.append(LiveEnvRelationGroup(child=int(child), sources=tuple(sources)))

    def register_live_backreaction(self, kind: str, source_child: int, target: int, factor: float) -> None:
        self.live_backreaction_relations.append(
            LiveBackreactionRelation(kind=str(kind), source_child=int(source_child), target=int(target), factor=float(factor))
        )

    def rebuild_live_directed_edges_from_relations(self) -> None:
        """Recompute all live directed edges from current node.g values.

        This is the v8 script with the v7 relational-live correction.  The prior v6 layer froze
        edge weights at event time.  It updated existing nodes' scalar g values
        but did not update the already existing directed relations that depend
        on those g values.  Here every recorded relation is re-pulled from the
        current source/target conductances before Schur analysis.

        Environment edges are normalized over the original birth environment
        group, but with current source conductances.  Backreaction edges are
        proportional to the current conductance of their source child.
        """
        new_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }

        for group in self.live_env_relation_groups:
            current_total = 0.0
            for src in group.sources:
                current_total += float(self.nodes[src.source].g) * float(src.factor)
            total = current_total + self.eps
            target_amp = self.live_target_amplitude(group.child)
            for src in group.sources:
                contrib = float(self.nodes[src.source].g) * float(src.factor)
                weight = self.alpha_env * contrib / total * target_amp
                if abs(weight) > 0.0:
                    new_by_kind[src.kind][(src.source, group.child)] += float(weight)

        for rel in self.live_backreaction_relations:
            weight = float(rel.factor) * float(self.nodes[rel.source_child].g)
            if abs(weight) > 0.0:
                new_by_kind[rel.kind][(rel.source_child, rel.target)] += float(weight)

        self.directed_edges_by_kind = new_by_kind
        self.directed_edges = defaultdict(float)
        for edge_map in self.directed_edges_by_kind.values():
            for e, w in edge_map.items():
                self.directed_edges[e] += float(w)
        self.relational_rebuild_count += 1

    def add_sym_edge(self, u: int, v: int, weight: float) -> None:
        w = float(weight)
        self.sym_edges[(u, v)] += w
        self.sym_edges[(v, u)] += w

    def parent_line(self, parent: int) -> List[int]:
        line: List[int] = []
        cur: Optional[int] = parent
        while cur is not None:
            line.append(cur)
            cur = self.nodes[cur].parent
        return line

    def birth_environment_load(self, parent: int, older_siblings: Sequence[int], current: bool = True) -> float:
        env = 0.0
        for d, a in enumerate(self.parent_line(parent), start=1):
            g = self.nodes[a].g if current else self.nodes[a].birth_g
            env += g * (self.ancestor_decay ** (d - 1))
        for s in older_siblings:
            g = self.nodes[s].g if current else self.nodes[s].birth_g
            env += g
        return float(env)

    def child_conductance_from_env(self, env_load: float) -> float:
        if self.mode == "linear":
            return self.base + self.alpha_env * env_load
        if self.mode == "log":
            return self.base + self.alpha_env * math.log1p(env_load)
        if self.mode == "saturating":
            return self.base + self.alpha_env * (env_load / (1.0 + env_load))
        raise ValueError(f"unknown mode: {self.mode}")

    def add_child(self, parent: int, order: int) -> int:
        self.t += 1
        older = list(self.nodes[parent].children)

        env_load = self.birth_environment_load(parent, older, current=True)
        birth_g = self.child_conductance_from_env(env_load)
        child = self._new_node(parent, self.nodes[parent].level + 1, order, birth_g)
        c = child.id

        # Symmetric control tree: reciprocal parent-child conductance.
        self.add_sym_edge(parent, c, birth_g)

        # Register the live relational environment group.  In v8 this relation
        # will be recomputed from current node.g at every rebuild, so later
        # changes to any source node alter already existing outgoing relations.
        live_sources: List[LiveEnvSource] = []
        for d, a in enumerate(self.parent_line(parent), start=1):
            live_sources.append(LiveEnvSource("env_ancestor_to_child", a, self.ancestor_decay ** (d - 1)))
        for s in older:
            live_sources.append(LiveEnvSource("env_sibling_to_child", s, 1.0))
        self.register_live_env_group(c, live_sources)

        # Live environment influence: existing parent-line and older siblings -> newborn.
        total_env = env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].g
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_sibling_to_child", s, c, weight)

        # Record-only environment influence: same topology, frozen birth_g source amplitudes.
        record_env_load = self.birth_environment_load(parent, older, current=False)
        total_record_env = record_env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].birth_g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].birth_g
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_sibling_to_child", s, c, weight)

        # Live backreaction: newborn acts as UV-tail for the parent line.
        for d, a in enumerate(self.parent_line(parent), start=1):
            delta = self.br_ancestor * birth_g / (d * d)
            self.nodes[a].g += delta
            self.add_directed_edge("uv_child_to_ancestor", c, a, delta)
            self.register_live_backreaction("uv_child_to_ancestor", c, a, self.br_ancestor / (d * d))
            self.add_record_edge("record_uv_child_to_ancestor", c, a, delta)

        # Live backreaction to older siblings: this is the closure edge family removed in path-only control.
        for s in older:
            delta = self.br_sibling * birth_g
            self.nodes[s].g += delta
            self.add_directed_edge("sibling_backreaction", c, s, delta)
            self.register_live_backreaction("sibling_backreaction", c, s, self.br_sibling)
            self.add_record_edge("record_sibling_backreaction", c, s, delta)

        if self.relational_live_update:
            # Re-pull the live relation layer immediately after every scalar
            # backreaction.  This makes the edge layer and all subsequent Schur
            # responses sensitive to changed conductances of already existing
            # nodes, instead of freezing regional relations at completion time.
            self.rebuild_live_directed_edges_from_relations()

        children = self.nodes[parent].children
        self.event_rows.append(
            {
                "mode": self.mode,
                "t": self.t,
                "parent": parent,
                "child": c,
                "child_level": child.level,
                "child_order": order,
                "older_siblings": " ".join(map(str, older)),
                "env_load_live": env_load,
                "env_load_record": record_env_load,
                "child_birth_g": birth_g,
                "parent_g_after": self.nodes[parent].g,
                "sibling_current_g": " ".join(f"{self.nodes[x].g:.12g}" for x in children),
                "triple_completed": int(len(children) == 3),
                "relational_live_update": int(self.relational_live_update),
                "live_relation_target_scale": self.live_relation_target_scale,
                "live_env_relation_groups": len(self.live_env_relation_groups),
                "live_backreaction_relations": len(self.live_backreaction_relations),
                "relational_rebuild_count": self.relational_rebuild_count,
            }
        )
        return c

    def grow_level(self, frontier: Sequence[int]) -> List[int]:
        next_frontier: List[int] = []
        for p in frontier:
            for k in range(1, 4):
                next_frontier.append(self.add_child(p, k))
        return next_frontier

    def completed_parents(self) -> List[int]:
        return [n.id for n in self.nodes.values() if len(n.children) == 3]

    # ------------------------------------------------------------------
    # Matrix construction and Schur/DtN response.
    # ------------------------------------------------------------------

    def directed_laplacian(self, edges: Dict[Edge, float]) -> np.ndarray:
        n = self.next_id
        K = np.zeros((n, n), dtype=float)
        for (u, v), w in edges.items():
            if u == v or abs(w) <= 0.0:
                continue
            K[u, u] += w
            K[u, v] -= w
        return K

    @staticmethod
    def symmetrized_edges(edges: Dict[Edge, float]) -> DefaultDict[Edge, float]:
        out: DefaultDict[Edge, float] = defaultdict(float)
        unordered = {tuple(sorted((u, v))) for (u, v) in edges.keys() if u != v}
        for a, b in unordered:
            w = 0.5 * (edges.get((a, b), 0.0) + edges.get((b, a), 0.0))
            if abs(w) > 0.0:
                out[(a, b)] += w
                out[(b, a)] += w
        return out

    def f1_only_edges(self) -> DefaultDict[Edge, float]:
        """Keep only longitudinal directed families.

        This is the corrected replacement for the former misleading
        ``path_only`` control.  It removes *all* directed sibling couplings:

        - env_sibling_to_child
        - sibling_backreaction

        What remains is the F1/root-front channel:

        - env_ancestor_to_child
        - uv_child_to_ancestor
        """
        keep = {"env_ancestor_to_child", "uv_child_to_ancestor"}
        out: DefaultDict[Edge, float] = defaultdict(float)
        for kind, edge_map in self.directed_edges_by_kind.items():
            if kind not in keep:
                continue
            for e, w in edge_map.items():
                out[e] += w
        return out

    def f2_only_edges(self) -> DefaultDict[Edge, float]:
        """Keep only directed sibling families.

        This removes every longitudinal directed family:

        - env_ancestor_to_child
        - uv_child_to_ancestor

        and keeps the F2/birth-rank channel:

        - env_sibling_to_child
        - sibling_backreaction

        With all longitudinal edges removed, the usual parent/rootward
        interiors of the regional Schur tests are disconnected.  Therefore the
        F2-only diagnostic is evaluated on the sibling boundary block, not by
        pretending that the original Schur interior is still invertible.
        """
        keep = {"env_sibling_to_child", "sibling_backreaction"}
        out: DefaultDict[Edge, float] = defaultdict(float)
        for kind, edge_map in self.directed_edges_by_kind.items():
            if kind not in keep:
                continue
            for e, w in edge_map.items():
                out[e] += w
        return out

    def schur_response(
        self,
        K: np.ndarray,
        boundary: Sequence[int],
        interior: Sequence[int],
    ) -> SchurResult:
        if len(boundary) == 0:
            return SchurResult(ok=False, error="empty boundary")
        if len(interior) == 0:
            return SchurResult(ok=False, error="empty interior")
        if set(boundary).intersection(interior):
            return SchurResult(ok=False, error="boundary/interior overlap")

        B = np.array(boundary, dtype=int)
        I = np.array(interior, dtype=int)
        K_BB = K[np.ix_(B, B)]
        K_BI = K[np.ix_(B, I)]
        K_IB = K[np.ix_(I, B)]
        K_II = K[np.ix_(I, I)]

        try:
            cond = float(np.linalg.cond(K_II))
            if not np.isfinite(cond) or cond > self.cond_max:
                return SchurResult(ok=False, cond_KII=cond, error="singular_or_ill_conditioned_KII")
            X = np.linalg.solve(K_II, K_IB)
            Lambda = K_BB - K_BI @ X
            solve_residual = float(np.linalg.norm(K_II @ X - K_IB, ord="fro"))
            row_sum_residual = float(np.linalg.norm(Lambda @ np.ones(len(boundary))))
            return SchurResult(
                ok=True,
                Lambda=Lambda,
                cond_KII=cond,
                solve_residual=solve_residual,
                row_sum_residual=row_sum_residual,
            )
        except np.linalg.LinAlgError as exc:
            return SchurResult(ok=False, error=f"lin_alg_error:{exc}")

    def boundary_block_response(self, K: np.ndarray, boundary: Sequence[int]) -> SchurResult:
        """Return the boundary block as a response with no interior elimination.

        This is used only for the F2-only axis-isolation control.  Removing all
        longitudinal directed edges disconnects the parent/rootward interiors by
        construction, so a regional Schur complement would be singular and would
        falsely test numerical invertibility rather than sibling orientation.
        """
        if len(boundary) == 0:
            return SchurResult(ok=False, error="empty boundary")
        B = np.array(boundary, dtype=int)
        Lambda = K[np.ix_(B, B)]
        row_sum_residual = float(np.linalg.norm(Lambda @ np.ones(len(boundary))))
        return SchurResult(ok=True, Lambda=Lambda, cond_KII=0.0, solve_residual=0.0, row_sum_residual=row_sum_residual)

    def selected_axis_omega(self, spec: RegionSpec, A: np.ndarray, axis: str) -> float:
        """Extract the axis-specific orientation scalar for controls.

        ``axis='f1'`` uses the F1/F2 projection whenever the region supplies a
        rootward port; otherwise it falls back to the sibling projection.
        ``axis='f2'`` always uses the sibling Z3 sector, because F2 is the
        birth-rank/sibling-order axis after longitudinal ports have been removed.
        """
        pmetrics = self.projection_metrics(spec, A)
        if axis == "f1":
            if math.isfinite(float(pmetrics.get("omega_f1f2", math.nan))):
                return float(pmetrics["omega_f1f2"])
            return float(pmetrics.get("omega_sibling", math.nan))
        if axis == "f2":
            return float(pmetrics.get("omega_sibling", math.nan))
        raise ValueError(f"unknown axis: {axis}")

    def front_bulk_geometry(self, spec: RegionSpec, current_growth_level: int) -> dict:
        """Front-anchored depth coordinate for the orientation-profile gate.

        The front is the current growth frontier at ``current_growth_level``.
        A region touches the front if at least one boundary node is on that
        frontier.  Older regions are bulk regions.  This is deliberately not an
        absolute tree depth; it is the distance from the moving front.
        """
        boundary_levels = [self.nodes[n].level for n in spec.boundary]
        interior_levels = [self.nodes[n].level for n in spec.interior] if spec.interior else []
        child_levels = [self.nodes[n].level for n in spec.children] if spec.children else []
        max_boundary_level = max(boundary_levels) if boundary_levels else -1
        min_boundary_level = min(boundary_levels) if boundary_levels else -1
        max_region_level = max(boundary_levels + interior_levels) if (boundary_levels or interior_levels) else -1
        distance_to_front = max(0, int(current_growth_level - max_boundary_level))
        return {
            "current_front_level": int(current_growth_level),
            "max_boundary_level": int(max_boundary_level),
            "min_boundary_level": int(min_boundary_level),
            "max_region_level": int(max_region_level),
            "distance_to_front": distance_to_front,
            "touches_front": int(distance_to_front == 0),
            "child_max_level": int(max(child_levels)) if child_levels else -1,
            "child_min_level": int(min(child_levels)) if child_levels else -1,
        }

    # ------------------------------------------------------------------
    # Provenance address / spiral rank metadata.
    # ------------------------------------------------------------------

    def address_orders(self, node_id: int) -> List[int]:
        """Return the root-to-node birth-order address, excluding the root.

        For ternary growth the entries are 1, 2, 3.  This is the discrete
        provenance word whose accumulated rank phase is used by the v8 spiral
        diagnostic.  It is postprocessing metadata; it is not fed back into the
        growth law.
        """
        orders: List[int] = []
        cur: Optional[int] = node_id
        while cur is not None and self.nodes[cur].parent is not None:
            orders.append(int(self.nodes[cur].birth_order))
            cur = self.nodes[cur].parent
        orders.reverse()
        return orders

    def signed_rank_value(self, order: int) -> float:
        # For b=3: firstborn -> -1, middle -> 0, lastborn -> +1.
        return float(order - ((self.branching + 1) / 2.0))

    def rank_theta_from_orders(self, orders: Sequence[int], decay: float = 0.75) -> float:
        if not orders:
            return 0.0
        n = len(orders)
        return float(sum((decay ** (n - 1 - i)) * self.signed_rank_value(o) for i, o in enumerate(orders)))

    def rank_phase_components_from_orders(self, orders: Sequence[int], decay: float = 0.75) -> Tuple[float, float]:
        """Return a real two-component accumulated birth-rank phase.

        This uses only real postprocessing coordinates (cos/sin components) to
        expose a possible helical ordering of addresses.  It is not a complex
        input to the growth model.
        """
        if not orders:
            return 0.0, 0.0
        n = len(orders)
        c = 0.0
        s = 0.0
        for i, o in enumerate(orders):
            weight = decay ** (n - 1 - i)
            angle = 2.0 * math.pi * float(o - 1) / float(self.branching)
            c += weight * math.cos(angle)
            s += weight * math.sin(angle)
        return float(c), float(s)

    @staticmethod
    def deterministic_order_permutation(seed: int) -> Tuple[int, int, int]:
        """A deterministic non-random-looking local permutation of (1,2,3)."""
        perms = [
            (2, 3, 1),
            (3, 1, 2),
            (1, 3, 2),
            (3, 2, 1),
            (2, 1, 3),
        ]
        return perms[abs(seed) % len(perms)]

    def sibling_rank_shuffled_orders(self, orders: Sequence[int], salt: int) -> List[int]:
        """Deterministically shuffle sibling ranks along an address word.

        This is a negative-control coordinate: the address length is retained,
        but every local birth-rank digit is remapped by a deterministic
        parent/prefix-dependent permutation.  A genuine spiral signal should be
        suppressed when omega is paired with this shuffled rank phase.
        """
        shuffled: List[int] = []
        prefix_code = 0
        for depth, o in enumerate(orders, start=1):
            perm = self.deterministic_order_permutation(7919 * (salt + 1) + 104729 * depth + 37 * prefix_code)
            shuffled_o = perm[int(o) - 1]
            shuffled.append(int(shuffled_o))
            prefix_code = prefix_code * 5 + int(o)
        return shuffled

    def provenance_rank_metadata(self, spec: RegionSpec) -> dict:
        """Birth-rank metadata for helical/spiral diagnostics.

        The region is indexed by the parent cut.  The local F1/F2 orientation
        lives on the boundary response, but the accumulated spiral phase lives
        on the parent's root-to-node address.  This avoids treating orientation
        as an individual node label while still preserving birth-rank history.
        """
        orders = self.address_orders(spec.parent)
        theta = self.rank_theta_from_orders(orders)
        phase_c, phase_s = self.rank_phase_components_from_orders(orders)
        shuffled_orders = self.sibling_rank_shuffled_orders(orders, salt=spec.parent)
        shuffled_theta = self.rank_theta_from_orders(shuffled_orders)
        reversed_orders = [self.branching + 1 - int(o) for o in orders]
        reversed_theta = self.rank_theta_from_orders(reversed_orders)
        parent_birth_rank_signed = self.signed_rank_value(self.nodes[spec.parent].birth_order) if self.nodes[spec.parent].parent is not None else 0.0
        parent_sector = "root"
        if self.nodes[spec.parent].parent is not None:
            parent_sector = {1: "firstborn", 2: "middleborn", 3: "lastborn"}.get(int(self.nodes[spec.parent].birth_order), "unknown")
        return {
            "cohort_id": f"{spec.region_type}:parent={spec.parent}",
            "parent_address": ".".join(map(str, orders)) if orders else "root",
            "parent_address_depth": len(orders),
            "parent_birth_order": int(self.nodes[spec.parent].birth_order),
            "parent_birth_rank_signed": parent_birth_rank_signed,
            "parent_birth_rank_sector": parent_sector,
            "theta_rank": theta,
            "theta_rank_abs": abs(theta),
            "theta_rank_reversed": reversed_theta,
            "theta_rank_sibling_shuffle": shuffled_theta,
            "rank_phase_cos": phase_c,
            "rank_phase_sin": phase_s,
            "rank_phase_radius": float(math.hypot(phase_c, phase_s)),
        }

    def add_normalized_orientation_metrics(self, row: dict) -> None:
        """Add raw and normalized orientation observables to a region row.

        Audit note: omega/||Lambda|| is *not* allowed to be the only verdict
        metric.  It is retained as a scale-share diagnostic because it can turn
        a rising raw omega profile into a falling normalized profile when the
        total Schur-response norm grows faster than omega.  The front/bulk
        verdict below therefore reports raw-omega slopes, Lambda-norm slopes,
        normalized slopes, and a normalization-artifact flag separately.
        """
        norm_lambda = max(float(row.get("norm_lambda_live", math.nan)), self.eps)
        sym_norm = max(float(row.get("sym_norm_live", math.nan)), self.eps)
        skew_norm = max(float(row.get("skew_norm_live", math.nan)), self.eps)
        for key in ["omega_sibling", "omega_f1f2", "omega_f1f2_curv"]:
            try:
                omega = float(row.get(key, math.nan))
            except (TypeError, ValueError):
                omega = math.nan
            row[f"abs_{key}"] = abs(omega) if math.isfinite(omega) else math.nan
            row[f"abs_{key}_over_lambda"] = abs(omega) / norm_lambda if math.isfinite(omega) else math.nan
            row[f"abs_{key}_over_sym"] = abs(omega) / sym_norm if math.isfinite(omega) else math.nan
            row[f"abs_{key}_over_skew"] = abs(omega) / skew_norm if math.isfinite(omega) else math.nan
            row[f"sign_{key}"] = 1 if math.isfinite(omega) and omega > 0 else (-1 if math.isfinite(omega) and omega < 0 else 0)

        # Legacy normalized scale-share metric for the front/bulk profile:
        # rootward_sibling_cone -> F1/F2; otherwise sibling-sector fallback.
        # The raw omega and Lambda-norm are tracked separately in the trajectory verdict.
        if row.get("region_type") == "rootward_sibling_cone" and math.isfinite(float(row.get("abs_omega_f1f2_over_lambda", math.nan))):
            row["primary_orientation_metric"] = float(row["abs_omega_f1f2_over_lambda"])
            row["primary_orientation_norm_over_lambda"] = float(row["abs_omega_f1f2_over_lambda"])
            row["primary_orientation_norm_over_sym"] = float(row["abs_omega_f1f2_over_sym"])
            row["primary_orientation_raw_abs_omega"] = float(row["abs_omega_f1f2"])
            row["primary_omega_signed"] = float(row.get("omega_f1f2", math.nan))
            row["primary_orientation_axis"] = "f1f2"
            row["primary_orientation_sign"] = int(row["sign_omega_f1f2"])
        else:
            row["primary_orientation_metric"] = float(row.get("abs_omega_sibling_over_lambda", math.nan))
            row["primary_orientation_norm_over_lambda"] = float(row.get("abs_omega_sibling_over_lambda", math.nan))
            row["primary_orientation_norm_over_sym"] = float(row.get("abs_omega_sibling_over_sym", math.nan))
            row["primary_orientation_raw_abs_omega"] = float(row.get("abs_omega_sibling", math.nan))
            row["primary_omega_signed"] = float(row.get("omega_sibling", math.nan))
            row["primary_orientation_axis"] = "sibling"
            row["primary_orientation_sign"] = int(row.get("sign_omega_sibling", 0))

    # ------------------------------------------------------------------
    # Region selection.
    # ------------------------------------------------------------------

    def region_specs_for_parent(self, parent: int) -> List[RegionSpec]:
        node = self.nodes[parent]
        if len(node.children) != 3:
            return []
        c1, c2, c3 = node.children
        specs = [
            RegionSpec(
                region_type="sibling_star",
                parent=parent,
                boundary=[c1, c2, c3],
                interior=[parent],
                children=[c1, c2, c3],
                rootward=None,
            )
        ]

        if node.parent is not None:
            specs.append(
                RegionSpec(
                    region_type="rootward_sibling_cone",
                    parent=parent,
                    boundary=[node.parent, c1, c2, c3],
                    interior=[parent],
                    children=[c1, c2, c3],
                    rootward=node.parent,
                )
            )

        if self.include_shell_h2 and node.parent is not None:
            leaves: List[int] = []
            complete = True
            for c in [c1, c2, c3]:
                gc = self.nodes[c].children
                if len(gc) != 3:
                    complete = False
                    break
                leaves.extend(gc)
            if complete:
                specs.append(
                    RegionSpec(
                        region_type="subtree_shell_h2",
                        parent=parent,
                        boundary=[node.parent] + leaves,
                        interior=[parent, c1, c2, c3],
                        children=[c1, c2, c3],
                        rootward=node.parent,
                    )
                )
        return specs

    def current_region_specs(self) -> List[RegionSpec]:
        specs: List[RegionSpec] = []
        for p in self.completed_parents():
            specs.extend(self.region_specs_for_parent(p))
        return specs

    # ------------------------------------------------------------------
    # Skew/J-block diagnostics.
    # ------------------------------------------------------------------

    @staticmethod
    def z3_sibling_basis() -> np.ndarray:
        u1 = np.array([1.0, -1.0, 0.0]) / math.sqrt(2.0)
        u2 = np.array([1.0, 1.0, -2.0]) / math.sqrt(6.0)
        return np.column_stack([u1, u2])

    @staticmethod
    def f1f2_basis() -> np.ndarray:
        f1 = np.array([-3.0, 1.0, 1.0, 1.0])
        f1 /= np.linalg.norm(f1)
        f2 = np.array([0.0, -1.0, 0.0, 1.0])
        f2 /= np.linalg.norm(f2)
        return np.column_stack([f1, f2])

    @staticmethod
    def f1f2_curvature_basis() -> np.ndarray:
        f1 = np.array([-3.0, 1.0, 1.0, 1.0])
        f1 /= np.linalg.norm(f1)
        f2_curv = np.array([0.0, 1.0, -2.0, 1.0])
        f2_curv /= np.linalg.norm(f2_curv)
        return np.column_stack([f1, f2_curv])

    @staticmethod
    def j_metrics(A2: np.ndarray, eps: float = EPS) -> dict:
        J0 = np.array([[0.0, -1.0], [1.0, 0.0]])
        omega = float(0.5 * (A2[1, 0] - A2[0, 1]))
        norm_A2 = float(np.linalg.norm(A2, ord="fro"))
        j_residual = float(np.linalg.norm(A2 - omega * J0, ord="fro") / max(norm_A2, eps))
        if abs(omega) > eps:
            J_est = A2 / omega
            j2_residual = float(np.linalg.norm(J_est @ J_est + np.eye(2), ord="fro"))
        else:
            j2_residual = math.nan
        return {
            "omega": omega,
            "j_residual": j_residual,
            "j2_residual": j2_residual,
            "omega_nonzero": int(abs(omega) > eps),
        }

    def full_skew_metrics(self, A: np.ndarray) -> dict:
        eig = np.linalg.eigvals(A)
        abs_imags = sorted([abs(float(z.imag)) for z in eig if abs(float(z.imag)) > self.tol], reverse=True)
        largest = abs_imags[0] if abs_imags else 0.0
        second = abs_imags[2] if len(abs_imags) >= 4 else 0.0  # first sigma of second pair if present
        num_pairs = int(round(len(abs_imags) / 2.0))
        pair_sum = sum(abs_imags) / 2.0 if abs_imags else 0.0
        block_dominance = largest / pair_sum if pair_sum > self.eps else 0.0
        rank = int(np.linalg.matrix_rank(A, tol=self.tol))
        return {
            "skew_rank_numeric": rank,
            "num_imag_pairs_A": num_pairs,
            "largest_sigma_A": largest,
            "second_sigma_A": second,
            "block_dominance_A": block_dominance,
            "one_skew_pair": int(num_pairs == 1),
            "eigvals_A": " ".join(f"{z.real:.9g}{z.imag:+.9g}j" for z in eig),
        }

    def projection_metrics(self, spec: RegionSpec, A: np.ndarray) -> dict:
        out = {
            "omega_sibling": math.nan,
            "j_residual_sibling": math.nan,
            "j2_residual_sibling": math.nan,
            "omega_sibling_nonzero": 0,
            "omega_f1f2": math.nan,
            "j_residual_f1f2": math.nan,
            "j2_residual_f1f2": math.nan,
            "omega_f1f2_nonzero": 0,
            "omega_f1f2_curv": math.nan,
            "j_residual_f1f2_curv": math.nan,
            "j2_residual_f1f2_curv": math.nan,
            "omega_f1f2_curv_nonzero": 0,
            "kappa_omega": math.nan,
            "kappa_flips_sign": 0,
            "kappa_preserves_birth_order": 0,
        }

        b_index = {node_id: i for i, node_id in enumerate(spec.boundary)}
        child_indices = [b_index[c] for c in spec.children if c in b_index]

        if len(child_indices) == 3:
            A3 = A[np.ix_(child_indices, child_indices)]
            B3 = self.z3_sibling_basis()
            jm = self.j_metrics(B3.T @ A3 @ B3, eps=self.eps)
            out.update(
                {
                    "omega_sibling": jm["omega"],
                    "j_residual_sibling": jm["j_residual"],
                    "j2_residual_sibling": jm["j2_residual"],
                    "omega_sibling_nonzero": jm["omega_nonzero"],
                }
            )

            K3 = np.array([[0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [1.0, 0.0, 0.0]])
            A3_kappa = K3 @ A3 @ K3.T
            jm_k = self.j_metrics(B3.T @ A3_kappa @ B3, eps=self.eps)
            out["kappa_omega"] = jm_k["omega"]
            out["kappa_flips_sign"] = int(abs(jm["omega"] + jm_k["omega"]) <= max(1e-8, 1e-7 * abs(jm["omega"])))

            birth = np.array([self.nodes[c].birth_time for c in spec.children], dtype=float)
            birth_kappa = K3 @ birth
            out["kappa_preserves_birth_order"] = int(bool(np.all(np.diff(birth_kappa) > 0)))

        if spec.region_type == "rootward_sibling_cone" and len(spec.boundary) == 4:
            B4 = self.f1f2_basis()
            jm = self.j_metrics(B4.T @ A @ B4, eps=self.eps)
            out.update(
                {
                    "omega_f1f2": jm["omega"],
                    "j_residual_f1f2": jm["j_residual"],
                    "j2_residual_f1f2": jm["j2_residual"],
                    "omega_f1f2_nonzero": jm["omega_nonzero"],
                }
            )
            B4c = self.f1f2_curvature_basis()
            jmc = self.j_metrics(B4c.T @ A @ B4c, eps=self.eps)
            out.update(
                {
                    "omega_f1f2_curv": jmc["omega"],
                    "j_residual_f1f2_curv": jmc["j_residual"],
                    "j2_residual_f1f2_curv": jmc["j2_residual"],
                    "omega_f1f2_curv_nonzero": jmc["omega_nonzero"],
                }
            )

            K4 = np.array(
                [
                    [1.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 1.0],
                    [0.0, 0.0, 1.0, 0.0],
                    [0.0, 1.0, 0.0, 0.0],
                ]
            )
            jm_k = self.j_metrics(B4.T @ (K4 @ A @ K4.T) @ B4, eps=self.eps)
            out["kappa_omega"] = jm_k["omega"]
            out["kappa_flips_sign"] = int(abs(jm["omega"] + jm_k["omega"]) <= max(1e-8, 1e-7 * abs(jm["omega"])))

            birth = np.array([self.nodes[c].birth_time for c in spec.children], dtype=float)
            birth_kappa = np.array([birth[2], birth[1], birth[0]])
            out["kappa_preserves_birth_order"] = int(bool(np.all(np.diff(birth_kappa) > 0)))

        return out

    @staticmethod
    def skew_metrics_from_lambda(Lambda: np.ndarray, eps: float = EPS) -> Tuple[np.ndarray, np.ndarray, dict]:
        S = 0.5 * (Lambda + Lambda.T)
        A = 0.5 * (Lambda - Lambda.T)
        norm_L = float(np.linalg.norm(Lambda, ord="fro"))
        skew_norm = float(np.linalg.norm(A, ord="fro"))
        sym_norm = float(np.linalg.norm(S, ord="fro"))
        return S, A, {
            "norm_lambda_live": norm_L,
            "skew_norm_live": skew_norm,
            "sym_norm_live": sym_norm,
            "rel_skew_live": skew_norm / max(norm_L, eps),
        }

    @staticmethod
    def real_doubled_symmetric_operator(Lambda: np.ndarray) -> np.ndarray:
        """Map a real Schur response Lambda=S+A to a real symmetric doubled operator.

        For S^T=S and A^T=-A,

            H_R = [[S, A], [-A, S]]

        is real symmetric.  This is a finite diagnostic representation of the
        Hermitian shape S+iA without using it as a CNNA input structure.
        """
        S = 0.5 * (Lambda + Lambda.T)
        A = 0.5 * (Lambda - Lambda.T)
        return np.block([[S, A], [-A, S]])

    def gibbs_density_from_symmetric_operator(
        self,
        H: np.ndarray,
        beta: float = 1.0,
        shape_normalize: bool = True,
    ) -> Tuple[np.ndarray, float]:
        """Return rho = exp(-beta H)/Tr exp(-beta H) using eigenvalues only.

        Constant energy shifts are removed.  With ``shape_normalize=True`` the
        centered spectrum is divided by its spectral standard deviation.  This
        intentionally suppresses trivial growth of the total conductance scale
        and is therefore closer to a finite shape/distinguishability proxy than
        to a raw-energy thermodynamic state.
        """
        Hs = 0.5 * (H + H.T)
        n = Hs.shape[0]
        tr = float(np.trace(Hs) / max(n, 1))
        Hc = Hs - tr * np.eye(n)
        evals, evecs = np.linalg.eigh(Hc)
        scale = 1.0
        if shape_normalize:
            scale = float(np.std(evals))
            if not math.isfinite(scale) or scale < self.eps:
                scale = 1.0
            evals = evals / scale
        shifted = -beta * evals
        shifted = shifted - float(np.max(shifted))
        weights = np.exp(shifted)
        weights = weights / max(float(np.sum(weights)), self.eps)
        rho = (evecs * weights) @ evecs.T
        rho = 0.5 * (rho + rho.T)
        return rho, scale

    def matrix_log_density(self, rho: np.ndarray) -> np.ndarray:
        rho_s = 0.5 * (rho + rho.T)
        evals, evecs = np.linalg.eigh(rho_s)
        evals = np.clip(evals, self.eps, None)
        return (evecs * np.log(evals)) @ evecs.T

    def finite_relative_entropy(self, rho: np.ndarray, sigma: np.ndarray) -> float:
        """Finite-dimensional Umegaki relative entropy Tr rho(log rho-log sigma)."""
        lr = self.matrix_log_density(rho)
        ls = self.matrix_log_density(sigma)
        value = float(np.trace(rho @ (lr - ls)))
        # Numerical roundoff can produce tiny negative values.
        return 0.0 if -1e-12 < value < 0.0 else value

    def entropy_proxy_metrics(self, live_lambda: np.ndarray, ref_lambda: np.ndarray, prefix: str) -> dict:
        """Finite diagnostic relative-entropy proxies between live and reference responses.

        The shape-normalized proxy is the main anti-artifact diagnostic; the
        scale-sensitive proxy is reported separately.  Both are finite-matrix
        surrogates, not Type-III/Araki relative entropy.
        """
        out = {
            f"{prefix}_state_proxy": "real_doubled_schur_gibbs",
            f"{prefix}_state_dim": 0,
            # Forward Umegaki direction: D(rho_live || rho_ref).
            f"{prefix}_rel_entropy_shape": math.nan,
            f"{prefix}_rel_entropy_scale_sensitive": math.nan,
            # Reverse Umegaki direction: D(rho_ref || rho_live).
            f"{prefix}_rel_entropy_reverse_shape": math.nan,
            f"{prefix}_rel_entropy_reverse_scale_sensitive": math.nan,
            # Signed directionality diagnostics.  These are not entropies;
            # they measure the non-symmetric part of the finite proxy.
            f"{prefix}_rel_entropy_directional_shape": math.nan,
            f"{prefix}_rel_entropy_directional_scale_sensitive": math.nan,
            f"{prefix}_rel_entropy_directional_abs_shape": math.nan,
            f"{prefix}_rel_entropy_directional_ratio_shape": math.nan,
            f"{prefix}_shape_scale_live": math.nan,
            f"{prefix}_shape_scale_ref": math.nan,
            f"{prefix}_valid": 0,
        }
        try:
            H_live = self.real_doubled_symmetric_operator(live_lambda)
            H_ref = self.real_doubled_symmetric_operator(ref_lambda)
            rho_shape, scale_live = self.gibbs_density_from_symmetric_operator(H_live, shape_normalize=True)
            sigma_shape, scale_ref = self.gibbs_density_from_symmetric_operator(H_ref, shape_normalize=True)
            rho_scale, _ = self.gibbs_density_from_symmetric_operator(H_live, shape_normalize=False)
            sigma_scale, _ = self.gibbs_density_from_symmetric_operator(H_ref, shape_normalize=False)
            d_shape_fwd = self.finite_relative_entropy(rho_shape, sigma_shape)
            d_shape_rev = self.finite_relative_entropy(sigma_shape, rho_shape)
            d_scale_fwd = self.finite_relative_entropy(rho_scale, sigma_scale)
            d_scale_rev = self.finite_relative_entropy(sigma_scale, rho_scale)
            d_shape_dir = d_shape_fwd - d_shape_rev
            d_scale_dir = d_scale_fwd - d_scale_rev
            out.update(
                {
                    f"{prefix}_state_dim": int(H_live.shape[0]),
                    f"{prefix}_rel_entropy_shape": d_shape_fwd,
                    f"{prefix}_rel_entropy_scale_sensitive": d_scale_fwd,
                    f"{prefix}_rel_entropy_reverse_shape": d_shape_rev,
                    f"{prefix}_rel_entropy_reverse_scale_sensitive": d_scale_rev,
                    f"{prefix}_rel_entropy_directional_shape": d_shape_dir,
                    f"{prefix}_rel_entropy_directional_scale_sensitive": d_scale_dir,
                    f"{prefix}_rel_entropy_directional_abs_shape": abs(d_shape_dir),
                    f"{prefix}_rel_entropy_directional_ratio_shape": d_shape_dir / max(d_shape_fwd + d_shape_rev, self.eps),
                    f"{prefix}_shape_scale_live": scale_live,
                    f"{prefix}_shape_scale_ref": scale_ref,
                    f"{prefix}_valid": 1,
                }
            )
        except Exception as exc:  # deterministic diagnostic; keep failure visible in CSV
            out[f"{prefix}_error"] = str(exc)
        return out

    def analyze_region(self, spec: RegionSpec, Ks: Dict[str, np.ndarray], level: int) -> dict:
        geometry = self.front_bulk_geometry(spec, current_growth_level=level)
        base_row = {
            "mode": self.mode,
            "level": level,
            "time": self.t,
            "parent": spec.parent,
            "parent_level": self.nodes[spec.parent].level,
            "region_type": spec.region_type,
            "boundary_nodes": " ".join(map(str, spec.boundary)),
            "interior_nodes": " ".join(map(str, spec.interior)),
            "children": " ".join(map(str, spec.children)),
            "rootward": spec.rootward if spec.rootward is not None else "",
            "n_boundary": len(spec.boundary),
            "n_interior": len(spec.interior),
            "valid_live": 0,
            "schur_error_live": "",
            "relational_live_update": int(self.relational_live_update),
            "live_relation_target_scale": self.live_relation_target_scale,
            "live_env_relation_groups": len(self.live_env_relation_groups),
            "live_backreaction_relations": len(self.live_backreaction_relations),
            "relational_rebuild_count": self.relational_rebuild_count,
        }
        base_row.update(geometry)
        base_row.update(self.provenance_rank_metadata(spec))

        live = self.schur_response(Ks["live"], spec.boundary, spec.interior)
        if not live.ok or live.Lambda is None:
            base_row.update(
                {
                    "cond_KII_live": live.cond_KII,
                    "solve_residual_live": live.solve_residual,
                    "row_sum_residual_live": live.row_sum_residual,
                    "schur_error_live": live.error,
                }
            )
            return base_row

        base_row.update(
            {
                "valid_live": 1,
                "cond_KII_live": live.cond_KII,
                "solve_residual_live": live.solve_residual,
                "row_sum_residual_live": live.row_sum_residual,
            }
        )

        _, A_live, live_metrics = self.skew_metrics_from_lambda(live.Lambda, eps=self.eps)
        base_row.update(live_metrics)
        base_row.update(self.full_skew_metrics(A_live))
        base_row.update(self.projection_metrics(spec, A_live))
        self.add_normalized_orientation_metrics(base_row)

        # Symmetric tree-control.
        sym = self.schur_response(Ks["sym"], spec.boundary, spec.interior)
        if sym.ok and sym.Lambda is not None:
            _, A_sym, _ = self.skew_metrics_from_lambda(sym.Lambda, eps=self.eps)
            base_row["rel_skew_sym_control"] = float(np.linalg.norm(A_sym, ord="fro") / max(np.linalg.norm(sym.Lambda, ord="fro"), self.eps))
            smetrics = self.projection_metrics(spec, A_sym)
            base_row["omega_sym_control"] = smetrics["omega_f1f2"] if math.isfinite(float(smetrics.get("omega_f1f2", math.nan))) else smetrics["omega_sibling"]
            base_row.update(self.entropy_proxy_metrics(live.Lambda, sym.Lambda, prefix="entropy_live_vs_sym"))
        else:
            base_row["rel_skew_sym_control"] = math.nan
            base_row["schur_error_sym_control"] = sym.error

        # Symmetrized-live control.
        symdir = self.schur_response(Ks["symdir"], spec.boundary, spec.interior)
        if symdir.ok and symdir.Lambda is not None:
            _, A_symdir, _ = self.skew_metrics_from_lambda(symdir.Lambda, eps=self.eps)
            base_row["rel_skew_symdir_control"] = float(np.linalg.norm(A_symdir, ord="fro") / max(np.linalg.norm(symdir.Lambda, ord="fro"), self.eps))
            sdmetrics = self.projection_metrics(spec, A_symdir)
            base_row["omega_symdir_control"] = sdmetrics["omega_f1f2"] if math.isfinite(float(sdmetrics.get("omega_f1f2", math.nan))) else sdmetrics["omega_sibling"]
            base_row.update(self.entropy_proxy_metrics(live.Lambda, symdir.Lambda, prefix="entropy_live_vs_symdir"))
        else:
            base_row["rel_skew_symdir_control"] = math.nan
            base_row["schur_error_symdir_control"] = symdir.error

        # F1-only axis control: remove all directed sibling couplings.
        # This tests whether the longitudinal root/front channel alone carries orientation.
        f1_only = self.schur_response(Ks["f1_only"], spec.boundary, spec.interior)
        if f1_only.ok and f1_only.Lambda is not None:
            _, A_f1, _ = self.skew_metrics_from_lambda(f1_only.Lambda, eps=self.eps)
            base_row["valid_f1_only_control"] = 1
            base_row["omega_f1_only_control"] = self.selected_axis_omega(spec, A_f1, axis="f1")
            base_row["rel_skew_f1_only_control"] = float(
                np.linalg.norm(A_f1, ord="fro") / max(np.linalg.norm(f1_only.Lambda, ord="fro"), self.eps)
            )
        else:
            base_row["valid_f1_only_control"] = 0
            base_row["omega_f1_only_control"] = math.nan
            base_row["rel_skew_f1_only_control"] = math.nan
            base_row["schur_error_f1_only_control"] = f1_only.error

        # F2-only axis control: remove all longitudinal directed couplings.
        # The original Schur interior is then disconnected by construction, so diagnose
        # the directed sibling boundary block explicitly.
        f2_only = self.boundary_block_response(Ks["f2_only"], spec.children)
        if f2_only.ok and f2_only.Lambda is not None:
            _, A_f2, _ = self.skew_metrics_from_lambda(f2_only.Lambda, eps=self.eps)
            fake_spec = RegionSpec(
                region_type="sibling_star",
                parent=spec.parent,
                boundary=list(spec.children),
                interior=[],
                children=list(spec.children),
                rootward=None,
            )
            base_row["valid_f2_only_control"] = 1
            base_row["f2_only_response_kind"] = "sibling_boundary_block"
            base_row["omega_f2_only_control"] = self.selected_axis_omega(fake_spec, A_f2, axis="f2")
            base_row["rel_skew_f2_only_control"] = float(
                np.linalg.norm(A_f2, ord="fro") / max(np.linalg.norm(f2_only.Lambda, ord="fro"), self.eps)
            )
        else:
            base_row["valid_f2_only_control"] = 0
            base_row["f2_only_response_kind"] = "sibling_boundary_block"
            base_row["omega_f2_only_control"] = math.nan
            base_row["rel_skew_f2_only_control"] = math.nan
            base_row["schur_error_f2_only_control"] = f2_only.error

        # Record-only control.
        record = self.schur_response(Ks["record"], spec.boundary, spec.interior)
        if record.ok and record.Lambda is not None:
            _, A_record, _ = self.skew_metrics_from_lambda(record.Lambda, eps=self.eps)
            rmetrics = self.projection_metrics(spec, A_record)
            base_row["omega_record_only"] = (
                rmetrics["omega_f1f2"] if not math.isnan(rmetrics["omega_f1f2"]) else rmetrics["omega_sibling"]
            )
            base_row["rel_skew_record_only"] = float(np.linalg.norm(A_record, ord="fro") / max(np.linalg.norm(record.Lambda, ord="fro"), self.eps))
        else:
            base_row["omega_record_only"] = math.nan
            base_row["rel_skew_record_only"] = math.nan
            base_row["schur_error_record_only"] = record.error

        # Rootward-cone kappa should use the F1/F2 kappa omega; sibling-star uses sibling omega.
        # projection_metrics has already selected the appropriate overwrite for rootward_sibling_cone.
        return base_row

    def build_all_Ks(self) -> Dict[str, np.ndarray]:
        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()
        symdir_edges = self.symmetrized_edges(self.directed_edges)
        f1_only_edges = self.f1_only_edges()
        f2_only_edges = self.f2_only_edges()
        return {
            "live": self.directed_laplacian(self.directed_edges),
            "sym": self.directed_laplacian(self.sym_edges),
            "symdir": self.directed_laplacian(symdir_edges),
            "f1_only": self.directed_laplacian(f1_only_edges),
            "f2_only": self.directed_laplacian(f2_only_edges),
            "record": self.directed_laplacian(self.record_edges),
        }

    def analyze_current_regions(self, level: int) -> List[dict]:
        specs = self.current_region_specs()
        if not specs:
            return []
        Ks = self.build_all_Ks()
        rows = [self.analyze_region(spec, Ks, level=level) for spec in specs]
        self.region_rows.extend(rows)
        return rows

    # ------------------------------------------------------------------
    # Level summaries.
    # ------------------------------------------------------------------

    @staticmethod
    def finite_values(rows: Sequence[dict], key: str) -> List[float]:
        vals: List[float] = []
        for r in rows:
            try:
                v = float(r.get(key, math.nan))
            except (TypeError, ValueError):
                continue
            if math.isfinite(v):
                vals.append(v)
        return vals

    @staticmethod
    def mean(vals: Sequence[float]) -> float:
        return float(np.mean(vals)) if vals else 0.0

    @staticmethod
    def median(vals: Sequence[float]) -> float:
        return float(np.median(vals)) if vals else 0.0

    def level_summary(self, level: int, rows: Sequence[dict]) -> dict:
        valid = [r for r in rows if int(r.get("valid_live", 0)) == 1]
        rootward = [r for r in valid if r.get("region_type") == "rootward_sibling_cone"]
        sibling = [r for r in valid if r.get("region_type") == "sibling_star"]

        rels = self.finite_values(valid, "rel_skew_live")
        omega_sib = [abs(x) for x in self.finite_values(sibling, "omega_sibling")]
        omega_f1 = [abs(x) for x in self.finite_values(rootward, "omega_f1f2")]
        block_dom = self.finite_values(valid, "block_dominance_A")
        sym_ctrl = self.finite_values(valid, "rel_skew_sym_control")
        symdir_ctrl = self.finite_values(valid, "rel_skew_symdir_control")
        f1_only_omega = [abs(x) for x in self.finite_values(valid, "omega_f1_only_control")]
        f2_only_omega = [abs(x) for x in self.finite_values(valid, "omega_f2_only_control")]

        def frac(rows_: Sequence[dict], pred) -> float:
            return sum(1 for r in rows_ if pred(r)) / len(rows_) if rows_ else 0.0

        row = {
            "mode": self.mode,
            "level": level,
            "time": self.t,
            "nodes": len(self.nodes),
            "completed_triples": len(self.completed_parents()),
            "relational_live_update": int(self.relational_live_update),
            "live_relation_target_scale": self.live_relation_target_scale,
            "live_env_relation_groups": len(self.live_env_relation_groups),
            "live_backreaction_relations": len(self.live_backreaction_relations),
            "relational_rebuild_count": self.relational_rebuild_count,
            "regions_tested": len(rows),
            "regions_valid": len(valid),
            "mean_rel_skew_live": self.mean(rels),
            "median_rel_skew_live": self.median(rels),
            "min_rel_skew_live": min(rels) if rels else 0.0,
            "max_rel_skew_live": max(rels) if rels else 0.0,
            "mean_abs_omega_sibling": self.mean(omega_sib),
            "frac_sibling_omega_nonzero": frac(sibling, lambda r: int(r.get("omega_sibling_nonzero", 0)) == 1),
            "frac_sibling_J2_ok": frac(
                sibling,
                lambda r: math.isfinite(float(r.get("j2_residual_sibling", math.nan)))
                and float(r.get("j2_residual_sibling", math.inf)) < 1e-7,
            ),
            "mean_abs_omega_f1f2": self.mean(omega_f1),
            "frac_f1f2_omega_nonzero": frac(rootward, lambda r: int(r.get("omega_f1f2_nonzero", 0)) == 1),
            "frac_f1f2_J2_ok": frac(
                rootward,
                lambda r: math.isfinite(float(r.get("j2_residual_f1f2", math.nan)))
                and float(r.get("j2_residual_f1f2", math.inf)) < 1e-7,
            ),
            "frac_f1f2_orientation_positive": frac(
                rootward,
                lambda r: math.isfinite(float(r.get("omega_f1f2", math.nan)))
                and float(r.get("omega_f1f2", 0.0)) > 0.0,
            ),
            "mean_block_dominance_A": self.mean(block_dom),
            "frac_one_skew_pair": frac(valid, lambda r: int(r.get("one_skew_pair", 0)) == 1),
            "max_rel_skew_sym_control": max(sym_ctrl) if sym_ctrl else 0.0,
            "max_rel_skew_symdir_control": max(symdir_ctrl) if symdir_ctrl else 0.0,
            "mean_abs_omega_f1_only_control": self.mean(f1_only_omega),
            "frac_f1_only_control_zero": frac(
                valid,
                lambda r: math.isfinite(float(r.get("omega_f1_only_control", math.nan)))
                and abs(float(r.get("omega_f1_only_control", math.inf))) < 1e-10,
            ),
            "frac_f1_only_control_nonzero": frac(
                valid,
                lambda r: math.isfinite(float(r.get("omega_f1_only_control", math.nan)))
                and abs(float(r.get("omega_f1_only_control", 0.0))) >= 1e-10,
            ),
            "mean_abs_omega_f2_only_control": self.mean(f2_only_omega),
            "frac_f2_only_control_zero": frac(
                valid,
                lambda r: math.isfinite(float(r.get("omega_f2_only_control", math.nan)))
                and abs(float(r.get("omega_f2_only_control", math.inf))) < 1e-10,
            ),
            "frac_f2_only_control_nonzero": frac(
                valid,
                lambda r: math.isfinite(float(r.get("omega_f2_only_control", math.nan)))
                and abs(float(r.get("omega_f2_only_control", 0.0))) >= 1e-10,
            ),
            "frac_kappa_flips": frac(valid, lambda r: int(r.get("kappa_flips_sign", 0)) == 1),
            "frac_kappa_preserves_birth_order": frac(valid, lambda r: int(r.get("kappa_preserves_birth_order", 0)) == 1),
        }
        self.level_rows.append(row)
        return row

    def depth_trajectory_rows(self) -> List[dict]:
        """Aggregate orientation, scale, and entropy proxies by moving-front distance."""
        groups: Dict[Tuple[int, str, int], List[dict]] = defaultdict(list)
        for r in self.region_rows:
            if int(r.get("valid_live", 0)) != 1:
                continue
            key = (int(r.get("level", -1)), str(r.get("region_type", "")), int(r.get("distance_to_front", -1)))
            groups[key].append(r)

        def frac(rows_: Sequence[dict], pred) -> float:
            return sum(1 for x in rows_ if pred(x)) / len(rows_) if rows_ else 0.0

        out: List[dict] = []
        for (level, region_type, distance), rows in sorted(groups.items()):
            normed = self.finite_values(rows, "primary_orientation_norm_over_lambda")
            raw = self.finite_values(rows, "primary_orientation_raw_abs_omega")
            if not normed and not raw:
                continue
            lambda_norms = self.finite_values(rows, "norm_lambda_live")
            sym_norms = self.finite_values(rows, "sym_norm_live")
            skew_norms = self.finite_values(rows, "skew_norm_live")
            rels = self.finite_values(rows, "rel_skew_live")
            ent_shape_sym = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_shape")
            ent_shape_sym_reverse = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_reverse_shape")
            ent_shape_sym_directional = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_directional_shape")
            ent_shape_sym_directional_abs = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_directional_abs_shape")
            ent_shape_sym_directional_ratio = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_directional_ratio_shape")
            ent_shape_symdir = self.finite_values(rows, "entropy_live_vs_symdir_rel_entropy_shape")
            ent_shape_symdir_reverse = self.finite_values(rows, "entropy_live_vs_symdir_rel_entropy_reverse_shape")
            ent_shape_symdir_directional = self.finite_values(rows, "entropy_live_vs_symdir_rel_entropy_directional_shape")
            ent_scale_sym = self.finite_values(rows, "entropy_live_vs_sym_rel_entropy_scale_sensitive")
            f1f2_norm = self.finite_values(rows, "abs_omega_f1f2_over_lambda")
            sibling_norm = self.finite_values(rows, "abs_omega_sibling_over_lambda")
            out.append(
                {
                    "mode": self.mode,
                    "level": level,
                    "region_type": region_type,
                    "distance_to_front": distance,
                    "touches_front": int(distance == 0),
                    "count": len(rows),
                    "mean_primary_orientation_norm_over_lambda": self.mean(normed),
                    "median_primary_orientation_norm_over_lambda": self.median(normed),
                    "mean_primary_orientation_metric": self.mean(normed),  # legacy alias
                    "median_primary_orientation_metric": self.median(normed),  # legacy alias
                    "mean_primary_raw_abs_omega": self.mean(raw),
                    "median_primary_raw_abs_omega": self.median(raw),
                    "mean_norm_lambda_live": self.mean(lambda_norms),
                    "median_norm_lambda_live": self.median(lambda_norms),
                    "mean_sym_norm_live": self.mean(sym_norms),
                    "mean_skew_norm_live": self.mean(skew_norms),
                    "mean_rel_skew_live": self.mean(rels),
                    "mean_abs_omega_f1f2_over_lambda": self.mean(f1f2_norm),
                    "mean_abs_omega_sibling_over_lambda": self.mean(sibling_norm),
                    "mean_entropy_shape_live_vs_sym": self.mean(ent_shape_sym),
                    "median_entropy_shape_live_vs_sym": self.median(ent_shape_sym),
                    "mean_entropy_shape_sym_vs_live": self.mean(ent_shape_sym_reverse),
                    "median_entropy_shape_sym_vs_live": self.median(ent_shape_sym_reverse),
                    "mean_entropy_shape_directional_live_minus_sym": self.mean(ent_shape_sym_directional),
                    "mean_abs_entropy_shape_directional_live_minus_sym": self.mean(ent_shape_sym_directional_abs),
                    "mean_entropy_shape_directional_ratio_live_minus_sym": self.mean(ent_shape_sym_directional_ratio),
                    "mean_entropy_shape_live_vs_symdir": self.mean(ent_shape_symdir),
                    "mean_entropy_shape_symdir_vs_live": self.mean(ent_shape_symdir_reverse),
                    "mean_entropy_shape_directional_live_minus_symdir": self.mean(ent_shape_symdir_directional),
                    "mean_entropy_scale_sensitive_live_vs_sym": self.mean(ent_scale_sym),
                    "frac_primary_orientation_positive": frac(rows, lambda r: int(r.get("primary_orientation_sign", 0)) > 0),
                    "frac_primary_orientation_negative": frac(rows, lambda r: int(r.get("primary_orientation_sign", 0)) < 0),
                    "frac_kappa_flips": frac(rows, lambda r: int(r.get("kappa_flips_sign", 0)) == 1),
                }
            )
        return out

    @staticmethod
    def log_slope_for_distance_values(d_to_v: Dict[int, float], eps: float = EPS) -> float:
        positive = [(d, v) for d, v in sorted(d_to_v.items()) if math.isfinite(v) and v > eps]
        if len(positive) < 2:
            return math.nan
        xs = np.array([d for d, _ in positive], dtype=float)
        ys = np.log(np.array([v for _, v in positive], dtype=float))
        return float(np.polyfit(xs, ys, 1)[0])

    @staticmethod
    def linear_slope_for_distance_values(d_to_v: Dict[int, float]) -> float:
        finite = [(d, v) for d, v in sorted(d_to_v.items()) if math.isfinite(v)]
        if len(finite) < 2:
            return math.nan
        xs = np.array([d for d, _ in finite], dtype=float)
        ys = np.array([v for _, v in finite], dtype=float)
        return float(np.polyfit(xs, ys, 1)[0])

    def front_bulk_verdict_rows(self, trajectory_rows: Sequence[dict]) -> List[dict]:
        """Summarize finite-L front/bulk profiles without hiding scale artifacts.

        The old v3 verdict used omega/||Lambda|| as the primary gate.  The audit
        showed that this can invert the raw signal when ||Lambda|| grows faster
        into the bulk.  The v5 verdict therefore reports separate slopes for:

        - raw orientation omega;
        - total Schur response norm ||Lambda||;
        - normalized scale-share omega/||Lambda||;
        - finite relative-entropy proxy against the symmetric twin.

        A normalization artifact is flagged when normalized orientation decays
        while raw omega does not decay and ||Lambda|| grows with distance.
        """
        by_type: Dict[str, List[dict]] = defaultdict(list)
        for r in trajectory_rows:
            by_type[str(r.get("region_type", ""))].append(r)

        verdicts: List[dict] = []
        for region_type, rows in sorted(by_type.items()):
            by_level: Dict[int, List[dict]] = defaultdict(list)
            for r in rows:
                by_level[int(r["level"])].append(r)

            front_normed: List[float] = []
            front_raw: List[float] = []
            front_entropy_shape: List[float] = []
            front_entropy_shape_reverse: List[float] = []
            front_entropy_directional_signed: List[float] = []
            front_entropy_directional_abs: List[float] = []
            normed_slopes: List[float] = []
            raw_slopes: List[float] = []
            lambda_slopes: List[float] = []
            entropy_shape_slopes: List[float] = []
            entropy_shape_reverse_slopes: List[float] = []
            entropy_shape_directional_abs_slopes: List[float] = []
            entropy_shape_directional_signed_linear_slopes: List[float] = []
            entropy_symdir_slopes: List[float] = []
            front_over_bulk_normed: List[float] = []
            front_over_bulk_raw: List[float] = []
            artifact_levels = 0
            levels_with_profile = 0

            for level, lrows in sorted(by_level.items()):
                by_distance = {int(r["distance_to_front"]): r for r in lrows}
                d_normed = {d: float(r.get("mean_primary_orientation_norm_over_lambda", math.nan)) for d, r in by_distance.items()}
                d_raw = {d: float(r.get("mean_primary_raw_abs_omega", math.nan)) for d, r in by_distance.items()}
                d_lambda = {d: float(r.get("mean_norm_lambda_live", math.nan)) for d, r in by_distance.items()}
                d_ent_shape = {d: float(r.get("mean_entropy_shape_live_vs_sym", math.nan)) for d, r in by_distance.items()}
                d_ent_shape_reverse = {d: float(r.get("mean_entropy_shape_sym_vs_live", math.nan)) for d, r in by_distance.items()}
                d_ent_shape_directional_signed = {d: float(r.get("mean_entropy_shape_directional_live_minus_sym", math.nan)) for d, r in by_distance.items()}
                d_ent_shape_directional_abs = {d: float(r.get("mean_abs_entropy_shape_directional_live_minus_sym", math.nan)) for d, r in by_distance.items()}
                d_ent_symdir = {d: float(r.get("mean_entropy_shape_live_vs_symdir", math.nan)) for d, r in by_distance.items()}

                if 0 in d_normed and math.isfinite(d_normed[0]):
                    front_normed.append(d_normed[0])
                if 0 in d_raw and math.isfinite(d_raw[0]):
                    front_raw.append(d_raw[0])
                if 0 in d_ent_shape and math.isfinite(d_ent_shape[0]):
                    front_entropy_shape.append(d_ent_shape[0])
                if 0 in d_ent_shape_reverse and math.isfinite(d_ent_shape_reverse[0]):
                    front_entropy_shape_reverse.append(d_ent_shape_reverse[0])
                if 0 in d_ent_shape_directional_signed and math.isfinite(d_ent_shape_directional_signed[0]):
                    front_entropy_directional_signed.append(d_ent_shape_directional_signed[0])
                if 0 in d_ent_shape_directional_abs and math.isfinite(d_ent_shape_directional_abs[0]):
                    front_entropy_directional_abs.append(d_ent_shape_directional_abs[0])

                sn = self.log_slope_for_distance_values(d_normed, eps=self.eps)
                sr = self.log_slope_for_distance_values(d_raw, eps=self.eps)
                sl = self.log_slope_for_distance_values(d_lambda, eps=self.eps)
                se = self.log_slope_for_distance_values(d_ent_shape, eps=self.eps)
                ser = self.log_slope_for_distance_values(d_ent_shape_reverse, eps=self.eps)
                seda = self.log_slope_for_distance_values(d_ent_shape_directional_abs, eps=self.eps)
                sedl = self.linear_slope_for_distance_values(d_ent_shape_directional_signed)
                sesd = self.log_slope_for_distance_values(d_ent_symdir, eps=self.eps)
                if math.isfinite(sn):
                    normed_slopes.append(sn)
                if math.isfinite(sr):
                    raw_slopes.append(sr)
                if math.isfinite(sl):
                    lambda_slopes.append(sl)
                if math.isfinite(se):
                    entropy_shape_slopes.append(se)
                if math.isfinite(ser):
                    entropy_shape_reverse_slopes.append(ser)
                if math.isfinite(seda):
                    entropy_shape_directional_abs_slopes.append(seda)
                if math.isfinite(sedl):
                    entropy_shape_directional_signed_linear_slopes.append(sedl)
                if math.isfinite(sesd):
                    entropy_symdir_slopes.append(sesd)
                if math.isfinite(sn) or math.isfinite(sr) or math.isfinite(sl):
                    levels_with_profile += 1
                if math.isfinite(sn) and math.isfinite(sr) and math.isfinite(sl):
                    if sn < 0.0 and sr >= 0.0 and sl > 0.0:
                        artifact_levels += 1

                bulk_normed = [v for d, v in d_normed.items() if d >= 1 and math.isfinite(v) and v > self.eps]
                bulk_raw = [v for d, v in d_raw.items() if d >= 1 and math.isfinite(v) and v > self.eps]
                if 0 in d_normed and bulk_normed and d_normed[0] > self.eps:
                    front_over_bulk_normed.append(float(d_normed[0] / np.mean(bulk_normed)))
                if 0 in d_raw and bulk_raw and d_raw[0] > self.eps:
                    front_over_bulk_raw.append(float(d_raw[0] / np.mean(bulk_raw)))

            front_normed_mean = self.mean(front_normed)
            front_raw_mean = self.mean(front_raw)
            front_entropy_mean = self.mean(front_entropy_shape)
            front_entropy_reverse_mean = self.mean(front_entropy_shape_reverse)
            front_entropy_directional_signed_mean = self.mean(front_entropy_directional_signed)
            front_entropy_directional_abs_mean = self.mean(front_entropy_directional_abs)
            raw_mean_slope = self.mean(raw_slopes)
            normed_mean_slope = self.mean(normed_slopes)
            lambda_mean_slope = self.mean(lambda_slopes)
            entropy_mean_slope = self.mean(entropy_shape_slopes)
            entropy_reverse_mean_slope = self.mean(entropy_shape_reverse_slopes)
            entropy_directional_abs_mean_slope = self.mean(entropy_shape_directional_abs_slopes)
            entropy_directional_signed_linear_mean_slope = self.mean(entropy_shape_directional_signed_linear_slopes)
            entropy_symdir_mean_slope = self.mean(entropy_symdir_slopes)

            def neg_frac(vals: Sequence[float]) -> float:
                return sum(1 for v in vals if v < 0.0) / len(vals) if vals else 0.0

            verdicts.append(
                {
                    "mode": self.mode,
                    "region_type": region_type,
                    "levels_with_front": len(front_normed),
                    "levels_with_depth_profile": levels_with_profile,
                    "front_mean_normed_orientation_over_lambda": front_normed_mean,
                    "front_min_normed_orientation_over_lambda": min(front_normed) if front_normed else 0.0,
                    "front_max_normed_orientation_over_lambda": max(front_normed) if front_normed else 0.0,
                    "front_cv_normed_orientation_over_lambda": (float(np.std(front_normed)) / max(front_normed_mean, self.eps)) if front_normed else math.nan,
                    "front_mean_raw_abs_omega": front_raw_mean,
                    "front_min_raw_abs_omega": min(front_raw) if front_raw else 0.0,
                    "front_max_raw_abs_omega": max(front_raw) if front_raw else 0.0,
                    "front_cv_raw_abs_omega": (float(np.std(front_raw)) / max(front_raw_mean, self.eps)) if front_raw else math.nan,
                    "front_mean_entropy_shape_live_vs_sym": front_entropy_mean,
                    "front_mean_entropy_shape_sym_vs_live": front_entropy_reverse_mean,
                    "front_mean_entropy_shape_directional_live_minus_sym": front_entropy_directional_signed_mean,
                    "front_mean_abs_entropy_shape_directional_live_minus_sym": front_entropy_directional_abs_mean,
                    "mean_log_slope_normed_orientation_vs_distance": normed_mean_slope,
                    "mean_log_slope_raw_omega_vs_distance": raw_mean_slope,
                    "mean_log_slope_lambda_norm_vs_distance": lambda_mean_slope,
                    "mean_log_slope_entropy_shape_live_vs_sym_vs_distance": entropy_mean_slope,
                    "mean_log_slope_entropy_shape_sym_vs_live_vs_distance": entropy_reverse_mean_slope,
                    "mean_log_slope_abs_entropy_shape_directional_live_minus_sym_vs_distance": entropy_directional_abs_mean_slope,
                    "mean_linear_slope_entropy_shape_directional_live_minus_sym_vs_distance": entropy_directional_signed_linear_mean_slope,
                    "mean_log_slope_entropy_shape_live_vs_symdir_vs_distance": entropy_symdir_mean_slope,
                    "frac_levels_normed_negative_depth_slope": neg_frac(normed_slopes),
                    "frac_levels_raw_omega_negative_depth_slope": neg_frac(raw_slopes),
                    "frac_levels_lambda_norm_positive_depth_slope": (sum(1 for v in lambda_slopes if v > 0.0) / len(lambda_slopes)) if lambda_slopes else 0.0,
                    "frac_levels_entropy_shape_negative_depth_slope": neg_frac(entropy_shape_slopes),
                    "frac_levels_entropy_shape_reverse_negative_depth_slope": neg_frac(entropy_shape_reverse_slopes),
                    "frac_levels_abs_entropy_shape_directional_negative_depth_slope": neg_frac(entropy_shape_directional_abs_slopes),
                    "frac_levels_entropy_shape_directional_signed_linear_negative_depth_slope": neg_frac(entropy_shape_directional_signed_linear_slopes),
                    "mean_front_over_bulk_ratio_normed": self.mean(front_over_bulk_normed),
                    "mean_front_over_bulk_ratio_raw": self.mean(front_over_bulk_raw),
                    "normalization_artifact_level_fraction": (artifact_levels / levels_with_profile) if levels_with_profile else 0.0,
                    "normalization_artifact_suspected": int(levels_with_profile > 0 and artifact_levels / levels_with_profile >= 0.5),
                    # New conservative gates.  The normalized legacy metric alone is not sufficient.
                    "profile_gate_front_raw_nonzero": int(front_raw_mean > self.eps),
                    "profile_gate_raw_bulk_decay_majority": int(raw_slopes and neg_frac(raw_slopes) >= 0.5),
                    "profile_gate_entropy_bulk_decay_majority": int(entropy_shape_slopes and neg_frac(entropy_shape_slopes) >= 0.5),
                    "profile_gate_reverse_entropy_bulk_decay_majority": int(entropy_shape_reverse_slopes and neg_frac(entropy_shape_reverse_slopes) >= 0.5),
                    "profile_gate_directed_abs_entropy_bulk_decay_majority": int(entropy_shape_directional_abs_slopes and neg_frac(entropy_shape_directional_abs_slopes) >= 0.5),
                    "profile_gate_directed_signed_entropy_bulk_decay_majority": int(entropy_shape_directional_signed_linear_slopes and neg_frac(entropy_shape_directional_signed_linear_slopes) >= 0.5),
                    "profile_gate_normed_decay_without_artifact": int(normed_slopes and neg_frac(normed_slopes) >= 0.5 and not (levels_with_profile > 0 and artifact_levels / levels_with_profile >= 0.5)),
                    # Legacy aliases retained so downstream diffing remains possible, but no longer used as a pass claim.
                    "front_mean_primary_orientation_metric": front_normed_mean,
                    "front_cv_primary_orientation_metric": (float(np.std(front_normed)) / max(front_normed_mean, self.eps)) if front_normed else math.nan,
                    "mean_log_slope_vs_distance": normed_mean_slope,
                    "frac_levels_with_negative_depth_slope": neg_frac(normed_slopes),
                    "mean_front_over_bulk_ratio": self.mean(front_over_bulk_normed),
                    "profile_gate_front_nonzero": int(front_normed_mean > self.eps),
                    "profile_gate_bulk_decay_majority": int(normed_slopes and neg_frac(normed_slopes) >= 0.5),
                    "profile_gate_not_everywhere_constant": int(abs(normed_mean_slope) > 1e-6) if normed_slopes else 0,
                }
            )
        return verdicts

    # ------------------------------------------------------------------
    # Cohort/aging and birth-rank spiral diagnostics.
    # ------------------------------------------------------------------

    @staticmethod
    def _stable_seed(level: int, distance: int, region_type: str, salt: int = 0) -> int:
        code = 2166136261 + 16777619 * (level + 31 * distance + 9973 * salt)
        for ch in region_type:
            code = (code ^ ord(ch)) * 16777619
        return int(code % (2**32 - 1))

    @staticmethod
    def _safe_float(row: dict, key: str) -> float:
        try:
            v = float(row.get(key, math.nan))
        except (TypeError, ValueError):
            return math.nan
        return v if math.isfinite(v) else math.nan

    def cohort_trajectory_rows(self) -> List[dict]:
        """Return one row per valid observation of the same regional cut.

        A cohort is a fixed `(region_type, parent)` cut observed at successive
        current growth levels.  This is the v8 correction to purely radial
        front/bulk binning: the same region is followed as it ages and moves
        away from the current frontier.
        """
        keys = [
            "mode", "level", "time", "cohort_id", "region_type", "parent", "parent_level",
            "parent_address", "parent_address_depth", "parent_birth_order",
            "parent_birth_rank_signed", "parent_birth_rank_sector", "theta_rank",
            "theta_rank_abs", "theta_rank_sibling_shuffle", "theta_rank_reversed",
            "rank_phase_cos", "rank_phase_sin", "rank_phase_radius", "distance_to_front",
            "touches_front", "primary_orientation_axis", "primary_omega_signed",
            "primary_orientation_raw_abs_omega", "primary_orientation_norm_over_lambda",
            "norm_lambda_live", "rel_skew_live", "omega_sibling", "omega_f1f2", "kappa_omega",
            "omega_sym_control", "omega_symdir_control",
            "entropy_live_vs_sym_rel_entropy_shape",
            "entropy_live_vs_sym_rel_entropy_reverse_shape",
            "entropy_live_vs_sym_rel_entropy_directional_shape",
            "entropy_live_vs_sym_rel_entropy_directional_abs_shape",
        ]
        rows: List[dict] = []
        for r in self.region_rows:
            if int(r.get("valid_live", 0)) != 1:
                continue
            out = {k: r.get(k, "") for k in keys}
            out["cohort_age"] = int(r.get("distance_to_front", 0))
            out["signed_helicity"] = self._safe_float(r, "primary_omega_signed") * self._safe_float(r, "theta_rank")
            out["signed_helicity_sibling_rank_shuffle"] = self._safe_float(r, "primary_omega_signed") * self._safe_float(r, "theta_rank_sibling_shuffle")
            out["signed_helicity_first_last_kappa"] = self._safe_float(r, "kappa_omega") * self._safe_float(r, "theta_rank")
            out["signed_helicity_symdir"] = self._safe_float(r, "omega_symdir_control") * self._safe_float(r, "theta_rank")
            rows.append(out)
        rows.sort(key=lambda x: (str(x.get("region_type", "")), int(x.get("parent", -1)), int(x.get("level", -1))))
        return rows

    def cohort_verdict_rows(self) -> List[dict]:
        """Summarize aging slopes for fixed regional cuts."""
        groups: Dict[Tuple[str, int], List[dict]] = defaultdict(list)
        for r in self.region_rows:
            if int(r.get("valid_live", 0)) != 1:
                continue
            groups[(str(r.get("region_type", "")), int(r.get("parent", -1)))].append(r)

        verdicts: List[dict] = []
        for (region_type, parent), rows in sorted(groups.items()):
            rows = sorted(rows, key=lambda r: int(r.get("level", -1)))
            if len(rows) < 2:
                continue
            age_to_raw = {int(r.get("distance_to_front", 0)): self._safe_float(r, "primary_orientation_raw_abs_omega") for r in rows}
            age_to_entropy = {int(r.get("distance_to_front", 0)): self._safe_float(r, "entropy_live_vs_sym_rel_entropy_shape") for r in rows}
            age_to_entropy_rev = {int(r.get("distance_to_front", 0)): self._safe_float(r, "entropy_live_vs_sym_rel_entropy_reverse_shape") for r in rows}
            age_to_abs_dir = {int(r.get("distance_to_front", 0)): self._safe_float(r, "entropy_live_vs_sym_rel_entropy_directional_abs_shape") for r in rows}
            age_to_helicity_abs = {int(r.get("distance_to_front", 0)): abs(self._safe_float(r, "primary_omega_signed") * self._safe_float(r, "theta_rank")) for r in rows}
            raw_slope = self.log_slope_for_distance_values(age_to_raw, eps=self.eps)
            ent_slope = self.log_slope_for_distance_values(age_to_entropy, eps=self.eps)
            ent_rev_slope = self.log_slope_for_distance_values(age_to_entropy_rev, eps=self.eps)
            abs_dir_slope = self.log_slope_for_distance_values(age_to_abs_dir, eps=self.eps)
            hel_abs_slope = self.log_slope_for_distance_values(age_to_helicity_abs, eps=self.eps)
            signs = [int(r.get("primary_orientation_sign", 0)) for r in rows if int(r.get("primary_orientation_sign", 0)) != 0]
            sign_stability = (max(signs.count(1), signs.count(-1)) / len(signs)) if signs else 0.0
            first = rows[0]
            last = rows[-1]
            verdicts.append(
                {
                    "mode": self.mode,
                    "region_type": region_type,
                    "parent": parent,
                    "cohort_id": f"{region_type}:parent={parent}",
                    "observations": len(rows),
                    "start_level": int(first.get("level", -1)),
                    "end_level": int(last.get("level", -1)),
                    "start_age": int(first.get("distance_to_front", 0)),
                    "end_age": int(last.get("distance_to_front", 0)),
                    "parent_address": first.get("parent_address", ""),
                    "theta_rank": self._safe_float(first, "theta_rank"),
                    "parent_birth_rank_sector": first.get("parent_birth_rank_sector", ""),
                    "raw_omega_log_slope_vs_age": raw_slope,
                    "entropy_live_vs_sym_log_slope_vs_age": ent_slope,
                    "entropy_sym_vs_live_log_slope_vs_age": ent_rev_slope,
                    "abs_directed_entropy_log_slope_vs_age": abs_dir_slope,
                    "abs_signed_helicity_log_slope_vs_age": hel_abs_slope,
                    "orientation_sign_stability": sign_stability,
                    "scenario_A_front_relaxation_raw": int(math.isfinite(raw_slope) and raw_slope < 0.0),
                    "scenario_B_accumulated_spiral_memory": int(
                        (math.isfinite(raw_slope) and raw_slope > 0.0 or math.isfinite(ent_slope) and ent_slope > 0.0 or math.isfinite(hel_abs_slope) and hel_abs_slope > 0.0)
                        and sign_stability >= 0.8
                    ),
                }
            )
        return verdicts

    def spiral_order_rows(self) -> List[dict]:
        """Birth-rank-resolved helical order by level, region type, and front distance."""
        groups: Dict[Tuple[int, str, int], List[dict]] = defaultdict(list)
        for r in self.region_rows:
            if int(r.get("valid_live", 0)) != 1:
                continue
            key = (int(r.get("level", -1)), str(r.get("region_type", "")), int(r.get("distance_to_front", -1)))
            groups[key].append(r)

        out: List[dict] = []
        for (level, region_type, distance), rows in sorted(groups.items()):
            omega = np.array([self._safe_float(r, "primary_omega_signed") for r in rows], dtype=float)
            theta = np.array([self._safe_float(r, "theta_rank") for r in rows], dtype=float)
            theta_shuf_local = np.array([self._safe_float(r, "theta_rank_sibling_shuffle") for r in rows], dtype=float)
            kappa_omega = np.array([self._safe_float(r, "kappa_omega") for r in rows], dtype=float)
            symdir_omega = np.array([self._safe_float(r, "omega_symdir_control") for r in rows], dtype=float)
            mask = np.isfinite(omega) & np.isfinite(theta)
            if np.sum(mask) == 0:
                continue
            omega = omega[mask]
            theta = theta[mask]
            theta_shuf_local = theta_shuf_local[mask]
            kappa_omega = kappa_omega[mask]
            symdir_omega = symdir_omega[mask]
            n = int(len(omega))
            # Deterministic address-phase shuffle across rows in the same radial bin.
            rng = np.random.default_rng(self._stable_seed(level, distance, region_type, salt=17))
            theta_addr_shuffle = np.array(theta, copy=True)
            if n > 1:
                theta_addr_shuffle = theta_addr_shuffle[rng.permutation(n)]
            h_live_vals = omega * theta
            h_sibling_shuffle_vals = omega * theta_shuf_local
            h_address_shuffle_vals = omega * theta_addr_shuffle
            h_kappa_vals = kappa_omega * theta
            h_symdir_vals = symdir_omega * theta
            cov = float(np.mean((omega - np.mean(omega)) * (theta - np.mean(theta)))) if n >= 2 else 0.0
            corr = float(np.corrcoef(omega, theta)[0, 1]) if n >= 2 and np.std(omega) > self.eps and np.std(theta) > self.eps else math.nan
            h_live = float(np.mean(h_live_vals))
            h_sibling_shuffle = float(np.mean(h_sibling_shuffle_vals))
            h_address_shuffle = float(np.mean(h_address_shuffle_vals))
            h_kappa = float(np.mean(h_kappa_vals)) if np.all(np.isfinite(h_kappa_vals)) else math.nan
            h_symdir = float(np.mean(h_symdir_vals)) if np.all(np.isfinite(h_symdir_vals)) else math.nan

            sector_means = {}
            for sector in ["firstborn", "middleborn", "lastborn", "root"]:
                vals = [self._safe_float(r, "primary_omega_signed") for r in rows if r.get("parent_birth_rank_sector") == sector]
                vals = [v for v in vals if math.isfinite(v)]
                sector_means[f"mean_omega_sector_{sector}"] = float(np.mean(vals)) if vals else math.nan
                sector_means[f"count_sector_{sector}"] = len(vals)
            first = sector_means.get("mean_omega_sector_firstborn", math.nan)
            last = sector_means.get("mean_omega_sector_lastborn", math.nan)
            first_last_antisym = float(last - first) if math.isfinite(first) and math.isfinite(last) else math.nan

            out_row = {
                "mode": self.mode,
                "level": level,
                "region_type": region_type,
                "distance_to_front": distance,
                "touches_front": int(distance == 0),
                "count": n,
                "mean_signed_omega": float(np.mean(omega)),
                "mean_abs_omega": float(np.mean(np.abs(omega))),
                "mean_theta_rank": float(np.mean(theta)),
                "mean_abs_theta_rank": float(np.mean(np.abs(theta))),
                "cov_omega_theta_rank": cov,
                "corr_omega_theta_rank": corr,
                "signed_helicity_H": h_live,
                "abs_mean_signed_helicity": float(np.mean(np.abs(h_live_vals))),
                "signed_helicity_sibling_rank_shuffle_H": h_sibling_shuffle,
                "signed_helicity_address_phase_shuffle_H": h_address_shuffle,
                "signed_helicity_first_last_kappa_H": h_kappa,
                "signed_helicity_symdir_H": h_symdir,
                "reversal_error_abs_H_plus_Hkappa_over_abs_H": abs(h_live + h_kappa) / max(abs(h_live), self.eps) if math.isfinite(h_kappa) else math.nan,
                "sibling_rank_shuffle_abs_ratio": abs(h_sibling_shuffle) / max(abs(h_live), self.eps),
                "address_phase_shuffle_abs_ratio": abs(h_address_shuffle) / max(abs(h_live), self.eps),
                "symdir_abs_ratio": abs(h_symdir) / max(abs(h_live), self.eps) if math.isfinite(h_symdir) else math.nan,
                "first_last_sector_antisymmetry": first_last_antisym,
            }
            out_row.update(sector_means)
            out.append(out_row)
        return out

    def spiral_verdict_rows(self, spiral_rows: Sequence[dict]) -> List[dict]:
        by_type: Dict[str, List[dict]] = defaultdict(list)
        for r in spiral_rows:
            by_type[str(r.get("region_type", ""))].append(r)
        verdicts: List[dict] = []
        for region_type, rows in sorted(by_type.items()):
            H = [abs(self._safe_float(r, "signed_helicity_H")) for r in rows]
            H = [v for v in H if math.isfinite(v)]
            sibling_ratio = [self._safe_float(r, "sibling_rank_shuffle_abs_ratio") for r in rows]
            sibling_ratio = [v for v in sibling_ratio if math.isfinite(v)]
            addr_ratio = [self._safe_float(r, "address_phase_shuffle_abs_ratio") for r in rows]
            addr_ratio = [v for v in addr_ratio if math.isfinite(v)]
            sym_ratio = [self._safe_float(r, "symdir_abs_ratio") for r in rows]
            sym_ratio = [v for v in sym_ratio if math.isfinite(v)]
            rev_err = [self._safe_float(r, "reversal_error_abs_H_plus_Hkappa_over_abs_H") for r in rows]
            rev_err = [v for v in rev_err if math.isfinite(v)]
            def frac(vals: Sequence[float], pred) -> float:
                return sum(1 for v in vals if pred(v)) / len(vals) if vals else 0.0
            verdicts.append(
                {
                    "mode": self.mode,
                    "region_type": region_type,
                    "bins": len(rows),
                    "mean_abs_signed_helicity_H": self.mean(H),
                    "median_abs_signed_helicity_H": self.median(H),
                    "mean_sibling_rank_shuffle_abs_ratio": self.mean(sibling_ratio),
                    "mean_address_phase_shuffle_abs_ratio": self.mean(addr_ratio),
                    "mean_symdir_abs_ratio": self.mean(sym_ratio),
                    "mean_first_last_reversal_error": self.mean(rev_err),
                    "frac_bins_first_last_reversal_flips_H": frac(rev_err, lambda v: v < 0.25),
                    "frac_bins_sibling_rank_shuffle_suppressed": frac(sibling_ratio, lambda v: v < 0.5),
                    "frac_bins_address_phase_shuffle_suppressed": frac(addr_ratio, lambda v: v < 0.5),
                    "frac_bins_symdir_near_zero": frac(sym_ratio, lambda v: v < 1e-6),
                    "spiral_gate_controls_pass_majority": int(
                        frac(rev_err, lambda v: v < 0.25) >= 0.5
                        and frac(sibling_ratio, lambda v: v < 0.5) >= 0.5
                        and frac(addr_ratio, lambda v: v < 0.5) >= 0.5
                        and frac(sym_ratio, lambda v: v < 1e-6) >= 0.5
                    ),
                }
            )
        return verdicts


    # ------------------------------------------------------------------
    # v8 two-ended bulk quotient diagnostic.
    # ------------------------------------------------------------------

    def two_ended_bulk_specs(self) -> List[TwoEndedBulkSpec]:
        """Return bulk windows with rootward and frontward caps.

        Minimal h=2 window around a completed parent p:

            root_cap  = [parent(p)]
            measure   = children(p) = [c1,c2,c3]
            front_cap = grandchildren(p) = children(c1)+children(c2)+children(c3)
            interior  = [p]

        The first Schur response is formed on root_cap + measure + front_cap.
        The caps are then eliminated from that boundary response.  This keeps a
        nontrivial local sibling/F2 measurement sector while denying the
        resulting bulk subsystem explicit access to the rootward or frontward
        end as an orientation anchor.
        """
        specs: List[TwoEndedBulkSpec] = []
        for p in self.completed_parents():
            node = self.nodes[p]
            if node.parent is None or len(node.children) != 3:
                continue
            front_cap: List[int] = []
            complete_h2 = True
            for c in node.children:
                gc = self.nodes[c].children
                if len(gc) != 3:
                    complete_h2 = False
                    break
                front_cap.extend(gc)
            if not complete_h2:
                continue
            root_cap = [node.parent]
            measure = list(node.children)
            boundary = root_cap + measure + front_cap
            specs.append(
                TwoEndedBulkSpec(
                    parent=p,
                    measure=measure,
                    root_cap=root_cap,
                    front_cap=front_cap,
                    boundary=boundary,
                    interior=[p],
                    children=measure,
                )
            )
        return specs

    def _solve_for_quotient(self, A: np.ndarray, B: np.ndarray, label: str) -> Tuple[bool, Optional[np.ndarray], dict]:
        """Solve A X = B for quotient Schur elimination.

        Primary path: direct np.linalg.solve when A is well-conditioned.
        Fallback: mean-zero gauge-fixed augmented solve

            [ A  1 ] [X] = [B]
            [1^T 0 ] [λ]   [0]

        This is intentionally not an inverse.  If both paths fail, the quotient
        row is marked invalid rather than silently using an unconstrained
        pseudo-inverse.
        """
        info = {
            f"{label}_solve_ok": 0,
            f"{label}_solve_method": "",
            f"{label}_cond": math.nan,
            f"{label}_solve_residual": math.nan,
            f"{label}_error": "",
        }
        if A.size == 0:
            info[f"{label}_error"] = "empty_elimination_block"
            return False, None, info
        try:
            cond = float(np.linalg.cond(A))
            info[f"{label}_cond"] = cond
            if math.isfinite(cond) and cond <= self.cond_max:
                X = np.linalg.solve(A, B)
                info[f"{label}_solve_ok"] = 1
                info[f"{label}_solve_method"] = "direct_solve"
                info[f"{label}_solve_residual"] = float(np.linalg.norm(A @ X - B, ord="fro"))
                return True, X, info
        except np.linalg.LinAlgError as exc:
            info[f"{label}_error"] = f"direct_solve_error:{exc}"

        # Gauge-fixed fallback for DtN-like blocks with a constant-mode defect.
        try:
            n = A.shape[0]
            ones = np.ones((n, 1), dtype=float)
            aug = np.block([[A, ones], [ones.T, np.zeros((1, 1), dtype=float)]])
            rhs = np.vstack([B, np.zeros((1, B.shape[1]), dtype=float)])
            sol = np.linalg.solve(aug, rhs)
            X = sol[:n, :]
            info[f"{label}_solve_ok"] = 1
            info[f"{label}_solve_method"] = "mean_zero_gauge_solve"
            info[f"{label}_solve_residual"] = float(np.linalg.norm(A @ X - B, ord="fro"))
            return True, X, info
        except np.linalg.LinAlgError as exc:
            existing = info.get(f"{label}_error", "")
            info[f"{label}_error"] = (existing + ";" if existing else "") + f"gauge_solve_error:{exc}"
            return False, None, info

    def quotient_keep_response(
        self,
        Lambda: np.ndarray,
        keep_idx: Sequence[int],
        elim_idx: Sequence[int],
        label: str,
    ) -> Tuple[bool, Optional[np.ndarray], dict]:
        """Schur-eliminate a subset of boundary variables from Lambda."""
        K = np.array(list(keep_idx), dtype=int)
        E = np.array(list(elim_idx), dtype=int)
        out = {
            f"{label}_keep_dim": int(len(K)),
            f"{label}_elim_dim": int(len(E)),
            f"{label}_valid": 0,
        }
        if len(K) == 0 or len(E) == 0:
            out[f"{label}_error"] = "empty_keep_or_elim"
            return False, None, out
        L_KK = Lambda[np.ix_(K, K)]
        L_KE = Lambda[np.ix_(K, E)]
        L_EK = Lambda[np.ix_(E, K)]
        L_EE = Lambda[np.ix_(E, E)]
        ok, X, solve_info = self._solve_for_quotient(L_EE, L_EK, label=f"{label}_EE")
        out.update(solve_info)
        if not ok or X is None:
            out[f"{label}_error"] = out.get(f"{label}_EE_error", "quotient_solve_failed")
            return False, None, out
        Q = L_KK - L_KE @ X
        out[f"{label}_valid"] = 1
        out[f"{label}_row_sum_residual"] = float(np.linalg.norm(Q @ np.ones(len(K))))
        return True, Q, out

    def m_block_after_eliminating_cap(
        self,
        Lambda: np.ndarray,
        measure_idx: Sequence[int],
        kept_cap_idx: Sequence[int],
        eliminated_cap_idx: Sequence[int],
        cap_side: str,
    ) -> Tuple[bool, Optional[np.ndarray], dict]:
        """Return M-M block with one end cap retained as a Dirichlet anchor.

        root-anchor view: eliminate the front cap, keep root cap + M, then read
        the M-M block while the root cap remains as an external anchor.

        front-anchor view: eliminate the root cap, keep M + front cap, then read
        the M-M block while the front cap remains as an external anchor.
        """
        if cap_side == "root_anchor":
            keep = list(kept_cap_idx) + list(measure_idx)
            m_positions = list(range(len(kept_cap_idx), len(kept_cap_idx) + len(measure_idx)))
        elif cap_side == "front_anchor":
            keep = list(measure_idx) + list(kept_cap_idx)
            m_positions = list(range(0, len(measure_idx)))
        else:
            raise ValueError(f"unknown cap_side: {cap_side}")
        ok, Q, info = self.quotient_keep_response(Lambda, keep, eliminated_cap_idx, label=cap_side)
        if not ok or Q is None:
            return False, None, info
        M = Q[np.ix_(m_positions, m_positions)]
        info[f"{cap_side}_m_block_valid"] = 1
        return True, M, info

    def _sibling_omega_from_lambda(self, measure_nodes: Sequence[int], Lambda_M: np.ndarray) -> dict:
        """Sibling-sector orientation diagnostics for a 3-port measurement block."""
        _, A, metrics = self.skew_metrics_from_lambda(Lambda_M, eps=self.eps)
        fake_spec = RegionSpec(
            region_type="sibling_star",
            parent=-1,
            boundary=list(measure_nodes),
            interior=[],
            children=list(measure_nodes),
            rootward=None,
        )
        proj = self.projection_metrics(fake_spec, A)
        out = {
            "norm_lambda": metrics["norm_lambda_live"],
            "skew_norm": metrics["skew_norm_live"],
            "sym_norm": metrics["sym_norm_live"],
            "rel_skew": metrics["rel_skew_live"],
            "omega": proj["omega_sibling"],
            "abs_omega": abs(float(proj["omega_sibling"])) if math.isfinite(float(proj["omega_sibling"])) else math.nan,
            "j_residual": proj["j_residual_sibling"],
            "j2_residual": proj["j2_residual_sibling"],
            "omega_nonzero": proj["omega_sibling_nonzero"],
            "kappa_omega": proj["kappa_omega"],
            "kappa_flips_sign": proj["kappa_flips_sign"],
        }
        return out

    def analyze_two_ended_bulk_spec(self, spec: TwoEndedBulkSpec, Ks: Dict[str, np.ndarray], level: int) -> dict:
        """Analyze one two-ended bulk quotient window."""
        # Boundary ordering: root_cap + measure + front_cap.
        rdim = len(spec.root_cap)
        mdim = len(spec.measure)
        fdim = len(spec.front_cap)
        root_idx = list(range(0, rdim))
        measure_idx = list(range(rdim, rdim + mdim))
        front_idx = list(range(rdim + mdim, rdim + mdim + fdim))
        end_idx = root_idx + front_idx

        base_row = {
            "mode": self.mode,
            "level": level,
            "time": self.t,
            "window_type": spec.window_type,
            "parent": spec.parent,
            "parent_level": self.nodes[spec.parent].level,
            "measure_nodes": " ".join(map(str, spec.measure)),
            "root_cap_nodes": " ".join(map(str, spec.root_cap)),
            "front_cap_nodes": " ".join(map(str, spec.front_cap)),
            "boundary_nodes": " ".join(map(str, spec.boundary)),
            "interior_nodes": " ".join(map(str, spec.interior)),
            "n_measure": len(spec.measure),
            "n_root_cap": len(spec.root_cap),
            "n_front_cap": len(spec.front_cap),
            "n_end_cap": len(end_idx),
            "n_boundary_extended": len(spec.boundary),
            "n_interior": len(spec.interior),
            "valid_extended_live": 0,
            "valid_two_end_bulk": 0,
            "relational_live_update": int(self.relational_live_update),
            "live_relation_target_scale": self.live_relation_target_scale,
        }
        geom_spec = RegionSpec(
            region_type=spec.window_type,
            parent=spec.parent,
            boundary=list(spec.measure),
            interior=list(spec.interior),
            children=list(spec.measure),
            rootward=spec.root_cap[0] if spec.root_cap else None,
        )
        base_row.update(self.front_bulk_geometry(geom_spec, current_growth_level=level))
        base_row.update(self.provenance_rank_metadata(geom_spec))

        live = self.schur_response(Ks["live"], spec.boundary, spec.interior)
        if not live.ok or live.Lambda is None:
            base_row["extended_schur_error_live"] = live.error
            base_row["cond_KII_extended_live"] = live.cond_KII
            return base_row
        base_row["valid_extended_live"] = 1
        base_row["cond_KII_extended_live"] = live.cond_KII
        base_row["row_sum_residual_extended_live"] = live.row_sum_residual

        # Two-ended quotient: eliminate both end caps and observe M only.
        ok_bulk, Lambda_bulk, qinfo = self.quotient_keep_response(live.Lambda, measure_idx, end_idx, label="two_end_bulk")
        base_row.update(qinfo)
        if ok_bulk and Lambda_bulk is not None:
            base_row["valid_two_end_bulk"] = 1
            m = self._sibling_omega_from_lambda(spec.measure, Lambda_bulk)
            for k, v in m.items():
                base_row[f"two_end_bulk_{k}"] = v
            theta = self._safe_float(base_row, "theta_rank")
            omega = float(m["omega"])
            komega = float(m["kappa_omega"])
            base_row["two_end_bulk_signed_helicity"] = omega * theta
            base_row["two_end_bulk_abs_signed_helicity"] = abs(omega * theta)
            base_row["two_end_bulk_kappa_signed_helicity"] = komega * theta
            base_row["two_end_bulk_reversal_error_abs_H_plus_Hkappa_over_abs_H"] = abs((omega + komega) * theta) / max(abs(omega * theta), self.eps)

        # Root-anchored view: eliminate front cap, then M-block with root cap retained.
        ok_root, Lambda_root_anchor, root_info = self.m_block_after_eliminating_cap(
            live.Lambda, measure_idx, root_idx, front_idx, cap_side="root_anchor"
        )
        base_row.update(root_info)
        if ok_root and Lambda_root_anchor is not None:
            m = self._sibling_omega_from_lambda(spec.measure, Lambda_root_anchor)
            for k, v in m.items():
                base_row[f"root_anchor_{k}"] = v
            theta = self._safe_float(base_row, "theta_rank")
            base_row["root_anchor_signed_helicity"] = float(m["omega"]) * theta

        # Front-anchored view: eliminate root cap, then M-block with front cap retained.
        ok_front, Lambda_front_anchor, front_info = self.m_block_after_eliminating_cap(
            live.Lambda, measure_idx, front_idx, root_idx, cap_side="front_anchor"
        )
        base_row.update(front_info)
        if ok_front and Lambda_front_anchor is not None:
            m = self._sibling_omega_from_lambda(spec.measure, Lambda_front_anchor)
            for k, v in m.items():
                base_row[f"front_anchor_{k}"] = v
            theta = self._safe_float(base_row, "theta_rank")
            base_row["front_anchor_signed_helicity"] = float(m["omega"]) * theta

        # Entropy symmetry of root/front references on the same M dimension.
        if Lambda_bulk is not None and Lambda_root_anchor is not None:
            base_row.update(self.entropy_proxy_metrics(Lambda_bulk, Lambda_root_anchor, prefix="entropy_two_end_vs_root_anchor"))
        if Lambda_bulk is not None and Lambda_front_anchor is not None:
            base_row.update(self.entropy_proxy_metrics(Lambda_bulk, Lambda_front_anchor, prefix="entropy_two_end_vs_front_anchor"))
        if Lambda_root_anchor is not None and Lambda_front_anchor is not None:
            base_row.update(self.entropy_proxy_metrics(Lambda_root_anchor, Lambda_front_anchor, prefix="entropy_root_anchor_vs_front_anchor"))
            d_root = self._safe_float(base_row, "entropy_two_end_vs_root_anchor_rel_entropy_shape")
            d_front = self._safe_float(base_row, "entropy_two_end_vs_front_anchor_rel_entropy_shape")
            if math.isfinite(d_root) and math.isfinite(d_front):
                base_row["root_front_reference_entropy_gap_abs"] = abs(d_root - d_front)
                base_row["root_front_reference_entropy_gap_rel"] = abs(d_root - d_front) / max(d_root + d_front, self.eps)

        # Symmetrized-live twin under the same two-ended quotient: should kill sign-sensitive skew.
        symdir = self.schur_response(Ks["symdir"], spec.boundary, spec.interior)
        if symdir.ok and symdir.Lambda is not None:
            ok_symdir, Lambda_symdir_bulk, symdir_qinfo = self.quotient_keep_response(symdir.Lambda, measure_idx, end_idx, label="two_end_symdir_bulk")
            # Keep only compact validity/solve diagnostics to avoid key collisions.
            for k, v in symdir_qinfo.items():
                base_row[f"symdir_{k}"] = v
            if ok_symdir and Lambda_symdir_bulk is not None:
                m = self._sibling_omega_from_lambda(spec.measure, Lambda_symdir_bulk)
                for k, v in m.items():
                    base_row[f"two_end_symdir_{k}"] = v
                live_abs = self._safe_float(base_row, "two_end_bulk_abs_omega")
                base_row["two_end_symdir_abs_omega_ratio"] = abs(float(m["omega"])) / max(live_abs, self.eps)
        else:
            base_row["two_end_symdir_error"] = symdir.error

        # Reciprocal symmetric tree-control under the same two-ended quotient.
        sym = self.schur_response(Ks["sym"], spec.boundary, spec.interior)
        if sym.ok and sym.Lambda is not None:
            ok_sym, Lambda_sym_bulk, sym_qinfo = self.quotient_keep_response(sym.Lambda, measure_idx, end_idx, label="two_end_sym_bulk")
            for k, v in sym_qinfo.items():
                base_row[f"sym_{k}"] = v
            if ok_sym and Lambda_sym_bulk is not None:
                m = self._sibling_omega_from_lambda(spec.measure, Lambda_sym_bulk)
                for k, v in m.items():
                    base_row[f"two_end_sym_{k}"] = v
                live_abs = self._safe_float(base_row, "two_end_bulk_abs_omega")
                base_row["two_end_sym_abs_omega_ratio"] = abs(float(m["omega"])) / max(live_abs, self.eps)
        else:
            base_row["two_end_sym_error"] = sym.error

        # Perspective diagnostics.
        root_H = self._safe_float(base_row, "root_anchor_signed_helicity")
        front_H = self._safe_float(base_row, "front_anchor_signed_helicity")
        if math.isfinite(root_H) and math.isfinite(front_H):
            base_row["root_front_anchor_H_sum_abs_over_root_abs"] = abs(root_H + front_H) / max(abs(root_H), self.eps)
            base_row["root_front_anchor_H_diff_abs"] = abs(root_H - front_H)
        return base_row

    def analyze_current_two_ended_bulk(self, level: int) -> List[dict]:
        specs = self.two_ended_bulk_specs()
        if not specs:
            return []
        Ks = self.build_all_Ks()
        rows = [self.analyze_two_ended_bulk_spec(spec, Ks, level=level) for spec in specs]
        self.two_ended_bulk_rows.extend(rows)
        return rows

    def two_ended_bulk_verdict_rows(self, rows: Sequence[dict]) -> List[dict]:
        """Aggregate v8 sign-convention gates for the two-ended quotient."""
        groups: Dict[Tuple[int, str], List[dict]] = defaultdict(list)
        for r in rows:
            if int(r.get("valid_two_end_bulk", 0)) != 1:
                continue
            groups[(int(r.get("level", -1)), str(r.get("window_type", "")))].append(r)

        out: List[dict] = []
        for (level, window_type), rs in sorted(groups.items()):
            abs_omega = [self._safe_float(r, "two_end_bulk_abs_omega") for r in rs]
            abs_omega = [v for v in abs_omega if math.isfinite(v)]
            rel_skew = [self._safe_float(r, "two_end_bulk_rel_skew") for r in rs]
            rel_skew = [v for v in rel_skew if math.isfinite(v)]
            H = [self._safe_float(r, "two_end_bulk_signed_helicity") for r in rs]
            H = [v for v in H if math.isfinite(v)]
            absH = [abs(v) for v in H]
            kerr = [self._safe_float(r, "two_end_bulk_reversal_error_abs_H_plus_Hkappa_over_abs_H") for r in rs]
            kerr = [v for v in kerr if math.isfinite(v)]
            symdir_ratio = [self._safe_float(r, "two_end_symdir_abs_omega_ratio") for r in rs]
            symdir_ratio = [v for v in symdir_ratio if math.isfinite(v)]
            sym_ratio = [self._safe_float(r, "two_end_sym_abs_omega_ratio") for r in rs]
            sym_ratio = [v for v in sym_ratio if math.isfinite(v)]
            dgap_rel = [self._safe_float(r, "root_front_reference_entropy_gap_rel") for r in rs]
            dgap_rel = [v for v in dgap_rel if math.isfinite(v)]
            root_H = [abs(self._safe_float(r, "root_anchor_signed_helicity")) for r in rs]
            root_H = [v for v in root_H if math.isfinite(v)]
            front_H = [abs(self._safe_float(r, "front_anchor_signed_helicity")) for r in rs]
            front_H = [v for v in front_H if math.isfinite(v)]
            root_front_Hsum = [self._safe_float(r, "root_front_anchor_H_sum_abs_over_root_abs") for r in rs]
            root_front_Hsum = [v for v in root_front_Hsum if math.isfinite(v)]

            def frac(vals: Sequence[float], pred) -> float:
                return sum(1 for v in vals if pred(v)) / len(vals) if vals else 0.0

            mean_absH = self.mean(absH)
            signed_ratio = abs(self.mean(H)) / max(mean_absH, self.eps) if H else math.nan
            verdict = {
                "mode": self.mode,
                "level": level,
                "window_type": window_type,
                "windows": len(rs),
                "valid_windows": len(rs),
                "mean_two_end_abs_omega": self.mean(abs_omega),
                "mean_two_end_rel_skew": self.mean(rel_skew),
                "mean_abs_signed_helicity_two_end": mean_absH,
                "mean_signed_helicity_two_end": self.mean(H),
                "signed_helicity_convention_ratio_abs_mean_over_mean_abs": signed_ratio,
                "mean_kappa_reversal_error": self.mean(kerr),
                "frac_kappa_reversal_flips_two_end_H": frac(kerr, lambda v: v < 0.25),
                "mean_symdir_abs_omega_ratio": self.mean(symdir_ratio),
                "mean_sym_abs_omega_ratio": self.mean(sym_ratio),
                "frac_symdir_near_zero": frac(symdir_ratio, lambda v: v < 1e-6),
                "frac_sym_near_zero": frac(sym_ratio, lambda v: v < 1e-6),
                "mean_root_front_reference_entropy_gap_rel": self.mean(dgap_rel),
                "median_root_front_reference_entropy_gap_rel": self.median(dgap_rel),
                "frac_root_front_reference_entropy_gap_small": frac(dgap_rel, lambda v: v < 0.25),
                "mean_abs_root_anchor_H": self.mean(root_H),
                "mean_abs_front_anchor_H": self.mean(front_H),
                "mean_root_front_anchor_H_sum_abs_over_root_abs": self.mean(root_front_Hsum),
                "frac_root_front_anchor_opposite_H": frac(root_front_Hsum, lambda v: v < 0.5),
            }
            # Hard falsifiable gates:
            # A: two-ended quotient did not erase local skew/J magnitude.
            verdict["gate_A_local_J_magnitude_survives"] = int(self.mean(abs_omega) > self.eps and self.mean(rel_skew) > 1e-10)
            # B: signed helicity is conventional: mean signed signal small relative to mean magnitude.
            verdict["gate_B_signed_helicity_conventional"] = int(math.isfinite(signed_ratio) and signed_ratio < 0.25 and mean_absH > self.eps)
            # C: the two-ended bulk sees root/front anchored references approximately symmetrically.
            verdict["gate_C_root_front_reference_symmetry"] = int(self.mean(dgap_rel) < 0.25 if dgap_rel else 0)
            # D: root-anchored signal remains nontrivial, and first-last reversal still flips it.
            verdict["gate_D_root_anchored_signal_nonzero"] = int(self.mean(root_H) > self.eps and frac(kerr, lambda v: v < 0.25) >= 0.5)
            verdict["two_ended_bulk_sign_convention_gate_all"] = int(
                verdict["gate_A_local_J_magnitude_survives"]
                and verdict["gate_B_signed_helicity_conventional"]
                and verdict["gate_C_root_front_reference_symmetry"]
                and verdict["gate_D_root_anchored_signal_nonzero"]
            )
            out.append(verdict)
        return out

    def run(self, max_level: int, analyze_each_level: bool = True) -> None:
        frontier = [self.root]
        if analyze_each_level:
            rows = self.analyze_current_regions(level=0)
            self.analyze_current_two_ended_bulk(level=0)
            self.level_summary(0, rows)
        for level in range(1, max_level + 1):
            frontier = self.grow_level(frontier)
            if analyze_each_level:
                rows = self.analyze_current_regions(level=level)
                self.analyze_current_two_ended_bulk(level=level)
                self.level_summary(level, rows)
        if not analyze_each_level:
            rows = self.analyze_current_regions(level=max_level)
            self.analyze_current_two_ended_bulk(level=max_level)
            self.level_summary(max_level, rows)


# ----------------------------------------------------------------------
# Output helpers.
# ----------------------------------------------------------------------


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = sorted({k for row in rows for k in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def render_results_markdown(outdir: Path, summary: str, max_level: int) -> str:
    return f"""# Dynamic birth two-ended bulk quotient diagnostic v8-b3

## What changed after the audit

The v3 front/bulk verdict used `omega / ||Lambda||` as its primary orientation metric.  The audit found that this can be misleading: raw orientation can rise into the bulk while `||Lambda||` rises even faster, making the normalized ratio fall.  v8 therefore separates the observables:

```text
raw orientation:        |omega|
response scale:         ||Lambda||_F
scale-share diagnostic: |omega| / ||Lambda||_F
finite entropy proxies:  D(rho_live || rho_ref), D(rho_ref || rho_live), and their directed gap
```

A normalization-artifact flag is raised when the normalized profile decays while raw omega does not decay and the total response norm grows with the distance from the front.

## Relative-entropy proxy

This is still not the full AQFT/Araki relative entropy.  It is a finite diagnostic scaffold:

```text
Lambda = S + A,  S^T=S, A^T=-A
H_R = [[S, A], [-A, S]]
rho = exp(-beta * centered/shape-normalized H_R) / Tr(...)
D(rho_live || rho_ref) = Tr rho_live (log rho_live - log rho_ref)
D(rho_ref || rho_live) = Tr rho_ref (log rho_ref - log rho_live)
Delta_D = D(rho_live || rho_ref) - D(rho_ref || rho_live)
```

The reference states currently are the reciprocal symmetric tree control and the symmetrized-live control.  v8 writes both Umegaki directions and the signed/absolute directed gap to CSV.  This implements the missing operator-to-state step as a finite proxy and keeps it explicitly labeled as such.

## What is shown

This package still tests whether deterministic Script-2 sequential birth rules generate a non-symmetric regional Schur/DtN response with antisymmetric local 2D skew-block candidates.  It now also tests whether the front/bulk conclusion survives when raw omega, Lambda scale, normalized ratio, both Umegaki directions, and the directed entropy gap are separated.

## What is not shown

This run does not prove canonical quantization, an AQFT net, Tomita-Takesaki modular dynamics, Type-III behavior, a physical time evolution, or a Schrödinger equation.  The entropy computation is finite-dimensional Umegaki entropy of a constructed proxy state, not Araki relative entropy.

## Generated CSV files

Per mode:

- `events_<mode>.csv`
- `regions_<mode>.csv`
- `levels_<mode>.csv`
- `depth_trajectory_<mode>.csv`
- `front_bulk_verdict_<mode>.csv`
- `cohort_trajectory_<mode>.csv`
- `cohort_verdict_<mode>.csv`
- `spiral_order_<mode>.csv`
- `spiral_verdict_<mode>.csv`
- `two_ended_bulk_<mode>.csv`
- `two_ended_bulk_verdict_<mode>.csv`

Global:

- `all_level_summaries.csv`
- `SUMMARY.txt`
- `RESULTS_dynamic_birth_front_bulk_directed_entropy.md`

## Default run

The included output was generated with `--max-level {max_level} --branching 3`.

```text
{summary}
```

## Conservative interpretation

A favorable result now requires more than a falling `omega/||Lambda||` curve.  At minimum, the raw-orientation slope and/or a directed finite entropy-proxy slope must support the claimed front/bulk relaxation, and `normalization_artifact_suspected` must be false.  If raw omega rises while only `omega/||Lambda||` falls, the script reports that as a normalization artifact rather than a passed front/bulk gate.

## v8 two-ended bulk quotient gate

v8 adds the missing bulk-internal perspective.  For each h=2 window it first builds an extended boundary response on

```text
rootward cap + bulk measurement ports + frontward cap
```

and then Schur-eliminates both caps.  The resulting bulk response should retain sign-blind local J/skew magnitude, while the signed helicity should become conventional if the bulk really cannot use either end as a canonical orientation anchor.

The subsequent measure gate remains weight robustness: vary `alpha_env`, `ancestor_decay`, `br_ancestor`, `br_sibling`, and the conductance law, then test whether the quotient sign-convention profile is invariant or merely borrowed from the selected weights.
"""


def run_suite(
    max_level: int,
    outdir: Path,
    analyze_each_level: bool = True,
    include_shell_h2: bool = True,
    branching: int = 3,
    relational_live_update: bool = True,
    live_relation_target_scale: str = "current_g",
) -> str:
    outdir.mkdir(parents=True, exist_ok=True)
    configs = [
        ("linear", 0.22),
        ("log", 0.22),
        ("saturating", 0.90),
    ]

    all_level_rows: List[dict] = []
    lines: List[str] = []

    for mode, alpha in configs:
        model = DynamicBirthGyroscopicSchurModel(
            mode=mode,
            alpha_env=alpha,
            include_shell_h2=include_shell_h2,
            branching=branching,
            relational_live_update=relational_live_update,
            live_relation_target_scale=live_relation_target_scale,
        )
        model.run(max_level=max_level, analyze_each_level=analyze_each_level)

        trajectory_rows = model.depth_trajectory_rows()
        verdict_rows = model.front_bulk_verdict_rows(trajectory_rows)
        cohort_trajectory_rows = model.cohort_trajectory_rows()
        cohort_verdict_rows = model.cohort_verdict_rows()
        spiral_rows = model.spiral_order_rows()
        spiral_verdict_rows = model.spiral_verdict_rows(spiral_rows)
        two_ended_bulk_rows = model.two_ended_bulk_rows
        two_ended_bulk_verdict_rows = model.two_ended_bulk_verdict_rows(two_ended_bulk_rows)

        write_csv(outdir / f"events_{mode}.csv", model.event_rows)
        write_csv(outdir / f"regions_{mode}.csv", model.region_rows)
        write_csv(outdir / f"levels_{mode}.csv", model.level_rows)
        write_csv(outdir / f"depth_trajectory_{mode}.csv", trajectory_rows)
        write_csv(outdir / f"front_bulk_verdict_{mode}.csv", verdict_rows)
        write_csv(outdir / f"cohort_trajectory_{mode}.csv", cohort_trajectory_rows)
        write_csv(outdir / f"cohort_verdict_{mode}.csv", cohort_verdict_rows)
        write_csv(outdir / f"spiral_order_{mode}.csv", spiral_rows)
        write_csv(outdir / f"spiral_verdict_{mode}.csv", spiral_verdict_rows)
        write_csv(outdir / f"two_ended_bulk_{mode}.csv", two_ended_bulk_rows)
        write_csv(outdir / f"two_ended_bulk_verdict_{mode}.csv", two_ended_bulk_verdict_rows)
        all_level_rows.extend(model.level_rows)

        final = model.level_rows[-1] if model.level_rows else {}
        rootward_verdict = next((v for v in verdict_rows if v.get("region_type") == "rootward_sibling_cone"), {})
        sibling_verdict = next((v for v in verdict_rows if v.get("region_type") == "sibling_star"), {})
        lines.append(f"MODE {mode}")
        lines.append(f"  branching={branching}")
        lines.append(f"  relational live update={int(final.get('relational_live_update', int(relational_live_update)))}")
        lines.append(f"  live relation target scale={final.get('live_relation_target_scale', live_relation_target_scale)}")
        lines.append(f"  live env relation groups={final.get('live_env_relation_groups', 0)}, live backreaction relations={final.get('live_backreaction_relations', 0)}")
        lines.append(f"  relational rebuild count={final.get('relational_rebuild_count', 0)}")
        lines.append(f"  final nodes={final.get('nodes', 0)}, completed triples={final.get('completed_triples', 0)}")
        lines.append(f"  regions tested={final.get('regions_tested', 0)}, valid={final.get('regions_valid', 0)}")
        lines.append(f"  mean rel skew live={float(final.get('mean_rel_skew_live', 0.0)):.12g}")
        lines.append(f"  mean |omega sibling|={float(final.get('mean_abs_omega_sibling', 0.0)):.12g}")
        lines.append(f"  mean |omega F1/F2|={float(final.get('mean_abs_omega_f1f2', 0.0)):.12g}")
        lines.append(f"  F1/F2 omega nonzero fraction={float(final.get('frac_f1f2_omega_nonzero', 0.0)):.3f}")
        lines.append(f"  F1/F2 J2-ok fraction={float(final.get('frac_f1f2_J2_ok', 0.0)):.3f}")
        lines.append(f"  F1/F2 orientation positive fraction={float(final.get('frac_f1f2_orientation_positive', 0.0)):.3f}")
        lines.append(f"  mean block dominance={float(final.get('mean_block_dominance_A', 0.0)):.12g}")
        lines.append(f"  one-skew-pair fraction={float(final.get('frac_one_skew_pair', 0.0)):.3f}")
        lines.append(f"  max rel skew symmetric control={float(final.get('max_rel_skew_sym_control', 0.0)):.3e}")
        lines.append(f"  max rel skew symdir control={float(final.get('max_rel_skew_symdir_control', 0.0)):.3e}")
        lines.append(f"  mean |omega F1-only control|={float(final.get('mean_abs_omega_f1_only_control', 0.0)):.12g}")
        lines.append(f"  F1-only control nonzero fraction={float(final.get('frac_f1_only_control_nonzero', 0.0)):.3f}")
        lines.append(f"  mean |omega F2-only control|={float(final.get('mean_abs_omega_f2_only_control', 0.0)):.12g}")
        lines.append(f"  F2-only control nonzero fraction={float(final.get('frac_f2_only_control_nonzero', 0.0)):.3f}")
        lines.append(f"  kappa flips fraction={float(final.get('frac_kappa_flips', 0.0)):.3f}")
        lines.append(f"  kappa preserves birth order fraction={float(final.get('frac_kappa_preserves_birth_order', 0.0)):.3f}")
        lines.append("  FRONT/BULK PROFILE rootward_sibling_cone")
        lines.append(f"    front mean raw |omega|={float(rootward_verdict.get('front_mean_raw_abs_omega', 0.0)):.12g}")
        lines.append(f"    raw |omega| log-slope vs distance={float(rootward_verdict.get('mean_log_slope_raw_omega_vs_distance', 0.0)):.12g}")
        lines.append(f"    Lambda-norm log-slope vs distance={float(rootward_verdict.get('mean_log_slope_lambda_norm_vs_distance', 0.0)):.12g}")
        lines.append(f"    normalized omega/Lambda log-slope={float(rootward_verdict.get('mean_log_slope_normed_orientation_vs_distance', 0.0)):.12g}")
        lines.append(f"    entropy-shape D(live||sym) log-slope={float(rootward_verdict.get('mean_log_slope_entropy_shape_live_vs_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    entropy-shape D(sym||live) log-slope={float(rootward_verdict.get('mean_log_slope_entropy_shape_sym_vs_live_vs_distance', 0.0)):.12g}")
        lines.append(f"    abs directional entropy log-slope={float(rootward_verdict.get('mean_log_slope_abs_entropy_shape_directional_live_minus_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    signed directional entropy linear-slope={float(rootward_verdict.get('mean_linear_slope_entropy_shape_directional_live_minus_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    normalization artifact suspected={int(rootward_verdict.get('normalization_artifact_suspected', 0))}")
        lines.append(f"    artifact level fraction={float(rootward_verdict.get('normalization_artifact_level_fraction', 0.0)):.3f}")
        lines.append(f"    raw front/bulk ratio={float(rootward_verdict.get('mean_front_over_bulk_ratio_raw', 0.0)):.12g}")
        lines.append(f"    normalized front/bulk ratio={float(rootward_verdict.get('mean_front_over_bulk_ratio_normed', 0.0)):.12g}")
        lines.append("  FRONT/BULK PROFILE sibling_star")
        lines.append(f"    front mean raw |omega|={float(sibling_verdict.get('front_mean_raw_abs_omega', 0.0)):.12g}")
        lines.append(f"    raw |omega| log-slope vs distance={float(sibling_verdict.get('mean_log_slope_raw_omega_vs_distance', 0.0)):.12g}")
        lines.append(f"    Lambda-norm log-slope vs distance={float(sibling_verdict.get('mean_log_slope_lambda_norm_vs_distance', 0.0)):.12g}")
        lines.append(f"    normalized omega/Lambda log-slope={float(sibling_verdict.get('mean_log_slope_normed_orientation_vs_distance', 0.0)):.12g}")
        lines.append(f"    entropy-shape D(live||sym) log-slope={float(sibling_verdict.get('mean_log_slope_entropy_shape_live_vs_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    entropy-shape D(sym||live) log-slope={float(sibling_verdict.get('mean_log_slope_entropy_shape_sym_vs_live_vs_distance', 0.0)):.12g}")
        lines.append(f"    abs directional entropy log-slope={float(sibling_verdict.get('mean_log_slope_abs_entropy_shape_directional_live_minus_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    signed directional entropy linear-slope={float(sibling_verdict.get('mean_linear_slope_entropy_shape_directional_live_minus_sym_vs_distance', 0.0)):.12g}")
        lines.append(f"    normalization artifact suspected={int(sibling_verdict.get('normalization_artifact_suspected', 0))}")
        rootward_spiral = next((v for v in spiral_verdict_rows if v.get("region_type") == "rootward_sibling_cone"), {})
        sibling_spiral = next((v for v in spiral_verdict_rows if v.get("region_type") == "sibling_star"), {})
        rootward_cohorts = [v for v in cohort_verdict_rows if v.get("region_type") == "rootward_sibling_cone"]
        sibling_cohorts = [v for v in cohort_verdict_rows if v.get("region_type") == "sibling_star"]
        def _frac_rows(rows_, key):
            return sum(1 for x in rows_ if int(x.get(key, 0)) == 1) / len(rows_) if rows_ else 0.0
        lines.append("  COHORT/AGING rootward_sibling_cone")
        lines.append(f"    cohorts={len(rootward_cohorts)}")
        lines.append(f"    scenario A raw relaxation fraction={_frac_rows(rootward_cohorts, 'scenario_A_front_relaxation_raw'):.3f}")
        lines.append(f"    scenario B accumulated spiral-memory fraction={_frac_rows(rootward_cohorts, 'scenario_B_accumulated_spiral_memory'):.3f}")
        lines.append("  SPIRAL ORDER rootward_sibling_cone")
        lines.append(f"    mean |H|={float(rootward_spiral.get('mean_abs_signed_helicity_H', 0.0)):.12g}")
        lines.append(f"    first-last reversal flip fraction={float(rootward_spiral.get('frac_bins_first_last_reversal_flips_H', 0.0)):.3f}")
        lines.append(f"    sibling-rank shuffle suppressed fraction={float(rootward_spiral.get('frac_bins_sibling_rank_shuffle_suppressed', 0.0)):.3f}")
        lines.append(f"    address-phase shuffle suppressed fraction={float(rootward_spiral.get('frac_bins_address_phase_shuffle_suppressed', 0.0)):.3f}")
        lines.append(f"    symdir near-zero fraction={float(rootward_spiral.get('frac_bins_symdir_near_zero', 0.0)):.3f}")
        lines.append(f"    spiral controls pass majority={int(rootward_spiral.get('spiral_gate_controls_pass_majority', 0))}")
        lines.append("  COHORT/AGING sibling_star")
        lines.append(f"    cohorts={len(sibling_cohorts)}")
        lines.append(f"    scenario A raw relaxation fraction={_frac_rows(sibling_cohorts, 'scenario_A_front_relaxation_raw'):.3f}")
        lines.append(f"    scenario B accumulated spiral-memory fraction={_frac_rows(sibling_cohorts, 'scenario_B_accumulated_spiral_memory'):.3f}")
        lines.append("  SPIRAL ORDER sibling_star")
        lines.append(f"    mean |H|={float(sibling_spiral.get('mean_abs_signed_helicity_H', 0.0)):.12g}")
        lines.append(f"    first-last reversal flip fraction={float(sibling_spiral.get('frac_bins_first_last_reversal_flips_H', 0.0)):.3f}")
        lines.append(f"    sibling-rank shuffle suppressed fraction={float(sibling_spiral.get('frac_bins_sibling_rank_shuffle_suppressed', 0.0)):.3f}")
        lines.append(f"    address-phase shuffle suppressed fraction={float(sibling_spiral.get('frac_bins_address_phase_shuffle_suppressed', 0.0)):.3f}")
        lines.append(f"    symdir near-zero fraction={float(sibling_spiral.get('frac_bins_symdir_near_zero', 0.0)):.3f}")
        lines.append(f"    spiral controls pass majority={int(sibling_spiral.get('spiral_gate_controls_pass_majority', 0))}")
        final_two_end = [v for v in two_ended_bulk_verdict_rows if int(v.get('level', -1)) == max_level]
        two_end = final_two_end[0] if final_two_end else (two_ended_bulk_verdict_rows[-1] if two_ended_bulk_verdict_rows else {})
        lines.append("  TWO-ENDED BULK QUOTIENT")
        lines.append(f"    windows={int(two_end.get('windows', 0))}")
        lines.append(f"    mean two-end |omega|={float(two_end.get('mean_two_end_abs_omega', 0.0)):.12g}")
        lines.append(f"    mean two-end rel skew={float(two_end.get('mean_two_end_rel_skew', 0.0)):.12g}")
        lines.append(f"    signed helicity convention ratio={float(two_end.get('signed_helicity_convention_ratio_abs_mean_over_mean_abs', 0.0)):.12g}")
        lines.append(f"    root/front ref entropy gap rel={float(two_end.get('mean_root_front_reference_entropy_gap_rel', 0.0)):.12g}")
        lines.append(f"    root anchored |H|={float(two_end.get('mean_abs_root_anchor_H', 0.0)):.12g}")
        lines.append(f"    front anchored |H|={float(two_end.get('mean_abs_front_anchor_H', 0.0)):.12g}")
        lines.append(f"    kappa reversal flip fraction={float(two_end.get('frac_kappa_reversal_flips_two_end_H', 0.0)):.3f}")
        lines.append(f"    symdir near-zero fraction={float(two_end.get('frac_symdir_near_zero', 0.0)):.3f}")
        lines.append(f"    gate A local J magnitude survives={int(two_end.get('gate_A_local_J_magnitude_survives', 0))}")
        lines.append(f"    gate B signed helicity conventional={int(two_end.get('gate_B_signed_helicity_conventional', 0))}")
        lines.append(f"    gate C root/front reference symmetry={int(two_end.get('gate_C_root_front_reference_symmetry', 0))}")
        lines.append(f"    gate D root-anchored signal nonzero={int(two_end.get('gate_D_root_anchored_signal_nonzero', 0))}")
        lines.append(f"    two-ended sign-convention gate all={int(two_end.get('two_ended_bulk_sign_convention_gate_all', 0))}")
        lines.append("")

    write_csv(outdir / "all_level_summaries.csv", all_level_rows)
    summary = "\n".join(lines)
    (outdir / "SUMMARY.txt").write_text(summary, encoding="utf-8")
    (outdir / "RESULTS_dynamic_birth_front_bulk_directed_entropy.md").write_text(
        render_results_markdown(outdir, summary, max_level=max_level), encoding="utf-8"
    )
    return summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-level", type=int, default=6, help="Default 6 is safe; try 7 for a larger L7 run.")
    ap.add_argument("--branching", type=int, default=3, help="Explicit branching parameter. This v8 diagnostic supports --branching 3.")
    ap.add_argument("--outdir", type=Path, default=Path("dynamic_birth_front_bulk_directed_entropy_out"))
    ap.add_argument("--final-only", action="store_true", help="Analyze only the final level, not every level.")
    ap.add_argument("--no-shell-h2", action="store_true", help="Disable subtree_shell_h2 regions.")
    ap.add_argument("--legacy-frozen-live", action="store_true", help="Disable relational re-pulling and use event-time live edges, reproducing the v6 frozen-relation behavior.")
    ap.add_argument("--live-relation-target-scale", choices=["current_g", "birth_g"], default="current_g", help="Amplitude used when recomputing environment edges into an already born child.")
    args = ap.parse_args()

    summary = run_suite(
        max_level=args.max_level,
        outdir=args.outdir,
        analyze_each_level=not args.final_only,
        include_shell_h2=not args.no_shell_h2,
        branching=args.branching,
        relational_live_update=not args.legacy_frozen_live,
        live_relation_target_scale=args.live_relation_target_scale,
    )
    print(summary)


if __name__ == "__main__":
    main()
