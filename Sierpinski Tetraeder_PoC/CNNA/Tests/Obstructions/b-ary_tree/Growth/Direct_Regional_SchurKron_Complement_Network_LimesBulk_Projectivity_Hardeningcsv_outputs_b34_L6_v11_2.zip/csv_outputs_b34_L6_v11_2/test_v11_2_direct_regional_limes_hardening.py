#!/usr/bin/env python3
"""
CNNA v11.2 — Direct Regional Schur/Kron Complement Network: Limes/Bulk/Projectivity Hardening.

Purpose
-------
This deterministic diagnostic keeps direct regional Schur/Kron-DtN from the
finite dynamic graph as the v11.2 main path and hardens the limes diagnostics.  The v9/v10.2 local shell-DtN
construction remains the smallest local response observable and diagnostic layer,
but naive composition of already-reduced shell responses is optional only and does
not gate the main verdict.

Ontology used by this script
----------------------------
- node / word / cylinder: provenance index only
- local shell-DtN Lambda_w: smallest invariant response observable
- regional DtN Lambda_R: directly Schur/Kron-reduced response of a region
- complement network C_{b,L}: finite nested net of direct regional responses at tree depth L
- limes diagnostic: scaling of the entire finite response net as L increases

Core operations
---------------
1. Generate the asymmetric dynamic birth tree using the v9/v10.2 conductance,
   directed live-update, record, and symmetric-reference mechanisms.
2. Compute local shell-DtNs using exactly the v10.2 shell split:
      root:     boundary=children(root), interior=[root]
      non-root: boundary=[parent(w)] + children(w), interior=[w]
3. Build regions (shell, prefix, sibling blocks, ancestor cones, two-cap bulk).
4. For each region R, compute the primary response:
      raw: direct graph-level Schur/Kron DtN from K
   Optional diagnostic only:
      comp: naive composition of local shell-DtNs with internal port elimination
5. Gate R0 validates the direct regional Schur/Kron response.
   Gate C0 is reported only when optional shell-composition is explicitly enabled.
6. Build finite positive response states rho_R from mean-zero projected S_R only.
   The skew/current A_R is never inserted into rho_R.
7. Compute relative entropies live||sym, live||record, record||sym, record||live.
8. Test entropic projectivity on prefix partitions and bulk scaling diagnostics.

No np.linalg.inv is used; all Schur complements use np.linalg.solve.

This script is intentionally finite.  It approximates the infinite-growth limit
by a sequence of complete finite direct regional complement networks C_{b,L},
not by attempting to build an infinite network directly.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import DefaultDict, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

EPS = 1e-12
DEFAULT_TOL = 1e-9
DEFAULT_COND_MAX = 1e12
Edge = Tuple[int, int]


# -----------------------------------------------------------------------------
# Data records
# -----------------------------------------------------------------------------

@dataclass
class Node:
    id: int
    parent: Optional[int]
    level: int
    birth_order: int
    birth_time: int
    birth_g: float
    g: float
    children: List[int] = field(default_factory=list)


@dataclass(frozen=True)
class LiveEnvSource:
    kind: str
    source: int
    factor: float


@dataclass(frozen=True)
class LiveEnvRelationGroup:
    child: int
    sources: Tuple[LiveEnvSource, ...]


@dataclass(frozen=True)
class LiveBackreactionRelation:
    kind: str
    source_child: int
    target: int
    factor: float


@dataclass
class SchurResult:
    ok: bool
    Lambda: Optional[np.ndarray] = None
    cond_KII: float = math.nan
    solve_residual: float = math.nan
    row_sum_residual: float = math.nan
    error: str = ""


@dataclass
class ShellResult:
    ok: bool
    node_id: int
    state: str
    boundary: List[int]
    interior: List[int]
    Lambda: Optional[np.ndarray]
    schur: SchurResult
    error: str = ""


@dataclass
class Region:
    region_id: str
    scheme: str
    level: int
    word: str
    interior: List[int]
    boundary: List[int]
    meta: Dict[str, object]


@dataclass
class ResponseBuild:
    ok: bool
    source: str
    Lambda: Optional[np.ndarray]
    boundary: List[int]
    cond_KII: float = math.nan
    solve_residual: float = math.nan
    row_sum_residual: float = math.nan
    error: str = ""
    n_internal_ports: int = 0
    n_shells_used: int = 0


@dataclass
class RhoBuild:
    ok: bool
    rho: Optional[np.ndarray]
    dim: int
    trace_raw: float = math.nan
    psd_defect: float = math.nan
    psd_defect_rel: float = math.nan
    min_eig: float = math.nan
    max_eig: float = math.nan
    cond_pos: float = math.nan
    error: str = ""


# -----------------------------------------------------------------------------
# v9/v10.2 dynamic birth provenance model
# -----------------------------------------------------------------------------

class DynamicBirthProvenanceModel:
    """v9/v10.2 growth/live-backreaction core, generalized in branching.

    The local shell-DtN construction below reuses the v10.2 shell exactly.  The
    fully symmetric reference used by v11 can be chosen separately by CLI.
    """

    def __init__(
        self,
        mode: str = "linear",
        branching: int = 3,
        base: float = 1.0,
        alpha_env: float = 0.22,
        ancestor_decay: float = 0.55,
        br_ancestor: float = 0.045,
        br_sibling: float = 0.035,
        eps: float = EPS,
        tol: float = DEFAULT_TOL,
        cond_max: float = DEFAULT_COND_MAX,
        relational_live_update: bool = True,
        live_relation_target_scale: str = "current_g",
        ancestor_kernel: str = "shell_norm_inverse_square",
    ) -> None:
        if branching < 2:
            raise ValueError("branching must be >= 2")
        if mode not in {"linear", "log", "saturating"}:
            raise ValueError("mode must be one of: linear, log, saturating")
        if live_relation_target_scale not in {"current_g", "birth_g"}:
            raise ValueError("live_relation_target_scale must be 'current_g' or 'birth_g'")
        if ancestor_kernel not in {"inverse_square", "shell_norm_inverse_square"}:
            raise ValueError("ancestor_kernel must be inverse_square or shell_norm_inverse_square")
        self.mode = str(mode)
        self.branching = int(branching)
        self.base = float(base)
        self.alpha_env = float(alpha_env)
        self.ancestor_decay = float(ancestor_decay)
        self.br_ancestor = float(br_ancestor)
        self.br_sibling = float(br_sibling)
        self.eps = float(eps)
        self.tol = float(tol)
        self.cond_max = float(cond_max)
        self.relational_live_update = bool(relational_live_update)
        self.live_relation_target_scale = live_relation_target_scale
        self.ancestor_kernel = ancestor_kernel

        self.nodes: Dict[int, Node] = {}
        self.t = 0
        self.next_id = 0

        self.directed_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.directed_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }
        self.live_env_relation_groups: List[LiveEnvRelationGroup] = []
        self.live_backreaction_relations: List[LiveBackreactionRelation] = []
        self.relational_rebuild_count = 0

        self.record_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.record_edges_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "record_env_ancestor_to_child": defaultdict(float),
            "record_env_sibling_to_child": defaultdict(float),
            "record_uv_child_to_ancestor": defaultdict(float),
            "record_sibling_backreaction": defaultdict(float),
        }
        self.sym_birth_edges: DefaultDict[Edge, float] = defaultdict(float)
        self.event_rows: List[dict] = []

        root = self._new_node(parent=None, level=0, birth_order=0, birth_g=1.0)
        self.root = root.id

    def _new_node(self, parent: Optional[int], level: int, birth_order: int, birth_g: float) -> Node:
        n = Node(
            id=self.next_id,
            parent=parent,
            level=int(level),
            birth_order=int(birth_order),
            birth_time=self.t,
            birth_g=float(birth_g),
            g=float(birth_g),
        )
        self.nodes[n.id] = n
        self.next_id += 1
        if parent is not None:
            self.nodes[parent].children.append(n.id)
        return n

    def add_directed_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.directed_edges[(u, v)] += w
        self.directed_edges_by_kind[kind][(u, v)] += w

    def add_record_edge(self, kind: str, u: int, v: int, weight: float) -> None:
        if abs(weight) <= 0.0:
            return
        w = float(weight)
        self.record_edges[(u, v)] += w
        self.record_edges_by_kind[kind][(u, v)] += w

    def add_sym_birth_edge(self, u: int, v: int, weight: float) -> None:
        w = float(weight)
        self.sym_birth_edges[(u, v)] += w
        self.sym_birth_edges[(v, u)] += w

    def live_target_amplitude(self, child: int) -> float:
        if self.live_relation_target_scale == "birth_g":
            return float(self.nodes[child].birth_g)
        return float(self.nodes[child].g)

    def register_live_env_group(self, child: int, sources: Sequence[LiveEnvSource]) -> None:
        self.live_env_relation_groups.append(LiveEnvRelationGroup(child=int(child), sources=tuple(sources)))

    def register_live_backreaction(self, kind: str, source_child: int, target: int, factor: float) -> None:
        self.live_backreaction_relations.append(
            LiveBackreactionRelation(kind=str(kind), source_child=int(source_child), target=int(target), factor=float(factor))
        )

    def rebuild_live_directed_edges_from_relations(self) -> None:
        new_by_kind: Dict[str, DefaultDict[Edge, float]] = {
            "env_ancestor_to_child": defaultdict(float),
            "env_sibling_to_child": defaultdict(float),
            "uv_child_to_ancestor": defaultdict(float),
            "sibling_backreaction": defaultdict(float),
        }
        for group in self.live_env_relation_groups:
            current_total = 0.0
            for src in group.sources:
                current_total += float(self.nodes[src.source].g) * float(src.factor)
            total = current_total + self.eps
            target_amp = self.live_target_amplitude(group.child)
            for src in group.sources:
                contrib = float(self.nodes[src.source].g) * float(src.factor)
                weight = self.alpha_env * contrib / total * target_amp
                if abs(weight) > 0.0:
                    new_by_kind[src.kind][(src.source, group.child)] += float(weight)

        for rel in self.live_backreaction_relations:
            weight = float(rel.factor) * float(self.nodes[rel.source_child].g)
            if abs(weight) > 0.0:
                new_by_kind[rel.kind][(rel.source_child, rel.target)] += float(weight)

        self.directed_edges_by_kind = new_by_kind
        self.directed_edges = defaultdict(float)
        for edge_map in self.directed_edges_by_kind.values():
            for e, w in edge_map.items():
                self.directed_edges[e] += float(w)
        self.relational_rebuild_count += 1

    def parent_line(self, parent: int) -> List[int]:
        line: List[int] = []
        cur: Optional[int] = parent
        while cur is not None:
            line.append(cur)
            cur = self.nodes[cur].parent
        return line

    def ancestor_kernel_value(self, d: int) -> float:
        if self.ancestor_kernel == "shell_norm_inverse_square":
            return 1.0 / ((self.branching ** (d - 1)) * (d * d))
        return 1.0 / (d * d)

    def birth_environment_load(self, parent: int, older_siblings: Sequence[int], current: bool = True) -> float:
        env = 0.0
        for d, a in enumerate(self.parent_line(parent), start=1):
            g = self.nodes[a].g if current else self.nodes[a].birth_g
            env += g * (self.ancestor_decay ** (d - 1))
        for s in older_siblings:
            g = self.nodes[s].g if current else self.nodes[s].birth_g
            env += g
        return float(env)

    def child_conductance_from_env(self, env_load: float) -> float:
        if self.mode == "linear":
            return self.base + self.alpha_env * env_load
        if self.mode == "log":
            return self.base + self.alpha_env * math.log1p(env_load)
        if self.mode == "saturating":
            return self.base + self.alpha_env * (env_load / (1.0 + env_load))
        raise ValueError(f"unknown mode: {self.mode}")

    def add_child(self, parent: int, order: int) -> int:
        self.t += 1
        older = list(self.nodes[parent].children)
        env_load = self.birth_environment_load(parent, older, current=True)
        birth_g = self.child_conductance_from_env(env_load)
        child = self._new_node(parent, self.nodes[parent].level + 1, order, birth_g)
        c = child.id

        self.add_sym_birth_edge(parent, c, birth_g)

        live_sources: List[LiveEnvSource] = []
        for d, a in enumerate(self.parent_line(parent), start=1):
            live_sources.append(LiveEnvSource("env_ancestor_to_child", a, self.ancestor_decay ** (d - 1)))
        for s in older:
            live_sources.append(LiveEnvSource("env_sibling_to_child", s, 1.0))
        self.register_live_env_group(c, live_sources)

        total_env = env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].g
            weight = self.alpha_env * contrib / total_env * birth_g
            self.add_directed_edge("env_sibling_to_child", s, c, weight)

        record_env_load = self.birth_environment_load(parent, older, current=False)
        total_record_env = record_env_load + self.eps
        for d, a in enumerate(self.parent_line(parent), start=1):
            contrib = self.nodes[a].birth_g * (self.ancestor_decay ** (d - 1))
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_ancestor_to_child", a, c, weight)
        for s in older:
            contrib = self.nodes[s].birth_g
            weight = self.alpha_env * contrib / total_record_env * birth_g
            self.add_record_edge("record_env_sibling_to_child", s, c, weight)

        for d, a in enumerate(self.parent_line(parent), start=1):
            kd = self.ancestor_kernel_value(d)
            delta = self.br_ancestor * birth_g * kd
            self.nodes[a].g += delta
            self.add_directed_edge("uv_child_to_ancestor", c, a, delta)
            self.register_live_backreaction("uv_child_to_ancestor", c, a, self.br_ancestor * kd)
            self.add_record_edge("record_uv_child_to_ancestor", c, a, delta)

        for s in older:
            delta = self.br_sibling * birth_g
            self.nodes[s].g += delta
            self.add_directed_edge("sibling_backreaction", c, s, delta)
            self.register_live_backreaction("sibling_backreaction", c, s, self.br_sibling)
            self.add_record_edge("record_sibling_backreaction", c, s, delta)

        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()

        children = self.nodes[parent].children
        self.event_rows.append(
            {
                "mode": self.mode,
                "t": self.t,
                "parent": parent,
                "child": c,
                "child_level": child.level,
                "child_order": order,
                "older_siblings": " ".join(map(str, older)),
                "env_load_live": env_load,
                "env_load_record": record_env_load,
                "child_birth_g": birth_g,
                "parent_g_after": self.nodes[parent].g,
                "sibling_current_g": " ".join(f"{self.nodes[x].g:.12g}" for x in children),
                "branching": self.branching,
                "parent_children_after": len(children),
                "parent_completed": int(len(children) == self.branching),
                "relational_live_update": int(self.relational_live_update),
                "live_relation_target_scale": self.live_relation_target_scale,
                "ancestor_kernel": self.ancestor_kernel,
                "live_env_relation_groups": len(self.live_env_relation_groups),
                "live_backreaction_relations": len(self.live_backreaction_relations),
                "relational_rebuild_count": self.relational_rebuild_count,
            }
        )
        return c

    def grow_level(self, frontier: Sequence[int]) -> List[int]:
        next_frontier: List[int] = []
        for p in frontier:
            for k in range(1, self.branching + 1):
                next_frontier.append(self.add_child(p, k))
        return next_frontier

    def run_growth(self, max_level: int) -> None:
        frontier = [self.root]
        for _level in range(1, max_level + 1):
            frontier = self.grow_level(frontier)
        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()

    def directed_laplacian(self, edges: Dict[Edge, float]) -> np.ndarray:
        n = self.next_id
        K = np.zeros((n, n), dtype=float)
        for (u, v), w in edges.items():
            if u == v or abs(w) <= 0.0:
                continue
            K[u, u] += w
            K[u, v] -= w
        return K

    def build_live_laplacian(self) -> np.ndarray:
        if self.relational_live_update:
            self.rebuild_live_directed_edges_from_relations()
        return self.directed_laplacian(self.directed_edges)

    def build_record_laplacian(self) -> np.ndarray:
        return self.directed_laplacian(self.record_edges)

    def build_symmetric_reference_laplacian(self, reference: str = "level_mean") -> np.ndarray:
        """Build a fully symmetric undirected reference Laplacian.

        reference='level_mean' keeps a depth-dependent average edge scale while
        removing sibling/birth-order asymmetry.  reference='uniform' uses base
        weight everywhere.  reference='birth_sym' reproduces the v10-style
        bidirectional birth-g edge scale and is less strict as a symmetry anchor.
        """
        edges: DefaultDict[Edge, float] = defaultdict(float)
        if reference == "birth_sym":
            return self.directed_laplacian(self.sym_birth_edges)
        level_means: Dict[int, float] = {}
        if reference == "level_mean":
            levels = sorted({n.level for n in self.nodes.values() if n.parent is not None})
            for lev in levels:
                vals = [n.birth_g for n in self.nodes.values() if n.level == lev and n.parent is not None]
                level_means[lev] = float(np.mean(vals)) if vals else self.base
        elif reference == "uniform":
            pass
        else:
            raise ValueError("sym_reference must be one of: level_mean, uniform, birth_sym")
        for nid, n in self.nodes.items():
            if n.parent is None:
                continue
            if reference == "uniform":
                w = self.base
            else:
                w = level_means.get(n.level, self.base)
            edges[(n.parent, nid)] += float(w)
            edges[(nid, n.parent)] += float(w)
        return self.directed_laplacian(edges)

    def schur_response(self, K: np.ndarray, boundary: Sequence[int], interior: Sequence[int]) -> SchurResult:
        return schur_response_matrix(K, boundary, interior, self.cond_max)

    def address_orders(self, node_id: int) -> List[int]:
        orders: List[int] = []
        cur: Optional[int] = node_id
        while cur is not None and cur != self.root:
            n = self.nodes[cur]
            orders.append(n.birth_order)
            cur = n.parent
        return list(reversed(orders))

    def word(self, node_id: int) -> str:
        orders = self.address_orders(node_id)
        return "" if not orders else ".".join(map(str, orders))

    def parent_word(self, node_id: int) -> str:
        p = self.nodes[node_id].parent
        return "" if p is None else self.word(p)

    def nodes_at_level(self, level: int) -> List[int]:
        return sorted([n.id for n in self.nodes.values() if n.level == level], key=lambda x: self.address_orders(x))

    def descendants_or_self(self, node_id: int, max_level: Optional[int] = None) -> List[int]:
        w = self.word(node_id)
        out = []
        for nid, n in self.nodes.items():
            if max_level is not None and n.level > max_level:
                continue
            if word_is_descendant_or_equal(self.word(nid), w):
                out.append(nid)
        return sorted(out, key=lambda x: (self.nodes[x].level, self.address_orders(x)))

    def path_root_to(self, node_id: int) -> List[int]:
        path: List[int] = []
        cur: Optional[int] = node_id
        while cur is not None:
            path.append(cur)
            cur = self.nodes[cur].parent
        return list(reversed(path))

    def address_rows(self) -> List[dict]:
        rows: List[dict] = []
        for nid in sorted(self.nodes, key=lambda x: (self.nodes[x].level, self.address_orders(x))):
            n = self.nodes[nid]
            children = sorted(n.children, key=lambda c: self.nodes[c].birth_order)
            rows.append(
                {
                    "node_id": nid,
                    "level": n.level,
                    "word": self.word(nid),
                    "parent_node": "" if n.parent is None else n.parent,
                    "parent_word": self.parent_word(nid),
                    "birth_order": n.birth_order,
                    "birth_order_path": self.word(nid),
                    "child_nodes": " ".join(map(str, children)),
                    "child_words": " ".join(self.word(c) for c in children),
                    "n_children": len(children),
                    "branching": self.branching,
                    "root_relation": "root" if nid == self.root else "descendant",
                    "front_relation": "front" if len(children) == 0 else "interior",
                    "F1_label": "root_front_prefix_depth",
                    "F2_label": "birth_order_rank",
                    "birth_g": n.birth_g,
                    "live_g": n.g,
                    "birth_time": n.birth_time,
                }
            )
        return rows


# -----------------------------------------------------------------------------
# Linear algebra helpers
# -----------------------------------------------------------------------------

def safe_float(x: object, default: float = math.nan) -> float:
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def word_is_descendant_or_equal(desc_word: str, anc_word: str) -> bool:
    if anc_word == "":
        return True
    return desc_word == anc_word or desc_word.startswith(anc_word + ".")


def mean_zero_basis(n: int) -> np.ndarray:
    """Return Q with Q.T @ 1=0 and Q.T @ Q=I, shape n x (n-1)."""
    if n <= 1:
        return np.zeros((n, 0), dtype=float)
    M = np.zeros((n, n - 1), dtype=float)
    for j in range(n - 1):
        M[j, j] = 1.0
        M[n - 1, j] = -1.0
    Q, _ = np.linalg.qr(M, mode="reduced")
    return Q


def schur_response_matrix(K: np.ndarray, boundary: Sequence[int], interior: Sequence[int], cond_max: float) -> SchurResult:
    if len(boundary) == 0:
        return SchurResult(ok=False, error="empty_boundary")
    if len(interior) == 0:
        return SchurResult(ok=False, error="empty_interior")
    if set(boundary).intersection(interior):
        return SchurResult(ok=False, error="boundary_interior_overlap")
    B = np.array(list(boundary), dtype=int)
    I = np.array(list(interior), dtype=int)
    try:
        K_BB = K[np.ix_(B, B)]
        K_BI = K[np.ix_(B, I)]
        K_IB = K[np.ix_(I, B)]
        K_II = K[np.ix_(I, I)]
        cond = float(np.linalg.cond(K_II))
        if not np.isfinite(cond) or cond > cond_max:
            return SchurResult(ok=False, cond_KII=cond, error="singular_or_ill_conditioned_KII")
        X = np.linalg.solve(K_II, K_IB)
        Lambda = K_BB - K_BI @ X
        solve_residual = float(np.linalg.norm(K_II @ X - K_IB, ord="fro"))
        row_sum_residual = float(np.linalg.norm(Lambda @ np.ones(len(B))))
        return SchurResult(True, Lambda, cond, solve_residual, row_sum_residual, "")
    except np.linalg.LinAlgError as exc:
        return SchurResult(ok=False, error=f"lin_alg_error:{exc}")
    except Exception as exc:
        return SchurResult(ok=False, error=f"error:{type(exc).__name__}:{exc}")


def schur_on_local_ports(M: np.ndarray, external_idx: Sequence[int], internal_idx: Sequence[int], cond_max: float) -> SchurResult:
    if len(external_idx) == 0:
        return SchurResult(ok=False, error="empty_external_ports")
    if len(internal_idx) == 0:
        E = np.array(list(external_idx), dtype=int)
        Lambda = M[np.ix_(E, E)]
        return SchurResult(True, Lambda, math.nan, 0.0, float(np.linalg.norm(Lambda @ np.ones(len(E)))), "")
    return schur_response_matrix(M, boundary=external_idx, interior=internal_idx, cond_max=cond_max)


def decompose_response(Lambda: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    S = 0.5 * (Lambda + Lambda.T)
    A = 0.5 * (Lambda - Lambda.T)
    return S, A


def fro_norm(x: Optional[np.ndarray]) -> float:
    if x is None:
        return math.nan
    return float(np.linalg.norm(x, ord="fro"))


def spectral_log_spd(rho: np.ndarray, floor: float = 1e-300) -> np.ndarray:
    rho = 0.5 * (rho + rho.T)
    vals, vecs = np.linalg.eigh(rho)
    vals = np.maximum(vals, floor)
    return (vecs * np.log(vals)) @ vecs.T


def relative_entropy(rho: np.ndarray, sigma: np.ndarray) -> float:
    logr = spectral_log_spd(rho)
    logs = spectral_log_spd(sigma)
    val = float(np.trace(rho @ (logr - logs)))
    if abs(val) < 1e-12:
        val = 0.0
    return val


def rho_from_response(Lambda: np.ndarray, eps_rel: float) -> RhoBuild:
    if Lambda.shape[0] <= 1:
        return RhoBuild(False, None, 0, error="boundary_dim_le_1")
    S, _A = decompose_response(Lambda)
    Q = mean_zero_basis(S.shape[0])
    if Q.shape[1] <= 0:
        return RhoBuild(False, None, 0, error="zero_mean_dim")
    S_perp = Q.T @ S @ Q
    S_perp = 0.5 * (S_perp + S_perp.T)
    try:
        eigs, vecs = np.linalg.eigh(S_perp)
    except np.linalg.LinAlgError as exc:
        return RhoBuild(False, None, int(Q.shape[1]), error=f"eigh_error:{exc}")
    pos = np.maximum(eigs, 0.0)
    pos_trace = float(np.sum(pos))
    psd_defect = float(np.sum(np.maximum(-eigs, 0.0)))
    psd_defect_rel = float(psd_defect / max(psd_defect + pos_trace, EPS))
    eps_abs = float(eps_rel * max(pos_trace, 1.0))
    vals = pos + eps_abs
    tr = float(np.sum(vals))
    if tr <= 0.0 or not np.isfinite(tr):
        return RhoBuild(False, None, int(Q.shape[1]), psd_defect=psd_defect, psd_defect_rel=psd_defect_rel, error="nonpositive_regularized_trace")
    rho = (vecs * (vals / tr)) @ vecs.T
    rho = 0.5 * (rho + rho.T)
    min_pos = float(np.min(vals))
    max_pos = float(np.max(vals))
    return RhoBuild(
        True,
        rho,
        int(Q.shape[1]),
        trace_raw=pos_trace,
        psd_defect=psd_defect,
        psd_defect_rel=psd_defect_rel,
        min_eig=float(np.min(eigs)) if len(eigs) else math.nan,
        max_eig=float(np.max(eigs)) if len(eigs) else math.nan,
        cond_pos=float(max_pos / max(min_pos, EPS)),
        error="",
    )


# -----------------------------------------------------------------------------
# Shell DtN and region definitions
# -----------------------------------------------------------------------------

def shell_boundary_and_interior(model: DynamicBirthProvenanceModel, node_id: int) -> Tuple[List[int], List[int], str]:
    n = model.nodes[node_id]
    children = sorted(n.children, key=lambda c: model.nodes[c].birth_order)
    if len(children) != model.branching:
        return [], [node_id], "node_has_no_complete_child_shell"
    if n.parent is None:
        boundary = list(children)
    else:
        boundary = [n.parent] + list(children)
    return boundary, [node_id], ""


def compute_shells_for_state(model: DynamicBirthProvenanceModel, K: np.ndarray, state: str, max_level: int) -> Dict[int, ShellResult]:
    out: Dict[int, ShellResult] = {}
    for level in range(0, max_level):
        for nid in model.nodes_at_level(level):
            boundary, interior, err = shell_boundary_and_interior(model, nid)
            if err:
                out[nid] = ShellResult(False, nid, state, boundary, interior, None, SchurResult(False, error=err), err)
                continue
            res = model.schur_response(K, boundary=boundary, interior=interior)
            out[nid] = ShellResult(res.ok, nid, state, boundary, interior, res.Lambda, res, res.error)
    return out


def region_sort_key(model: DynamicBirthProvenanceModel, r: Region) -> Tuple[str, int, str, str]:
    return (r.scheme, r.level, r.word, r.region_id)


def descendants_at_level(model: DynamicBirthProvenanceModel, node_id: int, level: int) -> List[int]:
    prefix = model.word(node_id)
    return [nid for nid in model.nodes_at_level(level) if word_is_descendant_or_equal(model.word(nid), prefix)]


def make_region(
    model: DynamicBirthProvenanceModel,
    scheme: str,
    interior: Iterable[int],
    boundary: Iterable[int],
    level: int,
    word: str,
    meta: Dict[str, object],
) -> Optional[Region]:
    interior_list = sorted(set(int(x) for x in interior), key=lambda x: (model.nodes[x].level, model.address_orders(x)))
    boundary_list = sorted(set(int(x) for x in boundary), key=lambda x: (model.nodes[x].level, model.address_orders(x)))
    if not interior_list or not boundary_list:
        return None
    if set(interior_list).intersection(boundary_list):
        return None
    rid_word = word if word != "" else "root"
    rid = f"{scheme}:L{level}:{rid_word}:{meta.get('tag','')}".rstrip(":")
    return Region(rid, scheme, int(level), str(word), interior_list, boundary_list, dict(meta))


def build_regions(
    model: DynamicBirthProvenanceModel,
    max_level: int,
    schemes: Sequence[str],
    cap_roots: Sequence[int],
    cap_fronts: Sequence[int],
    max_regions_per_scheme: int,
) -> List[Region]:
    regions: List[Region] = []
    schemes_set = set(schemes)

    if "shell" in schemes_set:
        shell_regs = []
        for level in range(0, max_level):
            for nid in model.nodes_at_level(level):
                boundary, interior, err = shell_boundary_and_interior(model, nid)
                if err:
                    continue
                shell_regs.append(make_region(model, "shell", interior, boundary, level, model.word(nid), {"node_id": nid, "tag": f"node{nid}"}))
        regions.extend([r for r in shell_regs if r is not None][:max_regions_per_scheme])

    if "prefix" in schemes_set:
        pref_regs = []
        for level in range(0, max_level):
            for nid in model.nodes_at_level(level):
                interior = [x for x in model.descendants_or_self(nid, max_level=max_level - 1)]
                boundary: List[int] = []
                if model.nodes[nid].parent is not None:
                    boundary.append(model.nodes[nid].parent)  # rootward external cap
                boundary.extend(descendants_at_level(model, nid, max_level))  # front boundary
                pref_regs.append(make_region(model, "prefix", interior, boundary, level, model.word(nid), {"root_node": nid, "tag": f"prefix{nid}"}))
        regions.extend([r for r in pref_regs if r is not None][:max_regions_per_scheme])

    if "sibling" in schemes_set:
        sib_regs = []
        for level in range(0, max_level - 1):
            for p in model.nodes_at_level(level):
                children = sorted(model.nodes[p].children, key=lambda c: model.nodes[c].birth_order)
                if len(children) != model.branching:
                    continue
                # Sibling block: children are interiors, parent and grandchildren are boundary ports.
                interior = [c for c in children if model.nodes[c].level < max_level]
                boundary = [p]
                for c in interior:
                    boundary.extend(model.nodes[c].children)
                sib_regs.append(make_region(model, "sibling", interior, boundary, level + 1, model.word(p), {"parent_node": p, "tag": f"siblings_of_{p}"}))
        regions.extend([r for r in sib_regs if r is not None][:max_regions_per_scheme])

    if "ancestor" in schemes_set:
        anc_regs = []
        for level in range(1, max_level):
            for nid in model.nodes_at_level(level):
                path = model.path_root_to(nid)
                interior = [x for x in path if model.nodes[x].level < max_level]
                path_set = set(path)
                boundary: List[int] = []
                for x in interior:
                    for c in model.nodes[x].children:
                        if c not in path_set:
                            boundary.append(c)
                # terminal descendants one step forward keep the cone open at the front
                boundary.extend([c for c in model.nodes[nid].children if c not in path_set])
                anc_regs.append(make_region(model, "ancestor", interior, boundary, level, model.word(nid), {"target_node": nid, "tag": f"path_to_{nid}"}))
        regions.extend([r for r in anc_regs if r is not None][:max_regions_per_scheme])

    if "bulk" in schemes_set:
        bulk_regs = []
        for rcap in cap_roots:
            for fcap in cap_fronts:
                if rcap < 0 or fcap < 0:
                    continue
                front_level = max_level - fcap
                if rcap >= front_level - 1:
                    continue
                interior = [nid for nid, n in model.nodes.items() if rcap < n.level < front_level]
                boundary = model.nodes_at_level(rcap) + model.nodes_at_level(front_level)
                bulk_regs.append(make_region(model, "bulk", interior, boundary, rcap + 1, "bulk", {"cap_root": rcap, "cap_front": fcap, "front_level": front_level, "tag": f"r{rcap}_f{fcap}"}))
        regions.extend([r for r in bulk_regs if r is not None][:max_regions_per_scheme])

    # Deduplicate by region id while preserving deterministic order.
    seen = set()
    unique: List[Region] = []
    for r in sorted(regions, key=lambda x: region_sort_key(model, x)):
        if r.region_id in seen:
            continue
        seen.add(r.region_id)
        unique.append(r)
    return unique


# -----------------------------------------------------------------------------
# Raw and composed regional responses
# -----------------------------------------------------------------------------

def direct_region_response(
    model: DynamicBirthProvenanceModel,
    K: np.ndarray,
    region: Region,
    max_direct_interior: int,
    max_root_prefix_interior: Optional[int] = None,
) -> ResponseBuild:
    limit = int(max_direct_interior)
    if region.scheme == "prefix" and region.word == "" and max_root_prefix_interior is not None:
        limit = int(max_root_prefix_interior)
    if len(region.interior) > limit:
        return ResponseBuild(False, "raw", None, region.boundary, error=f"skipped_interior_gt_{limit}")
    res = model.schur_response(K, boundary=region.boundary, interior=region.interior)
    return ResponseBuild(res.ok, "raw", res.Lambda, list(region.boundary), res.cond_KII, res.solve_residual, res.row_sum_residual, res.error)


def composed_region_response(
    model: DynamicBirthProvenanceModel,
    region: Region,
    shell_cache: Dict[int, ShellResult],
) -> ResponseBuild:
    # Compose full shell responses for all central nodes in the region and then
    # eliminate internal boundary-ports.  This is response-level port elimination.
    shells: List[ShellResult] = []
    for nid in region.interior:
        sh = shell_cache.get(nid)
        if sh is None or not sh.ok or sh.Lambda is None:
            return ResponseBuild(False, "comp", None, region.boundary, error=f"missing_or_invalid_shell_for_node_{nid}", n_shells_used=len(shells))
        shells.append(sh)
    port_nodes: List[int] = sorted(set(p for sh in shells for p in sh.boundary), key=lambda x: (model.nodes[x].level, model.address_orders(x)))
    if not set(region.boundary).issubset(set(port_nodes)):
        missing = sorted(set(region.boundary) - set(port_nodes))
        return ResponseBuild(False, "comp", None, region.boundary, error=f"external_boundary_not_in_shell_ports:{missing}", n_shells_used=len(shells))
    pindex = {p: i for i, p in enumerate(port_nodes)}
    M = np.zeros((len(port_nodes), len(port_nodes)), dtype=float)
    for sh in shells:
        idx = [pindex[p] for p in sh.boundary]
        for a_local, a in enumerate(idx):
            for b_local, b in enumerate(idx):
                M[a, b] += float(sh.Lambda[a_local, b_local])
    external_idx = [pindex[p] for p in region.boundary]
    external_set = set(external_idx)
    internal_idx = [i for i in range(len(port_nodes)) if i not in external_set]
    res = schur_on_local_ports(M, external_idx, internal_idx, model.cond_max)
    return ResponseBuild(res.ok, "comp", res.Lambda, list(region.boundary), res.cond_KII, res.solve_residual, res.row_sum_residual, res.error, n_internal_ports=len(internal_idx), n_shells_used=len(shells))


def response_summary_metrics(Lambda: Optional[np.ndarray]) -> Dict[str, float]:
    if Lambda is None:
        return {
            "n_boundary": math.nan,
            "Lambda_fro": math.nan,
            "S_fro": math.nan,
            "A_fro": math.nan,
            "rel_skew": math.nan,
            "row_sum_residual": math.nan,
        }
    S, A = decompose_response(Lambda)
    Lf = fro_norm(Lambda)
    return {
        "n_boundary": int(Lambda.shape[0]),
        "Lambda_fro": Lf,
        "S_fro": fro_norm(S),
        "A_fro": fro_norm(A),
        "rel_skew": float(fro_norm(A) / max(Lf, EPS)),
        "row_sum_residual": float(np.linalg.norm(Lambda @ np.ones(Lambda.shape[0]))),
    }


# -----------------------------------------------------------------------------
# Analysis per finite complement network C_{b,L}
# -----------------------------------------------------------------------------

def compute_shell_rows(model: DynamicBirthProvenanceModel, shells_by_state: Dict[str, Dict[int, ShellResult]], b: int, L: int, mode: str) -> List[dict]:
    rows: List[dict] = []
    for state, cache in shells_by_state.items():
        for nid, sh in sorted(cache.items(), key=lambda kv: (model.nodes[kv[0]].level, model.address_orders(kv[0]))):
            metrics = response_summary_metrics(sh.Lambda if sh.ok else None)
            S_perp_info = {}
            if sh.ok and sh.Lambda is not None:
                rho_b = rho_from_response(sh.Lambda, eps_rel=1e-10)
                S_perp_info = {
                    "mean_zero_dim": rho_b.dim,
                    "psd_defect": rho_b.psd_defect,
                    "psd_defect_rel": rho_b.psd_defect_rel,
                    "trace_positive_S_perp": rho_b.trace_raw,
                    "min_S_perp_eig": rho_b.min_eig,
                    "max_S_perp_eig": rho_b.max_eig,
                }
            row = {
                "branching": b,
                "max_level": L,
                "mode": mode,
                "state": state,
                "node_id": nid,
                "level": model.nodes[nid].level,
                "word": model.word(nid),
                "ok": int(sh.ok),
                "error": sh.error,
                "boundary_nodes": " ".join(map(str, sh.boundary)),
                "interior_nodes": " ".join(map(str, sh.interior)),
                "cond_KII": sh.schur.cond_KII,
                "solve_residual": sh.schur.solve_residual,
                "schur_row_sum_residual": sh.schur.row_sum_residual,
            }
            row.update(metrics)
            row.update(S_perp_info)
            rows.append(row)
    return rows


def build_response_and_entropy_rows(
    model: DynamicBirthProvenanceModel,
    b: int,
    L: int,
    mode: str,
    regions: Sequence[Region],
    K_by_state: Dict[str, np.ndarray],
    shell_by_state: Dict[str, Dict[int, ShellResult]],
    entropy_eps: float,
    max_direct_interior: int,
    enable_shell_composition: bool,
    max_root_prefix_interior: Optional[int] = None,
) -> Tuple[List[dict], List[dict], List[dict], List[dict], List[dict]]:
    region_rows: List[dict] = []
    gate_r0_rows: List[dict] = []
    gate_c0_rows: List[dict] = []
    entropy_rows: List[dict] = []
    region_metric_rows: List[dict] = []

    # region -> state -> responses
    responses: Dict[str, Dict[str, Dict[str, ResponseBuild]]] = defaultdict(lambda: defaultdict(dict))

    for region in regions:
        meta_json = json.dumps(region.meta, sort_keys=True)
        region_rows.append({
            "branching": b,
            "max_level": L,
            "mode": mode,
            "region_id": region.region_id,
            "scheme": region.scheme,
            "level": region.level,
            "word": region.word,
            "n_interior": len(region.interior),
            "n_boundary": len(region.boundary),
            "interior_nodes": " ".join(map(str, region.interior)),
            "boundary_nodes": " ".join(map(str, region.boundary)),
            "meta": meta_json,
        })
        for state, K in K_by_state.items():
            raw = direct_region_response(model, K, region, max_direct_interior=max_direct_interior, max_root_prefix_interior=max_root_prefix_interior)
            if enable_shell_composition:
                comp = composed_region_response(model, region, shell_by_state[state])
            else:
                comp = ResponseBuild(False, "comp", None, list(region.boundary), error="disabled_optional_shell_composition")
            responses[region.region_id][state]["raw"] = raw
            responses[region.region_id][state]["comp"] = comp

            direct_verdict = "pass" if raw.ok else ("skipped" if raw.error.startswith("skipped_") else "fail")
            if raw.ok:
                if math.isfinite(raw.cond_KII) and raw.cond_KII > DEFAULT_COND_MAX:
                    direct_verdict = "warn_condition"
                elif math.isfinite(raw.solve_residual) and raw.solve_residual > 1e-6:
                    direct_verdict = "warn_solve_residual"
            gate_r0_rows.append({
                "branching": b,
                "max_level": L,
                "mode": mode,
                "region_id": region.region_id,
                "scheme": region.scheme,
                "level": region.level,
                "word": region.word,
                "state": state,
                "direct_ok": int(raw.ok),
                "direct_error": raw.error,
                "n_region_interior": len(region.interior),
                "n_region_boundary": len(region.boundary),
                "cond_KII": raw.cond_KII,
                "solve_residual": raw.solve_residual,
                "response_row_sum_residual": raw.row_sum_residual,
                "verdict": direct_verdict,
            })

            sources_to_write = [("raw", raw)]
            if enable_shell_composition:
                sources_to_write.append(("comp", comp))
            for source, rb in sources_to_write:
                m = response_summary_metrics(rb.Lambda if rb.ok else None)
                row = {
                    "branching": b,
                    "max_level": L,
                    "mode": mode,
                    "region_id": region.region_id,
                    "scheme": region.scheme,
                    "level": region.level,
                    "word": region.word,
                    "state": state,
                    "source": source,
                    "ok": int(rb.ok),
                    "error": rb.error,
                    "n_region_interior": len(region.interior),
                    "n_region_boundary": len(region.boundary),
                    "n_internal_ports": rb.n_internal_ports,
                    "n_shells_used": rb.n_shells_used,
                    "cond_KII": rb.cond_KII,
                    "solve_residual": rb.solve_residual,
                    "response_row_sum_residual": rb.row_sum_residual,
                }
                row.update(m)
                region_metric_rows.append(row)

        # Optional C0 composition gate.  In v11.2 this is explicitly not a main-path gate.
        if enable_shell_composition:
            for state in K_by_state:
                raw = responses[region.region_id][state]["raw"]
                comp = responses[region.region_id][state]["comp"]
                if raw.ok and comp.ok and raw.Lambda is not None and comp.Lambda is not None and raw.Lambda.shape == comp.Lambda.shape:
                    diff = raw.Lambda - comp.Lambda
                    raw_norm = fro_norm(raw.Lambda)
                    rel = float(fro_norm(diff) / max(raw_norm, EPS))
                    S_raw, A_raw = decompose_response(raw.Lambda)
                    S_comp, A_comp = decompose_response(comp.Lambda)
                    rel_S = float(fro_norm(S_raw - S_comp) / max(fro_norm(S_raw), EPS))
                    rel_A = float(fro_norm(A_raw - A_comp) / max(fro_norm(A_raw), EPS))
                    verdict = "pass" if rel <= 1e-8 else ("warn" if rel <= 1e-4 else "fail")
                else:
                    rel = math.nan
                    rel_S = math.nan
                    rel_A = math.nan
                    verdict = "not_comparable"
                gate_c0_rows.append({
                    "branching": b,
                    "max_level": L,
                    "mode": mode,
                    "region_id": region.region_id,
                    "scheme": region.scheme,
                    "level": region.level,
                    "word": region.word,
                    "state": state,
                    "raw_ok": int(raw.ok),
                    "comp_ok": int(comp.ok),
                    "raw_error": raw.error,
                    "comp_error": comp.error,
                    "rel_fro_defect": rel,
                    "rel_S_defect": rel_S,
                    "rel_A_defect": rel_A,
                    "verdict": verdict,
                })

        # Entropy rows use the direct raw regional response as primary.  Optional comp is fallback only if enabled and raw was skipped/invalid.
        primary: Dict[str, Tuple[str, ResponseBuild, RhoBuild]] = {}
        for state in K_by_state:
            raw_rb = responses[region.region_id][state]["raw"]
            comp_rb = responses[region.region_id][state]["comp"]
            if raw_rb.ok:
                selected_source = "raw"
                rb = raw_rb
            elif enable_shell_composition and comp_rb.ok:
                selected_source = "comp_fallback"
                rb = comp_rb
            else:
                selected_source = "raw_invalid"
                rb = raw_rb
            if rb.ok and rb.Lambda is not None:
                rho_b = rho_from_response(rb.Lambda, eps_rel=entropy_eps)
            else:
                rho_b = RhoBuild(False, None, 0, error=rb.error)
            primary[state] = (selected_source, rb, rho_b)

        def rel_row(kind: str, lhs: str, rhs: str) -> dict:
            lhs_source, lhs_rb, lhs_rho = primary[lhs]
            rhs_source, rhs_rb, rhs_rho = primary[rhs]
            if lhs_rho.ok and rhs_rho.ok and lhs_rho.rho is not None and rhs_rho.rho is not None and lhs_rho.rho.shape == rhs_rho.rho.shape:
                try:
                    D = relative_entropy(lhs_rho.rho, rhs_rho.rho)
                    ok = int(np.isfinite(D) and D >= -1e-10)
                    err = "" if ok else "negative_or_nonfinite_relative_entropy"
                except Exception as exc:
                    D = math.nan
                    ok = 0
                    err = f"relative_entropy_error:{type(exc).__name__}:{exc}"
            else:
                D = math.nan
                ok = 0
                err = f"rho_invalid_or_shape_mismatch:{lhs_rho.error}|{rhs_rho.error}"
            _, A_lhs = decompose_response(lhs_rb.Lambda) if lhs_rb.ok and lhs_rb.Lambda is not None else (None, None)
            S_lhs, _ = decompose_response(lhs_rb.Lambda) if lhs_rb.ok and lhs_rb.Lambda is not None else (None, None)
            A_norm = fro_norm(A_lhs)
            S_norm = fro_norm(S_lhs)
            return {
                "branching": b,
                "max_level": L,
                "mode": mode,
                "region_id": region.region_id,
                "scheme": region.scheme,
                "level": region.level,
                "word": region.word,
                "entropy_kind": kind,
                "lhs_state": lhs,
                "rhs_state": rhs,
                "lhs_source": lhs_source,
                "rhs_source": rhs_source,
                "ok": ok,
                "error": err,
                "D": D,
                "rho_dim": lhs_rho.dim if lhs_rho.ok else rhs_rho.dim,
                "lhs_trace_positive_S_perp": lhs_rho.trace_raw,
                "rhs_trace_positive_S_perp": rhs_rho.trace_raw,
                "lhs_psd_defect_rel": lhs_rho.psd_defect_rel,
                "rhs_psd_defect_rel": rhs_rho.psd_defect_rel,
                "lhs_cond_pos": lhs_rho.cond_pos,
                "rhs_cond_pos": rhs_rho.cond_pos,
                "A_fro_lhs": A_norm,
                "S_fro_lhs": S_norm,
                "rel_skew_lhs": float(A_norm / max(fro_norm(lhs_rb.Lambda), EPS)) if lhs_rb.ok and lhs_rb.Lambda is not None else math.nan,
            }
        entropy_rows.append(rel_row("live_vs_sym", "live", "sym"))
        entropy_rows.append(rel_row("live_vs_record", "live", "record"))
        entropy_rows.append(rel_row("record_vs_sym", "record", "sym"))
        entropy_rows.append(rel_row("record_vs_live", "record", "live"))

    return region_rows, region_metric_rows, gate_r0_rows, gate_c0_rows, entropy_rows


def entropic_projectivity_rows(entropy_rows: Sequence[dict], b: int, L: int, mode: str) -> List[dict]:
    # Prefix only: normalized D at prefix depth k should push forward from k+1.
    rows: List[dict] = []
    prefix_rows = [r for r in entropy_rows if r.get("scheme") == "prefix" and r.get("entropy_kind") == "live_vs_sym" and int(r.get("ok", 0)) == 1]
    by_level: DefaultDict[int, List[dict]] = defaultdict(list)
    for r in prefix_rows:
        D = safe_float(r.get("D"), 0.0)
        if D < 0.0 or not math.isfinite(D):
            continue
        by_level[int(r["level"])].append(r)
    p_by_key: Dict[Tuple[int, str], float] = {}
    for lev, rs in by_level.items():
        total = sum(max(0.0, safe_float(r.get("D"), 0.0)) for r in rs)
        if total <= EPS:
            continue
        for r in rs:
            p_by_key[(lev, str(r.get("word", "")))] = max(0.0, safe_float(r.get("D"), 0.0)) / total
    levels = sorted(by_level)
    for lev in levels:
        if lev + 1 not in by_level:
            continue
        defect = 0.0
        n_terms = 0
        for r in by_level[lev]:
            w = str(r.get("word", ""))
            p = p_by_key.get((lev, w), math.nan)
            if not math.isfinite(p):
                continue
            child_sum = 0.0
            for cr in by_level[lev + 1]:
                cw = str(cr.get("word", ""))
                if word_is_descendant_or_equal(cw, w) and cw != w:
                    child_sum += p_by_key.get((lev + 1, cw), 0.0)
            defect += abs(p - child_sum)
            n_terms += 1
        rows.append({
            "branching": b,
            "max_level": L,
            "mode": mode,
            "entropy_kind": "live_vs_sym",
            "parent_prefix_level": lev,
            "child_prefix_level": lev + 1,
            "n_parent_terms": n_terms,
            "delta_D_projective": defect,
            "delta_D_projective_mean": defect / max(n_terms, 1),
            "verdict": "controlled" if defect <= 1e-8 else ("finite_nonzero" if math.isfinite(defect) else "invalid"),
        })
    return rows


def aggregate_scaling_rows(all_entropy_rows: Sequence[dict], all_gate_rows: Sequence[dict], all_region_metric_rows: Sequence[dict]) -> Tuple[List[dict], List[dict]]:
    summary: List[dict] = []
    key_rows: DefaultDict[Tuple[int, str, int, str], List[dict]] = defaultdict(list)
    for r in all_entropy_rows:
        if r.get("entropy_kind") != "live_vs_sym" or int(r.get("ok", 0)) != 1:
            continue
        key = (int(r["branching"]), str(r["mode"]), int(r["max_level"]), str(r["scheme"]))
        key_rows[key].append(r)
    for key, rs in sorted(key_rows.items()):
        b, mode, L, scheme = key
        Ds = np.array([max(0.0, safe_float(r.get("D"), 0.0)) for r in rs], dtype=float)
        As = np.array([safe_float(r.get("A_fro_lhs"), math.nan) for r in rs], dtype=float)
        relsk = np.array([safe_float(r.get("rel_skew_lhs"), math.nan) for r in rs], dtype=float)
        good_A = np.isfinite(As)
        corr = math.nan
        if len(Ds) >= 2 and np.sum(good_A) >= 2 and float(np.std(Ds)) > EPS and float(np.std(As[good_A])) > EPS:
            # Align finite A subset with D subset.
            D2 = Ds[good_A]
            A2 = As[good_A]
            corr = float(np.corrcoef(D2, A2)[0, 1])
        summary.append({
            "branching": b,
            "mode": mode,
            "max_level": L,
            "scheme": scheme,
            "n_regions": len(rs),
            "D_sum": float(np.sum(Ds)) if len(Ds) else math.nan,
            "D_mean": float(np.mean(Ds)) if len(Ds) else math.nan,
            "D_median": float(np.median(Ds)) if len(Ds) else math.nan,
            "D_max": float(np.max(Ds)) if len(Ds) else math.nan,
            "A_fro_mean": float(np.nanmean(As)) if len(As) else math.nan,
            "rel_skew_mean": float(np.nanmean(relsk)) if len(relsk) else math.nan,
            "corr_D_A_fro": corr,
        })

    # L to L+1 ratio rows for the same b/mode/scheme.
    limes: List[dict] = []
    by_bms: DefaultDict[Tuple[int, str, str], List[dict]] = defaultdict(list)
    for r in summary:
        by_bms[(int(r["branching"]), str(r["mode"]), str(r["scheme"]))].append(r)
    for key, rs in by_bms.items():
        rs_sorted = sorted(rs, key=lambda x: int(x["max_level"]))
        for a, c in zip(rs_sorted, rs_sorted[1:]):
            L0 = int(a["max_level"])
            L1 = int(c["max_level"])
            if L1 != L0 + 1:
                continue
            D0 = safe_float(a.get("D_sum"), math.nan)
            D1 = safe_float(c.get("D_sum"), math.nan)
            skew0 = safe_float(a.get("rel_skew_mean"), math.nan)
            skew1 = safe_float(c.get("rel_skew_mean"), math.nan)
            limes.append({
                "branching": key[0],
                "mode": key[1],
                "scheme": key[2],
                "L0": L0,
                "L1": L1,
                "D_sum_L0": D0,
                "D_sum_L1": D1,
                "D_sum_ratio_L1_over_L0": float(D1 / max(D0, EPS)) if math.isfinite(D0) and math.isfinite(D1) else math.nan,
                "rel_skew_mean_L0": skew0,
                "rel_skew_mean_L1": skew1,
                "rel_skew_delta": float(skew1 - skew0) if math.isfinite(skew0) and math.isfinite(skew1) else math.nan,
            })
    return summary, limes




def entropy_density_summary_rows(all_entropy_rows: Sequence[dict], all_region_rows: Sequence[dict]) -> List[dict]:
    """Normalize live||sym relative entropy by region count, boundary and interior size.

    This is a v11.2 hardening layer: D_R is still an information functional, not
    automatically a measure.  These rows expose whether the finite limes behaves
    extensively with region count, boundary size, or interior size.
    """
    size_lookup: Dict[Tuple[int, int, str, str], Tuple[int, int]] = {}
    for r in all_region_rows:
        try:
            key = (int(r["branching"]), int(r["max_level"]), str(r["mode"]), str(r["region_id"]))
            size_lookup[key] = (int(r.get("n_interior", 0)), int(r.get("n_boundary", 0)))
        except Exception:
            continue
    groups: DefaultDict[Tuple[int, str, int, str], List[dict]] = defaultdict(list)
    for r in all_entropy_rows:
        if r.get("entropy_kind") != "live_vs_sym" or int(r.get("ok", 0)) != 1:
            continue
        D = safe_float(r.get("D"), math.nan)
        if not math.isfinite(D) or D < -1e-10:
            continue
        key = (int(r["branching"]), str(r["mode"]), int(r["max_level"]), str(r["scheme"]))
        groups[key].append(r)
    out: List[dict] = []
    for key, rs in sorted(groups.items()):
        b, mode, L, scheme = key
        Ds = []
        per_boundary = []
        per_interior = []
        b_sizes = []
        i_sizes = []
        A = []
        relsk = []
        for r in rs:
            D = max(0.0, safe_float(r.get("D"), 0.0))
            skey = (int(r["branching"]), int(r["max_level"]), str(r["mode"]), str(r["region_id"]))
            n_int, n_bnd = size_lookup.get(skey, (0, 0))
            Ds.append(D)
            if n_bnd > 0:
                per_boundary.append(D / n_bnd)
                b_sizes.append(n_bnd)
            if n_int > 0:
                per_interior.append(D / n_int)
                i_sizes.append(n_int)
            A.append(safe_float(r.get("A_fro_lhs"), math.nan))
            relsk.append(safe_float(r.get("rel_skew_lhs"), math.nan))
        Darr = np.array(Ds, dtype=float)
        Aarr = np.array(A, dtype=float)
        good = np.isfinite(Aarr)
        corr = math.nan
        if len(Darr) >= 2 and np.sum(good) >= 2 and float(np.std(Darr[good])) > EPS and float(np.std(Aarr[good])) > EPS:
            corr = float(np.corrcoef(Darr[good], Aarr[good])[0, 1])
        sum_b = int(sum(b_sizes)) if b_sizes else 0
        sum_i = int(sum(i_sizes)) if i_sizes else 0
        D_sum = float(np.sum(Darr)) if len(Darr) else math.nan
        out.append({
            "branching": b,
            "mode": mode,
            "max_level": L,
            "scheme": scheme,
            "n_regions": len(rs),
            "D_sum": D_sum,
            "D_per_region": D_sum / max(len(rs), 1),
            "boundary_size_sum": sum_b,
            "interior_size_sum": sum_i,
            "D_per_boundary_size_sum": D_sum / max(sum_b, 1),
            "D_per_interior_size_sum": D_sum / max(sum_i, 1),
            "D_per_boundary_mean": float(np.mean(per_boundary)) if per_boundary else math.nan,
            "D_per_boundary_median": float(np.median(per_boundary)) if per_boundary else math.nan,
            "D_per_interior_mean": float(np.mean(per_interior)) if per_interior else math.nan,
            "D_per_interior_median": float(np.median(per_interior)) if per_interior else math.nan,
            "A_fro_mean": float(np.nanmean(Aarr)) if len(Aarr) else math.nan,
            "rel_skew_mean": float(np.nanmean(np.array(relsk, dtype=float))) if relsk else math.nan,
            "corr_D_A_fro": corr,
        })
    return out


def entropy_density_limes_rows(density_rows: Sequence[dict]) -> List[dict]:
    out: List[dict] = []
    by_key: DefaultDict[Tuple[int, str, str], List[dict]] = defaultdict(list)
    for r in density_rows:
        by_key[(int(r["branching"]), str(r["mode"]), str(r["scheme"]))].append(r)
    metrics = [
        "D_per_region",
        "D_per_boundary_size_sum",
        "D_per_interior_size_sum",
        "D_per_boundary_mean",
        "D_per_interior_mean",
        "rel_skew_mean",
        "corr_D_A_fro",
    ]
    for (b, mode, scheme), rs in sorted(by_key.items()):
        rs_sorted = sorted(rs, key=lambda x: int(x["max_level"]))
        for a, c in zip(rs_sorted, rs_sorted[1:]):
            L0 = int(a["max_level"]); L1 = int(c["max_level"])
            if L1 != L0 + 1:
                continue
            row = {"branching": b, "mode": mode, "scheme": scheme, "L0": L0, "L1": L1}
            for m in metrics:
                x0 = safe_float(a.get(m), math.nan)
                x1 = safe_float(c.get(m), math.nan)
                row[f"{m}_L0"] = x0
                row[f"{m}_L1"] = x1
                row[f"{m}_ratio_L1_over_L0"] = float(x1 / max(abs(x0), EPS)) if math.isfinite(x0) and math.isfinite(x1) else math.nan
                row[f"{m}_delta"] = float(x1 - x0) if math.isfinite(x0) and math.isfinite(x1) else math.nan
            out.append(row)
    return out


def mode_universality_rows(all_entropy_rows: Sequence[dict]) -> List[dict]:
    """TV distance between normalized entropic distributions across modes.

    Groups are scheme-level partitions.  For each b,L,scheme,level and mode pair,
    compare p_R ∝ D_R(live||sym) over the common region ids.
    """
    rows: List[dict] = []
    data: DefaultDict[Tuple[int, int, str, int, str], Dict[str, float]] = defaultdict(dict)
    for r in all_entropy_rows:
        if r.get("entropy_kind") != "live_vs_sym" or int(r.get("ok", 0)) != 1:
            continue
        D = safe_float(r.get("D"), math.nan)
        if not math.isfinite(D) or D < 0:
            continue
        key = (int(r["branching"]), int(r["max_level"]), str(r["scheme"]), int(r["level"]), str(r["region_id"]))
        data[key][str(r["mode"])] = max(0.0, D)
    by_group: DefaultDict[Tuple[int, int, str, int], Dict[str, Dict[str, float]]] = defaultdict(lambda: defaultdict(dict))
    for (b, L, scheme, level, rid), md in data.items():
        for mode, D in md.items():
            by_group[(b, L, scheme, level)][mode][rid] = D
    for (b, L, scheme, level), mode_map in sorted(by_group.items()):
        modes = sorted(mode_map)
        for i, m1 in enumerate(modes):
            for m2 in modes[i+1:]:
                ids = sorted(set(mode_map[m1]).intersection(mode_map[m2]))
                if len(ids) < 2:
                    continue
                v1 = np.array([mode_map[m1][rid] for rid in ids], dtype=float)
                v2 = np.array([mode_map[m2][rid] for rid in ids], dtype=float)
                s1 = float(np.sum(v1)); s2 = float(np.sum(v2))
                if s1 <= EPS or s2 <= EPS:
                    tv = math.nan
                    verdict = "invalid_zero_mass"
                else:
                    p1 = v1 / s1; p2 = v2 / s2
                    tv = float(0.5 * np.sum(np.abs(p1 - p2)))
                    verdict = "mode_universal_small" if tv <= 0.05 else ("mode_close" if tv <= 0.15 else "mode_dependent")
                rows.append({
                    "branching": b,
                    "max_level": L,
                    "scheme": scheme,
                    "region_level": level,
                    "mode_a": m1,
                    "mode_b": m2,
                    "n_common_regions": len(ids),
                    "D_sum_a": s1,
                    "D_sum_b": s2,
                    "tv_distance": tv,
                    "verdict": verdict,
                })
    return rows


def current_entropy_correlation_rows(all_entropy_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    groups: DefaultDict[Tuple[int, str, int, str], List[dict]] = defaultdict(list)
    for r in all_entropy_rows:
        if r.get("entropy_kind") == "live_vs_sym" and int(r.get("ok", 0)) == 1:
            groups[(int(r["branching"]), str(r["mode"]), int(r["max_level"]), str(r["scheme"]))].append(r)
    for (b, mode, L, scheme), rs in sorted(groups.items()):
        D = np.array([safe_float(r.get("D"), math.nan) for r in rs], dtype=float)
        A = np.array([safe_float(r.get("A_fro_lhs"), math.nan) for r in rs], dtype=float)
        rel = np.array([safe_float(r.get("rel_skew_lhs"), math.nan) for r in rs], dtype=float)
        goodA = np.isfinite(D) & np.isfinite(A)
        goodR = np.isfinite(D) & np.isfinite(rel)
        corrA = math.nan
        corrR = math.nan
        if np.sum(goodA) >= 3 and float(np.std(D[goodA])) > EPS and float(np.std(A[goodA])) > EPS:
            corrA = float(np.corrcoef(D[goodA], A[goodA])[0, 1])
        if np.sum(goodR) >= 3 and float(np.std(D[goodR])) > EPS and float(np.std(rel[goodR])) > EPS:
            corrR = float(np.corrcoef(D[goodR], rel[goodR])[0, 1])
        abs_corr = max(abs(corrA) if math.isfinite(corrA) else 0.0, abs(corrR) if math.isfinite(corrR) else 0.0)
        verdict = "correlated" if abs_corr >= 0.5 else ("weak_correlation" if abs_corr >= 0.2 else "uncorrelated_or_flat")
        rows.append({
            "branching": b,
            "mode": mode,
            "max_level": L,
            "scheme": scheme,
            "n_regions": len(rs),
            "corr_D_A_fro": corrA,
            "corr_D_rel_skew": corrR,
            "D_mean": float(np.nanmean(D)) if len(D) else math.nan,
            "A_fro_mean": float(np.nanmean(A)) if len(A) else math.nan,
            "rel_skew_mean": float(np.nanmean(rel)) if len(rel) else math.nan,
            "verdict": verdict,
        })
    return rows


def root_prefix_verification_rows(all_gate_r0_rows: Sequence[dict]) -> List[dict]:
    rows: List[dict] = []
    for r in all_gate_r0_rows:
        if str(r.get("scheme")) == "prefix" and str(r.get("word", "")) == "":
            rows.append({
                "branching": int(r["branching"]),
                "mode": str(r["mode"]),
                "max_level": int(r["max_level"]),
                "state": str(r["state"]),
                "region_id": str(r["region_id"]),
                "n_region_interior": int(r.get("n_region_interior", 0)),
                "n_region_boundary": int(r.get("n_region_boundary", 0)),
                "direct_ok": int(r.get("direct_ok", 0)),
                "direct_error": str(r.get("direct_error", "")),
                "cond_KII": safe_float(r.get("cond_KII"), math.nan),
                "solve_residual": safe_float(r.get("solve_residual"), math.nan),
                "verdict": str(r.get("verdict", "")),
            })
    return rows


def v11_2_verdict_rows(base_verdicts: Sequence[dict], density_rows: Sequence[dict], mode_rows: Sequence[dict], corr_rows: Sequence[dict]) -> List[dict]:
    out: List[dict] = []
    # Summarize hardening diagnostics per b,L,mode.
    dens_by_key: DefaultDict[Tuple[int, str, int], List[dict]] = defaultdict(list)
    for r in density_rows:
        dens_by_key[(int(r["branching"]), str(r["mode"]), int(r["max_level"]))].append(r)
    corr_by_key: DefaultDict[Tuple[int, str, int], List[dict]] = defaultdict(list)
    for r in corr_rows:
        corr_by_key[(int(r["branching"]), str(r["mode"]), int(r["max_level"]))].append(r)
    mode_by_bl: DefaultDict[Tuple[int, int], List[dict]] = defaultdict(list)
    for r in mode_rows:
        mode_by_bl[(int(r["branching"]), int(r["max_level"]))].append(r)
    for r in base_verdicts:
        b = int(r["branching"]); mode = str(r["mode"]); L = int(r["max_level"])
        dens = dens_by_key.get((b, mode, L), [])
        corr = corr_by_key.get((b, mode, L), [])
        modes = mode_by_bl.get((b, L), [])
        tv_vals = [safe_float(x.get("tv_distance"), math.nan) for x in modes if math.isfinite(safe_float(x.get("tv_distance"), math.nan))]
        max_tv = float(np.max(tv_vals)) if tv_vals else math.nan
        med_tv = float(np.median(tv_vals)) if tv_vals else math.nan
        corr_vals = []
        for x in corr:
            for c in [safe_float(x.get("corr_D_A_fro"), math.nan), safe_float(x.get("corr_D_rel_skew"), math.nan)]:
                if math.isfinite(c): corr_vals.append(abs(c))
        max_abs_corr = float(np.max(corr_vals)) if corr_vals else math.nan
        density_ok = any(math.isfinite(safe_float(x.get("D_per_boundary_size_sum"), math.nan)) for x in dens)
        base_v = str(r.get("verdict", ""))
        if base_v != "direct_regional_entropic_candidate":
            verdict = base_v
        elif density_ok and (not math.isfinite(max_tv) or max_tv <= 0.25):
            verdict = "v11_2_limes_hardened_candidate"
        elif density_ok:
            verdict = "v11_2_entropic_candidate_mode_dependent"
        else:
            verdict = "v11_2_finite_candidate_density_incomplete"
        row = dict(r)
        row.update({
            "mode_universality_tv_median_all_pairs": med_tv,
            "mode_universality_tv_max_all_pairs": max_tv,
            "max_abs_current_entropy_corr": max_abs_corr,
            "density_rows_available": len(dens),
            "v11_2_verdict": verdict,
        })
        out.append(row)
    return out

def combined_verdict_rows(all_gate_r0_rows: Sequence[dict], all_entropy_rows: Sequence[dict], all_projectivity_rows: Sequence[dict]) -> List[dict]:
    out: List[dict] = []
    keys = sorted({(int(r["branching"]), str(r["mode"]), int(r["max_level"])) for r in list(all_gate_r0_rows) + list(all_entropy_rows)})
    for b, mode, L in keys:
        gate = [r for r in all_gate_r0_rows if int(r["branching"]) == b and str(r["mode"]) == mode and int(r["max_level"]) == L]
        ent = [r for r in all_entropy_rows if int(r["branching"]) == b and str(r["mode"]) == mode and int(r["max_level"]) == L and r.get("entropy_kind") == "live_vs_sym"]
        proj = [r for r in all_projectivity_rows if int(r["branching"]) == b and str(r["mode"]) == mode and int(r["max_level"]) == L]
        attempted = [r for r in gate if r.get("verdict") != "skipped"]
        direct_pass_frac = sum(1 for r in attempted if r.get("verdict") in {"pass", "warn_condition", "warn_solve_residual"}) / max(len(attempted), 1)
        direct_fail_frac = sum(1 for r in attempted if r.get("verdict") == "fail") / max(len(attempted), 1)
        skipped_frac = sum(1 for r in gate if r.get("verdict") == "skipped") / max(len(gate), 1)
        valid_ent = [r for r in ent if int(r.get("ok", 0)) == 1 and math.isfinite(safe_float(r.get("D")))]
        nonzero_ent_frac = sum(1 for r in valid_ent if safe_float(r.get("D"), 0.0) > 1e-10) / max(len(valid_ent), 1)
        proj_vals = [safe_float(r.get("delta_D_projective"), math.nan) for r in proj]
        proj_median = float(np.nanmedian(proj_vals)) if proj_vals else math.nan
        if direct_pass_frac < 0.5:
            verdict = "direct_regional_schur_incomplete"
        elif nonzero_ent_frac > 0.25:
            verdict = "direct_regional_entropic_candidate"
        elif len(valid_ent) > 0:
            verdict = "direct_regional_finite_control_only"
        else:
            verdict = "finite_diagnostic_only"
        out.append({
            "branching": b,
            "mode": mode,
            "max_level": L,
            "n_R0_rows": len(gate),
            "n_R0_attempted": len(attempted),
            "R0_direct_pass_fraction": direct_pass_frac,
            "R0_direct_fail_fraction": direct_fail_frac,
            "R0_skipped_fraction": skipped_frac,
            "n_live_vs_sym_entropy_rows": len(ent),
            "n_valid_live_vs_sym_entropy_rows": len(valid_ent),
            "nonzero_entropy_fraction": nonzero_ent_frac,
            "prefix_projectivity_median_delta": proj_median,
            "verdict": verdict,
        })
    return out


# -----------------------------------------------------------------------------
# IO helpers
# -----------------------------------------------------------------------------

def write_csv(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def write_summary(outdir: Path, args: argparse.Namespace, verdicts: Sequence[dict], limes_rows: Sequence[dict]) -> None:
    lines: List[str] = []
    lines.append("# CNNA v11.2 — Direct Regional Schur/Kron Complement Network")
    lines.append("")
    lines.append("## Scope")
    lines.append("v11.2 uses direct regional Schur/Kron-DtN from the finite dynamic graph as the main path. The v9/v10.2 local shell-DtN construction remains the smallest local response observable and diagnostic layer. Nodes/words remain provenance indices; regional responses, relative entropies and skew currents are the tested observables.")
    lines.append("")
    lines.append("## Configuration")
    lines.append(f"- branchings: `{args.branching}`")
    lines.append(f"- levels: `{args.levels_resolved}`")
    lines.append(f"- modes: `{args.modes}`")
    lines.append(f"- region schemes: `{args.region_schemes}`")
    lines.append(f"- symmetric reference: `{args.sym_reference}`")
    lines.append(f"- max direct Schur interior: `{args.max_direct_interior}`")
    lines.append("")
    lines.append("## Output files")
    for name in [
        "v11_nodes.csv",
        "v11_events.csv",
        "v11_shell_dtn_summary.csv",
        "v11_regions.csv",
        "v11_region_dtn_summary.csv",
        "gate_R0_direct_regional_schur_validity.csv",
        "gate_C0_optional_shell_composition.csv",
        "v11_region_entropy.csv",
        "v11_entropic_projectivity.csv",
        "v11_scaling_summary.csv",
        "v11_limes_scaling.csv",
        "v11_2_entropy_density_summary.csv",
        "v11_2_entropy_density_limes.csv",
        "v11_2_mode_universality.csv",
        "v11_2_current_entropy_correlation.csv",
        "v11_2_root_prefix_verification.csv",
        "v11_2_combined_verdicts.csv",
    ]:
        lines.append(f"- `{name}`")
    lines.append("")
    lines.append("## Verdict overview")
    if verdicts:
        for r in verdicts:
            lines.append(
                f"- b={r['branching']}, L={r['max_level']}, mode={r['mode']}: "
                f"{r.get('v11_2_verdict', r.get('verdict'))} | base={r.get('verdict')} | "
                f"R0 direct pass={safe_float(r.get('R0_direct_pass_fraction'), 0):.3g}, "
                f"nonzero entropy={safe_float(r.get('nonzero_entropy_fraction'), 0):.3g}, "
                f"max TV={safe_float(r.get('mode_universality_tv_max_all_pairs'), math.nan):.3g}"
            )
    else:
        lines.append("No verdict rows generated.")
    lines.append("")
    lines.append("## Interpretation guardrails")
    lines.append("- A uniform/count provenance carrier is not a failure; it is a control carrier.")
    lines.append("- Relative entropy is reported first as an information functional, not automatically as a measure.")
    lines.append("- A_R/J_R remains a separate skew-current layer and is never used to define rho_R.")
    lines.append("- Type-III/vN language is only a limes motivation here; v11.2 reports finite indicators only.")
    lines.append("")
    if limes_rows:
        lines.append("## L-to-L+1 scaling rows")
        for r in limes_rows[:30]:
            lines.append(
                f"- b={r['branching']}, mode={r['mode']}, scheme={r['scheme']}, "
                f"L {r['L0']}→{r['L1']}: D_sum ratio={safe_float(r.get('D_sum_ratio_L1_over_L0'), math.nan):.6g}, "
                f"rel_skew_delta={safe_float(r.get('rel_skew_delta'), math.nan):.6g}"
            )
    (outdir / "SUMMARY_v11_2.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    results = [
        "# RESULTS — CNNA v11.2 finite diagnostic",
        "",
        "This run is a finite diagnostic of the direct regional Schur/Kron complement network. It does not claim an infinite algebraic limit; it prepares and tests finite scaling indicators.",
        "",
        "Core result categories:",
        "- R0 tests whether direct regional Schur/Kron responses are valid. C0 is optional and diagnostic only; it tests naive shell-composition against direct Schur reduction when enabled.",
        "- Entropy rows test finite relative response information live||sym, live||record, record||sym and record||live.",
        "- Projectivity rows test whether live||sym relative entropy can become an entropic measure candidate on prefix partitions.",
        "- Scaling rows compare finite complement networks C_{b,L} across L.",
        "",
        "See `v11_2_combined_verdicts.csv` for machine-readable verdicts.",
    ]
    (outdir / "RESULTS_v11_2.md").write_text("\n".join(results) + "\n", encoding="utf-8")


def copy_self_and_docs(outdir: Path) -> None:
    script_path = Path(__file__).resolve()
    target = outdir / script_path.name
    if script_path != target:
        shutil.copy2(script_path, target)


# -----------------------------------------------------------------------------
# Main driver
# -----------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CNNA v11.2 direct regional Schur/Kron complement network limes-hardening diagnostic")
    p.add_argument("--branching", type=int, nargs="+", default=[3, 4], help="branching values; v11.2 default keeps b={3,4}")
    p.add_argument("--min-level", type=int, default=3, help="minimum complete tree depth for scaling runs")
    p.add_argument("--max-level", type=int, default=4, help="maximum complete tree depth for scaling runs")
    p.add_argument("--levels", type=int, nargs="*", default=None, help="explicit levels; overrides min/max if given")
    p.add_argument("--modes", nargs="+", default=["linear", "log", "saturating"], choices=["linear", "log", "saturating"])
    p.add_argument("--region-schemes", nargs="+", default=["shell", "prefix", "sibling", "ancestor", "bulk"], choices=["shell", "prefix", "sibling", "ancestor", "bulk"])
    p.add_argument("--cap-root", type=int, nargs="+", default=[0, 1, 2, 3], help="root cap widths for bulk regions; v11.2 default is denser")
    p.add_argument("--cap-front", type=int, nargs="+", default=[1, 2, 3], help="front cap widths for bulk regions; v11.2 default is denser")
    p.add_argument("--sym-reference", default="level_mean", choices=["level_mean", "uniform", "birth_sym"], help="fully symmetric reference anchor")
    p.add_argument("--max-regions-per-scheme", type=int, default=400, help="deterministic cap per region scheme and run")
    p.add_argument("--max-direct-interior", type=int, default=800, help="skip direct Schur for larger interiors; optional comp can still run if enabled")
    p.add_argument("--max-root-prefix-interior", type=int, default=None, help="optional higher direct Schur interior cap only for the root prefix region; use for b=4,L=6 root-prefix verification")
    p.add_argument("--enable-shell-composition", action="store_true", help="enable optional naive shell-DtN composition and C0 comparison; disabled by default in v11.2")
    p.add_argument("--entropy-eps", type=float, default=1e-10, help="relative spectral floor for finite rho_R construction")
    p.add_argument("--ancestor-kernel", default="shell_norm_inverse_square", choices=["inverse_square", "shell_norm_inverse_square"])
    p.add_argument("--live-relation-target-scale", default="current_g", choices=["current_g", "birth_g"])
    p.add_argument("--outdir", type=str, default="csv_outputs_v11_2_limes_hardening")
    p.add_argument("--no-copy-script", action="store_true", help="do not copy script into output directory")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if args.levels:
        levels = sorted(set(int(x) for x in args.levels))
    else:
        levels = list(range(int(args.min_level), int(args.max_level) + 1))
    if not levels:
        raise SystemExit("no levels selected")
    args.levels_resolved = levels

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    all_nodes: List[dict] = []
    all_events: List[dict] = []
    all_shell_rows: List[dict] = []
    all_region_rows: List[dict] = []
    all_region_metric_rows: List[dict] = []
    all_gate_r0_rows: List[dict] = []
    all_gate_c0_rows: List[dict] = []
    all_entropy_rows: List[dict] = []
    all_projectivity_rows: List[dict] = []

    for b in args.branching:
        if b not in (3, 4):
            raise SystemExit("This v11 package is intentionally restricted to b in {3,4}.")
        for L in levels:
            for mode in args.modes:
                model = DynamicBirthProvenanceModel(
                    mode=mode,
                    branching=b,
                    ancestor_kernel=args.ancestor_kernel,
                    live_relation_target_scale=args.live_relation_target_scale,
                )
                model.run_growth(L)
                K_by_state = {
                    "live": model.build_live_laplacian(),
                    "record": model.build_record_laplacian(),
                    "sym": model.build_symmetric_reference_laplacian(args.sym_reference),
                }
                shell_by_state = {state: compute_shells_for_state(model, K, state, L) for state, K in K_by_state.items()}
                regions = build_regions(
                    model,
                    max_level=L,
                    schemes=args.region_schemes,
                    cap_roots=args.cap_root,
                    cap_fronts=args.cap_front,
                    max_regions_per_scheme=args.max_regions_per_scheme,
                )

                for r in model.address_rows():
                    row = {"branching": b, "max_level": L, "mode": mode}
                    row.update(r)
                    all_nodes.append(row)
                for ev in model.event_rows:
                    row = {"max_level": L}
                    row.update(ev)
                    all_events.append(row)
                all_shell_rows.extend(compute_shell_rows(model, shell_by_state, b, L, mode))
                region_rows, region_metric_rows, gate_r0_rows, gate_c0_rows, entropy_rows = build_response_and_entropy_rows(
                    model=model,
                    b=b,
                    L=L,
                    mode=mode,
                    regions=regions,
                    K_by_state=K_by_state,
                    shell_by_state=shell_by_state,
                    entropy_eps=args.entropy_eps,
                    max_direct_interior=args.max_direct_interior,
                    enable_shell_composition=args.enable_shell_composition,
                    max_root_prefix_interior=args.max_root_prefix_interior,
                )
                all_region_rows.extend(region_rows)
                all_region_metric_rows.extend(region_metric_rows)
                all_gate_r0_rows.extend(gate_r0_rows)
                all_gate_c0_rows.extend(gate_c0_rows)
                all_entropy_rows.extend(entropy_rows)
                all_projectivity_rows.extend(entropic_projectivity_rows(entropy_rows, b, L, mode))
                print(
                    f"[v11.2] completed b={b} L={L} mode={mode}: "
                    f"nodes={len(model.nodes)} regions={len(regions)} shells={sum(len(x) for x in shell_by_state.values())}",
                    flush=True,
                )

    scaling_summary, limes_rows = aggregate_scaling_rows(all_entropy_rows, all_gate_c0_rows, all_region_metric_rows)
    density_rows = entropy_density_summary_rows(all_entropy_rows, all_region_rows)
    density_limes_rows = entropy_density_limes_rows(density_rows)
    mode_universality = mode_universality_rows(all_entropy_rows)
    current_entropy_corr = current_entropy_correlation_rows(all_entropy_rows)
    root_prefix_rows = root_prefix_verification_rows(all_gate_r0_rows)
    verdicts_base = combined_verdict_rows(all_gate_r0_rows, all_entropy_rows, all_projectivity_rows)
    verdicts = v11_2_verdict_rows(verdicts_base, density_rows, mode_universality, current_entropy_corr)

    write_csv(outdir / "v11_nodes.csv", all_nodes)
    write_csv(outdir / "v11_events.csv", all_events)
    write_csv(outdir / "v11_shell_dtn_summary.csv", all_shell_rows)
    write_csv(outdir / "v11_regions.csv", all_region_rows)
    write_csv(outdir / "v11_region_dtn_summary.csv", all_region_metric_rows)
    write_csv(outdir / "gate_R0_direct_regional_schur_validity.csv", all_gate_r0_rows)
    write_csv(outdir / "gate_C0_optional_shell_composition.csv", all_gate_c0_rows)
    write_csv(outdir / "v11_region_entropy.csv", all_entropy_rows)
    write_csv(outdir / "v11_entropic_projectivity.csv", all_projectivity_rows)
    write_csv(outdir / "v11_scaling_summary.csv", scaling_summary)
    write_csv(outdir / "v11_limes_scaling.csv", limes_rows)
    write_csv(outdir / "v11_2_entropy_density_summary.csv", density_rows)
    write_csv(outdir / "v11_2_entropy_density_limes.csv", density_limes_rows)
    write_csv(outdir / "v11_2_mode_universality.csv", mode_universality)
    write_csv(outdir / "v11_2_current_entropy_correlation.csv", current_entropy_corr)
    write_csv(outdir / "v11_2_root_prefix_verification.csv", root_prefix_rows)
    write_csv(outdir / "v11_2_combined_verdicts.csv", verdicts)

    if not args.no_copy_script:
        copy_self_and_docs(outdir)
    write_summary(outdir, args, verdicts, limes_rows)
    print(f"[v11.2] wrote output to {outdir}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
