# RESULTS — CNNA v11.2 finite diagnostic

This run is a finite diagnostic of the direct regional Schur/Kron complement network. It does not claim an infinite algebraic limit; it prepares and tests finite scaling indicators.

Core result categories:
- R0 tests whether direct regional Schur/Kron responses are valid. C0 is optional and diagnostic only; it tests naive shell-composition against direct Schur reduction when enabled.
- Entropy rows test finite relative response information live||sym, live||record, record||sym and record||live.
- Projectivity rows test whether live||sym relative entropy can become an entropic measure candidate on prefix partitions.
- Scaling rows compare finite complement networks C_{b,L} across L.

See `v11_2_combined_verdicts.csv` for machine-readable verdicts.
