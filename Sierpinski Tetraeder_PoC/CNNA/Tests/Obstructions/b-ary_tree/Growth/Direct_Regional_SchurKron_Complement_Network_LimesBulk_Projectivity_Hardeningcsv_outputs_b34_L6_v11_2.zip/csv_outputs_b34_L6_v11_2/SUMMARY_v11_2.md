# CNNA v11.2 — Direct Regional Schur/Kron Complement Network

## Scope
v11.2 uses direct regional Schur/Kron-DtN from the finite dynamic graph as the main path. The v9/v10.2 local shell-DtN construction remains the smallest local response observable and diagnostic layer. Nodes/words remain provenance indices; regional responses, relative entropies and skew currents are the tested observables.

## Configuration
- branchings: `[3, 4]`
- levels: `[3, 4, 5, 6]`
- modes: `['linear', 'log', 'saturating']`
- region schemes: `['shell', 'prefix', 'sibling', 'ancestor', 'bulk']`
- symmetric reference: `level_mean`
- max direct Schur interior: `800`

## Output files
- `v11_nodes.csv`
- `v11_events.csv`
- `v11_shell_dtn_summary.csv`
- `v11_regions.csv`
- `v11_region_dtn_summary.csv`
- `gate_R0_direct_regional_schur_validity.csv`
- `gate_C0_optional_shell_composition.csv`
- `v11_region_entropy.csv`
- `v11_entropic_projectivity.csv`
- `v11_scaling_summary.csv`
- `v11_limes_scaling.csv`
- `v11_2_entropy_density_summary.csv`
- `v11_2_entropy_density_limes.csv`
- `v11_2_mode_universality.csv`
- `v11_2_current_entropy_correlation.csv`
- `v11_2_root_prefix_verification.csv`
- `v11_2_combined_verdicts.csv`

## Verdict overview
- b=3, L=3, mode=linear: v11_2_limes_hardened_candidate | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.186
- b=3, L=4, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.279
- b=3, L=5, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.339
- b=3, L=6, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.38
- b=3, L=3, mode=log: v11_2_limes_hardened_candidate | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.186
- b=3, L=4, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.279
- b=3, L=5, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.339
- b=3, L=6, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.38
- b=3, L=3, mode=saturating: v11_2_limes_hardened_candidate | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.186
- b=3, L=4, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.279
- b=3, L=5, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.339
- b=3, L=6, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.38
- b=4, L=3, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.396
- b=4, L=4, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.486
- b=4, L=5, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.477
- b=4, L=6, mode=linear: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.441
- b=4, L=3, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.396
- b=4, L=4, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.486
- b=4, L=5, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.477
- b=4, L=6, mode=log: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.441
- b=4, L=3, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.396
- b=4, L=4, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.486
- b=4, L=5, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.477
- b=4, L=6, mode=saturating: v11_2_entropic_candidate_mode_dependent | base=direct_regional_entropic_candidate | R0 direct pass=1, nonzero entropy=1, max TV=0.441

## Interpretation guardrails
- A uniform/count provenance carrier is not a failure; it is a control carrier.
- Relative entropy is reported first as an information functional, not automatically as a measure.
- A_R/J_R remains a separate skew-current layer and is never used to define rho_R.
- Type-III/vN language is only a limes motivation here; v11.2 reports finite indicators only.

## L-to-L+1 scaling rows
- b=3, mode=linear, scheme=ancestor, L 3→4: D_sum ratio=6.97529, rel_skew_delta=-0.0193846
- b=3, mode=linear, scheme=ancestor, L 4→5: D_sum ratio=4.96025, rel_skew_delta=-0.0106091
- b=3, mode=linear, scheme=ancestor, L 5→6: D_sum ratio=4.236, rel_skew_delta=-0.00631535
- b=3, mode=linear, scheme=bulk, L 3→4: D_sum ratio=3.26841, rel_skew_delta=-0.0217655
- b=3, mode=linear, scheme=bulk, L 4→5: D_sum ratio=1.90131, rel_skew_delta=-0.0133476
- b=3, mode=linear, scheme=bulk, L 5→6: D_sum ratio=1.46344, rel_skew_delta=-0.00653708
- b=3, mode=linear, scheme=prefix, L 3→4: D_sum ratio=3.9117, rel_skew_delta=-0.00843573
- b=3, mode=linear, scheme=prefix, L 4→5: D_sum ratio=3.19256, rel_skew_delta=-0.00372604
- b=3, mode=linear, scheme=prefix, L 5→6: D_sum ratio=3.03983, rel_skew_delta=-0.0020862
- b=3, mode=linear, scheme=shell, L 3→4: D_sum ratio=3.766, rel_skew_delta=-0.00669274
- b=3, mode=linear, scheme=shell, L 4→5: D_sum ratio=3.10239, rel_skew_delta=-0.00311289
- b=3, mode=linear, scheme=shell, L 5→6: D_sum ratio=3.0227, rel_skew_delta=-0.00181382
- b=3, mode=linear, scheme=sibling, L 3→4: D_sum ratio=3.45294, rel_skew_delta=-0.0136193
- b=3, mode=linear, scheme=sibling, L 4→5: D_sum ratio=3.05244, rel_skew_delta=-0.00608525
- b=3, mode=linear, scheme=sibling, L 5→6: D_sum ratio=3.01657, rel_skew_delta=-0.00319664
- b=3, mode=log, scheme=ancestor, L 3→4: D_sum ratio=6.76866, rel_skew_delta=-0.0189305
- b=3, mode=log, scheme=ancestor, L 4→5: D_sum ratio=4.82067, rel_skew_delta=-0.0101835
- b=3, mode=log, scheme=ancestor, L 5→6: D_sum ratio=4.14872, rel_skew_delta=-0.00592885
- b=3, mode=log, scheme=bulk, L 3→4: D_sum ratio=3.22854, rel_skew_delta=-0.0257711
- b=3, mode=log, scheme=bulk, L 4→5: D_sum ratio=1.89338, rel_skew_delta=-0.0153975
- b=3, mode=log, scheme=bulk, L 5→6: D_sum ratio=1.44564, rel_skew_delta=-0.00772596
- b=3, mode=log, scheme=prefix, L 3→4: D_sum ratio=3.57952, rel_skew_delta=-0.00775262
- b=3, mode=log, scheme=prefix, L 4→5: D_sum ratio=3.04995, rel_skew_delta=-0.00298782
- b=3, mode=log, scheme=prefix, L 5→6: D_sum ratio=2.94123, rel_skew_delta=-0.00137587
- b=3, mode=log, scheme=shell, L 3→4: D_sum ratio=3.32788, rel_skew_delta=-0.00641707
- b=3, mode=log, scheme=shell, L 4→5: D_sum ratio=2.94438, rel_skew_delta=-0.00274169
- b=3, mode=log, scheme=shell, L 5→6: D_sum ratio=2.92786, rel_skew_delta=-0.00141016
- b=3, mode=log, scheme=sibling, L 3→4: D_sum ratio=3.13001, rel_skew_delta=-0.0151768
- b=3, mode=log, scheme=sibling, L 4→5: D_sum ratio=2.8875, rel_skew_delta=-0.00669751
- b=3, mode=log, scheme=sibling, L 5→6: D_sum ratio=2.90504, rel_skew_delta=-0.00332012
