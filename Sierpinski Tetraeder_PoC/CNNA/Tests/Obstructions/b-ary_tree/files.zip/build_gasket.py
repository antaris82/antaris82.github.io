import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components

# ---------------------------------------------------------------
# Sierpinski Gasket graph, generation n.
# Standard construction: start with a triangle (3 nodes, 3 edges).
# Each generation: replace every "upward" triangle by 3 sub-triangles
# sharing the midpoints. The graph at generation n has:
#   V = 3*(3^n + 1)/2 nodes,  E = 3^{n+1} edges,
#   b1 = E - V + 1.
# We build it by coordinate-based midpoint subdivision and dedup nodes.
# ---------------------------------------------------------------
def build_gasket(n):
    # represent points in a triangular lattice using integer barycentric-ish coords
    # via repeated subdivision; dedup by rounded coordinates.
    import itertools
    # initial triangle vertices
    V0 = [np.array([0.0,0.0]), np.array([1.0,0.0]), np.array([0.5, np.sqrt(3)/2])]
    triangles = [tuple(range(3))]
    coords = list(V0)
    def get_id(p, table, coords, tol=1e-9):
        key = (round(p[0]/tol), round(p[1]/tol))
        if key in table: return table[key]
        idx = len(coords); coords.append(p); table[key]=idx; return idx
    table = {}
    for i,p in enumerate(V0):
        key=(round(p[0]/1e-9), round(p[1]/1e-9)); table[key]=i
    for gen in range(n):
        new_tris=[]
        for (a,b,c) in triangles:
            pa,pb,pc = coords[a],coords[b],coords[c]
            mab=(pa+pb)/2; mbc=(pb+pc)/2; mca=(pc+pa)/2
            iab=get_id(mab,table,coords); ibc=get_id(mbc,table,coords); ica=get_id(mca,table,coords)
            # three corner sub-triangles (the middle one is the "hole")
            new_tris += [(a,iab,ica),(iab,b,ibc),(ica,ibc,c)]
        triangles=new_tris
    # edges = union of triangle edges
    edge_set=set()
    for (a,b,c) in triangles:
        for (u,v) in [(a,b),(b,c),(c,a)]:
            edge_set.add((min(u,v),max(u,v)))
    N=len(coords); edges=list(edge_set)
    return N, edges, coords

def cycle_rank(N, edges):
    E=len(edges)
    rows=[];cols=[]
    for (u,v) in edges:
        rows+=[u,v];cols+=[v,u]
    A=sp.coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(N,N))
    ncc,_=connected_components(A,directed=False)
    return E-N+ncc,E,N,ncc

for n in [1,2,3,4,5]:
    N,edges,coords=build_gasket(n)
    b1,E,V,ncc=cycle_rank(N,edges)
    Vpred = 3*(3**n+1)//2
    Epred = 3**(n+1)
    print(f"GASKET n={n}: V={V}(pred {Vpred}) E={E}(pred {Epred}) cc={ncc} b1={b1}")
