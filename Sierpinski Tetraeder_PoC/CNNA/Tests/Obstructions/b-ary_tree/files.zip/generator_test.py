import numpy as np
import scipy.sparse as sp
exec(open('build_structures.py').read().split('for D in')[0])  # tree builders
exec(open('build_gasket.py').read().split('for n in')[0])       # gasket builders

np.set_printoptions(precision=4, suppress=True, linewidth=120)

def make_L_tree(b,D):
    N,edges = build_tree(b,D)
    L = laplacian_from_edges(N,edges).toarray()
    return N, L

def make_L_gasket(n):
    N,edges,coords = build_gasket(n)
    L = laplacian_from_edges(N,edges).toarray()
    return N, L

def analyze(name, L):
    N = L.shape[0]
    # dynamical generator A = [[0, I],[-L, 0]] on R^{2N}
    I = np.eye(N)
    Z = np.zeros((N,N))
    A = np.block([[Z, I],[-L, Z]])
    # spectrum of A: should be +/- i*sqrt(lambda_k)
    evА = np.linalg.eigvals(A)
    # eigenvalues of L (real symmetric, >=0)
    lamL = np.linalg.eigvalsh(L)
    lamL_clipped = np.clip(lamL, 0, None)
    pred = np.sort(np.concatenate([1j*np.sqrt(lamL_clipped), -1j*np.sqrt(lamL_clipped)]))
    got = np.sort_complex(evА)
    max_real = np.max(np.abs(evА.real))
    # zero modes of L (constant vector for connected graph -> 1 zero eigenvalue)
    nzero = np.sum(lamL < 1e-9)
    print(f"  {name}: N={N}  #zero-modes(L)={nzero}  max|Re(eig A)|={max_real:.2e}")
    return A, L, lamL

# ---- kappa-resistance test ----
# A real => A = conj(A). Define J via polar/sign of A on the non-kernel part.
# The question: is there a canonical J with J^2=-I commuting with dynamics,
# distinguishable from -J under complex conjugation kappa?
# Operationally: build J = A |A|^{-1} (sign of the skew operator) on range,
# then test whether kappa(J) = -J (conjugation flips it) and whether anything
# in the REAL structure singles out +J over -J.
def kappa_test(name, A, L):
    N = L.shape[0]
    # work on the L>0 subspace (drop kernel of L to avoid the static zero mode)
    lam, U = np.linalg.eigh(L)
    pos = lam > 1e-9
    lam_p = lam[pos]; Up = U[:,pos]
    k = lam_p.size
    # On each 2D block (q_i,p_i) for mode i, A acts as [[0,1],[-lam_i,0]].
    # Rescale p -> p/sqrt(lam_i) to get [[0, sqrt(lam_i)],[-sqrt(lam_i),0]] = sqrt(lam_i)*Jblock
    # Jblock = [[0,1],[-1,0]], Jblock^2 = -I.  This is the canonical complex structure.
    # kappa (complex conj in the eigenbasis): the generator is REAL, so both +Jblock
    # and -Jblock are equally compatible. Test explicitly:
    Jb = np.array([[0.,1.],[-1.,0.]])
    # Is +Jb distinguished from -Jb by any real invariant of the block? 
    # Real-orthogonal conjugation by diag(1,-1) maps Jb -> -Jb:
    S = np.array([[1.,0.],[0.,-1.]])
    flipped = S@Jb@np.linalg.inv(S)
    distinguishable = not np.allclose(flipped, Jb)  # if a real orthogonal S flips it, NOT canonical
    print(f"  {name}: #dynamical modes k={k}  "
          f"real-orthogonal S=diag(1,-1) maps J -> {'-J (kappa-blind: sign NOT canonical)' if np.allclose(flipped,-Jb) else 'other'}")
    return k

print("=== TREE b=3 ===")
for D in [3,6]:
    N,L = make_L_tree(3,D)
    A,L,lam = analyze(f"tree D={D}", L)
    kappa_test(f"tree D={D}", A, L)

print("=== GASKET b=3 ===")
for n in [3,6]:
    N,L = make_L_gasket(n)
    A,L,lam = analyze(f"gasket n={n}", L)
    kappa_test(f"gasket n={n}", A, L)
