import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components

# ---------------------------------------------------------------
# Structure 1: b-ary tree (b=3) up to depth D, with root.
# Nodes: level 0 = root (1 node), level k has b^k nodes.
# Edges: each non-leaf node connects to its b children, weight 1.
# b_1 (cycle rank) of a tree = 0 by construction (E = V-1, connected).
# ---------------------------------------------------------------
def build_tree(b, D):
    # node indexing: BFS order. node 0 = root.
    nodes = []
    # level lists
    levels = [[0]]
    counter = 1
    for k in range(1, D+1):
        lvl = list(range(counter, counter + b**k))
        counter += b**k
        levels.append(lvl)
    N = counter
    edges = []
    for k in range(D):
        for i, parent in enumerate(levels[k]):
            for c in range(b):
                child = levels[k+1][i*b + c]
                edges.append((parent, child))
    return N, edges

def laplacian_from_edges(N, edges, w=1.0):
    rows=[]; cols=[]; vals=[]
    deg = np.zeros(N)
    for (u,v) in edges:
        rows += [u,v]; cols += [v,u]; vals += [-w,-w]
        deg[u]+=w; deg[v]+=w
    A = sp.coo_matrix((vals,(rows,cols)), shape=(N,N)).tocsr()
    L = sp.diags(deg) + A   # since off-diagonals are -w, L = D - W
    return L.tocsr()

def cycle_rank(N, edges):
    # b_1 = E - V + (#connected components)
    E = len(edges)
    # build adjacency for cc
    if E==0:
        ncc = N
    else:
        rows=[]; cols=[]
        for (u,v) in edges:
            rows+=[u,v]; cols+=[v,u]
        A = sp.coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(N,N))
        ncc,_ = connected_components(A, directed=False)
    return E - N + ncc, E, N, ncc

for D in [3,6,9]:
    N, edges = build_tree(3, D)
    b1,E,V,ncc = cycle_rank(N, edges)
    print(f"TREE b=3 D={D}: V={V} E={E} components={ncc} b1={b1}")
