import numpy as np
import scipy.sparse as sp
exec(open('build_structures.py').read().split('for D in')[0])
exec(open('build_gasket.py').read().split('for n in')[0])
np.set_printoptions(precision=4, suppress=True, linewidth=130)

# ---------- oriented incidence / cycle space machinery ----------
def oriented_incidence(N, edges):
    """B: N x E oriented incidence (edge u->v gives +1 at u? use -1 at tail,+1 at head)."""
    E=len(edges)
    B=np.zeros((N,E))
    for j,(u,v) in enumerate(edges):
        B[u,j]=-1.0; B[v,j]=+1.0
    return B

def cycle_space_basis(N, edges):
    """Kernel of B (E x ... ) = cycle space, dimension b1. Returns E x b1 matrix Z."""
    B=oriented_incidence(N,edges)            # N x E
    # cycle space = null space of B (vectors on edges with zero boundary)
    u,s,vt=np.linalg.svd(B)
    tol=1e-9
    rank=np.sum(s>tol)
    ns=vt[rank:].T.conj()                    # E x (E-rank) ; E-rank = b1
    return ns, B

# =====================================================================
# TEST 1 (GEOMETRY): planar intersection form on H_1.
# For a planar graph, the cycle space carries a natural skew form given by
# signed area / linking of the embedded cycles. We build the face-based
# skew form: orient each bounded face CCW (using coords), express faces in
# the edge basis, and compute the antisymmetric "intersection" J_geo from
# the planar embedding. Question: does it give a canonical J (J^2=-I after
# normalization) that is NOT flippable by a real orthogonal change of cycle
# basis -- i.e. does the PLANE orientation fix the sign?
# =====================================================================
def test1_geometry(name, N, edges, coords):
    Z,B = cycle_space_basis(N,edges)
    b1 = Z.shape[1]
    if b1==0:
        print(f"  [GEO] {name}: b1=0  -> no cycle space, geometry test VACUOUS (tree cannot carry J)")
        return
    coords=np.array(coords)
    # signed area form on edges: for edge (u,v) assign the 2-form x dy contribution
    # omega_edge(j) acting as discrete 1-form; the area of a cycle c is sum_j c_j * (x_u*y_v - x_v*y_u)/2
    area_w=np.zeros(len(edges))
    for j,(u,v) in enumerate(edges):
        xu,yu=coords[u]; xv,yv=coords[v]
        area_w[j]=0.5*(xu*yv - xv*yu)
    # signed area of each cycle basis vector
    areas = Z.T@area_w
    # Build skew bilinear form on H1 via the planar intersection pairing:
    # Omega_{ab} = sum over shared edges with orientation -> approximate by
    # Omega = Z^T S Z where S is the edge "rotation" coupling from the embedding.
    # Use S_jk = (area contribution coupling) : here use the boundary-orientation
    # pairing S = antisymmetric part of (area_w outer indicator). Simpler & canonical:
    # the planar embedding gives each independent cycle a SIGN via its signed area.
    signs = np.sign(areas)
    print(f"  [GEO] {name}: b1={b1}  signed areas of cycle basis: "
          f"#pos={np.sum(signs>0)} #neg={np.sum(signs<0)} #zero={np.sum(signs==0)}")
    # Canonicity test: is the global orientation (sum of signed areas) nonzero?
    total=np.sum(areas)
    # If we conjugate the plane by a reflection (x->-x), all signed areas flip sign.
    # So the SET {+,-} is reflection-equivariant. A canonical J would need the
    # sign fixed WITHOUT choosing plane orientation. Test: does reflection flip total?
    coords_ref=coords.copy(); coords_ref[:,0]*=-1
    area_w_ref=np.zeros(len(edges))
    for j,(u,v) in enumerate(edges):
        xu,yu=coords_ref[u]; xv,yv=coords_ref[v]
        area_w_ref[j]=0.5*(xu*yv-xv*yu)
    total_ref=np.sum(Z.T@area_w_ref)
    flips = np.sign(total)!=np.sign(total_ref) if abs(total)>1e-9 else None
    print(f"       total signed area={total:.4f}, under x->-x reflection={total_ref:.4f}  "
          f"-> orientation {'FLIPS (sign = plane choice, NOT canonical)' if flips else 'invariant?'}")

# =====================================================================
# TEST 2 (DYNAMICS): restrict the dynamical complex structure to the
# cycle subspace. Map cycle space into node space via B (edges->nodes is
# trivial; we need cycles' action on the dynamics). The dynamics lives on
# NODES (L is node Laplacian). The cycle space lives on EDGES. The link is
# the edge Laplacian / Hodge. Build the 1-form (edge) Laplacian
# L1 = B^T B  (graph has no 2-cells here) and its dynamical generator
# A1=[[0,I],[-L1,0]] restricted to ker(B)=H1, then test kappa-resistance.
# =====================================================================
def test2_dynamics(name, N, edges):
    Z,B = cycle_space_basis(N,edges)
    b1=Z.shape[1]
    if b1==0:
        print(f"  [DYN] {name}: b1=0 -> cycle subspace empty, dynamics test VACUOUS")
        return
    # edge Laplacian (down-Laplacian) L1 = B^T B acts on edge space; restrict to H1=ker B.
    L1 = B.T@B
    L1_H1 = Z.T@L1@Z            # b1 x b1, symmetric PSD
    # but ker(B) is exactly the kernel of the DOWN-laplacian B^T B? B B^T? 
    # H1 = ker(B) (cycles). For these, B Z =0 so L1 Z = B^T B Z. B Z=0 => L1 Z=0.
    # So the down-laplacian annihilates cycles. Need UP-laplacian (needs 2-cells).
    # Without 2-cells, cycles are harmonic => zero generator => J undefined from this.
    eig=np.linalg.eigvalsh(L1_H1)
    print(f"  [DYN] {name}: b1={b1}  spectrum of down-edge-Laplacian on H1: "
          f"max={eig.max():.2e} min={eig.min():.2e}  "
          f"-> {'all ~0: cycles are HARMONIC, dynamics gives NO J on H1' if eig.max()<1e-8 else 'nonzero!'}")

# ---------------- run ----------------
print("=== TREE b=3 (control: b1=0) ===")
for D in [3,6]:
    N,edges=build_tree(3,D)
    # tree has no coords; geometry test vacuous anyway (b1=0)
    test1_geometry(f"tree D={D}", N, edges, np.zeros((N,2)))
    test2_dynamics(f"tree D={D}", N, edges)

print("=== GASKET b=3 ===")
for n in [3,6]:
    N,edges,coords=build_gasket(n)
    test1_geometry(f"gasket n={n}", N, edges, coords)
    test2_dynamics(f"gasket n={n}", N, edges)
