# Mehrteilchen-/H₁-Test: Zusammenfassung

**Datum:** 2026-06-09
**Kontext:** Korrekt modellierte Fortsetzung des in F10 zurückgezogenen Mehrteilchen-Tests; zugleich erster direkter Test der topologischen Wurzel-Hypothese F9 (*„i lebt in den Schleifen, nicht im Baum"*).

---

## 1. Was getestet wurde

Vergleich zweier Strukturen bei gleichem Verzweigungsparameter **b = 3**:

| Struktur | Stufe | Knoten V | Kanten E | Zyklenrang b₁ |
|---|---|---|---|---|
| b-ärer Baum | Tiefe 3 | 40 | 39 | **0** |
| b-ärer Baum | Tiefe 6 | 1093 | 1092 | **0** |
| Sierpinski-Gasket | Gen. 3 | 42 | 81 | **40** |
| Sierpinski-Gasket | Gen. 6 | 1095 | ~2187 | **1093** |

Der Baum dient als **Kontrollgruppe**: leerer Zyklenraum (b₁ = 0). Alles, was beim
Gasket auftaucht, beim Baum aber nicht auftauchen *kann*, ist der einzige Ort, an
dem die Topologie (Schleifen) einen echten Unterschied machen darf.

Verifiziert wurde vorab, dass die b₁-Werte **4, 13, 40, 121, 364** des Gaskets
exakt mit den in F9 notierten Werten übereinstimmen (Konstruktion korrekt).

---

## 2. Der dynamische Generator (Korrektur des F10-Fehlers)

Statt des statischen Schur-Operators wurde der **dynamische Generator**
A = [[0, I], [−L, 0]] auf R^{2N} verwendet, mit L = reeller, symmetrischer,
positiver Knoten-Laplace.

**Befund (generator_test.py):** A hat in *beiden* Strukturen das erwartete
**rein imaginäre Spektrum** ±i·√λₖ (max |Re λ| ∼ 10⁻⁸…10⁻¹⁵, numerisch null),
mit genau einem Nullmodus (konstanter Vektor des zusammenhängenden Graphen).
Auf jedem Modenblock wirkt A als √λᵢ · J_block mit J_block = [[0,1],[−1,0]].

**Kappa-Test:** Eine *reell-orthogonale* Konjugation S = diag(1,−1) bildet
J_block ↦ −J_block. Also ist +J von −J im Rahmen der reellen Struktur **nicht
unterscheidbar** — die komplexe Struktur ist **κ-blind**, und zwar **identisch
für Baum und Gasket**.

**Einschränkung (wichtig):** Dieser Test ist *zu schwach*, um F9 zu berühren. Er
schaut auf das Spektrum von L allein, das der Baum genauso hat. Er reproduziert
den Einteilchen-Befund (F1–F8: κ-Blindheit), sagt aber nichts über die
Schleifen. Ein Test, der F9 nicht falsifizieren *kann*, ist kein Test von F9.
→ Deshalb die beiden gezielten H₁-Tests.

---

## 3. Die zwei H₁-Tests (h1_tests.py)

### Test 1 — GEOMETRIE: Orientierung der Zyklen (zielt auf F4/F11)

Planare Einbettung des Gaskets → jeder Basiszyklus erhält eine **signierte
Fläche**, also ein Vorzeichen.

- Gasket Gen. 3: b₁ = 40, signierte Flächen #pos = 18, #neg = 22
- Gasket Gen. 6: b₁ = 1093, #pos = 563, #neg = 530
- Gesamt-signierte-Fläche: +0.0467 (Gen. 3), +0.0827 (Gen. 6)

**Entscheidend:** Unter der Spiegelung x → −x **klappt das Vorzeichen der
gesamten signierten Fläche um** (+0.0467 → −0.0467). Das Vorzeichen der aus der
Zyklenorientierung gewonnenen komplexen Struktur **ist die Wahl der
Ebenenorientierung**.

→ **Bestätigt F4/F11:** Die Geometrie liefert das i *nur* relativ zu einer
gewählten Orientierung. Es ist nicht kanonisch, sondern eine Vakuumwahl. Kein
Bruch — Bestätigung des bisherigen Befunds, jetzt explizit gerechnet.

### Test 2 — DYNAMIK: komplexe Struktur auf dem Zyklenraum (zielt auf F9)

Hypothese: Wenn i in den Schleifen lebt, sollte die Dynamik, eingeschränkt auf
H₁, eine komplexe Struktur erzeugen.

**Befund:** Der Down-Kanten-Laplace L₁ = BᵀB, eingeschränkt auf H₁ = ker(B), ist
**exakt null** (Spektrum ∼ 10⁻¹⁶). Strukturell, nicht numerisch: Zyklen sind per
Definition der Kern von B, also annihiliert L₁ sie. Ohne 2-Zellen sind die
Schleifen **harmonisch** — die Dynamik tut auf ihnen nichts.

→ **Widerlegt die graphentheoretische Form von F9.** Der Zyklenraum existiert
(anders als beim Baum), trägt aber keine Dynamik. Eine Dynamik, die nichts tut,
erzeugt keine komplexe Struktur. Das ist eine **echte Obstruktion**: Es hätte
herauskommen können, dass die Schleifendynamik ein J erzwingt — sie tut es nicht.

---

## 4. Was der Befund bedeutet (ohne Schönfärberei)

1. **Test 1 bestätigt F4/F11:** Zyklenorientierung gibt nur
   orientierungsabhängiges, nicht-kanonisches Vorzeichen = Vakuumwahl.

2. **Test 2 widerlegt F9 in der reinen Graphenform** (nur Knoten + Kanten):
   Schleifen sind harmonisch, keine Dynamik, kein J.

3. **Die einzige Überlebensbedingung für F9:** Die Rechnung zeigt zugleich, *was
   fehlen würde* — **2-Zellen** (eingeklebte Flächen). Mit 2-Zellen entsteht ein
   Up-Laplace B₂B₂ᵀ, der die Zyklen *nicht* annihiliert. F9 in reiner Graphenform
   ist damit tot; F9 würde einen echten **Kettenkomplex mit 2-Zellen** verlangen
   und wäre dann eine *neue, separat zu prüfende* Behauptung.

---

## 5. Offene Entscheidung (Leben/Tod von F9)

**Liefert die bright-dark-Verklebung der ToC-Konstruktion 2-Zellen?**

- Falls **ja** (die Dreiecksflächen des Gaskets werden eingeklebt): Up-Laplace
  bauen, prüfen, ob *dann* eine kanonische, konjugationsfeste komplexe Struktur
  auf H₁ entsteht. → Entscheidender nächster Test.
- Falls **nein** (Verklebung nur auf Knoten-Kanten-Ebene): Schleifen bleiben
  harmonisch, F9 ist endgültig tot, und das fehlende i bleibt vollständig im
  Bereich von F4/F11 (Vakuumwahl/Orientierung).

---

## 6. Skripte (in diesem Ordner)

| Datei | Zweck |
|---|---|
| `build_structures.py` | b-ärer Baum, Knoten-Laplace, Zyklenrang; Verifikation b₁=0 |
| `build_gasket.py` | Sierpinski-Gasket per Mittelpunkt-Subdivision; Verifikation V,E,b₁ |
| `generator_test.py` | Dynamischer Generator A=[[0,I],[−L,0]]; imaginäres Spektrum; κ-Test |
| `h1_tests.py` | Test 1 (Geometrie/Orientierung) + Test 2 (Dynamik auf H₁) |

Reproduktion: `python3 h1_tests.py` (lädt die beiden Builder selbsttätig).
