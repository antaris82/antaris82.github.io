# Verification Suite (Tab 3)
- A: TP-defect≈1.570e-16, min-eig≈5.241e-06 [OK]
- B: ΔChoi≈3.846e-16, η*≈0.009967, q*≈0.119203 [OK]
- C: ‖T(t+s)-T(t)T(s)‖_F≈5.888e-16 [OK]
- D: min≈0.193451, max≈1.626928, max dD≈-1.303e-02 [OK]
- E: TD≈5.730e-03 [OK]
