# Export
Dieses Archiv enthält die gewählten Grafiken und Markdown-Dateien (Einstellungen/Ergebnisse/Verification).
Verifikation umfasst: CPTP/Choi, GADC-Fit, Semigroup-Test, Gibbs/Spohn, MCWF≈GKSL.
Hinweis: Falls keine PNGs enthalten sind, wurden die Plots als HTML exportiert (kaleido nicht verfügbar).
