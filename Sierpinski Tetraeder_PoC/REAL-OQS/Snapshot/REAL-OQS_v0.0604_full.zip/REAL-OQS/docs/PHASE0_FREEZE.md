# Phase 0 — Freeze checklist (baseline v0.0313)

This checklist is purely operational and does not change semantics.

1. Ensure a clean baseline build:

```bash
lake build
```

2. Create an annotated tag:

```bash
git tag -a v0.0313_baseline_buildgreen -m "REALOQS baseline v0.0313 (build green)"
```

3. Push the tag:

```bash
git push origin v0.0313_baseline_buildgreen
```

4. Verify `docs/TRIVIALS.md` is committed (inventory complete).
