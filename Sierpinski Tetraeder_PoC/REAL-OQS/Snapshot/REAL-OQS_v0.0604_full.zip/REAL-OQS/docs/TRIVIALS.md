# Trivial-Inventory (Phase 0 Baseline)

Stand: **REALOQS_v0.0313** (Baseline + Tree-of-Cliques Phase 1 additions).

This document lists *intentional* Aristotle placeholder constructors / hooks that set
"trivial" values (e.g. `0`, `True`, identity maps) and therefore must **not** be used
in the **default derivation path** once the canonical pipeline (Tree-of-Cliques → DtN →
Mismatch → ScaleBreaking → Mass) is in place.

These placeholders are kept for:
- build-stable testing,
- emergency fallbacks,
- minimal examples.

## A. Update: MismatchFunctional

### 1) `PillarA.Update.MismatchFunctional.mkTrivial`
- File: `REALOQS/PillarA/Update/MismatchFunctional.lean`
- Location: around line **149**
- Current behavior: `mismatch := fun _ _ => 0`
- Intended replacement (default path): a norm/metric-based mismatch functional
  (e.g. Frobenius/trace/Operator norm on the DtN boundary operator).

### 2) `PillarA.Update.normalizeTrace`
- File: `REALOQS/PillarA/Update/MismatchFunctional.lean`
- Location: around line **160**
- Current behavior: returns the input operator unchanged
- Intended replacement: trace/normalization using a deterministic epsilon floor.

## B. Physics: ScaleBreakingAxis

### 3) `PillarA.Physics.ScaleBreaking.mkTrivial`
- File: `REALOQS/PillarA/Physics/ScaleBreaking.lean`
- Location: around line **130**
- Current behavior: `breakMeasure := fun _ => 0` and trivial coarsening
- Intended replacement (default path): `axis_fromMismatch` with DtN observer
  on the Tree-of-Cliques approximants.

## C. Physics: MassEnergyHook

### 4) `PillarA.Physics.MassHook.mkZero`
- File: `REALOQS/PillarA/Physics/MassHook.lean`
- Location: around line **136**
- Current behavior: `mass := fun _ => 0`
- Intended replacement (default path): Mass derived from `breakMeasure`,
  via `MassFromTailEliminationDtN` and a monotone `massOfBreak`.

## D. Update: AllCellsConsistency

### 5) `PillarA.Update.ApproximationPipeline.AllCellsConsistency.mkTrivialObserver`
- File: `REALOQS/PillarA/Update/ApproximationPipeline.lean`
- Location: around line **212**
- Current behavior: `Obs := fun _ _ => True`
- Intended replacement (default path): pointwise consistency derived from a
  nontrivial observer tied to DtN/boundary semantics.
