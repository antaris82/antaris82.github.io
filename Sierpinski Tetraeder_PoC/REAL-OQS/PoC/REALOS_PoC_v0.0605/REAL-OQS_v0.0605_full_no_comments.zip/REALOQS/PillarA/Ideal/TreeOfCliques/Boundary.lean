import REALOQS.PillarA.Ideal.TreeOfCliques.Vertex

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

abbrev Boundary (b k : Nat) : Type := ↥(cellsAtLevel b k)

theorem cellsAtLevel_subset_cellsUpTo (b : Nat) :
    ∀ k : Nat, cellsAtLevel b k ⊆ cellsUpTo b k
  | 0 => by
      intro a ha
      simp [cellsUpTo]
      exact ha
  | k+1 => by
      intro a ha
      simp [cellsUpTo]
      exact Or.inr ha

def boundaryEmbedding (b k : Nat) : Boundary b k → Vertex b k := by
  intro x
  refine ⟨x.1, ?_⟩
  exact (cellsAtLevel_subset_cellsUpTo b k) x.2

def interiorSet (b k : Nat) : Finset (Addr b) :=
  (cellsUpTo b k) \ (cellsAtLevel b k)

abbrev Interior (b k : Nat) : Type := ↥(interiorSet b k)

def interiorEmbedding (b k : Nat) : Interior b k → Vertex b k := by
  intro x
  refine ⟨x.1, ?_⟩
  exact (Finset.mem_sdiff.mp x.2).1

end TreeOfCliques
end Ideal
end PillarA
