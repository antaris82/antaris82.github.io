import REALOQS.PillarA.Ideal.TreeOfCliques.Laplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Split
import REALOQS.PillarA.OQS.DtN

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

open scoped BigOperators

noncomputable section

open PillarA.OQS
open PillarA.LayerA

namespace DtN

variable (b k : Nat)

abbrev V := Vertex b k
abbrev B := Boundary b k
abbrev I := Interior b k

abbrev s : PillarA.OQS.Split (V (b := b) (k := k)) := split (b := b) (k := k)

abbrev L : Matrix (V (b := b) (k := k)) (V (b := b) (k := k)) ℝ :=
  PillarA.Ideal.TreeOfCliques.laplacian
    (b := b) (k := k)

abbrev LII : Matrix (I (b := b) (k := k)) (I (b := b) (k := k)) ℝ :=
  (s (b := b) (k := k)).blockII (L (b := b) (k := k))

def interiorInv_of_det
    (hdet : (LII (b := b) (k := k)).det ≠ 0) :
    PillarA.OQS.Split.InteriorInv (s := s (b := b) (k := k)) (L (b := b) (k := k)) := by
  classical
  let A : Matrix (I (b := b) (k := k)) (I (b := b) (k := k)) ℝ :=
    (LII (b := b) (k := k))
  refine ⟨A⁻¹, ?_⟩
  simpa [A] using
    (PillarA.LayerA.gate_DTN_WELLPOSED_canonical (ι := I (b := b) (k := k)) (A := A) hdet)

def dtn_of_det
    (hdet : (LII (b := b) (k := k)).det ≠ 0) :
    Matrix (B (b := b) (k := k)) (B (b := b) (k := k)) ℝ :=
  (s (b := b) (k := k)).DtN_of (L := L (b := b) (k := k))
    (w := interiorInv_of_det (b := b) (k := k) hdet)

end DtN

end

end TreeOfCliques
end Ideal
end PillarA
