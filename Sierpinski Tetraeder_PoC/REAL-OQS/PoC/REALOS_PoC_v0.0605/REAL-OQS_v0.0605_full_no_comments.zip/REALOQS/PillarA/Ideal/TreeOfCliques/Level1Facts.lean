import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary
import REALOQS.PillarA.Ideal.TreeOfCliques.SmallScales

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

namespace Level1Facts

variable {b : Nat}

theorem boundary1_val_eq_singleton (x : Boundary b 1) : ∃ d : Fin b, (x : Addr b) = [d] := by
  have hxlen : (x : Addr b).length = 1 :=
    (mem_cellsAtLevel_iff_length b 1 (x : Addr b)).1 x.2
  rcases (List.length_eq_one_iff).1 hxlen with ⟨d, hd⟩
  exact ⟨d, hd⟩

@[simp] theorem pi_boundary1_eq_rootB0 (b : Nat) (x : Boundary b 1) :
    CoarsenBoundary.π b 0 x = rootB0 b := by
  classical
  apply Subtype.ext
  rcases boundary1_val_eq_singleton (b := b) x with ⟨d, hd⟩
  simp [CoarsenBoundary.π, rootB0_val, hd]

theorem fiber_rootB0_eq_univ (b : Nat) :
    CoarsenBoundary.fiber b 0 (rootB0 b) = (Finset.univ : Finset (Boundary b 1)) := by
  classical
  ext x
  simp [CoarsenBoundary.fiber]

end Level1Facts

end TreeOfCliques
end Ideal
end PillarA
