import Mathlib
import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilizedDefs
import REALOQS.PillarA.OQS.DtNStabilizedCriteria

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace Ideal
namespace TreeOfCliques
namespace DtNStabilized

noncomputable section

open PillarA.LayerA
open PillarA.OQS

variable {b : Nat}

abbrev DetGate (p : Policy b) : Prop :=
  ∀ k, (LII_stab (b := b) p k).det ≠ 0

abbrev c (k : Nat) : PillarA.LayerA.Weight (Vertex b k) :=
  fun x y => conductance (b := b) (k := k) x y

lemma c_symm (k : Nat) : ∀ i j : Vertex b k, c (b := b) k i j = c (b := b) k j i := by
  intro i j
  simpa [c] using (conductance_symm (b := b) (k := k) i j)

lemma c_nonneg (k : Nat) : ∀ i j : Vertex b k, 0 ≤ c (b := b) k i j := by
  intro i j
  simpa [c] using (conductance_nonneg (b := b) (k := k) i j)

lemma quadForm_L_nonneg (k : Nat) (f : Vertex b k → ℝ) :
    0 ≤ PillarA.LayerA.quadForm (L (b := b) k) f := by
  classical
  have hEq :
      PillarA.LayerA.dirichletEnergy (c (b := b) k) f =
        PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c (b := b) k)) f :=
    PillarA.LayerA.gate_DIRICHLET_EQ_LAPLACIAN_QUAD
      (c := c (b := b) k) (hsymm := c_symm (b := b) k) (f := f)
  have hNon : 0 ≤ PillarA.LayerA.dirichletEnergy (c (b := b) k) f :=
    PillarA.LayerA.gate_DIRICHLET_NONNEG
      (c := c (b := b) k) (hnonneg := c_nonneg (b := b) k) (f := f)
  have : 0 ≤ PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c (b := b) k)) f := by
    simpa [hEq] using hNon
  simpa [L, _root_.PillarA.Ideal.TreeOfCliques.laplacian, c] using this

abbrev sSplit (k : Nat) : PillarA.OQS.Split (Vertex b k) := split (b := b) (k := k)

lemma quadForm_ext_eq_quadForm_blockII
    (k : Nat) (Lk : Matrix (Vertex b k) (Vertex b k) ℝ)
    (x : (sSplit (b := b) k).I → ℝ) :
    let g : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) → ℝ := fun s =>
      match s with
      | Sum.inl _ => 0
      | Sum.inr i => x i
    let f : Vertex b k → ℝ := fun v => g ((sSplit (b := b) k).e v)
    PillarA.LayerA.quadForm Lk f =
      PillarA.LayerA.quadForm ((sSplit (b := b) k).blockII Lk) x := by
  classical
  intro g f
  change (∑ v : Vertex b k, f v * (∑ w : Vertex b k, Lk v w * f w))
      = (∑ i : (sSplit (b := b) k).I,
          x i * (∑ j : (sSplit (b := b) k).I, ((sSplit (b := b) k).blockII Lk) i j * x j))

  have houter :
      (∑ v : Vertex b k, f v * (∑ w : Vertex b k, Lk v w * f w))
        =
      (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        f (((sSplit (b := b) k).e).symm s) *
          (∑ w : Vertex b k, Lk (((sSplit (b := b) k).e).symm s) w * f w)) := by
    simpa using
      (Fintype.sum_equiv (sSplit (b := b) k).e
        (fun v : Vertex b k => f v * (∑ w : Vertex b k, Lk v w * f w))
        (fun s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) =>
          f (((sSplit (b := b) k).e).symm s) *
            (∑ w : Vertex b k,
              Lk (((sSplit (b := b) k).e).symm s) w * f w))
        (by intro v; simp))

  have hinner :
      ∀ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        (∑ w : Vertex b k, Lk (((sSplit (b := b) k).e).symm s) w * f w)
          =
        (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) *
            f (((sSplit (b := b) k).e).symm t))
        := by
    intro s
    simpa using
      (Fintype.sum_equiv (sSplit (b := b) k).e
        (fun w : Vertex b k => Lk (((sSplit (b := b) k).e).symm s) w * f w)
        (fun t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) =>
          Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) *
            f (((sSplit (b := b) k).e).symm t))
        (by intro w; simp))

  have hf :
      ∀ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        f (((sSplit (b := b) k).e).symm s) = g s := by
    intro s
    simp [f]

  have hLHS :
      (∑ v : Vertex b k, f v * (∑ w : Vertex b k, Lk v w * f w))
        =
      (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        g s * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) * g t)) := by
    calc
      (∑ v : Vertex b k, f v * (∑ w : Vertex b k, Lk v w * f w))
          =
        (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          f (((sSplit (b := b) k).e).symm s) *
            (∑ w : Vertex b k, Lk (((sSplit (b := b) k).e).symm s) w * f w)) := houter
      _ =
        (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          f (((sSplit (b := b) k).e).symm s) *
            (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
              Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) *
                f (((sSplit (b := b) k).e).symm t)))
        := by
        refine Fintype.sum_congr
          (fun s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) =>
            f (((sSplit (b := b) k).e).symm s) *
              (∑ w : Vertex b k,
                Lk (((sSplit (b := b) k).e).symm s) w * f w))
          (fun s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) =>
            f (((sSplit (b := b) k).e).symm s) *
              (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
                Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) *
                  f (((sSplit (b := b) k).e).symm t)))
          (by
            intro s
            exact congrArg (fun z => f (((sSplit (b := b) k).e).symm s) * z) (hinner s))
      _ = _ := by
        simp [hf]

  have hSplitOuter :
      (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        g s * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) * g t))
        =
      (∑ bb : (sSplit (b := b) k).B,
        g (Sum.inl bb) * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm (Sum.inl bb)) (((sSplit (b := b) k).e).symm t) * g t))
      +
      (∑ ii : (sSplit (b := b) k).I,
        g (Sum.inr ii) * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm t) * g t))
        := by
    simp [Fintype.sum_sum_type]

  have hInnerI :
      ∀ ii : (sSplit (b := b) k).I,
        (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii)) (((sSplit (b := b) k).e).symm t) * g t)
          =
        (∑ jj : (sSplit (b := b) k).I,
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm (Sum.inr jj)) * x jj)
        := by
    intro ii
    calc
      (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        Lk (((sSplit (b := b) k).e).symm (Sum.inr ii)) (((sSplit (b := b) k).e).symm t) * g t)
          =
        (∑ bb : (sSplit (b := b) k).B,
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm (Sum.inl bb)) * g (Sum.inl bb))
        +
        (∑ jj : (sSplit (b := b) k).I,
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm (Sum.inr jj)) * g (Sum.inr jj))
        := by
        simp [Fintype.sum_sum_type]
      _ =
        (∑ jj : (sSplit (b := b) k).I,
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm (Sum.inr jj)) * x jj)
        := by
        simp [g]

  calc
    (∑ v : Vertex b k, f v * (∑ w : Vertex b k, Lk v w * f w))
        =
      (∑ s : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
        g s * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm s) (((sSplit (b := b) k).e).symm t) * g t)) := hLHS
    _ =
      (∑ bb : (sSplit (b := b) k).B,
        g (Sum.inl bb) * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm (Sum.inl bb)) (((sSplit (b := b) k).e).symm t) * g t))
      +
      (∑ ii : (sSplit (b := b) k).I,
        g (Sum.inr ii) * (∑ t : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I),
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm t) * g t)) := hSplitOuter
    _ =
      (∑ ii : (sSplit (b := b) k).I,
        x ii * (∑ jj : (sSplit (b := b) k).I,
          Lk (((sSplit (b := b) k).e).symm (Sum.inr ii))
              (((sSplit (b := b) k).e).symm (Sum.inr jj)) * x jj))
        := by
        simp [g, hInnerI]
    _ =
      (∑ ii : (sSplit (b := b) k).I,
        x ii * (∑ jj : (sSplit (b := b) k).I, ((sSplit (b := b) k).blockII Lk) ii jj * x jj)) := by
      simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, Matrix.reindex]

lemma symm_blockII_eq
    (k : Nat)
    (Lk : Matrix (Vertex b k) (Vertex b k) ℝ)
    (hT : Matrix.transpose ((sSplit (b := b) k).blockII Lk) = (sSplit (b := b) k).blockII Lk) :
    PillarA.OQS.Split.DtNStabilized.symm
      (ι := (sSplit (b := b) k).I)
      ((sSplit (b := b) k).blockII Lk)
      = (sSplit (b := b) k).blockII Lk := by
  classical
  calc
    PillarA.OQS.Split.DtNStabilized.symm
      (ι := (sSplit (b := b) k).I)
      ((sSplit (b := b) k).blockII Lk)
        = (1 / 2 : ℝ) •
            (((sSplit (b := b) k).blockII Lk)
              + Matrix.transpose ((sSplit (b := b) k).blockII Lk)) := rfl
    _ = (1 / 2 : ℝ) • (((sSplit (b := b) k).blockII Lk) + ((sSplit (b := b) k).blockII Lk)) := by
      simp [hT]
    _ = (1 / 2 : ℝ) • ((2 : ℝ) • ((sSplit (b := b) k).blockII Lk)) := by
      simp [two_smul]
    _ = ((1 / 2 : ℝ) * 2) • ((sSplit (b := b) k).blockII Lk) := by
      simp [smul_smul]
    _ = (sSplit (b := b) k).blockII Lk := by
      norm_num

theorem hpsd_laplacian_blockII (k : Nat) :
    (PillarA.OQS.Split.DtNStabilized.symm (ι := (sSplit (b := b) k).I)
        ((sSplit (b := b) k).blockII (L (b := b) k))).PosSemidef := by
  classical
  have hsymmL : Matrix.transpose (L (b := b) k) = L (b := b) k :=
    (gate_LAPLACIAN_ADMISSIBLE_treeOfCliques (b := b) (k := k)).1
  have hsymmLII :
      Matrix.transpose ((sSplit (b := b) k).blockII (L (b := b) k))
        = (sSplit (b := b) k).blockII (L (b := b) k) :=
    PillarA.OQS.Split.blockII_transpose_of_symm (s := sSplit (b := b) k) (M := L (b := b) k) hsymmL
  have hsymmEq :
      PillarA.OQS.Split.DtNStabilized.symm (ι := (sSplit (b := b) k).I)
          ((sSplit (b := b) k).blockII (L (b := b) k))
        = (sSplit (b := b) k).blockII (L (b := b) k) :=
    symm_blockII_eq (b := b) (k := k) (Lk := L (b := b) k) hsymmLII

  have hLII : ((sSplit (b := b) k).blockII (L (b := b) k)).PosSemidef := by
    refine And.intro ?_ ?_
    · dsimp [Matrix.IsHermitian]
      ext i j
      have hij : ((sSplit (b := b) k).blockII (L (b := b) k)) j i
          = ((sSplit (b := b) k).blockII (L (b := b) k)) i j := by
        have hij0 :=
          congrArg
            (fun M : Matrix ((sSplit (b := b) k).I) ((sSplit (b := b) k).I) ℝ => M i j)
            hsymmLII
        simp [Matrix.transpose_apply] at hij0
        exact hij0
      simp [Matrix.conjTranspose, hij]
    · intro x
      let g : Sum ((sSplit (b := b) k).B) ((sSplit (b := b) k).I) → ℝ := fun s =>
        match s with
        | Sum.inl _ => 0
        | Sum.inr i => x i
      let f : Vertex b k → ℝ := fun v => g ((sSplit (b := b) k).e v)
      have h0 : 0 ≤ PillarA.LayerA.quadForm (L (b := b) k) f :=
        quadForm_L_nonneg (b := b) (k := k) f
      have hEq :
          PillarA.LayerA.quadForm (L (b := b) k) f =
            PillarA.LayerA.quadForm ((sSplit (b := b) k).blockII (L (b := b) k)) x := by
        simpa [f, g] using
          (quadForm_ext_eq_quadForm_blockII (b := b) (k := k) (Lk := L (b := b) k) x)
      have hx : 0 ≤ PillarA.LayerA.quadForm ((sSplit (b := b) k).blockII (L (b := b) k)) x := by
        simpa [hEq] using h0
      simpa [PillarA.LayerA.quadForm] using hx

  simpa [hsymmEq] using hLII

theorem detGate_proved (p : Policy b) : DetGate (b := b) p := by
  intro k
  have hpsd :
      (PillarA.OQS.Split.DtNStabilized.symm (ι := (sSplit (b := b) k).I)
        ((sSplit (b := b) k).blockII (L (b := b) k))).PosSemidef :=
    hpsd_laplacian_blockII (b := b) (k := k)
  have :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit (b := b) k) (p := p) (L := L (b := b) k)).det ≠ 0 := by
    exact PillarA.OQS.Split.DtNStabilized.det_LII_stabilized_ne_zero_of_posSemidef
      (s := sSplit (b := b) k) (p := p) (L := L (b := b) k) hpsd
  simpa [LII_stab, sSplit, s, L] using this

noncomputable def dtn_stabilized (p : Policy b) (k : Nat) :
    Matrix ((s (b := b) k).B) ((s (b := b) k).B) ℝ :=
  dtn_stabilized_of_det (b := b) (p := p) (k := k) ((detGate_proved (b := b) (p := p)) k)

end

end DtNStabilized
end TreeOfCliques
end Ideal
end PillarA
