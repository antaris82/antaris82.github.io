import REALOQS.PillarA.Ideal.TreeOfCliques.Boundary

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

def rootAddr (b : Nat) : Addr b := ([] : List (Fin b))

@[simp] theorem rootAddr_eq_nil (b : Nat) : rootAddr b = ([] : Addr b) := rfl

def rootB0 (b : Nat) : Boundary b 0 := by
  refine ⟨[], ?_⟩
  exact (mem_cellsAtLevel_iff_length b 0 ([] : Addr b)).2 (by simp)

@[simp] theorem rootB0_val (b : Nat) : (rootB0 b).1 = ([] : Addr b) := rfl

def rootI1 (b : Nat) : Interior b 1 := by
  refine ⟨[], ?_⟩
  refine Finset.mem_sdiff.2 ?_
  constructor
  · have h0 : ([] : Addr b) ∈ cellsUpTo b 0 := by
      simp [cellsUpTo, mem_cellsAtLevel_iff_length]
    simp [cellsUpTo]
    exact Or.inl h0
  · intro h1
    have hlen : ([] : Addr b).length = 1 := (mem_cellsAtLevel_iff_length b 1 ([] : Addr b)).1 h1
    have : ([] : Addr b).length ≠ 1 := by simp
    exact this hlen

@[simp] theorem rootI1_val (b : Nat) : (rootI1 b).1 = ([] : Addr b) := rfl

instance (b : Nat) : Unique (Boundary b 0) where
  default := rootB0 b
  uniq x := by
    apply Subtype.ext
    have hlen : (x : Addr b).length = 0 := (mem_cellsAtLevel_iff_length b 0 (x : Addr b)).1 x.2
    have hxnil : (x : Addr b) = [] := (List.length_eq_zero_iff).1 hlen
    simp [rootB0_val, hxnil]

theorem interiorSet_zero (b : Nat) : interiorSet b 0 = (∅ : Finset (Addr b)) := by
  ext a
  simp [interiorSet, cellsUpTo]

instance (b : Nat) : IsEmpty (Interior b 0) := by
  classical
  refine ⟨by
    intro x
    rcases x with ⟨a, ha⟩
    rw [interiorSet_zero (b := b)] at ha
    exact (Finset.notMem_empty a) ha⟩

instance (b : Nat) : Unique (Interior b 1) where
  default := rootI1 b
  uniq x := by
    apply Subtype.ext
    have hx : (x : Addr b) ∈ interiorSet b 1 := x.2
    have hx' : (x : Addr b) ∈ cellsUpTo b 1 ∧ (x : Addr b) ∉ cellsAtLevel b 1 :=
      Finset.mem_sdiff.mp hx
    have hcases : (x : Addr b) ∈ cellsUpTo b 0 ∨ (x : Addr b) ∈ cellsAtLevel b 1 := by
      have htmp := hx'.1
      simp [cellsUpTo] at htmp
      exact htmp
    have h0 : (x : Addr b) ∈ cellsUpTo b 0 := by
      cases hcases with
      | inl h => exact h
      | inr h => exact False.elim (hx'.2 h)
    have h0lvl : (x : Addr b) ∈ cellsAtLevel b 0 := by
      have htmp := h0
      simp [cellsUpTo] at htmp
      exact htmp
    have hlen : (x : Addr b).length = 0 := (mem_cellsAtLevel_iff_length b 0 (x : Addr b)).1 h0lvl
    have hxnil : (x : Addr b) = [] := (List.length_eq_zero_iff).1 hlen
    simp [rootI1_val, hxnil]

theorem card_boundary1 (b : Nat) : Fintype.card (Boundary b 1) = b := by
  classical
  have h := Ideal.card_cellsAtLevel b 1
  simp at h
  calc
    Fintype.card (Boundary b 1) = (cellsAtLevel b 1).card := by
      simp [Boundary]
    _ = b := h

end TreeOfCliques
end Ideal
end PillarA
