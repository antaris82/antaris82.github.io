import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.Ideal.TreeOfCliques.Edges

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

open scoped BigOperators

noncomputable section

open PillarA.LayerA

def laplacian (b k : Nat) : Matrix (Vertex b k) (Vertex b k) ℝ :=
  PillarA.LayerA.laplacian (c := conductance (b := b) (k := k))

theorem gate_LAPLACIAN_ADMISSIBLE_treeOfCliques (b k : Nat) :
    PillarA.LayerA.AdmissibleOp (V := Vertex b k)
      (PillarA.LayerA.laplacian (c := conductance (b := b) (k := k))) := by
  classical
  refine PillarA.LayerA.gate_LAPLACIAN_ADMISSIBLE
      (V := Vertex b k)
      (c := conductance (b := b) (k := k))
      (hsymm := ?_)
      (hnonneg := ?_)
  · intro i j
    simpa using (conductance_symm (b := b) (k := k) i j)
  · intro i j
    simpa using (conductance_nonneg (b := b) (k := k) i j)

end

end TreeOfCliques
end Ideal
end PillarA
