import Mathlib

set_option linter.style.longLine false

set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace Ideal

abbrev Addr (b : Nat) := List (Fin b)

def level {b : Nat} (a : Addr b) : Nat := a.length

def child {b : Nat} (a : Addr b) (d : Fin b) : Addr b := a ++ [d]

def children {b : Nat} (a : Addr b) : Finset (Addr b) :=
  Finset.univ.image (fun d : Fin b => child a d)

def cellsAtLevel (b : Nat) (k : Nat) : Finset (Addr b) :=
  (Finset.univ : Finset (Fin k → Fin b)).image (fun f => List.ofFn f)

def cellsUpTo (b : Nat) : Nat → Finset (Addr b)
| 0     => cellsAtLevel b 0
| L+1   => (cellsUpTo b L) ∪ (cellsAtLevel b (L+1))

theorem mem_cellsAtLevel_iff_length
    (b : Nat) (k : Nat) (a : Addr b) :
    a ∈ cellsAtLevel b k ↔ a.length = k := by
  constructor;
  · unfold PillarA.Ideal.cellsAtLevel; aesop;
  · intro ha
    have h_eq : ∃ f : Fin k → Fin b, List.ofFn f = a := by
      rw [ ← ha ];
      exact ⟨ fun i => a.get i, by rw [ List.ofFn_get ] ⟩;
    unfold PillarA.Ideal.cellsAtLevel; aesop;

theorem mem_children_length
    {b : Nat} (a : Addr b) (x : Addr b) :
    x ∈ children a → x.length = a.length + 1 := by
  intro hx
  obtain ⟨d, hd⟩ : ∃ d, x = a ++ [d] := by
    simp [PillarA.Ideal.children] at hx;
    obtain ⟨d, hd⟩ := hx;
    use d;
    rw [←hd];
    simp [PillarA.Ideal.child];
  simp [hd, List.length_append]

theorem children_subset_next_level
    (b : Nat) (k : Nat) (a x : Addr b)
    (ha : a ∈ cellsAtLevel b k) :
    x ∈ children a → x ∈ cellsAtLevel b (k+1) := by
  intro hx
  obtain ⟨d, hd⟩ : ∃ d : Fin b, x = a ++ [d] := by
    unfold PillarA.Ideal.children at hx; aesop;
  have h_len : x.length = k + 1 := by
    unfold PillarA.Ideal.cellsAtLevel at ha; aesop;
  apply (mem_cellsAtLevel_iff_length b (k + 1) x).mpr h_len

theorem card_cellsAtLevel
    (b : Nat) (k : Nat) :
    (cellsAtLevel b k).card = b^k := by
  have h_card_image :
      (Finset.image (fun f : Fin k → Fin b => List.ofFn f)
          (Finset.univ : Finset (Fin k → Fin b))).card
        =
      Finset.card (Finset.univ : Finset (Fin k → Fin b)) := by
    exact Finset.card_image_of_injective _ fun f g h => by simpa [ funext_iff ] using h;
  aesop

end Ideal

end PillarA
