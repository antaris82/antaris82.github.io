import Mathlib
import REALOQS.PillarA.Core.InfiniteCarrier
import REALOQS.PillarA.Core.InfiniteCarrierSymmetry
import REALOQS.PillarA.Ideal.Adapter.IdealSymmetryNoether
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance

set_option autoImplicit false

namespace PillarA

namespace Ideal

namespace Adapter

open scoped BigOperators

open PillarA.LayerA

namespace InfiniteCarrierInstance

variable {b : Nat}

def zeroDigit (b : Nat) (hb : 0 < b) : Fin b := ⟨0, hb⟩

def canonicalAddr (b : Nat) (hb : 0 < b) (L : Nat) : Addr b :=
  List.replicate L (zeroDigit b hb)

@[simp] theorem canonicalAddr_length (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalAddr b hb L).length = L := by
  simp [canonicalAddr]

theorem take_replicate_succ {α : Type} (a : α) (L : Nat) :
    (List.replicate (Nat.succ L) a).take L = List.replicate L a := by
  induction L with
  | zero =>
      simp
  | succ L ih =>
      simpa [List.replicate, ih]

@[simp] theorem canonicalAddr_take (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalAddr b hb (L + 1)).take L = canonicalAddr b hb L := by
  simp [canonicalAddr, take_replicate_succ (a := zeroDigit b hb) L]

def canonicalCell (b : Nat) (hb : 0 < b) (L : Nat) : IdealCell b L :=
  ⟨canonicalAddr b hb L,
    by
      apply (mem_cellsAtLevel_iff_length b L (canonicalAddr b hb L)).2
      simp [canonicalAddr]⟩

@[simp] theorem canonicalCell_val (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalCell b hb L).1 = canonicalAddr b hb L := rfl

@[simp] theorem canonicalCell_parent (b : Nat) (hb : 0 < b) (L : Nat) :
    IdealCell.parent (b := b) (L := L) (canonicalCell b hb (L + 1))
      = canonicalCell b hb L := by
  ext
  simp [IdealCell.parent, canonicalAddr_take]

def canonicalCarrier (b : Nat) (hb : 0 < b) :
    InfiniteCarrier (Cell := IdealCell b) :=
  { cell := fun L => canonicalCell b hb L
    coh := by
      intro L
      rw [DeterministicSubstrate.parents_eq_singleton_parent
            (Cell := IdealCell b)
            (c := canonicalCell b hb (L + 1))]
      have hdp :
          (DeterministicSubstrate.parent (Cell := IdealCell b)
              (canonicalCell b hb (L + 1)))
            = canonicalCell b hb L := by
        change
          IdealCell.parent (b := b) (L := L) (canonicalCell b hb (L + 1))
            = canonicalCell b hb L
        exact canonicalCell_parent (b := b) (hb := hb) (L := L)
      simp [hdp] }

noncomputable instance (b : Nat) [Fact (0 < b)] :
    Inhabited (InfiniteCarrier (Cell := IdealCell b)) :=
  ⟨canonicalCarrier b (Fact.out : 0 < b)⟩

open PillarA.Ideal.IdealSymmetry

noncomputable def idealSymm (b : Nat) : SymmetryAction (Cell := IdealCell b) :=
  PillarA.Ideal.IdealSymmetry.symmetryAction b

theorem gate_actInf_available (b : Nat) [Fact (0 < b)]
    (σ : DigitPerm b) (U : InfiniteCarrier (Cell := IdealCell b)) (L : Nat) :
    ((idealSymm b).actInf (Cell := IdealCell b) σ U).cell L
      = (idealSymm b).act (L := L) σ (U.cell L) := by
  rfl

end InfiniteCarrierInstance

end Adapter

end Ideal

end PillarA
