import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox

set_option autoImplicit false

namespace PillarA
namespace Update
namespace Instances

open scoped BigOperators

noncomputable section

namespace TreeOfCliquesAllCellsConsistency

open TreeOfCliquesApprox

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b := TreeOfCliquesApprox.mk (b := b) p

abbrev Cell : Type := (A (p := p)).FinestCell
abbrev State : Type := (A (p := p)).S

def Obs (w : Cell (p := p)) (s : State (p := p)) : Prop :=
  s.LBB w w ≠ 0

noncomputable def stId : State (p := p) :=
  { LBB := 1
    LBI := 0
    LIB := 0
    LII := 1
    inv := 1
    invOK := by
      classical
      refine ⟨?_, ?_⟩ <;> simp }

noncomputable def stZero : State (p := p) :=
  { LBB := 0
    LBI := 0
    LIB := 0
    LII := 1
    inv := 1
    invOK := by
      classical
      refine ⟨?_, ?_⟩ <;> simp }

lemma maskBB_diag (s : State (p := p)) (w : Cell (p := p)) :
    (TreeOfCliquesApprox.maskBB (p := p) (R := ({w} : Finset (Cell (p := p)))) s.LBB) w w =
      s.LBB w w := by
  classical
  simp [TreeOfCliquesApprox.maskBB]

lemma pipeline_allCells_eq (s : State (p := p)) :
    (A (p := p)).pipeline SubsystemMode.allCells s = (A (p := p)).stage1 s := by
  classical
  simp [TreeOfCliquesApprox.mk, TwoStageApprox.pipeline, TreeOfCliquesApprox.select]

lemma pipeline_single_LBB (s : State (p := p)) (w : Cell (p := p)) :
    ((A (p := p)).pipeline (SubsystemMode.single w) s).LBB =
      TreeOfCliquesApprox.maskBB (p := p) (R := ({w} : Finset (Cell (p := p))))
        ((A (p := p)).stage1 s).LBB := by
  classical
  simp [TreeOfCliquesApprox.mk, TwoStageApprox.pipeline, TwoStageApprox.stage1,
    SubsystemMode.single, TreeOfCliquesApprox.select]

instance instAllCellsConsistency :
    PillarA.Update.TwoStageApprox.AllCellsConsistency (A := A (p := p)) where
  observer :=
    { Obs := Obs (p := p)
      obs_congr := by
        intro w s t hst hObs
        simpa [Obs, hst] using hObs
      true_witness := by
        intro w
        refine ⟨stId (p := p), ?_⟩
        classical
        simp [Obs, stId]
      false_witness := by
        intro w
        refine ⟨stZero (p := p), ?_⟩
        classical
        simp [Obs, stZero] }
  allcells_pointwise := by
    classical
    intro s hSelected w hw
    have hW : Obs (p := p) w ((A (p := p)).pipeline (SubsystemMode.single w) s) :=
      hSelected w hw
    have hW' : (((A (p := p)).pipeline (SubsystemMode.single w) s).LBB) w w ≠ 0 := by
      simpa [Obs] using hW
    have hDiag : ((A (p := p)).stage1 s).LBB w w ≠ 0 := by
      have hLBB :
          ((A (p := p)).pipeline (SubsystemMode.single w) s).LBB w w =
            ((A (p := p)).stage1 s).LBB w w := by
        calc
          ((A (p := p)).pipeline (SubsystemMode.single w) s).LBB w w
              = (TreeOfCliquesApprox.maskBB (p := p)
                    (R := ({w} : Finset (Cell (p := p)))) ((A (p := p)).stage1 s).LBB) w w := by
                  simp [pipeline_single_LBB (p := p) (s := s) (w := w)]
          _ = ((A (p := p)).stage1 s).LBB w w := by
                simp [maskBB_diag (p := p) (s := (A (p := p)).stage1 s) (w := w)]
      simpa [hLBB] using hW'
    have : Obs (p := p) w ((A (p := p)).stage1 s) := by
      simpa [Obs] using hDiag
    simpa [pipeline_allCells_eq (p := p) (s := s), Obs] using this

end TreeOfCliquesAllCellsConsistency

end

end Instances
end Update
end PillarA
