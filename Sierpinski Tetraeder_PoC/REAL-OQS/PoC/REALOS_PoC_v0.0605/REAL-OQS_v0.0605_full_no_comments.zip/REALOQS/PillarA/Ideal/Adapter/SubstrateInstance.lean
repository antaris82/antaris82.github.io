import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA

namespace Ideal

open scoped BigOperators

abbrev IdealCell (b : Nat) : Nat → Type := fun L => ↥(cellsAtLevel b L)

namespace IdealCell

variable {b L : Nat}

@[simp] theorem mem_cellsAtLevel (c : IdealCell b L) : (c.1 : Addr b) ∈ cellsAtLevel b L :=
  c.2

def parent (c : IdealCell b (L + 1)) : IdealCell b L := by
  refine ⟨(c.1.take L), ?_⟩
  apply (mem_cellsAtLevel_iff_length b L (c.1.take L)).2
  have hc_len : c.1.length = L + 1 :=
    (mem_cellsAtLevel_iff_length b (L + 1) c.1).1 c.2
  simp [List.length_take, hc_len]

def child (c : IdealCell b L) (d : Fin b) : IdealCell b (L + 1) := by
  refine ⟨Ideal.child c.1 d, ?_⟩
  apply children_subset_next_level b L c.1 (Ideal.child c.1 d) c.2
  simp [Ideal.children, Ideal.child]

end IdealCell

open PillarA.LayerA

instance (b : Nat) : PillarA.LayerA.Substrate (IdealCell b) where
  instDecEq := fun _L => by infer_instance
  instFintype := fun _L => by infer_instance
  parents := fun {L} c => {IdealCell.parent (b := b) (L := L) c}
  children := fun {L} c =>
    Finset.univ.image (fun d : Fin b => IdealCell.child (b := b) (L := L) c d)

instance (b : Nat) : PillarA.LayerA.DeterministicSubstrate (IdealCell b) where
  parent := fun {L} c => IdealCell.parent (b := b) (L := L) c
  parents_eq_singleton_parent := by
    intro L c
    rfl

end Ideal

end PillarA
