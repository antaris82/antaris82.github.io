import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox
import REALOQS.PillarA.Update.TailEliminationDtN

set_option autoImplicit false

namespace PillarA
namespace Update
namespace Instances

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS

namespace TreeOfCliquesDtNSemantics

open TreeOfCliquesApprox

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b := TreeOfCliquesApprox.mk (b := b) p

noncomputable def mk :
    PillarA.Update.TailElimDtNSemantics (A := A (p := p)) := by
  classical
  refine
    { V := V (p := p)
      instFintypeV := inferInstance
      instDecEqV := inferInstance
      split := sSplit (p := p)
      L := fun st => fullMatrix (p := p) st
      inv := fun st => interiorInv (p := p) st
      boundaryOp := fun st => st.LBB
      boundaryOp_def := by
        intro st
        simp [blockBB_fullMatrix (p := p) st]
      stage1_boundaryOp_eq_DtN := by
        intro st
        simp [TreeOfCliquesApprox.mk, TwoStageApprox.stage1, TreeOfCliquesApprox.reduce] }

end TreeOfCliquesDtNSemantics

end

end Instances
end Update
end PillarA
