import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.Ideal.TreeOfCliques.Laplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Split
import REALOQS.PillarA.OQS.DtNStabilized
import REALOQS.PillarA.OQS.DtNStabilizedCriteria
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace Adapter

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS
open PillarA.Update

namespace TreeOfCliquesApproxDtNStabilized

variable {b : Nat} (p : Policy b)

abbrev k : Nat := p.L_max
abbrev B : Type := TreeOfCliques.Boundary b (k p)
abbrev I : Type := TreeOfCliques.Interior b (k p)
abbrev V : Type := TreeOfCliques.Vertex b (k p)
abbrev sSplit : PillarA.OQS.Split (V p) := TreeOfCliques.split (b := b) (k := k p)

abbrev L0 : Matrix (V p) (V p) ℝ :=
  TreeOfCliques.laplacian (b := b) (k := k p)

theorem gate_L0_admissible :
    PillarA.LayerA.AdmissibleOp (V := V p) (L0 (p := p)) := by
  classical
  simpa [L0, TreeOfCliques.laplacian] using
    TreeOfCliques.gate_LAPLACIAN_ADMISSIBLE_treeOfCliques (b := b) (k := k p)

abbrev LBB0 : Matrix (B p) (B p) ℝ := (sSplit p).blockBB (L0 (p := p))
abbrev LII0 : Matrix (I p) (I p) ℝ := (sSplit p).blockII (L0 (p := p))
abbrev LBI0 : Matrix (B p) (I p) ℝ := (sSplit p).blockBI (L0 (p := p))
abbrev LIB0 : Matrix (I p) (B p) ℝ := (sSplit p).blockIB (L0 (p := p))

@[simp] lemma LBB0_def : LBB0 (p := p) = (sSplit p).blockBB (L0 (p := p)) := rfl
@[simp] lemma LII0_def : LII0 (p := p) = (sSplit p).blockII (L0 (p := p)) := rfl
@[simp] lemma LBI0_def : LBI0 (p := p) = (sSplit p).blockBI (L0 (p := p)) := rfl
@[simp] lemma LIB0_def : LIB0 (p := p) = (sSplit p).blockIB (L0 (p := p)) := rfl

abbrev LII_stab0 : Matrix (I p) (I p) ℝ :=
  PillarA.OQS.Split.DtNStabilized.LII_stabilized
    (s := sSplit p) (p := p) (L := L0 (p := p))

abbrev hdet0 : Prop := (LII_stab0 (p := p)).det ≠ 0

abbrev hpsd0 : Prop :=
  (PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))).PosSemidef

abbrev c0 : PillarA.LayerA.Weight (V p) :=
  fun x y => TreeOfCliques.conductance (b := b) (k := k p) x y

lemma c0_symm : ∀ i j : V p, c0 (p := p) i j = c0 (p := p) j i := by
  intro i j
  simpa [c0] using (TreeOfCliques.conductance_symm (x := i) (y := j))

lemma c0_nonneg : ∀ i j : V p, 0 ≤ c0 (p := p) i j := by
  intro i j
  simpa [c0] using (TreeOfCliques.conductance_nonneg (x := i) (y := j))

lemma quadForm_L0_nonneg (f : V p → ℝ) :
    0 ≤ PillarA.LayerA.quadForm (L0 (p := p)) f := by
  classical
  have hEq :
      PillarA.LayerA.dirichletEnergy (c0 (p := p)) f =
        PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c0 (p := p))) f :=
    PillarA.LayerA.gate_DIRICHLET_EQ_LAPLACIAN_QUAD
      (c := c0 (p := p)) (hsymm := c0_symm (p := p)) (f := f)
  have hNon : 0 ≤ PillarA.LayerA.dirichletEnergy (c0 (p := p)) f :=
    PillarA.LayerA.gate_DIRICHLET_NONNEG (c := c0 (p := p)) (hnonneg := c0_nonneg (p := p)) (f := f)
  have : 0 ≤ PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c0 (p := p))) f := by
    simpa [hEq] using hNon
  simpa [L0, TreeOfCliques.laplacian, c0] using this

lemma symm_LII0_eq (hT : Matrix.transpose (LII0 (p := p)) = LII0 (p := p)) :
    PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p)) = LII0 (p := p) := by
  classical
  calc
    PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))
        = (1 / 2 : ℝ) • ((LII0 (p := p)) + Matrix.transpose (LII0 (p := p))) := rfl
    _ = (1 / 2 : ℝ) • ((LII0 (p := p)) + (LII0 (p := p))) := by
      simp [hT]
    _ = (1 / 2 : ℝ) • ((2 : ℝ) • (LII0 (p := p))) := by
      simp [two_smul]
    _ = ((1 / 2 : ℝ) * 2) • (LII0 (p := p)) := by
      simp [smul_smul]
    _ = LII0 (p := p) := by
      norm_num

lemma quadForm_ext_eq_quadForm_blockII
    (L : Matrix (V p) (V p) ℝ) (x : I p → ℝ) :
    let g : Sum (B p) (I p) → ℝ := fun s =>
      match s with
      | Sum.inl _ => 0
      | Sum.inr i => x i
    let f : V p → ℝ := fun v => g ((sSplit p).e v)
    PillarA.LayerA.quadForm L f = PillarA.LayerA.quadForm ((sSplit p).blockII L) x := by
  classical
  intro g f
  change (∑ v : V p, f v * (∑ w : V p, L v w * f w))
      = (∑ i : I p, x i * (∑ j : I p, ((sSplit p).blockII L) i j * x j))

  have houter :
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w)) := by
    simpa using
      (Fintype.sum_equiv (sSplit p).e
        (fun v : V p => f v * (∑ w : V p, L v w * f w))
        (fun s : Sum (B p) (I p) =>
          f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w))
        (by intro v; simp))

  have hinner :
      ∀ s : Sum (B p) (I p),
        (∑ w : V p, L ((sSplit p).e.symm s) w * f w)
          =
        (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t)) := by
    intro s
    simpa using
      (Fintype.sum_equiv (sSplit p).e
        (fun w : V p => L ((sSplit p).e.symm s) w * f w)
        (fun t : Sum (B p) (I p) =>
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t))
        (by intro w; simp))

  have hf : ∀ s : Sum (B p) (I p), f ((sSplit p).e.symm s) = g s := by
    intro s
    simp [f]

  have hLHS :
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t)) := by
    calc
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
          =
        (∑ s : Sum (B p) (I p),
          f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w)) := houter
      _ =
        (∑ s : Sum (B p) (I p),
          f ((sSplit p).e.symm s) *
            (∑ t : Sum (B p) (I p),
              L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t))) := by
        refine Fintype.sum_congr
          (fun s : Sum (B p) (I p) =>
            f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w))
          (fun s : Sum (B p) (I p) =>
            f ((sSplit p).e.symm s) *
              (∑ t : Sum (B p) (I p),
                L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t)))
          (by
            intro s
            exact congrArg (fun z => f ((sSplit p).e.symm s) * z) (hinner s))
      _ = _ := by
        simp [hf]

  have hSplitOuter :
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t))
        =
      (∑ b : B p,
        g (Sum.inl b) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inl b)) ((sSplit p).e.symm t) * g t))
      +
      (∑ i : I p,
        g (Sum.inr i) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)) := by
    simp [Fintype.sum_sum_type]

  have hInnerI :
      ∀ i : I p,
        (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)
          =
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j) := by
    intro i
    calc
      (∑ t : Sum (B p) (I p),
        L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)
          =
        (∑ b : B p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inl b)) * g (Sum.inl b))
        +
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * g (Sum.inr j)) := by
        simp [Fintype.sum_sum_type]
      _ =
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j) := by
        simp [g]

  calc
    (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t)) := hLHS
    _ =
      (∑ b : B p,
        g (Sum.inl b) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inl b)) ((sSplit p).e.symm t) * g t))
      +
      (∑ i : I p,
        g (Sum.inr i) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)) := hSplitOuter
    _ =
      (∑ i : I p,
        x i * (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j)) := by
        classical
        simp [g, hInnerI]
    _ =
      (∑ i : I p,
        x i * (∑ j : I p, ((sSplit p).blockII L) i j * x j)) := by
      simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, Matrix.reindex]

theorem hpsd0_proved : hpsd0 (p := p) := by
  classical
  have hsymmL0 : Matrix.transpose (L0 (p := p)) = L0 (p := p) := (gate_L0_admissible (p := p)).1
  have hsymmLII : Matrix.transpose (LII0 (p := p)) = LII0 (p := p) :=
    PillarA.OQS.Split.blockII_transpose_of_symm (s := sSplit p) (M := L0 (p := p)) hsymmL0
  have hsymmEq :
      PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p)) = LII0 (p := p) :=
    symm_LII0_eq (p := p) hsymmLII

  have hLII : (LII0 (p := p)).PosSemidef := by
    refine And.intro ?_ ?_
    · dsimp [Matrix.IsHermitian]
      ext i j
      have hij : (LII0 (p := p)) j i = (LII0 (p := p)) i j := by
        have hij0 := congrArg (fun M : Matrix (I p) (I p) ℝ => M i j) hsymmLII
        simp [Matrix.transpose_apply] at hij0
        exact hij0
      simp [Matrix.conjTranspose, hij]
    · intro x
      let g : Sum (B p) (I p) → ℝ := fun s =>
        match s with
        | Sum.inl _ => 0
        | Sum.inr i => x i
      let f : V p → ℝ := fun v => g ((sSplit p).e v)
      have h0 : 0 ≤ PillarA.LayerA.quadForm (L0 (p := p)) f :=
        quadForm_L0_nonneg (p := p) f
      have hEq :
          PillarA.LayerA.quadForm (L0 (p := p)) f =
            PillarA.LayerA.quadForm (LII0 (p := p)) x := by
        simpa [f, g, LII0] using (quadForm_ext_eq_quadForm_blockII (p := p) (L := L0 (p := p)) x)
      have hx : 0 ≤ PillarA.LayerA.quadForm (LII0 (p := p)) x := by
        simpa [hEq] using h0
      simpa [PillarA.LayerA.quadForm] using hx

  simpa [hpsd0, hsymmEq] using hLII
theorem hdet0_of_hpsd0 (hpsd : hpsd0 (p := p)) : hdet0 (p := p) := by
  classical
  have :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
          (s := sSplit p) (p := p) (L := L0 (p := p))).det ≠ 0 := by
    simpa [LII0] using
      (PillarA.OQS.Split.DtNStabilized.det_LII_stabilized_ne_zero_of_posSemidef
        (s := sSplit p) (p := p) (L := L0 (p := p)) hpsd)
  simpa [hdet0, LII_stab0] using this

def hdet0_inst : hdet0 (p := p) := hdet0_of_hpsd0 (p := p) (hpsd0_proved (p := p))

lemma hdet0_to_stateHdet :
    hdet0 (p := p) →
      (let A : Matrix (I p) (I p) ℝ :=
        PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))
       (PillarA.OQS.Split.DtNStabilized.stabilize (ι := I p) A
          (PillarA.OQS.Split.DtNStabilized.deltaSPD (p := p) (ι := I p) A)).det ≠ 0) := by
  intro h
  simpa [hdet0, LII_stab0, PillarA.OQS.Split.DtNStabilized.LII_stabilized, LII0] using h

structure ReducedOpState (p : Policy b) where
  LII : Matrix (I p) (I p) ℝ
  LBB : Matrix (B p) (B p) ℝ
  LBI : Matrix (B p) (I p) ℝ
  LIB : Matrix (I p) (B p) ℝ

  hdet :
    let A : Matrix (I p) (I p) ℝ :=
      PillarA.OQS.Split.DtNStabilized.symm (ι := I p) LII
    (PillarA.OQS.Split.DtNStabilized.stabilize (ι := I p) A
        (PillarA.OQS.Split.DtNStabilized.deltaSPD (p := p) (ι := I p) A)).det ≠ 0

@[ext] lemma ReducedOpState.ext
    {st st' : ReducedOpState p}
    (hII : st.LII = st'.LII)
    (hBB : st.LBB = st'.LBB)
    (hBI : st.LBI = st'.LBI)
    (hIB : st.LIB = st'.LIB) : st = st' := by
  cases st with
  | mk LII LBB LBI LIB hdet =>
    cases st' with
    | mk LII' LBB' LBI' LIB' hdet' =>
      cases hII; cases hBB; cases hBI; cases hIB
      have hh : hdet = hdet' := by
        apply Subsingleton.elim
      cases hh
      rfl

def ofMatrix
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    ReducedOpState p := by
  classical
  refine
    { LII := (sSplit p).blockII L
      LBB := (sSplit p).blockBB L
      LBI := (sSplit p).blockBI L
      LIB := (sSplit p).blockIB L
      hdet := ?_ }
  simpa [PillarA.OQS.Split.DtNStabilized.LII_stabilized] using hdet

@[simp] lemma ofMatrix_LII
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LII = (sSplit p).blockII L := by rfl

@[simp] lemma ofMatrix_LBB
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LBB = (sSplit p).blockBB L := by rfl

@[simp] lemma ofMatrix_LBI
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LBI = (sSplit p).blockBI L := by rfl

@[simp] lemma ofMatrix_LIB
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LIB = (sSplit p).blockIB L := by rfl

def ofLaplacian (h : hdet0 (p := p)) : ReducedOpState p :=
  ofMatrix (p := p) (L := L0 (p := p))
    (hdet := by
      simpa [hdet0, LII_stab0] using h)

def ofLaplacian_of_posSemidef (hpsd : hpsd0 (p := p)) : ReducedOpState p :=
  ofLaplacian (p := p) (h := hdet0_of_hpsd0 (p := p) hpsd)

def maskBB (R : Finset (B p)) (A : Matrix (B p) (B p) ℝ) : Matrix (B p) (B p) ℝ :=
  fun x y => (if x ∈ R then 1 else 0) * A x y * (if y ∈ R then 1 else 0)

def maskBI (R : Finset (B p)) (A : Matrix (B p) (I p) ℝ) : Matrix (B p) (I p) ℝ :=
  fun b i => if b ∈ R then A b i else 0

def maskIB (R : Finset (B p)) (A : Matrix (I p) (B p) ℝ) : Matrix (I p) (B p) ℝ :=
  fun i b => if b ∈ R then A i b else 0

@[simp] lemma maskBB_idem (R : Finset (B p)) (A : Matrix (B p) (B p) ℝ) :
    maskBB (p := p) R (maskBB (p := p) R A) = maskBB (p := p) R A := by
  classical
  ext x y
  by_cases hx : x ∈ R <;> by_cases hy : y ∈ R <;> simp [maskBB, hx, hy]

def sumMatrix (st : ReducedOpState p) :
    Matrix (Sum (B p) (I p)) (Sum (B p) (I p)) ℝ
  | Sum.inl b1, Sum.inl b2 => st.LBB b1 b2
  | Sum.inl b,  Sum.inr i  => st.LBI b i
  | Sum.inr i,  Sum.inl b  => st.LIB i b
  | Sum.inr i1, Sum.inr i2 => st.LII i1 i2

def fullMatrix (st : ReducedOpState p) : Matrix (V p) (V p) ℝ :=
  Matrix.reindex (sSplit p).e.symm (sSplit p).e.symm (sumMatrix (p := p) st)

@[simp] lemma blockBB_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockBB (fullMatrix (p := p) st) = st.LBB := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockBB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockII_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockII (fullMatrix (p := p) st) = st.LII := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockBI_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockBI (fullMatrix (p := p) st) = st.LBI := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockBI, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockIB_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockIB (fullMatrix (p := p) st) = st.LIB := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockIB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

lemma fullMatrix_ofMatrix
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    fullMatrix (p := p) (ofMatrix (p := p) L hdet) = L := by
  classical
  ext v w
  cases hv : (sSplit p).e v with
  | inl bv =>
      cases hw : (sSplit p).e w with
      | inl bw =>
          have hv' : (sSplit p).e.symm (Sum.inl bv) = v := by
            have : v = (sSplit p).e.symm (Sum.inl bv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inl bw) = w := by
            have : w = (sSplit p).e.symm (Sum.inl bw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockBB,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
      | inr iw =>
          have hv' : (sSplit p).e.symm (Sum.inl bv) = v := by
            have : v = (sSplit p).e.symm (Sum.inl bv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inr iw) = w := by
            have : w = (sSplit p).e.symm (Sum.inr iw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockBI,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
  | inr iv =>
      cases hw : (sSplit p).e w with
      | inl bw =>
          have hv' : (sSplit p).e.symm (Sum.inr iv) = v := by
            have : v = (sSplit p).e.symm (Sum.inr iv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inl bw) = w := by
            have : w = (sSplit p).e.symm (Sum.inl bw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockIB,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
      | inr iw =>
          have hv' : (sSplit p).e.symm (Sum.inr iv) = v := by
            have : v = (sSplit p).e.symm (Sum.inr iv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inr iw) = w := by
            have : w = (sSplit p).e.symm (Sum.inr iw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockII,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']

lemma fullMatrix_ofLaplacian (h : hdet0 (p := p)) :
    fullMatrix (p := p) (ofLaplacian (p := p) h) = L0 (p := p) := by
  classical
  simpa [ofLaplacian] using
    (fullMatrix_ofMatrix (p := p) (L := L0 (p := p))
      (hdet := by
        simpa [hdet0, LII_stab0] using h))

lemma hdet_LII_stabilized_fullMatrix (st : ReducedOpState p) :
    (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (fullMatrix (p := p) st)).det ≠ 0 := by
  classical
  simpa [PillarA.OQS.Split.DtNStabilized.LII_stabilized] using st.hdet

def invStab (st : ReducedOpState p) :
    PillarA.OQS.Split.DtNStabilized.InteriorInvStabilized
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st) := by
  classical
  exact
    PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st)
      (hdet := hdet_LII_stabilized_fullMatrix (p := p) st)

@[simp] lemma invStab_inv (st : ReducedOpState p) :
    (invStab (p := p) st).inv =
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (fullMatrix (p := p) st))⁻¹ := by
  classical
  simp [invStab, PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det]

def select (m : SubsystemMode (B p)) (st : ReducedOpState p) : ReducedOpState p := by
  classical
  cases m with
  | allCells =>
      exact st
  | region R =>
      refine
        { LII := st.LII
          LBB := maskBB (p := p) R st.LBB
          LBI := maskBI (p := p) R st.LBI
          LIB := maskIB (p := p) R st.LIB
          hdet := ?_ }
      simpa using st.hdet

lemma dtn_stabilized_fullMatrix_of_cross_zero (st : ReducedOpState p)
    (hBI : st.LBI = 0) (hIB : st.LIB = 0) :
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
        (s := sSplit p) (p := p) (L := fullMatrix (p := p) st)
        (w := invStab (p := p) st) = st.LBB := by
  classical
  simp [PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of, PillarA.LayerA.DtN, hBI, hIB]

def reduce (st : ReducedOpState p) : ReducedOpState p :=
  { LII := st.LII
    LBB := PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st) (w := invStab (p := p) st)
    LBI := 0
    LIB := 0
    hdet := st.hdet }

lemma dtn_stabilized_fullMatrix_of_reduced (st : ReducedOpState p) :
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
        (s := sSplit p) (p := p) (L := fullMatrix (p := p) (reduce (p := p) st))
        (w := invStab (p := p) (reduce (p := p) st))
      = (reduce (p := p) st).LBB := by
  classical
  apply dtn_stabilized_fullMatrix_of_cross_zero (p := p) (st := reduce (p := p) st) <;> rfl

lemma reduce_idem (st : ReducedOpState p) :
    reduce (p := p) (reduce (p := p) st) = reduce (p := p) st := by
  classical
  apply ReducedOpState.ext (p := p)
  · simp [reduce]
  · simpa [reduce] using (dtn_stabilized_fullMatrix_of_reduced (p := p) st)
  · simp [reduce]
  · simp [reduce]

def stLap : ReducedOpState p :=
  ofLaplacian (p := p) (hdet0_inst (p := p))

lemma fullMatrix_stLap :
    fullMatrix (p := p) (stLap (p := p)) = L0 (p := p) := by
  simpa [stLap] using fullMatrix_ofLaplacian (p := p) (hdet0_inst (p := p))

lemma reduce_cross_zero_stLap :
    (reduce (p := p) (stLap (p := p))).LBI = 0 ∧
    (reduce (p := p) (stLap (p := p))).LIB = 0 := by
  simp [reduce, stLap]

lemma reduce_LBB_eq_dtn_stab :
    (reduce (p := p) (stLap (p := p))).LBB =
      TreeOfCliques.DtNStabilized.dtn_stabilized_of_det
        (b := b) (p := p) (k := k p)
        (hdet := by
          simpa [TreeOfCliques.DtNStabilized.LII_stab,
            TreeOfCliques.DtNStabilized.s,
            TreeOfCliques.DtNStabilized.L,
            LII_stab0, L0, sSplit, k] using
              (show (LII_stab0 (p := p)).det ≠ 0 from (hdet0_inst (p := p)))) := by
  classical
  simp [reduce, stLap, ofLaplacian,
    TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
    TreeOfCliques.DtNStabilized.s,
    TreeOfCliques.DtNStabilized.L,
    PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
    PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
    PillarA.OQS.Split.DtNStabilized.LII_stabilized,
    PillarA.LayerA.DtN,
    invStab_inv,
    L0, sSplit, k]

def mk : PillarA.Update.TwoStageApprox b where
  policy := p
  Cell := (PillarA.Ideal.IdealCell b : Nat → Type)
  S := ReducedOpState p
  truncateTail := id
  integrateTail := fun s => reduce (p := p) s
  select := fun m s => select (p := p) m s
  truncate_idem := by intro s; rfl
  integrate_idem := by intro s; simpa using (reduce_idem (p := p) s)
  stage1_idem := by
    intro s
    simpa using (reduce_idem (p := p) s)

end TreeOfCliquesApproxDtNStabilized

end

end Adapter
end Ideal
end PillarA
