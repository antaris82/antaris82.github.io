import REALOQS.PillarA.Ideal.TreeOfCliques.DtN
import REALOQS.PillarA.OQS.DtNStabilized

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace Ideal
namespace TreeOfCliques

noncomputable section

open PillarA.OQS
open PillarA.LayerA

namespace DtNStabilized

variable {b : Nat}

abbrev s (k : Nat) : PillarA.OQS.Split (Vertex b k) :=
  split (b := b) (k := k)

abbrev L (k : Nat) : Matrix (Vertex b k) (Vertex b k) ℝ :=
  PillarA.Ideal.TreeOfCliques.laplacian (b := b) (k := k)

abbrev LII_stab (p : PillarA.LayerA.Policy b) (k : Nat) :
    Matrix ((s (b := b) k).I) ((s (b := b) k).I) ℝ :=
  PillarA.OQS.Split.DtNStabilized.LII_stabilized
    (s := s (b := b) k) (p := p) (L := L (b := b) k)

noncomputable def dtn_stabilized_of_det
    (p : PillarA.LayerA.Policy b) (k : Nat)
    (hdet : (LII_stab (b := b) p k).det ≠ 0) :
    Matrix ((s (b := b) k).B) ((s (b := b) k).B) ℝ :=
  PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det
    (s := s (b := b) k) (p := p) (L := L (b := b) k) hdet

end DtNStabilized

end

end TreeOfCliques
end Ideal
end PillarA
