import Mathlib
import REALOQS.PillarA.Ideal.LCPMeasure
import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA
namespace Ideal

open scoped BigOperators

lemma eq_of_prefix_of_length_eq {α : Type} {a x : List α}
    (h : a <+: x) (ha : a.length = x.length) : a = x := by
  rcases h with ⟨t, rfl⟩
  have ha' : a.length = a.length + t.length := by
    simpa [List.length_append] using ha
  have htlen : t.length = 0 := by
    have : a.length + t.length = a.length + 0 := by
      simpa [Nat.add_zero] using ha'.symm
    exact Nat.add_left_cancel this
  have ht : t = [] := by
    exact (List.length_eq_zero_iff.mp htlen)
  subst ht
  simp

end Ideal
end PillarA
