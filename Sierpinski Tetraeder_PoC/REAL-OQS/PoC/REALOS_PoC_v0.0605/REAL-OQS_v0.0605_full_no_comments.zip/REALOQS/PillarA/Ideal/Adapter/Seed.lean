import Mathlib
import REALOQS.PillarA.Ideal.Substrate
import REALOQS.PillarA.Update.Seed

set_option autoImplicit false

namespace PillarA

namespace Ideal

namespace Adapter

open PillarA.Ideal

abbrev IdealSeedSpec (b : Nat) : Type := PillarA.Update.SeedSpec (Addr b)

end Adapter

end Ideal

end PillarA
