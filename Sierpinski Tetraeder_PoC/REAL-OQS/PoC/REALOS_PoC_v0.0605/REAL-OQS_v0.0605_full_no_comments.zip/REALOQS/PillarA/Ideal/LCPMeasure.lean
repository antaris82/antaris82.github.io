import Mathlib
import REALOQS.PillarA.Ideal.Substrate

set_option linter.style.longLine false

namespace PillarA
namespace Ideal

open PillarA.Ideal

section LCP

variable {b : Nat}

def lcp : Addr b → Addr b → Addr b
| [], _ => []
| _, [] => []
| (a::as), (x::xs) =>
    if _h : a = x then a :: lcp as xs else []

theorem gate_lcp_prefix_left (u v : Addr b) : lcp (b := b) u v <+: u := by
  induction u generalizing v with
  | nil =>
      simp [lcp]
  | cons a as ih =>
      cases v with
      | nil =>
          simp [lcp]
      | cons x xs =>
          by_cases h : a = x
          · subst h
            have htail : lcp (b := b) as xs <+: as := ih xs
            rcases htail with ⟨t, ht⟩
            refine ⟨t, ?_⟩
            simp [lcp, ht]
          · simp [lcp, h]

theorem gate_lcp_prefix_right (u v : Addr b) : lcp (b := b) u v <+: v := by
  induction u generalizing v with
  | nil =>
      cases v <;> simp [lcp]
  | cons a as ih =>
      cases v with
      | nil => simp [lcp]
      | cons x xs =>
          by_cases h : a = x
          · subst h
            have htail : lcp (b := b) as xs <+: xs := ih xs
            rcases htail with ⟨t, ht⟩
            refine ⟨t, ?_⟩
            simp [lcp, ht]
          · simp [lcp, h]

theorem gate_lcp_comm (u v : Addr b) : lcp (b := b) u v = lcp (b := b) v u := by
induction u generalizing v with
| nil =>
    cases v <;> simp [lcp]
| cons a as ih =>
    cases v with
    | nil =>
        simp [lcp]
    | cons x xs =>
        by_cases h : a = x
        · subst h
          simp [lcp, ih]
        · have hx : x ≠ a := by
            intro hxEq
            exact h hxEq.symm
          simp [lcp, h, hx]

theorem gate_lcp_length_le_left (u v : Addr b) : (lcp (b := b) u v).length ≤ u.length := by
  exact (gate_lcp_prefix_left (b := b) u v).length_le

theorem gate_lcp_length_le_right (u v : Addr b) : (lcp (b := b) u v).length ≤ v.length := by
  exact (gate_lcp_prefix_right (b := b) u v).length_le

theorem gate_lcp_maximal (u v w : Addr b) :
    (w <+: u ∧ w <+: v) → w <+: lcp (b := b) u v := by
  intro hw
  induction w generalizing u v with
  | nil =>
      refine ⟨lcp (b := b) u v, by simp⟩
  | cons a ws ih =>
      rcases hw.1 with ⟨t1, rfl⟩
      rcases hw.2 with ⟨t2, rfl⟩
      have hws : ws <+: lcp (b := b) (ws ++ t1) (ws ++ t2) := by
        have hws1 : ws <+: ws ++ t1 := ⟨t1, by simp⟩
        have hws2 : ws <+: ws ++ t2 := ⟨t2, by simp⟩
        exact ih (u := ws ++ t1) (v := ws ++ t2) ⟨hws1, hws2⟩
      rcases hws with ⟨t, ht⟩
      refine ⟨t, ?_⟩
      simp [lcp, ht]

structure Edge (b : Nat) where
  u : Addr b
  v : Addr b

def owner (e : Edge b) : Addr b := lcp (b := b) e.u e.v

theorem gate_owner_prefix_u (e : Edge b) : owner (b := b) e <+: e.u := by
  simpa [owner] using gate_lcp_prefix_left (b := b) e.u e.v

theorem gate_owner_prefix_v (e : Edge b) : owner (b := b) e <+: e.v := by
  simpa [owner] using gate_lcp_prefix_right (b := b) e.u e.v

def Edge.swap (e : Edge b) : Edge b := ⟨e.v, e.u⟩

theorem gate_owner_swap (e : Edge b) :
    owner (b := b) (Edge.swap (b := b) e) = owner (b := b) e := by
  simp [Edge.swap, owner, gate_lcp_comm]

theorem gate_owner_iff_commonPrefix (e : Edge b) (w : Addr b) :
    (w <+: owner (b := b) e) ↔ (w <+: e.u ∧ w <+: e.v) := by
  constructor
  · intro h
    constructor
    · exact h.trans (gate_owner_prefix_u (b := b) e)
    · exact h.trans (gate_owner_prefix_v (b := b) e)
  · intro hw
    simpa [owner] using gate_lcp_maximal (b := b) e.u e.v w hw

end LCP

end Ideal
end PillarA
