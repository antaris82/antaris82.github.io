import Mathlib

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u

class Substrate (Cell : Nat → Type u) : Type (u + 1) where
  instDecEq : ∀ L : Nat, DecidableEq (Cell L)
  instFintype : ∀ L : Nat, Fintype (Cell L)
  parents : ∀ {L : Nat}, Cell (L + 1) → Finset (Cell L)
  children : ∀ {L : Nat}, Cell L → Finset (Cell (L + 1))

attribute [instance] Substrate.instDecEq
attribute [instance] Substrate.instFintype

namespace Substrate

variable {Cell : Nat → Type u} [Substrate Cell]

def ParentRel {L : Nat} (c : Cell (L + 1)) (p : Cell L) : Prop :=
  p ∈ Substrate.parents c

def ChildRel {L : Nat} (p : Cell L) (c : Cell (L + 1)) : Prop :=
  c ∈ Substrate.children p

def refineSet {L : Nat} (S : Finset (Cell L)) : Finset (Cell (L + 1)) :=
  S.biUnion (fun c => Substrate.children c)

def coarsenSet {L : Nat} (S : Finset (Cell (L + 1))) : Finset (Cell L) :=
  S.biUnion (fun c => Substrate.parents c)

theorem refineSet_mono {L : Nat} {S T : Finset (Cell L)} (h : S ⊆ T) :
    refineSet (Cell := Cell) S ⊆ refineSet (Cell := Cell) T := by
  intro x hx
  rcases Finset.mem_biUnion.mp hx with ⟨c, hcS, hxchild⟩
  exact Finset.mem_biUnion.mpr ⟨c, h hcS, hxchild⟩

theorem coarsenSet_mono {L : Nat} {S T : Finset (Cell (L + 1))} (h : S ⊆ T) :
    coarsenSet (Cell := Cell) S ⊆ coarsenSet (Cell := Cell) T := by
  intro x hx
  rcases Finset.mem_biUnion.mp hx with ⟨c, hcS, hxpar⟩
  exact Finset.mem_biUnion.mpr ⟨c, h hcS, hxpar⟩

end Substrate

class DeterministicSubstrate (Cell : Nat → Type u) [Substrate Cell] : Type (u + 1) where
  parent : ∀ {L : Nat}, Cell (L + 1) → Cell L
  parents_eq_singleton_parent :
    ∀ {L : Nat} (c : Cell (L + 1)),
      Substrate.parents c = {parent c}

namespace DeterministicSubstrate

variable {Cell : Nat → Type u} [Substrate Cell] [DeterministicSubstrate Cell]

theorem parent_mem_parents {L : Nat} (c : Cell (L + 1)) :
    (DeterministicSubstrate.parent (Cell := Cell) c) ∈ Substrate.parents c := by
  simp [DeterministicSubstrate.parents_eq_singleton_parent (Cell := Cell) c]

end DeterministicSubstrate

end LayerA

end PillarA
