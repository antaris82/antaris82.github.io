import Mathlib
import REALOQS.PillarA.Core.BInterfaces.ChannelNet

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v w

open scoped BigOperators

variable {Ω : Type u}

structure RelativeEntropyHook (CN : ChannelNet (Ω := Ω)) where
  D : ∀ {r : CN.RN.Region}, CN.Obj r → CN.Obj r → ENNReal
  self : ∀ {r : CN.RN.Region} (ρ : CN.Obj r), D ρ ρ = 0
  dpi : ∀ {a b : CN.RN.Region} (hab : a ≤ b) (Φ : CN.Chan hab) (ρ σ : CN.Obj b),
    D (CN.apply (a := a) (b := b) hab Φ ρ) (CN.apply (a := a) (b := b) hab Φ σ) ≤ D ρ σ

namespace RelativeEntropyHook

variable (CN : ChannelNet (Ω := Ω)) (H : RelativeEntropyHook (CN := CN))

theorem gate_QRE_self {r : CN.RN.Region} (ρ : CN.Obj r) : H.D ρ ρ = 0 := H.self ρ

theorem gate_QRE_DPI {a b : CN.RN.Region} (hab : a ≤ b) (Φ : CN.Chan hab) (ρ σ : CN.Obj b) :
    H.D (CN.apply (a := a) (b := b) hab Φ ρ) (CN.apply (a := a) (b := b) hab Φ σ) ≤ H.D ρ σ :=
  H.dpi hab Φ ρ σ

end RelativeEntropyHook

end LayerA
end PillarA
