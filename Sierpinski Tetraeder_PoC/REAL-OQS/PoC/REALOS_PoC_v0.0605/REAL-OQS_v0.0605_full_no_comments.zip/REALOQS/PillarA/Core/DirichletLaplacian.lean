import REALOQS.PillarA.Core.Gates

set_option linter.style.longLine false

set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace LayerA

section Dirichlet

variable {V : Type} [Fintype V] [DecidableEq V]

def offDiag (c : Weight V) (i j : V) : ℝ := if j = i then 0 else c i j

noncomputable def dirichletEnergy (c : Weight V) (f : V → ℝ) : ℝ :=
  (1 / 2 : ℝ) * ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j)^2

def quadForm (Λ : Matrix V V ℝ) (f : V → ℝ) : ℝ :=
  ∑ i, f i * (Λ.mulVec f) i

def Sii (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f i) ^ 2

def Sij (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f i) * (f j)

def Sjj (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f j) ^ 2

lemma degree_eq_sum_offDiag (c : Weight V) (i : V) :
    degree c i = ∑ j : V, offDiag c i j := by
  simp [degree, offDiag]

lemma Sii_eq_degree (c : Weight V) (f : V → ℝ) :
    Sii c f = ∑ i : V, (degree c i) * (f i) ^ 2 := by
  classical
  simp [PillarA.LayerA.Sii, PillarA.LayerA.degree];
  simp [PillarA.LayerA.offDiag];
  simp [mul_comm, Finset.mul_sum]

omit [Fintype V] in
lemma offDiag_symm_of_symm
    (c : Weight V) (hsymm : ∀ i j, c i j = c j i) (i j : V) :
    offDiag c i j = offDiag c j i := by
  by_cases h : j = i
  · subst h; simp [offDiag]
  · have h' : i ≠ j := by exact ne_comm.mp h
    simp [offDiag, h, h', hsymm]

lemma Sjj_eq_degree_of_symm
    (c : Weight V) (hsymm : ∀ i j, c i j = c j i) (f : V → ℝ) :
    Sjj c f = ∑ j : V, (degree c j) * (f j) ^ 2 := by
  classical
  have h_sum_eq : ∑ j, ∑ i, offDiag c i j * (f j) ^ 2 = ∑ j, (degree c j) * (f j) ^ 2 := by
    simp [offDiag];
    exact Finset.sum_congr rfl fun i hi => by
      rw [show PillarA.LayerA.degree c i = ∑ j : V, if j = i then 0 else c i j by rfl]
      rw [Finset.sum_mul _ _ _]
      exact Finset.sum_congr rfl fun j hj => by aesop
  have h_sum_eq : ∑ i, ∑ j, offDiag c i j * (f j) ^ 2 = ∑ j, ∑ i, offDiag c i j * (f j) ^ 2 := by
    exact Finset.sum_comm;
  convert h_sum_eq.trans ‹_› using 1

lemma dirichletEnergy_expand (c : Weight V) (f : V → ℝ) :
    dirichletEnergy c f = (1 / 2 : ℝ) * (Sii c f - 2 * Sij c f + Sjj c f) := by
  classical
  have h_expand :
      ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2 =
        ∑ i : V, ∑ j : V, offDiag c i j * (f i) ^ 2 -
          2 * ∑ i : V, ∑ j : V, offDiag c i j * (f i) * (f j) +
            ∑ i : V, ∑ j : V, offDiag c i j * (f j) ^ 2 := by
    simp +decide only [sub_sq, mul_assoc, mul_left_comm, Finset.mul_sum _ _ _];
    simp [mul_sub, mul_add, Finset.sum_add_distrib, Finset.sum_sub_distrib];
    simp [mul_assoc, mul_comm, mul_left_comm];
  convert congr_arg ( fun x : ℝ => ( 1 / 2 : ℝ ) * x ) h_expand using 1

lemma quadForm_laplacian_eq_degree_sub_Sij (c : Weight V) (f : V → ℝ) :
    quadForm (laplacian c) f
      = (∑ i : V, (degree c i) * (f i) ^ 2) - Sij c f := by
  classical
  have h_split : quadForm (laplacian c) f = ∑ i, f i * (∑ j, (laplacian c i j) * f j) := by
    exact rfl
  have h_split :
      ∑ i, f i * (∑ j, (laplacian c i j) * f j) =
        ∑ i, f i * (degree c i * f i - ∑ j, offDiag c i j * f j) := by
    congr with i
    simp +decide [PillarA.LayerA.laplacian, PillarA.LayerA.degree, PillarA.LayerA.offDiag]
    simp +decide [ Finset.sum_ite, Finset.filter_eq, Finset.filter_ne, sub_eq_add_neg ];
    simp +decide [ Finset.filter_ne' ];
    exact mul_eq_mul_left_iff.mp rfl
  have h_Sij : ∑ i, f i * (∑ j, offDiag c i j * f j) = Sij c f := by
    exact Finset.sum_congr rfl fun i hi => by
      rw [Finset.mul_sum _ _ _]
      exact Finset.sum_congr rfl fun j hj => by ring
  simp_all +decide [ mul_sub, mul_assoc, mul_comm, pow_two ]

theorem gate_DIRICHLET_EQ_LAPLACIAN_QUAD
    (c : Weight V)
    (hsymm : ∀ i j, c i j = c j i)
    (f : V → ℝ) :
    dirichletEnergy c f = quadForm (laplacian c) f := by
  classical
  have h_final :
      dirichletEnergy c f = (1 / 2 : ℝ) * (Sii c f - 2 * Sij c f + Sjj c f) ∧
        quadForm (laplacian c) f = (∑ i : V, (degree c i) * (f i) ^ 2) - Sij c f := by
    exact ⟨dirichletEnergy_expand c f, quadForm_laplacian_eq_degree_sub_Sij c f⟩
  linarith [ Sii_eq_degree c f, Sjj_eq_degree_of_symm c hsymm f ]

theorem gate_DIRICHLET_NONNEG
    (c : Weight V) (hnonneg : ∀ i j, 0 ≤ c i j) (f : V → ℝ) :
    0 ≤ dirichletEnergy c f := by
  classical
  unfold dirichletEnergy
  have hoff : ∀ i j, 0 ≤ offDiag c i j := by
    intro i j
    by_cases h : j = i
    · subst h; simp [offDiag]
    · simp [offDiag, h, hnonneg]
  have hterm : ∀ i j, 0 ≤ offDiag c i j * (f i - f j) ^ 2 := by
    intro i j
    exact mul_nonneg (hoff i j) (sq_nonneg (f i - f j))
  have : 0 ≤ ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2 := by
    refine Finset.sum_nonneg ?_
    intro i hi
    refine Finset.sum_nonneg ?_
    intro j hj
    exact hterm i j
  nlinarith

def clamp01 (x : ℝ) : ℝ := max (0 : ℝ) (min (1 : ℝ) x)

lemma clamp01_nonexpansive (x y : ℝ) : |clamp01 x - clamp01 y| ≤ |x - y| := by
  unfold PillarA.LayerA.clamp01;
  cases max_cases (0 : ℝ) (Min.min 1 x) <;>
    cases max_cases (0 : ℝ) (Min.min 1 y) <;>
    cases min_cases (1 : ℝ) x <;>
    cases min_cases (1 : ℝ) y <;>
    cases abs_cases (x - y) <;>
    cases abs_cases (Max.max 0 (Min.min 1 x) - Max.max 0 (Min.min 1 y)) <;>
    linarith

lemma clamp01_sq_le (x y : ℝ) : (clamp01 x - clamp01 y) ^ 2 ≤ (x - y) ^ 2 := by
  simpa [sq_le_sq] using (clamp01_nonexpansive (x := x) (y := y))

class DirichletMarkovHook (c : Weight V) : Prop where
  markov_clamp01 : ∀ f : V → ℝ,
    dirichletEnergy c (fun v => clamp01 (f v)) ≤ dirichletEnergy c f

theorem gate_DIRICHLET_MARKOV_CLAMP01
    (c : Weight V) [DirichletMarkovHook (c := c)] (f : V → ℝ) :
    dirichletEnergy c (fun v => clamp01 (f v)) ≤ dirichletEnergy c f :=
  DirichletMarkovHook.markov_clamp01 (c := c) f

def DirichletMarkovHook.mkOfNonneg (c : Weight V) (h : ∀ i j, 0 ≤ c i j) :
    DirichletMarkovHook (c := c) := by
  classical
  refine ⟨?_⟩
  intro f
  unfold dirichletEnergy
  have hoff : ∀ i j, 0 ≤ offDiag c i j := by
    intro i j
    by_cases hji : j = i
    · subst hji; simp [offDiag]
    · simpa [offDiag, hji] using h i j
  have hterm : ∀ i j,
      offDiag c i j * (clamp01 (f i) - clamp01 (f j)) ^ 2
        ≤ offDiag c i j * (f i - f j) ^ 2 := by
    intro i j
    exact mul_le_mul_of_nonneg_left (clamp01_sq_le (x := f i) (y := f j)) (hoff i j)
  have hsum :
      (∑ i : V, ∑ j : V, offDiag c i j * (clamp01 (f i) - clamp01 (f j)) ^ 2)
        ≤ (∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2) := by
    refine Finset.sum_le_sum ?_
    intro i hi
    refine Finset.sum_le_sum ?_
    intro j hj
    simpa using hterm i j
  have hhalf : 0 ≤ (1 / 2 : ℝ) := by norm_num
  exact mul_le_mul_of_nonneg_left hsum hhalf

end Dirichlet

end LayerA

end PillarA
