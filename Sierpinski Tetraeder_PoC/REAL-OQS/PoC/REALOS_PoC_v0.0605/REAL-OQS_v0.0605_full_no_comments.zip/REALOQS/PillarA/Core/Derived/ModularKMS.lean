import Mathlib.Data.Complex.Basic
import REALOQS.PillarA.Core.ToC.AQFTSubstrate

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

class HasDerivedModularKMS (A : Type u) where
  StateOn : Type u
  isState : StateOn → Prop
  mkModularKMSData : ∀ ω : StateOn, isState ω → Type u

end Derived
end PillarA
