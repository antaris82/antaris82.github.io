import REALOQS.PillarA.Core.RegionNet

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v w

structure LocalAlgebraNet (Ω : Type u) where
  RN : RegionNet Ω
  Alg : RN.Region → Type v
  incl : ∀ {a b : RN.Region}, a ≤ b → Alg a → Alg b
  incl_id : ∀ (a : RN.Region) (x : Alg a), incl (a := a) (b := a) (le_rfl) x = x
  incl_comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) (x : Alg a),
    incl (a := b) (b := c) hbc (incl (a := a) (b := b) hab x) =
      incl (a := a) (b := c) (le_trans hab hbc) x

namespace LocalAlgebraNet

variable {Ω : Type u} (LAN : LocalAlgebraNet (Ω := Ω))

instance : SemilatticeSup LAN.RN.Region := by
  infer_instance

theorem gate_ALG_include_id (a : LAN.RN.Region) (x : LAN.Alg a) :
    LAN.incl (a := a) (b := a) (le_rfl) x = x :=
  LAN.incl_id a x

theorem gate_ALG_include_comp {a b c : LAN.RN.Region}
    (hab : a ≤ b) (hbc : b ≤ c) (x : LAN.Alg a) :
    LAN.incl (a := b) (b := c) hbc (LAN.incl (a := a) (b := b) hab x) =
      LAN.incl (a := a) (b := c) (le_trans hab hbc) x :=
  LAN.incl_comp hab hbc x

end LocalAlgebraNet

end LayerA
end PillarA
