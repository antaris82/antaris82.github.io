import Mathlib

set_option linter.style.commandStart false

namespace PillarA
namespace LayerA

section Resistance

variable {V : Type}

abbrev RInf := ENNReal

structure ResistanceMetric (V : Type) where
  R : V → V → RInf
  symm : ∀ u v, R u v = R v u
  self : ∀ u, R u u = 0

noncomputable def dist (rm : ResistanceMetric V) (u v : V) : RInf :=
  (rm.R u v) ^ ((1 : ℝ) / 2)

theorem gate_dist_self (rm : ResistanceMetric V) (u : V) : dist rm u u = 0 := by
  simp [dist, rm.self u]

theorem gate_dist_symm (rm : ResistanceMetric V) (u v : V) : dist rm u v = dist rm v u := by
  simp [dist, rm.symm u v]

def finiteR (rm : ResistanceMetric V) (u v : V) : Prop := rm.R u v ≠ (⊤ : RInf)

structure ResistanceMetricLaws (rm : ResistanceMetric V) : Prop where

  triangle : ∀ u v w : V, dist rm u w ≤ dist rm u v + dist rm v w

  eq_of_dist_eq_zero : ∀ {u v : V}, dist rm u v = 0 → u = v

end Resistance

end LayerA
end PillarA
