import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.BoundaryPorts
import REALOQS.PillarA.Core.SymmetryAction
import REALOQS.PillarA.Core.TailInterface

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v w

open TailInterface TailEliminationHook

class TailProject (Cell : Nat → Type u) [TailInterface (Cell := Cell)] where
  down : ∀ {L : Nat}, TailAt (Cell := Cell) (L + 1) → TailAt (Cell := Cell) L

class EBDProject (Cell : Nat → Type u)
    [TailInterface (Cell := Cell)] [TailEliminationHook (Cell := Cell)] where
  downEBD : ∀ {L : Nat}, EBD (Cell := Cell) (L + 1) → EBD (Cell := Cell) L

structure TailEliminationCoherence (Cell : Nat → Type u)
    [Substrate Cell]
    [TailInterface (Cell := Cell)]
    [TailEliminationHook (Cell := Cell)]
    [TailProject (Cell := Cell)]
    [EBDProject (Cell := Cell)] where
  coherent_succ :
    ∀ {L : Nat} [DecidableEq (Cell L)],
      (A : Approximant Cell L) →
      (t : TailAt (Cell := Cell) (L + 1)) →
      (bp : BoundaryPorts Cell L) →
      EBDProject.downEBD (Cell := Cell)
          (L := L)
          (TailEliminationHook.eliminate
            (Cell := Cell)
            (L := L + 1)
            (Approximant.refine (Cell := Cell) A)
            t
            (BoundaryPorts.refine (Cell := Cell) (L := L) bp))
        =
        TailEliminationHook.eliminate
          (Cell := Cell)
          (L := L)
          A
          (TailProject.down (Cell := Cell) (L := L) t)
          bp

namespace TailEliminationCoherence

variable {Cell : Nat → Type u}
  [Substrate Cell]
  [TailInterface (Cell := Cell)]
  [TailEliminationHook (Cell := Cell)]
  [TailProject (Cell := Cell)]
  [EBDProject (Cell := Cell)]

theorem gate_TAIL_coherent_succ
    (C : TailEliminationCoherence (Cell := Cell))
    {L : Nat} [DecidableEq (Cell L)]
    (A : Approximant Cell L)
    (t : TailAt (Cell := Cell) (L + 1))
    (bp : BoundaryPorts Cell L) :
    EBDProject.downEBD (Cell := Cell)
        (L := L)
        (TailEliminationHook.eliminate
          (Cell := Cell)
          (L := L + 1)
          (Approximant.refine (Cell := Cell) A)
          t
          (BoundaryPorts.refine (Cell := Cell) (L := L) bp))
      =
      TailEliminationHook.eliminate
        (Cell := Cell)
        (L := L)
        A
        (TailProject.down (Cell := Cell) (L := L) t)
        bp :=
  C.coherent_succ (A := A) (t := t) (bp := bp)

end TailEliminationCoherence

namespace TailEliminationEquivariance

open SymmetryAction

variable {Cell : Nat → Type u}
  [Substrate Cell]
  [TailInterface (Cell := Cell)]
  [TailEliminationHook (Cell := Cell)]

theorem gate_TAIL_ELIMINATION_EQUIVARIANT
    (S : SymmetryAction (Cell := Cell))
    (Eqv : SymmetryAction.TailEliminationEquivariant (Cell := Cell) S)
    {L : Nat} [DecidableEq (Cell L)]
    (g : S.G) (A : Approximant Cell L)
    (T : TailInterface.TailAt (Cell := Cell) L)
    (bp : BoundaryPorts Cell L) :
    Eqv.actEBD (L := L) g (TailEliminationHook.eliminate (Cell := Cell) A T bp)
      =
      TailEliminationHook.eliminate (Cell := Cell)
        (SymmetryAction.actApproximant (Cell := Cell) S (L := L) g A)
        (Eqv.actTail (L := L) g T)
        (SymmetryAction.actBoundaryPorts (Cell := Cell) S (L := L) g bp) :=
  Eqv.eliminate_equivariant (L := L) g A T bp

end TailEliminationEquivariance

end LayerA
end PillarA
