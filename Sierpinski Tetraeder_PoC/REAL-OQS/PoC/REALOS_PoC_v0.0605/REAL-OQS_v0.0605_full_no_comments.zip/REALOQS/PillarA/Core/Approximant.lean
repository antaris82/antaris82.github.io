import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u

structure Approximant (Cell : Nat → Type u) (L : Nat) where
  cells : Finset (Cell L)

namespace Approximant

variable {Cell : Nat → Type u} {L : Nat}

instance : Coe (Approximant Cell L) (Finset (Cell L)) := ⟨Approximant.cells⟩

@[simp] theorem coe_cells (A : Approximant Cell L) : (A : Finset (Cell L)) = A.cells := rfl

def card (A : Approximant Cell L) : Nat := A.cells.card

def full (Cell : Nat → Type u) (L : Nat) [Substrate Cell] : Approximant Cell L :=
  ⟨Finset.univ⟩

def refine [Substrate Cell] (A : Approximant Cell L) : Approximant Cell (L + 1) :=
  ⟨Substrate.refineSet (Cell := Cell) A.cells⟩

def coarsen [Substrate Cell] (A : Approximant Cell (L + 1)) : Approximant Cell L :=
  ⟨Substrate.coarsenSet (Cell := Cell) A.cells⟩

end Approximant

end LayerA

end PillarA
