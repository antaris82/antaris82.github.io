import REALOQS.PillarA.Core.InfiniteCarrierSymmetry
import REALOQS.PillarA.Core.RegionCore

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u

open RegionCore

namespace CylinderSets

variable {Cell : Nat → Type u} [Substrate Cell]

def cyl {L : Nat} (R : RegionAt Cell L) : Set (InfiniteCarrier (Cell := Cell)) :=
  fun U => U.cell L ∈ R

@[simp] theorem mem_cyl {L : Nat} (U : InfiniteCarrier (Cell := Cell)) (R : RegionAt Cell L) :
    U ∈ cyl (Cell := Cell) R ↔ U.cell L ∈ R := Iff.rfl

theorem cyl_mono {L : Nat} {R R' : RegionAt Cell L} (h : R ⊆ R') :
    cyl (Cell := Cell) R ⊆ cyl (Cell := Cell) R' := by
  intro U hU
  exact h hU

open SymmetryAction

private theorem act_inv_act
    {L : Nat} (S : SymmetryAction (Cell := Cell)) (g : S.G) (x : Cell L) :
    S.act (L := L) (g⁻¹) (S.act (L := L) g x) = x := by
  have hmul := S.act_mul (L := L) (g := g⁻¹) (h := g) x

  calc
    S.act (L := L) (g⁻¹) (S.act (L := L) g x)
        = S.act (L := L) (g⁻¹ * g) x := by
            exact hmul.symm
    _ = S.act (L := L) (1 : S.G) x := by
          simp
    _ = x := by
          simp [S.act_one]

private theorem act_act_inv
    {L : Nat} (S : SymmetryAction (Cell := Cell)) (g : S.G) (x : Cell L) :
    S.act (L := L) g (S.act (L := L) (g⁻¹) x) = x := by
  have hmul := S.act_mul (L := L) (g := g) (h := g⁻¹) x

  calc
    S.act (L := L) g (S.act (L := L) (g⁻¹) x)
        = S.act (L := L) (g * g⁻¹) x := by
            exact hmul.symm
    _ = S.act (L := L) (1 : S.G) x := by
          simp
    _ = x := by
          simp [S.act_one]

theorem cyl_actRegion_preimage
    {L : Nat} (S : SymmetryAction (Cell := Cell)) [DecidableEq (Cell L)]
    (g : S.G) (R : RegionAt Cell L) :
    cyl (Cell := Cell) (actRegion (Cell := Cell) S (L := L) g R)
      = (fun U => S.actInf (Cell := Cell) (g⁻¹) U) ⁻¹' (cyl (Cell := Cell) R) := by
  ext U
  constructor
  · intro h

    rcases Finset.mem_image.1 h with ⟨x, hxR, hx⟩
    have hx' : S.act (L := L) (g⁻¹) (U.cell L) = x := by
      calc
        S.act (L := L) (g⁻¹) (U.cell L)
            = S.act (L := L) (g⁻¹) (S.act (L := L) g x) := by

                simp [hx.symm]
        _ = x := act_inv_act (Cell := Cell) (L := L) S g x
    have hpre : S.act (L := L) (g⁻¹) (U.cell L) ∈ R := by

      rw [hx']
      exact hxR

    simp [SymmetryAction.actInf]
    exact hpre
  · intro h

    have h' : U ∈ (fun U => S.actInf (Cell := Cell) (g⁻¹) U) ⁻¹' cyl (Cell := Cell) R := h

    simp [SymmetryAction.actInf] at h'
    have hxR : S.act (L := L) (g⁻¹) (U.cell L) ∈ R := by
      exact h'
    refine Finset.mem_image.2 ?_
    refine ⟨S.act (L := L) (g⁻¹) (U.cell L), hxR, ?_⟩

    exact (act_act_inv (Cell := Cell) (L := L) S g (U.cell L))

end CylinderSets

end LayerA
end PillarA
