import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.BoundaryPorts

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u v

class TailInterface (Cell : Nat → Type u) where
  Tail : Nat → Type v

namespace TailInterface

variable {Cell : Nat → Type u} [TailInterface (Cell := Cell)]

abbrev TailAt (L : Nat) : Type v := TailInterface.Tail (Cell := Cell) L

end TailInterface

class TailEliminationHook (Cell : Nat → Type u) [TailInterface (Cell := Cell)] where
  EffectiveBoundaryData : Nat → Type v
  eliminate : ∀ {L : Nat} [DecidableEq (Cell L)],
    Approximant Cell L → TailInterface.TailAt (Cell := Cell) L →
    BoundaryPorts Cell L → EffectiveBoundaryData L

namespace TailEliminationHook

variable {Cell : Nat → Type u} [TailInterface (Cell := Cell)] [TailEliminationHook (Cell := Cell)]

abbrev EBD (L : Nat) : Type v := TailEliminationHook.EffectiveBoundaryData (Cell := Cell) L

end TailEliminationHook

end LayerA

end PillarA
