import Mathlib
import REALOQS.PillarA.Core.Policy

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA

namespace LayerA

namespace Determinism

inductive Level where
  | D0 : Level
  | D1 : Level
  deriving DecidableEq, Repr

variable {b : Nat}

structure PolicyHash (b : Nat) where
  hash : Policy b → Nat
  depends_only_on_key : ∀ p q : Policy b, Policy.key p = Policy.key q → hash p = hash q
  key_of_hash : ∀ p q : Policy b, hash p = hash q → Policy.key p = Policy.key q

theorem gate_D0_DERIVED_PARAMS_OF_KEY (p q : Policy b)
    (hkey : Policy.key p = Policy.key q) :
    (Policy.K_max p = Policy.K_max q) ∧
    (Policy.eps0 p = Policy.eps0 q) ∧
    (Policy.alphaDenom p = Policy.alphaDenom q) ∧
    (∀ k, Policy.alpha p k = Policy.alpha q k) := by
  have hpq : p = q := Policy.key_injective (b := b) hkey
  simpa using (Policy.gate_POLICY_derived_stable (b := b) (p := p) (q := q) hpq)

theorem gate_POLICY_HASH_STABLE (H : PolicyHash b) (p q : Policy b) :
    (Policy.key p = Policy.key q → H.hash p = H.hash q) ∧
    (H.hash p = H.hash q → Policy.key p = Policy.key q) := by
  refine ⟨?_, ?_⟩
  · intro h; exact H.depends_only_on_key p q h
  · intro h; exact H.key_of_hash p q h

structure ExportBundle where
  payload : String

structure Exporter (b : Nat) (Artifact : Type) where
  emit : Policy b → Nat → Artifact → ExportBundle

class ExportLaws {Artifact : Type} (E : Exporter b Artifact) : Prop where
  depends_only_on_key :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a

theorem gate_D1_EXPORT_DEPENDS_ONLY_ON_KEY {Artifact : Type} (E : Exporter b Artifact)
    [ExportLaws (b := b) E] :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a :=
  ExportLaws.depends_only_on_key (E := E)

def ExportLaws.mkOfKeyInvariant {Artifact : Type} (E : Exporter b Artifact)
    (h : ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a) :
    ExportLaws (b := b) E :=
  ⟨h⟩

end Determinism

end LayerA

end PillarA
