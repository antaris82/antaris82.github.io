import Mathlib

set_option linter.style.longLine false

set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace LayerA

section Laplacian

variable {V : Type} [Fintype V] [DecidableEq V]

abbrev Weight (V : Type) := V → V → ℝ

def degree (c : Weight V) (i : V) : ℝ := ∑ j : V, if j = i then 0 else c i j

def laplacian (c : Weight V) : Matrix V V ℝ := fun i j => if i = j then degree c i else - c i j

def AdmissibleOp (Λ : Matrix V V ℝ) : Prop := Matrix.transpose Λ = Λ ∧
  (∀ i : V, (∑ j : V, Λ i j) = 0) ∧
  (∀ i j : V, i ≠ j → Λ i j ≤ 0)

theorem laplacian_is_symmetric_of_symm
    (c : Weight V)
    (hsymm : ∀ i j, c i j = c j i) :
    Matrix.transpose (laplacian c) = laplacian c := by
  ext i j; simp [PillarA.LayerA.laplacian, hsymm];
  simp [eq_comm];
  by_cases hij : i = j <;> simp [hij]

theorem laplacian_rowSum_zero (c : Weight V) :
    ∀ i : V, (∑ j : V, laplacian c i j) = 0 := by
  intro i
  simp [PillarA.LayerA.laplacian, PillarA.LayerA.degree];
  simp [Finset.sum_ite, Finset.filter_ne];
  have h_split : ∑ x : V, c i x = c i i + ∑ x : V with ¬x = i, c i x := by
    rw [ Finset.sum_eq_add_sum_diff_singleton ( Finset.mem_univ i ) ];
    rw [ Finset.sdiff_singleton_eq_erase, Finset.filter_ne' ];
  simp [h_split, Finset.card_filter]

theorem gate_LAPLACIAN_ADMISSIBLE
    (c : Weight V)
    (hsymm : ∀ i j, c i j = c j i)
    (hnonneg : ∀ i j, 0 ≤ c i j) :
    AdmissibleOp (laplacian c) := by

  constructor;
  · unfold PillarA.LayerA.laplacian; ext i j; aesop;
  · have h_off_diag :
      ∀ i j : V, i ≠ j → laplacian c i j ≤ 0 := by
      intros i j hij
      simp [laplacian, hij, hnonneg];
    exact ⟨ by simpa [ hsymm ] using laplacian_rowSum_zero c, h_off_diag ⟩

end Laplacian

section Fold

variable {V B : Type} [Fintype V] [Fintype B] [DecidableEq V]

def embedMatBV (σ : B → V) : Matrix V B ℝ := fun v b => if v = σ b then (1 : ℝ) else 0

def FoldBV (σ : B → V) (Λ : Matrix B B ℝ) : Matrix V V ℝ :=
  (embedMatBV σ) * Λ * Matrix.transpose (embedMatBV σ)

theorem gate_LAPLACIAN_FOLD
    (σ : B → V) (Λ : Matrix B B ℝ)
    (hΛ : AdmissibleOp (V := B) Λ) :
    AdmissibleOp (V := V) (FoldBV σ Λ) := by

  constructor
  · unfold PillarA.LayerA.FoldBV
    simp +decide [Matrix.transpose_mul]
    rw [Matrix.mul_assoc, hΛ.1]
  · constructor
    · intro i
      simp [PillarA.LayerA.FoldBV, Matrix.mul_apply, Matrix.transpose_apply]
      rw [Finset.sum_comm]
      simp +decide [Finset.sum_ite, PillarA.LayerA.embedMatBV]
      rw [Finset.sum_comm]
      exact Finset.sum_eq_zero (fun y hy => hΛ.2.1 y)
    · have h_expand :
          ∀ i j,
            (FoldBV σ Λ) i j =
              ∑ b₁, ∑ b₂,
                (if i = σ b₁ then 1 else 0) * Λ b₁ b₂ * (if j = σ b₂ then 1 else 0) := by
        intro i j
        simp [FoldBV, Matrix.mul_apply]
        simp +decide [PillarA.LayerA.embedMatBV, Finset.sum_mul _ _ _]
        rw [Finset.sum_comm]
        congr
        ext
        aesop
      intro i j hij
      rw [h_expand i j]
      refine Finset.sum_nonpos (fun b₁ _ => ?_)
      refine Finset.sum_nonpos (fun b₂ _ => ?_)
      by_cases hi : i = σ b₁ <;> by_cases hj : j = σ b₂ <;> simp_all +decide
      exact hΛ.2.2 _ _ (by aesop)
end Fold

section TwoSidedInv

variable {ι : Type} [Fintype ι] [DecidableEq ι]

abbrev TwoSidedInv (A Ainv : Matrix ι ι ℝ) : Prop := (Ainv * A = 1) ∧ (A * Ainv = 1)

theorem gate_DTN_WELLPOSED
    (A : Matrix ι ι ℝ)
    (hdet : A.det ≠ 0) :
    ∃ Ainv : Matrix ι ι ℝ, TwoSidedInv A Ainv := by

  obtain ⟨Ainv, hAinv⟩ : ∃ Ainv : Matrix ι ι ℝ, A * Ainv = 1 ∧ Ainv * A = 1 := by
    use A⁻¹;
    simp [Matrix.mul_nonsing_inv, Matrix.nonsing_inv_mul, hdet];
  grind

theorem gate_DTN_WELLPOSED_canonical
    (A : Matrix ι ι ℝ)
    (hdet : A.det ≠ 0) :
    TwoSidedInv A A⁻¹ := by
  constructor <;>
    simp [Matrix.mul_nonsing_inv, Matrix.nonsing_inv_mul, hdet]

end TwoSidedInv

section DtN

variable {B I : Type} [Fintype I] [DecidableEq I]

def DtN
    (LBB : Matrix B B ℝ) (LBI : Matrix B I ℝ) (LIB : Matrix I B ℝ)
    (LIIinv : Matrix I I ℝ) : Matrix B B ℝ := LBB - (LBI * LIIinv * LIB)

def concatCols {I₁ I₂ : Type} [Fintype I₁] [Fintype I₂] [DecidableEq I₁] [DecidableEq I₂]
    (LB1 : Matrix B I₁ ℝ) (LB2 : Matrix B I₂ ℝ) : Matrix B (Sum I₁ I₂) ℝ := fun b i =>
    match i with
    | Sum.inl i1 => LB1 b i1
    | Sum.inr i2 => LB2 b i2

def concatRows {I₁ I₂ : Type} [Fintype I₁] [Fintype I₂] [DecidableEq I₁] [DecidableEq I₂]
    (L1B : Matrix I₁ B ℝ) (L2B : Matrix I₂ B ℝ) : Matrix (Sum I₁ I₂) B ℝ := fun i b =>
    match i with
    | Sum.inl i1 => L1B i1 b
    | Sum.inr i2 => L2B i2 b

def blockDiag {I₁ I₂ : Type} [Fintype I₁] [Fintype I₂] [DecidableEq I₁] [DecidableEq I₂]
    (A : Matrix I₁ I₁ ℝ) (B' : Matrix I₂ I₂ ℝ) :
    Matrix (Sum I₁ I₂) (Sum I₁ I₂) ℝ := fun i j =>
    match i, j with
    | Sum.inl i1, Sum.inl j1 => A i1 j1
    | Sum.inr i2, Sum.inr j2 => B' i2 j2
    | _, _ => 0

theorem gate_GLUE_BW_IDENTITY
    {I₁ I₂ : Type} [Fintype I₁] [Fintype I₂] [DecidableEq I₁] [DecidableEq I₂]
    (LBB : Matrix B B ℝ)
    (LB1 : Matrix B I₁ ℝ) (LB2 : Matrix B I₂ ℝ)
    (L1B : Matrix I₁ B ℝ) (L2B : Matrix I₂ B ℝ)
    (L11inv : Matrix I₁ I₁ ℝ) (L22inv : Matrix I₂ I₂ ℝ) :
    DtN (B := B) (I := Sum I₁ I₂)
        LBB
        (concatCols (B := B) LB1 LB2)
        (concatRows (B := B) L1B L2B)
        (blockDiag L11inv L22inv)
      =
    (LBB - (LB1 * L11inv * L1B) - (LB2 * L22inv * L2B)) := by

  ext i j
  unfold PillarA.LayerA.DtN
  unfold PillarA.LayerA.concatCols PillarA.LayerA.concatRows PillarA.LayerA.blockDiag
  simp +decide [Matrix.mul_apply, sub_sub]

end DtN

end LayerA

end PillarA
