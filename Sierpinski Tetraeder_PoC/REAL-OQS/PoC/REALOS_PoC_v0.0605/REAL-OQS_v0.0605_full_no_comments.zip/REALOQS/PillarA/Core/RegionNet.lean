import Mathlib

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u v w

structure RegionNet (Ω : Type u) where
  Region : Type v

  instSup : SemilatticeSup Region

  top : Region
  le_top : (letI := instSup; ∀ a : Region, a ≤ top)
  carrier : Region → Set Ω
  carrier_mono : ∀ {a b : Region}, (letI := instSup; a ≤ b) → carrier a ⊆ carrier b

namespace RegionNet

variable {Ω : Type u}

instance (RN : RegionNet Ω) : SemilatticeSup RN.Region := RN.instSup

@[simp] theorem carrier_mono' (RN : RegionNet Ω) {a b : RN.Region} (hab : a ≤ b) :
    RN.carrier a ⊆ RN.carrier b := by
  simpa using RN.carrier_mono (a := a) (b := b) hab

theorem gate_REGION_le_refl (RN : RegionNet Ω) (a : RN.Region) : a ≤ a := by
  exact le_rfl

theorem gate_REGION_le_trans (RN : RegionNet Ω) {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) :
    a ≤ c := by
  exact le_trans hab hbc

theorem gate_REGION_le_antisymm (RN : RegionNet Ω) {a b : RN.Region} (hab : a ≤ b) (hba : b ≤ a) :
    a = b := by
  exact le_antisymm hab hba

theorem directed (RN : RegionNet Ω) :
    ∀ a b : RN.Region, ∃ c : RN.Region, a ≤ c ∧ b ≤ c := by
  intro a b
  refine ⟨a ⊔ b, ?_, ?_⟩
  · exact le_sup_left
  · exact le_sup_right

theorem gate_REGION_directed (RN : RegionNet Ω) (a b : RN.Region) :
    ∃ c : RN.Region, a ≤ c ∧ b ≤ c := directed (RN := RN) a b

theorem le_top' (RN : RegionNet Ω) (a : RN.Region) : a ≤ RN.top := by
  simpa using (RN.le_top a)

end RegionNet

structure RegionNetWithBoundary (Ω : Type u) where
  base : RegionNet Ω
  boundary : base.Region → base.Region
  boundary_mono : (letI := base.instSup; Monotone boundary)

namespace RegionNetWithBoundary

variable {Ω : Type u} (RNb : RegionNetWithBoundary Ω)

instance : SemilatticeSup RNb.base.Region := RNb.base.instSup

@[simp] theorem boundary_mono' {a b : RNb.base.Region} (hab : a ≤ b) :
    RNb.boundary a ≤ RNb.boundary b := (RNb.boundary_mono hab)

theorem gate_BOUNDARY_functorial {a b : RNb.base.Region} (hab : a ≤ b) :
    RNb.boundary a ≤ RNb.boundary b := boundary_mono' (RNb := RNb) hab

end RegionNetWithBoundary

structure RegionNetWithCompl (Ω : Type u) where
  base : RegionNet Ω
  compl : base.Region → base.Region
  compl_antitone : (letI := base.instSup; Antitone compl)
  compl_involutive : ∀ r : base.Region, compl (compl r) = r

namespace RegionNetWithCompl

variable {Ω : Type u} (RNc : RegionNetWithCompl Ω)

instance : SemilatticeSup RNc.base.Region := RNc.base.instSup

@[simp] theorem compl_antitone' {a b : RNc.base.Region} (hab : a ≤ b) :
    RNc.compl b ≤ RNc.compl a := (RNc.compl_antitone hab)

theorem gate_COMPL_antitone {a b : RNc.base.Region} (hab : a ≤ b) :
    RNc.compl b ≤ RNc.compl a := compl_antitone' (RNc := RNc) hab

@[simp] theorem compl_compl (r : RNc.base.Region) :
    RNc.compl (RNc.compl r) = r :=
  RNc.compl_involutive r

theorem gate_COMPL_involutive (r : RNc.base.Region) :
    RNc.compl (RNc.compl r) = r :=
  RNc.compl_involutive r

end RegionNetWithCompl

def SetRegionNet (Ω : Type u) : RegionNet Ω where
  Region := Set Ω
  instSup := inferInstance
  top := Set.univ
  le_top := by
    intro a x hx
    trivial
  carrier := fun r => r
  carrier_mono := by
    intro a b hab
    simpa using hab

def FinsetRegionNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] : RegionNet Ω where
  Region := Finset Ω
  instSup := inferInstance
  top := Finset.univ
  le_top := by
    intro a
    exact Finset.subset_univ a
  carrier := fun r => (r : Set Ω)
  carrier_mono := by
    intro a b hab
    intro x hx
    exact hab hx

def SetRegionNetWithCompl (Ω : Type u) : RegionNetWithCompl Ω where
  base := SetRegionNet Ω
  compl := fun r => Set.compl r
  compl_antitone := by
    intro a b hab
    intro x hx
    intro ha
    exact hx (hab ha)
  compl_involutive := by
    intro r
    classical
    apply Set.ext
    intro x
    constructor
    · intro hx
      change x ∉ Set.compl r at hx
      by_contra hr
      have : x ∈ Set.compl r := by
        exact hr
      exact hx this
    · intro hx
      change x ∉ Set.compl r
      intro hxcr
      exact hxcr hx

namespace Net

variable {Ω : Type u} (RN : RegionNet Ω)

structure PreNet where
  Obj : RN.Region → Type w
  map : ∀ {a b : RN.Region}, a ≤ b → Obj a → Obj b
  map_id : ∀ (a : RN.Region) (x : Obj a), map (a := a) (b := a) (le_rfl) x = x
  map_comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) (x : Obj a),
      map (a := b) (b := c) hbc (map (a := a) (b := b) hab x) =
        map (a := a) (b := c) (le_trans hab hbc) x

end Net

end LayerA

end PillarA
