import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u

variable {Cell : Nat → Type u} [Substrate Cell]

structure InfiniteCarrier (Cell : Nat → Type u) [Substrate Cell] : Type (u + 1) where
  cell : ∀ L : Nat, Cell L
  coh : ∀ L : Nat, cell L ∈ Substrate.parents (Cell := Cell) (cell (L + 1))

namespace InfiniteCarrier

variable (U V : InfiniteCarrier (Cell := Cell))

@[ext] theorem ext (h : ∀ L : Nat, U.cell L = V.cell L) : U = V := by
  cases U with
  | mk cellU cohU =>
    cases V with
    | mk cellV cohV =>
      have hc : cellU = cellV := by
        funext L
        exact h L
      subst hc
      have hcoh : cohU = cohV := by
        funext L
        exact Subsingleton.elim (cohU L) (cohV L)
      cases hcoh
      rfl

abbrev proj (U : InfiniteCarrier (Cell := Cell)) (L : Nat) : Cell L := U.cell L

@[simp] theorem proj_def (U : InfiniteCarrier (Cell := Cell)) (L : Nat) : U.proj L = U.cell L :=
  rfl

end InfiniteCarrier

end LayerA
end PillarA
