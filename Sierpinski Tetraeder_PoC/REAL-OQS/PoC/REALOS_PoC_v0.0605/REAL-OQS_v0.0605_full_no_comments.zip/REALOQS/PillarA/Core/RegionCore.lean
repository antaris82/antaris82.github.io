import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u

namespace RegionCore

variable {Cell : Nat → Type u}

abbrev RegionAt (Cell : Nat → Type u) (L : Nat) : Type u :=
  Finset (Cell L)

namespace RegionAt

variable {L : Nat}

def carrier (R : RegionAt Cell L) : Set (Cell L) := fun x => x ∈ R

def singleton (c : Cell L) : RegionAt Cell L := {c}

end RegionAt

def refineAt [Substrate Cell] {L : Nat} (R : RegionAt Cell L) : RegionAt Cell (L + 1) :=
  Substrate.refineSet (Cell := Cell) R

def coarsenAt [Substrate Cell] {L : Nat} (R : RegionAt Cell (L + 1)) : RegionAt Cell L :=
  Substrate.coarsenSet (Cell := Cell) R

end RegionCore

end LayerA

end PillarA
