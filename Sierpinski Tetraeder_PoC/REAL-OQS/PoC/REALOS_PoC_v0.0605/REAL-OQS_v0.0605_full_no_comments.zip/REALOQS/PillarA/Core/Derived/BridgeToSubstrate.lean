import REALOQS.PillarA.Core.Derived.GNS
import REALOQS.PillarA.Core.Derived.ModularKMS
import REALOQS.PillarA.Core.ToC.AQFTSubstrate

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

noncomputable def mkAQFTSubstrate_fromDerivedGNS
    (A : Type u)
    (SA : PillarB.AQFT.StarAlgebra A)
    [h : HasDerivedGNS A] :
    PillarA.ToC.AQFTSubstrate A := by
  classical
  refine
    { SA := SA
      StateOn := h.StateOn
      eval := fun _ _ => 0
      isState := h.isState
      GNSData := fun w => h.isState w → PillarA.Derived.GNSData A
      ModularKMSData := fun _ => PUnit
    }

noncomputable def mkAQFTSubstrate_fromDerivedModularKMS
    (A : Type u)
    (SA : PillarB.AQFT.StarAlgebra A)
    [h : HasDerivedModularKMS A] :
    PillarA.ToC.AQFTSubstrate A := by
  classical
  refine
    { SA := SA
      StateOn := h.StateOn
      eval := fun _ _ => 0
      isState := h.isState
      GNSData := fun _ => PUnit
      ModularKMSData := fun w => h.isState w → Type u
    }

end Derived
end PillarA
