import Mathlib
import REALOQS.PillarA.Core.TailInterface

set_option autoImplicit false

namespace PillarA

namespace LayerA

universe u v w

class VacuumOffsetHook (Cell : Nat → Type u)
    [TailInterface (Cell := Cell)]
    [TailEliminationHook (Cell := Cell)] where
  Offset : Nat → Type w
  offset : ∀ {L : Nat},
    TailEliminationHook.EBD (Cell := Cell) L → Offset L

end LayerA

end PillarA
