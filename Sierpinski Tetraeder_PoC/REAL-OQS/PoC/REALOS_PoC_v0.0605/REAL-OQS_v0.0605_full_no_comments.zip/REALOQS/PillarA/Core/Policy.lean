import Mathlib

set_option autoImplicit false

open scoped BigOperators

namespace PillarA
namespace LayerA

inductive GroundRule where
  | minId : GroundRule
  | minLex : GroundRule
  deriving DecidableEq, Repr

structure Policy (b : Nat) where

  L_max : Nat

namespace Policy

variable {b : Nat}

abbrev Key (_b : Nat) := Nat

def key (p : Policy b) : Key b := p.L_max

theorem key_congr {p q : Policy b} (h : p = q) : p.key = q.key := by
  cases h
  rfl

theorem key_injective {p q : Policy b} (h : p.key = q.key) : p = q := by
  cases p with
  | mk Lp =>
    cases q with
    | mk Lq =>
      cases h
      rfl

def canonical (b : Nat) (L_max : Nat) : Policy b :=
  { L_max := L_max }

theorem canonical_eq_iff {L1 L2 : Nat} :
    canonical (b := b) L1 = canonical (b := b) L2 ↔ L1 = L2 := by
  constructor
  · intro h
    cases h
    rfl
  · intro h
    subst h
    rfl

def L_int (_p : Policy b) : Nat := 1

def K_max (p : Policy b) : Nat := Nat.pred p.L_max

theorem K_max_def (p : Policy b) : p.K_max = Nat.pred p.L_max := rfl

def groundRule (_p : Policy b) : GroundRule := GroundRule.minId

noncomputable def rStar (_p : Policy b) : ℝ := 1 / ((b : ℝ) + 1)

noncomputable def eta (_p : Policy b) : ℝ := (1 : ℝ)

noncomputable def epsMach64 : ℝ := (2 : ℝ) ^ (-52 : ℤ)

noncomputable def epsFloor64 : ℝ := Real.sqrt epsMach64

theorem epsMach64_pos : (0 : ℝ) < epsMach64 := by
  have h2 : (0 : ℝ) < (2 : ℝ) := by norm_num
  simpa [epsMach64] using (zpow_pos h2 (-52 : ℤ))

theorem epsFloor64_pos : (0 : ℝ) < epsFloor64 := by
  have h : (0 : ℝ) < epsMach64 := epsMach64_pos
  simpa [epsFloor64] using (Real.sqrt_pos.2 h)

noncomputable def eps (_p : Policy b) : ℝ := epsFloor64

theorem eps_pos (p : Policy b) : (0 : ℝ) < p.eps := by
  simpa [Policy.eps] using epsFloor64_pos

noncomputable def eps0 (p : Policy b) : ℝ := max (p.rStar ^ p.L_max) epsFloor64

noncomputable def alphaDenom (p : Policy b) : ℝ :=
  (Finset.Icc (1 : Nat) p.K_max).sum (fun j => p.rStar ^ j)

noncomputable def alpha (p : Policy b) (k : Nat) : ℝ :=
  if k ∈ Finset.Icc (1 : Nat) p.K_max then
    (p.rStar ^ k) / p.alphaDenom
  else
    0

theorem alpha_eq_zero_of_not_mem (p : Policy b) {k : Nat}
    (hk : k ∉ Finset.Icc (1 : Nat) p.K_max) : p.alpha k = 0 := by
  simp [Policy.alpha, hk]

theorem alpha_eq_div_of_mem (p : Policy b) {k : Nat}
    (hk : k ∈ Finset.Icc (1 : Nat) p.K_max) :
    p.alpha k = (p.rStar ^ k) / p.alphaDenom := by
  simp [Policy.alpha, hk]

theorem gate_POLICY_derived_stable {p q : Policy b} (h : p = q) :
    (p.K_max = q.K_max) ∧
    (p.eps0 = q.eps0) ∧
    (p.alphaDenom = q.alphaDenom) ∧
    (∀ k, p.alpha k = q.alpha k) := by
  cases h
  refine ⟨rfl, ?_⟩
  refine ⟨rfl, ?_⟩
  refine ⟨rfl, ?_⟩
  intro k
  rfl

end Policy

end LayerA
end PillarA
