import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.RegionCore
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA

namespace LayerA

open RegionCore

universe u

structure Selector (Cell : Nat → Type u) [Substrate Cell] (L : Nat) where
  choose : Approximant Cell L → RegionCore.RegionAt Cell L
  choose_subset : ∀ A : Approximant Cell L, choose A ⊆ A.cells

namespace Selector

variable {Cell : Nat → Type u} [Substrate Cell] {L : Nat}

def all : Selector Cell L :=
  { choose := fun A => A.cells
    choose_subset := by
      intro A
      exact subset_rfl }

end Selector

end LayerA

end PillarA
