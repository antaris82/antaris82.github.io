import Mathlib

set_option autoImplicit false

namespace PillarA

namespace RG

structure ScaleWindow where
  kmin : Nat
  kmax : Nat
  hk : kmin ≤ kmax
  eps : Nat → ENNReal

namespace ScaleWindow

def In (W : ScaleWindow) (k : Nat) : Prop := W.kmin ≤ k ∧ k ≤ W.kmax

def inSucc (W : ScaleWindow) (k : Nat) : Prop := W.In k ∧ W.In (k + 1)

@[simp] theorem inSucc_iff (W : ScaleWindow) (k : Nat) :
    W.inSucc k ↔ (W.In k ∧ W.In (k + 1)) := Iff.rfl

@[simp] theorem in_iff (W : ScaleWindow) (k : Nat) : W.In k ↔ W.kmin ≤ k ∧ k ≤ W.kmax := by
  rfl

theorem kmin_in (W : ScaleWindow) : W.In W.kmin := by
  exact ⟨le_rfl, W.hk⟩

theorem kmax_in (W : ScaleWindow) : W.In W.kmax := by
  exact ⟨W.hk, le_rfl⟩

def length (W : ScaleWindow) : Nat := W.kmax - W.kmin

def epsAt (W : ScaleWindow) (k : Nat) : ENNReal := W.eps k

noncomputable def epsSup (W : ScaleWindow) : ENNReal := ⨆ k : {k // W.In k}, W.eps k

theorem eps_le_epsSup (W : ScaleWindow) (k : Nat) (hk : W.In k) :
    W.eps k ≤ W.epsSup := by
  have h_eps_le_epsSup : ∀ (k : Nat), W.In k → W.eps k ≤ W.epsSup := by
    exact fun k hk => le_iSup_of_le ⟨ k, hk ⟩ le_rfl;
  exact h_eps_le_epsSup k hk

def sub (W : ScaleWindow)
    (kmin' kmax' : Nat)
    (_hmin : W.kmin ≤ kmin')
    (_hmax : kmax' ≤ W.kmax)
    (h : kmin' ≤ kmax') : ScaleWindow := { kmin := kmin', kmax := kmax', hk := h, eps := W.eps }

theorem in_of_in_sub
    (W : ScaleWindow)
    (kmin' kmax' : Nat)
    (hmin : W.kmin ≤ kmin')
    (hmax : kmax' ≤ W.kmax)
    (h : kmin' ≤ kmax')
    (k : Nat) :
    (sub W kmin' kmax' hmin hmax h).In k → W.In k := by
  intro hk
  refine ⟨le_trans hmin hk.1, le_trans hk.2 hmax⟩

def relax (W : ScaleWindow) (M : ENNReal) : ScaleWindow :=
  { kmin := W.kmin,
    kmax := W.kmax,
    hk := W.hk,
    eps := fun k => max (W.eps k) M }

theorem epsSup_relax_ge (W : ScaleWindow) (M : ENNReal) :
    M ≤ (relax W M).epsSup := by
  have hk : (relax W M).In W.kmin := by
    simpa [relax, In] using (relax W M).kmin_in
  have hMk : M ≤ (relax W M).eps W.kmin := by
    simp [relax]
  have hle : (relax W M).eps W.kmin ≤ (relax W M).epsSup :=
    (relax W M).eps_le_epsSup W.kmin hk
  exact le_trans hMk hle

def EpsMonotone (W : ScaleWindow) : Prop := ∀ {i j : Nat}, i ≤ j → W.eps j ≤ W.eps i

def EpsBounded (W : ScaleWindow) : Prop := ∃ M : ENNReal, ∀ k, W.In k → W.eps k ≤ M

theorem epsBounded_of_epsSup (W : ScaleWindow) : W.EpsBounded := by
  refine ⟨W.epsSup, ?_⟩
  intro k hk
  exact W.eps_le_epsSup k hk

end ScaleWindow

end RG

end PillarA
