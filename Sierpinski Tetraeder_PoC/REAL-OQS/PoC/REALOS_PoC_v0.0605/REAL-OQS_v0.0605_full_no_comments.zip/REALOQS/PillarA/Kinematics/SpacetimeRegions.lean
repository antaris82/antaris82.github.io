import Mathlib
import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace Kinematics

open DiscreteSpacetime
open PillarA.LayerA

variable {X : Type}

abbrev SpacetimeRegionNet (_ST : DiscreteSpacetime X) : LayerA.RegionNet X :=
  LayerA.SetRegionNet X

def sliceRegion (ST : DiscreteSpacetime X) (n : Nat) : (SpacetimeRegionNet (X := X) ST).Region := by
  simpa [SpacetimeRegionNet] using (ST.Sigma n)

def tubeRegion (ST : DiscreteSpacetime X) (T : WorldTube ST) (n : Nat) : Set X := (T.W n : Set X)

theorem gate_tubeRegion_subset_slice (ST : DiscreteSpacetime X) (T : WorldTube ST) (n : Nat) :
    tubeRegion (ST := ST) T n ⊆ ST.Sigma n := by
  intro x hx
  exact T.adapted n x hx

end Kinematics
end PillarA
