import Mathlib
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option autoImplicit false

namespace PillarA
namespace Kinematics

abbrev Worldline (V : Type) := ℕ → V

abbrev WorldTube (V : Type) := ℕ → Finset V

def TubeNonempty {V : Type} (W : WorldTube V) : Prop := ∀ n, (W n).Nonempty

def IsCenterline {V : Type} (W : WorldTube V) (γ : Worldline V) : Prop := ∀ n, γ n ∈ W n

theorem gate_CENTERLINE_IS_WORLDLINE {V : Type} (W : WorldTube V) (γ : Worldline V) :
    IsCenterline (V := V) W γ → ∀ n, γ n ∈ W n := by
  intro h
  exact h

class WorldTubeChoiceAxis (V : Type) where
  chooseCenterline : ∀ (W : WorldTube V), TubeNonempty (V := V) W → Worldline V
  choose_spec : ∀ (W : WorldTube V) (hW : TubeNonempty (V := V) W),
    IsCenterline (V := V) W (chooseCenterline W hW)

namespace WorldTubeChoiceAxis

noncomputable def mkClassicalChoice (V : Type) : WorldTubeChoiceAxis V := by
  refine ⟨?_, ?_⟩
  · intro W hW
    classical
    exact fun n => Classical.choose (hW n)
  · intro W hW
    classical
    intro n
    exact Classical.choose_spec (hW n)

end WorldTubeChoiceAxis

theorem gate_TUBE_HAS_CENTERLINE {V : Type} [WorldTubeChoiceAxis V]
    (W : WorldTube V) (hW : TubeNonempty (V := V) W) :
    ∃ γ : Worldline V, IsCenterline (V := V) W γ := by
  refine ⟨WorldTubeChoiceAxis.chooseCenterline (V := V) W hW, ?_⟩
  exact WorldTubeChoiceAxis.choose_spec (V := V) W hW

end Kinematics
end PillarA
