import Mathlib

namespace PillarA
namespace Kinematics

section Discrete

variable {S : Type}

abbrev Evo (S : Type) := ℕ → (S → S)

abbrev Frame (S : Type) := ℕ → Equiv.Perm S

def timeIndependent (U : Frame S) : Prop := ∀ n, U n = U 0

def frameChange (T : Evo S) (U : Frame S) : Evo S := fun n x => (U (n+1)) (T n ((U n).symm x))

def relChange (U : Frame S) : ℕ → Equiv.Perm S := fun n => (U (n+1)) * (U n)⁻¹

theorem gate_FRAMECHANGE_CONJ_CONST (T : Evo S) (U : Frame S) (hU : timeIndependent (S := S) U) :
    ∀ n, frameChange (S := S) T U n = fun x => (U 0) (T n ((U 0).symm x)) := by
  intro n
  funext x
  simp [frameChange, hU n, hU (n+1)]

theorem gate_RELCHANGE_ID_OF_CONST (U : Frame S) (hU : timeIndependent (S := S) U) :
    ∀ n, relChange (S := S) U n = 1 := by
  intro n
  simp [relChange, hU n, hU (n+1)]

theorem gate_NONINERTIAL_IF_RELCHANGE_NE_ID (U : Frame S) :
    (∃ n, relChange (S := S) U n ≠ 1) → ¬ timeIndependent (S := S) U := by
  intro h hU
  rcases h with ⟨n, hn⟩
  have : relChange (S := S) U n = 1 := gate_RELCHANGE_ID_OF_CONST (S := S) U hU n
  exact hn this

end Discrete

end Kinematics
end PillarA
