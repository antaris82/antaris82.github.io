import Mathlib
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false
set_option linter.style.longLine false

namespace PillarA
namespace Kinematics

open PillarA.Update

namespace FromUpdate

universe u

variable {b : Nat} (A : TwoStageApprox b)

abbrev Event : Type u := Nat × A.FinestCell

noncomputable def canonicalSpacetime : DiscreteSpacetime (Event (A := A)) where
  τ := Prod.fst
  step := fun x y => y.1 = x.1 + 1 ∧ y.2 = x.2
  step_tau := by
    intro x y h
    simpa using h.1

def eventEmbed (n : Nat) : A.FinestCell ↪ Event (A := A) where
  toFun := fun w => (n, w)
  inj' := by
    intro a b h
    exact congrArg Prod.snd h

noncomputable def observedCells
    [C : TwoStageApprox.AllCellsConsistency (A := A)]
    (m : SubsystemMode A.FinestCell) (s : A.S) : Finset A.FinestCell := by
  classical
  exact A.finestCells.filter (fun w => decide (C.Obs w (A.pipeline m s)))

noncomputable def worldTubeOfRun
    [C : TwoStageApprox.AllCellsConsistency (A := A)]
    (m : SubsystemMode A.FinestCell) (run : Nat → A.S) :
    (canonicalSpacetime (A := A)).WorldTube := by
  classical
  refine ⟨?_, ?_⟩
  · intro n
    exact (observedCells (A := A) (m := m) (s := run n)).map (eventEmbed (A := A) n)
  · intro n x hx
    rcases Finset.mem_map.mp hx with ⟨w, hw, rfl⟩
    rfl

end FromUpdate

end Kinematics
end PillarA
