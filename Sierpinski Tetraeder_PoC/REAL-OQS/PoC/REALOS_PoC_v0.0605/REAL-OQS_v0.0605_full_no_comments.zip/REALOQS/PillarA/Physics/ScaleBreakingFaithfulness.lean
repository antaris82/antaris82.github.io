import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatch

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace Physics

open PillarA.Update

variable {S α : Type}

structure ScaleBreakingFaithfulness
    (A : ScaleBreakingAxis S) (Obs : OpObserver (S := S) (α := α))
    (M : MismatchFunctional (α := α)) (eps : ℝ) : Prop where
  eps_pos : eps > 0

  ideal_observed_eq_of_scaleInvariant :
    A.scaleInvariant → ∀ k,
      Obs.op (A.ideal k) = Obs.op (A.coarsen k (A.ideal (k+1)))

  real_normed_observed_neq_of_breaksScale :
    A.breaksScale → ∃ k,
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)) ≠
        normalizeTrace (α := α) M.P M.T eps eps_pos
          (Obs.op (A.coarsen k (A.real (k + 1))))

  mismatch_pos_of_real_normed_observed_neq :
    ∀ k,
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)) ≠
        normalizeTrace (α := α) M.P M.T eps eps_pos
          (Obs.op (A.coarsen k (A.real (k + 1)))) →
        0 < M.mismatch
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)))
          (normalizeTrace (α := α) M.P M.T eps eps_pos
            (Obs.op (A.coarsen k (A.real (k + 1)))))

noncomputable def Laws_fromMismatch_withFaithfulness
    (A : ScaleBreakingAxis S) (Obs : OpObserver (S := S) (α := α))
    (M : MismatchFunctional (α := α)) (eps : ℝ)
    (F : ScaleBreakingFaithfulness (A := A) (Obs := Obs) (M := M) eps) :
    ScaleBreakingAxis.Laws (axis_fromMismatch (A := A) Obs M eps F.eps_pos) := by
  refine
    { breakMeasureIdeal_zero_of_scaleInvariant := ?_
      breakMeasure_pos_of_breaksScale := ?_ }
  · intro hSI k
    have hObs :
        Obs.op (A.ideal k) = Obs.op (A.coarsen k (A.ideal (k + 1))) :=
      F.ideal_observed_eq_of_scaleInvariant hSI k
    have hEq :
        normalizeTrace M.P M.T eps (by exact F.eps_pos) (Obs.op (A.ideal k)) =
          normalizeTrace M.P M.T eps (by exact F.eps_pos)
            (Obs.op (A.coarsen k (A.ideal (k + 1)))) := by
      simp [hObs]
    simpa [axis_fromMismatch, breakMeasure_fromMismatchIdeal] using
      gate_breakMeasure_zero_of_observed_eq
        (tower := A.ideal) (coarsen := A.coarsen) (Obs := Obs) (M := M) (eps := eps)
        (eps_pos := F.eps_pos) (k := k) hEq
  · intro hBS
    rcases F.real_normed_observed_neq_of_breaksScale hBS with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    have hPos := F.mismatch_pos_of_real_normed_observed_neq (k := k) hk
    simpa [axis_fromMismatch, breakMeasure_fromMismatchReal, breakMeasure_fromMismatch_onTower]
      using hPos

end Physics
end PillarA
