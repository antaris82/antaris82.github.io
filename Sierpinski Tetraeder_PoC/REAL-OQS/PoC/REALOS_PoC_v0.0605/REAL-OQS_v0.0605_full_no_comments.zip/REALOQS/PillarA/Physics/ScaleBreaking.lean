import Mathlib

set_option autoImplicit false

namespace PillarA

namespace Physics

universe u

def constFamily (S : Type u) : Nat → Type u := fun _ => S

structure ScaleBreakingAxis (S : Type) where
  coarsen : Nat → S → S
  ideal : Nat → S
  real  : Nat → S

  breakMeasure : Nat → ENNReal

  breakMeasureIdeal : Nat → ENNReal

namespace ScaleBreakingAxis

variable {S : Type} (A : ScaleBreakingAxis S)

def scaleInvariant : Prop := ∀ k, A.coarsen k (A.ideal (k+1)) = A.ideal k

def breaksScale : Prop := ∃ k, A.coarsen k (A.real (k+1)) ≠ A.real k

def breaksScaleByMeasure : Prop := ∃ k, A.breakMeasure k ≠ 0

def breaksScaleByMeasureIdeal : Prop := ∃ k, A.breakMeasureIdeal k ≠ 0

def coarsenFrom (k n : Nat) (s : S) : S := Nat.rec s (fun m t => A.coarsen (k+m) t) n

theorem gate_COARSENFROM_zero (k : Nat) (s : S) :
    A.coarsenFrom k 0 s = s := by
  simp [coarsenFrom]

theorem gate_COARSENFROM_succ (k n : Nat) (s : S) :
    A.coarsenFrom k (n+1) s = A.coarsen (k+n) (A.coarsenFrom k n s) := by
  simp [coarsenFrom]

class Laws (A : ScaleBreakingAxis S) : Prop where

  breakMeasureIdeal_zero_of_scaleInvariant :
    A.scaleInvariant → ∀ k, A.breakMeasureIdeal k = 0

  breakMeasure_pos_of_breaksScale :
    A.breaksScale → ∃ k, 0 < A.breakMeasure k

theorem gate_BREAKMEASURE_zero (A : ScaleBreakingAxis S) [Laws A] :
    A.scaleInvariant → ∀ k, A.breakMeasureIdeal k = 0 :=
  Laws.breakMeasureIdeal_zero_of_scaleInvariant (A := A)

theorem gate_BREAKMEASURE_pos (A : ScaleBreakingAxis S) [Laws A] :
    A.breaksScale → ∃ k, 0 < A.breakMeasure k :=
  Laws.breakMeasure_pos_of_breaksScale (A := A)

def Laws.ofProofs {S : Type} {A : ScaleBreakingAxis S}
    (hIdeal : A.scaleInvariant → ∀ k, A.breakMeasureIdeal k = 0)
    (hReal : A.breaksScale → ∃ k, 0 < A.breakMeasure k) : Laws A :=
  ⟨hIdeal, hReal⟩

end ScaleBreakingAxis

structure ScaleBreakingAxisD (S : Nat → Type) where
  coarsen : ∀ k, S (k+1) → S k
  ideal : ∀ k, S k
  real  : ∀ k, S k

  breakMeasure : Nat → ENNReal

  breakMeasureIdeal : Nat → ENNReal

namespace ScaleBreakingAxisD

variable {S : Nat → Type} (A : ScaleBreakingAxisD S)

def scaleInvariantD : Prop := ∀ k, A.coarsen k (A.ideal (k+1)) = A.ideal k

def breaksScaleD : Prop := ∃ k, A.coarsen k (A.real (k+1)) ≠ A.real k

def breaksScaleByMeasureD : Prop := ∃ k, A.breakMeasure k ≠ 0

def breaksScaleByMeasureIdealD : Prop := ∃ k, A.breakMeasureIdeal k ≠ 0

def coarsenFromD (k : Nat) : ∀ n, S (k+n) → S k
  | 0, s => by
      simpa using s
  | n+1, s =>
      coarsenFromD k n (A.coarsen (k+n) s)

theorem gate_COARSENFROMD_zero (k : Nat) (s : S k) :
    A.coarsenFromD k 0 s = s := by
  simp [coarsenFromD]

theorem gate_COARSENFROMD_succ (k n : Nat) (s : S (k + n + 1)) :
    A.coarsenFromD k (n+1) s = A.coarsenFromD k n (A.coarsen (k+n) s) := by
  simp [coarsenFromD]

class LawsD (A : ScaleBreakingAxisD S) : Prop where
  breakMeasureIdeal_zero_of_scaleInvariantD :
    A.scaleInvariantD → ∀ k, A.breakMeasureIdeal k = 0
  breakMeasure_pos_of_breaksScaleD :
    A.breaksScaleD → ∃ k, 0 < A.breakMeasure k

theorem gate_BREAKMEASURED_zero (A : ScaleBreakingAxisD S) [LawsD A] :
    A.scaleInvariantD → ∀ k, A.breakMeasureIdeal k = 0 :=
  LawsD.breakMeasureIdeal_zero_of_scaleInvariantD (A := A)

theorem gate_BREAKMEASURED_pos (A : ScaleBreakingAxisD S) [LawsD A] :
    A.breaksScaleD → ∃ k, 0 < A.breakMeasure k :=
  LawsD.breakMeasure_pos_of_breaksScaleD (A := A)

end ScaleBreakingAxisD

namespace ScaleBreakingAxis

def toD {S : Type} (A : ScaleBreakingAxis S) :
    ScaleBreakingAxisD (constFamily S) :=
  { coarsen := fun k s => A.coarsen k s
    , ideal := fun k => A.ideal k
    , real := fun k => A.real k
    , breakMeasure := fun k => A.breakMeasure k
    , breakMeasureIdeal := fun k => A.breakMeasureIdeal k }

@[simp] theorem toD_coarsen {S : Type} (A : ScaleBreakingAxis S) (k : Nat) (s : S) :
    (toD (S := S) A).coarsen k s = A.coarsen k s := rfl

end ScaleBreakingAxis

namespace ScaleBreakingAxisD

def toConst {S : Type} (A : ScaleBreakingAxisD (constFamily S)) :
    ScaleBreakingAxis S :=
  { coarsen := fun k s => A.coarsen k s
    , ideal := fun k => A.ideal k
    , real := fun k => A.real k
    , breakMeasure := fun k => A.breakMeasure k
    , breakMeasureIdeal := fun k => A.breakMeasureIdeal k }

@[simp] theorem toConst_coarsen {S : Type} (A : ScaleBreakingAxisD (constFamily S))
    (k : Nat) (s : S) :
    (toConst (S := S) A).coarsen k s = A.coarsen k s := rfl

@[simp] theorem toConst_toD {S : Type} (A : ScaleBreakingAxis S) :
    toConst (S := S) (ScaleBreakingAxis.toD (S := S) A) = A := by
  rfl

end ScaleBreakingAxisD

end Physics

end PillarA
