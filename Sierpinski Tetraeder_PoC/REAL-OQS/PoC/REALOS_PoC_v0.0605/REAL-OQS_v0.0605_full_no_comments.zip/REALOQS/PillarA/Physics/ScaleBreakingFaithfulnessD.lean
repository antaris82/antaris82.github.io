import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace Physics

open PillarA.Update

noncomputable section

theorem gate_breakMeasure_fromMismatch_onTowerD_zero_of_observed_eq
    {S : Nat → Type} {α : Nat → Type}
    (coarsen : ∀ k, S (k + 1) → S k) (tower : ∀ k, S k)
    (Obs : OpObserverD S α) (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) (k : Nat)
    (hEq :
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)) =
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (coarsen k (tower (k + 1))))) :
    (breakMeasure_fromMismatch_onTowerD
        (S := S) (α := α) coarsen tower Obs M eps eps_pos) k = 0 := by
  have h0 :
      (M k).mismatch
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
            (Obs.op k (coarsen k (tower (k + 1))))) = 0 := by
    calc
      (M k).mismatch
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
            (Obs.op k (coarsen k (tower (k + 1)))))
          = (M k).mismatch
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k))) := by
                simpa using
                  congrArg
                    (fun X =>
                      (M k).mismatch
                        (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
                          (Obs.op k (tower k)))
                        X)
                    hEq.symm
      _ = 0 := (M k).mismatch_self _
  simp [breakMeasure_fromMismatch_onTowerD, h0]

structure ScaleBreakingFaithfulnessD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) : Prop where
  eps_pos : eps > 0

  ideal_observed_eq_of_scaleInvariantD :
    A.scaleInvariantD → ∀ k,
      Obs.op k (A.ideal k) = Obs.op k (A.coarsen k (A.ideal (k + 1)))

  real_normed_observed_neq_of_breaksScaleD :
    A.breaksScaleD → ∃ k,
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)) ≠
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (A.coarsen k (A.real (k + 1))))

  mismatch_pos_of_real_normed_observed_neq :
    ∀ k,
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)) ≠
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (A.coarsen k (A.real (k + 1)))) →
        0 < (M k).mismatch
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)))
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
                (Obs.op k (A.coarsen k (A.real (k + 1)))))

noncomputable def LawsD_fromMismatch_withFaithfulnessD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ)
    (F : ScaleBreakingFaithfulnessD (A := A) (Obs := Obs) (M := M) eps) :
    ScaleBreakingAxisD.LawsD
      (axis_fromMismatchD (S := S) (α := α) (A := A) Obs M eps F.eps_pos) := by
  refine ⟨?_, ?_⟩
  · intro hSI k
    have hObs := F.ideal_observed_eq_of_scaleInvariantD hSI k
    have hEq :
        normalizeTrace (α := α k) (M k).P (M k).T eps F.eps_pos (Obs.op k (A.ideal k)) =
          normalizeTrace (α := α k) (M k).P (M k).T eps F.eps_pos
            (Obs.op k (A.coarsen k (A.ideal (k + 1)))) := by
      simp [hObs]
    have h0 :=
      gate_breakMeasure_fromMismatch_onTowerD_zero_of_observed_eq
        (S := S) (α := α)
        (coarsen := A.coarsen)
        (tower := A.ideal)
        (Obs := Obs) (M := M)
        (eps := eps) (eps_pos := F.eps_pos)
        (k := k) hEq
    simpa [axis_fromMismatchD, breakMeasure_fromMismatchIdealD] using h0
  · intro hBS
    rcases F.real_normed_observed_neq_of_breaksScaleD hBS with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    have hPos := F.mismatch_pos_of_real_normed_observed_neq (k := k) hk
    simpa [axis_fromMismatchD, breakMeasure_fromMismatchRealD, breakMeasure_fromMismatch_onTowerD]
      using hPos

end
end Physics
end PillarA
