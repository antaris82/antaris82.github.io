import Mathlib
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA

namespace Physics

open PillarA.Update

abbrev OpObserver (S : Type) (α : Type) := PillarA.Update.OpObserver S α

noncomputable def breakMeasure_fromMismatch_onTower {S α : Type}
    (coarsen : Nat → S → S) (tower : Nat → S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal := fun k =>
    let Ak : NormalizedOp (α := α) := normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))
    let Acoarse : NormalizedOp (α := α) :=
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))
    M.mismatch Ak Acoarse

noncomputable def breakMeasure_fromMismatchReal {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTower (α := α) A.coarsen A.real Obs M eps eps_pos

noncomputable def breakMeasure_fromMismatchIdeal {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTower (α := α) A.coarsen A.ideal Obs M eps eps_pos

noncomputable def axis_fromMismatch {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : ScaleBreakingAxis S :=
  { coarsen := A.coarsen,
    ideal := A.ideal,
    real := A.real,
    breakMeasure := breakMeasure_fromMismatchReal (A := A) Obs M eps eps_pos,
    breakMeasureIdeal := breakMeasure_fromMismatchIdeal (A := A) Obs M eps eps_pos }

theorem gate_breakMeasure_zero_of_observed_eq {S α : Type}
    (coarsen : Nat → S → S) (tower : Nat → S)
    (Obs : OpObserver S α) (M : MismatchFunctional (α := α))
    (eps : ℝ) (eps_pos : eps > 0) (k : Nat)
    (hEq : normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)) =
          normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))) :
    (breakMeasure_fromMismatch_onTower (α := α) coarsen tower Obs M eps eps_pos) k = 0 := by
  have h0 : M.mismatch
      (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
      (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))) = 0 := by
    calc
      M.mismatch
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1)))))
          = M.mismatch
              (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
              (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))) := by
                simpa using congrArg (fun X => M.mismatch
                    (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))) X) hEq.symm
      _ = 0 := M.mismatch_self _
  simp [breakMeasure_fromMismatch_onTower, h0]

def Laws_fromMismatch {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0)
    (hIdeal :
      (axis_fromMismatch (A := A) Obs M eps eps_pos).scaleInvariant →
        ∀ k, (axis_fromMismatch (A := A) Obs M eps eps_pos).breakMeasureIdeal k = 0)
    (hReal :
      (axis_fromMismatch (A := A) Obs M eps eps_pos).breaksScale →
        ∃ k, 0 < (axis_fromMismatch (A := A) Obs M eps eps_pos).breakMeasure k) :
    ScaleBreakingAxis.Laws (axis_fromMismatch (A := A) Obs M eps eps_pos) :=
  ScaleBreakingAxis.Laws.ofProofs
    (A := axis_fromMismatch (A := A) Obs M eps eps_pos)
    hIdeal hReal

end Physics
end PillarA
