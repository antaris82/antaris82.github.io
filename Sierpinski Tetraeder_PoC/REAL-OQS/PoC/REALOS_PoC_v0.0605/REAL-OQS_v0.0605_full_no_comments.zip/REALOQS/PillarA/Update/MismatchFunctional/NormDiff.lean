import Mathlib
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Update.MismatchFunctional

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace Update

noncomputable section

namespace MismatchFunctional
namespace NormDiff

variable {α : Type}

section Delta

variable [DecidableEq α]

def delta (j : α) : α → ℝ := fun x => if x = j then 1 else 0

@[simp] theorem delta_self (j : α) : delta (α := α) j j = 1 := by
  simp [delta]

@[simp] theorem delta_ne {i j : α} (h : i ≠ j) : delta (α := α) j i = 0 := by
  simp [delta, h]

end Delta

section MatrixRep

variable [DecidableEq α]

def matrixOfLinOp (A : LinOp (α := α)) : Matrix α α ℝ :=
  fun i j => A.apply (delta (α := α) j) i

@[simp] theorem matrixOfLinOp_zero : matrixOfLinOp (α := α) (0 : LinOp (α := α)) = 0 := by
  classical
  ext i j
  simp [matrixOfLinOp]

@[simp] theorem matrixOfLinOp_add (A B : LinOp (α := α)) :
    matrixOfLinOp (α := α) (A + B) = matrixOfLinOp (α := α) A + matrixOfLinOp (α := α) B := by
  classical
  ext i j
  simp [matrixOfLinOp]

@[simp] theorem matrixOfLinOp_neg (A : LinOp (α := α)) :
    matrixOfLinOp (α := α) (-A) = - matrixOfLinOp (α := α) A := by
  classical
  ext i j
  simp [matrixOfLinOp]

end MatrixRep

namespace Frob

open PillarA.LayerA

variable [Fintype α]

@[simp] theorem frobSq_zero :
    MatrixNorm.frobSq (ι := α) (0 : Matrix α α ℝ) = 0 := by
  classical
  simp [MatrixNorm.frobSq]

@[simp] theorem frob_zero :
    MatrixNorm.frob (ι := α) (0 : Matrix α α ℝ) = 0 := by
  classical
  simp [MatrixNorm.frob, MatrixNorm.frobSq]

end Frob

def idProjector : NullModeProjector α :=
  { proj := id
    map_add := by
      intro f g
      rfl
    map_zero := by
      rfl }

open PillarA.LayerA

section Mismatch

variable [Fintype α] [DecidableEq α]

noncomputable def mismatch (P : NullModeProjector α)
    (A B : NormalizedOp (α := α)) : ENNReal :=
  let D : LinOp (α := α) := projectOp P (A + (-B))
  ENNReal.ofReal (MatrixNorm.frobSq (ι := α) (matrixOfLinOp (α := α) D))

theorem mismatch_self (P : NullModeProjector α) (A : NormalizedOp (α := α)) :
    mismatch (α := α) P A A = 0 := by
  classical
  have hAA : (A + (-A) : LinOp (α := α)) = 0 := by
    ext f x
    simp
  simp [mismatch, hAA, projectOp_zero, matrixOfLinOp_zero, Frob.frobSq_zero]

theorem mismatch_pos_of_matrix_ne_zero (P : NullModeProjector α)
    (A B : NormalizedOp (α := α))
    (hM :
      matrixOfLinOp (α := α) (projectOp P (A + (-B))) ≠ 0) :
    0 < mismatch (α := α) P A B := by
  classical
  have hPos :
      0 < MatrixNorm.frobSq (ι := α)
        (matrixOfLinOp (α := α) (projectOp P (A + (-B)))) :=
    MatrixNorm.frobSq_pos_of_ne_zero
      (ι := α)
      (A := matrixOfLinOp (α := α) (projectOp P (A + (-B))))
      hM
  simpa [mismatch] using (ENNReal.ofReal_pos.2 hPos)

def mk (P : NullModeProjector α) : MismatchFunctional (α := α) :=
  { P := P
    T := fun _ => 1
    mismatch := mismatch (α := α) P
    mismatch_self := by
      intro A
      simpa using mismatch_self (α := α) P A }

def mkId : MismatchFunctional (α := α) :=
  mk (α := α) idProjector

end Mismatch

end NormDiff
end MismatchFunctional

end
end Update
end PillarA
