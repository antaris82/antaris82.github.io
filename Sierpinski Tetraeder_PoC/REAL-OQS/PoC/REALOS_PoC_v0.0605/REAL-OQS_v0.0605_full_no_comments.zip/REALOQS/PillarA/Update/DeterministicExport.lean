import Mathlib
import REALOQS.PillarA.Core.Determinism
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false

namespace PillarA
namespace Update

open PillarA.LayerA
open PillarA.LayerA.Determinism

namespace DeterministicExport

variable {b : Nat}

def exportId (H : PolicyHash b) (p : Policy b) (step : Nat) : Nat :=
  (H.hash p) * 65537 + step

theorem gate_EXPORTID_DEPENDS_ONLY_ON_KEY
    (H : PolicyHash b) (p q : Policy b) (step : Nat)
    (hkey : Policy.key p = Policy.key q) :
    exportId (b := b) H p step = exportId (b := b) H q step := by
  simp [exportId, H.depends_only_on_key p q hkey]

structure Plan (State Artifact : Type) where
  policy : Policy b
  H : PolicyHash b
  E : Exporter b Artifact
  observe : State → Artifact

namespace Plan

variable {State Artifact : Type}

def id (P : Plan (b := b) State Artifact) (step : Nat) : Nat :=
  exportId (b := b) P.H P.policy step

def emit (P : Plan (b := b) State Artifact) (step : Nat) (s : State) : ExportBundle :=
  P.E.emit P.policy step (P.observe s)

end Plan

theorem gate_EXPORT_DEPENDS_ONLY_ON_KEY
    {Artifact : Type} (E : Exporter b Artifact) [ExportLaws (b := b) E] :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a :=
  Determinism.gate_D1_EXPORT_DEPENDS_ONLY_ON_KEY (b := b) E

variable {Artifact : Type}

def mkPlanFromTwoStage
    (A : TwoStageApprox b)
    (H : PolicyHash b)
    (E : Exporter b Artifact)
    (observe : A.S → Artifact) :
    Plan (b := b) A.S Artifact :=
  { policy := A.policy
    H := H
    E := E
    observe := observe }

def emitStage1 {State Artifact : Type}
    (P : Plan (b := b) State Artifact)
    (A : TwoStageApprox b) (step : Nat)
    (coerce : A.S → State) (s : A.S) : ExportBundle :=
  P.emit step (coerce (A.stage1 s))

def emitPipeline {State Artifact : Type}
    (P : Plan (b := b) State Artifact)
    (A : TwoStageApprox b) (m : SubsystemMode A.FinestCell)
    (step : Nat) (coerce : A.S → State) (s : A.S) : ExportBundle :=
  P.emit step (coerce (A.pipeline m s))

end DeterministicExport

end Update
end PillarA
