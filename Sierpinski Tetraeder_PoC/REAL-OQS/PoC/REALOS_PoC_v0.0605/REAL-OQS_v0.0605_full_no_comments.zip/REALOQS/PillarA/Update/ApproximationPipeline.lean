import Mathlib
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.Selection
import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Core.SymmetryAction

set_option autoImplicit false

namespace PillarA
namespace Update

universe u

inductive SubsystemMode (α : Type u) where
  | region (R : Finset α)
  | allCells

namespace SubsystemMode

variable {α : Type u}

def single [DecidableEq α] (w : α) : SubsystemMode α :=
  SubsystemMode.region ({w} : Finset α)

end SubsystemMode

structure TwoStageApprox (b : Nat) where
  (policy : _root_.PillarA.LayerA.Policy b)
  (Cell : Nat → Type u)
  [instSubstrate : PillarA.LayerA.Substrate Cell]
  (S : Type)
  (truncateTail : S → S)
  (integrateTail : S → S)
  (select : SubsystemMode (Cell policy.L_max) → S → S)

  truncate_idem : ∀ s : S, truncateTail (truncateTail s) = truncateTail s
  integrate_idem : ∀ s : S, integrateTail (integrateTail s) = integrateTail s
  stage1_idem : ∀ s : S,
    integrateTail (truncateTail (integrateTail (truncateTail s))) =
    integrateTail (truncateTail s)

attribute [instance] TwoStageApprox.instSubstrate

namespace TwoStageApprox

variable {b : Nat} (A : TwoStageApprox b)

abbrev FinestCell : Type u := A.Cell A.policy.L_max

def finestCells : Finset A.FinestCell :=
  Finset.univ

def stage1 (s : A.S) : A.S := A.integrateTail (A.truncateTail s)

def pipeline (m : SubsystemMode A.FinestCell) (s : A.S) : A.S := A.select m (A.stage1 s)

theorem gate_STAGE1_DEF (s : A.S) : A.stage1 s = A.integrateTail (A.truncateTail s) := by
  rfl

theorem gate_PIPELINE_DEF (m : SubsystemMode A.FinestCell) (s : A.S) :
    A.pipeline m s = A.select m (A.integrateTail (A.truncateTail s)) := by
  rfl

theorem gate_TRUNCATE_IDEMPOTENT :
    (∀ s : A.S, A.truncateTail (A.truncateTail s) = A.truncateTail s) := A.truncate_idem

theorem gate_INTEGRATE_IDEMPOTENT :
    (∀ s : A.S, A.integrateTail (A.integrateTail s) = A.integrateTail s) := A.integrate_idem

theorem gate_STAGE1_IDEMPOTENT :
    (∀ s : A.S,
      A.integrateTail (A.truncateTail (A.integrateTail (A.truncateTail s))) =
      A.integrateTail (A.truncateTail s)) := A.stage1_idem

def mkOfLaws
    {b : Nat}
    (policy : _root_.PillarA.LayerA.Policy b)
    (Cell : Nat → Type u) [PillarA.LayerA.Substrate Cell]
    (S : Type)
    (truncateTail integrateTail : S → S)
    (select : SubsystemMode (Cell policy.L_max) → S → S)
    (truncate_idem : ∀ s : S, truncateTail (truncateTail s) = truncateTail s)
    (integrate_idem : ∀ s : S, integrateTail (integrateTail s) = integrateTail s)
    (stage1_idem : ∀ s : S,
      integrateTail (truncateTail (integrateTail (truncateTail s))) =
      integrateTail (truncateTail s)) : TwoStageApprox b :=
  { policy := policy
    Cell := Cell
    S := S
    truncateTail := truncateTail
    integrateTail := integrateTail
    select := select
    truncate_idem := truncate_idem
    integrate_idem := integrate_idem
    stage1_idem := stage1_idem }

def mkIdStage1
    {b : Nat}
    (policy : _root_.PillarA.LayerA.Policy b)
    (Cell : Nat → Type u) [PillarA.LayerA.Substrate Cell]
    (S : Type)
    (_truncateTail _integrateTail : S → S)
    (select : SubsystemMode (Cell policy.L_max) → S → S) : TwoStageApprox b := by
  refine
    { policy := policy
      Cell := Cell
      S := S
      truncateTail := id
      integrateTail := id
      select := select
      truncate_idem := ?_
      integrate_idem := ?_
      stage1_idem := ?_ }
  · intro s; rfl
  · intro s; rfl
  · intro s; rfl

class MonotoneLaws [Preorder A.S] : Prop where
  truncate_monotone : Monotone A.truncateTail
  integrate_monotone : Monotone A.integrateTail
  select_monotone : ∀ m : SubsystemMode A.FinestCell, Monotone (A.select m)

def MonotoneLaws.mkOf [Preorder A.S]
    (hTr : Monotone A.truncateTail)
    (hIn : Monotone A.integrateTail)
    (hSel : ∀ m : SubsystemMode A.FinestCell, Monotone (A.select m)) :
    MonotoneLaws (A := A) :=
  ⟨hTr, hIn, hSel⟩

theorem gate_PIPELINE_MONOTONE [Preorder A.S]
    [h : MonotoneLaws (A := A)] (m : SubsystemMode A.FinestCell) : Monotone (A.pipeline m) := by
  intro s t hst
  have htr : A.truncateTail s ≤ A.truncateTail t := (MonotoneLaws.truncate_monotone (A := A)) hst
  have hint :
      A.integrateTail (A.truncateTail s) ≤ A.integrateTail (A.truncateTail t) :=
    (MonotoneLaws.integrate_monotone (A := A)) htr
  exact (MonotoneLaws.select_monotone (A := A) m) hint

structure Observer where

  Obs : A.FinestCell → A.S → Prop

  obs_congr : ∀ w s t, s = t → Obs w s → Obs w t

  true_witness : ∀ w : A.FinestCell, ∃ s : A.S, Obs w s

  false_witness : ∀ w : A.FinestCell, ∃ s : A.S, ¬ Obs w s

class AllCellsConsistency where
  observer : Observer (A := A)
  allcells_pointwise :
    ∀ s : A.S,
      (∀ w ∈ A.finestCells,
        observer.Obs w (A.pipeline (SubsystemMode.single w) s)) →
      (∀ w ∈ A.finestCells,
        observer.Obs w (A.pipeline SubsystemMode.allCells s))

namespace AllCellsConsistency

variable {b : Nat} {A : TwoStageApprox b}

@[simp] def Obs (C : AllCellsConsistency (A := A)) : A.FinestCell → A.S → Prop :=
  C.observer.Obs

def obs_congr (C : AllCellsConsistency (A := A)) :
    ∀ w s t, s = t → C.Obs w s → C.Obs w t :=
  C.observer.obs_congr

def true_witness (C : AllCellsConsistency (A := A)) :
    ∀ w : A.FinestCell, ∃ s : A.S, C.Obs w s :=
  C.observer.true_witness

def false_witness (C : AllCellsConsistency (A := A)) :
    ∀ w : A.FinestCell, ∃ s : A.S, ¬ C.Obs w s :=
  C.observer.false_witness

end AllCellsConsistency

theorem gate_ALLCELLS_POINTWISE
    [C : AllCellsConsistency (A := A)]
    (s : A.S) :
    (∀ w ∈ A.finestCells, C.Obs w (A.pipeline (SubsystemMode.single w) s)) →
    (∀ w ∈ A.finestCells, C.Obs w (A.pipeline SubsystemMode.allCells s)) :=
  C.allcells_pointwise s

open PillarA.LayerA

namespace Equivariance

variable {b : Nat} (A : TwoStageApprox b)

abbrev Cell := A.Cell

noncomputable def actMode
    (S : SymmetryAction (Cell := A.Cell)) (g : S.G) :
    SubsystemMode A.FinestCell → SubsystemMode A.FinestCell :=
  by
    classical
    intro m
    cases m with
    | region R =>
        exact SubsystemMode.region (R.image (S.act (L := A.policy.L_max) g))
    | allCells =>
        exact SubsystemMode.allCells

def ModeInvariant (S : SymmetryAction (Cell := A.Cell)) (m : SubsystemMode A.FinestCell) : Prop :=
  ∀ g : S.G, actMode (A := A) S g m = m

class Laws (S : SymmetryAction (Cell := A.Cell)) where

  actS : S.G → A.S → A.S

  truncate_equivariant : ∀ g s, actS g (A.truncateTail s) = A.truncateTail (actS g s)
  integrate_equivariant : ∀ g s, actS g (A.integrateTail s) = A.integrateTail (actS g s)

  select_equivariant : ∀ g m s,
      actS g (A.select m s) = A.select (actMode (A := A) S g m) (actS g s)

namespace Laws

variable {A} {S : SymmetryAction (Cell := A.Cell)}

theorem gate_STAGE1_EQUIVARIANT [h : Laws (A := A) S] (g : S.G) (s : A.S) :
    h.actS g (A.stage1 s) = A.stage1 (h.actS g s) := by
  simp [TwoStageApprox.stage1, h.integrate_equivariant, h.truncate_equivariant]

theorem gate_PIPELINE_EQUIVARIANT [h : Laws (A := A) S]
    (g : S.G) (m : SubsystemMode A.FinestCell) (s : A.S) :
    h.actS g (A.pipeline m s) = A.pipeline (actMode (A := A) S g m) (h.actS g s) := by
  simp [TwoStageApprox.pipeline, gate_STAGE1_EQUIVARIANT (A := A) (S := S) (g := g) (s := s),
    h.select_equivariant]

def stage1KernelEquivariant
    [h : Laws (A := A) S] :
    PillarA.LayerA.SymmetryAction.UpdateKernelEquivariant (S := S) (State := A.S) where
  actState := h.actS
  step := A.stage1
  step_equivariant := by
    intro g s
    simpa using gate_STAGE1_EQUIVARIANT (A := A) (S := S) (g := g) (s := s)

def pipelineKernelEquivariant
    [h : Laws (A := A) S] (m : SubsystemMode A.FinestCell)
    (hm : ModeInvariant (A := A) S m) :
    PillarA.LayerA.SymmetryAction.UpdateKernelEquivariant (S := S) (State := A.S) where
  actState := h.actS
  step := A.pipeline m
  step_equivariant := by
    intro g s
    have := gate_PIPELINE_EQUIVARIANT (A := A) (S := S) (g := g) (m := m) (s := s)
    simpa [ModeInvariant, hm g] using this

end Laws

end Equivariance

end TwoStageApprox

end Update
end PillarA
