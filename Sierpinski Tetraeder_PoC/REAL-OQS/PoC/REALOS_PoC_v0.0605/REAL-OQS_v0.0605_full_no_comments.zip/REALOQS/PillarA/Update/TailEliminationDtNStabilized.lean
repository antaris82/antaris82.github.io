import REALOQS.PillarA.OQS.DtNStabilized
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false

namespace PillarA
namespace Update

open scoped BigOperators

noncomputable section

open PillarA.OQS

structure TailElimDtNStabilizedSemantics {b : Nat} (A : TwoStageApprox b) where

  V : Type
  instFintypeV : Fintype V
  instDecEqV : DecidableEq V

  split : Split V

  L : A.S → Matrix V V ℝ

  invStab : ∀ s : A.S,
    Split.DtNStabilized.InteriorInvStabilized (s := split) (p := A.policy) (L s)

  boundaryOp : A.S → Matrix split.B split.B ℝ

  stage1_boundaryOp_eq : ∀ s : A.S,
    boundaryOp (A.stage1 s) =
      Split.DtNStabilized.DtN_stabilized_of (s := split) (p := A.policy) (L s) (invStab s)

attribute [instance] TailElimDtNStabilizedSemantics.instFintypeV
attribute [instance] TailElimDtNStabilizedSemantics.instDecEqV

end

end Update
end PillarA
