import Mathlib

namespace PillarA
namespace Update

noncomputable section

section Mismatch

variable {α : Type}

structure LinOp (α : Type) where
  apply : (α → ℝ) → (α → ℝ)

namespace LinOp

instance : Zero (LinOp α) := ⟨⟨fun _ => 0⟩⟩
instance : Add (LinOp α) := ⟨fun A B => ⟨fun f => A.apply f + B.apply f⟩⟩
instance : Neg (LinOp α) := ⟨fun A => ⟨fun f => -A.apply f⟩⟩
instance : SMul ℝ (LinOp α) := ⟨fun r A => ⟨fun f => r • (A.apply f)⟩⟩

@[simp] theorem zero_apply (f : α → ℝ) : (0 : LinOp α).apply f = 0 := rfl
@[simp] theorem add_apply (A B : LinOp α) (f : α → ℝ) :
    (A + B).apply f = A.apply f + B.apply f := rfl
@[simp] theorem neg_apply (A : LinOp α) (f : α → ℝ) : (-A).apply f = -A.apply f := rfl
@[simp] theorem smul_apply (r : ℝ) (A : LinOp α) (f : α → ℝ) :
    (r • A).apply f = r • (A.apply f) := rfl

@[ext]
theorem ext {A B : LinOp α} (h : ∀ f x, A.apply f x = B.apply f x) : A = B := by
  cases A with
  | mk a =>
    cases B with
    | mk b =>
      have hab : a = b := by
        funext f x
        exact h f x
      cases hab
      rfl

end LinOp

structure NullModeProjector (α : Type) where
  proj : (α → ℝ) → (α → ℝ)
  map_add : ∀ f g, proj (f + g) = proj f + proj g
  map_zero : proj 0 = 0

def projectOp {α : Type} (P : NullModeProjector α) (A : LinOp α) : LinOp α :=
  ⟨fun f => P.proj (A.apply f)⟩

@[simp] theorem projectOp_apply {α : Type} (P : NullModeProjector α) (A : LinOp α) (f : α → ℝ) :
    (projectOp P A).apply f = P.proj (A.apply f) := rfl

theorem projectOp_add {α : Type} (P : NullModeProjector α) (A B : LinOp α) :
    projectOp P (A + B) = projectOp P A + projectOp P B := by
  ext f x
  simp [projectOp, P.map_add]

theorem projectOp_zero {α : Type} (P : NullModeProjector α) : projectOp P (0 : LinOp α) = 0 := by
  ext f x
  simp [projectOp, P.map_zero]

def traceNormFactor {α : Type} [Fintype α] (f : α → ℝ) : ℝ :=
  (Finset.univ.sum fun x => |f x|) + 1

def normalizeTraceVec {α : Type} [Fintype α] (f : α → ℝ) : α → ℝ :=
  fun x => f x / traceNormFactor f

def mismatchVec {α : Type} [Fintype α] (P : NullModeProjector α) (A : LinOp α) (f : α → ℝ) : ℝ :=
  let fN : α → ℝ := normalizeTraceVec f
  let g : α → ℝ := (projectOp P A).apply fN
  Finset.univ.sum fun x => |g x|

end Mismatch

abbrev NormalizedOp (α : Type) := LinOp (α := α)

structure MismatchFunctional (α : Type) where
  P : NullModeProjector α

  T : NormalizedOp (α := α) → ℝ := fun _ => 1

  mismatch : NormalizedOp (α := α) → NormalizedOp (α := α) → ENNReal

  mismatch_self : ∀ A, mismatch A A = 0

namespace MismatchFunctional

noncomputable def mkEqMismatch (α : Type) (P : NullModeProjector α)
    [DecidableEq (NormalizedOp (α := α))] : MismatchFunctional (α := α) := by
  classical
  refine { P := P
          , mismatch := ?_
          , mismatch_self := ?_ }
  · intro A B
    exact (if A = B then (0 : ENNReal) else (1 : ENNReal))
  · intro A
    simp

noncomputable def mkDefault (α : Type) (P : NullModeProjector α)
    [DecidableEq (NormalizedOp (α := α))] : MismatchFunctional (α := α) := by
  classical
  exact mkEqMismatch (α := α) P

end MismatchFunctional

def normalizeTrace {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (_hε : 0 < ε) (A : NormalizedOp (α := α)) : NormalizedOp (α := α) := by
  let Ap : NormalizedOp (α := α) := projectOp P A
  let denom : ℝ := max ε |tracePerp Ap|
  exact (1 / denom) • A

theorem normalizeTrace_denom_pos {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (hε : 0 < ε) (A : NormalizedOp (α := α)) :
    0 < max ε |tracePerp (projectOp P A)| := by
  have : 0 < ε := hε
  exact lt_of_lt_of_le this (le_max_left _ _)

theorem normalizeTrace_congr {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (hε : 0 < ε) {A B : NormalizedOp (α := α)}
    (h : A = B) : normalizeTrace P tracePerp ε hε A = normalizeTrace P tracePerp ε hε B := by
  cases h
  rfl

end

end Update
end PillarA
