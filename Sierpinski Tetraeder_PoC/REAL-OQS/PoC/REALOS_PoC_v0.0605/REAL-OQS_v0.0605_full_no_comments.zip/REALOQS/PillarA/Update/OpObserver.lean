import Mathlib
import REALOQS.PillarA.Update.MismatchFunctional

set_option autoImplicit false

namespace PillarA
namespace Update

def constFamily (S : Type) : Nat → Type := fun _ => S

structure OpObserver (S : Type) (α : Type) where
  op : S → LinOp (α := α)

structure OpObserverD (S : Nat → Type) (α : Nat → Type) where
  op : ∀ k, S k → LinOp (α := α k)

namespace OpObserver

def toD {S : Type} {α : Type} (Obs : OpObserver S α) :
    OpObserverD (constFamily S) (constFamily α) :=
  { op := fun _ s => Obs.op s }

@[simp] theorem toD_op {S : Type} {α : Type} (Obs : OpObserver S α) (k : Nat) (s : S) :
    (toD (S := S) (α := α) Obs).op k s = Obs.op s := rfl

end OpObserver

namespace OpObserverD

def toConst {S : Type} {α : Type}
    (Obs : OpObserverD (constFamily S) (constFamily α)) : OpObserver S α :=
  { op := Obs.op 0 }

@[simp] theorem toConst_toD {S : Type} {α : Type} (Obs : OpObserver S α) :
    (OpObserverD.toConst (S := S) (α := α) (OpObserver.toD (S := S) (α := α) Obs)) = Obs := by
  rfl

end OpObserverD

abbrev OpObserverFam (S : Nat → Type) (α : Nat → Type) := ∀ k, OpObserver (S k) (α k)

namespace OpObserverFam

def ofD {S : Nat → Type} {α : Nat → Type} (Obs : OpObserverD S α) : OpObserverFam S α :=
  fun k => { op := Obs.op k }

def toD {S : Nat → Type} {α : Nat → Type} (F : OpObserverFam S α) : OpObserverD S α :=
  { op := fun k => (F k).op }

@[simp] theorem ofD_toD {S : Nat → Type} {α : Nat → Type} (F : OpObserverFam S α) :
    ofD (toD (S := S) (α := α) F) = F := by
  funext k
  cases hk : F k with
  | mk op =>
      simp [OpObserverFam.ofD, OpObserverFam.toD, hk]

@[simp] theorem toD_ofD {S : Nat → Type} {α : Nat → Type} (Obs : OpObserverD S α) :
    toD (S := S) (α := α) (ofD Obs) = Obs := by
  cases Obs
  rfl

end OpObserverFam

end Update
end PillarA
