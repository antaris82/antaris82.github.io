import Mathlib
import Mathlib.Tactic.GeneralizeProofs
import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.OQS.SysEnv

namespace Harmonic.GeneralizeProofs

open Lean Meta Elab Parser.Tactic Elab.Tactic Mathlib.Tactic.GeneralizeProofs
def mkLambdaFVarsUsedOnly' (fvars : Array Expr) (e : Expr) : MetaM (Array Expr × Expr) := do
  let mut e := e
  let mut fvars' : List Expr := []
  for i' in [0:fvars.size] do
    let fvar := fvars[fvars.size - i' - 1]!
    e ← mkLambdaFVars #[fvar] e (usedOnly := false) (usedLetOnly := false)
    match e with
    | .letE _ _ v b _ => e := b.instantiate1 v
    | .lam _ _ _b _ => fvars' := fvar :: fvars'
    | _ => unreachable!
  return (fvars'.toArray, e)

partial def abstractProofs' (e : Expr) (ty? : Option Expr) : MAbs Expr := do
  if (← read).depth ≤ (← read).config.maxDepth then
    MAbs.withRecurse <| visit (← instantiateMVars e) ty?
  else
    return e
where
  visit (e : Expr) (ty? : Option Expr) : MAbs Expr := do
    if (← read).config.debug then
      if let some ty := ty? then
        unless ← isDefEq (← inferType e) ty do
          throwError "visit: type of{indentD e}\nis not{indentD ty}"
    if e.isAtomic then
      return e
    else
      checkCache (e, ty?) fun _ ↦ do
        if ← isProof e then
          visitProof e ty?
        else
          match e with
          | .forallE n t b i =>
            withLocalDecl n i (← visit t none) fun x ↦ MAbs.withLocal x do
              mkForallFVars #[x] (← visit (b.instantiate1 x) none)
                (usedOnly := false) (usedLetOnly := false)
          | .lam n t b i => do
            withLocalDecl n i (← visit t none) fun x ↦ MAbs.withLocal x do
              let ty'? ←
                if let some ty := ty? then
                  let .forallE _ _ tyB _ ← pure ty
                    | throwError "Expecting forall in abstractProofs .lam"
                  pure <| some <| tyB.instantiate1 x
                else
                  pure none
              mkLambdaFVars #[x] (← visit (b.instantiate1 x) ty'?)
                (usedOnly := false) (usedLetOnly := false)
          | .letE n t v b _ =>
            let t' ← visit t none
            withLetDecl n t' (← visit v t') fun x ↦ MAbs.withLocal x do
              mkLetFVars #[x] (← visit (b.instantiate1 x) ty?) (usedLetOnly := false)
          | .app .. =>
            e.withApp fun f args ↦ do
              let f' ← visit f none
              let argTys ← appArgExpectedTypes f' args ty?
              let mut args' := #[]
              for arg in args, argTy in argTys do
                args' := args'.push <| ← visit arg argTy
              return mkAppN f' args'
          | .mdata _ b  => return e.updateMData! (← visit b ty?)
          | .proj _ _ b => return e.updateProj! (← visit b none)
          | _           => unreachable!
  visitProof (e : Expr) (ty? : Option Expr) : MAbs Expr := do
    let eOrig := e
    let fvars := (← read).fvars
    let e := e.withApp' fun f args => f.beta args
    if e.withApp' fun f args => f.isAtomic && args.all fvars.contains then return e
    let e ←
      if let some ty := ty? then
        if (← read).config.debug then
          unless ← isDefEq ty (← inferType e) do
            throwError m!"visitProof: incorrectly propagated type{indentD ty}\nfor{indentD e}"
        mkExpectedTypeHint e ty
      else pure e
    if (← read).config.debug then
      unless ← Lean.MetavarContext.isWellFormed (← getLCtx) e do
        throwError m!"visitProof: proof{indentD e}\nis not well-formed in the current context\n\
          fvars: {fvars}"
    let (fvars', pf) ← mkLambdaFVarsUsedOnly' fvars e
    if !(← read).config.abstract && !fvars'.isEmpty then
      return eOrig
    if (← read).config.debug then
      unless ← Lean.MetavarContext.isWellFormed (← read).initLCtx pf do
        throwError m!"visitProof: proof{indentD pf}\nis not well-formed in the initial context\n\
          fvars: {fvars}\n{(← mkFreshExprMVar none).mvarId!}"
    let pfTy ← instantiateMVars (← inferType pf)
    let pfTy ← abstractProofs' pfTy none
    if let some pf' ← MAbs.findProof? pfTy then
      return mkAppN pf' fvars'
    MAbs.insertProof pfTy pf
    return mkAppN pf fvars'
partial def withGeneralizedProofs' {α : Type} [Inhabited α] (e : Expr) (ty? : Option Expr)
    (k : Array Expr → Array Expr → Expr → MGen α) :
    MGen α := do
  let propToFVar := (← get).propToFVar
  let (e, generalizations) ← MGen.runMAbs <| abstractProofs' e ty?
  let rec
    go [Inhabited α] (i : Nat) (fvars pfs : Array Expr)
        (proofToFVar propToFVar : ExprMap Expr) : MGen α := do
      if h : i < generalizations.size then
        let (ty, pf) := generalizations[i]
        let ty := (← instantiateMVars (ty.replace proofToFVar.get?)).cleanupAnnotations
        withLocalDeclD (← mkFreshUserName `pf) ty fun fvar => do
          go (i + 1) (fvars := fvars.push fvar) (pfs := pfs.push pf)
            (proofToFVar := proofToFVar.insert pf fvar)
            (propToFVar := propToFVar.insert ty fvar)
      else
        withNewLocalInstances fvars 0 do
          let e' := e.replace proofToFVar.get?
          modify fun s => { s with propToFVar }
          k fvars pfs e'
  go 0 #[] #[] (proofToFVar := {}) (propToFVar := propToFVar)

partial def generalizeProofsCore'
    (g : MVarId) (fvars rfvars : Array FVarId) (target : Bool) :
    MGen (Array Expr × MVarId) := go g 0 #[]
where
  go (g : MVarId) (i : Nat) (hs : Array Expr) : MGen (Array Expr × MVarId) := g.withContext do
    let tag ← g.getTag
    if h : i < rfvars.size then
      let fvar := rfvars[i]
      if fvars.contains fvar then
        let tgt ← instantiateMVars <| ← g.getType
        let ty := (if tgt.isLet then tgt.letType! else tgt.bindingDomain!).cleanupAnnotations
        if ← pure tgt.isLet <&&> Meta.isProp ty then
          let tgt' := Expr.forallE tgt.letName! ty tgt.letBody! .default
          let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
          g.assign <| .app g' tgt.letValue!
          return ← go g'.mvarId! i hs
        if let some pf := (← get).propToFVar.get? ty then
          let tgt' := tgt.bindingBody!.instantiate1 pf
          let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
          g.assign <| .lam tgt.bindingName! tgt.bindingDomain! g' tgt.bindingInfo!
          return ← go g'.mvarId! (i + 1) hs
        match tgt with
        | .forallE n t b bi =>
          let prop ← Meta.isProp t
          withGeneralizedProofs' t none fun hs' pfs' t' => do
            let t' := t'.cleanupAnnotations
            let tgt' := Expr.forallE n t' b bi
            let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
            let lam ←
              mkLambdaFVars hs' g' (usedOnly := false) (usedLetOnly := false)
            g.assign <| mkAppN lam pfs'
            let (fvar', g') ← g'.mvarId!.intro1P
            g'.withContext do Elab.pushInfoLeaf <|
              .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
            if prop then
              MGen.insertFVar t' (.fvar fvar')
            go g' (i + 1) (hs ++ hs')
        | .letE n t v b _ =>
          withGeneralizedProofs' t none fun hs' pfs' t' => do
            withGeneralizedProofs' v t' fun hs'' pfs'' v' => do
              let tgt' := Expr.letE n t' v' b false
              let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
              let lam ←
                mkLambdaFVars (hs' ++ hs'') g' (usedOnly := false) (usedLetOnly := false)
              g.assign <| mkAppN lam (pfs' ++ pfs'')
              let (fvar', g') ← g'.mvarId!.intro1P
              g'.withContext do Elab.pushInfoLeaf <|
                .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
              go g' (i + 1) (hs ++ hs' ++ hs'')
        | _ => unreachable!
      else
        let (fvar', g') ← g.intro1P
        g'.withContext do Elab.pushInfoLeaf <|
          .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
        go g' (i + 1) hs
    else if target then
      withGeneralizedProofs' (← g.getType) none fun hs' pfs' ty' => do
        let g' ← mkFreshExprSyntheticOpaqueMVar ty' tag
        g.assign <| mkAppN (← mkLambdaFVars hs' g' (usedOnly := false) (usedLetOnly := false)) pfs'
        return (hs ++ hs', g'.mvarId!)
    else
      return (hs, g)

end GeneralizeProofs

open Lean Elab Parser.Tactic Elab.Tactic Mathlib.Tactic.GeneralizeProofs
partial def generalizeProofs'
    (g : MVarId) (fvars : Array FVarId) (target : Bool) (config : Config := {}) :
    MetaM (Array Expr × MVarId) := do
  let (rfvars, g) ← g.revert fvars (clearAuxDeclsInsteadOfRevert := true)
  g.withContext do
    let s := { propToFVar := ← initialPropToFVar }
    GeneralizeProofs.generalizeProofsCore' g fvars rfvars target |>.run config |>.run' s

elab (name := generalizeProofsElab'') "generalize_proofs" config?:(Parser.Tactic.config)?
    hs:(ppSpace colGt binderIdent)* loc?:(location)? : tactic => withMainContext do
  let config ← elabConfig (mkOptionalNode config?)
  let (fvars, target) ←
    match expandOptLocation (Lean.mkOptionalNode loc?) with
    | .wildcard => pure ((← getLCtx).getFVarIds, true)
    | .targets t target => pure (← getFVarIds t, target)
  liftMetaTactic1 fun g => do
    let (pfs, g) ← generalizeProofs' g fvars target config
    g.withContext do
      let mut lctx ← getLCtx
      for h in hs, fvar in pfs do
        if let `(binderIdent| $s:ident) := h then
          lctx := lctx.setUserName fvar.fvarId! s.getId
        Expr.addLocalVarInfoForBinderIdent fvar h
      Meta.withLCtx lctx (← Meta.getLocalInstances) do
        let g' ← Meta.mkFreshExprSyntheticOpaqueMVar (← g.getType) (← g.getTag)
        g.assign g'
        return g'.mvarId!

end Harmonic
set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace OQS

namespace Split

variable {V : Type} [Fintype V] [DecidableEq V]

variable (s : PillarA.OQS.Split V)

open PillarA.LayerA

structure InteriorInv (L : Matrix V V ℝ) where

  inv : Matrix s.I s.I ℝ

  invOK : PillarA.LayerA.TwoSidedInv (s.blockII L) inv

structure InteriorWellposedAxis (L : Matrix V V ℝ) where
  PosWeights : Prop
  ConnInterior : Prop
  inv_of_axis : PosWeights → ConnInterior → ∃ _w : InteriorInv (s := s) L, True

namespace InteriorWellposedAxis

variable {L : Matrix V V ℝ}

def mkWitnessAxis (L : Matrix V V ℝ) : InteriorWellposedAxis (s := s) L := by
  refine ⟨(∃ w : InteriorInv (s := s) L, True), True, ?_⟩
  intro hPos _hConn
  exact hPos

end InteriorWellposedAxis

def DtN_of (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) : Matrix s.B s.B ℝ := PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := w.inv)

def interiorSolve (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    s.I → ℝ :=
  fun i => - (w.inv.mulVec ((s.blockIB L).mulVec φ)) i

def boundaryFlux (L : Matrix V V ℝ) (φ : s.B → ℝ) (uI : s.I → ℝ) :
    s.B → ℝ :=
  fun b => (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec uI b

theorem boundaryFlux_eq_DtN_mulVec
    (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    s.boundaryFlux L φ (s.interiorSolve L w φ)
      =
    (s.DtN_of L w).mulVec φ := by
  classical
  let rhsI : s.I → ℝ := ((s.blockIB L).mulVec φ)
  let wI : s.I → ℝ := w.inv.mulVec rhsI
  let M : Matrix s.B s.B ℝ := (s.blockBI L) * w.inv * (s.blockIB L)

  funext b

  have hMain :
      (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec (fun i => - wI i) b
        =
      ((s.blockBB L) + (-M)).mulVec φ b := by
    have hNeg :
        (s.blockBI L).mulVec (fun i => - wI i) b
          =
        - (s.blockBI L).mulVec wI b := by
      simp [Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, mul_neg]

    have hComp :
        M.mulVec φ b = (s.blockBI L).mulVec wI b := by
      simp [M, wI, rhsI, Matrix.mul_assoc, Matrix.mulVec_mulVec]

    have hNegMat : (-M).mulVec φ b = - (M.mulVec φ b) := by
      simp [M, Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, neg_mul]

    have hInteriorTerm :
        (s.blockBI L).mulVec (fun i => - wI i) b = (-M).mulVec φ b := by
      calc
        (s.blockBI L).mulVec (fun i => - wI i) b
            = - (s.blockBI L).mulVec wI b := by
              exact hNeg
        _   = - (M.mulVec φ b) := by
              exact congrArg Neg.neg hComp.symm
        _   = (-M).mulVec φ b := by
              exact hNegMat.symm

    have hAdd :
        ((s.blockBB L) + (-M)).mulVec φ b
          =
        (s.blockBB L).mulVec φ b + (-M).mulVec φ b := by
      simp [Matrix.mulVec, dotProduct, Finset.sum_add_distrib, add_mul]

    calc
      (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec (fun i => - wI i) b
          = (s.blockBB L).mulVec φ b + (-M).mulVec φ b := by
              simp [hInteriorTerm]
      _   = ((s.blockBB L) + (-M)).mulVec φ b := by
              simp [hAdd]

  have hw : s.interiorSolve L w φ = fun i => - wI i := by
    funext i
    simp [interiorSolve, wI, rhsI]

  simpa [boundaryFlux, DtN_of, PillarA.LayerA.DtN, sub_eq_add_neg, hw, M] using hMain

theorem blockII_mulVec_interiorSolve
    (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    (s.blockII L).mulVec (s.interiorSolve L w φ)
      =
    - (s.blockIB L).mulVec φ := by
  classical
  let rhs : s.I → ℝ := (s.blockIB L).mulVec φ
  have hL : (s.blockII L) * w.inv = (1 : Matrix s.I s.I ℝ) := w.invOK.2

  have hMulVec : (s.blockII L).mulVec (w.inv.mulVec rhs) = ((s.blockII L) * w.inv).mulVec rhs := by
    have h' : ((s.blockII L) * w.inv).mulVec rhs = (s.blockII L).mulVec (w.inv.mulVec rhs) := by
      simp [Matrix.mulVec_mulVec]
    exact h'.symm

  have hOne : (1 : Matrix s.I s.I ℝ).mulVec rhs = rhs := by
    funext i
    classical
    simp [Matrix.mulVec, Matrix.one_apply, dotProduct]

  funext i
  calc
    ((s.blockII L).mulVec (s.interiorSolve L w φ)) i
        = - ((s.blockII L).mulVec (w.inv.mulVec rhs)) i := by
            simp [interiorSolve, rhs, Matrix.mulVec, dotProduct,
              Finset.sum_neg_distrib, mul_neg]
    _   = - (((s.blockII L) * w.inv).mulVec rhs) i := by
            simp [hMulVec]
    _   = - ((1 : Matrix s.I s.I ℝ).mulVec rhs) i := by
            simp [hL]
    _   = (- rhs) i := by
            simp [hOne]
    _   = (- (s.blockIB L).mulVec φ) i := by
            simp [rhs]

end Split

end OQS

end PillarA
