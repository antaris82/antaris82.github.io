import Mathlib
import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.OQS.DtN

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace OQS
namespace Split

noncomputable section

open PillarA.LayerA

variable {V : Type} [Fintype V] [DecidableEq V]
variable (s : PillarA.OQS.Split V)

namespace DtNStabilized

variable {b : Nat}

noncomputable def symm {ι : Type} [Fintype ι] (A : Matrix ι ι ℝ) : Matrix ι ι ℝ :=
  (1 / 2 : ℝ) • (A + Matrix.transpose A)

noncomputable def stabilize {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) (δ : ℝ) : Matrix ι ι ℝ :=
  A + δ • (1 : Matrix ι ι ℝ)

noncomputable def deltaSPD (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) : ℝ :=
  PillarA.LayerA.MatrixNorm.deltaSPD (ι := ι) p.eps A

noncomputable abbrev deltaNum (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) : ℝ :=
  deltaSPD (p := p) (ι := ι) A

@[simp] lemma deltaSPD_eq_deltaNum (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    deltaSPD (p := p) (ι := ι) A = deltaNum (p := p) (ι := ι) A := rfl

@[simp] lemma deltaNum_def (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    deltaNum (p := p) (ι := ι) A = p.eps * max 1 (PillarA.LayerA.MatrixNorm.frob (ι := ι) A) := by
  simp [deltaNum, deltaSPD, PillarA.LayerA.MatrixNorm.deltaSPD]

lemma deltaNum_pos (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    0 < deltaNum (p := p) (ι := ι) A := by
  simpa [deltaNum, deltaSPD] using
    (PillarA.LayerA.MatrixNorm.deltaSPD_pos (ι := ι) (ε := p.eps) (A := A) p.eps_pos)

lemma deltaNum_ge_eps (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    p.eps ≤ deltaNum (p := p) (ι := ι) A := by
  have hmax : (1 : ℝ) ≤ max 1 (PillarA.LayerA.MatrixNorm.frob (ι := ι) A) := by
    exact le_max_left _ _
  have h := mul_le_mul_of_nonneg_left hmax (le_of_lt p.eps_pos)
  simpa [deltaNum_def, mul_one] using h

noncomputable def LII_stabilized (p : Policy b) (L : Matrix V V ℝ) :
    Matrix s.I s.I ℝ :=
  let A : Matrix s.I s.I ℝ := symm (ι := s.I) (s.blockII L)
  stabilize A (deltaSPD (p := p) A)

structure InteriorInvStabilized (p : Policy b) (L : Matrix V V ℝ) where
  inv : Matrix s.I s.I ℝ
  invOK : PillarA.LayerA.TwoSidedInv (LII_stabilized (s := s) (p := p) L) inv

def interiorInvStabilized_of_det
    (p : Policy b) (L : Matrix V V ℝ)
    (hdet : (LII_stabilized (s := s) (p := p) L).det ≠ 0) :
    InteriorInvStabilized (s := s) (p := p) L := by
  classical
  let A : Matrix s.I s.I ℝ := LII_stabilized (s := s) (p := p) L
  refine ⟨A⁻¹, ?_⟩
  simpa [A] using
    (PillarA.LayerA.gate_DTN_WELLPOSED_canonical (ι := s.I) (A := A) hdet)

noncomputable def DtN_stabilized (p : Policy b) (L : Matrix V V ℝ) :
    Matrix s.B s.B ℝ :=
  PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := (LII_stabilized (s := s) (p := p) L)⁻¹)

noncomputable def DtN_stabilized_of (p : Policy b) (L : Matrix V V ℝ)
    (w : InteriorInvStabilized (s := s) (p := p) L) :
    Matrix s.B s.B ℝ :=
  PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := w.inv)

noncomputable def dtn_stabilized_of_det
    (p : Policy b) (L : Matrix V V ℝ)
    (hdet : (LII_stabilized (s := s) (p := p) L).det ≠ 0) :
    Matrix s.B s.B ℝ :=
  DtN_stabilized_of (s := s) (p := p) (L := L)
    (w := interiorInvStabilized_of_det (s := s) (p := p) (L := L) hdet)

end DtNStabilized

end

end Split
end OQS
end PillarA
