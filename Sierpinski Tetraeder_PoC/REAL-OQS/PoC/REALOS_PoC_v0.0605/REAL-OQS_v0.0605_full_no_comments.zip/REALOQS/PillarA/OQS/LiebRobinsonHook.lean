import Mathlib
import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Kinematics.Causality
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.RG.ScaleWindow

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace OQS

open PillarA.LayerA
open PillarA.Kinematics
open PillarA.RG

universe u v w

structure Evolution (A : Type u) where
  T : Nat → A → A
  T0 : ∀ a, T 0 a = a

  T_succ : ∀ n a, T (n+1) a = T 1 (T n a)

structure CommutatorNorm (A : Type u) where
  comm : A → A → A
  norm : A → ENNReal

structure Support (Ω : Type v) (RN : PillarA.LayerA.RegionNet Ω) (A : Type u) where
  supp : A → RN.Region

structure LiebRobinsonBound {Ω : Type v} (RN : PillarA.LayerA.RegionNet Ω) (A : Type u) where
  evo : Evolution A
  cn  : CommutatorNorm A
  sup : Support Ω RN A

  vLR : ENNReal

  LR : Nat → A → A → Prop

  lr_all : ∀ t a b, LR t a b

structure LiebRobinsonHook {X : Type}
    (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) where

  win : ScaleWindow

  vLR : ENNReal

  step_bound_of_LR : ∀ {x y : X}, ST.step x y → dist (rm := rm) x y ≤ vLR

namespace LiebRobinsonHook

variable {X : Type} {ST : DiscreteSpacetime X} {rm : ResistanceMetric X}
variable (H : LiebRobinsonHook (ST := ST) (rm := rm))

def toCausalSpeedLimit : Kinematics.CausalSpeedLimit ST rm := by
  classical
  refine { c := H.vLR, step_bound := ?_ }
  intro x y hstep
  exact H.step_bound_of_LR (x := x) (y := y) hstep

@[simp] theorem toCausalSpeedLimit_c : (H.toCausalSpeedLimit).c = H.vLR := by
  rfl

theorem gate_worldline_bounded (γ : ST.Worldline) :
    Kinematics.CausalSpeedLimit.WorldlineBounded
      (ST := ST) (rm := rm) (H.toCausalSpeedLimit) γ := by
  simpa [LiebRobinsonHook.toCausalSpeedLimit] using
    (Kinematics.CausalSpeedLimit.gate_worldline_bounded
      (ST := ST) (rm := rm) (H.toCausalSpeedLimit) γ)

theorem finite_c_of_finite_v (hv : H.vLR ≠ (⊤ : ENNReal)) :
    (H.toCausalSpeedLimit).c ≠ (⊤ : ENNReal) := by
  simpa [LiebRobinsonHook.toCausalSpeedLimit] using hv

theorem derive_step_bound_from_LR
    {RN : PillarA.LayerA.RegionNet X} {A : Type u}
    (B : LiebRobinsonBound (RN := RN) (A := A))
    (hcompat : True) :
    ∀ {x y : X}, ST.step x y → dist (rm := rm) x y ≤ H.vLR := by
  cases hcompat
  cases B
  intro x y hstep
  exact H.step_bound_of_LR (x := x) (y := y) hstep

end LiebRobinsonHook

end OQS
end PillarA
