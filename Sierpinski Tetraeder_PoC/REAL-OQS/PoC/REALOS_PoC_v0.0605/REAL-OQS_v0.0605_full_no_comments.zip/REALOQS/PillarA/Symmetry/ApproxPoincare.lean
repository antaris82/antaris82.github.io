import Mathlib
import REALOQS.PillarA.RG.ScaleWindow
import REALOQS.PillarA.Symmetry.ApproxIsometry

set_option autoImplicit false

namespace PillarA

namespace Symmetry

open scoped BigOperators

variable {X : Type} {d : Dist X}

structure GroupLikeAction (H : Type) (X : Type) where
  one : H
  mul : H → H → H
  inv : H → H
  act : H → X → X
  one_act : ∀ x : X, act one x = x
  mul_act : ∀ a b : H, ∀ x : X, act (mul a b) x = act a (act b x)
  inv_left : ∀ a : H, ∀ x : X, act (inv a) (act a x) = x

namespace GroupLikeAction

variable {H : Type}

theorem act_congr (A : GroupLikeAction H X) {a b : H} (h : a = b) (x : X) :
    A.act a x = A.act b x := by
  simp [h]

end GroupLikeAction

structure ApproxPoincare (X : Type) (d : Dist X) where
  W : PillarA.RG.ScaleWindow

  Trans : Type
  transAct : GroupLikeAction Trans X
  transIso : Trans → ApproxIsometry X d

  Rot : Type
  rotAct : GroupLikeAction Rot X
  rotIso : Rot → ApproxIsometry X d

  Boost : Type
  boostAct : GroupLikeAction Boost X
  boostIso : Boost → ApproxIsometry X d

  trans_f : ∀ t : Trans, (transIso t).f = transAct.act t
  rot_f : ∀ r : Rot, (rotIso r).f = rotAct.act r
  boost_f : ∀ b : Boost, (boostIso b).f = boostAct.act b

  trans_on : ∀ t : Trans, (transIso t).err ≤ W.epsSup
  rot_on : ∀ r : Rot, (rotIso r).err ≤ W.epsSup
  boost_on : ∀ b : Boost, (boostIso b).err ≤ W.epsSup

namespace ApproxPoincare

variable (P : ApproxPoincare X d)
abbrev τ (t : P.Trans) : X → X := P.transAct.act t

abbrev ρ (r : P.Rot) : X → X := P.rotAct.act r

abbrev β (b : P.Boost) : X → X := P.boostAct.act b

theorem trans_upper (t : P.Trans) :
    ∀ x y : X, d (P.τ t x) (P.τ t y) ≤ d x y + P.W.epsSup := by
  intro x y
  have hf : (P.transIso t).f = P.τ t := P.trans_f t
  have hwin : (P.transIso t).err ≤ P.W.epsSup := P.trans_on t
  simpa [τ, hf] using (ApproxIsometry.upper_epsSup (W := P.W) (A := P.transIso t) hwin x y)

theorem rot_upper (r : P.Rot) :
    ∀ x y : X, d (P.ρ r x) (P.ρ r y) ≤ d x y + P.W.epsSup := by
  intro x y
  have hf : (P.rotIso r).f = P.ρ r := P.rot_f r
  have hwin : (P.rotIso r).err ≤ P.W.epsSup := P.rot_on r
  simpa [ρ, hf] using (ApproxIsometry.upper_epsSup (W := P.W) (A := P.rotIso r) hwin x y)

theorem boost_upper (b : P.Boost) :
    ∀ x y : X, d (P.β b x) (P.β b y) ≤ d x y + P.W.epsSup := by
  intro x y
  have hf : (P.boostIso b).f = P.β b := P.boost_f b
  have hwin : (P.boostIso b).err ≤ P.W.epsSup := P.boost_on b
  simpa [β, hf] using (ApproxIsometry.upper_epsSup (W := P.W) (A := P.boostIso b) hwin x y)

theorem trans_comp_contract (a b : P.Trans) :
    ∃ c : P.Trans,
      (P.τ c) = (P.τ a) ∘ (P.τ b) ∧
      (P.transIso c).err ≤ (P.transIso a).err + (P.transIso b).err + P.W.epsSup := by
  refine ⟨P.transAct.mul a b, ?_, ?_⟩
  · funext x
    exact P.transAct.mul_act a b x
  · have hwin : (P.transIso (P.transAct.mul a b)).err ≤ P.W.epsSup :=
      P.trans_on (P.transAct.mul a b)
    have hweak :
        P.W.epsSup ≤ (P.transIso a).err + (P.transIso b).err + P.W.epsSup := by
      exact le_add_of_nonneg_left (by positivity)
    exact le_trans hwin hweak

theorem approx_commute_contract
    (t : P.Trans) (r : P.Rot) (b : P.Boost) :
    let M : ENNReal := P.W.epsSup + P.W.epsSup + P.W.epsSup
    let W' : PillarA.RG.ScaleWindow := PillarA.RG.ScaleWindow.relax P.W M
    (ApproxIsometry.OnWindow W'
        ((P.transIso t) ∘ₐ ((P.rotIso r) ∘ₐ (P.boostIso b))))
      ∧
      (ApproxIsometry.OnWindow W'
        ((P.boostIso b) ∘ₐ ((P.rotIso r) ∘ₐ (P.transIso t)))) := by
  classical
  let M : ENNReal := P.W.epsSup + P.W.epsSup + P.W.epsSup
  let W' : PillarA.RG.ScaleWindow := PillarA.RG.ScaleWindow.relax P.W M
  have hM : M ≤ W'.epsSup := by
    simpa [W', M] using (PillarA.RG.ScaleWindow.epsSup_relax_ge P.W M)
  have ht : (P.transIso t).err ≤ P.W.epsSup := P.trans_on t
  have hr : (P.rotIso r).err ≤ P.W.epsSup := P.rot_on r
  have hb : (P.boostIso b).err ≤ P.W.epsSup := P.boost_on b
  have htri₁ :
      ((P.transIso t) ∘ₐ ((P.rotIso r) ∘ₐ (P.boostIso b))).err ≤ M := by
    have hbr : (P.boostIso b).err + (P.rotIso r).err ≤ P.W.epsSup + P.W.epsSup :=
      add_le_add hb hr
    have h1 :
        (P.boostIso b).err + (P.rotIso r).err + (P.transIso t).err ≤
          (P.W.epsSup + P.W.epsSup) + (P.transIso t).err := by
      exact add_le_add_right hbr (P.transIso t).err
    have h2 :
        (P.W.epsSup + P.W.epsSup) + (P.transIso t).err ≤
          (P.W.epsSup + P.W.epsSup) + P.W.epsSup := by
      exact add_le_add_left ht (P.W.epsSup + P.W.epsSup)
    have hbrt :
        (P.boostIso b).err + (P.rotIso r).err + (P.transIso t).err ≤
          (P.W.epsSup + P.W.epsSup) + P.W.epsSup := le_trans h1 h2
    simpa [M, ApproxIsometry.comp, add_assoc, add_comm, add_left_comm] using hbrt

  have htri₂ :
      ((P.boostIso b) ∘ₐ ((P.rotIso r) ∘ₐ (P.transIso t))).err ≤ M := by
    have hrt : (P.transIso t).err + (P.rotIso r).err ≤ P.W.epsSup + P.W.epsSup :=
      add_le_add ht hr
    have h1 :
        (P.transIso t).err + (P.rotIso r).err + (P.boostIso b).err ≤
          (P.W.epsSup + P.W.epsSup) + (P.boostIso b).err := by
      exact add_le_add_right hrt (P.boostIso b).err
    have h2 :
        (P.W.epsSup + P.W.epsSup) + (P.boostIso b).err ≤
          (P.W.epsSup + P.W.epsSup) + P.W.epsSup := by
      exact add_le_add_left hb (P.W.epsSup + P.W.epsSup)
    have hrtb :
        (P.transIso t).err + (P.rotIso r).err + (P.boostIso b).err ≤
          (P.W.epsSup + P.W.epsSup) + P.W.epsSup := le_trans h1 h2
    simpa [M, ApproxIsometry.comp, add_assoc, add_comm, add_left_comm] using hrtb
  have hw₁ :
      ApproxIsometry.OnWindow W'
        ((P.transIso t) ∘ₐ ((P.rotIso r) ∘ₐ (P.boostIso b))) := by
    exact le_trans htri₁ hM
  have hw₂ :
      ApproxIsometry.OnWindow W'
        ((P.boostIso b) ∘ₐ ((P.rotIso r) ∘ₐ (P.transIso t))) := by
    exact le_trans htri₂ hM

  simpa [ApproxIsometry.OnWindow, W', M] using And.intro hw₁ hw₂

end ApproxPoincare

end Symmetry
end PillarA
