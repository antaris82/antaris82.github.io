import Mathlib
import REALOQS.PillarA.RG.ScaleWindow

set_option autoImplicit false

namespace PillarA
namespace Symmetry

open scoped BigOperators

noncomputable section

abbrev Dist (X : Type) : Type := X → X → ENNReal

structure ApproxIsometry (X : Type) (d : Dist X) where
    f : X → X
    err : ENNReal
    upper : ∀ x y : X, d (f x) (f y) ≤ d x y + err
    lower : ∀ x y : X, d x y ≤ d (f x) (f y) + err

namespace ApproxIsometry

variable {X : Type} {d : Dist X}

def id (X : Type) (d : Dist X) : ApproxIsometry X d :=
{ f := _root_.id,
  err := 0,
  upper := by
    intro x y
    simp
  lower := by
    intro x y
    simp }

def comp (g : ApproxIsometry X d) (f : ApproxIsometry X d) : ApproxIsometry X d :=
{ f := g.f ∘ f.f,
  err := f.err + g.err,
    upper := by
      intro x y
      have h₁ : d (g.f (f.f x)) (g.f (f.f y)) ≤ d (f.f x) (f.f y) + g.err := by
        simpa [Function.comp] using g.upper (f.f x) (f.f y)
      have h₂ : d (f.f x) (f.f y) ≤ d x y + f.err := by
        simpa using f.upper x y
      have h₃ : d (f.f x) (f.f y) + g.err ≤ (d x y + f.err) + g.err := by
        exact add_le_add_right h₂ g.err
      have : d (g.f (f.f x)) (g.f (f.f y)) ≤ (d x y + f.err) + g.err := le_trans h₁ h₃
      simpa [add_assoc, Function.comp] using this,
    lower := by
      intro x y
      have h₁ : d x y ≤ d (f.f x) (f.f y) + f.err := by
        simpa using f.lower x y
      have h₂ : d (f.f x) (f.f y) ≤ d (g.f (f.f x)) (g.f (f.f y)) + g.err := by
        simpa [Function.comp] using g.lower (f.f x) (f.f y)
      have h₃ :
          d (f.f x) (f.f y) + f.err ≤ (d (g.f (f.f x)) (g.f (f.f y)) + g.err) + f.err := by
        exact add_le_add_right h₂ f.err
      have : d x y ≤ (d (g.f (f.f x)) (g.f (f.f y)) + g.err) + f.err := le_trans h₁ h₃
      simpa [Function.comp, add_assoc, add_comm, add_left_comm] using this }

infixr:80 " ∘ₐ " => comp

def OnWindow (W : PillarA.RG.ScaleWindow) (A : ApproxIsometry X d) : Prop := A.err ≤ W.epsSup

theorem upper_epsSup (W : PillarA.RG.ScaleWindow) (A : ApproxIsometry X d)
    (h : A.OnWindow W) :
    ∀ x y : X, d (A.f x) (A.f y) ≤ d x y + W.epsSup := by
  intro x y
  have h₁ : d (A.f x) (A.f y) ≤ d x y + A.err := A.upper x y
  have h₂ : d x y + A.err ≤ d x y + W.epsSup := by
    exact add_le_add_left h (d x y)
  exact le_trans h₁ h₂

theorem lower_epsSup (W : PillarA.RG.ScaleWindow) (A : ApproxIsometry X d)
    (h : A.OnWindow W) :
    ∀ x y : X, d x y ≤ d (A.f x) (A.f y) + W.epsSup := by
  intro x y
  have h₁ : d x y ≤ d (A.f x) (A.f y) + A.err := A.lower x y
  have h₂ : d (A.f x) (A.f y) + A.err ≤ d (A.f x) (A.f y) + W.epsSup := by
    exact add_le_add_left h (d (A.f x) (A.f y))
  exact le_trans h₁ h₂

theorem onWindow_comp_closed
    (W : PillarA.RG.ScaleWindow)
    (A B : ApproxIsometry X d)
    (hA : A.OnWindow W) (hB : B.OnWindow W)
    (hAB : A.err + B.err ≤ W.epsSup) :
    (B ∘ₐ A).OnWindow W := by
  have _ : A.OnWindow W := hA
  have _ : B.OnWindow W := hB
  simpa [OnWindow, comp, add_comm, add_left_comm, add_assoc] using hAB

theorem onWindow_comp_relax
    (W : PillarA.RG.ScaleWindow)
    (A B : ApproxIsometry X d)
    (hA : A.OnWindow W) (hB : B.OnWindow W) :
    (B ∘ₐ A).OnWindow
      (PillarA.RG.ScaleWindow.relax W (W.epsSup + W.epsSup)) := by
  have hsum : A.err + B.err ≤ W.epsSup + W.epsSup := add_le_add hA hB
  have hcomp : (B ∘ₐ A).err ≤ W.epsSup + W.epsSup := by
    simpa [comp] using hsum
  have hM :
      W.epsSup + W.epsSup ≤
        (PillarA.RG.ScaleWindow.relax W (W.epsSup + W.epsSup)).epsSup := by
    simpa using
      (PillarA.RG.ScaleWindow.epsSup_relax_ge W (W.epsSup + W.epsSup))
  have :
      (B ∘ₐ A).err ≤
        (PillarA.RG.ScaleWindow.relax W (W.epsSup + W.epsSup)).epsSup :=
    le_trans hcomp hM
  simpa [OnWindow] using this

end ApproxIsometry

end

end Symmetry
end PillarA
