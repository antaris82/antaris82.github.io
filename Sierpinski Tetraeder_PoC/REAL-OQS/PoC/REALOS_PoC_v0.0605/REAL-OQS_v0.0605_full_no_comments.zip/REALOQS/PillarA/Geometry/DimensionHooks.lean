import Mathlib
import REALOQS.PillarA.RG.ScaleWindow

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA

namespace Geometry

open PillarA.RG

structure HeatKernelHook where
    win : ScaleWindow
    t : Nat → ℝ
    P : Nat → ℝ

    ht_pos : ∀ k, win.In k → 0 < t k
    hP_pos : ∀ k, win.In k → 0 < P k

    ht_step : ∀ k, win.inSucc k → t k < t (k + 1)

namespace HeatKernelHook

variable (H : HeatKernelHook)

noncomputable def dS_est (k : Nat) : ℝ := let t0 := H.t k
  let t1 := H.t (k + 1)
  let p0 := H.P k
  let p1 := H.P (k + 1)
  (-2) * (Real.log p1 - Real.log p0) / (Real.log t1 - Real.log t0)

@[simp] theorem dS_est_def (k : Nat) :
    H.dS_est k =
      (-2) * (Real.log (H.P (k + 1)) - Real.log (H.P k))
        / (Real.log (H.t (k + 1)) - Real.log (H.t k)) := by
  rfl

theorem denom_ne_zero (k : Nat) (_hk : H.win.inSucc k) :
    (Real.log (H.t (k + 1)) - Real.log (H.t k)) ≠ 0 := by
  exact
    sub_ne_zero_of_ne
      (ne_of_gt (Real.log_lt_log (H.ht_pos k (by exact _hk.1)) (H.ht_step k _hk)))

theorem dS_est_eq_zero_of_P_const
    (k : Nat) (_hk : H.win.inSucc k)
    (hP : H.P (k + 1) = H.P k) :
    H.dS_est k = 0 := by
  simp [HeatKernelHook.dS_est, hP]

end HeatKernelHook

structure SpectralDimensionHook extends HeatKernelHook where
    dS : ℝ

    approx_const :
    ∀ k, win.inSucc k →
      abs ((toHeatKernelHook.dS_est k) - dS)
        ≤ (win.eps k).toReal

namespace SpectralDimensionHook

def asHeat (H : SpectralDimensionHook) : HeatKernelHook :=
  { win := H.win
    t := H.t
    P := H.P
    ht_pos := H.ht_pos
    hP_pos := H.hP_pos
    ht_step := H.ht_step }

theorem gate_approx_const (H : SpectralDimensionHook) (k : Nat) (hk : H.win.inSucc k) :
    abs ((H.asHeat.dS_est k) - H.dS) ≤ (H.win.eps k).toReal := by
  convert H.approx_const k hk using 1

def LogLogLinear (H : SpectralDimensionHook) (C : ℝ) : Prop := ∀ k, H.win.In k →
    abs (Real.log (H.P k) - (C - (H.dS / 2) * Real.log (H.t k)))
      ≤ (H.win.eps k).toReal

theorem dS_est_exact_of_loglog_zero
    (H : SpectralDimensionHook)
    (C : ℝ)
    (h0 : ∀ k, H.win.In k → H.win.eps k = 0)
    (hlin : H.LogLogLinear C) :
    ∀ k, H.win.inSucc k → (H.asHeat.dS_est k) = H.dS := by
  intro k hk;
  have h_dS_est_const : ∀ k, H.win.In k → Real.log (H.P k) = C - (H.dS / 2) * Real.log (H.t k) := by
    intro k hk; specialize hlin k hk; rw [ h0 k hk ] at hlin; norm_num at hlin; linarith;
  unfold PillarA.Geometry.SpectralDimensionHook.asHeat PillarA.Geometry.HeatKernelHook.dS_est;
  rw [ div_eq_iff ];
  · rw [ h_dS_est_const k hk.1, h_dS_est_const ( k + 1 ) hk.2 ] ; ring;
  · exact sub_ne_zero_of_ne <| ne_of_gt <| Real.log_lt_log ( H.ht_pos k hk.1 ) <| H.ht_step k hk

end SpectralDimensionHook

end Geometry

end PillarA
