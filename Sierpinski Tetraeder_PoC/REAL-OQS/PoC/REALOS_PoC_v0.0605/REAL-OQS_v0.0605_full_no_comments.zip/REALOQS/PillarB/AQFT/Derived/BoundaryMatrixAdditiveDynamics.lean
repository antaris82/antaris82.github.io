import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler
open PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

universe u

section Generic

variable {A : Type u}

def PreservesSet (f : A → A) (S : Set A) : Prop :=
  ∀ ⦃x : A⦄, x ∈ S → f x ∈ S

end Generic

namespace TreeOfCliquesFromPillarA
namespace ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

abbrev RichTopAlg [Fact (0 < b)] : Type :=
  (N_rich_ToC (b := b) (p := p)).LAN.Alg
    ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)

abbrev AdditiveTopAlg [Fact (0 < b)] : Type :=
  (N_add_ToC (b := b) (p := p)).LAN.Alg
    ((N_add_ToC (b := b) (p := p)).LAN.RN.top)

section ObservableTop

variable [Fact (0 < b)]

def observableTopBasisGenSet_ToC : Set (RichTopAlg (b := b) (p := p)) :=
  PillarB.AQFT.Gates.HaagKastler.basisGenSet
    (N := N_rich_ToC (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)

@[simp] theorem mem_observableTopBasisGenSet_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) ↔
      A ∈ PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  rfl

def observableTopCarrier_ToC : Set (RichTopAlg (b := b) (p := p)) :=
  { A |
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A }

@[simp] theorem mem_observableTopCarrier_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A := by
  rfl

theorem observableTopBasisGenSet_subset_observableTopCarrier_ToC :
    observableTopBasisGenSet_ToC (b := b) (p := p) ⊆
      observableTopCarrier_ToC (b := b) (p := p) := by
  intro A hA
  exact generatedBy_of_mem
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)) hA

def topBasisGenerator_ToC
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RichTopAlg (b := b) (p := p) :=
  (N_rich_ToC (b := b) (p := p)).LAN.incl h A

theorem topBasisGenerator_mem_observableTopCarrier_ToC
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    topBasisGenerator_ToC (b := b) (p := p)
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  have hgen :
      topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
          A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) := by
    exact mem_basisGenSet_of_basic
      (N := N_rich_ToC (b := b) (p := p))
      (B := B_ToC (b := b) (p := p))
      hu
      (_root_.PillarA.LayerA.RegionNet.le_top'
        (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
      A
  exact observableTopBasisGenSet_subset_observableTopCarrier_ToC
    (b := b) (p := p) hgen

def dynImageTopBasisGenerator_ToC (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RichTopAlg (b := b) (p := p) :=
  (dyn_top_ToC (b := b) (p := p)).α t
    (topBasisGenerator_ToC (b := b) (p := p) h A)

@[simp] theorem topBasisGenerator_ToC_toMatrix
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RegionBlockMat.toMatrix
        (topBasisGenerator_ToC (b := b) (p := p) h A) =
      RegionBlockMat.toMatrix A := by
  exact boundaryMatrixRegionToMatrix_natural
    (Ω := Ω (b := b) (p := p)) h A

@[simp] theorem dynImageTopBasisGenerator_ToC_toMatrix
    (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A) =
      (fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A) := by
  rw [dynImageTopBasisGenerator_ToC]
  rw [dyn_top_ToC_eq_boundaryMatrixTopDynMinus (b := b) (p := p)]
  rw [boundaryMatrixTopDynMinus_alpha_apply]
  rw [topBasisGenerator_ToC_toMatrix (b := b) (p := p) h A]
  rw [matrixToTopRegion_toMatrix]

theorem dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_regionLocalized
    (t : ℝ)
    {u v : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hv : (B_ToC (b := b) (p := p)).basic v)
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u)
    (hloc : RegionLocalized v
      ((fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A))) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  let Bv : (N_rich_ToC (b := b) (p := p)).LAN.Alg v :=
    ⟨(fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A), hloc⟩
  have hgen :
      topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) v)
          Bv ∈ observableTopCarrier_ToC (b := b) (p := p) :=
    topBasisGenerator_mem_observableTopCarrier_ToC
      (b := b) (p := p) hv Bv
  have hEq :
      dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A =
        topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) v)
          Bv := by
    apply RegionBlockMat.ext
    rw [dynImageTopBasisGenerator_ToC_toMatrix (b := b) (p := p) t h A]
    rfl
  simpa [hEq] using hgen

theorem dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_basic_ball_regionLocalized
    (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u)
    (hloc : RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      ((fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A))) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_regionLocalized
    (b := b) (p := p) t
    (u := u)
    (v := boundaryBallFromL (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p)) i)
    (B_ToC_basic_ball (b := b) (p := p) i)
    h A hloc

theorem dyn_top_ToC_zero_maps_topBasisGenerator_to_observableTop
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  rw [dynImageTopBasisGenerator_ToC]
  rw [_root_.PillarB.AQFT.StarAlgDynamics.alpha_zero_apply
      (D := dyn_top_ToC (b := b) (p := p))]
  exact topBasisGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) hu A

theorem dyn_top_ToC_zero_maps_basic_ball_generator_to_observableTop
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
          (boundaryBallFromL (Ω := Ω (b := b) (p := p))
            (L := L (b := b) (p := p)) i))
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_zero_maps_topBasisGenerator_to_observableTop
    (b := b) (p := p)
    (B_ToC_basic_ball (b := b) (p := p) i) A

def observableTopSubalgebra_ToC :
    StarSubalgebra
      ((N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)) where
  carrier := observableTopCarrier_ToC (b := b) (p := p)
  zero_mem := by
    exact GeneratedBy.zero
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      (PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
  one_mem := by
    exact GeneratedBy.one
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      (PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
  add_mem := by
    intro x y hx hy
    exact GeneratedBy.add
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx hy
  mul_mem := by
    intro x y hx hy
    exact GeneratedBy.mul
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx hy
  neg_mem := by
    intro x hx
    exact GeneratedBy.neg
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx
  star_mem := by
    intro x hx
    exact GeneratedBy.star
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx

@[simp] theorem mem_observableTopSubalgebra_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ (observableTopSubalgebra_ToC (b := b) (p := p)).carrier ↔
      A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem additiveTop_mem_observableTopCarrier_ToC
    (A : AdditiveTopAlg (b := b) (p := p)) :
    observableInclRich_ToC (b := b) (p := p)
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top) A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact A.2

theorem mem_observableTopCarrier_ToC_iff_exists_preimage
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      ∃ B : AdditiveTopAlg (b := b) (p := p),
        observableInclRich_ToC (b := b) (p := p)
          ((N_add_ToC (b := b) (p := p)).LAN.RN.top) B = A := by
  constructor
  · intro hA
    refine ⟨⟨A, hA⟩, ?_⟩
    rfl
  · rintro ⟨B, rfl⟩
    exact additiveTop_mem_observableTopCarrier_ToC (b := b) (p := p) B

@[simp] theorem observableTopState_is_restriction_defined :
    ρAdd_top (b := b) (p := p) =
      boundaryMatrixAdditiveTopFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem observableQuasiLocal_is_restriction_defined :
    Φ_add_FromA (b := b) (p := p) =
      boundaryMatrixAdditiveQuasiLocalStateFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

def dyn_top_ToC_preserves_N_add_top : Prop :=
  ∀ t : ℝ,
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α t)
      (observableTopCarrier_ToC (b := b) (p := p))

def dyn_top_ToC_preserves_observableTopSubalgebra : Prop :=
  ∀ t : ℝ,
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α t)
      ((observableTopSubalgebra_ToC (b := b) (p := p)).carrier)

end ObservableTop

theorem basic_region_eq_boundaryBallFromL
    {u : BoundaryRegion (Ω := Ω (b := b) (p := p))}
    (hu : (B_ToC (b := b) (p := p)).basic u) :
    ∃ i : Ω (b := b) (p := p),
      u = boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i := by
  change u ∈ (Finset.univ.image
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)))) at hu
  rcases Finset.mem_image.mp hu with ⟨i, _hiU, hi⟩
  exact ⟨i, hi.symm⟩

section ObservableTop

variable [Fact (0 < b)]

def dyn_top_ToC_preserves_basic_ball_generator_localization : Prop :=
  ∀ (t : ℝ) (i : Ω (b := b) (p := p))
      {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i ≤
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
      (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)),
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A))

theorem dyn_top_ToC_preserves_N_add_top_of_preserves_basic_ball_generator_localization
    (hball : dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro t A hA
  exact GeneratedBy.preserved
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
    ((dyn_top_ToC (b := b) (p := p)).α t)
    (by
      intro y hy
      rcases hy with ⟨u, hu, hle, x, rfl⟩
      rcases basic_region_eq_boundaryBallFromL (b := b) (p := p) hu with ⟨i, rfl⟩
      exact dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_basic_ball_regionLocalized
        (b := b) (p := p) t
        (u := boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)
        hle i x (hball t i (h := hle) x))
    hA

theorem dyn_top_ToC_zero_preserves_basic_ball_generator_localization
    (i : Ω (b := b) (p := p))
    {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i ≤
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) 0 h A)) := by
  rw [dynImageTopBasisGenerator_ToC_toMatrix (b := b) (p := p) 0 h A]
  rw [fullBoundaryDynMinus_alpha_apply]
  rw [fullBoundaryDynMapMinus_zero_apply]
  exact A.2

@[simp] theorem dyn_top_ToC_preserves_observableTopSubalgebra_iff :
    dyn_top_ToC_preserves_observableTopSubalgebra (b := b) (p := p) ↔
      dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  rfl

theorem dyn_top_ToC_zero_preserves_N_add_top :
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α 0)
      (observableTopCarrier_ToC (b := b) (p := p)) := by
  intro A hA
  rw [_root_.PillarB.AQFT.StarAlgDynamics.alpha_zero_apply
      (D := dyn_top_ToC (b := b) (p := p)) A]
  exact hA

theorem dyn_top_ToC_preserves_N_add_top_of_preserves_basisGenerators
    (hgen : ∀ (t : ℝ) ⦃A : RichTopAlg (b := b) (p := p)⦄,
      A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) →
        (dyn_top_ToC (b := b) (p := p)).α t A ∈
          observableTopCarrier_ToC (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro t A hA
  exact GeneratedBy.preserved
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
    ((dyn_top_ToC (b := b) (p := p)).α t)
    (fun y hy => hgen t hy)
    hA

noncomputable def dyn_top_ToC_preserves_N_add_top_decidable :
    Decidable (dyn_top_ToC_preserves_N_add_top (b := b) (p := p)) := by
  classical
  infer_instance

theorem dyn_top_ToC_preserves_N_add_top_or_not :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) ∨
      ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  classical
  exact em _

end ObservableTop

end ToC
end TreeOfCliquesFromPillarA

end

end Derived
end AQFT
end PillarB
