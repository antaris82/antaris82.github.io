import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Data.Complex.Basic
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u}

def phaseArg (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) : Complex :=
  Complex.I * (((t * L i i : ℝ)) : Complex)

def phasePlusR (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) : Complex :=
  Complex.exp (phaseArg L t i)

def phaseMinusR (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) : Complex :=
  Complex.exp (- phaseArg L t i)

@[simp] theorem phaseArg_zero (L : Matrix Ω Ω ℝ) (i : Ω) :
    phaseArg L 0 i = 0 := by
  simp [phaseArg]

@[simp] theorem phaseArg_add (L : Matrix Ω Ω ℝ) (s t : ℝ) (i : Ω) :
    phaseArg L (s + t) i = phaseArg L s i + phaseArg L t i := by
  simp [phaseArg, add_mul, mul_add]

@[simp] theorem phasePlus_zero (L : Matrix Ω Ω ℝ) (i : Ω) :
    phasePlusR L 0 i = 1 := by
  simp [phasePlusR, phaseArg]

@[simp] theorem phaseMinus_zero (L : Matrix Ω Ω ℝ) (i : Ω) :
    phaseMinusR L 0 i = 1 := by
  simp [phaseMinusR, phaseArg]

@[simp] theorem phasePlus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) (i : Ω) :
    phasePlusR L (s + t) i = phasePlusR L s i * phasePlusR L t i := by
  simpa [phasePlusR, phaseArg_add] using Complex.exp_add (phaseArg L s i) (phaseArg L t i)

@[simp] theorem phaseMinus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) (i : Ω) :
    phaseMinusR L (s + t) i = phaseMinusR L s i * phaseMinusR L t i := by
  rw [phaseMinusR, phaseArg_add, neg_add, Complex.exp_add]
  rfl

@[simp] theorem phaseMinus_neg (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    phaseMinusR L (-t) i = phasePlusR L t i := by
  simp [phaseMinusR, phasePlusR, phaseArg]

@[simp] theorem phasePlus_neg (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    phasePlusR L (-t) i = phaseMinusR L t i := by
  simp [phaseMinusR, phasePlusR, phaseArg]

@[simp] theorem phaseMinus_mul_phasePlus (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    phaseMinusR L t i * phasePlusR L t i = 1 := by
  calc
    phaseMinusR L t i * phasePlusR L t i
        = Complex.exp (-(phaseArg L t i)) * Complex.exp (phaseArg L t i) := rfl
    _ = Complex.exp (-(phaseArg L t i) + phaseArg L t i) := by
          rw [← Complex.exp_add]
    _ = 1 := by simp

@[simp] theorem phasePlus_mul_phaseMinus (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    phasePlusR L t i * phaseMinusR L t i = 1 := by
  calc
    phasePlusR L t i * phaseMinusR L t i
        = phaseMinusR L t i * phasePlusR L t i := by simp [mul_comm]
    _ = 1 := phaseMinus_mul_phasePlus (L := L) t i

@[simp] theorem phaseArg_star (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    star (phaseArg L t i) = - phaseArg L t i := by
  simp [phaseArg]

@[simp] theorem star_cexp (z : Complex) :
    star (Complex.exp z) = Complex.exp (star z) := by
  exact (Complex.exp_conj z).symm

@[simp] theorem phasePlus_star (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    star (phasePlusR L t i) = phaseMinusR L t i := by
  rw [phasePlusR, phaseMinusR, star_cexp, phaseArg_star]

@[simp] theorem phaseMinus_star (L : Matrix Ω Ω ℝ) (t : ℝ) (i : Ω) :
    star (phaseMinusR L t i) = phasePlusR L t i := by
  rw [phaseMinusR, star_cexp, phasePlusR, star_neg, phaseArg_star, neg_neg]

end
end Derived
end AQFT
end PillarB
