import Mathlib.Data.Real.Basic
import REALOQS.PillarB.AQFT.HaagKastler.Support

set_option autoImplicit false

namespace PillarB.AQFT.HaagKastler

universe u v w

abbrev Momentum : Type := ℝ × ℝ × ℝ × ℝ

def forwardCone (p : Momentum) : Prop :=
  let p0 : ℝ := p.1
  let p1 : ℝ := p.2.1
  let p2 : ℝ := p.2.2.1
  let p3 : ℝ := p.2.2.2
  0 ≤ p0 ∧ p0 ^ 2 ≥ p1 ^ 2 + p2 ^ 2 + p3 ^ 2

def ForwardCone : Set Momentum := {p | forwardCone p}

structure RepData (G : Type u) where

  H : Type v

  U : G → H ≃ H

structure SpectrumWitness where

  support : Set Momentum

  support_subset_forward : support ⊆ ForwardCone

structure SpectrumCondition (G : Type u) where
  rep : RepData G
  spec : SpectrumWitness

end PillarB.AQFT.HaagKastler
