import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

structure CStarKMSStateOn (A : Type u)
    [CStarAlgebra A] [NormedAlgebra ℂ A] where
  β : ℝ
  dyn : StarAlgDynamics (SA := starAlgebraOfCStar A)
  state : CStarStateOn A
  isKMS : IsKMS (SA := starAlgebraOfCStar A) (D := dyn) β state.toStateOn

namespace CStarKMSStateOn

section Basic

variable {A : Type u}
variable [CStarAlgebra A] [NormedAlgebra ℂ A]

variable (K : CStarKMSStateOn A)

theorem beta_pos : 0 < K.β := K.isKMS.beta_pos

theorem invariant : IsInvariant (SA := starAlgebraOfCStar A) K.dyn K.state.toStateOn :=
  K.isKMS.invariant

def toKMSState (K : CStarKMSStateOn A) : KMSState (SA := starAlgebraOfCStar A) where
  β := K.β
  dyn := K.dyn
  state := K.state.toStateOn
  isKMS := K.isKMS

@[simp] theorem toKMSState_beta (K : CStarKMSStateOn A) : K.toKMSState.β = K.β := rfl

@[simp] theorem toKMSState_state_apply (K : CStarKMSStateOn A) (a : A) :
    K.toKMSState.state a = K.state.toCLM a := rfl

end Basic

end CStarKMSStateOn

end AQFT
end PillarB
