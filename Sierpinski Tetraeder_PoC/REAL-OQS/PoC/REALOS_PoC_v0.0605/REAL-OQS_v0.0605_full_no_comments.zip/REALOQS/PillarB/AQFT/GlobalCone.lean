import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

abbrev GlobalStateCone {Ω : Type u} (SN : PillarA.LayerA.StateNet (Ω := Ω)) :=
  PillarA.LayerA.GlobalStateCone (SN := SN)

end AQFT
end PillarB
