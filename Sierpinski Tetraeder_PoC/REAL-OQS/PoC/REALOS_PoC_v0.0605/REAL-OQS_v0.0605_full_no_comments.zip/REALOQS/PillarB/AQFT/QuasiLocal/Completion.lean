import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.QuasiLocal.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace QuasiLocal

universe u v

variable {Ω : Type u}

open PillarB.AQFT

namespace Completion

structure Data (N : LocalStarAlgebraNet (Ω := Ω)) where

  Ainf : CStarAlgebraBundle.{v}

  SAq : StarAlgebra (QuasiLocal.Carrier (Ω := Ω) N) :=
    QuasiLocal.carrierStarAlgebra (Ω := Ω) N

  SAt : StarAlgebra Ainf.Carrier :=
    AQFT.starAlgebraOfCStar Ainf.Carrier

  iota_inf : StarAlgHom SAq SAt

  isIsometric : Prop

  hasDenseRange : Prop

  hasUP : Prop

end Completion

end QuasiLocal
end AQFT
end PillarB
