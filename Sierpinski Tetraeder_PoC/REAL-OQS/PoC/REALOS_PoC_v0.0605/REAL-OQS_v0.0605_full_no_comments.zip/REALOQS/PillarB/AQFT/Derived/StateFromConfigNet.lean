import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarB.AQFT.Derived.LocalConfigNet
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

universe u

def stateNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarA.LayerA.StateNet (Ω := Ω) :=
  (localStarAlgebraNet (Ω := Ω) d).toStateNet

def evalTop (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω)) :=
  { toFun := fun f => f σ0 }

def globalCone_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet (Ω := Ω) d)
    (ρTop := ρTop)

def globalCone (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet (Ω := Ω) d)
    (ρTop := evalTop (Ω := Ω) d σ0)

end Derived
end AQFT
end PillarB
