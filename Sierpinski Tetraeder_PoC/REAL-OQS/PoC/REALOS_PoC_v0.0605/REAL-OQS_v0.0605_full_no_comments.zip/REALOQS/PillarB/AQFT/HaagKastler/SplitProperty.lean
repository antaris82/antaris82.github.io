import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace HaagKastler

universe u v w

open PillarA.LayerA

section

variable {Ω : Type u} (LAN : LocalAlgebraNet.{u, v, w} (Ω := Ω))

structure SplitData {a b : LAN.RN.Region} (hab : a ≤ b) where
  N : Type v
  i₁ : LAN.Alg a → N
  i₂ : N → LAN.Alg b
  i₁_inj : Function.Injective i₁
  i₂_inj : Function.Injective i₂
  compat : ∀ x : LAN.Alg a, i₂ (i₁ x) = LAN.incl (a := a) (b := b) hab x

namespace SplitData

def refl (a : LAN.RN.Region) :
    SplitData (LAN := LAN) (a := a) (b := a) le_rfl where
  N := LAN.Alg a
  i₁ := id
  i₂ := id
  i₁_inj := by
    intro x y h
    simpa using h
  i₂_inj := by
    intro x y h
    simpa using h
  compat := by
    intro x
    simpa using (LAN.incl_id a x).symm

end SplitData

def SplitProperty : Prop :=
  ∀ {a b : LAN.RN.Region} (hab : a ≤ b),
    Nonempty (SplitData (LAN := LAN) (a := a) (b := b) hab)

theorem splitData_nonempty_refl (a : LAN.RN.Region) :
    Nonempty (SplitData (LAN := LAN) (a := a) (b := a) le_rfl) :=
  ⟨SplitData.refl (LAN := LAN) a⟩

end

end HaagKastler
end AQFT
end PillarB
