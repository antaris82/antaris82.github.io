import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.QuasiLocal.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

abbrev boundaryMatrixQuasiLocalTopRegion :
    (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region :=
  (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top

abbrev boundaryMatrixQuasiLocalCarrier :=
  QuasiLocal.Carrier (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))

abbrev boundaryMatrixQuasiLocalSA :
    StarAlgebra (boundaryMatrixQuasiLocalCarrier (Ω := Ω)) :=
  QuasiLocal.carrierStarAlgebra (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))

abbrev boundaryMatrixTopSA :
    StarAlgebra
      ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
        (boundaryMatrixQuasiLocalTopRegion (Ω := Ω))) :=
  (boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixQuasiLocalTopRegion (Ω := Ω))

def boundaryMatrixQuasiLocalToTopHom :
    StarAlgHom
      (boundaryMatrixQuasiLocalSA (Ω := Ω))
      (boundaryMatrixTopSA (Ω := Ω)) :=
  { toFun := QuasiLocal.toTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))
    isHom := by
      refine
        { map_zero := ?_
          map_one := ?_
          map_add := ?_
          map_mul := ?_
          map_neg := ?_
          map_star := ?_ }
      · simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a b
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a b
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra] }

@[simp] theorem boundaryMatrixQuasiLocalToTopHom_apply
    (q : boundaryMatrixQuasiLocalCarrier (Ω := Ω)) :
    boundaryMatrixQuasiLocalToTopHom (Ω := Ω) q =
      QuasiLocal.toTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) q := rfl

def boundaryMatrixTopToQuasiLocalHom :
    StarAlgHom
      (boundaryMatrixTopSA (Ω := Ω))
      (boundaryMatrixQuasiLocalSA (Ω := Ω)) :=
  { toFun := QuasiLocal.ofTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))
    isHom := by
      refine
        { map_zero := ?_
          map_one := ?_
          map_add := ?_
          map_mul := ?_
          map_neg := ?_
          map_star := ?_ }
      · simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a b
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a b
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra]
      · intro a
        simp [boundaryMatrixQuasiLocalSA, boundaryMatrixTopSA,
          QuasiLocal.carrierStarAlgebra] }

@[simp] theorem boundaryMatrixTopToQuasiLocalHom_apply
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      (boundaryMatrixQuasiLocalTopRegion (Ω := Ω)))) :
    boundaryMatrixTopToQuasiLocalHom (Ω := Ω) A =
      QuasiLocal.ofTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) A := rfl

def boundaryMatrixQuasiLocalIsoTop :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω))
      (SB := boundaryMatrixTopSA (Ω := Ω)) where
  hom := boundaryMatrixQuasiLocalToTopHom (Ω := Ω)
  inv := boundaryMatrixTopToQuasiLocalHom (Ω := Ω)
  left_inv := by
    intro q
    exact QuasiLocal.ofTop_toTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) q
  right_inv := by
    intro A
    exact QuasiLocal.toTop_ofTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) A

def boundaryMatrixQuasiLocalToMatrixHom :
    StarAlgHom
      (boundaryMatrixQuasiLocalSA (Ω := Ω))
      (matrixStarAlgebraCStar Ω) :=
  StarAlgHom.comp
    ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom)
    (boundaryMatrixQuasiLocalToTopHom (Ω := Ω))

def boundaryMatrixMatrixToQuasiLocalHom :
    StarAlgHom
      (matrixStarAlgebraCStar Ω)
      (boundaryMatrixQuasiLocalSA (Ω := Ω)) :=
  StarAlgHom.comp
    (boundaryMatrixTopToQuasiLocalHom (Ω := Ω))
    ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv)

def boundaryMatrixQuasiLocalIsoMatrix :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω))
      (SB := matrixStarAlgebraCStar Ω) where
  hom := boundaryMatrixQuasiLocalToMatrixHom (Ω := Ω)
  inv := boundaryMatrixMatrixToQuasiLocalHom (Ω := Ω)
  left_inv := by
    intro q
    have htop :
        (boundaryMatrixTopIsoMatrix (Ω := Ω)).inv
          ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom
            ((boundaryMatrixQuasiLocalToTopHom (Ω := Ω)) q)) =
          (boundaryMatrixQuasiLocalToTopHom (Ω := Ω)) q :=
      (boundaryMatrixTopIsoMatrix (Ω := Ω)).left_inv
        ((boundaryMatrixQuasiLocalToTopHom (Ω := Ω)) q)
    exact
      calc
        (boundaryMatrixMatrixToQuasiLocalHom (Ω := Ω))
            ((boundaryMatrixQuasiLocalToMatrixHom (Ω := Ω)) q)
            = (boundaryMatrixTopToQuasiLocalHom (Ω := Ω))
                ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv
                  ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom
                    ((boundaryMatrixQuasiLocalToTopHom (Ω := Ω)) q))) := by
              rfl
        _ = (boundaryMatrixTopToQuasiLocalHom (Ω := Ω))
              ((boundaryMatrixQuasiLocalToTopHom (Ω := Ω)) q) := by
              exact congrArg (boundaryMatrixTopToQuasiLocalHom (Ω := Ω)) htop
        _ = q := (boundaryMatrixQuasiLocalIsoTop (Ω := Ω)).left_inv q
  right_inv := by
    intro A
    have htop :
        (boundaryMatrixQuasiLocalToTopHom (Ω := Ω))
          ((boundaryMatrixTopToQuasiLocalHom (Ω := Ω))
            ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A)) =
          (boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A :=
      (boundaryMatrixQuasiLocalIsoTop (Ω := Ω)).right_inv
        ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A)
    exact
      calc
        (boundaryMatrixQuasiLocalToMatrixHom (Ω := Ω))
            ((boundaryMatrixMatrixToQuasiLocalHom (Ω := Ω)) A)
            = (boundaryMatrixTopIsoMatrix (Ω := Ω)).hom
                ((boundaryMatrixQuasiLocalToTopHom (Ω := Ω))
                  ((boundaryMatrixTopToQuasiLocalHom (Ω := Ω))
                    ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A))) := by
              rfl
        _ = (boundaryMatrixTopIsoMatrix (Ω := Ω)).hom
              ((boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A) := by
              exact congrArg ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom) htop
        _ = A := (boundaryMatrixTopIsoMatrix (Ω := Ω)).right_inv A

abbrev boundaryMatrixQuasiLocalClosureTop :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω))
      (SB := boundaryMatrixTopSA (Ω := Ω)) :=
  boundaryMatrixQuasiLocalIsoTop (Ω := Ω)

abbrev boundaryMatrixQuasiLocalClosureMatrix :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω))
      (SB := matrixStarAlgebraCStar Ω) :=
  boundaryMatrixQuasiLocalIsoMatrix (Ω := Ω)

@[simp] theorem boundaryMatrixQuasiLocalIsoTop_hom_apply
    (q : boundaryMatrixQuasiLocalCarrier (Ω := Ω)) :
    (boundaryMatrixQuasiLocalIsoTop (Ω := Ω)).hom q =
      QuasiLocal.toTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) q := rfl

@[simp] theorem boundaryMatrixQuasiLocalIsoTop_inv_apply
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      (boundaryMatrixQuasiLocalTopRegion (Ω := Ω)))) :
    (boundaryMatrixQuasiLocalIsoTop (Ω := Ω)).inv A =
      QuasiLocal.ofTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) A := rfl

@[simp] theorem boundaryMatrixQuasiLocalIsoMatrix_hom_apply
    (q : boundaryMatrixQuasiLocalCarrier (Ω := Ω)) :
    (boundaryMatrixQuasiLocalIsoMatrix (Ω := Ω)).hom q =
      RegionBlockMat.toMatrix
        (QuasiLocal.toTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω)) q) := by
  rfl

@[simp] theorem boundaryMatrixQuasiLocalIsoMatrix_inv_apply (A : BoundaryMat Ω) :
    (boundaryMatrixQuasiLocalIsoMatrix (Ω := Ω)).inv A =
      QuasiLocal.ofTop (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))
        (matrixToTopRegion (Ω := Ω) A) := by
  rfl

end

end Derived
end AQFT
end PillarB
