import REALOQS.PillarB.Gates.SplitProperty
