import Mathlib.Analysis.Calculus.FDeriv.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.Data.Real.Basic
import REALOQS.PillarA.Core.ToC.AQFTSubstrate
import REALOQS.PillarB.AQFT.StarAlgebra
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

variable {A : Type u} {SA : StarAlgebra A}

structure StarAlgDynamics (SA : StarAlgebra A) where
  α : ℝ → StarAlgHom SA SA
  map_zero : α 0 = StarAlgHom.id SA
  map_add : ∀ s t : ℝ, α (s + t) = StarAlgHom.comp (α s) (α t)

namespace StarAlgDynamics

variable (D : StarAlgDynamics (SA := SA))

@[simp] theorem alpha_zero : D.α 0 = StarAlgHom.id SA := D.map_zero

@[simp] theorem alpha_add (s t : ℝ) : D.α (s + t) = StarAlgHom.comp (D.α s) (D.α t) :=
  D.map_add s t

@[simp] theorem alpha_zero_apply (x : A) : D.α 0 x = x := by
  simp [StarAlgDynamics.alpha_zero (D := D)]

@[simp] theorem alpha_add_apply (s t : ℝ) (x : A) : D.α (s + t) x = D.α s (D.α t x) := by
  simp [StarAlgDynamics.alpha_add (D := D) s t, StarAlgHom.comp_apply]

end StarAlgDynamics

def IsInvariant (D : StarAlgDynamics (SA := SA)) (ϕ : StateOn A) : Prop :=
  ∀ t : ℝ, ∀ a : A, ϕ (D.α t a) = ϕ a

abbrev ModularKMSData {A : Type u}
    (S : PillarA.ToC.AQFTSubstrate A) (φ : S.StateOn) :
    Type (u + 1) :=
  S.ModularKMSData φ

def KMSStrip
    (D : StarAlgDynamics (SA := SA))
    (β : ℝ)
    (ϕ : StateOn A) : Prop :=
  ∀ a b : A, ∃ F : Complex → Complex,
    DifferentiableOn Complex F {z : Complex | 0 < z.im ∧ z.im < β} ∧
    ContinuousOn F {z : Complex | 0 ≤ z.im ∧ z.im ≤ β} ∧
    (∀ t : ℝ, F (t : Complex) = ϕ (SA.mul (D.α t a) b)) ∧
    (∀ t : ℝ, F ((t : Complex) + Complex.I * (β : Complex)) = ϕ (SA.mul b (D.α t a)))

structure IsKMS
    (D : StarAlgDynamics (SA := SA))
    (β : ℝ)
    (ϕ : StateOn A) : Prop where
  beta_pos : 0 < β
  invariant : IsInvariant (SA := SA) D ϕ
  kmsStrip : KMSStrip (SA := SA) D β ϕ

structure KMSState (SA : StarAlgebra A) where
  β : ℝ
  dyn : StarAlgDynamics (SA := SA)
  state : StateOn A
  isKMS : IsKMS (SA := SA) (D := dyn) β state

namespace KMSState

variable (K : KMSState (SA := SA))

theorem beta_pos : 0 < K.β := K.isKMS.beta_pos

theorem invariant : IsInvariant (SA := SA) K.dyn K.state := K.isKMS.invariant

end KMSState

end AQFT
end PillarB
