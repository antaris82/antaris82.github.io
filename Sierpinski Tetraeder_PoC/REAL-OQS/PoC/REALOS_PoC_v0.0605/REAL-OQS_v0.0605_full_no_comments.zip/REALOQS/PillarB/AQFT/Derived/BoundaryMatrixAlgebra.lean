import Mathlib
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

abbrev Mat (Ω : Type u) := Matrix Ω Ω Complex

def matrixStarAlgebra (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgebra (Mat Ω) :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := Matrix.conjTranspose
    add_assoc := by intro a b c; ext i j; simp [add_assoc]
    add_comm := by intro a b; ext i j; simp [add_comm]
    add_zero := by intro a; ext i j; simp
    zero_add := by intro a; ext i j; simp
    add_left_neg := by intro a; ext i j; simp
    mul_assoc := by intro a b c; simpa using Matrix.mul_assoc a b c
    one_mul := by intro a; simp
    mul_one := by intro a; simp
    left_distrib := by intro a b c; simpa using Matrix.mul_add a b c
    right_distrib := by intro a b c; simpa using Matrix.add_mul a b c
    zero_mul := by intro a; simp
    mul_zero := by intro a; simp
    star_involutive := by intro a; simp
    star_add := by intro a b; simp
    star_mul := by intro a b; simp
    star_one := by simp
    star_zero := by simp }

end
end Derived
end AQFT
end PillarB
