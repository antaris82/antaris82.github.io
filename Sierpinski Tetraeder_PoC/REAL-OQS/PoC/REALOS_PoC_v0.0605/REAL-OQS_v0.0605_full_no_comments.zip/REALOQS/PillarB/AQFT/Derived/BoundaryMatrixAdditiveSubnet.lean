import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixObservableBasis

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler

universe u

section BoundaryMatrixAdditiveSubnet

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

abbrev RichBoundaryNet := boundaryMatrixRichNet (Ω := Ω)

variable (B : RegionBasis (N := RichBoundaryNet (Ω := Ω)))

def boundaryMatrixAdditiveGenerated
    (r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region)
    (A : (RichBoundaryNet (Ω := Ω)).LAN.Alg r) : Prop :=
  GeneratedBy
    (SA := (RichBoundaryNet (Ω := Ω)).SA r)
    (basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r)
    A

abbrev BoundaryMatrixAdditiveFiber
    (r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region) :=
  { A : (RichBoundaryNet (Ω := Ω)).LAN.Alg r //
      boundaryMatrixAdditiveGenerated (Ω := Ω) B r A }

@[simp] theorem boundaryMatrixAdditiveGenerated_of_basic
    {r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (hr : B.basic r) (A : (RichBoundaryNet (Ω := Ω)).LAN.Alg r) :
    boundaryMatrixAdditiveGenerated (Ω := Ω) B r A := by
  exact generatedBy_of_mem (SA := (RichBoundaryNet (Ω := Ω)).SA r)
    (mem_basisGenSet_of_basic
      (N := RichBoundaryNet (Ω := Ω)) (B := B) hr le_rfl A)

@[simp] theorem boundaryMatrixAdditiveFiber_val
    {r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (A : BoundaryMatrixAdditiveFiber (Ω := Ω) B r) :
    A.1 = A.val := rfl

theorem basisGenSet_mono
    {a b : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (hab : a ≤ b) {y : (RichBoundaryNet (Ω := Ω)).LAN.Alg a}
    (hy : y ∈ basisGenSet (N := RichBoundaryNet (Ω := Ω)) B a) :
    (RichBoundaryNet (Ω := Ω)).LAN.incl hab y ∈
      basisGenSet (N := RichBoundaryNet (Ω := Ω)) B b := by
  rcases hy with ⟨u, hu, hua, x, rfl⟩
  refine ⟨u, hu, le_trans hua hab, x, ?_⟩
  simpa using
    (RichBoundaryNet (Ω := Ω)).LAN.incl_comp hua hab x

theorem boundaryMatrixAdditiveGenerated_mono
    {a b : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (hab : a ≤ b)
    {A : (RichBoundaryNet (Ω := Ω)).LAN.Alg a}
    (hA : boundaryMatrixAdditiveGenerated (Ω := Ω) B a A) :
    boundaryMatrixAdditiveGenerated (Ω := Ω) B b
      ((RichBoundaryNet (Ω := Ω)).LAN.incl hab A) := by
  exact GeneratedBy.map
    (SA := (RichBoundaryNet (Ω := Ω)).SA a)
    (SB := (RichBoundaryNet (Ω := Ω)).SA b)
    (S := basisGenSet (N := RichBoundaryNet (Ω := Ω)) B a)
    (T := basisGenSet (N := RichBoundaryNet (Ω := Ω)) B b)
    ((RichBoundaryNet (Ω := Ω)).inclHom hab)
    (fun y hy => basisGenSet_mono (Ω := Ω) (B := B) hab hy)
    hA

def boundaryMatrixAdditiveStarAlgebra
    (r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region) :
    StarAlgebra (BoundaryMatrixAdditiveFiber (Ω := Ω) B r) :=
  { zero := ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.zero,
      GeneratedBy.zero (SA := (RichBoundaryNet (Ω := Ω)).SA r)
        (basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r)⟩
    one := ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.one,
      GeneratedBy.one (SA := (RichBoundaryNet (Ω := Ω)).SA r)
        (basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r)⟩
    add := fun A C => ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.add A.1 C.1,
      GeneratedBy.add (SA := (RichBoundaryNet (Ω := Ω)).SA r) A.2 C.2⟩
    mul := fun A C => ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.mul A.1 C.1,
      GeneratedBy.mul (SA := (RichBoundaryNet (Ω := Ω)).SA r) A.2 C.2⟩
    neg := fun A => ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.neg A.1,
      GeneratedBy.neg (SA := (RichBoundaryNet (Ω := Ω)).SA r) A.2⟩
    star := fun A => ⟨(RichBoundaryNet (Ω := Ω)).SA r |>.star A.1,
      GeneratedBy.star (SA := (RichBoundaryNet (Ω := Ω)).SA r) A.2⟩
    add_assoc := by
      intro A C D
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.add_assoc A.1 C.1 D.1
    add_comm := by
      intro A C
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.add_comm A.1 C.1
    add_zero := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.add_zero A.1
    zero_add := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.zero_add A.1
    add_left_neg := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.add_left_neg A.1
    mul_assoc := by
      intro A C D
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.mul_assoc A.1 C.1 D.1
    one_mul := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.one_mul A.1
    mul_one := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.mul_one A.1
    left_distrib := by
      intro A C D
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.left_distrib A.1 C.1 D.1
    right_distrib := by
      intro A C D
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.right_distrib A.1 C.1 D.1
    zero_mul := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.zero_mul A.1
    mul_zero := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.mul_zero A.1
    star_involutive := by
      intro A
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.star_involutive A.1
    star_add := by
      intro A C
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.star_add A.1 C.1
    star_mul := by
      intro A C
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.star_mul A.1 C.1
    star_one := by
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.star_one
    star_zero := by
      apply Subtype.ext
      exact (RichBoundaryNet (Ω := Ω)).SA r |>.star_zero }

def boundaryMatrixAdditiveLocalAlgebraNet :
    PillarA.LayerA.LocalAlgebraNet (Ω := Ω) where
  RN := (RichBoundaryNet (Ω := Ω)).LAN.RN
  Alg := BoundaryMatrixAdditiveFiber (Ω := Ω) B
  incl := by
    intro a b hab A
    exact ⟨(RichBoundaryNet (Ω := Ω)).LAN.incl hab A.1,
      boundaryMatrixAdditiveGenerated_mono (Ω := Ω) (B := B) hab A.2⟩
  incl_id := by
    intro a A
    apply Subtype.ext
    simpa using (RichBoundaryNet (Ω := Ω)).LAN.incl_id a A.1
  incl_comp := by
    intro a b c hab hbc A
    apply Subtype.ext
    simpa using (RichBoundaryNet (Ω := Ω)).LAN.incl_comp hab hbc A.1

def boundaryMatrixAdditiveNet :
    LocalStarAlgebraNet (Ω := Ω) where
  LAN := boundaryMatrixAdditiveLocalAlgebraNet (Ω := Ω) B
  SA := boundaryMatrixAdditiveStarAlgebra (Ω := Ω) B
  incl_isHom := by
    intro a b hab
    refine
      { map_zero := by rfl
        map_one := by rfl
        map_add := by intro A C; rfl
        map_mul := by intro A C; rfl
        map_neg := by intro A; rfl
        map_star := by intro A; rfl }

def boundaryMatrixAdditiveInclRichHom
    (r : (boundaryMatrixAdditiveNet (Ω := Ω) B).LAN.RN.Region) :
    StarAlgHom
      ((boundaryMatrixAdditiveNet (Ω := Ω) B).SA r)
      ((RichBoundaryNet (Ω := Ω)).SA r) :=
  { toFun := fun A => A.1
    isHom :=
      { map_zero := rfl
        map_one := rfl
        map_add := by intro A C; rfl
        map_mul := by intro A C; rfl
        map_neg := by intro A; rfl
        map_star := by intro A; rfl } }

@[simp] theorem boundaryMatrixAdditiveInclRichHom_apply
    {r : (boundaryMatrixAdditiveNet (Ω := Ω) B).LAN.RN.Region}
    (A : (boundaryMatrixAdditiveNet (Ω := Ω) B).LAN.Alg r) :
    boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r A = A.1 := rfl

theorem boundaryMatrixAdditiveInclRich_injective
    (r : (boundaryMatrixAdditiveNet (Ω := Ω) B).LAN.RN.Region) :
    Function.Injective (boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r) := by
  intro A C h
  exact Subtype.ext h

def richToBoundaryMatrixAdditiveBasicHom
    {r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (hr : B.basic r) :
    StarAlgHom
      ((RichBoundaryNet (Ω := Ω)).SA r)
      ((boundaryMatrixAdditiveNet (Ω := Ω) B).SA r) :=
  { toFun := fun A => ⟨A, boundaryMatrixAdditiveGenerated_of_basic (Ω := Ω) (B := B) hr A⟩
    isHom :=
      { map_zero := rfl
        map_one := rfl
        map_add := by intro A C; rfl
        map_mul := by intro A C; rfl
        map_neg := by intro A; rfl
        map_star := by intro A; rfl } }

def boundaryMatrixAdditiveIsoRichOnBasic
    {r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    (hr : B.basic r) :
    StarAlgIso
      (SA := ((boundaryMatrixAdditiveNet (Ω := Ω) B).SA r))
      (SB := ((RichBoundaryNet (Ω := Ω)).SA r)) where
  hom := boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r
  inv := richToBoundaryMatrixAdditiveBasicHom (Ω := Ω) (B := B) hr
  left_inv := by
    intro A
    apply Subtype.ext
    rfl
  right_inv := by
    intro A
    rfl

def boundaryMatrixAdditiveNetFromL (L : Matrix Ω Ω ℝ) :
    LocalStarAlgebraNet (Ω := Ω) :=
  boundaryMatrixAdditiveNet (Ω := Ω)
    (B := boundaryObservableBasisFromL (Ω := Ω) (L := L))

end BoundaryMatrixAdditiveSubnet

end

end Derived
end AQFT
end PillarB
