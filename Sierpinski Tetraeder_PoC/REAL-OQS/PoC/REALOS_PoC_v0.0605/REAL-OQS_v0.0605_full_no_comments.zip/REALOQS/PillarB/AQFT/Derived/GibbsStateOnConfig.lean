import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Data.Complex.Basic
import Mathlib.Data.Real.Basic
import REALOQS.PillarB.AQFT.Derived.FiniteWeightState
import REALOQS.PillarB.AQFT.Derived.LocalConfigNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

universe u

variable {Ω : Type u} [Fintype Ω]

noncomputable section

def gibbsWeight (d : Nat) (β : ℝ)
    (E : Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ) :
    Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ :=
  fun σ => Real.exp (-β * E σ)

def gibbsZ (d : Nat) (β : ℝ)
    (E : Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ)
    [Fintype (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))] : ℝ :=
  Z (X := Cfg (Ω := Ω) d (Finset.univ : Finset Ω))
    (w := gibbsWeight (Ω := Ω) d β E)

theorem gibbsZ_pos (d : Nat) (β : ℝ)
    (E : Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ)
    [Fintype (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))]
    (hcfg : Nonempty (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    0 < gibbsZ (Ω := Ω) d β E := by
  classical
  rcases hcfg with ⟨σ0⟩

  let X : Type u := Cfg (Ω := Ω) d (Finset.univ : Finset Ω)
  have hnonneg : ∀ σ ∈ (Finset.univ : Finset X), 0 ≤ gibbsWeight (Ω := Ω) d β E σ := by
    intro σ _
    exact le_of_lt (Real.exp_pos _)
  have hex : ∃ σ ∈ (Finset.univ : Finset X), 0 < gibbsWeight (Ω := Ω) d β E σ := by
    refine ⟨(σ0 : X), ?_, Real.exp_pos _⟩
    simp
  have hsum : 0 < (Finset.univ : Finset X).sum (fun σ => gibbsWeight (Ω := Ω) d β E σ) :=
    Finset.sum_pos' hnonneg hex

  simpa [gibbsZ, Z] using hsum

theorem gibbsZ_ne_zero (d : Nat) (β : ℝ)
    (E : Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ)
    [Fintype (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))]
    (hcfg : Nonempty (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    gibbsZ (Ω := Ω) d β E ≠ 0 := by
  exact ne_of_gt (gibbsZ_pos (Ω := Ω) d β E hcfg)

def gibbsTopState (d : Nat) (β : ℝ)
    (E : Cfg (Ω := Ω) d (Finset.univ : Finset Ω) → ℝ)
    [Fintype (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))]
    (hcfg : Nonempty (Cfg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω)) :=
  expectationState
    (X := Cfg (Ω := Ω) d (Finset.univ : Finset Ω))
    (w := gibbsWeight (Ω := Ω) d β E)
    (hZ := by
      simpa [Z, gibbsZ, gibbsWeight] using
        (gibbsZ_ne_zero (Ω := Ω) d β E hcfg))

end

end Derived
end AQFT
end PillarB
