import Mathlib
import REALOQS.PillarB.AQFT.CStarKMSState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDensityState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics
import REALOQS.PillarB.AQFT.TimeOrientation

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def unitaryFromLMinusC (L : Matrix Ω Ω ℝ) (z : ℂ) : Mat Ω :=
  hamExp (Ω := Ω) L (-Complex.I * z)

def unitaryFromLPlusC (L : Matrix Ω Ω ℝ) (z : ℂ) : Mat Ω :=
  hamExp (Ω := Ω) L (Complex.I * z)

@[simp] theorem unitaryFromLMinusC_real (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLMinusC (Ω := Ω) L (t : ℂ) = unitaryFromLMinus (Ω := Ω) L t := by
  simp [unitaryFromLMinusC, unitaryFromLMinus]

@[simp] theorem unitaryFromLPlusC_real (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLPlusC (Ω := Ω) L (t : ℂ) = unitaryFromLPlus (Ω := Ω) L t := by
  simp [unitaryFromLPlusC, unitaryFromLPlus]

theorem unitaryFromLMinusC_top
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLMinusC (Ω := Ω) L ((t : ℂ) + Complex.I) =
      hamExp (Ω := Ω) L (1 : ℂ) * unitaryFromLMinus (Ω := Ω) L t := by
  unfold unitaryFromLMinusC unitaryFromLMinus
  have harg :
      -Complex.I * ((t : ℂ) + Complex.I) = (1 : ℂ) + (-Complex.I * (t : ℂ)) := by
    calc
      -Complex.I * ((t : ℂ) + Complex.I)
          = -Complex.I * (t : ℂ) + (-Complex.I * Complex.I) := by
              rw [mul_add]
      _ = -Complex.I * (t : ℂ) + (1 : ℂ) := by
              norm_num
      _ = (1 : ℂ) + (-Complex.I * (t : ℂ)) := by
              rw [add_comm]
  rw [harg, hamExp_add]

theorem unitaryFromLPlusC_top
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLPlusC (Ω := Ω) L ((t : ℂ) + Complex.I) =
      unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L := by
  unfold unitaryFromLPlusC unitaryFromLPlus gibbsOpCore
  have harg :
      Complex.I * ((t : ℂ) + Complex.I) = (Complex.I * (t : ℂ)) + (-((1 : ℝ) : ℂ)) := by
    calc
      Complex.I * ((t : ℂ) + Complex.I)
          = Complex.I * (t : ℂ) + (Complex.I * Complex.I) := by
              rw [mul_add]
      _ = Complex.I * (t : ℂ) + (-((1 : ℝ) : ℂ)) := by
              norm_num
  rw [harg, hamExp_add]

theorem densityMatrixCore_mul_hamExp_one
    (L : Matrix Ω Ω ℝ) :
    densityMatrixCore (Ω := Ω) L * hamExp (Ω := Ω) L (1 : ℂ) =
      ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • (1 : Mat Ω)) := by
  calc
    densityMatrixCore (Ω := Ω) L * hamExp (Ω := Ω) L (1 : ℂ)
        = ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
            (gibbsOpCore (Ω := Ω) L * hamExp (Ω := Ω) L (1 : ℂ))) := by
              simp [densityMatrixCore]
    _ = ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
            hamExp (Ω := Ω) L (((-((1 : ℝ) : ℂ))) + (1 : ℂ))) := by
              have hmul :
                  gibbsOpCore (Ω := Ω) L * hamExp (Ω := Ω) L (1 : ℂ) =
                    hamExp (Ω := Ω) L (((-((1 : ℝ) : ℂ))) + (1 : ℂ)) := by
                rw [gibbsOpCore]
                symm
                exact hamExp_add (Ω := Ω) L (-((1 : ℝ) : ℂ)) (1 : ℂ)
              rw [hmul]
    _ = ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • (1 : Mat Ω)) := by
              simp

omit [Fintype Ω] [DecidableEq Ω] in
theorem transpose_smul_self
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.transpose ((β : ℝ) • L) = (β : ℝ) • L := by
  simpa using congrArg (fun M : Matrix Ω Ω ℝ => (β : ℝ) • M) hL

omit [Fintype Ω] [DecidableEq Ω] in
theorem fullHamiltonian_smul_real
    (L : Matrix Ω Ω ℝ) (β : ℝ) :
    fullHamiltonian (Ω := Ω) ((β : ℝ) • L) =
      ((β : ℂ) • fullHamiltonian (Ω := Ω) L) := by
  ext i j
  simp [fullHamiltonian]

theorem hamExp_smul_real
    (L : Matrix Ω Ω ℝ) (β : ℝ) (z : ℂ) :
    hamExp (Ω := Ω) ((β : ℝ) • L) z =
      hamExp (Ω := Ω) L (z * (β : ℂ)) := by
  rw [hamExp, hamExp, fullHamiltonian_smul_real]
  congr 1
  calc
    z • ((β : ℂ) • fullHamiltonian (Ω := Ω) L)
        = (z * (β : ℂ)) • fullHamiltonian (Ω := Ω) L := by
            rw [smul_smul]

def gibbsOpCoreAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-(β : ℂ))

@[simp] theorem gibbsOpCoreAtBeta_one
    (L : Matrix Ω Ω ℝ) :
    gibbsOpCoreAtBeta (Ω := Ω) L 1 = gibbsOpCore (Ω := Ω) L := by
  simp [gibbsOpCoreAtBeta, gibbsOpCore]

theorem gibbsOpCoreAtBeta_eq_gibbsOpCore_smul
    (L : Matrix Ω Ω ℝ) (β : ℝ) :
    gibbsOpCoreAtBeta (Ω := Ω) L β =
      gibbsOpCore (Ω := Ω) ((β : ℝ) • L) := by
  simpa [gibbsOpCoreAtBeta, gibbsOpCore, mul_comm] using
    (hamExp_smul_real (Ω := Ω) L β (-((1 : ℝ) : ℂ))).symm

def boundaryDensityZAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) : ℝ :=
  Complex.re (matTrace (Ω := Ω) (gibbsOpCoreAtBeta (Ω := Ω) L β))

theorem boundaryDensityZAtBeta_eq_boundaryDensityZ_smul
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    boundaryDensityZAtBeta (Ω := Ω) L β =
      boundaryDensityZ (Ω := Ω) ((β : ℝ) • L) := by
  have hβL : Matrix.transpose ((β : ℝ) • L) = (β : ℝ) • L :=
    transpose_smul_self (Ω := Ω) L β hL
  calc
    boundaryDensityZAtBeta (Ω := Ω) L β
        = (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) ((β : ℝ) • L))).re := by
            simp [boundaryDensityZAtBeta, gibbsOpCoreAtBeta_eq_gibbsOpCore_smul]
    _ = boundaryDensityZ (Ω := Ω) ((β : ℝ) • L) := by
            simpa using
              (boundaryDensityZ_eq_re_matTrace_gibbsOpCore
                (Ω := Ω) ((β : ℝ) • L) hβL).symm

section WithNonemptyBeta

variable [Nonempty Ω]

theorem boundaryDensityZAtBeta_pos
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    0 < boundaryDensityZAtBeta (Ω := Ω) L β := by
  rw [boundaryDensityZAtBeta_eq_boundaryDensityZ_smul (Ω := Ω) L β hL]
  exact boundaryDensityZ_pos (Ω := Ω) ((β : ℝ) • L)

@[simp] theorem boundaryDensityZAtBeta_ne_zero
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    boundaryDensityZAtBeta (Ω := Ω) L β ≠ 0 :=
  ne_of_gt (boundaryDensityZAtBeta_pos (Ω := Ω) L β hL)

def densityMatrixCoreAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω :=
  ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) •
    gibbsOpCoreAtBeta (Ω := Ω) L β)

omit [Nonempty Ω] in
theorem densityMatrixCoreAtBeta_eq_densityMatrixCore_smul
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    densityMatrixCoreAtBeta (Ω := Ω) L β =
      densityMatrixCore (Ω := Ω) ((β : ℝ) • L) := by
  simp [densityMatrixCoreAtBeta, densityMatrixCore,
    gibbsOpCoreAtBeta_eq_gibbsOpCore_smul,
    boundaryDensityZAtBeta_eq_boundaryDensityZ_smul (Ω := Ω) L β hL]

@[simp] theorem densityMatrixCoreAtBeta_trace_one
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    matTrace (Ω := Ω) (densityMatrixCoreAtBeta (Ω := Ω) L β) = 1 := by
  have hβL : Matrix.transpose ((β : ℝ) • L) = (β : ℝ) • L :=
    transpose_smul_self (Ω := Ω) L β hL
  rw [densityMatrixCoreAtBeta_eq_densityMatrixCore_smul (Ω := Ω) L β hL]
  simpa using matTrace_densityMatrixCore (Ω := Ω) ((β : ℝ) • L) hβL

omit [Nonempty Ω] in
theorem densityMatrixCoreAtBeta_mul_hamExp_beta
    (L : Matrix Ω Ω ℝ) (β : ℝ) :
    densityMatrixCoreAtBeta (Ω := Ω) L β * hamExp (Ω := Ω) L (β : ℂ) =
      ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) • (1 : Mat Ω)) := by
  calc
    densityMatrixCoreAtBeta (Ω := Ω) L β * hamExp (Ω := Ω) L (β : ℂ)
        = ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) •
            (gibbsOpCoreAtBeta (Ω := Ω) L β * hamExp (Ω := Ω) L (β : ℂ))) := by
              simp [densityMatrixCoreAtBeta]
    _ = ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) •
            hamExp (Ω := Ω) L ((-(β : ℂ)) + (β : ℂ))) := by
              have hmul :
                  gibbsOpCoreAtBeta (Ω := Ω) L β * hamExp (Ω := Ω) L (β : ℂ) =
                    hamExp (Ω := Ω) L ((-(β : ℂ)) + (β : ℂ)) := by
                rw [gibbsOpCoreAtBeta]
                symm
                exact hamExp_add (Ω := Ω) L (-(β : ℂ)) (β : ℂ)
              rw [hmul]
    _ = ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) • (1 : Mat Ω)) := by
              simp

def boundaryDensityStateMatAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω → ℂ :=
  fun A => matTrace (Ω := Ω) ((densityMatrixCoreAtBeta (Ω := Ω) L β) * A)

omit [Nonempty Ω] in
@[simp] theorem boundaryDensityStateMatAtBeta_eq_matTrace_densityMatrixCoreAtBeta_mul
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryDensityStateMatAtBeta (Ω := Ω) L β A =
      matTrace (Ω := Ω) ((densityMatrixCoreAtBeta (Ω := Ω) L β) * A) := rfl

def boundaryDensityStateAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) (_hL : Matrix.transpose L = L) :
    CStarStateOn (Mat Ω) :=
  boundaryDensityState (Ω := Ω) ((β : ℝ) • L)

@[simp] theorem boundaryDensityStateAtBeta_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    boundaryDensityStateAtBeta (Ω := Ω) L β hL A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β A := by
  have hβL : Matrix.transpose ((β : ℝ) • L) = (β : ℝ) • L :=
    transpose_smul_self (Ω := Ω) L β hL
  change boundaryDensityStateMat (Ω := Ω) ((β : ℝ) • L) A =
    boundaryDensityStateMatAtBeta (Ω := Ω) L β A
  rw [boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul
    (Ω := Ω) ((β : ℝ) • L) hβL A]
  rw [boundaryDensityStateMatAtBeta]
  rw [densityMatrixCoreAtBeta_eq_densityMatrixCore_smul (Ω := Ω) L β hL]

@[simp] theorem boundaryDensityStateAtBeta_toStateOn_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn.toFun A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β A := by
  change boundaryDensityStateAtBeta (Ω := Ω) L β hL A =
    boundaryDensityStateMatAtBeta (Ω := Ω) L β A
  exact boundaryDensityStateAtBeta_apply (Ω := Ω) L β hL A

end WithNonemptyBeta

theorem gibbsOpCoreAtBeta_mul_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    gibbsOpCoreAtBeta (Ω := Ω) L β * unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β := by
  calc
    gibbsOpCoreAtBeta (Ω := Ω) L β * unitaryFromLPlus (Ω := Ω) L t
        = hamExp (Ω := Ω) L (-(β : ℂ)) *
            hamExp (Ω := Ω) L (Complex.I * (t : ℂ)) := by
              simp [gibbsOpCoreAtBeta, unitaryFromLPlus]
    _ = hamExp (Ω := Ω) L ((-(β : ℂ)) + Complex.I * (t : ℂ)) := by
              symm
              exact hamExp_add (Ω := Ω) L (-(β : ℂ)) (Complex.I * (t : ℂ))
    _ = hamExp (Ω := Ω) L (Complex.I * (t : ℂ) + (-(β : ℂ))) := by
              rw [add_comm]
    _ = unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β := by
              simpa [gibbsOpCoreAtBeta, unitaryFromLPlus] using
                (hamExp_add (Ω := Ω) L (Complex.I * (t : ℂ)) (-(β : ℂ)))

theorem gibbsOpCoreAtBeta_mul_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    gibbsOpCoreAtBeta (Ω := Ω) L β * unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β := by
  rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
  exact gibbsOpCoreAtBeta_mul_unitaryFromLPlus (Ω := Ω) L β (-t)

theorem densityMatrixCoreAtBeta_mul_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    densityMatrixCoreAtBeta (Ω := Ω) L β * unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L t * densityMatrixCoreAtBeta (Ω := Ω) L β := by
  have hcommG := gibbsOpCoreAtBeta_mul_unitaryFromLPlus (Ω := Ω) L β t
  calc
    densityMatrixCoreAtBeta (Ω := Ω) L β * unitaryFromLPlus (Ω := Ω) L t
        = ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) •
            (gibbsOpCoreAtBeta (Ω := Ω) L β * unitaryFromLPlus (Ω := Ω) L t)) := by
              simp [densityMatrixCoreAtBeta]
    _ = ((((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹) •
            (unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β)) := by
              rw [hcommG]
    _ = unitaryFromLPlus (Ω := Ω) L t * densityMatrixCoreAtBeta (Ω := Ω) L β := by
              simp [densityMatrixCoreAtBeta]

theorem densityMatrixCoreAtBeta_mul_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    densityMatrixCoreAtBeta (Ω := Ω) L β * unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L t * densityMatrixCoreAtBeta (Ω := Ω) L β := by
  rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
  exact densityMatrixCoreAtBeta_mul_unitaryFromLPlus (Ω := Ω) L β (-t)

theorem boundaryDensityStateMatAtBeta_invariant_fullDynMinus
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A : Mat Ω) :
    boundaryDensityStateMatAtBeta (Ω := Ω) L β
      (fullBoundaryDynMapMinus (Ω := Ω) L t A)
    =
    boundaryDensityStateMatAtBeta (Ω := Ω) L β A := by
  let U : Mat Ω := unitaryFromLMinus (Ω := Ω) L t
  have hcommρ :
      densityMatrixCoreAtBeta (Ω := Ω) L β * U =
        U * densityMatrixCoreAtBeta (Ω := Ω) L β :=
    densityMatrixCoreAtBeta_mul_unitaryFromLMinus (Ω := Ω) L β t
  calc
    boundaryDensityStateMatAtBeta (Ω := Ω) L β
        (fullBoundaryDynMapMinus (Ω := Ω) L t A)
        = matTrace (Ω := Ω)
            ((densityMatrixCoreAtBeta (Ω := Ω) L β) *
              fullBoundaryDynMapMinus (Ω := Ω) L t A) := by
                rfl
    _ = matTrace (Ω := Ω)
            (((densityMatrixCoreAtBeta (Ω := Ω) L β) * U) * A * Matrix.conjTranspose U) := by
              simp [fullBoundaryDynMapMinus, U, Matrix.mul_assoc]
    _ = matTrace (Ω := Ω)
            ((U * densityMatrixCoreAtBeta (Ω := Ω) L β) * A * Matrix.conjTranspose U) := by
              rw [hcommρ]
    _ = matTrace (Ω := Ω)
            (Matrix.conjTranspose U * (U * densityMatrixCoreAtBeta (Ω := Ω) L β) * A) := by
              simpa [Matrix.mul_assoc] using
                (matTrace_mul_mul_mul_cycle (Ω := Ω)
                  (X := U * densityMatrixCoreAtBeta (Ω := Ω) L β)
                  (Y := A)
                  (Z := Matrix.conjTranspose U))
    _ = matTrace (Ω := Ω)
            (((Matrix.conjTranspose U * U) * densityMatrixCoreAtBeta (Ω := Ω) L β) * A) := by
              simp [Matrix.mul_assoc]
    _ = matTrace (Ω := Ω) ((densityMatrixCoreAtBeta (Ω := Ω) L β) * A) := by
              rw [unitaryFromLMinus_conjTranspose_mul_self (Ω := Ω) L t hL]
              simp
    _ = boundaryDensityStateMatAtBeta (Ω := Ω) L β A := by
              rfl

theorem boundaryDensityStateAtBeta_invariant_fullDynMinus
    [Nonempty Ω]
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A : Mat Ω) :
    (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn
      ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A)
    =
    (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn A := by
  change (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toCLM
      ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A)
    =
    (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toCLM A
  rw [fullBoundaryDynMinus_alpha_apply]
  repeat rw [← CStarStateOn.coe_apply]
  repeat rw [boundaryDensityStateAtBeta_apply (Ω := Ω) L β hL]
  exact boundaryDensityStateMatAtBeta_invariant_fullDynMinus (Ω := Ω) L β hL t A

theorem unitaryFromLMinusC_top_atBeta
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    unitaryFromLMinusC (Ω := Ω) L ((t : ℂ) + (β : ℂ) * Complex.I) =
      hamExp (Ω := Ω) L (β : ℂ) * unitaryFromLMinus (Ω := Ω) L t := by
  unfold unitaryFromLMinusC unitaryFromLMinus
  have harg :
      -Complex.I * ((t : ℂ) + (β : ℂ) * Complex.I) =
        (β : ℂ) + (-Complex.I * (t : ℂ)) := by
    calc
      -Complex.I * ((t : ℂ) + (β : ℂ) * Complex.I)
          = -Complex.I * (t : ℂ) + (-Complex.I * ((β : ℂ) * Complex.I)) := by
              rw [mul_add]
      _ = -Complex.I * (t : ℂ) + (β : ℂ) := by
              have hβ : -Complex.I * ((β : ℂ) * Complex.I) = (β : ℂ) := by
                calc
                  -Complex.I * ((β : ℂ) * Complex.I) = ((-Complex.I) * Complex.I) * (β : ℂ) := by
                    ac_rfl
                  _ = (1 : ℂ) * (β : ℂ) := by
                    norm_num
                  _ = (β : ℂ) := by simp
              rw [hβ]
      _ = (β : ℂ) + (-Complex.I * (t : ℂ)) := by
              rw [add_comm]
  rw [harg, hamExp_add]

theorem unitaryFromLPlusC_top_atBeta
    (L : Matrix Ω Ω ℝ) (β t : ℝ) :
    unitaryFromLPlusC (Ω := Ω) L ((t : ℂ) + (β : ℂ) * Complex.I) =
      unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β := by
  unfold unitaryFromLPlusC unitaryFromLPlus gibbsOpCoreAtBeta
  have harg :
      Complex.I * ((t : ℂ) + (β : ℂ) * Complex.I) =
        (Complex.I * (t : ℂ)) + (-(β : ℂ)) := by
    calc
      Complex.I * ((t : ℂ) + (β : ℂ) * Complex.I)
          = Complex.I * (t : ℂ) + (Complex.I * ((β : ℂ) * Complex.I)) := by
              rw [mul_add]
      _ = Complex.I * (t : ℂ) + (-(β : ℂ)) := by
              have hβ : Complex.I * ((β : ℂ) * Complex.I) = -(β : ℂ) := by
                calc
                  Complex.I * ((β : ℂ) * Complex.I) = (Complex.I * Complex.I) * (β : ℂ) := by
                    ac_rfl
                  _ = (-1 : ℂ) * (β : ℂ) := by
                    norm_num
                  _ = -(β : ℂ) := by simp
              rw [hβ]
  rw [harg, hamExp_add]

def fullKMSKernelMinusAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A B : Mat Ω) (z : ℂ) : ℂ :=
  matTrace (Ω := Ω)
    ((((densityMatrixCoreAtBeta (Ω := Ω) L β) * unitaryFromLMinusC (Ω := Ω) L z) * A) *
      unitaryFromLPlusC (Ω := Ω) L z * B)

@[fun_prop] theorem fullKMSKernelMinusAtBeta_differentiable
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A B : Mat Ω) :
    Differentiable Complex (fullKMSKernelMinusAtBeta (Ω := Ω) L β A B) := by
  classical
  have hminus :
      Differentiable Complex (unitaryFromLMinusC (Ω := Ω) L) := by
    intro z
    have hlin :
        DifferentiableAt Complex
          (fun w : Complex => -((Complex.I * w) • fullHamiltonian (Ω := Ω) L)) z := by
      fun_prop
    have hexp :
        DifferentiableAt Complex
          (fun x : Mat Ω => NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) x)
          (-((Complex.I * z) • fullHamiltonian (Ω := Ω) L)) :=
      (NormedSpace.exp_analytic
        (-((Complex.I * z) • fullHamiltonian (Ω := Ω) L))).differentiableAt
    have hEq :
        unitaryFromLMinusC (Ω := Ω) L =
          (fun w : Complex =>
            NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω)
              (-((Complex.I * w) • fullHamiltonian (Ω := Ω) L))) := by
      funext w
      simp [unitaryFromLMinusC, hamExp, neg_mul, neg_smul]
    rw [hEq]
    exact hexp.comp z hlin
  have hplus :
      Differentiable Complex (unitaryFromLPlusC (Ω := Ω) L) := by
    intro z
    have hlin :
        DifferentiableAt Complex
          (fun w : Complex => (Complex.I * w) • fullHamiltonian (Ω := Ω) L) z := by
      fun_prop
    have hexp :
        DifferentiableAt Complex
          (fun x : Mat Ω => NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) x)
          ((Complex.I * z) • fullHamiltonian (Ω := Ω) L) :=
      (NormedSpace.exp_analytic
        ((Complex.I * z) • fullHamiltonian (Ω := Ω) L)).differentiableAt
    have hEq :
        unitaryFromLPlusC (Ω := Ω) L =
          (fun w : Complex =>
            NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω)
              ((Complex.I * w) • fullHamiltonian (Ω := Ω) L)) := by
      funext w
      simp [unitaryFromLPlusC, hamExp]
    rw [hEq]
    exact hexp.comp z hlin
  unfold fullKMSKernelMinusAtBeta matTrace
  fun_prop

section WithNonempty

variable [Nonempty Ω]

omit [Nonempty Ω] in
 theorem fullKMSKernelMinusAtBeta_re_boundary
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A B : Mat Ω) :
    fullKMSKernelMinusAtBeta (Ω := Ω) L β A B (t : ℂ) =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β
        ((matrixStarAlgebraCStar Ω).mul ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A) B) := by
  rw [fullBoundaryDynMinus_alpha_apply, fullBoundaryDynMapMinus]
  simp_rw [conjTranspose_unitaryFromLMinus (Ω := Ω) L t hL]
  simp [fullKMSKernelMinusAtBeta, boundaryDensityStateMatAtBeta, Matrix.mul_assoc]

omit [Nonempty Ω] in
theorem fullKMSKernelMinusAtBeta_top_boundary
    (L : Matrix Ω Ω ℝ) (β : ℝ) (_hβ : 0 < β) (hL : Matrix.transpose L = L)
    (t : ℝ) (A B : Mat Ω) :
    fullKMSKernelMinusAtBeta (Ω := Ω) L β A B ((t : ℂ) + (β : ℂ) * Complex.I) =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β
        ((matrixStarAlgebraCStar Ω).mul B ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A)) := by
  let c : ℂ := (((boundaryDensityZAtBeta (Ω := Ω) L β : ℝ) : ℂ)⁻¹)
  let X : Mat Ω :=
    unitaryFromLMinus (Ω := Ω) L t * A * unitaryFromLPlus (Ω := Ω) L t
  have hkernel :
      fullKMSKernelMinusAtBeta (Ω := Ω) L β A B ((t : ℂ) + (β : ℂ) * Complex.I) =
        matTrace (Ω := Ω) ((c • (X * gibbsOpCoreAtBeta (Ω := Ω) L β)) * B) := by
    calc
      fullKMSKernelMinusAtBeta (Ω := Ω) L β A B ((t : ℂ) + (β : ℂ) * Complex.I)
          = matTrace (Ω := Ω)
              ((((densityMatrixCoreAtBeta (Ω := Ω) L β) *
                  (hamExp (Ω := Ω) L (β : ℂ) * unitaryFromLMinus (Ω := Ω) L t)) * A) *
                (unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β) * B) := by
                  simp [fullKMSKernelMinusAtBeta, unitaryFromLMinusC_top_atBeta,
                    unitaryFromLPlusC_top_atBeta]
      _ = matTrace (Ω := Ω)
              (((((densityMatrixCoreAtBeta (Ω := Ω) L β * hamExp (Ω := Ω) L (β : ℂ)) *
                    unitaryFromLMinus (Ω := Ω) L t) * A) *
                  unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β) * B) := by
                  simp [Matrix.mul_assoc]
      _ = matTrace (Ω := Ω)
              (((((c • (1 : Mat Ω)) * unitaryFromLMinus (Ω := Ω) L t) * A) *
                  unitaryFromLPlus (Ω := Ω) L t * gibbsOpCoreAtBeta (Ω := Ω) L β) * B) := by
                  rw [densityMatrixCoreAtBeta_mul_hamExp_beta (Ω := Ω) L β]
      _ = matTrace (Ω := Ω) ((c • (X * gibbsOpCoreAtBeta (Ω := Ω) L β)) * B) := by
                  simp [c, X, Matrix.mul_assoc]
  have hcycle :
      matTrace (Ω := Ω) ((c • (X * gibbsOpCoreAtBeta (Ω := Ω) L β)) * B) =
        matTrace (Ω := Ω) ((c • (gibbsOpCoreAtBeta (Ω := Ω) L β * B)) * X) := by
    calc
      matTrace (Ω := Ω) ((c • (X * gibbsOpCoreAtBeta (Ω := Ω) L β)) * B)
          = matTrace (Ω := Ω) (c • ((X * gibbsOpCoreAtBeta (Ω := Ω) L β) * B)) := by
              simp [Matrix.mul_assoc]
      _ = c * matTrace (Ω := Ω) ((X * gibbsOpCoreAtBeta (Ω := Ω) L β) * B) := by
              rw [matTrace_smul]
      _ = c * matTrace (Ω := Ω) (B * X * gibbsOpCoreAtBeta (Ω := Ω) L β) := by
              rw [matTrace_mul_mul_mul_cycle (Ω := Ω)
                (X := X) (Y := gibbsOpCoreAtBeta (Ω := Ω) L β) (Z := B)]
      _ = c * matTrace (Ω := Ω) (gibbsOpCoreAtBeta (Ω := Ω) L β * (B * X)) := by
              rw [matTrace_mul_comm (Ω := Ω)
                (A := B * X) (B := gibbsOpCoreAtBeta (Ω := Ω) L β)]
      _ = matTrace (Ω := Ω) (c • (gibbsOpCoreAtBeta (Ω := Ω) L β * (B * X))) := by
              rw [← matTrace_smul]
      _ = matTrace (Ω := Ω) ((c • (gibbsOpCoreAtBeta (Ω := Ω) L β * B)) * X) := by
              simp [Matrix.mul_assoc]
  calc
    fullKMSKernelMinusAtBeta (Ω := Ω) L β A B ((t : ℂ) + (β : ℂ) * Complex.I)
        = matTrace (Ω := Ω) ((c • (X * gibbsOpCoreAtBeta (Ω := Ω) L β)) * B) := hkernel
    _ = matTrace (Ω := Ω) ((c • (gibbsOpCoreAtBeta (Ω := Ω) L β * B)) * X) := hcycle
    _ = matTrace (Ω := Ω)
          ((densityMatrixCoreAtBeta (Ω := Ω) L β) *
            (B * fullBoundaryDynMapMinus (Ω := Ω) L t A)) := by
              rw [fullBoundaryDynMapMinus]
              rw [conjTranspose_unitaryFromLMinus (Ω := Ω) L t hL]
              simp [c, X, densityMatrixCoreAtBeta, Matrix.mul_assoc]
    _ = boundaryDensityStateMatAtBeta (Ω := Ω) L β
          ((matrixStarAlgebraCStar Ω).mul B ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A)) := by
              rw [boundaryDensityStateMatAtBeta_eq_matTrace_densityMatrixCoreAtBeta_mul]
              rw [fullBoundaryDynMinus_alpha_apply]
              rfl

theorem boundaryDensityState_isKMS_minus_atBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β)
    (hL : Matrix.transpose L = L) :
    IsKMS
      (SA := matrixStarAlgebraCStar Ω)
      (D := fullBoundaryDynMinus (Ω := Ω) L hL)
      β
      (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn := by
  refine
    { beta_pos := hβ
      invariant := ?_
      kmsStrip := ?_ }
  · intro t A
    exact
      boundaryDensityStateAtBeta_invariant_fullDynMinus (Ω := Ω) L β hL t A
  · intro A B
    refine ⟨fullKMSKernelMinusAtBeta (Ω := Ω) L β A B, ?_, ?_, ?_, ?_⟩
    · exact (fullKMSKernelMinusAtBeta_differentiable (Ω := Ω) L β A B).differentiableOn
    · exact (fullKMSKernelMinusAtBeta_differentiable (Ω := Ω) L β A B).continuous.continuousOn
    · intro t
      rw [boundaryDensityStateAtBeta_toStateOn_apply (Ω := Ω) L β hL
        ((matrixStarAlgebraCStar Ω).mul (((fullBoundaryDynMinus (Ω := Ω) L hL).α t).toFun A) B)]
      rw [show
        (matrixStarAlgebraCStar Ω).mul (((fullBoundaryDynMinus (Ω := Ω) L hL).α t).toFun A) B
          =
        (matrixStarAlgebraCStar Ω).mul ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A) B by
          rfl]
      exact fullKMSKernelMinusAtBeta_re_boundary (Ω := Ω) L β hL t A B
    · intro t
      rw [boundaryDensityStateAtBeta_toStateOn_apply (Ω := Ω) L β hL
        ((matrixStarAlgebraCStar Ω).mul B (((fullBoundaryDynMinus (Ω := Ω) L hL).α t).toFun A))]
      rw [show
        (matrixStarAlgebraCStar Ω).mul B (((fullBoundaryDynMinus (Ω := Ω) L hL).α t).toFun A)
          =
        (matrixStarAlgebraCStar Ω).mul B ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A) by
          rfl]
      have hItop :
          ((t : ℂ) + Complex.I * (β : Complex)) = ((t : ℂ) + (β : ℂ) * Complex.I) := by
        rw [mul_comm]
      rw [hItop]
      exact fullKMSKernelMinusAtBeta_top_boundary (Ω := Ω) L β hβ hL t A B

end WithNonempty

def fullKMSKernelMinus
    (L : Matrix Ω Ω ℝ) (A B : Mat Ω) (z : ℂ) : ℂ :=
  matTrace (Ω := Ω)
    ((((densityMatrixCore (Ω := Ω) L) * unitaryFromLMinusC (Ω := Ω) L z) * A) *
      unitaryFromLPlusC (Ω := Ω) L z * B)

@[fun_prop] theorem differentiable_unitaryFromLMinusC
    (L : Matrix Ω Ω ℝ) :
    Differentiable Complex (unitaryFromLMinusC (Ω := Ω) L) := by
  intro z
  have hlin :
      DifferentiableAt Complex
        (fun w : Complex => -((Complex.I * w) • fullHamiltonian (Ω := Ω) L)) z := by
    fun_prop
  have hexp :
      DifferentiableAt Complex
        (fun x : Mat Ω => NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) x)
        (-((Complex.I * z) • fullHamiltonian (Ω := Ω) L)) :=
    (NormedSpace.exp_analytic
      (-((Complex.I * z) • fullHamiltonian (Ω := Ω) L))).differentiableAt
  have hEq :
      unitaryFromLMinusC (Ω := Ω) L =
        (fun w : Complex =>
          NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω)
            (-((Complex.I * w) • fullHamiltonian (Ω := Ω) L))) := by
    funext w
    simp [unitaryFromLMinusC, hamExp, neg_mul, neg_smul]
  rw [hEq]
  exact hexp.comp z hlin

@[fun_prop] theorem differentiable_unitaryFromLPlusC
    (L : Matrix Ω Ω ℝ) :
    Differentiable Complex (unitaryFromLPlusC (Ω := Ω) L) := by
  intro z
  have hlin :
      DifferentiableAt Complex
        (fun w : Complex => (Complex.I * w) • fullHamiltonian (Ω := Ω) L) z := by
    fun_prop
  have hexp :
      DifferentiableAt Complex
        (fun x : Mat Ω => NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) x)
        ((Complex.I * z) • fullHamiltonian (Ω := Ω) L) :=
    (NormedSpace.exp_analytic
      ((Complex.I * z) • fullHamiltonian (Ω := Ω) L)).differentiableAt
  have hEq :
      unitaryFromLPlusC (Ω := Ω) L =
        (fun w : Complex =>
          NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω)
            ((Complex.I * w) • fullHamiltonian (Ω := Ω) L)) := by
    funext w
    simp [unitaryFromLPlusC, hamExp]
  rw [hEq]
  exact hexp.comp z hlin

theorem fullKMSKernelMinus_differentiable
    (L : Matrix Ω Ω ℝ) (A B : Mat Ω) :
    Differentiable Complex (fullKMSKernelMinus (Ω := Ω) L A B) := by
  classical
  unfold fullKMSKernelMinus matTrace
  fun_prop

section WithNonempty

variable [Nonempty Ω]

theorem fullKMSKernelMinus_re_boundary
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A B : Mat Ω) :
    fullKMSKernelMinus (Ω := Ω) L A B (t : ℂ) =
      boundaryDensityStateMat (Ω := Ω) L
        ((matrixStarAlgebraCStar Ω).mul ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A) B) := by
  rw [boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul (Ω := Ω) L hL]
  rw [fullBoundaryDynMinus_alpha_apply, fullBoundaryDynMapMinus]
  simp_rw [conjTranspose_unitaryFromLMinus (Ω := Ω) L t hL]
  simp [fullKMSKernelMinus, Matrix.mul_assoc]

theorem fullKMSKernelMinus_top_boundary
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A B : Mat Ω) :
    fullKMSKernelMinus (Ω := Ω) L A B ((t : ℂ) + Complex.I) =
      boundaryDensityStateMat (Ω := Ω) L
        ((matrixStarAlgebraCStar Ω).mul B ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A)) := by
  let c : ℂ := (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹)
  let X : Mat Ω :=
    unitaryFromLMinus (Ω := Ω) L t * A * unitaryFromLPlus (Ω := Ω) L t
  rw [boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul (Ω := Ω) L hL]
  have hkernel :
      fullKMSKernelMinus (Ω := Ω) L A B ((t : ℂ) + Complex.I) =
        matTrace (Ω := Ω) ((c • (X * gibbsOpCore (Ω := Ω) L)) * B) := by
    calc
      fullKMSKernelMinus (Ω := Ω) L A B ((t : ℂ) + Complex.I)
          = matTrace (Ω := Ω)
              ((((densityMatrixCore (Ω := Ω) L) *
                  (hamExp (Ω := Ω) L (1 : ℂ) * unitaryFromLMinus (Ω := Ω) L t)) * A) *
                (unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L) * B) := by
                  simp [fullKMSKernelMinus, unitaryFromLMinusC_top, unitaryFromLPlusC_top]
      _ = matTrace (Ω := Ω)
              (((((densityMatrixCore (Ω := Ω) L * hamExp (Ω := Ω) L (1 : ℂ)) *
                    unitaryFromLMinus (Ω := Ω) L t) * A) *
                  unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L) * B) := by
                  simp [Matrix.mul_assoc]
      _ = matTrace (Ω := Ω)
              (((((c • (1 : Mat Ω)) * unitaryFromLMinus (Ω := Ω) L t) * A) *
                  unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L) * B) := by
                  rw [densityMatrixCore_mul_hamExp_one (Ω := Ω) L]
      _ = matTrace (Ω := Ω) ((c • (X * gibbsOpCore (Ω := Ω) L)) * B) := by
                  simp [c, X, Matrix.mul_assoc]
  have hcycle :
      matTrace (Ω := Ω) ((c • (X * gibbsOpCore (Ω := Ω) L)) * B) =
        matTrace (Ω := Ω) ((c • (gibbsOpCore (Ω := Ω) L * B)) * X) := by
    calc
      matTrace (Ω := Ω) ((c • (X * gibbsOpCore (Ω := Ω) L)) * B)
          = matTrace (Ω := Ω) (c • ((X * gibbsOpCore (Ω := Ω) L) * B)) := by
              simp [Matrix.mul_assoc]
      _ = c * matTrace (Ω := Ω) ((X * gibbsOpCore (Ω := Ω) L) * B) := by
              rw [matTrace_smul]
      _ = c * matTrace (Ω := Ω) (B * X * gibbsOpCore (Ω := Ω) L) := by
              rw [matTrace_mul_mul_mul_cycle (Ω := Ω)
                (X := X) (Y := gibbsOpCore (Ω := Ω) L) (Z := B)]
      _ = c * matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L * (B * X)) := by
              rw [matTrace_mul_comm (Ω := Ω)
                (A := B * X) (B := gibbsOpCore (Ω := Ω) L)]
      _ = matTrace (Ω := Ω) (c • (gibbsOpCore (Ω := Ω) L * (B * X))) := by
              rw [← matTrace_smul]
      _ = matTrace (Ω := Ω) ((c • (gibbsOpCore (Ω := Ω) L * B)) * X) := by
              simp [Matrix.mul_assoc]
  calc
    fullKMSKernelMinus (Ω := Ω) L A B ((t : ℂ) + Complex.I)
        = matTrace (Ω := Ω) ((c • (X * gibbsOpCore (Ω := Ω) L)) * B) := hkernel
    _ = matTrace (Ω := Ω) ((c • (gibbsOpCore (Ω := Ω) L * B)) * X) := hcycle
    _ = matTrace (Ω := Ω)
          ((densityMatrixCore (Ω := Ω) L) *
            (B * fullBoundaryDynMapMinus (Ω := Ω) L t A)) := by
              rw [fullBoundaryDynMapMinus]
              rw [conjTranspose_unitaryFromLMinus (Ω := Ω) L t hL]
              simp [c, X, densityMatrixCore, Matrix.mul_assoc]

theorem boundaryDensityState_isKMS_minus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    IsKMS
      (SA := matrixStarAlgebraCStar Ω)
      (D := fullBoundaryDynMinus (Ω := Ω) L hL)
      1
      (boundaryDensityStateMat (Ω := Ω) L) := by
  refine
    { beta_pos := by norm_num
      invariant := ?_
      kmsStrip := ?_ }
  · intro t A
    exact boundaryDensityState_invariant_fullDynMinus (Ω := Ω) L hL t A
  · intro A B
    refine ⟨fullKMSKernelMinus (Ω := Ω) L A B, ?_, ?_, ?_, ?_⟩
    · exact (fullKMSKernelMinus_differentiable (Ω := Ω) L A B).differentiableOn
    · exact (fullKMSKernelMinus_differentiable (Ω := Ω) L A B).continuous.continuousOn
    · intro t
      exact fullKMSKernelMinus_re_boundary (Ω := Ω) L hL t A B
    · intro t
      have hItop :
          ((t : ℂ) + Complex.I * ((1 : ℝ) : ℂ)) = ((t : ℂ) + Complex.I) := by
        norm_num
      rw [hItop]
      exact fullKMSKernelMinus_top_boundary (Ω := Ω) L hL t A B

end WithNonempty

section WithNonemptyBundles

variable [Nonempty Ω]

def boundaryFullKMSMinusAtBeta
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β)
    (hL : Matrix.transpose L = L) :
    CStarKMSStateOn (Mat Ω) where
  β := β
  dyn := fullBoundaryDynMinus (Ω := Ω) L hL
  state := boundaryDensityStateAtBeta (Ω := Ω) L β hL
  isKMS := by
    simpa [boundaryDensityStateAtBeta_apply (Ω := Ω) L β hL] using
      (boundaryDensityState_isKMS_minus_atBeta (Ω := Ω) L β hβ hL)

@[simp] theorem boundaryFullKMSMinusAtBeta_beta
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β)
    (hL : Matrix.transpose L = L) :
    (boundaryFullKMSMinusAtBeta (Ω := Ω) L β hβ hL).β = β := rfl

@[simp] theorem boundaryFullKMSMinusAtBeta_dyn
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β)
    (hL : Matrix.transpose L = L) :
    (boundaryFullKMSMinusAtBeta (Ω := Ω) L β hβ hL).dyn =
      fullBoundaryDynMinus (Ω := Ω) L hL := rfl

def boundaryFullKMSMinusCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    CStarKMSStateOn (Mat Ω) :=
  boundaryFullKMSMinusAtBeta (Ω := Ω) L 1 zero_lt_one hL

def boundaryFullKMSMinus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    KMSState (SA := matrixStarAlgebraCStar Ω) :=
  (boundaryFullKMSMinusCore (Ω := Ω) L hL).toKMSState

@[simp] theorem boundaryFullKMSMinusCore_beta
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    (boundaryFullKMSMinusCore (Ω := Ω) L hL).β = 1 := rfl

@[simp] theorem boundaryFullKMSMinus_beta
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    (boundaryFullKMSMinus (Ω := Ω) L hL).β = 1 := rfl

@[simp] theorem boundaryFullKMSMinus_dyn
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    (boundaryFullKMSMinus (Ω := Ω) L hL).dyn =
      fullBoundaryDynMinus (Ω := Ω) L hL := rfl

@[simp] theorem boundaryFullKMSMinusAtBeta_one_eq_core
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryFullKMSMinusAtBeta (Ω := Ω) L 1 zero_lt_one hL =
      boundaryFullKMSMinusCore (Ω := Ω) L hL := rfl

end WithNonemptyBundles

end

end Derived
end AQFT
end PillarB
