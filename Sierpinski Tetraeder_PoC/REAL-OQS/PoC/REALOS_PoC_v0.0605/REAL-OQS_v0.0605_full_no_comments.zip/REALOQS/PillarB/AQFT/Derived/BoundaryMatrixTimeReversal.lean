import Mathlib
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics
import REALOQS.PillarB.AQFT.TimeOrientation
import REALOQS.PillarB.AQFT.TimeReversal

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

section Basic

variable {Ω : Type u}

def matrixTimeReversalMap (A : Mat Ω) : Mat Ω :=
  Matrix.transpose (Matrix.conjTranspose A)

@[simp] theorem matrixTimeReversalMap_apply (A : Mat Ω) (i j : Ω) :
    matrixTimeReversalMap (Ω := Ω) A i j = star (A i j) := by
  simp [matrixTimeReversalMap, Matrix.conjTranspose_apply]

@[simp] theorem matrixTimeReversalMap_zero :
    matrixTimeReversalMap (Ω := Ω) (0 : Mat Ω) = 0 := by
  ext i j
  simp [matrixTimeReversalMap_apply]

@[simp] theorem matrixTimeReversalMap_add (A B : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (A + B) =
      matrixTimeReversalMap (Ω := Ω) A + matrixTimeReversalMap (Ω := Ω) B := by
  ext i j
  simp [matrixTimeReversalMap_apply]

@[simp] theorem matrixTimeReversalMap_neg (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (-A) = -matrixTimeReversalMap (Ω := Ω) A := by
  ext i j
  simp [matrixTimeReversalMap_apply]

@[simp] theorem matrixTimeReversalMap_smul (z : ℂ) (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (z • A) =
      (star z) • matrixTimeReversalMap (Ω := Ω) A := by
  ext i j
  simp [matrixTimeReversalMap_apply]

@[simp] theorem matrixTimeReversalMap_star (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (star A) =
      star (matrixTimeReversalMap (Ω := Ω) A) := by
  ext i j
  simp [matrixTimeReversalMap_apply, star_eq_conjTranspose, Matrix.conjTranspose_apply]

@[simp] theorem matrixTimeReversalMap_involutive (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (matrixTimeReversalMap (Ω := Ω) A) = A := by
  ext i j
  simp [matrixTimeReversalMap_apply]

@[simp] theorem matrixTimeReversal_fullHamiltonian
    (L : Matrix Ω Ω ℝ) :
    matrixTimeReversalMap (Ω := Ω) (fullHamiltonian (Ω := Ω) L) =
      fullHamiltonian (Ω := Ω) L := by
  ext i j
  simp [matrixTimeReversalMap_apply, fullHamiltonian]

end Basic

section FiniteOne

variable {Ω : Type u} [DecidableEq Ω]

@[simp] theorem matrixTimeReversalMap_one :
    matrixTimeReversalMap (Ω := Ω) (1 : Mat Ω) = 1 := by
  ext i j
  by_cases h : i = j
  · subst h
    simp [matrixTimeReversalMap_apply]
  · simp [matrixTimeReversalMap_apply, h]

end FiniteOne

section FiniteMul

variable {Ω : Type u} [Fintype Ω]

@[simp] theorem matrixTimeReversalMap_mul (A B : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (A * B) =
      matrixTimeReversalMap (Ω := Ω) A * matrixTimeReversalMap (Ω := Ω) B := by
  ext i j
  simp [matrixTimeReversalMap_apply, Matrix.mul_apply]

end FiniteMul

section Finite

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def matrixTimeReversal : TimeReversalOn (Mat Ω) where
  toFun := matrixTimeReversalMap (Ω := Ω)
  map_zero' := matrixTimeReversalMap_zero (Ω := Ω)
  map_one' := matrixTimeReversalMap_one (Ω := Ω)
  map_add' := matrixTimeReversalMap_add (Ω := Ω)
  map_mul' := matrixTimeReversalMap_mul (Ω := Ω)
  map_neg' := matrixTimeReversalMap_neg (Ω := Ω)
  map_star' := matrixTimeReversalMap_star (Ω := Ω)
  map_smul' := matrixTimeReversalMap_smul (Ω := Ω)
  involutive' := matrixTimeReversalMap_involutive (Ω := Ω)

theorem matrixTimeReversal_hamExp
    (L : Matrix Ω Ω ℝ) (z : ℂ) :
    matrixTimeReversalMap (Ω := Ω) (hamExp (Ω := Ω) L z) =
      hamExp (Ω := Ω) L (star z) := by
  let A : Mat Ω := z • fullHamiltonian (Ω := Ω) L
  have hA : Matrix.transpose (Matrix.conjTranspose A) = (star z) • fullHamiltonian (Ω := Ω) L := by
    ext i j
    simp [A, fullHamiltonian, Matrix.conjTranspose_apply]
  calc
    matrixTimeReversalMap (Ω := Ω) (hamExp (Ω := Ω) L z)
        = Matrix.transpose
            (Matrix.conjTranspose
              (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A)) := by
            simp [matrixTimeReversalMap, hamExp, A]
    _ = Matrix.transpose
          (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (Matrix.conjTranspose A)) := by
            rw [(Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm]
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (Matrix.transpose (Matrix.conjTranspose A)) := by
            simpa using
              (Matrix.exp_transpose (𝕂 := ℂ) (A := Matrix.conjTranspose A)).symm
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) ((star z) • fullHamiltonian (Ω := Ω) L) := by
          rw [hA]
    _ = hamExp (Ω := Ω) L (star z) := by
          simp [hamExp]

@[simp] theorem matrixTimeReversal_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    matrixTimeReversalMap (Ω := Ω) (unitaryFromLPlus (Ω := Ω) L t) =
      unitaryFromLMinus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (matrixTimeReversal_hamExp (Ω := Ω) L (Complex.I * (t : ℂ)))

@[simp] theorem matrixTimeReversal_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    matrixTimeReversalMap (Ω := Ω) (unitaryFromLMinus (Ω := Ω) L t) =
      unitaryFromLPlus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (matrixTimeReversal_hamExp (Ω := Ω) L (-Complex.I * (t : ℂ)))

theorem matrixTimeReversal_fullBoundaryDynMapPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (fullBoundaryDynMapPlus (Ω := Ω) L t A) =
      fullBoundaryDynMapMinus (Ω := Ω) L t (matrixTimeReversalMap (Ω := Ω) A) := by
  calc
    matrixTimeReversalMap (Ω := Ω) (fullBoundaryDynMapPlus (Ω := Ω) L t A)
        = matrixTimeReversalMap (Ω := Ω) (unitaryFromLPlus (Ω := Ω) L t) *
            matrixTimeReversalMap (Ω := Ω) A *
            matrixTimeReversalMap (Ω := Ω)
              (Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t)) := by
            simp [fullBoundaryDynMapPlus, Matrix.mul_assoc, matrixTimeReversalMap_mul]
    _ = unitaryFromLMinus (Ω := Ω) L t * matrixTimeReversalMap (Ω := Ω) A *
          Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) := by
            rw [matrixTimeReversal_unitaryFromLPlus]
            rw [show Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) =
                  star (unitaryFromLPlus (Ω := Ω) L t) by rfl]
            rw [matrixTimeReversalMap_star]
            rw [matrixTimeReversal_unitaryFromLPlus]
            rfl
    _ = fullBoundaryDynMapMinus (Ω := Ω) L t (matrixTimeReversalMap (Ω := Ω) A) := by
            simp [fullBoundaryDynMapMinus, Matrix.mul_assoc]

theorem matrixTimeReversal_fullBoundaryDynMapMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    matrixTimeReversalMap (Ω := Ω) (fullBoundaryDynMapMinus (Ω := Ω) L t A) =
      fullBoundaryDynMapPlus (Ω := Ω) L t (matrixTimeReversalMap (Ω := Ω) A) := by
  calc
    matrixTimeReversalMap (Ω := Ω) (fullBoundaryDynMapMinus (Ω := Ω) L t A)
        = matrixTimeReversalMap (Ω := Ω) (unitaryFromLMinus (Ω := Ω) L t) *
            matrixTimeReversalMap (Ω := Ω) A *
            matrixTimeReversalMap (Ω := Ω)
              (Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)) := by
            simp [fullBoundaryDynMapMinus, Matrix.mul_assoc, matrixTimeReversalMap_mul]
    _ = unitaryFromLPlus (Ω := Ω) L t * matrixTimeReversalMap (Ω := Ω) A *
          Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) := by
            rw [matrixTimeReversal_unitaryFromLMinus]
            rw [show Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) =
                  star (unitaryFromLMinus (Ω := Ω) L t) by rfl]
            rw [matrixTimeReversalMap_star]
            rw [matrixTimeReversal_unitaryFromLMinus]
            rfl
    _ = fullBoundaryDynMapPlus (Ω := Ω) L t (matrixTimeReversalMap (Ω := Ω) A) := by
            simp [fullBoundaryDynMapPlus, Matrix.mul_assoc]

theorem matrixTimeReversal_intertwines_fullBoundaryDyn
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    TimeReversalIntertwines
      (A := Mat Ω) (SA := matrixStarAlgebraCStar Ω)
      (matrixTimeReversal (Ω := Ω))
      (fullBoundaryDynPlus (Ω := Ω) L hL)
      (fullBoundaryDynMinus (Ω := Ω) L hL) := by
  intro t A
  change matrixTimeReversalMap (Ω := Ω) ((fullBoundaryDynPlus (Ω := Ω) L hL).α t A) =
    (fullBoundaryDynMinus (Ω := Ω) L hL).α t (matrixTimeReversalMap (Ω := Ω) A)
  rw [fullBoundaryDynPlus_alpha_apply, fullBoundaryDynMinus_alpha_apply]
  exact matrixTimeReversal_fullBoundaryDynMapPlus (Ω := Ω) L t A

theorem matrixTimeReversal_intertwines_fullBoundaryDyn_symm
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    TimeReversalIntertwines
      (A := Mat Ω) (SA := matrixStarAlgebraCStar Ω)
      (matrixTimeReversal (Ω := Ω))
      (fullBoundaryDynMinus (Ω := Ω) L hL)
      (fullBoundaryDynPlus (Ω := Ω) L hL) := by
  intro t A
  change matrixTimeReversalMap (Ω := Ω) ((fullBoundaryDynMinus (Ω := Ω) L hL).α t A) =
    (fullBoundaryDynPlus (Ω := Ω) L hL).α t (matrixTimeReversalMap (Ω := Ω) A)
  rw [fullBoundaryDynMinus_alpha_apply, fullBoundaryDynPlus_alpha_apply]
  exact matrixTimeReversal_fullBoundaryDynMapMinus (Ω := Ω) L t A

theorem matrixTimeReversal_intertwines_boundaryMatrixDyn
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    TimeReversalIntertwines
      (A := Mat Ω) (SA := matrixStarAlgebraCStar Ω)
      (matrixTimeReversal (Ω := Ω))
      (AQFT.boundaryMatrixDyn (Ω := Ω) AQFT.TimeOrientation.plus L hL)
      (AQFT.boundaryMatrixDyn (Ω := Ω) AQFT.TimeOrientation.minus L hL) := by
  simpa [AQFT.boundaryMatrixDyn] using
    (matrixTimeReversal_intertwines_fullBoundaryDyn (Ω := Ω) L hL)

end Finite

end

end Derived
end AQFT
end PillarB
