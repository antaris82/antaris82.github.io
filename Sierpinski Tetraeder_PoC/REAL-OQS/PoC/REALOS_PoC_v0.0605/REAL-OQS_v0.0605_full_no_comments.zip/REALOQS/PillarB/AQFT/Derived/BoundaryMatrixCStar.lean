import Mathlib
import Mathlib.Analysis.CStarAlgebra.Matrix
import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra

set_option autoImplicit false

open scoped Matrix.Norms.L2Operator

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

noncomputable instance instMatrixCStarAlgebra
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    CStarAlgebra (Mat Ω) where
  toNormedRing := inferInstance
  toStarRing := inferInstance
  toCompleteSpace := inferInstance
  toCStarRing := inferInstance
  toNormedAlgebra := inferInstance
  toStarModule := inferInstance

abbrev matrixCStarBundle (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    CStarAlgebraBundle :=
  CStarAlgebraBundle.ofType (Mat Ω)

abbrev matrixStarAlgebraCStar (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgebra (Mat Ω) :=
  starAlgebraOfCStar (Mat Ω)

example : CStarAlgebra (Mat Ω) := by
  infer_instance

example : NonUnitalCStarAlgebra
    ((CStarAlgebraBundle.toNonUnital (matrixCStarBundle Ω)).Carrier) := by
  infer_instance

@[simp] theorem matrixCStarBundle_carrier
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    (matrixCStarBundle Ω).Carrier = Mat Ω := by
  simp [matrixCStarBundle]

@[simp] theorem matrixStarAlgebraCStar_zero_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    (matrixStarAlgebraCStar Ω).zero = (0 : Mat Ω) := by
  simp [matrixStarAlgebraCStar]

@[simp] theorem matrixStarAlgebraCStar_one_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    (matrixStarAlgebraCStar Ω).one = (1 : Mat Ω) := by
  simp [matrixStarAlgebraCStar]

@[simp] theorem matrixStarAlgebraCStar_add_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A B : Mat Ω) :
    (matrixStarAlgebraCStar Ω).add A B = A + B := by
  simp [matrixStarAlgebraCStar]

@[simp] theorem matrixStarAlgebraCStar_mul_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A B : Mat Ω) :
    (matrixStarAlgebraCStar Ω).mul A B = A * B := by
  simp [matrixStarAlgebraCStar]

@[simp] theorem matrixStarAlgebraCStar_neg_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A : Mat Ω) :
    (matrixStarAlgebraCStar Ω).neg A = -A := by
  simp [matrixStarAlgebraCStar]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem star_eq_conjTranspose (A : Mat Ω) : star A = Matrix.conjTranspose A := by
  ext i j
  rfl

@[simp] theorem matrixStarAlgebraCStar_star_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A : Mat Ω) :
    (matrixStarAlgebraCStar Ω).star A = Matrix.conjTranspose A := by
  rw [show (matrixStarAlgebraCStar Ω).star A = star A by
    simp [matrixStarAlgebraCStar]]
  exact star_eq_conjTranspose (A := A)

def matrixStarAlgebraToCStarBridge
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgHom (matrixStarAlgebra Ω) (matrixStarAlgebraCStar Ω) :=
  { toFun := fun A => A
    isHom :=
      { map_zero := by
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_one := by
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_add := by
          intro A B
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_mul := by
          intro A B
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_neg := by
          intro A
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_star := by
          intro A
          simp [matrixStarAlgebra, matrixStarAlgebraCStar] } }

def matrixStarAlgebraFromCStarBridge
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgHom (matrixStarAlgebraCStar Ω) (matrixStarAlgebra Ω) :=
  { toFun := fun A => A
    isHom :=
      { map_zero := by
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_one := by
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_add := by
          intro A B
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_mul := by
          intro A B
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_neg := by
          intro A
          simp [matrixStarAlgebra, matrixStarAlgebraCStar]
        map_star := by
          intro A
          simp [matrixStarAlgebra, matrixStarAlgebraCStar] } }

@[simp] theorem matrixStarAlgebraToCStarBridge_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A : Mat Ω) :
    matrixStarAlgebraToCStarBridge Ω A = A := rfl

@[simp] theorem matrixStarAlgebraFromCStarBridge_apply
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (A : Mat Ω) :
    matrixStarAlgebraFromCStarBridge Ω A = A := rfl

@[simp] theorem matrixStarAlgebraToCStarBridge_comp_from
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgHom.comp
        (matrixStarAlgebraToCStarBridge Ω)
        (matrixStarAlgebraFromCStarBridge Ω) =
      StarAlgHom.id (matrixStarAlgebraCStar Ω) := by
  apply StarAlgHom.ext
  intro A
  rfl

@[simp] theorem matrixStarAlgebraFromCStarBridge_comp_to
    (Ω : Type u) [Fintype Ω] [DecidableEq Ω] :
    StarAlgHom.comp
        (matrixStarAlgebraFromCStarBridge Ω)
        (matrixStarAlgebraToCStarBridge Ω) =
      StarAlgHom.id (matrixStarAlgebra Ω) := by
  apply StarAlgHom.ext
  intro A
  rfl

end

end Derived
end AQFT
end PillarB
