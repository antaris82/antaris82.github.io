import Mathlib
import REALOQS.PillarB.AQFT.Derived.EnergyFromBoundaryOp

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

def betaFromSignal (s : ℝ) : ℝ :=
  1 + abs s

theorem betaFromSignal_pos (s : ℝ) : 0 < betaFromSignal s := by
  have h0 : (0 : ℝ) < 1 := by
    norm_num
  have habs : 0 ≤ abs s :=
    abs_nonneg s
  have h1 : (1 : ℝ) ≤ 1 + abs s :=
    le_add_of_nonneg_right habs
  exact lt_of_lt_of_le h0 h1

def matterFromSignal
    (d : Nat)
    (d_pos : 0 < d)
    (φ : Fin d → ℝ)
    (s : ℝ) : MatterTemplate :=
  { d := d
    d_pos := d_pos
    β := betaFromSignal s
    φ := φ }

end

end Derived
end AQFT
end PillarB
