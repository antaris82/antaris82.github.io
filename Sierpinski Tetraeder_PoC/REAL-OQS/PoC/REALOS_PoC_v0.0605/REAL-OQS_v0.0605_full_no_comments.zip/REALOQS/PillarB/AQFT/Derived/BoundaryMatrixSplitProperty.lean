import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocality
import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.Gates.SplitProperty

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

abbrev boundaryMatrixNet := boundaryMatrixLocalNet (Ω := Ω)

abbrev boundaryMatrixSplitCarrier
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) : Type u :=
  { y : (boundaryMatrixNet (Ω := Ω)).LAN.Alg b //
      ∃ x : (boundaryMatrixNet (Ω := Ω)).LAN.Alg a,
        (boundaryMatrixNet (Ω := Ω)).LAN.incl hab x = y }

theorem boundaryMatrixIncl_injective
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    Function.Injective ((boundaryMatrixNet (Ω := Ω)).LAN.incl hab) := by
  intro A B h
  apply RegionBlockMat.ext
  have hmat := congrArg RegionBlockMat.toMatrix h
  simpa [boundaryMatrixLocalNet_incl_toMatrix] using hmat

def boundaryMatrixSplitIn
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    (boundaryMatrixNet (Ω := Ω)).LAN.Alg a → boundaryMatrixSplitCarrier (Ω := Ω) hab :=
  fun x => ⟨(boundaryMatrixNet (Ω := Ω)).LAN.incl hab x, ⟨x, rfl⟩⟩

def boundaryMatrixSplitOutLeft
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (y : boundaryMatrixSplitCarrier (Ω := Ω) hab) :
    (boundaryMatrixNet (Ω := Ω)).LAN.Alg a :=
  Classical.choose y.2

@[simp] theorem boundaryMatrixSplitOutLeft_spec
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (y : boundaryMatrixSplitCarrier (Ω := Ω) hab) :
    (boundaryMatrixNet (Ω := Ω)).LAN.incl hab
      (boundaryMatrixSplitOutLeft (Ω := Ω) hab y) = y.1 :=
  Classical.choose_spec y.2

@[simp] theorem boundaryMatrixSplitOutLeft_in
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (x : (boundaryMatrixNet (Ω := Ω)).LAN.Alg a) :
    boundaryMatrixSplitOutLeft (Ω := Ω) hab
        (boundaryMatrixSplitIn (Ω := Ω) hab x) = x := by
  apply boundaryMatrixIncl_injective (Ω := Ω) hab
  rw [boundaryMatrixSplitOutLeft_spec (Ω := Ω) hab
      (boundaryMatrixSplitIn (Ω := Ω) hab x)]
  rfl

@[simp] theorem boundaryMatrixSplitIn_outLeft
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (y : boundaryMatrixSplitCarrier (Ω := Ω) hab) :
    boundaryMatrixSplitIn (Ω := Ω) hab
        (boundaryMatrixSplitOutLeft (Ω := Ω) hab y) = y := by
  apply Subtype.ext
  exact boundaryMatrixSplitOutLeft_spec (Ω := Ω) hab y

def boundaryMatrixSplitEquiv
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    (boundaryMatrixNet (Ω := Ω)).LAN.Alg a ≃ boundaryMatrixSplitCarrier (Ω := Ω) hab where
  toFun := boundaryMatrixSplitIn (Ω := Ω) hab
  invFun := boundaryMatrixSplitOutLeft (Ω := Ω) hab
  left_inv := boundaryMatrixSplitOutLeft_in (Ω := Ω) hab
  right_inv := boundaryMatrixSplitIn_outLeft (Ω := Ω) hab

def boundaryMatrixSplitSA
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    StarAlgebra (boundaryMatrixSplitCarrier (Ω := Ω) hab) := by
  let e := boundaryMatrixSplitEquiv (Ω := Ω) hab
  let SAa := (boundaryMatrixNet (Ω := Ω)).SA a
  let zeroF : boundaryMatrixSplitCarrier (Ω := Ω) hab := e SAa.zero
  let oneF : boundaryMatrixSplitCarrier (Ω := Ω) hab := e SAa.one
  let addF : boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab :=
    fun x y => e (SAa.add (e.symm x) (e.symm y))
  let mulF : boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab :=
    fun x y => e (SAa.mul (e.symm x) (e.symm y))
  let negF : boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab :=
    fun x => e (SAa.neg (e.symm x))
  let starF : boundaryMatrixSplitCarrier (Ω := Ω) hab →
      boundaryMatrixSplitCarrier (Ω := Ω) hab :=
    fun x => e (SAa.star (e.symm x))
  refine
    { zero := zeroF
      one := oneF
      add := addF
      mul := mulF
      neg := negF
      star := starF
      add_assoc := by
        intro x y z
        apply e.symm.injective
        simpa [addF, e] using (SAa.add_assoc (e.symm x) (e.symm y) (e.symm z))
      add_comm := by
        intro x y
        apply e.symm.injective
        simpa [addF, e] using (SAa.add_comm (e.symm x) (e.symm y))
      add_zero := by
        intro x
        apply e.symm.injective
        simpa [addF, zeroF, e] using (SAa.add_zero (e.symm x))
      zero_add := by
        intro x
        apply e.symm.injective
        simpa [addF, zeroF, e] using (SAa.zero_add (e.symm x))
      add_left_neg := by
        intro x
        apply e.symm.injective
        simpa [addF, negF, zeroF, e] using (SAa.add_left_neg (e.symm x))
      mul_assoc := by
        intro x y z
        apply e.symm.injective
        simpa [mulF, e] using (SAa.mul_assoc (e.symm x) (e.symm y) (e.symm z))
      one_mul := by
        intro x
        apply e.symm.injective
        simpa [mulF, oneF, e] using (SAa.one_mul (e.symm x))
      mul_one := by
        intro x
        apply e.symm.injective
        simpa [mulF, oneF, e] using (SAa.mul_one (e.symm x))
      left_distrib := by
        intro x y z
        apply e.symm.injective
        simpa [mulF, addF, e] using (SAa.left_distrib (e.symm x) (e.symm y) (e.symm z))
      right_distrib := by
        intro x y z
        apply e.symm.injective
        simpa [mulF, addF, e] using (SAa.right_distrib (e.symm x) (e.symm y) (e.symm z))
      zero_mul := by
        intro x
        apply e.symm.injective
        simpa [mulF, zeroF, e] using (SAa.zero_mul (e.symm x))
      mul_zero := by
        intro x
        apply e.symm.injective
        simpa [mulF, zeroF, e] using (SAa.mul_zero (e.symm x))
      star_involutive := by
        intro x
        apply e.symm.injective
        simpa [starF, e] using (SAa.star_involutive (e.symm x))
      star_add := by
        intro x y
        apply e.symm.injective
        simpa [starF, addF, e] using (SAa.star_add (e.symm x) (e.symm y))
      star_mul := by
        intro x y
        apply e.symm.injective
        simpa [starF, mulF, e] using (SAa.star_mul (e.symm x) (e.symm y))
      star_one := by
        apply e.symm.injective
        simpa [starF, oneF, e] using (SAa.star_one)
      star_zero := by
        apply e.symm.injective
        simpa [starF, zeroF, e] using (SAa.star_zero) }

def boundaryMatrixSplitIsoLocal
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    HaagKastler.StarAlgIso
      (SA := (boundaryMatrixNet (Ω := Ω)).SA a)
      (SB := boundaryMatrixSplitSA (Ω := Ω) hab) := by
  let e := boundaryMatrixSplitEquiv (Ω := Ω) hab
  let SAa := (boundaryMatrixNet (Ω := Ω)).SA a
  refine
    { hom :=
        { toFun := e
          isHom := by
            refine
              { map_zero := by rfl
                map_one := by rfl
                map_add := ?_
                map_mul := ?_
                map_neg := ?_
                map_star := ?_ }
            · intro x y
              change boundaryMatrixSplitIn (Ω := Ω) hab (SAa.add x y) =
                boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.add
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab x))
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab y)))
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab x,
                boundaryMatrixSplitOutLeft_in (Ω := Ω) hab y]
            · intro x y
              change boundaryMatrixSplitIn (Ω := Ω) hab (SAa.mul x y) =
                boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.mul
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab x))
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab y)))
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab x,
                boundaryMatrixSplitOutLeft_in (Ω := Ω) hab y]
            · intro x
              change boundaryMatrixSplitIn (Ω := Ω) hab (SAa.neg x) =
                boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.neg
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab x)))
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab x]
            · intro x
              change boundaryMatrixSplitIn (Ω := Ω) hab (SAa.star x) =
                boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.star
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab
                      (boundaryMatrixSplitIn (Ω := Ω) hab x)))
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab x] }
      inv :=
        { toFun := e.symm
          isHom := by
            refine
              { map_zero := ?_
                map_one := ?_
                map_add := ?_
                map_mul := ?_
                map_neg := ?_
                map_star := ?_ }
            · change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab SAa.zero) = SAa.zero
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab SAa.zero]
            · change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab SAa.one) = SAa.one
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab SAa.one]
            · intro x y
              change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.add
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab y))) =
                SAa.add
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab y)
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab
                (SAa.add
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab y))]
            · intro x y
              change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.mul
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab y))) =
                SAa.mul
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab y)
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab
                (SAa.mul
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
                  (boundaryMatrixSplitOutLeft (Ω := Ω) hab y))]
            · intro x
              change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.neg
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab x))) =
                SAa.neg (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab
                (SAa.neg (boundaryMatrixSplitOutLeft (Ω := Ω) hab x))]
            · intro x
              change boundaryMatrixSplitOutLeft (Ω := Ω) hab
                (boundaryMatrixSplitIn (Ω := Ω) hab
                  (SAa.star
                    (boundaryMatrixSplitOutLeft (Ω := Ω) hab x))) =
                SAa.star (boundaryMatrixSplitOutLeft (Ω := Ω) hab x)
              rw [boundaryMatrixSplitOutLeft_in (Ω := Ω) hab
                (SAa.star (boundaryMatrixSplitOutLeft (Ω := Ω) hab x))] }
      left_inv := by
        intro x
        exact e.left_inv x
      right_inv := by
        intro y
        exact e.right_inv y }

def boundaryMatrixSplitToRightHom
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    StarAlgHom
      (boundaryMatrixSplitSA (Ω := Ω) hab)
      ((boundaryMatrixNet (Ω := Ω)).SA b) :=
  StarAlgHom.comp
    ((boundaryMatrixNet (Ω := Ω)).inclHom (a := a) (b := b) hab)
    ((boundaryMatrixSplitIsoLocal (Ω := Ω) hab).inv)

@[simp] theorem boundaryMatrixSplitToRightHom_apply
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (y : boundaryMatrixSplitCarrier (Ω := Ω) hab) :
    boundaryMatrixSplitToRightHom (Ω := Ω) hab y = y.1 := by
  change (boundaryMatrixNet (Ω := Ω)).LAN.incl hab
      (boundaryMatrixSplitOutLeft (Ω := Ω) hab y) = y.1
  exact boundaryMatrixSplitOutLeft_spec (Ω := Ω) hab y

def boundaryMatrixSplitWitness
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    PillarB.AQFT.Gates.SplitWitness (N := boundaryMatrixNet (Ω := Ω)) hab :=
  { F := boundaryMatrixSplitCarrier (Ω := Ω) hab
    SF := boundaryMatrixSplitSA (Ω := Ω) hab
    ι₁ := (boundaryMatrixSplitIsoLocal (Ω := Ω) hab).hom
    ι₂ := boundaryMatrixSplitToRightHom (Ω := Ω) hab
    comp_eq := by
      apply StarAlgHom.ext
      intro x
      change (boundaryMatrixNet (Ω := Ω)).LAN.incl hab
          (boundaryMatrixSplitOutLeft (Ω := Ω) hab
            (boundaryMatrixSplitIn (Ω := Ω) hab x)) =
        (boundaryMatrixNet (Ω := Ω)).LAN.incl hab x
      simp
    isTypeI := Nonempty
      (HaagKastler.StarAlgIso
        (SA := boundaryMatrixSplitSA (Ω := Ω) hab)
        (SB := (boundaryMatrixNet (Ω := Ω)).SA a)) }

theorem boundaryMatrixSplitWitness_isTypeI
    {a b : (boundaryMatrixNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    (boundaryMatrixSplitWitness (Ω := Ω) hab).isTypeI := by
  refine ⟨{ hom := (boundaryMatrixSplitIsoLocal (Ω := Ω) hab).inv
            inv := (boundaryMatrixSplitIsoLocal (Ω := Ω) hab).hom
            left_inv := (boundaryMatrixSplitIsoLocal (Ω := Ω) hab).right_inv
            right_inv := (boundaryMatrixSplitIsoLocal (Ω := Ω) hab).left_inv }⟩

theorem boundaryMatrixSplitProperty :
    PillarB.AQFT.Gates.SplitProperty (N := boundaryMatrixNet (Ω := Ω)) := by
  intro a b hab
  exact ⟨boundaryMatrixSplitWitness (Ω := Ω) hab⟩

end

end Derived
end AQFT
end PillarB
