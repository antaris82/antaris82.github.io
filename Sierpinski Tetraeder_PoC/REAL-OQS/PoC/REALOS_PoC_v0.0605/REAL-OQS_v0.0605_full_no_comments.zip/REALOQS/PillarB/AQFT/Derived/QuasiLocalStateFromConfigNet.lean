import REALOQS.PillarB.AQFT.Derived.StateFromConfigNet
import REALOQS.PillarB.AQFT.QuasiLocal.StateLift

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

universe u

open PillarA

abbrev N (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω) :=
  localStarAlgebraNet (Ω := Ω) d

abbrev SN (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarA.LayerA.StateNet (Ω := Ω) :=
  PillarB.AQFT.QuasiLocal.SN (Ω := Ω) (N := N (Ω := Ω) d)

def globalConeQL_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := SN (Ω := Ω) d)
    (ρTop := ρTop)

def quasiLocalState_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    StateOn (PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω) (N := N (Ω := Ω) d)) :=
  PillarB.AQFT.QuasiLocal.stateLift (Ω := Ω) (N := N (Ω := Ω) d)
    (C := globalConeQL_fromTopState (Ω := Ω) d ρTop)

def globalConeQL (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := SN (Ω := Ω) d)
    (ρTop := evalTop (Ω := Ω) d σ0)

def quasiLocalState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    StateOn (PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω) (N := N (Ω := Ω) d)) :=
  PillarB.AQFT.QuasiLocal.stateLift (Ω := Ω) (N := N (Ω := Ω) d)
    (C := globalConeQL (Ω := Ω) d σ0)

example (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω) (N := N (Ω := Ω) d)
        (quasiLocalState (Ω := Ω) d σ0) (Finset.univ : Finset Ω) =
      (globalConeQL (Ω := Ω) d σ0).ω (Finset.univ : Finset Ω) := by
  simpa [quasiLocalState] using
    (PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω) (N := N (Ω := Ω) d) (C := globalConeQL (Ω := Ω) d σ0)
      (r := (Finset.univ : Finset Ω)))

example (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω) (N := N (Ω := Ω) d)
        (quasiLocalState (Ω := Ω) d σ0) (∅ : Finset Ω) =
      (globalConeQL (Ω := Ω) d σ0).ω (∅ : Finset Ω) := by
  simpa [quasiLocalState] using
    (PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω) (N := N (Ω := Ω) d) (C := globalConeQL (Ω := Ω) d σ0)
      (r := (∅ : Finset Ω)))

end Derived
end AQFT
end PillarB
