import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.Gates.HaagKastler

universe u

section FromBoundaryOperator

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryAdjFromL (L : Matrix Ω Ω ℝ) (i j : Ω) : Prop :=
  i = j ∨ L i j ≠ 0 ∨ L j i ≠ 0

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryAdjFromL_refl (L : Matrix Ω Ω ℝ) (i : Ω) :
    boundaryAdjFromL (Ω := Ω) L i i :=
  Or.inl rfl

omit [Fintype Ω] [DecidableEq Ω] in
theorem boundaryAdjFromL_symm (L : Matrix Ω Ω ℝ) (i j : Ω) :
    boundaryAdjFromL (Ω := Ω) L i j ↔ boundaryAdjFromL (Ω := Ω) L j i := by
  constructor <;> intro h
  · rcases h with h | hij | hji
    · exact Or.inl h.symm
    · exact Or.inr (Or.inr hij)
    · exact Or.inr (Or.inl hji)
  · rcases h with h | hji | hij
    · exact Or.inl h.symm
    · exact Or.inr (Or.inr hji)
    · exact Or.inr (Or.inl hij)

def boundaryBallFromL (L : Matrix Ω Ω ℝ) (i : Ω) : BoundaryRegion Ω := by
  classical
  exact Finset.univ.filter (fun j => boundaryAdjFromL (Ω := Ω) L i j)

omit [DecidableEq Ω] in
@[simp] theorem mem_boundaryBallFromL_iff
    (L : Matrix Ω Ω ℝ) (i j : Ω) :
    j ∈ boundaryBallFromL (Ω := Ω) L i ↔ boundaryAdjFromL (Ω := Ω) L i j := by
  classical
  simp [boundaryBallFromL]

omit [DecidableEq Ω] in
@[simp] theorem center_mem_boundaryBallFromL
    (L : Matrix Ω Ω ℝ) (i : Ω) :
    i ∈ boundaryBallFromL (Ω := Ω) L i := by
  classical
  simp [mem_boundaryBallFromL_iff, boundaryAdjFromL]

def boundaryObservableBasisFamilyFromL (L : Matrix Ω Ω ℝ) :
    Finset (BoundaryRegion Ω) :=
  Finset.univ.image (boundaryBallFromL (Ω := Ω) L)

@[simp] theorem boundaryBallFromL_mem_boundaryObservableBasisFamilyFromL
    (L : Matrix Ω Ω ℝ) (i : Ω) :
    boundaryBallFromL (Ω := Ω) L i ∈
      boundaryObservableBasisFamilyFromL (Ω := Ω) L := by
  classical
  unfold boundaryObservableBasisFamilyFromL
  exact Finset.mem_image.mpr ⟨i, by simp, rfl⟩

def boundaryObservableBasisFromL (L : Matrix Ω Ω ℝ) :
    RegionBasis (N := boundaryMatrixRichNet (Ω := Ω)) where
  basic := { r | r ∈ boundaryObservableBasisFamilyFromL (Ω := Ω) L }

@[simp] theorem boundaryObservableBasisFromL_basic_ball
    (L : Matrix Ω Ω ℝ) (i : Ω) :
    (boundaryObservableBasisFromL (Ω := Ω) L).basic
      (boundaryBallFromL (Ω := Ω) L i) := by
  unfold boundaryObservableBasisFromL
  exact boundaryBallFromL_mem_boundaryObservableBasisFamilyFromL (Ω := Ω) L i

theorem boundaryObservableBasisFamilyFromL_covers_top
    (L : Matrix Ω Ω ℝ) :
    BasisCover
      (N := boundaryMatrixRichNet (Ω := Ω))
      (boundaryObservableBasisFamilyFromL (Ω := Ω) L)
      ((boundaryMatrixRichNet (Ω := Ω)).LAN.RN.top) := by
  intro ω hω
  refine ⟨boundaryBallFromL (Ω := Ω) L ω, ?_, ?_⟩
  · exact boundaryBallFromL_mem_boundaryObservableBasisFamilyFromL
      (Ω := Ω) L ω
  · exact center_mem_boundaryBallFromL (Ω := Ω) L ω

theorem boundaryObservableBasisFromL_has_top_cover
    (L : Matrix Ω Ω ℝ) :
    ∃ U : Finset (BoundaryRegion Ω),
      (∀ u, u ∈ U → (boundaryObservableBasisFromL (Ω := Ω) L).basic u) ∧
      BasisCover
        (N := boundaryMatrixRichNet (Ω := Ω))
        U
        ((boundaryMatrixRichNet (Ω := Ω)).LAN.RN.top) := by
  refine ⟨boundaryObservableBasisFamilyFromL (Ω := Ω) L, ?_, ?_⟩
  · intro u hu
    unfold boundaryObservableBasisFromL
    exact hu
  · exact boundaryObservableBasisFamilyFromL_covers_top (Ω := Ω) L

end FromBoundaryOperator

end

end Derived
end AQFT
end PillarB
