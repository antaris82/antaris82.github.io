import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.Gates.HaagKastler.Locality

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open PillarA

universe u

variable {Ω : Type u}

abbrev Cfg (d : Nat) (r : Finset Ω) : Type u := (↑(r : Set Ω)) → Fin d

abbrev Alg (d : Nat) (r : Finset Ω) : Type u := Cfg (Ω := Ω) d r → Complex

def piStarAlgebra (X : Type u) : StarAlgebra (X → Complex) :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := fun f => f

    add_assoc := by
      intro a b c
      funext x
      simp [add_assoc]
    add_comm := by
      intro a b
      funext x
      simp [add_comm]
    add_zero := by
      intro a
      funext x
      simp
    zero_add := by
      intro a
      funext x
      simp
    add_left_neg := by
      intro a
      funext x
      simp

    mul_assoc := by
      intro a b c
      funext x
      simp [mul_assoc]
    one_mul := by
      intro a
      funext x
      simp
    mul_one := by
      intro a
      funext x
      simp
    left_distrib := by
      intro a b c
      funext x
      simp [left_distrib]
    right_distrib := by
      intro a b c
      funext x
      simp [right_distrib]
    zero_mul := by
      intro a
      funext x
      simp
    mul_zero := by
      intro a
      funext x
      simp

    star_involutive := by
      intro a
      rfl
    star_add := by
      intro a b
      rfl
    star_mul := by
      intro a b
      funext x
      simp [mul_comm]
    star_one := rfl
    star_zero := rfl }

def restrictCfg (d : Nat) {a b : Finset Ω} (hab : a ≤ b) : Cfg (Ω := Ω) d b → Cfg d a :=
  fun σb xa =>
    σb
      ⟨xa.1,
        by
          have hx : xa.1 ∈ a := by
            exact (Finset.mem_coe).1 xa.2
          have hx' : xa.1 ∈ b := hab hx
          exact (Finset.mem_coe).2 hx'⟩

def inclAlg (d : Nat) {a b : Finset Ω} (hab : a ≤ b) : Alg (Ω := Ω) d a → Alg d b :=
  fun fa σb => fa (restrictCfg (Ω := Ω) d hab σb)

def localAlgebraNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarA.LayerA.LocalAlgebraNet (Ω := Ω) where
  RN := PillarA.LayerA.FinsetRegionNet Ω
  Alg := fun r => Alg (Ω := Ω) d r
  incl := by
    intro a b hab
    exact inclAlg (Ω := Ω) d hab
  incl_id := by
    intro a f
    funext σa
    rfl
  incl_comp := by
    intro a b c hab hbc f
    funext σc
    rfl

def localStarAlgebraNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω) where
  LAN := localAlgebraNet (Ω := Ω) d
  SA := fun r => piStarAlgebra (X := Cfg (Ω := Ω) d r)
  incl_isHom := by
    intro a b hab
    exact
      { map_zero := rfl
        map_one := rfl
        map_add := by intro x y; rfl
        map_mul := by intro x y; rfl
        map_neg := by intro x; rfl
        map_star := by intro x; rfl }

open PillarB.AQFT.HaagKastler

theorem haagKastler_locality_localStarAlgebraNet (Ω : Type u)
    [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (D : Region.CausalDisjoint (RN := (localStarAlgebraNet (Ω := Ω) d).LAN.RN)) :
    PillarB.AQFT.Gates.HaagKastler.Locality
      (N := localStarAlgebraNet (Ω := Ω) d) (D := D) := by
  intro a b _ x y

  unfold PillarB.AQFT.HaagKastler.Commute
  dsimp [localStarAlgebraNet, localAlgebraNet, piStarAlgebra]
  funext σ
  simp [mul_comm]

end Derived
end AQFT
end PillarB
