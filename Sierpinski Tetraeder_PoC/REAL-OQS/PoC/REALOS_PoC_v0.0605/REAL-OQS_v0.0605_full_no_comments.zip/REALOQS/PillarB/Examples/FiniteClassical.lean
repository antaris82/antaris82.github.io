import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace Examples

namespace FiniteClassical

open PillarA
open PillarB.AQFT

def piStarAlgebra (n : Nat) : StarAlgebra (Fin n → Complex) :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := fun f => f

    add_assoc := by
      intro a b c
      funext i
      simp [add_assoc]
    add_comm := by
      intro a b
      funext i
      simp [add_comm]
    add_zero := by
      intro a
      funext i
      simp
    zero_add := by
      intro a
      funext i
      simp
    add_left_neg := by
      intro a
      funext i
      simp

    mul_assoc := by
      intro a b c
      funext i
      simp [mul_assoc]
    one_mul := by
      intro a
      funext i
      simp
    mul_one := by
      intro a
      funext i
      simp
    left_distrib := by
      intro a b c
      funext i
      simp [left_distrib]
    right_distrib := by
      intro a b c
      funext i
      simp [right_distrib]
    zero_mul := by
      intro a
      funext i
      simp
    mul_zero := by
      intro a
      funext i
      simp

    star_involutive := by
      intro a
      rfl
    star_add := by
      intro a b
      rfl
    star_mul := by
      intro a b

      funext i
      simp [mul_comm]
    star_one := rfl
    star_zero := rfl }

def localAlgebraNet (n : Nat) : PillarA.LayerA.LocalAlgebraNet (Ω := Fin n) where
  RN := PillarA.LayerA.SetRegionNet (Fin n)
  Alg := fun _r => Fin n → Complex
  incl := by
    intro _a _b _hab f
    exact f
  incl_id := by
    intro _a x
    rfl
  incl_comp := by
    intro _a _b _c _hab _hbc x
    rfl

def localStarNet (n : Nat) : PillarB.AQFT.LocalStarAlgebraNet (Ω := Fin n) where
  LAN := localAlgebraNet n
  SA := fun _r => piStarAlgebra n
  incl_isHom := by
    intro a b hab

    exact
      { map_zero := rfl
        map_one := rfl
        map_add := by intro x y; rfl
        map_mul := by intro x y; rfl
        map_neg := by intro x; rfl
        map_star := by intro x; rfl }

def stateNet (n : Nat) : PillarA.LayerA.StateNet (Ω := Fin n) :=
  (localStarNet n).toStateNet

def evalState {n : Nat} (i : Fin n) : StateOn (Fin n → Complex) :=
  { toFun := fun f => f i }

def globalCone (n : Nat) (i : Fin n) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet n) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet n) (evalState i)

end FiniteClassical

end Examples
end PillarB
