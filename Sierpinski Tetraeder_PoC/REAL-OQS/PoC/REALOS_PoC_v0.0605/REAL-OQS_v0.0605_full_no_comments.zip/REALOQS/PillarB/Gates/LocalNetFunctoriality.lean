import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

section

variable {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω))

theorem inclHom_id (a : N.LAN.RN.Region) :
    N.inclHom (a := a) (b := a) (le_rfl) = StarAlgHom.id (N.SA a) :=
  N.inclHom_id a

theorem inclHom_comp {a b c : N.LAN.RN.Region} (hab : a ≤ b) (hbc : b ≤ c) :
    StarAlgHom.comp (N.inclHom (a := b) (b := c) hbc) (N.inclHom (a := a) (b := b) hab) =
      N.inclHom (a := a) (b := c) (le_trans hab hbc) :=
  N.inclHom_comp hab hbc

end

end Gates
end AQFT
end PillarB
