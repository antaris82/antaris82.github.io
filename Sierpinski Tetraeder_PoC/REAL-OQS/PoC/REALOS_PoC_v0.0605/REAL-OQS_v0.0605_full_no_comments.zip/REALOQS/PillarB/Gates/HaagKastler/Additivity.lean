import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

def additivityImgLeft (a b : N.LAN.RN.Region) : Set (N.LAN.Alg (a ⊔ b)) :=
  Set.range (N.LAN.incl (show a ≤ a ⊔ b from le_sup_left))

def additivityImgRight (a b : N.LAN.RN.Region) : Set (N.LAN.Alg (a ⊔ b)) :=
  Set.range (N.LAN.incl (show b ≤ a ⊔ b from le_sup_right))

def additivityGenSet (a b : N.LAN.RN.Region) : Set (N.LAN.Alg (a ⊔ b)) :=
  additivityImgLeft (N := N) a b ∪ additivityImgRight (N := N) a b

def Additivity : Prop :=
  ∀ (a b : N.LAN.RN.Region),
    IsGeneratedBy (SA := N.SA (a ⊔ b)) (additivityGenSet (N := N) a b)

theorem gate_additivity_generated (hAdd : Additivity (N := N))
    (a b : N.LAN.RN.Region) (x : N.LAN.Alg (a ⊔ b)) :
    GeneratedBy (SA := N.SA (a ⊔ b)) (additivityGenSet (N := N) a b) x :=
  hAdd a b x

end HaagKastler

end Gates
end AQFT
end PillarB
