import REALOQS.PillarB.Gates.HaagKastler.Additivity
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity
import REALOQS.PillarB.Gates.HaagKastler.Covariance
import REALOQS.PillarB.Gates.HaagKastler.Isotony
import REALOQS.PillarB.Gates.HaagKastler.Locality
import REALOQS.PillarB.Gates.HaagKastler.Spectrum
import REALOQS.PillarB.Gates.HaagKastler.StrongAdditivity
import REALOQS.PillarB.Gates.HaagKastler.TimeSlice
import REALOQS.PillarB.Gates.HaagKastler.Vacuum

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

structure Minimal (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN)) where
  isotony : Isotony (N := N)
  locality : Locality (N := N) D
  additivity : Additivity (N := N)

structure ObservableMinimal
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (B : RegionBasis (N := N)) where
  isotony : Isotony (N := N)
  locality : Locality (N := N) D
  additivityOnBasis : AdditivityOnBasis (N := N) B

structure Full
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (G : Type v) [Group G]
    (C : CovariantStateAction (Ω := Ω) (G := G) N)
    (CC : CausalCompletion (N := N))
    (isTimeSlice : N.LAN.RN.Region → Prop)
    (T : Type v) [Group T] where
  minimal : Minimal (N := N) D
  strongAdditivity : StrongAdditivity (N := N)
  covariance : CovarianceWith (N := N) (G := G) C.RA
  timeSlice : TimeSlice (N := N) CC isTimeSlice

  vacuumState : GlobalState (Ω := Ω) N
  vacuumPhysical : IsPhysical (Ω := Ω) vacuumState
  vacuumInvariant : IsInvariant (Ω := Ω) (G := G) (C := C) vacuumState
  spectrum : SpectrumCondition (N := N) (T := T)

structure ObservableFull
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (B : RegionBasis (N := N))
    (G : Type v) [Group G]
    (C : CovariantStateAction (Ω := Ω) (G := G) N)
    (CC : CausalCompletion (N := N))
    (isTimeSlice : N.LAN.RN.Region → Prop)
    (T : Type v) [Group T] where
  minimal : ObservableMinimal (N := N) D B
  strongAdditivityOnBasis : StrongAdditivityOnBasis (N := N) B
  covariance : CovarianceWith (N := N) (G := G) C.RA
  timeSlice : TimeSlice (N := N) CC isTimeSlice
  vacuumState : GlobalState (Ω := Ω) N
  vacuumPhysical : IsPhysical (Ω := Ω) vacuumState
  vacuumInvariant : IsInvariant (Ω := Ω) (G := G) (C := C) vacuumState
  spectrum : SpectrumCondition (N := N) (T := T)

end HaagKastler

end Gates
end AQFT
end PillarB
