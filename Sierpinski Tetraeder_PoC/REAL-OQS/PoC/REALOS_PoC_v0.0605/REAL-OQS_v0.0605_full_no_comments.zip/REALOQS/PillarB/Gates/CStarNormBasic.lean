import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Analysis.CStarAlgebra.Hom
import Mathlib.Analysis.Normed.Group.Basic
import REALOQS.PillarB.AQFT.CStarNorm

set_option autoImplicit false

namespace PillarB
namespace Gates

universe u v

section CStarLaws

variable {A : Type u}

theorem gate_cstar_norm_star_mul_self [NonUnitalCStarAlgebra A] (x : A) :
    ‖star x * x‖ = ‖x‖ * ‖x‖ := by
  simpa using (CStarRing.norm_star_mul_self (x := x))

theorem gate_norm_star [NonUnitalCStarAlgebra A] (x : A) : ‖star x‖ = ‖x‖ := by
  simp

end CStarLaws

section IsometryOfInjectiveHom

variable {A : Type u} {B : Type v}

theorem gate_nonunital_star_alg_hom_isometry
    [NonUnitalCStarAlgebra A] [NonUnitalCStarAlgebra B]
    (φ : A →⋆ₙₐ[ℂ] B) (hφ : Function.Injective φ) : Isometry φ := by
  simpa using (NonUnitalStarAlgHom.isometry (φ := φ) hφ)

theorem gate_nonunital_star_alg_hom_norm_map
    [NonUnitalCStarAlgebra A] [NonUnitalCStarAlgebra B]
    (φ : A →⋆ₙₐ[ℂ] B) (hφ : Function.Injective φ) (x : A) : ‖φ x‖ = ‖x‖ := by
  have hIso : Isometry φ := gate_nonunital_star_alg_hom_isometry (φ := φ) hφ

  simpa [dist_eq_norm, map_zero] using (hIso.dist_eq x 0)

end IsometryOfInjectiveHom

end Gates
end PillarB
