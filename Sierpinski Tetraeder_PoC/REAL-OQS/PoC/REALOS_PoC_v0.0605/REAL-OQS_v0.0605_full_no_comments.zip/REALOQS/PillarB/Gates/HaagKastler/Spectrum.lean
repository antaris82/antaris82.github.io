import REALOQS.PillarB.AQFT.HaagKastler.SupportFull
import REALOQS.PillarB.Gates.HaagKastler.Covariance

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

structure SpectrumCondition (N : LocalStarAlgebraNet (Ω := Ω)) (T : Type v) where
  witness : PillarB.AQFT.HaagKastler.SpectrumCondition (G := T)

def SpectrumCondition.InForwardCone
    {N : LocalStarAlgebraNet (Ω := Ω)} {T : Type v}
    (SC : SpectrumCondition N T) : Prop :=
  SC.witness.spec.support ⊆ ForwardCone

theorem SpectrumCondition.inForwardCone
    {N : LocalStarAlgebraNet (Ω := Ω)} {T : Type v}
    (SC : SpectrumCondition N T) : SC.InForwardCone :=
  SC.witness.spec.support_subset_forward

end HaagKastler

end Gates
end AQFT
end PillarB
