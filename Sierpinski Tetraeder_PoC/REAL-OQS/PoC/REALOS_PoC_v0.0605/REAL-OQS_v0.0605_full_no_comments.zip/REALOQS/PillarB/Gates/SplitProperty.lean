import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v w

variable {Ω : Type u}

structure SplitWitness
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) where

  F : Type v

  SF : StarAlgebra F

  ι₁ : StarAlgHom (N.SA a) SF

  ι₂ : StarAlgHom SF (N.SA b)

  comp_eq : StarAlgHom.comp ι₂ ι₁ = N.inclHom (a := a) (b := b) hab

  isTypeI : Prop

def SplitProperty (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)) : Prop :=
  ∀ {a b : N.LAN.RN.Region} (hab : a ≤ b), Nonempty (SplitWitness (N := N) hab)

def TypeIPlaceholder : Prop := (0 : Nat) = 0

def splitWitness_factorThroughLarger
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    SplitWitness (N := N) hab :=
  { F := N.LAN.Alg b
    SF := N.SA b
    ι₁ := N.inclHom (a := a) (b := b) hab
    ι₂ := StarAlgHom.id (N.SA b)
    comp_eq := by
      apply StarAlgHom.ext
      intro x
      rfl
    isTypeI := TypeIPlaceholder }

theorem splitProperty_factorThroughLarger
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)) :
    SplitProperty (N := N) := by
  intro a b hab
  exact ⟨splitWitness_factorThroughLarger (N := N) hab⟩

namespace SplitProperty

variable {N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)}

theorem refl (h : SplitProperty (N := N)) (a : N.LAN.RN.Region) :
    Nonempty (SplitWitness (N := N) (a := a) (b := a) (le_rfl)) :=
  h (a := a) (b := a) (le_rfl)

end SplitProperty

end Gates
end AQFT
end PillarB
