import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS

universe u

structure MarkovSemigroup (A : Type u) where
  Φ : Nat → CPTPChannel A A
  map_zero : ∀ x : A, (Φ 0).toChannel.map x = x
  map_add : ∀ (t s : Nat) (x : A),
    (Φ (t + s)).toChannel.map x = (Φ t).toChannel.map ((Φ s).toChannel.map x)

namespace MarkovSemigroup

variable {A : Type u} (S : MarkovSemigroup (A := A))

@[simp] theorem gate_map_zero (x : A) : (S.Φ 0).toChannel.map x = x :=
  S.map_zero x

theorem gate_map_add (t s : Nat) (x : A) :
    (S.Φ (t + s)).toChannel.map x = (S.Φ t).toChannel.map ((S.Φ s).toChannel.map x) :=
  S.map_add t s x

end MarkovSemigroup

end OQS
end PillarC
