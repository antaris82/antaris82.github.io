import Mathlib

set_option autoImplicit false

namespace PillarC
namespace OQS

universe u v w

structure Channel (A : Type u) (B : Type v) where
  map : A → B

namespace Channel

variable {A : Type u} {B : Type v} {C : Type w}

instance : CoeFun (Channel A B) (fun _ => A → B) where
  coe Φ := Φ.map

def id (A : Type u) : Channel A A := ⟨fun x => x⟩

def comp (Φ : Channel A B) (Ψ : Channel B C) : Channel A C :=
  ⟨fun x => Ψ.map (Φ.map x)⟩

@[simp] theorem map_id (x : A) : (id A).map x = x := rfl

@[simp] theorem map_comp (Φ : Channel A B) (Ψ : Channel B C) (x : A) :
    (comp Φ Ψ).map x = Ψ.map (Φ.map x) := rfl

end Channel

structure CPTPChannel (A : Type u) (B : Type v) extends Channel A B where

  isCP : Prop

  isTP : Prop

namespace CPTPChannel

variable {A : Type u} {B : Type v} {C : Type w}

instance : CoeFun (CPTPChannel A B) (fun _ => A → B) where
  coe Φ := Φ.toChannel.map

def ofChannel (Φ : Channel A B) (cp tp : Prop) : CPTPChannel A B :=
  { toChannel := Φ
    isCP := cp
    isTP := tp }

def id (A : Type u) (cp tp : Prop) : CPTPChannel A A :=
  ofChannel (Channel.id A) cp tp

def comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) : CPTPChannel A C :=
  { toChannel := Channel.comp Φ.toChannel Ψ.toChannel
    isCP := Φ.isCP ∧ Ψ.isCP
    isTP := Φ.isTP ∧ Ψ.isTP }

@[simp] theorem map_id (cp tp : Prop) (x : A) :
    (id (A := A) cp tp).toChannel.map x = x := rfl

@[simp] theorem map_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) (x : A) :
    (comp Φ Ψ).toChannel.map x = Ψ.toChannel.map (Φ.toChannel.map x) := rfl

theorem gate_cp_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) :
    (comp Φ Ψ).isCP ↔ (Φ.isCP ∧ Ψ.isCP) := Iff.rfl

theorem gate_tp_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) :
    (comp Φ Ψ).isTP ↔ (Φ.isTP ∧ Ψ.isTP) := Iff.rfl

end CPTPChannel

end OQS
end PillarC
