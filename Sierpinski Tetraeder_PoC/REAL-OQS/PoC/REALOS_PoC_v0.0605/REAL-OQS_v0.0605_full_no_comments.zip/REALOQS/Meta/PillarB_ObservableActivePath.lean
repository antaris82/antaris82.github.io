import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableActivePath

noncomputable section

open _root_.PillarB.AQFT.Derived
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

@[simp] theorem toc_observable_basis_eq_boundaryMatrixAdditiveBasis [Fact (0 < b)] :
    B_add_ToC (b := b) (p := p) =
      boundaryMatrixAdditiveBasis
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p)) := by
  rfl

@[simp] theorem toc_observable_net_eq_boundaryMatrixAdditiveNetFromL [Fact (0 < b)] :
    N_add_ToC (b := b) (p := p) =
      boundaryMatrixAdditiveNetFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) := by
  rfl

@[simp] theorem toc_observable_state_net_eq_boundaryMatrixAdditiveStateNet [Fact (0 < b)] :
    SN_add_ToC (b := b) (p := p) =
      boundaryMatrixAdditiveStateNet
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p)) := by
  rfl

@[simp] theorem toc_observable_top_eq_boundaryMatrixAdditiveTopFromRich [Fact (0 < b)] :
    ρAdd_top (b := b) (p := p) =
      boundaryMatrixAdditiveTopFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem
    toc_observable_quasilocal_eq_boundaryMatrixAdditiveQuasiLocalStateFromRich
    [Fact (0 < b)] :
    Φ_add_FromA (b := b) (p := p) =
      boundaryMatrixAdditiveQuasiLocalStateFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

end
end PillarB_ObservableActivePath
end Meta
