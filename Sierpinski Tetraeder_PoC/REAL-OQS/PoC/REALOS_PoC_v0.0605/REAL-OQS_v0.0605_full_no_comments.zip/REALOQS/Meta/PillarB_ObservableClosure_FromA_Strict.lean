import REALOQS.Meta.PillarB_HK_Observable_Strict
import REALOQS.Meta.PillarB_ObservablePath
import REALOQS.Meta.PillarB_ObservableStatePath

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableClosure_FromA_Strict

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

theorem toc_observable_quasilocal_univ_marker :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))
        (Φ_add_FromA (b := b) (p := p))
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top) =
      ρAdd_top (b := b) (p := p) := by
  trans ρAdd_region (b := b) (p := p) ((N_add_ToC (b := b) (p := p)).LAN.RN.top)
  · exact restrictToRegion_Φ_add_FromA (b := b) (p := p)
      ((N_add_ToC (b := b) (p := p)).LAN.RN.top)
  · apply StateOn.ext
    intro A
    simp [ρAdd_top_apply, ρAdd_region_apply]

theorem toc_observable_isotony_marker :
    _root_.PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_add_ToC (b := b) (p := p)) :=
  isotony_ToC_add (b := b) (p := p)

theorem toc_observable_locality_marker :
    _root_.PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_add_ToC (b := b) (p := p))
      (_root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))) :=
  locality_ToC_add (b := b) (p := p)

theorem toc_observable_additivity_marker :
    _root_.PillarB.AQFT.Gates.HaagKastler.AdditivityOnBasis
      (N := N_add_ToC (b := b) (p := p))
      (B_add_ToC (b := b) (p := p)) :=
  additivity_basis_ToC_add (b := b) (p := p)

theorem toc_observable_top_restricts_marker
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    (SN_add_ToC (b := b) (p := p)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_add_ToC (b := b) (p := p)).LAN.RN) r)
        (ρAdd_top (b := b) (p := p)) =
      ρAdd_region (b := b) (p := p) r :=
  ρAdd_region_eq_restrict_top (b := b) (p := p) r

def toc_observable_minimal_marker :
    _root_.PillarB.AQFT.Gates.HaagKastler.ObservableMinimal
      (N := N_add_ToC (b := b) (p := p))
      (_root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p)))
      (B_add_ToC (b := b) (p := p)) :=
  _root_.Meta.PillarB_HK_Observable_Strict.toc_observable_minimal (b := b) (p := p)

end
end PillarB_ObservableClosure_FromA_Strict
end Meta
