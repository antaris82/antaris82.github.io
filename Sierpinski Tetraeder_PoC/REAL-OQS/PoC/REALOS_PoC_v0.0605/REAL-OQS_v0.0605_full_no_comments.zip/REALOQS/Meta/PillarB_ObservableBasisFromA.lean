import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableBasisFromA

noncomputable section

open _root_.PillarB.AQFT.Gates.HaagKastler
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

theorem toc_observable_basis_basic_ball
    (i : Ω (b := b) (p := p)) :
    (B_ToC (b := b) (p := p)).basic
      (_root_.PillarB.AQFT.Derived.boundaryBallFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i) :=
  B_ToC_basic_ball (b := b) (p := p) i

theorem toc_observable_basis_covers_top :
    BasisCover
      (N := N_rich_ToC (b := b) (p := p))
      (basisFamily_ToC (b := b) (p := p))
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) :=
  basisFamily_ToC_covers_top (b := b) (p := p)

end
end PillarB_ObservableBasisFromA
end Meta
