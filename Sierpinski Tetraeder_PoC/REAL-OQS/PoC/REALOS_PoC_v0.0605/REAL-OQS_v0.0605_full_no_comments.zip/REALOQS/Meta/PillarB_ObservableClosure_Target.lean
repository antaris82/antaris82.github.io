import REALOQS.Meta.PillarB_ObservableActivePath
import REALOQS.Meta.PillarB_ObservableClosure_FromA_Strict

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableClosure_Target

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

@[simp] theorem toc_observable_closure_target_marker :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))
        (Φ_add_FromA (b := b) (p := p))
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top) =
      ρAdd_top (b := b) (p := p) :=
  _root_.Meta.PillarB_ObservableClosure_FromA_Strict.toc_observable_quasilocal_univ_marker
    (b := b) (p := p)

@[simp] theorem toc_observable_state_target_marker :
    SN_add_ToC (b := b) (p := p) =
      _root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveStateNet
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p)) := by
  rfl

end
end PillarB_ObservableClosure_Target
end Meta
