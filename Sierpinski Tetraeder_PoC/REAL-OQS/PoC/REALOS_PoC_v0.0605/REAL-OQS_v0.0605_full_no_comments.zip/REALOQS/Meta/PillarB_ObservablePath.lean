import REALOQS.PillarB.AQFT
import REALOQS.PillarB.Gates.HaagKastler

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservablePath

noncomputable section

open _root_.PillarB.AQFT.Gates.HaagKastler
open _root_.PillarB.AQFT.Derived

universe u v

variable {Ω : Type u}
variable (N : _root_.PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω))
variable (D : _root_.PillarB.AQFT.HaagKastler.Region.CausalDisjoint (RN := N.LAN.RN))
variable (B : RegionBasis (N := N))
variable (G : Type v) [Group G]
variable (C : CovariantStateAction (Ω := Ω) (G := G) N)
variable (CC : CausalCompletion (N := N))
variable (isTimeSlice : N.LAN.RN.Region → Prop)
variable (T : Type v) [Group T]

theorem observable_minimal_exposes_basis_additivity
    (h : ObservableMinimal (N := N) (D := D) (B := B)) :
    AdditivityOnBasis (N := N) B :=
  h.additivityOnBasis

theorem observable_full_exposes_basis_strong_additivity
    (h : ObservableFull
      (N := N) (D := D) (B := B) (G := G) (C := C)
      (CC := CC) (isTimeSlice := isTimeSlice) (T := T)) :
    StrongAdditivityOnBasis (N := N) B :=
  h.strongAdditivityOnBasis

theorem rich_boundary_matrix_net_not_additive_if_exists_ne
    [Fintype Ω] [DecidableEq Ω] (hΩ : ∃ i j : Ω, i ≠ j) :
    ¬ Additivity (N := boundaryMatrixRichNet (Ω := Ω)) :=
  boundaryMatrixRichNet_not_additive_of_exists_ne (Ω := Ω) hΩ

end
end PillarB_ObservablePath
end Meta
