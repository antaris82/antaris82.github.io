import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableDynamicsDecision

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

@[simp] theorem toc_observable_top_state_restriction_marker :
    observableTopState_is_restriction_defined (b := b) (p := p) := by
  exact observableTopState_is_restriction_defined (b := b) (p := p)

@[simp] theorem toc_observable_quasilocal_restriction_marker :
    observableQuasiLocal_is_restriction_defined (b := b) (p := p) := by
  exact observableQuasiLocal_is_restriction_defined (b := b) (p := p)

@[simp] theorem toc_observable_top_carrier_marker
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A := by
  rfl

@[simp] theorem toc_observable_top_basisGen_marker
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) ↔
      A ∈ _root_.PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  rfl

theorem toc_basis_generator_mem_observableTop
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    topBasisGenerator_ToC (b := b) (p := p)
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact topBasisGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) hu A

theorem toc_zero_maps_basic_ball_generator_to_observableTop
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (_root_.PillarB.AQFT.Derived.boundaryBallFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
          (_root_.PillarB.AQFT.Derived.boundaryBallFromL
            (Ω := Ω (b := b) (p := p))
            (L := L (b := b) (p := p)) i))
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_zero_maps_basic_ball_generator_to_observableTop
    (b := b) (p := p) i A

@[simp] theorem toc_observable_ball_generator_marker
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (_root_.PillarB.AQFT.Derived.boundaryBallFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    observableBallGenerator_ToC (b := b) (p := p) i A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact observableBallGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) i A

theorem toc_observable_escape_witness_blocks_closure
    (hw : observableDynEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact observableDynEscapeWitness_not_preserves_N_add_top
    (b := b) (p := p) hw

theorem toc_sameBall_escape_witness_blocks_sameBall_ansatz
    (hw : observableDynSameBallLocalizationEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p) := by
  exact observableDynSameBallLocalizationEscapeWitness_not_preserves
    (b := b) (p := p) hw

theorem toc_observable_dynamics_closed_of_allBalls_eq_top
    (hball : ∀ i : Ω (b := b) (p := p),
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i =
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_allBalls_eq_top
    (b := b) (p := p) hball

theorem toc_observable_dynamics_closed_of_offdiag_nonzero
    (hoff : ∀ ⦃x y : Ω (b := b) (p := p)⦄, x ≠ y →
      L (b := b) (p := p) x y ≠ 0) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_offdiag_nonzero
    (b := b) (p := p) hoff

theorem toc_observable_dynamics_closed_of_Lmax_eq_one
    (hL : p.L_max = 1) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_Lmax_eq_one
    (b := b) (p := p) hL

theorem toc_observable_ball_generator_reduction_marker
    (hball : dyn_top_ToC_preserves_observableBallGenerators
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_observableBallGenerators
    (b := b) (p := p) hball

theorem toc_observable_dynamics_reduction_marker
    (hgen : ∀ (t : ℝ) ⦃A : RichTopAlg (b := b) (p := p)⦄,
      A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) →
        (dyn_top_ToC (b := b) (p := p)).α t A ∈
          observableTopCarrier_ToC (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_basisGenerators
    (b := b) (p := p) hgen

@[simp] theorem toc_handoff_Lmax_eq_two_crossParentBlockConstant_marker :
    handoff_Lmax_eq_two_crossParentBlockConstant (b := b) ↔
      handoff_Lmax_eq_two_crossParentBlockConstant (b := b) := by
  rfl

@[simp] theorem toc_handoff_Lmax_eq_two_coarsens_to_handoff_k1_marker :
    handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) ↔
      handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) := by
  rfl

theorem toc_handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  exact handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (b := b) hconst hcoarsen hij hx hy

theorem toc_handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  exact handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (b := b) hconst hcoarsen hxy

@[simp] theorem toc_handoff_Lmax_eq_two_refines_handoff_k1_marker :
    handoff_Lmax_eq_two_refines_handoff_k1 (b := b) ↔
      handoff_Lmax_eq_two_refines_handoff_k1 (b := b) := by
  rfl

theorem toc_handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine
    (hb : 0 < b)
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) := by
  exact
    _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
      .handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine
      (b := b) hb href

theorem toc_handoff_Lmax_eq_two_crossParentBlockConstant_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_crossParentBlockConstant (b := b) := by
  exact
    _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
      .handoff_Lmax_eq_two_crossParentBlockConstant_of_refine
      (b := b) href

theorem toc_handoff_Lmax_eq_two_crossParent_entry_ne_zero_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  exact
    _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
      .handoff_Lmax_eq_two_crossParent_entry_ne_zero_of_refine
      (b := b) href hij hx hy

theorem toc_handoff_Lmax_eq_two_boundaryBall_contains_crossParent_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  exact
    _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
      .handoff_Lmax_eq_two_boundaryBall_contains_crossParent_of_refine
      (b := b) href hxy

theorem toc_observable_dynamics_decision_surface :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) ∨
      ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_or_not (b := b) (p := p)

theorem toc_observable_dynamics_zero_marker :
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α 0)
      (observableTopCarrier_ToC (b := b) (p := p)) :=
  dyn_top_ToC_zero_preserves_N_add_top (b := b) (p := p)

end
end PillarB_ObservableDynamicsDecision

@[simp] theorem toc_basis_region_eq_basic_ball
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u) :
    ∃ i : Ω (b := b) (p := p),
      u = boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i := by
  exact basic_region_eq_boundaryBallFromL (b := b) (p := p) hu

example : dyn_top_ToC_preserves_basic_ball_generator_localization (b := b) (p := p) →
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro h
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_basic_ball_generator_localization
    (b := b) (p := p) h

example (i : Ω (b := b) (p := p))
    {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i ≤
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) 0 h A)) := by
  exact dyn_top_ToC_zero_preserves_basic_ball_generator_localization
    (b := b) (p := p) i A

end Meta
