import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_AQFT_FromA

noncomputable section

namespace ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

abbrev Ω : Type :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.Ω (b := b) p

abbrev L : Matrix (Ω (b := b) (p := p)) (Ω (b := b) (p := p)) ℝ :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.L (b := b) p

@[simp] lemma L_def :
    L (b := b) (p := p) =
      _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.L (b := b) p := rfl

noncomputable abbrev T : _root_.PillarB.AQFT.Derived.MatterTemplate :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.T (b := b) p

section Strict

variable [Fact (0 < b)]

noncomputable abbrev ρTop :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.ρTop (b := b) p

noncomputable abbrev Φ_ToC_fromA :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.Φ_FromA (b := b) p

end Strict

end ToC

end

end TreeOfCliques_AQFT_FromA
end Examples
end REALOQS
