import Mathlib
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalD
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarB.AQFT.Derived.MatterFromPillarA

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_MatterFromA

noncomputable section

open _root_.PillarA
open _root_.PillarA.LayerA
open _root_.PillarA.Physics
open _root_.PillarB
open _root_.PillarB.AQFT
open _root_.PillarB.AQFT.Derived

namespace ToC

variable {b : Nat}

noncomputable abbrev axis
    (p : Policy b) :=
  _root_.PillarA.Physics.Instances.TreeOfCliques.ToC.axis_canonicalD
    (b := b) (p := p)

def argmaxBreakUpTo
    (A : ScaleBreakingAxisD (_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.S b)) :
    Nat → Nat
  | 0 => 0
  | n + 1 =>
      let k := argmaxBreakUpTo A n
      if A.breakMeasure k ≤ A.breakMeasure (n + 1) then n + 1 else k

def kWindow (p : Policy b) : Nat := p.K_max

noncomputable def kStar (p : Policy b) : Nat :=
  argmaxBreakUpTo (b := b) (axis (b := b) p) (kWindow p)

noncomputable def signalAt
    (p : Policy b)
    (k : Nat) : ℝ :=
  ((axis (b := b) p).breakMeasure k).toReal

noncomputable def signalFromA (p : Policy b) : ℝ :=
  signalAt (b := b) p (kStar (b := b) p)

noncomputable def betaFromA (p : Policy b) : ℝ :=
  betaFromSignal (signalFromA (b := b) p)

def dFromA (p : Policy b) : Nat :=
  kWindow p + 1

theorem dFromA_pos (p : Policy b) : 0 < dFromA (b := b) p := by
  simp [dFromA, kWindow]

noncomputable def phiFromA
    (p : Policy b) : Fin (dFromA (b := b) p) → ℝ :=
  fun i => signalAt (b := b) p i.1

noncomputable def matterFromA
    (p : Policy b) : MatterTemplate :=
  { d := dFromA (b := b) p
    d_pos := dFromA_pos (b := b) p
    β := betaFromA (b := b) p
    φ := phiFromA (b := b) p }

theorem betaFromA_pos (p : Policy b) :
    0 < betaFromA (b := b) p := by
  simpa [betaFromA] using
    (betaFromSignal_pos (signalFromA (b := b) p))

theorem matterFromA_beta_pos (p : Policy b) :
    0 < (matterFromA (b := b) p).β := by
  simpa [matterFromA, betaFromA] using
    (betaFromSignal_pos (signalFromA (b := b) p))

theorem beta_pos (p : Policy b) :
    0 < (matterFromA (b := b) p).β := by
  simpa using matterFromA_beta_pos (b := b) p

@[simp] theorem matterFromA_d (p : Policy b) :
    (matterFromA (b := b) p).d = dFromA (b := b) p := rfl

@[simp] theorem matterFromA_phi (p : Policy b) :
    (matterFromA (b := b) p).φ = phiFromA (b := b) p := rfl

end ToC

end
end TreeOfCliques_MatterFromA
end Examples
end REALOQS
