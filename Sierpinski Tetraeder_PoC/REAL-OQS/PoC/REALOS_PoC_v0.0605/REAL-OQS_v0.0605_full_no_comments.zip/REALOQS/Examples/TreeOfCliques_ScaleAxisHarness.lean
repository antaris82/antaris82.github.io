import Mathlib
import REALOQS.Examples.TreeOfCliques_CoarsenBoundary
import REALOQS.Examples.TreeOfCliques_RealTower_FromDtNStabilized
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.PillarA.Update.TailEliminationDtN

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_ScaleAxisHarness

noncomputable section

open _root_.PillarA
open _root_.PillarA.Update
open _root_.PillarA.Physics

namespace ToC

open _root_.PillarA.LayerA

variable {b : Nat}

abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

noncomputable abbrev realTower (b : Nat) (p : Policy b) : ∀ k, S b k :=
  _root_.REALOQS.Examples.TreeOfCliques_RealTower_FromDtNStabilized.ToC.realTower
    (b := b) (p := p)

noncomputable def Obs (b : Nat) : OpObserverD (S b) (α b) := by
  classical
  refine { op := ?_ }
  intro k M
  exact _root_.PillarA.Update.linOpOfMatrix (α := α b k) M

noncomputable def M (b : Nat) : ∀ k, MismatchFunctional (α := α b k) := by
  classical
  intro k
  exact _root_.PillarA.Update.MismatchFunctional.NormDiff.mkId (α := α b k)

def axis0
    (p : Policy b)
    (coarsen : ∀ k, S b (k + 1) → S b k)
    (ideal : ∀ k, S b k) :
    ScaleBreakingAxisD (S b) :=
  { coarsen := coarsen
    , ideal := ideal
    , real := realTower (b := b) (p := p)
    , breakMeasure := fun _ => 0
    , breakMeasureIdeal := fun _ => 0 }

noncomputable def axis
    (p : Policy b)
    (coarsen : ∀ k, S b (k + 1) → S b k)
    (ideal : ∀ k, S b k)
    (eps : ℝ) (eps_pos : eps > 0) :
    ScaleBreakingAxisD (S b) :=
  axis_fromMismatchD
    (S := S b) (α := α b)
    (A := axis0 (b := b) p coarsen ideal)
    (Obs := Obs b)
    (M := M b)
    (eps := eps) (eps_pos := eps_pos)

noncomputable abbrev coarsenCanonical (b : Nat) : ∀ k, S b (k + 1) → S b k :=
  fun k =>
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat (b := b) (k := k)

noncomputable abbrev idealCanonical (b : Nat) : ∀ k, S b k :=
  _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.idealTower (b := b)

noncomputable def axis_canonical
    (p : Policy b) :
    ScaleBreakingAxisD (S b) :=
  axis
    (b := b) (p := p)
    (coarsen := coarsenCanonical (b := b))
    (ideal := idealCanonical (b := b))
    (eps := p.eps) (eps_pos := p.eps_pos)

end ToC

end
end TreeOfCliques_ScaleAxisHarness
end Examples
end REALOQS
