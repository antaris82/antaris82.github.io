import Mathlib
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_RealTower_FromDtNStabilized

noncomputable section

namespace ToC

open _root_.PillarA

variable {b : Nat}

abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

noncomputable def realTower (p : _root_.PillarA.LayerA.Policy b) : ∀ k, S b k :=
  fun k =>
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) (k := k)

end ToC

end
end TreeOfCliques_RealTower_FromDtNStabilized
end Examples
end REALOQS
