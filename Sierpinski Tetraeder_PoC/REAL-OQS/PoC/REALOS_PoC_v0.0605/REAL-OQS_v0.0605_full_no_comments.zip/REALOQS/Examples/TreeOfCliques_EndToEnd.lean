import Mathlib
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNSemantics

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_EndToEnd

noncomputable section

namespace ToC

open _root_.PillarA.LayerA

variable {b : Nat} (p : _root_.PillarA.LayerA.Policy b)

abbrev A : _root_.PillarA.Update.TwoStageApprox.{0} b :=
  _root_.PillarA.Update.Instances.TreeOfCliquesApprox.mk (b := b) p

abbrev Sem :
    _root_.PillarA.Update.TailElimDtNSemantics (A := A (p := p)) :=
  _root_.PillarA.Update.Instances.TreeOfCliquesDtNSemantics.mk (b := b) p

abbrev State : Type := (A (p := p)).S

abbrev Boundary : Type := (Sem (p := p)).split.B

abbrev BoundaryOp (st : State (p := p)) : Matrix (Boundary (p := p)) (Boundary (p := p)) ℝ :=
  (Sem (p := p)).boundaryOp st

theorem boundaryOp_eq_blockBB (st : State (p := p)) :
    (Sem (p := p)).boundaryOp st = (Sem (p := p)).split.blockBB ((Sem (p := p)).L st) := by
  simpa using (Sem (p := p)).boundaryOp_def st

theorem stage1_boundaryOp_eq_DtN (st : State (p := p)) :
    (Sem (p := p)).boundaryOp ((A (p := p)).stage1 st) =
      (Sem (p := p)).split.DtN_of ((Sem (p := p)).L st) ((Sem (p := p)).inv st) := by
  simpa using (Sem (p := p)).stage1_boundaryOp_eq_DtN st

end ToC

end
end TreeOfCliques_EndToEnd
end Examples
end REALOQS
