import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
import REALOQS.PillarB.AQFT.Derived.QuasiLocalStateFromConfigNet

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_AQFT_Derived

noncomputable section

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
open _root_.PillarB.AQFT.Derived

variable {b : Nat}

abbrev Ω (p : _root_.PillarA.LayerA.Policy b) : Type :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.V (p := p)

namespace ToC

variable (p : _root_.PillarA.LayerA.Policy b)

instance : Fintype (Ω (p := p)) := by
  infer_instance

instance : DecidableEq (Ω (p := p)) := by
  classical
  exact Classical.decEq _

variable (d : Nat)

variable (σ0 : Cfg (Ω := Ω (p := p)) d (Finset.univ : Finset (Ω (p := p))))

abbrev LSAN_ToC : _root_.PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω (p := p)) :=
  localStarAlgebraNet (Ω := Ω (p := p)) d

abbrev SN_ToC : _root_.PillarA.LayerA.StateNet (Ω := Ω (p := p)) :=
  stateNet (Ω := Ω (p := p)) d

abbrev Cone_ToC :
    _root_.PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω (p := p)) d) :=
  globalCone (Ω := Ω (p := p)) d σ0

def Φ_ToC (p : _root_.PillarA.LayerA.Policy b) (d : Nat)
    (σ0 : Cfg (Ω := Ω (b := b) p) d (Finset.univ : Finset (Ω (b := b) p))) :
    _root_.PillarB.AQFT.StateOn
      (_root_.PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω (b := b) p)
        (N := localStarAlgebraNet (Ω := Ω (b := b) p) d)) :=
  quasiLocalState (Ω := Ω (b := b) p) d σ0

example :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω (p := p))
        (N := localStarAlgebraNet (Ω := Ω (p := p)) d) (Φ_ToC (b := b) p d σ0)
        (Finset.univ : Finset (Ω (p := p))) =
      (globalConeQL (Ω := Ω (p := p)) d σ0).ω
        (Finset.univ : Finset (Ω (p := p))) := by
  simpa [Φ_ToC] using
    (_root_.PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω (p := p)) (N := localStarAlgebraNet (Ω := Ω (p := p)) d)
      (C := globalConeQL (Ω := Ω (p := p)) d σ0)
      (r := (Finset.univ : Finset (Ω (p := p)))))

end ToC

end

end TreeOfCliques_AQFT_Derived
end Examples
end REALOQS
