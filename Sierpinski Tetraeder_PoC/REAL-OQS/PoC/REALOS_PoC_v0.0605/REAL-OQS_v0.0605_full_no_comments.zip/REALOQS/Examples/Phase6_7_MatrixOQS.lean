import REALOQS.PillarB.Examples.FiniteMatrix
import REALOQS.PillarC.Examples.KrausChannel

set_option autoImplicit false

namespace REALOQS
namespace Examples

namespace Phase6_7

noncomputable section

abbrev Mat2 := PillarC.Examples.Kraus.Mat 2

def demoLSAN : PillarB.AQFT.LocalStarAlgebraNet (Ω := Fin 3) :=
  PillarB.Examples.FiniteMatrix.LSAN 3 2

def demoIdCPTP : PillarC.OQS.CPTPChannel Mat2 Mat2 :=
  PillarC.Examples.Kraus.idChannelCPTP 2

def demoDephaseCPTP : PillarC.OQS.CPTPChannel Mat2 Mat2 :=
  PillarC.Examples.Kraus.Qubit.dephaseCPTP

theorem demoIdCPTP_isCP : demoIdCPTP.isCP := by
  simpa [demoIdCPTP] using PillarC.Examples.Kraus.idChannelCPTP_isCP 2

theorem demoIdCPTP_isTP : demoIdCPTP.isTP := by
  simpa [demoIdCPTP] using PillarC.Examples.Kraus.idChannelCPTP_isTP 2

theorem demoDephaseCPTP_isCP : demoDephaseCPTP.isCP := by
  simpa [demoDephaseCPTP] using PillarC.Examples.Kraus.Qubit.dephaseCPTP_isCP

theorem demoDephaseCPTP_isTP : demoDephaseCPTP.isTP := by
  simpa [demoDephaseCPTP] using PillarC.Examples.Kraus.Qubit.dephaseCPTP_isTP

end

end Phase6_7

end Examples
end REALOQS
