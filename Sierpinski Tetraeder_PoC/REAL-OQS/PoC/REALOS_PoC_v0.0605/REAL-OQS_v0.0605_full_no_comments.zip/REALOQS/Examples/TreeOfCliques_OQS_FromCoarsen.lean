import Mathlib
import REALOQS.Examples.TreeOfCliques_CoarsenBoundary
import REALOQS.PillarC.OQS.Channel
import REALOQS.PillarC.OQS.Finite.RectKraus
import REALOQS.PillarC.OQS.Stinespring

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_OQS_FromCoarsen

noncomputable section

open scoped BigOperators

namespace ToC

open REALOQS.Examples.TreeOfCliques_CoarsenBoundary.ToC

variable {b k : Nat}

abbrev Mat (α : Type) := _root_.PillarC.OQS.Finite.RectKraus.Mat α

abbrev RectMat (α β : Type) := _root_.PillarC.OQS.Finite.RectKraus.RectMat α β

abbrev RectKrausOps (α β : Type) (r : Nat) :=
  _root_.PillarC.OQS.Finite.RectKraus.RectKrausOps α β r

abbrev rectKrausMap
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Mat β → Mat α :=
  _root_.PillarC.OQS.Finite.RectKraus.rectKrausMap (α := α) (β := β) r K

abbrev RectKrausTP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Prop :=
  _root_.PillarC.OQS.Finite.RectKraus.RectKrausTP (α := α) (β := β) r K

abbrev IsRectKrausCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (Φ : Mat β → Mat α) : Prop :=
  _root_.PillarC.OQS.Finite.RectKraus.IsRectKrausCP (α := α) (β := β) r Φ

abbrev rectKrausChannel
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    _root_.PillarC.OQS.CPTPChannel (Mat β) (Mat α) :=
  _root_.PillarC.OQS.Finite.RectKraus.rectKrausChannel (α := α) (β := β) r K

theorem rectKrausChannel_isCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    (rectKrausChannel (α := α) (β := β) r K).isCP := by
  simpa [rectKrausChannel] using
    (_root_.PillarC.OQS.Finite.RectKraus.rectKrausChannel_isCP (α := α) (β := β) r K)

def ptraceKraus (b k : Nat) :
    RectKrausOps (Boundary b k) (Boundary b (k + 1)) b :=
  fun d =>
    fun i x => if x = mkChild b k i d then (1 : Complex) else 0

def ptraceMap (b k : Nat) :
    Mat (Boundary b (k + 1)) → Mat (Boundary b k) :=
  rectKrausMap (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k)

def ptraceCPTP (b k : Nat) :
    _root_.PillarC.OQS.CPTPChannel (Mat (Boundary b (k + 1))) (Mat (Boundary b k)) :=
  rectKrausChannel (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k)

theorem ptraceCPTP_isCP (b k : Nat) : (ptraceCPTP b k).isCP := by
  change IsRectKrausCP (α := Boundary b k) (β := Boundary b (k + 1)) b
      (rectKrausMap (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k))
  exact ⟨ptraceKraus b k, rfl⟩

def stinespring_ptrace (b k : Nat) (hb : 0 < b) :
    _root_.PillarC.OQS.StinespringDilation (ptraceCPTP b k) := by
  let Φ := ptraceCPTP b k
  refine
    { E := Fin b
      V := fun ρ => (Φ.map ρ, ⟨0, hb⟩)
      discard := fun be => be.1
      dilationEq :=
        ∀ ρ : Mat (Boundary b (k + 1)),
          (fun be : Mat (Boundary b k) × Fin b => be.1) (Φ.map ρ, ⟨0, hb⟩) = Φ.map ρ }

theorem hasStinespring_ptrace (b k : Nat) (hb : 0 < b) :
    _root_.PillarC.OQS.HasStinespring (ptraceCPTP b k) := by
  exact ⟨stinespring_ptrace (b := b) (k := k) hb⟩

end ToC

end

end TreeOfCliques_OQS_FromCoarsen
end Examples
end REALOQS
