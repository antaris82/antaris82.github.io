import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveDynamics
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixRichNetNonAdditive
import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesBoundaryK1Shape


set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

universe u

namespace TreeOfCliquesFromPillarA
namespace ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

/-- Canonical observable-ball generator in the rich top algebra, obtained by
including the ball algebra of `boundaryBallFromL L i` into the top fiber. -/
def observableBallGenerator_ToC
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RichTopAlg (b := b) (p := p) :=
  topBasisGenerator_ToC (b := b) (p := p)
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    A

/-- Time-transported image of the canonical observable-ball generator. -/
def dynImageObservableBallGenerator_ToC
    (t : ℝ)
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RichTopAlg (b := b) (p := p) :=
  dynImageTopBasisGenerator_ToC (b := b) (p := p) t
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    A

@[simp] theorem observableBallGenerator_mem_observableTopCarrier_ToC
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    observableBallGenerator_ToC (b := b) (p := p) i A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact topBasisGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p)
    (B_ToC_basic_ball (b := b) (p := p) i) A

@[simp] theorem observableBallGenerator_ToC_toMatrix
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionBlockMat.toMatrix
        (observableBallGenerator_ToC (b := b) (p := p) i A) =
      RegionBlockMat.toMatrix A := by
  exact topBasisGenerator_ToC_toMatrix (b := b) (p := p)
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    A

@[simp] theorem dynImageObservableBallGenerator_ToC_toMatrix
    (t : ℝ)
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionBlockMat.toMatrix
        (dynImageObservableBallGenerator_ToC (b := b) (p := p) t i A) =
      (fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq
          (b := b) p)).α t
          (RegionBlockMat.toMatrix A) := by
  exact dynImageTopBasisGenerator_ToC_toMatrix (b := b) (p := p) t
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    A

/-- Strong positive D2d test predicate: every canonical observable-ball
generator stays inside the observable top carrier under the rich top dynamics. -/
def dyn_top_ToC_preserves_observableBallGenerators : Prop :=
  ∀ (t : ℝ) (i : Ω (b := b) (p := p))
      (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)),
    dynImageObservableBallGenerator_ToC (b := b) (p := p) t i A ∈
      observableTopCarrier_ToC (b := b) (p := p)

/-- Repackaging of the existing D2c reduction in terms of the canonical
observable-ball generators. -/
theorem dyn_top_ToC_preserves_observableBallGenerators_of_sameBallLocalization
    (hball : dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_observableBallGenerators (b := b) (p := p) := by
  intro t i A
  have hloc : RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      ((fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq
          (b := b) p)).α t
          (RegionBlockMat.toMatrix A)) := by
    have hloc' := hball t i
      (h := _root_.PillarA.LayerA.RegionNet.le_top'
        (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i))
      A
    simpa only [dynImageTopBasisGenerator_ToC_toMatrix] using hloc'
  exact dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_basic_ball_regionLocalized
    (b := b) (p := p) t
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    i A hloc

/-- Canonical ball-generator preservation already suffices for the full D2
preservation statement by the existing generator reduction. -/
theorem dyn_top_ToC_preserves_N_add_top_of_preserves_observableBallGenerators
    (hball : dyn_top_ToC_preserves_observableBallGenerators
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  refine dyn_top_ToC_preserves_N_add_top_of_preserves_basisGenerators
    (b := b) (p := p) ?_
  intro t A hA
  rcases hA with ⟨u, hu, hle, x, rfl⟩
  rcases basic_region_eq_boundaryBallFromL (b := b) (p := p) hu with ⟨i, rfl⟩
  simpa only [dynImageObservableBallGenerator_ToC, observableBallGenerator_ToC,
    dynImageTopBasisGenerator_ToC, topBasisGenerator_ToC] using hball t i x

/-- Direct negative D2d witness: one transported observable-ball generator
lands outside the observable top carrier.  This is strong enough to refute the
full preservation claim. -/
def observableDynEscapeWitness : Prop :=
  ∃ (t : ℝ) (i : Ω (b := b) (p := p))
      (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)),
    dynImageObservableBallGenerator_ToC (b := b) (p := p) t i A ∉
      observableTopCarrier_ToC (b := b) (p := p)

/-- A direct escape witness immediately decides D2d negatively. -/
theorem observableDynEscapeWitness_not_preserves_N_add_top
    (hw : observableDynEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  rintro hpres
  rcases hw with ⟨t, i, A, hw⟩
  have hmem : observableBallGenerator_ToC (b := b) (p := p) i A ∈
      observableTopCarrier_ToC (b := b) (p := p) :=
    observableBallGenerator_mem_observableTopCarrier_ToC (b := b) (p := p) i A
  exact hw (by
    simpa only [dynImageObservableBallGenerator_ToC, observableBallGenerator_ToC,
      dynImageTopBasisGenerator_ToC, topBasisGenerator_ToC] using (hpres t hmem))

/-- Explicit D2d negative reduction: it already suffices to exhibit one single
transported canonical observable-ball generator whose image leaves the
observable top carrier. -/
theorem dyn_top_ToC_not_preserves_N_add_top_of_generator_escape
    (t : ℝ)
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    (hescape : dynImageObservableBallGenerator_ToC (b := b) (p := p) t i A ∉
      observableTopCarrier_ToC (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact observableDynEscapeWitness_not_preserves_N_add_top
    (b := b) (p := p) ⟨t, i, A, hescape⟩

/-- Re-export of the direct witness reduction under the final D2d target name. -/
theorem dyn_top_ToC_not_preserves_N_add_top_of_escapeWitness
    (hw : observableDynEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact observableDynEscapeWitness_not_preserves_N_add_top
    (b := b) (p := p) hw

/-- Weaker negative-first test: failure of same-ball localization for one
canonical ball generator.  This does **not** yet refute D2d itself; it only
refutes the stronger D2c same-ball localization Ansatz. -/
def observableDynSameBallLocalizationEscapeWitness : Prop :=
  ∃ (t : ℝ) (i : Ω (b := b) (p := p))
      (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)),
    ¬ RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageObservableBallGenerator_ToC (b := b) (p := p) t i A))

/-- A same-ball localization escape witness rules out the strong D2c
localization conjecture, but not the full D2d closure claim. -/
theorem observableDynSameBallLocalizationEscapeWitness_not_preserves
    (hw : observableDynSameBallLocalizationEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p) := by
  rintro hloc
  rcases hw with ⟨t, i, A, hw⟩
  have hloc' := hloc t i
    (h := _root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i))
    A
  exact hw (by
    simpa only [dynImageObservableBallGenerator_ToC] using hloc')

/-- If every canonical `L`-ball already equals the top region, then the top
region itself is a distinguished observable basis region. This isolates the
positive D2d mechanism independently of the special `L_max = 1` computation. -/
theorem B_ToC_basic_top_of_allBalls_eq_top
    (hball : ∀ i : Ω (b := b) (p := p),
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i =
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top) :
    (B_ToC (b := b) (p := p)).basic
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  classical
  let i : Ω (b := b) (p := p) :=
    Classical.choice (show Nonempty (Ω (b := b) (p := p)) from inferInstance)
  have hbasic :
      (B_ToC (b := b) (p := p)).basic
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i) :=
    B_ToC_basic_ball (b := b) (p := p) i
  rw [hball i] at hbasic
  exact hbasic

/-- Every rich top element is already observable whenever all canonical
`L`-balls coincide with the top region. -/
theorem mem_observableTopCarrier_ToC_of_allBalls_eq_top
    (hball : ∀ i : Ω (b := b) (p := p),
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i =
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact _root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveGenerated_of_basic
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (r := (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (B_ToC_basic_top_of_allBalls_eq_top (b := b) (p := p) hball) A

/-- Positive D2d criterion: if every canonical `L`-ball is already the whole top
region, then observable-top preservation is automatic. This is the exact bridge
needed for any future `L_max > 1` all-to-all coupling proof. -/
theorem dyn_top_ToC_preserves_N_add_top_of_allBalls_eq_top
    (hball : ∀ i : Ω (b := b) (p := p),
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i =
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro t A _hA
  exact mem_observableTopCarrier_ToC_of_allBalls_eq_top
    (b := b) (p := p) hball ((dyn_top_ToC (b := b) (p := p)).α t A)

/-- Sufficient condition for the previous criterion: if every off-diagonal entry
of the exported boundary operator is nonzero, then each canonical `L`-ball is
the whole top region. This is useful for extending the `L_max = 1` mechanism to
higher levels once the corresponding DtN shape lemmas are available. -/
theorem boundaryBallFromL_eq_top_of_offdiag_nonzero
    (hoff : ∀ ⦃x y : Ω (b := b) (p := p)⦄, x ≠ y →
      L (b := b) (p := p) x y ≠ 0)
    (i : Ω (b := b) (p := p)) :
    boundaryBallFromL (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p)) i =
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top := by
  let _ : Fact (0 < b) := ‹Fact (0 < b)›
  exact Finset.ext (fun j => Iff.intro
    (fun _ => by
      change j ∈ (Finset.univ : Finset (Ω (b := b) (p := p)))
      exact Finset.mem_univ j)
    (fun _ => by
      by_cases hji : j = i
      · exact (mem_boundaryBallFromL_iff (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i j).2 (Or.inl hji.symm)
      · have hij : i ≠ j := by
          intro hijEq
          exact hji hijEq.symm
        have hoff' : L (b := b) (p := p) i j ≠ 0 := hoff hij
        exact (mem_boundaryBallFromL_iff (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i j).2 (Or.inr (Or.inl hoff'))))

/-- Off-diagonal nonvanishing is therefore already enough for a positive D2d
closure statement, uniformly in `L_max`. -/
theorem dyn_top_ToC_preserves_N_add_top_of_offdiag_nonzero
    (hoff : ∀ ⦃x y : Ω (b := b) (p := p)⦄, x ≠ y →
      L (b := b) (p := p) x y ≠ 0) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_allBalls_eq_top
    (b := b) (p := p)
    (fun i => boundaryBallFromL_eq_top_of_offdiag_nonzero
      (b := b) (p := p) hoff i)


/-- For the concrete ToC handoff at `L_max = 1`, every off-diagonal entry of
the exported boundary operator is nonzero. Hence every canonical `L`-ball is the
entire top region. -/
theorem L_offdiag_ne_zero_of_Lmax_eq_one
    (hL : p.L_max = 1)
    {x y : Ω (b := b) (p := p)}
    (hxy : x ≠ y) :
    L (b := b) (p := p) x y ≠ 0 := by
  rcases p with ⟨Lmax⟩
  cases hL
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p1)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.OQS.Split.DtNStabilized.symm
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (s1.blockII L1))
  let Schur :
      Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
        (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) ℝ :=
    s1.blockBI L1 *
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p1) 1)⁻¹ *
      s1.blockIB L1
  have hreduce :=
    _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.reduce_LBB_eq_dtn_stab
      (b := b) (p := p1)
  have hentry :
      L (b := b) (p := p1) x y =
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p1) 1) x y := by
    simpa [p1, L, _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L,
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.st1,
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.st0,
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized] using
      congrArg (fun M => M x y) hreduce
  have hdtn :
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
        (b := b) (p := p1) 1) x y
        = (-1 : ℝ) - ((b : ℝ) + δ)⁻¹ := by
    calc
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
        (b := b) (p := p1) 1) x y
          = s1.blockBB L1 x y - Schur x y := by
              simp [_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized,
                _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
                _root_.PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
                _root_.PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
                _root_.PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
                _root_.PillarA.OQS.Split.DtNStabilized.LII_stabilized,
                _root_.PillarA.LayerA.DtN,
                Schur, L1, s1, Matrix.sub_apply]
      _ = (-1 : ℝ) - ((b : ℝ) + δ)⁻¹ := by
            have hSchur : Schur x y = ((b : ℝ) + δ)⁻¹ := by
              simpa [Schur, δ, L1, s1] using
                (_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.schur_entry_const_k1
                  (b := b) (p := p1) x y)
            rw [_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.blockBB_k1_offdiag_eq_neg_one
                  (b := b) x y hxy,
              hSchur]
  have hbR : 0 < (b : ℝ) := by
    exact_mod_cast (Fact.out : 0 < b)
  have hδpos : 0 < δ := by
    simpa [δ] using
      (_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.delta_pos_k1
        (b := b) (p := p1))
  have hsumPos : 0 < (b : ℝ) + δ := add_pos hbR hδpos
  have hne_rhs : (-1 : ℝ) - ((b : ℝ) + δ)⁻¹ ≠ 0 := by
    have hinvPos : 0 < ((b : ℝ) + δ)⁻¹ := inv_pos.mpr hsumPos
    linarith
  intro hzero
  apply hne_rhs
  rw [← hdtn, ← hentry, hzero]

/-- At `L_max = 1`, every canonical `L`-ball on the active ToC handoff path is
the whole top region. -/
theorem boundaryBallFromL_eq_top_of_Lmax_eq_one
    (hL : p.L_max = 1)
    (i : Ω (b := b) (p := p)) :
    boundaryBallFromL (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p)) i =
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top := by
  ext j
  constructor
  · intro _
    change j ∈ (Finset.univ : Finset (Ω (b := b) (p := p)))
    exact Finset.mem_univ j
  · intro _
    by_cases hji : j = i
    · exact (mem_boundaryBallFromL_iff (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i j).2 (Or.inl hji.symm)
    · have hij : i ≠ j := by simpa [eq_comm] using hji
      have hoff : L (b := b) (p := p) i j ≠ 0 :=
        L_offdiag_ne_zero_of_Lmax_eq_one (b := b) (p := p) hL hij
      exact (mem_boundaryBallFromL_iff (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i j).2 (Or.inr (Or.inl hoff))

/-- Consequently, the top region itself is a distinguished observable basis
region on the active ToC path when `L_max = 1`. -/
theorem B_ToC_basic_top_of_Lmax_eq_one
    (hL : p.L_max = 1) :
    (B_ToC (b := b) (p := p)).basic
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  classical
  let i : Ω (b := b) (p := p) :=
    Classical.choice (show Nonempty (Ω (b := b) (p := p)) from inferInstance)
  have hbasic :
      (B_ToC (b := b) (p := p)).basic
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i) :=
    B_ToC_basic_ball (b := b) (p := p) i
  rw [boundaryBallFromL_eq_top_of_Lmax_eq_one (b := b) (p := p) hL i] at hbasic
  exact hbasic

/-- Hence the observable top carrier coincides with the full rich top carrier in
the `L_max = 1` case. -/
theorem mem_observableTopCarrier_ToC_of_Lmax_eq_one
    (hL : p.L_max = 1)
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact _root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveGenerated_of_basic
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (r := (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (B_ToC_basic_top_of_Lmax_eq_one (b := b) (p := p) hL) A

/-- Concrete positive D2d result at `L_max = 1`: the observable top carrier is
trivially preserved because it already equals the full rich top carrier. -/
theorem dyn_top_ToC_preserves_N_add_top_of_Lmax_eq_one
    (hL : p.L_max = 1) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_offdiag_nonzero
    (b := b) (p := p)
    (fun {x y} hxy => L_offdiag_ne_zero_of_Lmax_eq_one
      (b := b) (p := p) hL hxy)

/-- `k=2` reduction step: if a level-2 boundary matrix is constant on each
cross-parent fiber block and coarsens to a level-1 matrix with nonzero
off-diagonal entry at `(i,j)`, then every level-2 entry over the corresponding
fiber block is already nonzero. This isolates the concrete `L_max > 1`
cross-parent problem from the AQFT-side D2d closure logic. -/
theorem boundary2_crossParent_entry_ne_zero_of_coarsen_eq
    (A1 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
      (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) ℝ)
    (M2 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2)
      (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2) ℝ)
    (hconst : ∀ ⦃x y x' y' : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2⦄,
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
              _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
            M2 x y = M2 x' y')
    (hcoarsen :
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1 M2 = A1)
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j)
    (hA : A1 i j ≠ 0) :
    M2 x y ≠ 0 := by
  classical
  let _ : Fact (0 < b) := ‹Fact (0 < b)›
  let Fi := _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber b 1 i
  let Fj := _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber b 1 j
  have hFi_card : Fi.card = b := by
    dsimp [Fi]
    simpa using _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber_card b 1 i
  have hFj_card : Fj.card = b := by
    dsimp [Fj]
    simpa using _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber_card b 1 j
  have hcross :
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y := by
    intro hxy
    apply hij
    calc
      i = _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x := hx.symm
      _ = _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y := hxy
      _ = j := hy
  have hconstFib : ∀ x' ∈ Fi, ∀ y' ∈ Fj, M2 x' y' = M2 x y := by
    intro x' hx' y' hy'
    have hx'π : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' = i := by
      have hx'' : x' ∈ _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber b 1 i := by
        simpa [Fi] using hx'
      exact (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.mem_fiber_iff b 1 i x').1 hx''
    have hy'π : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' = j := by
      have hy'' : y' ∈ _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.fiber b 1 j := by
        simpa [Fj] using hy'
      exact (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.mem_fiber_iff b 1 j y').1 hy''
    have hxx' : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' := by
      rw [hx, hx'π]
    have hyy' : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' := by
      rw [hy, hy'π]
    exact (hconst hcross hxx' hyy').symm
  have hsumFj : ∀ x' ∈ Fi,
      Fj.sum (fun y' => M2 x' y') = (Fj.card : ℝ) * M2 x y := by
    intro x' hx'
    calc
      Fj.sum (fun y' => M2 x' y') = Fj.sum (fun _ => M2 x y) := by
        refine Finset.sum_congr rfl ?_
        intro y' hy'
        exact hconstFib x' hx' y' hy'
      _ = (Fj.card : ℝ) * M2 x y := by
        simp [Finset.sum_const, nsmul_eq_mul]
  have hsumFi :
      Fi.sum (fun x' => Fj.sum (fun y' => M2 x' y')) =
        (Fi.card : ℝ) * ((Fj.card : ℝ) * M2 x y) := by
    calc
      Fi.sum (fun x' => Fj.sum (fun y' => M2 x' y')) =
          Fi.sum (fun _ => (Fj.card : ℝ) * M2 x y) := by
            refine Finset.sum_congr rfl ?_
            intro x' hx'
            exact hsumFj x' hx'
      _ = (Fi.card : ℝ) * ((Fj.card : ℝ) * M2 x y) := by
        simp [Finset.sum_const, nsmul_eq_mul]
  have hcoarsen_entry :
      (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1 M2) i j = A1 i j := by
    simpa using congrArg (fun N => N i j) hcoarsen
  have hentry : A1 i j = (b : ℝ) * ((b : ℝ) * M2 x y) := by
    calc
      A1 i j = (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1 M2) i j := by
        exact hcoarsen_entry.symm
      _ = Fi.sum (fun x' => Fj.sum (fun y' => M2 x' y')) := by
        simp [_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat, Fi, Fj]
      _ = (Fi.card : ℝ) * ((Fj.card : ℝ) * M2 x y) := hsumFi
      _ = (b : ℝ) * ((b : ℝ) * M2 x y) := by simp [hFi_card, hFj_card]
  intro hzero
  apply hA
  rw [hentry, hzero]
  ring

/-- Concrete `k=2` reduction toward the active ToC handoff: if the level-2
boundary operator coarsens to the already understood `k=1` handoff operator and
is constant on each cross-parent fiber block, then every cross-parent level-2
off-diagonal entry is nonzero. -/
theorem boundary2_crossParent_entry_ne_zero_of_coarsen_eq_handoff_k1
    (M2 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2)
      (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2) ℝ)
    (hconst : ∀ ⦃x y x' y' : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2⦄,
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
              _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
            M2 x y = M2 x' y')
    (hcoarsen : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1 M2 =
      L (b := b) (p := ({ L_max := 1 } : _root_.PillarA.LayerA.Policy b)))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    M2 x y ≠ 0 := by
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  apply boundary2_crossParent_entry_ne_zero_of_coarsen_eq
    (b := b)
    (A1 := L (b := b) (p := p1))
    (M2 := M2)
    hconst hcoarsen hij hx hy
  exact L_offdiag_ne_zero_of_Lmax_eq_one (b := b) (p := p1) rfl hij

/-- Under the same concrete `k=2` hypotheses, every cross-parent level-2
boundary point already lies in the canonical `L`-ball.  This is the first
direct ball-membership reduction for the `L_max > 1` path. -/
theorem boundaryBall_boundary2_contains_crossParent_of_coarsen_eq_handoff_k1
    (M2 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2)
      (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 2) ℝ)
    (hconst : ∀ ⦃x y x' y' : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2⦄,
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
              _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
            M2 x y = M2 x' y')
    (hcoarsen : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1 M2 =
      L (b := b) (p := ({ L_max := 1 } : _root_.PillarA.LayerA.Policy b)))
    {x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2)
      (L := M2) x := by
  let i := _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x
  let j := _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y
  have hentry : M2 x y ≠ 0 :=
    boundary2_crossParent_entry_ne_zero_of_coarsen_eq_handoff_k1
      (b := b) (M2 := M2) hconst hcoarsen (i := i) (j := j) hxy rfl rfl
  exact (mem_boundaryBallFromL_iff
    (Ω := _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2)
    (L := M2) x y).2 (Or.inr (Or.inl hentry))



/-- Concrete target predicate for the real `L_max = 2` ToC handoff: the exported
boundary operator is constant on each cross-parent `π₁`-fiber block.  This is
exactly the symmetry input needed by the first nontrivial `L > 1` positive
reduction. -/
def handoff_Lmax_eq_two_crossParentBlockConstant : Prop :=
  let p2 : _root_.PillarA.LayerA.Policy b := { L_max := 2 }
  ∀ ⦃x y x' y' : Ω (b := b) (p := p2)⦄,
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
          L (b := b) (p := p2) x y = L (b := b) (p := p2) x' y'

/-- Concrete target predicate for the real `L_max = 2` ToC handoff: after
canonical boundary coarsening from level `2` to level `1`, the exported
boundary operator agrees with the already-understood `k=1` handoff operator. -/
def handoff_Lmax_eq_two_coarsens_to_handoff_k1 : Prop :=
  let p2 : _root_.PillarA.LayerA.Policy b := { L_max := 2 }
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1
      (L (b := b) (p := p2)) =
    L (b := b) (p := p1)

/-- First real `L > 1` handoff attachment point: under the two concrete level-2
hypotheses on the **actual** exported ToC handoff operator, every cross-parent
level-2 off-diagonal entry is nonzero. -/
theorem handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  have hconst' :
      ∀ ⦃x y x' y' : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2⦄,
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
              _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
                _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
              L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y =
                L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x' y' :=
    hconst
  have hcoarsen' :
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1
          (L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) =
        L (b := b) (p := ({ L_max := 1 } : _root_.PillarA.LayerA.Policy b)) :=
    hcoarsen
  exact boundary2_crossParent_entry_ne_zero_of_coarsen_eq_handoff_k1
    (b := b)
    (M2 := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    hconst' hcoarsen' hij hx hy

/-- Corresponding ball-membership statement on the **real** `L_max = 2` handoff:
under the same two concrete hypotheses, every cross-parent level-2 point already
lies in the canonical `L`-ball of the center. -/
theorem handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  have hconst' :
      ∀ ⦃x y x' y' : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 2⦄,
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y →
          _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
              _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x' →
            _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
                _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y' →
              L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y =
                L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x' y' :=
    hconst
  have hcoarsen' :
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1
          (L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) =
        L (b := b) (p := ({ L_max := 1 } : _root_.PillarA.LayerA.Policy b)) :=
    hcoarsen
  exact boundaryBall_boundary2_contains_crossParent_of_coarsen_eq_handoff_k1
    (b := b)
    (M2 := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    hconst' hcoarsen' hxy



/-- Stronger concrete `L > 1` handoff target: the real exported `L_max = 2`
boundary operator is exactly the canonical fiberwise refinement of the already
understood `k=1` handoff operator.  This single statement subsumes both the
coarsening target and the cross-parent block-constancy target. -/
def handoff_Lmax_eq_two_refines_handoff_k1 : Prop :=
  let p2 : _root_.PillarA.LayerA.Policy b := { L_max := 2 }
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  L (b := b) (p := p2) =
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
      (L (b := b) (p := p1))

/-- The refinement target automatically implies the concrete level-2-to-level-1
coarsening target on the real exported handoff operator. -/
theorem handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) := by
  have hb : 0 < b := Fact.out
  let p2 : _root_.PillarA.LayerA.Policy b := { L_max := 2 }
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  have href' :
      L (b := b) (p := p2) =
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
          (L (b := b) (p := p1)) :=
    href
  calc
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1
        (L (b := b) (p := p2))
        = _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 1
            (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
              (L (b := b) (p := p1))) := by
              rw [href']
    _ = L (b := b) (p := p1) := by
          exact _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat_refineMat
            b 1 hb (L (b := b) (p := p1))

/-- Strong form of the level-2 refinement consequence: the real exported
`L_max = 2` handoff operator is constant on every `π₁`-fiber block, without
needing to separate cross-parent from same-parent cases. -/
theorem handoff_Lmax_eq_two_blockConstant_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {x y x' y' : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x =
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x')
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y =
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y') :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y =
      L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x' y' := by
  let _ : Fact (0 < b) := ‹Fact (0 < b)›
  let p2 : _root_.PillarA.LayerA.Policy b := { L_max := 2 }
  let p1 : _root_.PillarA.LayerA.Policy b := { L_max := 1 }
  have href' :
      L (b := b) (p := p2) =
        _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
          (L (b := b) (p := p1)) :=
    href
  calc
    L (b := b) (p := p2) x y =
        (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
          (L (b := b) (p := p1))) x y := by
            rw [href']
    _ = (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.refineMat b 1
          (L (b := b) (p := p1))) x' y' := by
            change
              L (b := b) (p := p1)
                  (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x)
                  (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) / ((b : ℝ) ^ 2)
                =
              L (b := b) (p := p1)
                  (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x')
                  (_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y') / ((b : ℝ) ^ 2)
            rw [hx, hy]
    _ = L (b := b) (p := p2) x' y' := by
            rw [href']

/-- Hence the stronger refinement target implies the cross-parent block
constancy predicate used by the first `k=2` positive reduction. -/
theorem handoff_Lmax_eq_two_crossParentBlockConstant_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_crossParentBlockConstant (b := b) := by
  intro x y x' y' _hcross hx hy
  exact handoff_Lmax_eq_two_blockConstant_of_refine (b := b) href hx hy

/-- Under the stronger refinement target, every cross-parent level-2 entry of
the real exported handoff operator is nonzero. -/
theorem handoff_Lmax_eq_two_crossParent_entry_ne_zero_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  exact handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (b := b)
    (handoff_Lmax_eq_two_crossParentBlockConstant_of_refine (b := b) href)
    (handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine (b := b) href)
    hij hx hy

/-- Likewise, the stronger refinement target already yields the first concrete
`k=2` ball-membership consequence on the real exported handoff operator. -/
theorem handoff_Lmax_eq_two_boundaryBall_contains_crossParent_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  exact handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (b := b)
    (handoff_Lmax_eq_two_crossParentBlockConstant_of_refine (b := b) href)
    (handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine (b := b) href)
    hxy

section

/-- If a point already lies in the canonical `L`-ball around `x`, then the
two-point region `{x,y}` is contained in that ball. This packages the minimal
region witness needed to inject the pair off-diagonal matrix unit into the
canonical ball algebra. -/
omit [Fact (0 < b)] in
theorem pairRegion_le_boundaryBallFromL_of_mem
    {x y : Ω (b := b) (p := p)}
    (hy : y ∈ boundaryBallFromL (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p)) x) :
    _root_.PillarB.AQFT.Derived.pairRegion (Ω := Ω (b := b) (p := p)) x y ≤
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) x := by
  intro z hz
  rw [_root_.PillarB.AQFT.Derived.mem_pairRegion
    (Ω := Ω (b := b) (p := p)) (i := x) (j := y) (k := z)] at hz
  cases hz with
  | inl hzx =>
      subst hzx
      rw [mem_boundaryBallFromL_iff]
      exact Or.inl rfl
  | inr hzy =>
      subst hzy
      exact hy

/-- Canonical local off-diagonal witness inside the `L_max = 2` ball centered at
`x`, obtained by including the pair matrix unit `(x,y)` into the corresponding
ball algebra once `y` lies in that ball. -/
noncomputable def observableBallPairWitness_Lmax2
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :
    (N_rich_ToC (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))).LAN.Alg
      (boundaryBallFromL
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :=
  (N_rich_ToC (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))).LAN.incl
    (pairRegion_le_boundaryBallFromL_of_mem
      (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) hy)
    (_root_.PillarB.AQFT.Derived.pairOffDiagWitness
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x y)

/-- The associated canonical observable-ball generator at `L_max = 2`. -/
noncomputable def observableBallGenerator_Lmax2_pair
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :
    RichTopAlg (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) :=
  observableBallGenerator_ToC
    (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x
    (observableBallPairWitness_Lmax2 (b := b) x y hy)

omit [Fact (0 < b)] in
theorem observableBallPairWitness_Lmax2_toMatrix
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :
    RegionBlockMat.toMatrix
      (observableBallPairWitness_Lmax2 (b := b) x y hy) =
      _root_.PillarB.AQFT.Derived.boundaryMatrixUnit
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x y := by
  rw [observableBallPairWitness_Lmax2]
  rw [boundaryMatrixLocalNet_incl_toMatrix]
  rw [_root_.PillarB.AQFT.Derived.pairOffDiagWitness_toMatrix]

theorem observableBallGenerator_Lmax2_pair_toMatrix
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :
    RegionBlockMat.toMatrix
      (observableBallGenerator_Lmax2_pair (b := b) x y hy) =
      _root_.PillarB.AQFT.Derived.boundaryMatrixUnit
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x y := by
  rw [observableBallGenerator_Lmax2_pair]
  rw [observableBallGenerator_ToC_toMatrix]
  rw [observableBallPairWitness_Lmax2_toMatrix]

/-- Matrix-level normalization of the transported canonical `L_max = 2`
off-diagonal ball generator. This isolates the exact full-dynamics image that
must be analysed for a genuine D2d decision. -/
theorem dynImageObservableBallGenerator_Lmax2_pair_toMatrix
    (t : ℝ)
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x) :
    RegionBlockMat.toMatrix
      (dynImageObservableBallGenerator_ToC
        (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) t x
        (observableBallPairWitness_Lmax2 (b := b) x y hy)) =
      (fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq
          (b := b) ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))).α t
        (_root_.PillarB.AQFT.Derived.boundaryMatrixUnit
          (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x y) := by
  rw [dynImageObservableBallGenerator_ToC_toMatrix]
  rw [observableBallPairWitness_Lmax2_toMatrix]

end

/-- An explicit off-ball off-diagonal nonzero entry already rules out the strong
same-ball localization Ansatz for the transported canonical `L_max = 2` pair
witness. This is the sharp local obstruction available without any stronger
characterization of the full observable top carrier. -/
theorem dynImageObservableBallGenerator_Lmax2_pair_not_sameBallLocalized_of_entry
    (t : ℝ)
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
    {u v : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (huv : u ≠ v)
    (hout : u ∉ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x ∨
      v ∉ boundaryBallFromL
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
    (hentry : RegionBlockMat.toMatrix
      (dynImageObservableBallGenerator_ToC
        (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) t x
        (observableBallPairWitness_Lmax2 (b := b) x y hy)) u v ≠ 0) :
    ¬ RegionLocalized
      (boundaryBallFromL
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
      (RegionBlockMat.toMatrix
        (dynImageObservableBallGenerator_ToC
          (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) t x
          (observableBallPairWitness_Lmax2 (b := b) x y hy))) := by
  intro hloc
  exact hentry (_root_.PillarB.AQFT.Derived.regionLocalized_apply_eq_zero_of_or_not_mem
    (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (r := boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
    (A := RegionBlockMat.toMatrix
      (dynImageObservableBallGenerator_ToC
        (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) t x
        (observableBallPairWitness_Lmax2 (b := b) x y hy)))
    hloc huv hout)

/-- Packaging of the previous local obstruction as a same-ball localization
escape witness on the concrete `L_max = 2` pair generator. -/
theorem observableDynSameBallLocalizationEscapeWitness_of_Lmax2_pair_entry
    (t : ℝ)
    (x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
    (hy : y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
    {u v : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (huv : u ≠ v)
    (hout : u ∉ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x ∨
      v ∉ boundaryBallFromL
        (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
        (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x)
    (hentry : RegionBlockMat.toMatrix
      (dynImageObservableBallGenerator_ToC
        (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) t x
        (observableBallPairWitness_Lmax2 (b := b) x y hy)) u v ≠ 0) :
    observableDynSameBallLocalizationEscapeWitness
      (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) := by
  refine ⟨t, x, observableBallPairWitness_Lmax2 (b := b) x y hy, ?_⟩
  exact dynImageObservableBallGenerator_Lmax2_pair_not_sameBallLocalized_of_entry
    (b := b) t x y hy huv hout hentry

/-- Time-zero sanity check re-expressed on the canonical observable-ball
generator wrapper. -/
@[simp] theorem dyn_top_ToC_zero_maps_observableBallGenerator_to_observableTop
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    dynImageObservableBallGenerator_ToC (b := b) (p := p) 0 i A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  simpa only [dynImageObservableBallGenerator_ToC] using
    dyn_top_ToC_zero_maps_basic_ball_generator_to_observableTop
      (b := b) (p := p) i A

/-- Time-zero sanity check for the stronger same-ball localization Ansatz. -/
@[simp] theorem dyn_top_ToC_zero_preserves_observableBallGenerator_sameBallLocalization
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageObservableBallGenerator_ToC (b := b) (p := p) 0 i A)) := by
  simpa only [dynImageObservableBallGenerator_ToC] using
    dyn_top_ToC_zero_preserves_basic_ball_generator_localization
      (b := b) (p := p) i
      (h := _root_.PillarA.LayerA.RegionNet.le_top'
        (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i))
      A

end ToC
end TreeOfCliquesFromPillarA

end

end Derived
end AQFT
end PillarB
