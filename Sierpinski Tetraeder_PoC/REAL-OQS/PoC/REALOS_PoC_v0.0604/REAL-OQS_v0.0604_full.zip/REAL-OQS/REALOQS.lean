import REALOQS.BuildAll

/-!
# REALOQS

Root import used by the default `lake build` target.

This forwards to `REALOQS.BuildAll`, which in turn pulls in the maintained
strict core build surface.
-/
