import REALOQS.PillarA.Ideal.TreeOfCliques.Boundary
import REALOQS.PillarA.OQS.SysEnv

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

open scoped BigOperators

noncomputable section

open PillarA.OQS

/-!
Phase 2 (part 1): a concrete `Split` of the finite vertex set `V_k` into

* `B_k` (boundary)   := level-`k` cells, and
* `I_k` (interior)   := everything up to level `k` except the boundary.

This is purely combinatorial: it uses only address-length predicates.
-/

namespace Split

variable (b k : Nat)

abbrev V := Vertex b k
abbrev B := Boundary b k
abbrev I := Interior b k

/-- Helper: decide whether a vertex is on the boundary by address length. -/
def isBoundary (v : V (b := b) (k := k)) : Prop := v.1.length = k

private theorem not_mem_cellsAtLevel_of_not_length
    {a : Addr b} (h : a.length ≠ k) : a ∉ cellsAtLevel b k := by
  intro ha
  have hk : a.length = k := (mem_cellsAtLevel_iff_length (b := b) (k := k) a).1 ha
  exact h hk

private theorem mem_interiorSet_of_not_length
    {a : Addr b} (haUp : a ∈ cellsUpTo b k) (h : a.length ≠ k) : a ∈ interiorSet b k := by
  -- `interiorSet = cellsUpTo \ cellsAtLevel`
  refine Finset.mem_sdiff.2 ?_
  refine ⟨haUp, ?_⟩
  exact not_mem_cellsAtLevel_of_not_length (b := b) (k := k) (a := a) h

/-- The forward map `V_k → B_k ⊕ I_k` (case split on `length = k`). -/
def toSum (v : V (b := b) (k := k)) : Sum (B (b := b) (k := k)) (I (b := b) (k := k)) :=
  if h : v.1.length = k then
    Sum.inl ⟨v.1, (mem_cellsAtLevel_iff_length (b := b) (k := k) v.1).2 h⟩
  else
    Sum.inr ⟨v.1, mem_interiorSet_of_not_length (b := b) (k := k) (a := v.1) v.2 h⟩

/-- The inverse map `B_k ⊕ I_k → V_k` (by the canonical embeddings). -/
def fromSum : Sum (B (b := b) (k := k)) (I (b := b) (k := k)) → V (b := b) (k := k)
  | Sum.inl x => boundaryEmbedding (b := b) (k := k) x
  | Sum.inr x => interiorEmbedding (b := b) (k := k) x

/-- Canonical equivalence `V_k ≃ B_k ⊕ I_k` by case distinction on `length = k`. -/
def equivVertexSum : V (b := b) (k := k) ≃ Sum (B (b := b) (k := k)) (I (b := b) (k := k)) where
  toFun := toSum (b := b) (k := k)
  invFun := fromSum (b := b) (k := k)
  left_inv v := by
    classical
    by_cases h : v.1.length = k
    · -- boundary case
      apply Subtype.ext
      simp [toSum, fromSum, h, boundaryEmbedding]
    · -- interior case
      apply Subtype.ext
      simp [toSum, fromSum, h, interiorEmbedding]
  right_inv s := by
    classical
    cases s with
    | inl x =>
        -- boundary element: `length = k`, so `toSum` goes to `inl`.
        have hxlen : x.1.length = k := (mem_cellsAtLevel_iff_length (b := b) (k := k) x.1).1 x.2
        -- Compute `toSum (fromSum (inl x))` explicitly.
        have h_to :
            toSum (b := b) (k := k) (fromSum (b := b) (k := k) (Sum.inl x)) =
              Sum.inl ⟨x.1, (mem_cellsAtLevel_iff_length (b := b) (k := k) x.1).2 hxlen⟩ := by
          simp [fromSum, toSum, boundaryEmbedding, hxlen]
        have h_sub : (⟨x.1, (mem_cellsAtLevel_iff_length (b := b) (k := k) x.1).2 hxlen⟩ :
            B (b := b) (k := k)) = x := by
          apply Subtype.ext
          rfl
        -- Finish.
        simpa [h_sub] using h_to
    | inr x =>
        -- interior element: not in `cellsAtLevel`, hence `length ≠ k`, so `toSum` goes to `inr`.
        have hxnot : x.1 ∉ cellsAtLevel b k := (Finset.mem_sdiff.1 x.2).2
        have hxlen : x.1.length ≠ k := by
          intro hlen
          have : x.1 ∈ cellsAtLevel b k :=
            (mem_cellsAtLevel_iff_length (b := b) (k := k) x.1).2 hlen
          exact hxnot this
        have h_to :
            toSum (b := b) (k := k) (fromSum (b := b) (k := k) (Sum.inr x)) =
              Sum.inr ⟨x.1,
                mem_interiorSet_of_not_length (b := b) (k := k) (a := x.1)
                  ((Finset.mem_sdiff.1 x.2).1) hxlen⟩ := by
          simp [fromSum, toSum, interiorEmbedding, hxlen]
        have h_sub :
            (⟨x.1,
              mem_interiorSet_of_not_length (b := b) (k := k) (a := x.1)
                ((Finset.mem_sdiff.1 x.2).1) hxlen⟩ : I (b := b) (k := k)) = x := by
          apply Subtype.ext
          rfl
        simpa [h_sub] using h_to

end Split

/-- The canonical split `V_k ≃ B_k ⊕ I_k` packaged as an `OQS.Split`. -/
def split (b k : Nat) :
    PillarA.OQS.Split (Vertex b k) where
  B := Boundary b k
  I := Interior b k
  instFintypeB := by
    classical
    exact inferInstance
  instDecEqB := by
    classical
    exact inferInstance
  instFintypeI := by
    classical
    exact inferInstance
  instDecEqI := by
    classical
    exact inferInstance
  e := Split.equivVertexSum (b := b) (k := k)

end

end TreeOfCliques
end Ideal
end PillarA
