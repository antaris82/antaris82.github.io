import Mathlib
import REALOQS.PillarA.Ideal.Substrate

set_option linter.style.longLine false


/-!
REALOQS / Pillar A / Layer A: LCP-based attribution (μ via longest common prefix)
-- v0.11 (2026-01-22)

Purpose:
- Provide the combinatorial kernel of the "LCP measure" to avoid double counting.
- Attribute an (abstract) edge between two addressed vertices to the unique cell given
  by the longest common prefix (LCP) of their addresses.

This is independent of any embedding/continuum. It is purely address-tree logic.

We implement:
- lcp : Addr b → Addr b → Addr b
- basic properties: lcp is prefix of both, maximality (as a gate)
- owner(e) := lcp(u,v)
-/

namespace PillarA
namespace Ideal

open PillarA.Ideal

section LCP

variable {b : Nat}

/-- Longest common prefix of two addresses. -/
def lcp : Addr b → Addr b → Addr b
| [], _ => []
| _, [] => []
| (a::as), (x::xs) =>
    if _h : a = x then a :: lcp as xs else []

/-- lcp is a prefix of the left argument. -/
theorem gate_lcp_prefix_left (u v : Addr b) : lcp (b := b) u v <+: u := by
  induction u generalizing v with
  | nil =>
      simp [lcp]
  | cons a as ih =>
      cases v with
      | nil =>
          simp [lcp]
      | cons x xs =>
          by_cases h : a = x
          · subst h
            -- reduce to the tail prefix proof
            have htail : lcp (b := b) as xs <+: as := ih xs
            rcases htail with ⟨t, ht⟩
            refine ⟨t, ?_⟩
            -- `(a :: lcp as xs) ++ t = a :: as`
            simp [lcp, ht]
          · simp [lcp, h]

/-- lcp is a prefix of the right argument. -/
theorem gate_lcp_prefix_right (u v : Addr b) : lcp (b := b) u v <+: v := by
  induction u generalizing v with
  | nil =>
      cases v <;> simp [lcp]
  | cons a as ih =>
      cases v with
      | nil => simp [lcp]
      | cons x xs =>
          by_cases h : a = x
          · subst h
            have htail : lcp (b := b) as xs <+: xs := ih xs
            rcases htail with ⟨t, ht⟩
            refine ⟨t, ?_⟩
            simp [lcp, ht]
          · simp [lcp, h]

/-- lcp is commutative. -/
theorem gate_lcp_comm (u v : Addr b) : lcp (b := b) u v = lcp (b := b) v u := by
induction u generalizing v with
| nil =>
    cases v <;> simp [lcp]
| cons a as ih =>
    cases v with
    | nil =>
        simp [lcp]
    | cons x xs =>
        by_cases h : a = x
        · subst h
          simp [lcp, ih]
        · have hx : x ≠ a := by
            intro hxEq
            exact h hxEq.symm
          simp [lcp, h, hx]


/-- length(lcp u v) ≤ length u. -/
theorem gate_lcp_length_le_left (u v : Addr b) : (lcp (b := b) u v).length ≤ u.length := by
  exact (gate_lcp_prefix_left (b := b) u v).length_le

/-- length(lcp u v) ≤ length v. -/
theorem gate_lcp_length_le_right (u v : Addr b) : (lcp (b := b) u v).length ≤ v.length := by
  exact (gate_lcp_prefix_right (b := b) u v).length_le

/-- Maximality (gate form): any common prefix w is prefix of lcp(u,v). -/
theorem gate_lcp_maximal (u v w : Addr b) :
    (w <+: u ∧ w <+: v) → w <+: lcp (b := b) u v := by
  intro hw
  induction w generalizing u v with
  | nil =>
      -- `[]` is a prefix of every list.
      refine ⟨lcp (b := b) u v, by simp⟩
  | cons a ws ih =>
      -- unwrap the prefix witnesses for `u` and `v`
      rcases hw.1 with ⟨t1, rfl⟩
      rcases hw.2 with ⟨t2, rfl⟩
      -- reduce to the tails
      have hws : ws <+: lcp (b := b) (ws ++ t1) (ws ++ t2) := by
        have hws1 : ws <+: ws ++ t1 := ⟨t1, by simp⟩
        have hws2 : ws <+: ws ++ t2 := ⟨t2, by simp⟩
        exact ih (u := ws ++ t1) (v := ws ++ t2) ⟨hws1, hws2⟩
      rcases hws with ⟨t, ht⟩
      -- build the witness for `(a::ws) <:+ lcp ((a::ws)++t1) ((a::ws)++t2)`
      refine ⟨t, ?_⟩
      -- unfold `lcp` at the heads (equal by reflexivity)
      -- and use `ht : ws ++ t = lcp (ws ++ t1) (ws ++ t2)`
      simp [lcp, ht]


/-- Edge with addressed endpoints. -/
structure Edge (b : Nat) where
  u : Addr b
  v : Addr b

/-- LCP-based owner cell (μ attribution). -/
def owner (e : Edge b) : Addr b := lcp (b := b) e.u e.v

theorem gate_owner_prefix_u (e : Edge b) : owner (b := b) e <+: e.u := by
  simpa [owner] using gate_lcp_prefix_left (b := b) e.u e.v

theorem gate_owner_prefix_v (e : Edge b) : owner (b := b) e <+: e.v := by
  simpa [owner] using gate_lcp_prefix_right (b := b) e.u e.v

/-- Swap endpoints of an edge. -/
def Edge.swap (e : Edge b) : Edge b := ⟨e.v, e.u⟩

/-- Owner is symmetric under swapping endpoints. -/
theorem gate_owner_swap (e : Edge b) : owner (b := b) (Edge.swap (b := b) e) = owner (b := b) e := by
  simp [Edge.swap, owner, gate_lcp_comm]

/-- Characterization: `w` is a prefix of the owner iff it is a common prefix of both endpoints. -/
theorem gate_owner_iff_commonPrefix (e : Edge b) (w : Addr b) :
    (w <+: owner (b := b) e) ↔ (w <+: e.u ∧ w <+: e.v) := by
  constructor
  · intro h
    constructor
    · exact h.trans (gate_owner_prefix_u (b := b) e)
    · exact h.trans (gate_owner_prefix_v (b := b) e)
  · intro hw
    -- maximality of `lcp` among common prefixes
    simpa [owner] using gate_lcp_maximal (b := b) e.u e.v w hw

end LCP

end Ideal
end PillarA
