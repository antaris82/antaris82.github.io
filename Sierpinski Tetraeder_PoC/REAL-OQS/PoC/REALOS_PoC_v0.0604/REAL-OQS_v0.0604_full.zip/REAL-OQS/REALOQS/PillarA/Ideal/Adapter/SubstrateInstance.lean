import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA

namespace Ideal

/-!
# IDEAL as a `Core.Substrate` instance (Phase 2)

This module provides **instances** of the Phase-1 Core substrate contracts
for the IDEAL address-tree scaffold.

The core contract (`PillarA.LayerA.Substrate`) expects a level-indexed family
`Cell : Nat → Type`.

For IDEAL we use the canonical level-indexed type of addresses at a given level:

* `IdealCell b L := ↥(cellsAtLevel b L)`.

This keeps the core interface purely combinatorial:
no geometry, no physics, just refinement combinatorics.
-/

open scoped BigOperators

/-- Level-indexed IDEAL cells: addresses at level `L` in base `b`. -/
abbrev IdealCell (b : Nat) : Nat → Type := fun L => ↥(cellsAtLevel b L)

namespace IdealCell

variable {b L : Nat}

@[simp] theorem mem_cellsAtLevel (c : IdealCell b L) : (c.1 : Addr b) ∈ cellsAtLevel b L :=
  c.2

/-- The unique parent of a level-`(L+1)` IDEAL cell: truncate the address to length `L`. -/
def parent (c : IdealCell b (L + 1)) : IdealCell b L := by
  refine ⟨(c.1.take L), ?_⟩
  -- Membership is characterized by length.
  apply (mem_cellsAtLevel_iff_length b L (c.1.take L)).2
  have hc_len : c.1.length = L + 1 :=
    (mem_cellsAtLevel_iff_length b (L + 1) c.1).1 c.2
  -- `length (take L xs) = min L (length xs)`.
  -- Here `L ≤ L+1`, hence the minimum is `L`.
  simp [List.length_take, hc_len]

/-- Append one digit to obtain a child cell. -/
def child (c : IdealCell b L) (d : Fin b) : IdealCell b (L + 1) := by
  refine ⟨Ideal.child c.1 d, ?_⟩
  -- Show the new address is in the next level using the lemma from `Ideal.Substrate`.
  apply children_subset_next_level b L c.1 (Ideal.child c.1 d) c.2
  -- `Ideal.child c d` is a member of `children c` by construction.
  simp [Ideal.children, Ideal.child]

end IdealCell

open PillarA.LayerA

/-!
## Core substrate instances
-/

instance (b : Nat) : PillarA.LayerA.Substrate (IdealCell b) where
  instDecEq := fun _L => by infer_instance
  instFintype := fun _L => by infer_instance
  parents := fun {L} c => {IdealCell.parent (b := b) (L := L) c}
  children := fun {L} c =>
    Finset.univ.image (fun d : Fin b => IdealCell.child (b := b) (L := L) c d)

instance (b : Nat) : PillarA.LayerA.DeterministicSubstrate (IdealCell b) where
  parent := fun {L} c => IdealCell.parent (b := b) (L := L) c
  parents_eq_singleton_parent := by
    intro L c
    rfl

end Ideal

end PillarA
