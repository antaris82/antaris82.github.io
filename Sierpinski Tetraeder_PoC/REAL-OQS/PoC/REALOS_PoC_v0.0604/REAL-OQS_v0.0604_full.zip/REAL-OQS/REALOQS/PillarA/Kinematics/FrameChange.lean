import Mathlib

/-!
REALOQS / Pillar A / Layer A: Discrete Frame Change (downstream targets) -- v0.11 (2026-01-22)

Discrete algebraic kernel for time-dependent frame changes:
  T'ₙ = Uₙ₊₁ ∘ Tₙ ∘ Uₙ^{-1}

If Uₙ is constant, this reduces to conjugation by a single U.

Nontrivial gates are intended targets for downstream; core lemmas are provided.
-/

namespace PillarA
namespace Kinematics

section Discrete

variable {S : Type}

/-- Discrete-time evolution: a sequence of endomorphisms on `S`. -/
abbrev Evo (S : Type) := ℕ → (S → S)

/-- A "frame" is a time-dependent permutation of `S`. -/
abbrev Frame (S : Type) := ℕ → Equiv.Perm S

/-- Time-independence of a frame (single constant transformation). -/
def timeIndependent (U : Frame S) : Prop := ∀ n, U n = U 0

/-- Apply a time-dependent frame change Uₙ to an evolution Tₙ. -/
def frameChange (T : Evo S) (U : Frame S) : Evo S := fun n x => (U (n+1)) (T n ((U n).symm x))

/-- Relative change (discrete "connection"): Aₙ = Uₙ₊₁ ∘ Uₙ^{-1}. -/
def relChange (U : Frame S) : ℕ → Equiv.Perm S := fun n => (U (n+1)) * (U n)⁻¹

/-- Gate FRAMECHANGE_CONJ_CONST: If U is time-independent, then frameChange is conjugation by U0. -/
theorem gate_FRAMECHANGE_CONJ_CONST (T : Evo S) (U : Frame S) (hU : timeIndependent (S := S) U) :
    ∀ n, frameChange (S := S) T U n = fun x => (U 0) (T n ((U 0).symm x)) := by
  intro n
  funext x
  simp [frameChange, hU n, hU (n+1)]

/-- Gate RELCHANGE_ID_OF_CONST: If U is time-independent, all relative changes are identity. -/
theorem gate_RELCHANGE_ID_OF_CONST (U : Frame S) (hU : timeIndependent (S := S) U) :
    ∀ n, relChange (S := S) U n = 1 := by
  intro n
  simp [relChange, hU n, hU (n+1)]

/-- Gate NONINERTIAL_IF_RELCHANGE_NE_ID:
If some `relChange` is not identity, `U` is not time-independent. -/
theorem gate_NONINERTIAL_IF_RELCHANGE_NE_ID (U : Frame S) :
    (∃ n, relChange (S := S) U n ≠ 1) → ¬ timeIndependent (S := S) U := by
  intro h hU
  rcases h with ⟨n, hn⟩
  have : relChange (S := S) U n = 1 := gate_RELCHANGE_ID_OF_CONST (S := S) U hU n
  exact hn this

end Discrete

end Kinematics
end PillarA
