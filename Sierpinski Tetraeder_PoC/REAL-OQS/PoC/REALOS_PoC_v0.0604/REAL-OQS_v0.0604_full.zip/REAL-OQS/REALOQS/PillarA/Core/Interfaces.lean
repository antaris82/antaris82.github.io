/-
DEPRECATED (compatibility wrapper)

Historically, `REALOQS.PillarA.Core.Interfaces` was used as a broad umbrella.
After the Pillar-A interface consolidation, the recommended entry points are:

- `REALOQS.PillarA.Interface`   (canonical, substrate-agnostic API surface)
- `REALOQS.PillarA.All`         (heavy developer umbrella)
- `REALOQS.PillarA.Core.Exports` (core-only umbrella)

This module remains as a thin forwarder for backwards compatibility.
-/

import REALOQS.PillarA.Core.Exports
