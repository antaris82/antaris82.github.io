import REALOQS.PillarA.Ideal.Foliation

/-!
# IDEAL Adapter: Foliation

Thin re-export wrapper (Phase 8 import policy).
-/
