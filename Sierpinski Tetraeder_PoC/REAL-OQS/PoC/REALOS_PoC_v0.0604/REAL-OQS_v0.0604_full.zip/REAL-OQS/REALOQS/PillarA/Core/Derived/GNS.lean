import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Data.Complex.Basic

import REALOQS.PillarA.Core.ToC.AQFTSubstrate

/-!
# Derived GNS hooks (Phase II scaffold)

This file introduces a **Phase II** namespace in Pillar A meant to host
*derived* (Mathlib-backed) GNS constructions when available.

For now this is only a stable API surface, not a full construction.

Design notes
- We keep the data record minimal and extensible.
- We do **not** modify Pillar B. Pillar B continues to reference `S.GNSData`.
- Later: add a C*-algebra/positive functional based instance.
-/

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

/-- Minimal GNS output package. Extend as needed in Phase II. -/
structure GNSData (A : Type u) where
  /-- The GNS Hilbert space. -/
  H : Type u
  /-- The cyclic vector (placeholder surface; later include `π`, etc.). -/
  omegaVec : H

/--
A hook class: when Mathlib can construct GNS for `A`, provide a builder.

We intentionally keep the notion of state abstract here; Phase II will align it
with the project's `State` interface and/or Mathlib's positive functionals.
-/
class HasDerivedGNS (A : Type u) where
  StateOn : Type u
  isState : StateOn → Prop
  mkGNSData : ∀ ω : StateOn, isState ω → GNSData A

end Derived
end PillarA
