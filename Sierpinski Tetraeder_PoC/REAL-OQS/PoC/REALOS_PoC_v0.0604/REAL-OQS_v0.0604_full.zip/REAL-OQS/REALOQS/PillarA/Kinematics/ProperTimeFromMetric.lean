import Mathlib
import REALOQS.PillarA.Kinematics.ProperTime
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.Causality
import REALOQS.PillarA.Core.ResistanceMetric

set_option linter.style.longLine false


set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Proper-time hook from spatial metric + speed limit -- v0.11h-full

Pillar A does not assume a Lorentzian metric. Still, later layers need a way to assign a
nonnegative "proper time" to discrete trajectories. This file provides an interface that
links:

* a discrete spacetime `(τ, Σ_n, step)`,
* a spatial metric (here: an abstract `ResistanceMetric` on events),
* a per-step speed limit `c`,
* and a per-step cost `cost : StepCost X`.

No special-relativistic formula is hard-coded; only monotonicity and boundary conditions
are registered as contracts.
-/

namespace PillarA
namespace Kinematics

open PillarA.LayerA

noncomputable section

/-- Interface tying `StepCost` to a spatial metric and a speed-limit contract. -/
structure ProperTimeMetricHook {X : Type}
    (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) : Type where
  SL : CausalSpeedLimit ST rm
  cost : StepCost X

  /-- zero spatial displacement yields unit proper-time increment (normalization). -/
  cost_self : ∀ x : X, cost x x = 1

  /-- reaching the speed limit yields zero proper-time increment (SR-like boundary). -/
  cost_zero_of_maxspeed : ∀ {x y : X}, dist (rm := rm) x y = SL.c → cost x y = 0

  /-- any allowed spacetime step has a defined (finite) cost. -/
  cost_defined_of_step : ∀ {x y : X}, ST.step x y → cost x y ≠ (⊤ : ENNReal)

  /-- larger spatial displacement should not increase proper-time increment. -/
  cost_antitone_in_dist :
    ∀ {x y x' y' : X}, dist (rm := rm) x y ≤ dist (rm := rm) x' y' → cost x' y' ≤ cost x y

namespace ProperTimeMetricHook

variable {X : Type} {ST : DiscreteSpacetime X} {rm : ResistanceMetric X}

/-- Proper time up to step `n` for a spacetime worldline. -/
def properTimeOf (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) (n : Nat) : ENNReal := properTimeUpTo (V := X) H.cost γ.x n

/-- Gate: the one-step increment is `cost` for the current step. -/
theorem gate_properTimeOf_succ (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) (n : Nat) :
    H.properTimeOf γ (n+1) = H.properTimeOf γ n + H.cost (γ.x n) (γ.x (n+1)) := by
  classical
  -- unfold to a finite sum and use the standard `range`-succ split
  simp [properTimeOf, properTimeUpTo, Finset.sum_range_succ]

/-- Gate: along any spacetime worldline, each step cost is defined. -/
theorem gate_cost_defined_along_worldline (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) :
    ∀ n, H.cost (γ.x n) (γ.x (n+1)) ≠ (⊤ : ENNReal) := by
  intro n
  exact H.cost_defined_of_step (γ.step_ok n)

/-- downstream hook: a fully-typed witness with centralized `deferred proof`s. -/
def mkTopSpeedLimit {X : Type} (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) :
    ProperTimeMetricHook ST rm :=
by
  classical
  -- We provide a *total* (non-`⊤`) cost and a speed-limit contract that holds for
  -- any `ST` and `rm` by choosing `c = ⊤`.
  --
  -- This yields a maximally general, assumption-free witness:
  -- - every step is automatically speed-bounded;
  -- - the proper-time increment is normalized to `1` on zero spatial displacement;
  -- - if the (chosen) bound is saturated (i.e. the distance is `⊤`), the increment is `0`.
  let cost' : StepCost X := fun x y => if dist (rm := rm) x y = (⊤ : ENNReal) then 0 else 1
  refine
    { SL :=
        { c := (⊤ : ENNReal)
          step_bound := by
            intro x y hstep
            exact le_top }
      cost := cost'
      cost_self := by
        intro x
        -- `dist x x = 0`, hence not `⊤`.
        simp [cost', PillarA.LayerA.gate_dist_self (rm := rm) x]
      cost_zero_of_maxspeed := by
        intro x y h
        -- Here `SL.c = ⊤`, so `h` is exactly the guard used in `cost'`.
        simp [cost', h]
      cost_defined_of_step := by
        intro x y hstep
        -- `cost'` only takes values `0` or `1`.
        by_cases hxy : dist (rm := rm) x y = (⊤ : ENNReal)
        · simp [cost', hxy]
        · simp [cost', hxy]
      cost_antitone_in_dist := by
        intro x y x' y' hle
        -- Case split on whether the smaller distance is infinite.
        by_cases hxy : dist (rm := rm) x y = (⊤ : ENNReal)
        · have hx'y' : dist (rm := rm) x' y' = (⊤ : ENNReal) := by
            have : (⊤ : ENNReal) ≤ dist (rm := rm) x' y' := by
              simpa [hxy] using hle
            exact top_le_iff.mp this
          simp [cost', hxy, hx'y']
        · -- Otherwise `cost' x y = 1`, and `cost' x' y' ≤ 1` always.
          by_cases hx'y' : dist (rm := rm) x' y' = (⊤ : ENNReal)
          · simp [cost', hxy, hx'y']
          · simp [cost', hxy, hx'y'] }

end ProperTimeMetricHook

end

end Kinematics
end PillarA
