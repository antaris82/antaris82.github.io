import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.RegionCore

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Boundary ports (Core, Phase 5)

This is a **purely combinatorial** placeholder for “boundary degrees of freedom” of a
selected region inside an approximant.

At this stage, we only record:

* the chosen region `region : RegionAt Cell L`,
* a finite subset `ports` of that region.

No geometric/graph-theoretic notion of “boundary” is assumed.
-/

open RegionCore

universe u

/-- Boundary ports attached to a region at level `L`.

We make `DecidableEq (Cell L)` an explicit parameter. Otherwise, the
`Finset`-membership in `ports_subset` introduces an implicit typeclass
metavariable that can get stuck when using `BoundaryPorts` only via its type.
-/
structure BoundaryPorts (Cell : Nat → Type u) (L : Nat) [DecidableEq (Cell L)] where
  region : RegionAt Cell L
  ports : Finset (Cell L)
  ports_subset : ports ⊆ region

namespace BoundaryPorts

variable {Cell : Nat → Type u} {L : Nat} [DecidableEq (Cell L)]

@[simp] theorem mem_region_of_mem_ports (bp : BoundaryPorts Cell L) {x : Cell L} :
    x ∈ bp.ports → x ∈ bp.region := by
  intro hx
  exact bp.ports_subset hx

/-- Trivial boundary: take all cells of the region as ports. -/
def mkAll (R : RegionAt Cell L) : BoundaryPorts Cell L :=
  ⟨R, R, by intro x hx; exact hx⟩

/-- One-step refinement of boundary ports via the substrate's `children`.

Ports are refined by taking all children of the current port cells.
The resulting ports are automatically contained in the refined region.
-/
def refine [Substrate Cell] (bp : BoundaryPorts Cell L) :
    BoundaryPorts Cell (L + 1) := by
  refine ⟨RegionCore.refineAt (Cell := Cell) bp.region,
    Substrate.refineSet (Cell := Cell) bp.ports, ?_⟩
  intro x hx
  -- monotonicity of `refineSet` with respect to inclusion
  have hmono :
      Substrate.refineSet (Cell := Cell) bp.ports ⊆
        Substrate.refineSet (Cell := Cell) bp.region :=
    Substrate.refineSet_mono (Cell := Cell) (S := bp.ports) (T := bp.region) bp.ports_subset
  exact hmono hx

end BoundaryPorts

end LayerA

end PillarA
