import Mathlib



/-!
REALOQS / Pillar A / Update: Mismatch functional (interface)

This module is intentionally lightweight. It only fixes the *interfaces* that
later, more concrete layers (simulation, canonical grounded solve, etc.) must
implement.

Key ingredients:
- `LinOp α`: a linear operator acting on real-valued functions `α → ℝ`.
- `NullModeProjector α`: a projector removing null-modes / gauge directions.
- `projectOp`: composition of a projector with an operator.
- `mismatch`: a toy mismatch functional (L¹-like) on finite types.

No attempt is made to justify physical correctness here.
-/

namespace PillarA
namespace Update

noncomputable section

section Mismatch

variable {α : Type}

/-- A linear operator on real-valued functions on `α`.

We keep this abstract: linearity laws are *contracts* proved/used in later layers.
-/
structure LinOp (α : Type) where
  apply : (α → ℝ) → (α → ℝ)

namespace LinOp

instance : Zero (LinOp α) := ⟨⟨fun _ => 0⟩⟩
instance : Add (LinOp α) := ⟨fun A B => ⟨fun f => A.apply f + B.apply f⟩⟩
instance : Neg (LinOp α) := ⟨fun A => ⟨fun f => -A.apply f⟩⟩
instance : SMul ℝ (LinOp α) := ⟨fun r A => ⟨fun f => r • (A.apply f)⟩⟩

@[simp] theorem zero_apply (f : α → ℝ) : (0 : LinOp α).apply f = 0 := rfl
@[simp] theorem add_apply (A B : LinOp α) (f : α → ℝ) :
    (A + B).apply f = A.apply f + B.apply f := rfl
@[simp] theorem neg_apply (A : LinOp α) (f : α → ℝ) : (-A).apply f = -A.apply f := rfl
@[simp] theorem smul_apply (r : ℝ) (A : LinOp α) (f : α → ℝ) :
    (r • A).apply f = r • (A.apply f) := rfl

@[ext]
theorem ext {A B : LinOp α} (h : ∀ f x, A.apply f x = B.apply f x) : A = B := by
  cases A with
  | mk a =>
    cases B with
    | mk b =>
      have hab : a = b := by
        funext f x
        exact h f x
      cases hab
      rfl

end LinOp

/-- A projector removing null-modes (gauge directions).

Only additivity and preservation of zero are fixed at Pillar A.
-/
structure NullModeProjector (α : Type) where
  proj : (α → ℝ) → (α → ℝ)
  map_add : ∀ f g, proj (f + g) = proj f + proj g
  map_zero : proj 0 = 0

/-- Compose a projector with a linear operator. -/
def projectOp {α : Type} (P : NullModeProjector α) (A : LinOp α) : LinOp α :=
  ⟨fun f => P.proj (A.apply f)⟩

@[simp] theorem projectOp_apply {α : Type} (P : NullModeProjector α) (A : LinOp α) (f : α → ℝ) :
    (projectOp P A).apply f = P.proj (A.apply f) := rfl

theorem projectOp_add {α : Type} (P : NullModeProjector α) (A B : LinOp α) :
    projectOp P (A + B) = projectOp P A + projectOp P B := by
  ext f x
  simp [projectOp, P.map_add]

theorem projectOp_zero {α : Type} (P : NullModeProjector α) : projectOp P (0 : LinOp α) = 0 := by
  ext f x
  simp [projectOp, P.map_zero]

/-- A simple `L¹`-like trace-norm proxy on a finite set.

The `+ 1` guarantees strict positivity, avoiding division by zero.
-/
def traceNormFactor {α : Type} [Fintype α] (f : α → ℝ) : ℝ :=
  (Finset.univ.sum fun x => |f x|) + 1

/-- Normalize a function by the trace-norm proxy. -/
def normalizeTraceVec {α : Type} [Fintype α] (f : α → ℝ) : α → ℝ :=
  fun x => f x / traceNormFactor f

/-- A toy mismatch functional: project the operator output and take the `L¹` proxy.

This is an *interface* definition; concrete layers may replace it.
-/
def mismatchVec {α : Type} [Fintype α] (P : NullModeProjector α) (A : LinOp α) (f : α → ℝ) : ℝ :=
  let fN : α → ℝ := normalizeTraceVec f
  let g : α → ℝ := (projectOp P A).apply fN
  Finset.univ.sum fun x => |g x|

end Mismatch

/-!
## Operator-level mismatch API

Several higher-level modules work with *operators* (`LinOp`) rather than raw
functions.  We provide a minimal placeholder API here so the project compiles.
The mathematical/physical content is intentionally left for later refinement.
-/

/-- For now, a "normalized operator" is just a linear operator. -/
abbrev NormalizedOp (α : Type) := LinOp (α := α)

/-!
### Mismatch as an explicit hook

Phase 7 requirement: the mismatch must not be hard-coded as a global constant.
Instead it is an *explicit contract/hook* bundled with the projector and
normalization trace functional.

We keep the content minimal at Pillar A:
* `mismatch` returns an `ENNReal` to bake in nonnegativity.
* `mismatch_self` is the weakest stability axiom needed by downstream gates.

Concrete layers are expected to provide a nontrivial `mismatch` and prove the
contracts.
-/

/-- Bundle the projector `P`, a trace functional `T` (used for normalization),
and the operator-level mismatch hook. -/
structure MismatchFunctional (α : Type) where
  P : NullModeProjector α
  /-- Trace-like functional used by normalization. -/
  T : NormalizedOp (α := α) → ℝ := fun _ => 1
  /-- Nonnegative mismatch between two (already normalized) operators. -/
  mismatch : NormalizedOp (α := α) → NormalizedOp (α := α) → ENNReal
  /-- Contract: mismatch vanishes on identical inputs. -/
  mismatch_self : ∀ A, mismatch A A = 0

namespace MismatchFunctional

/-- A simple, nontrivial mismatch: an equality-test mismatch.

This is intentionally *very* weak but it is:
* non-vacuous (it can return `1`),
* interface-friendly (no topology/norms needed),
* and it satisfies `mismatch_self` by reflexivity.

Concrete layers should replace this with a physically meaningful metric. -/
noncomputable def mkEqMismatch (α : Type) (P : NullModeProjector α)
    [DecidableEq (NormalizedOp (α := α))] : MismatchFunctional (α := α) := by
  classical
  refine { P := P
          , mismatch := ?_
          , mismatch_self := ?_ }
  · intro A B
    exact (if A = B then (0 : ENNReal) else (1 : ENNReal))
  · intro A
    simp


/-- Default mismatch functional used on the productive path.

This is intentionally weak but **non-vacuous**: it can return `1`.
It depends only on an equality test on normalized operators.

Concrete layers should replace this with a physically meaningful metric.
-/

noncomputable def mkDefault (α : Type) (P : NullModeProjector α)
    [DecidableEq (NormalizedOp (α := α))] : MismatchFunctional (α := α) := by
  classical
  exact mkEqMismatch (α := α) P

end MismatchFunctional

/-- Normalize an operator using a trace functional and an epsilon floor.

We compute a strictly positive normalization denominator

`denom := max ε |tracePerp (projectOp P A)|`

and then scale the operator by `1/denom`.
-/
def normalizeTrace {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (_hε : 0 < ε) (A : NormalizedOp (α := α)) : NormalizedOp (α := α) := by
  -- We use the projected operator for the trace-like normalization.
  let Ap : NormalizedOp (α := α) := projectOp P A
  let denom : ℝ := max ε |tracePerp Ap|
  exact (1 / denom) • A

/-- The normalization denominator is strictly positive. -/
theorem normalizeTrace_denom_pos {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (hε : 0 < ε) (A : NormalizedOp (α := α)) :
    0 < max ε |tracePerp (projectOp P A)| := by
  have : 0 < ε := hε
  -- `max ε _ ≥ ε`.
  exact lt_of_lt_of_le this (le_max_left _ _)

/-- Congruence: `normalizeTrace` respects equality of operators. -/
theorem normalizeTrace_congr {α : Type}
    (P : NullModeProjector α) (tracePerp : NormalizedOp (α := α) → ℝ)
    (ε : ℝ) (hε : 0 < ε) {A B : NormalizedOp (α := α)}
    (h : A = B) : normalizeTrace P tracePerp ε hε A = normalizeTrace P tracePerp ε hε B := by
  cases h
  rfl

end

end Update
end PillarA
