import REALOQS.PillarA.Update.TailEliminationDtNStabilized
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace Adapter

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS
open PillarA.Update

/-!
# Tree-of-Cliques: `TailElimDtNStabilizedSemantics`

We connect the concrete Tree-of-Cliques stabilized DtN carrier
`TreeOfCliquesApproxDtNStabilized` to the semantic contract
`TailElimDtNStabilizedSemantics`.

Key point (post Phase 3): stage-1 is a genuine stabilized DtN reduction `reduce`.
It stores `DtN_stabilized_of (fullMatrix s)` in `LBB` and zeros the cross blocks.
-/

namespace TreeOfCliquesDtNStabilizedSemantics

open TreeOfCliquesApproxDtNStabilized

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b :=
  TreeOfCliquesApproxDtNStabilized.mk (b := b) p

abbrev V : Type := PillarA.Ideal.TreeOfCliques.Vertex b p.L_max

abbrev split : PillarA.OQS.Split (V := V p) :=
  TreeOfCliquesApproxDtNStabilized.sSplit (p := p)

def L (s : (A p).S) : Matrix (V p) (V p) ℝ :=
  TreeOfCliquesApproxDtNStabilized.fullMatrix (p := p) s

/-- Boundary operator observable stored in the update state.

Note: the semantic contract only probes `boundaryOp` on `stage1 s`.
In this carrier, `stage1` is `reduce`, and `reduce` stores the stabilized DtN
boundary operator in `LBB`.
-/
def boundaryOp (s : (A p).S) : Matrix (split p).B (split p).B ℝ :=
  s.LBB

def mk : PillarA.Update.TailElimDtNStabilizedSemantics (A := A p) := by
  refine
    { V := V p
      instFintypeV := by classical exact inferInstance
      instDecEqV := by classical exact inferInstance
      split := split p
      L := L (p := p)
      invStab := fun s => TreeOfCliquesApproxDtNStabilized.invStab (p := p) s
      boundaryOp := boundaryOp (p := p)
      stage1_boundaryOp_eq := ?_ }
  intro s
  -- `stage1 = reduce` and `boundaryOp = LBB`, hence by unfolding `reduce`.
  simp [boundaryOp, L, TwoStageApprox.stage1,
    TreeOfCliquesApproxDtNStabilized.mk, TreeOfCliquesApproxDtNStabilized.reduce]

end TreeOfCliquesDtNStabilizedSemantics

end
end Adapter
end Ideal
end PillarA
