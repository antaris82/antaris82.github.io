import Mathlib
import REALOQS.PillarA.Ideal.TreeOfCliques.SmallScales
import REALOQS.PillarA.Ideal.TreeOfCliques.Level1Facts
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesBreakWitness

set_option autoImplicit false

/-!
# Tree-of-Cliques: `k=1` boundary-block shape

This module isolates the exact `k=1` shape of the boundary block
`(s₁.blockBB L₁)` for the Tree-of-Cliques Laplacian:

* off-diagonal entries are `-1`,
* diagonal entries are `b`.

The proofs intentionally re-use the already established Phase-3 small-scale
facts from `TreeOfCliquesBreakWitness`, but package them in a dedicated,
minimal module for the S0 audit path.
-/

namespace PillarA
namespace Physics
namespace Instances
namespace TreeOfCliques

noncomputable section

open scoped BigOperators

namespace ToC

variable {b : Nat}

/-- Distinct level-1 boundary vertices are adjacent as siblings. -/
theorem adj_boundary1_boundary_of_ne
    (x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
    (hxy : x ≠ y) :
    _root_.PillarA.Ideal.TreeOfCliques.Adj
      (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x)
      (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y) := by
  classical
  simp [_root_.PillarA.Ideal.TreeOfCliques.Adj,
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding]
  rcases
    _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
      (b := b) x with ⟨dx, hx⟩
  rcases
    _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
      (b := b) y with ⟨dy, hy⟩
  refine Or.inr ?_
  refine ⟨?_, ?_, ?_⟩
  · intro haddr
    apply hxy
    exact Subtype.ext haddr
  · simp [hx, hy]
  · simp [hx, hy]

/-- Off-diagonal `k=1` Laplacian entry between boundary siblings. -/
theorem laplacian_boundary_boundary_eq_neg_one
    (x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
    (hxy : x ≠ y) :
    _root_.PillarA.Ideal.TreeOfCliques.laplacian (b := b) 1
      (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x)
      (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y)
      = (-1 : ℝ) := by
  classical
  let vx : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x
  let vy : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y
  have hadj : _root_.PillarA.Ideal.TreeOfCliques.Adj vx vy := by
    simpa [vx, vy] using adj_boundary1_boundary_of_ne (b := b) x y hxy
  have hne : vx ≠ vy := by
    intro h
    apply hxy
    apply Subtype.ext
    simpa [vx, vy, _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding] using
      congrArg
        (fun v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 => v.1) h
  simp [vx, vy,
    _root_.PillarA.Ideal.TreeOfCliques.laplacian,
    _root_.PillarA.LayerA.laplacian,
    _root_.PillarA.Ideal.TreeOfCliques.conductance,
    hadj, hne]

/-- Off-diagonal entries of the `k=1` boundary block are `-1`. -/
theorem blockBB_k1_offdiag_eq_neg_one
    (x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
    (hxy : x ≠ y) :
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x y
      = (-1 : ℝ) := by
  simpa [
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s,
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L,
    _root_.PillarA.OQS.Split.blockBB,
    _root_.PillarA.OQS.Split.reindex,
    _root_.PillarA.Ideal.TreeOfCliques.Split.equivVertexSum,
    _root_.PillarA.Ideal.TreeOfCliques.Split.fromSum
  ] using laplacian_boundary_boundary_eq_neg_one (b := b) x y hxy

/-- Sum of the off-diagonal entries in a fixed `k=1` boundary row. -/
theorem sum_offdiag_blockBB_k1_eq_neg_sub_one
    (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    Finset.sum (Finset.univ.erase x) (fun y =>
      ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x y)
      = -((b : ℝ) - 1) := by
  classical
  let LBB :=
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))
  have hconst :
      ∀ y ∈ Finset.univ.erase x, LBB x y = (-1 : ℝ) := by
    intro y hy
    have hyne : y ≠ x := (Finset.mem_erase.mp hy).1
    exact blockBB_k1_offdiag_eq_neg_one (b := b) x y (by
      intro h
      exact hyne h.symm)
  calc
    Finset.sum (Finset.univ.erase x) (fun y => LBB x y)
        = Finset.sum (Finset.univ.erase x) (fun _y => (-1 : ℝ)) := by
          refine Finset.sum_congr rfl ?_
          intro y hy
          exact hconst y hy
    _ = (((Finset.univ.erase x).card : ℝ) * (-1 : ℝ)) := by
          simp [Finset.sum_const, nsmul_eq_mul]
    _ = -((b : ℝ) - 1) := by
          have hcardF :
              (Finset.univ.erase x).card =
                Fintype.card (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) - 1 := by
            exact
              Finset.card_erase_of_mem
                (s := (Finset.univ : Finset (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)))
                (a := x) (Finset.mem_univ x)
          have hcardNat : (Finset.univ.erase x).card = b - 1 := by
            rw [_root_.PillarA.Ideal.TreeOfCliques.card_boundary1] at hcardF
            exact hcardF
          have hb0 : 0 < b := by
            rcases
              _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
                (b := b) x with ⟨d, hd⟩
            exact lt_of_le_of_lt (Nat.zero_le d.1) d.2
          have hb : 1 ≤ b := Nat.succ_le_of_lt hb0
          have hcardR : ((Finset.univ.erase x).card : ℝ) = (b : ℝ) - 1 := by
            rw [hcardNat, Nat.cast_sub hb]
            norm_num
          rw [hcardR]
          ring

/-- Diagonal entries of the `k=1` boundary block are `b`. -/
theorem blockBB_k1_diag_eq_b
    (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x x
      = (b : ℝ) := by
  classical
  let LBB :=
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))
  have hrow :
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, LBB x y) = (1 : ℝ) := by
    dsimp [LBB]
    exact sum_row_LBB_eq_one (b := b) x
  have hsplit :
      Finset.sum (Finset.univ.erase x)
        (fun y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 => LBB x y)
        + LBB x x =
      Finset.sum Finset.univ
        (fun y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 => LBB x y) := by
    exact Finset.sum_erase_add (s := Finset.univ) (a := x)
      (f := fun y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 => LBB x y) (by simp)
  have hoff :
      Finset.sum (Finset.univ.erase x)
        (fun y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 => LBB x y)
        = -((b : ℝ) - 1) := by
    simpa [LBB] using sum_offdiag_blockBB_k1_eq_neg_sub_one (b := b) x
  have hdiag : LBB x x = (1 : ℝ) - (-((b : ℝ) - 1)) := by
    linarith [hrow, hsplit, hoff]
  calc
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x x =
        (1 : ℝ) - (-((b : ℝ) - 1)) := by
      simpa [LBB] using hdiag
    _ = (b : ℝ) := by ring

/-- Explicit diagonal value of the stabilized DtN at `k=1`. -/
theorem dtn_stabilized_k1_diag_eq
    (p : _root_.PillarA.LayerA.Policy b)
    (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    let δ : ℝ :=
      _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
        (p := p)
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (_root_.PillarA.OQS.Split.DtNStabilized.symm
          (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
          (((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
            (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))))
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) x x
      = (b : ℝ) - ((b : ℝ) + δ)⁻¹ := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.OQS.Split.DtNStabilized.symm
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (s1.blockII L1))
  let Schur :
      Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
        (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) ℝ :=
    s1.blockBI L1 *
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1)⁻¹ *
      s1.blockIB L1
  have hSchur : Schur x x = ((b : ℝ) + δ)⁻¹ := by
    simpa [Schur, L1, s1, δ] using
      (schur_entry_const_k1 (b := b) (p := p) x x)
  calc
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) x x
        = s1.blockBB L1 x x - Schur x x := by
          simp [ _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized,
            _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
            _root_.PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
            _root_.PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
            _root_.PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
            _root_.PillarA.OQS.Split.DtNStabilized.LII_stabilized,
            _root_.PillarA.LayerA.DtN,
            Schur, L1, s1,
            Matrix.sub_apply]
    _ = (b : ℝ) - ((b : ℝ) + δ)⁻¹ := by
          rw [blockBB_k1_diag_eq_b (b := b) x, hSchur]

/-- The diagonal of the stabilized DtN at `k=1` is constant across boundary indices. -/
theorem dtn_stabilized_k1_diag_indep
    (p : _root_.PillarA.LayerA.Policy b)
    (x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) x x
      =
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) y y := by
  classical
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.OQS.Split.DtNStabilized.symm
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))))
  calc
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) x x
        = (b : ℝ) - ((b : ℝ) + δ)⁻¹ := by
            simpa [δ] using dtn_stabilized_k1_diag_eq (b := b) (p := p) x
    _ = (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) 1) y y := by
            symm
            simpa [δ] using dtn_stabilized_k1_diag_eq (b := b) (p := p) y

/-- There is no diagonal gap in the stabilized DtN at `k=1`. -/
theorem dtn_stabilized_k1_no_diag_gap
    (p : _root_.PillarA.LayerA.Policy b) :
    ¬ ∃ x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p) 1) x x
          ≠
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p) 1) y y := by
  intro h
  rcases h with ⟨x, y, hxy⟩
  exact hxy (dtn_stabilized_k1_diag_indep (b := b) (p := p) x y)

end ToC

end

end TreeOfCliques
end Instances
end Physics
end PillarA
