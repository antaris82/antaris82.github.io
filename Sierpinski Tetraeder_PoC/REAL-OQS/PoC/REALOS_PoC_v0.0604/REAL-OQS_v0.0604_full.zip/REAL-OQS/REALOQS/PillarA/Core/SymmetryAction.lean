import Mathlib
import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Core.RegionCore
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.BoundaryPorts
import REALOQS.PillarA.Core.Selection
import REALOQS.PillarA.Core.TailInterface

set_option autoImplicit false

namespace PillarA

namespace LayerA

open RegionCore

universe u v w

/-- A level-wise symmetry group action on a substrate. -/
structure SymmetryAction (Cell : Nat → Type u) [Substrate Cell] : Type (max (u+1) (v+1)) where
  /-- Symmetry group. -/
  G : Type v
  /-- Group structure. -/
  instGroup : Group G
  /-- Level-wise action on cells. -/
  act : ∀ {L : Nat}, G → Cell L → Cell L
  /-- Action law: identity. -/
  act_one : ∀ {L : Nat} (x : Cell L), act (L := L) (1 : G) x = x
  /-- Action law: multiplication. -/
  act_mul : ∀ {L : Nat} (g h : G) (x : Cell L),
      act (L := L) (g * h) x = act (L := L) g (act (L := L) h x)
  /-- Each group element acts bijectively on each level. -/
  act_bijective : ∀ {L : Nat} (g : G), Function.Bijective (act (L := L) g)
  /-- Parent map is equivariant (set-level statement). -/
  parents_equivariant :
    ∀ {L : Nat} (g : G) (c : Cell (L + 1)),
      Substrate.parents (Cell := Cell) (act (L := L + 1) g c)
        = (Substrate.parents (Cell := Cell) c).image (act (L := L) g)
  /-- Child map is equivariant (set-level statement). -/
  children_equivariant :
    ∀ {L : Nat} (g : G) (p : Cell L),
      Substrate.children (Cell := Cell) (act (L := L) g p)
        = (Substrate.children (Cell := Cell) p).image (act (L := L + 1) g)

attribute [instance] SymmetryAction.instGroup

namespace SymmetryAction

variable {Cell : Nat → Type u} [Substrate Cell]

/-- Action on a region (finite set) by `Finset.image`. -/
def actRegion (S : SymmetryAction (Cell := Cell)) {L : Nat} [DecidableEq (Cell L)] (g : S.G) :
    RegionAt Cell L → RegionAt Cell L :=
  fun R => R.image (S.act (L := L) g)

/-- Action on an approximant by acting on its visible cell set. -/
def actApproximant (S : SymmetryAction (Cell := Cell)) {L : Nat} [DecidableEq (Cell L)] (g : S.G) :
    Approximant Cell L → Approximant Cell L :=
  fun A => ⟨actRegion (Cell := Cell) S (L := L) g A.cells⟩

/-- Action on boundary ports (act on region and the port set). -/
def actBoundaryPorts (S : SymmetryAction (Cell := Cell)) {L : Nat} [DecidableEq (Cell L)]
    (g : S.G) (bp : BoundaryPorts Cell L) : BoundaryPorts Cell L :=
by
  refine ⟨actRegion (Cell := Cell) S (L := L) g bp.region,
          bp.ports.image (S.act (L := L) g), ?_⟩
  intro x hx
  rcases Finset.mem_image.1 hx with ⟨y, hy_ports, rfl⟩
  have hy_reg : y ∈ bp.region := bp.ports_subset hy_ports
  exact Finset.mem_image.2 ⟨y, hy_reg, rfl⟩

/-- Equivariance contract for a selector under a given symmetry action. -/
def SelectorEquivariant (S : SymmetryAction (Cell := Cell)) {L : Nat} [DecidableEq (Cell L)]
    (sel : Selector Cell L) : Prop :=
  ∀ g (A : Approximant Cell L),
    actRegion (Cell := Cell) S (L := L) g (sel.choose A)
      = sel.choose (actApproximant (Cell := Cell) S (L := L) g A)

/--
Equivariance contract for tail elimination.

This requires actions on the tail object and on the produced effective boundary data.
-/
structure TailEliminationEquivariant
    (S : SymmetryAction (Cell := Cell))
    [TailInterface (Cell := Cell)]
    [TailEliminationHook (Cell := Cell)] where
  actTail :
    ∀ {L : Nat}, S.G → TailInterface.TailAt (Cell := Cell) L → TailInterface.TailAt (Cell := Cell) L
  actEBD : ∀ {L : Nat}, S.G → TailEliminationHook.EBD (Cell := Cell) L →
    TailEliminationHook.EBD (Cell := Cell) L

  eliminate_equivariant :
    ∀ {L : Nat} [DecidableEq (Cell L)]
      (g : S.G) (A : Approximant Cell L)
      (T : TailInterface.TailAt (Cell := Cell) L)
      (bp : BoundaryPorts Cell L),
      actEBD (L := L) g (TailEliminationHook.eliminate (Cell := Cell) A T bp)
        =
      TailEliminationHook.eliminate (Cell := Cell)
        (actApproximant (Cell := Cell) S (L := L) g A)
        (actTail (L := L) g T)
        (actBoundaryPorts (Cell := Cell) S (L := L) g bp)

/-- Generic equivariance contract for a deterministic update kernel on a state space. -/
structure UpdateKernelEquivariant
    (S : SymmetryAction (Cell := Cell))
    (State : Type w) where
  actState : S.G → State → State
  step : State → State
  step_equivariant : ∀ g s, actState g (step s) = step (actState g s)

end SymmetryAction

end LayerA

end PillarA
