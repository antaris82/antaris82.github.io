/-
IDEAL adapter umbrella: concrete update instances derived from IDEAL substrates.

Import policy note:
Concrete, IDEAL-derived instantiations of `PillarA.Update.*` interfaces live
under `PillarA.Ideal.Adapter.*` so that `PillarA.Update.*` remains substrate
agnostic (ImportPolicy R2).
-/

import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAllCellsConsistency
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNSemantics
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNStabilizedSemantics
