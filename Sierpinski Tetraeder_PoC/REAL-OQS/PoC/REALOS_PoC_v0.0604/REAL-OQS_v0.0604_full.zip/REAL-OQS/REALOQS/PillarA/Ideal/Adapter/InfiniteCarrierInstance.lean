import Mathlib

import REALOQS.PillarA.Core.InfiniteCarrier
import REALOQS.PillarA.Core.InfiniteCarrierSymmetry
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance
import REALOQS.PillarA.Ideal.Adapter.IdealSymmetryNoether

set_option autoImplicit false

namespace PillarA

namespace Ideal

namespace Adapter

/-!
# IDEAL → `InfiniteCarrier` instance (Phase 9 smoke test)

This is an IDEAL-only adapter file that demonstrates that the Core inverse-limit
carrier (`PillarA.LayerA.InfiniteCarrier`) is **inhabited** for IDEAL whenever the
alphabet size `b` is nonzero.

We provide:

* a canonical coherent chain of IDEAL cells (always choosing the digit `0`),
* an `Inhabited` instance for `InfiniteCarrier (IdealCell b)` under `Fact (0 < b)`,
* a small gate lemma showing that the lifted Core action `actInf` is available on
  the IDEAL∞ carrier (no analysis; purely combinatorial).

No Core module imports IDEAL; this module lives entirely under `Ideal/Adapter/*`.
-/

open scoped BigOperators

open PillarA.LayerA

namespace InfiniteCarrierInstance

variable {b : Nat}

/-! ## Canonical digit and address/cell chain -/

/-- The canonical digit `0 : Fin b` (requires `0 < b`). -/
def zeroDigit (b : Nat) (hb : 0 < b) : Fin b := ⟨0, hb⟩

/-- Canonical address at level `L`: the list `[0,0, …, 0]` of length `L`. -/
def canonicalAddr (b : Nat) (hb : 0 < b) (L : Nat) : Addr b :=
  List.replicate L (zeroDigit b hb)

@[simp] theorem canonicalAddr_length (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalAddr b hb L).length = L := by
  simp [canonicalAddr]

/-- Small list lemma: taking `L` elements from the length `L+1` canonical address. -/
theorem take_replicate_succ {α : Type} (a : α) (L : Nat) :
    (List.replicate (Nat.succ L) a).take L = List.replicate L a := by
  induction L with
  | zero =>
      simp
  | succ L ih =>
      -- Reduce to the induction hypothesis using the simp equations for
      -- `List.replicate` and `List.take`.
      simpa [List.replicate, ih]

@[simp] theorem canonicalAddr_take (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalAddr b hb (L + 1)).take L = canonicalAddr b hb L := by
  simp [canonicalAddr, take_replicate_succ (a := zeroDigit b hb) L]

/-- Canonical IDEAL cell at level `L`. -/
def canonicalCell (b : Nat) (hb : 0 < b) (L : Nat) : IdealCell b L :=
  ⟨canonicalAddr b hb L,
    by
      apply (mem_cellsAtLevel_iff_length b L (canonicalAddr b hb L)).2
      simp [canonicalAddr]⟩

@[simp] theorem canonicalCell_val (b : Nat) (hb : 0 < b) (L : Nat) :
    (canonicalCell b hb L).1 = canonicalAddr b hb L := rfl

@[simp] theorem canonicalCell_parent (b : Nat) (hb : 0 < b) (L : Nat) :
    IdealCell.parent (b := b) (L := L) (canonicalCell b hb (L + 1))
      = canonicalCell b hb L := by
  ext
  simp [IdealCell.parent, canonicalAddr_take]

/-! ## Canonical IDEAL∞ carrier -/

/-- A canonical coherent chain of IDEAL cells (exists for `b > 0`). -/
def canonicalCarrier (b : Nat) (hb : 0 < b) :
    InfiniteCarrier (Cell := IdealCell b) :=
  { cell := fun L => canonicalCell b hb L
    coh := by
      intro L
      -- For deterministic substrates, `parents c` is the singleton `{parent c}`.
      rw [DeterministicSubstrate.parents_eq_singleton_parent
            (Cell := IdealCell b)
            (c := canonicalCell b hb (L + 1))]
      have hdp :
          (DeterministicSubstrate.parent (Cell := IdealCell b)
              (canonicalCell b hb (L + 1)))
            = canonicalCell b hb L := by
        -- In the IDEAL deterministic substrate instance, the deterministic parent
        -- is `IdealCell.parent`.
        change
          IdealCell.parent (b := b) (L := L) (canonicalCell b hb (L + 1))
            = canonicalCell b hb L
        exact canonicalCell_parent (b := b) (hb := hb) (L := L)
      -- Membership in the singleton is immediate.
      simp [hdp] }

/-! ## Inhabited instance (under `Fact (0 < b)`) -/

noncomputable instance (b : Nat) [Fact (0 < b)] :
    Inhabited (InfiniteCarrier (Cell := IdealCell b)) :=
  ⟨canonicalCarrier b (Fact.out : 0 < b)⟩

/-! ## Smoke gate: the IDEAL symmetry action lifts to IDEAL∞ via `actInf` -/

open PillarA.Ideal.IdealSymmetry

/-- The concrete (non-typeclass) symmetry action on `IdealCell b`. -/
noncomputable def idealSymm (b : Nat) : SymmetryAction (Cell := IdealCell b) :=
  PillarA.Ideal.IdealSymmetry.symmetryAction b

theorem gate_actInf_available (b : Nat) [Fact (0 < b)]
    (σ : DigitPerm b) (U : InfiniteCarrier (Cell := IdealCell b)) (L : Nat) :
    ((idealSymm b).actInf (Cell := IdealCell b) σ U).cell L
      = (idealSymm b).act (L := L) σ (U.cell L) := by
  rfl

end InfiniteCarrierInstance

end Adapter

end Ideal

end PillarA
