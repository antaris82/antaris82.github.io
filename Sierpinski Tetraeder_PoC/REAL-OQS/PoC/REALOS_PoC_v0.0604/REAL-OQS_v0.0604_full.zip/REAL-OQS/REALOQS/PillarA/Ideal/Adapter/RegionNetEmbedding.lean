import Mathlib

import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# IDEAL → RegionNet embedding (Adapter)

Moved out of `REALOQS.PillarA.Core.RegionNet` to keep `Core` IDEAL-free.
-/

namespace Ideal

open PillarA.Ideal

variable {b : Nat}

/-- Region corresponding to a cell address `w`: all addresses with prefix `w`. -/
def cellRegion (w : Addr b) : Set (Addr b) := {a | w <+: a}

/-- Refinement monotonicity: if `w₁` is a prefix of `w₂`, then `cellRegion w₂ ⊆ cellRegion w₁`. -/
theorem cellRegion_antitone {w₁ w₂ : Addr b} (h : w₁ <+: w₂) :
    cellRegion (b := b) w₂ ⊆ cellRegion (b := b) w₁ := by
  intro a ha
  rcases h with ⟨t₁, rfl⟩
  rcases ha with ⟨t₂, rfl⟩
  refine ⟨t₁ ++ t₂, by simp [List.append_assoc]⟩

/-- Special case: every child region is contained in its parent region. -/
theorem cellRegion_child_le (w : Addr b) (d : Fin b) :
    cellRegion (b := b) (PillarA.Ideal.child w d) ⊆ cellRegion (b := b) w := by
  intro a ha
  rcases ha with ⟨t, rfl⟩
  refine ⟨([d] ++ t), by simp [PillarA.Ideal.child, List.append_assoc]⟩

/-- Functoriality helper: monotone boundaries preserve the child≤parent inclusion. -/
theorem boundary_child_le
    (boundary : Set (Addr b) → Set (Addr b))
    (hmono : Monotone boundary)
    (w : Addr b) (d : Fin b) :
    boundary (cellRegion (b := b) (PillarA.Ideal.child w d))
      ≤ boundary (cellRegion (b := b) w) := by
  exact hmono (cellRegion_child_le (b := b) w d)

end Ideal

end LayerA

end PillarA
