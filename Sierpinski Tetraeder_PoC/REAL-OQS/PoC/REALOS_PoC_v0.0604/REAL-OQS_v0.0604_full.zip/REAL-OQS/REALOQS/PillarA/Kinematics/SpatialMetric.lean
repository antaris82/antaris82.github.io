import Mathlib
import REALOQS.PillarA.Core.ResistanceMetric

set_option autoImplicit false

/-!
REALOQS / Pillar A / Kinematics: spatial metric scaffold

We interpret a resistance metric as an *extended* nonnegative distance
(`ENNReal`, allowing `⊤` for disconnection). For a product type `V × T`,
Pillar A uses the simplest lift: ignore the second component and reuse the
metric from `V`.

This is a construction helper; the real physics/geometry content appears in
later pillars.
-/

namespace PillarA
namespace Kinematics

open PillarA.LayerA

variable {V T : Type}

/-- Product lift of a resistance metric: only the first component contributes. -/
noncomputable def prod (rm : ResistanceMetric V) : ResistanceMetric (V × T) :=
{ R := fun x y => rm.R x.1 y.1,
  symm := by
    intro x y
    simpa using rm.symm x.1 y.1,
  self := by
    intro x
    simpa using rm.self x.1 }

end Kinematics
end PillarA
