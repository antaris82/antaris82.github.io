import REALOQS.PillarA.Core.DirichletLaplacian

namespace PillarA
namespace Core

namespace DirichletLaplacianBridge

variable {V : Type} [Fintype V]

abbrev Weight (V : Type) :=
  PillarA.LayerA.Weight V

noncomputable def quadForm [DecidableEq V] (W : Weight V) (x : V → ℝ) : ℝ :=
  PillarA.LayerA.quadForm (V := V) W x

noncomputable def dirichletEnergy [DecidableEq V] (W : Weight V) (x : V → ℝ) : ℝ :=
  PillarA.LayerA.dirichletEnergy (V := V) W x

@[simp] theorem quadForm_eq [DecidableEq V] (W : Weight V) (x : V → ℝ) :
    quadForm (V := V) W x = PillarA.LayerA.quadForm (V := V) W x := by
  rfl

@[simp] theorem dirichletEnergy_eq [DecidableEq V] (W : Weight V) (x : V → ℝ) :
    dirichletEnergy (V := V) W x = PillarA.LayerA.dirichletEnergy (V := V) W x := by
  rfl

end DirichletLaplacianBridge

end Core
end PillarA
