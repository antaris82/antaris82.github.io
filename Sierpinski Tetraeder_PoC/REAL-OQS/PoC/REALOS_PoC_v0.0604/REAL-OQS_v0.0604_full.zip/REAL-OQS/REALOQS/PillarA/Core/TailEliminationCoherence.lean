import Mathlib

import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.BoundaryPorts
import REALOQS.PillarA.Core.TailInterface
import REALOQS.PillarA.Core.SymmetryAction

set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# Tail elimination coherence (Core, optional law bundle)

`TailEliminationHook` is intentionally an interface-only hook:

* given an `Approximant` at level `L`,
* a tail object `TailAt L`,
* and combinatorial `BoundaryPorts`,

it returns an abstract `EffectiveBoundaryData L`.

To connect this to the usual *compatibility under refinement / cutoffs*,
we provide **optional** (typeclass) projections between consecutive levels
and a minimal **coherence law** for one-step refinement.

No CP/CPTP or operator-algebra assumptions are made here.
-/

universe u v w

open TailInterface TailEliminationHook

/-- Optional projection of tails from level `L+1` down to level `L`.

This is the abstract replacement for "restrict the external environment"
when moving from a finer cutoff to a coarser one.
-/
class TailProject (Cell : Nat → Type u) [TailInterface (Cell := Cell)] where
  down : ∀ {L : Nat}, TailAt (Cell := Cell) (L + 1) → TailAt (Cell := Cell) L

/-- Optional projection of effective boundary data from level `L+1` down to level `L`.

This is the abstract replacement for "coarse-grain effective boundary data".
-/
class EBDProject (Cell : Nat → Type u)
    [TailInterface (Cell := Cell)] [TailEliminationHook (Cell := Cell)] where
  downEBD : ∀ {L : Nat}, EBD (Cell := Cell) (L + 1) → EBD (Cell := Cell) L

/-- Minimal one-step coherence law for tail elimination.

Interpretation:

Eliminating the tail at cutoff `L+1` and then projecting the effective boundary data
down to cutoff `L` must agree with first projecting the tail down and eliminating
already at cutoff `L`.

This is the diagrammatic "cutoff consistency" one needs before speaking about any
limit / thermodynamic / quasilocal constructions.
-/
structure TailEliminationCoherence (Cell : Nat → Type u)
    [Substrate Cell]
    [TailInterface (Cell := Cell)]
    [TailEliminationHook (Cell := Cell)]
    [TailProject (Cell := Cell)]
    [EBDProject (Cell := Cell)] where
  coherent_succ :
    ∀ {L : Nat} [DecidableEq (Cell L)],
      (A : Approximant Cell L) →
      (t : TailAt (Cell := Cell) (L + 1)) →
      (bp : BoundaryPorts Cell L) →
      EBDProject.downEBD (Cell := Cell)
          (L := L)
          (TailEliminationHook.eliminate
            (Cell := Cell)
            (L := L + 1)
            (Approximant.refine (Cell := Cell) A)
            t
            (BoundaryPorts.refine (Cell := Cell) (L := L) bp))
        =
        TailEliminationHook.eliminate
          (Cell := Cell)
          (L := L)
          A
          (TailProject.down (Cell := Cell) (L := L) t)
          bp

namespace TailEliminationCoherence

variable {Cell : Nat → Type u}
  [Substrate Cell]
  [TailInterface (Cell := Cell)]
  [TailEliminationHook (Cell := Cell)]
  [TailProject (Cell := Cell)]
  [EBDProject (Cell := Cell)]

theorem gate_TAIL_coherent_succ
    (C : TailEliminationCoherence (Cell := Cell))
    {L : Nat} [DecidableEq (Cell L)]
    (A : Approximant Cell L)
    (t : TailAt (Cell := Cell) (L + 1))
    (bp : BoundaryPorts Cell L) :
    EBDProject.downEBD (Cell := Cell)
        (L := L)
        (TailEliminationHook.eliminate
          (Cell := Cell)
          (L := L + 1)
          (Approximant.refine (Cell := Cell) A)
          t
          (BoundaryPorts.refine (Cell := Cell) (L := L) bp))
      =
      TailEliminationHook.eliminate
        (Cell := Cell)
        (L := L)
        A
        (TailProject.down (Cell := Cell) (L := L) t)
        bp :=
  C.coherent_succ (A := A) (t := t) (bp := bp)

end TailEliminationCoherence

/-!
## Optional symmetry law bundle (Tail elimination equivariance)

`PillarA.Core.SymmetryAction` defines the contract
`SymmetryAction.TailEliminationEquivariant`.

This file re-exports it as a *usable gate theorem* so downstream modules can require
equivariance of tail elimination without touching the definition-level details.
-/

namespace TailEliminationEquivariance

open SymmetryAction


variable {Cell : Nat → Type u}
  [Substrate Cell]
  [TailInterface (Cell := Cell)]
  [TailEliminationHook (Cell := Cell)]

theorem gate_TAIL_ELIMINATION_EQUIVARIANT
    (S : SymmetryAction (Cell := Cell))
    (Eqv : SymmetryAction.TailEliminationEquivariant (Cell := Cell) S)
    {L : Nat} [DecidableEq (Cell L)]
    (g : S.G) (A : Approximant Cell L)
    (T : TailInterface.TailAt (Cell := Cell) L)
    (bp : BoundaryPorts Cell L) :
    Eqv.actEBD (L := L) g (TailEliminationHook.eliminate (Cell := Cell) A T bp)
      =
      TailEliminationHook.eliminate (Cell := Cell)
        (SymmetryAction.actApproximant (Cell := Cell) S (L := L) g A)
        (Eqv.actTail (L := L) g T)
        (SymmetryAction.actBoundaryPorts (Cell := Cell) S (L := L) g bp) :=
  Eqv.eliminate_equivariant (L := L) g A T bp

end TailEliminationEquivariance

end LayerA
end PillarA
