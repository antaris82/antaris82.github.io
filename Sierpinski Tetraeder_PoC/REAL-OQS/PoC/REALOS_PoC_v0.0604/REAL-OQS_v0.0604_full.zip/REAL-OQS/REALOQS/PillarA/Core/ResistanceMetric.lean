import Mathlib

set_option linter.style.commandStart false

/-!
REALOQS / Pillar A / Core: Resistance metric interface

Pillar A keeps the resistance metric purely as an *interface*:
- no continuum input,
- no numerical solver assumptions,
- but stable, non-vacuous properties that later layers must discharge.

We model possible disconnection by allowing values in `ENNReal`:
- `R u v = ⊤` represents an undefined/infinite effective resistance.
- the induced distance is `d(u,v) = sqrt(R u v)`.

The canonical grounded+stabilized solve construction is packaged separately
in `ResistanceMetricCanonical.lean`.
-/

namespace PillarA
namespace LayerA

section Resistance

variable {V : Type}

/-- Extended nonnegative reals (allows `⊤` for disconnected pairs). -/
abbrev RInf := ENNReal

/-- Abstract resistance function with the minimal symmetry/reflexivity axioms. -/
structure ResistanceMetric (V : Type) where
  R : V → V → RInf
  symm : ∀ u v, R u v = R v u
  self : ∀ u, R u u = 0

/-- Induced distance `d(u,v) = sqrt(R(u,v))`.

Implementation note: we define `sqrt` using `rpow` to avoid relying on a dedicated
`ENNReal.sqrt` symbol.
-/
noncomputable def dist (rm : ResistanceMetric V) (u v : V) : RInf :=
  (rm.R u v) ^ ((1 : ℝ) / 2)

theorem gate_dist_self (rm : ResistanceMetric V) (u : V) : dist rm u u = 0 := by
  -- `simp` needs the explicit specialization `rm.self u`.
  simp [dist, rm.self u]

theorem gate_dist_symm (rm : ResistanceMetric V) (u v : V) : dist rm u v = dist rm v u := by
  simp [dist, rm.symm u v]

/-- Convenience: finiteness predicate for a pair. -/
def finiteR (rm : ResistanceMetric V) (u v : V) : Prop := rm.R u v ≠ (⊤ : RInf)

/-- Metric-style laws for `dist` (additional contracts, not derivable from the bare interface). -/
structure ResistanceMetricLaws (rm : ResistanceMetric V) : Prop where
  /-- Triangle inequality for the induced distance. -/
  triangle : ∀ u v w : V, dist rm u w ≤ dist rm u v + dist rm v w
  /-- Separation (on the finite part): if the distance is zero, the vertices coincide. -/
  eq_of_dist_eq_zero : ∀ {u v : V}, dist rm u v = 0 → u = v

end Resistance

end LayerA
end PillarA