/-
Backward-compatibility forwarder.

Historically, `REALOQS.PillarA.PillarA` was the primary umbrella import.

New recommended entry points:
- `REALOQS.PillarA.Interface` (canonical, substrate-agnostic)
- `REALOQS.PillarA.All`       (heavy developer umbrella)
-/

import REALOQS.PillarA.All
