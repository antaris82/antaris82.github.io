import REALOQS.PillarA.Ideal.Substrate

/-!
# IDEAL Adapter: Substrate

This file is a *thin re-export wrapper*.

Policy goal (Phase 8): outside of `PillarA.Ideal.*`, other modules should only
import IDEAL-specific material via `PillarA.Ideal.Adapter.*`.
-/
