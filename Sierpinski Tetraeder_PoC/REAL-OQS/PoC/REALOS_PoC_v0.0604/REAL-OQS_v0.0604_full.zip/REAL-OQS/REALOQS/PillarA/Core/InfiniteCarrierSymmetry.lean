import REALOQS.PillarA.Core.InfiniteCarrier
import REALOQS.PillarA.Core.SymmetryAction

set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# InfiniteCarrierSymmetry (Core, Phase 2)

Lift a level-wise `SymmetryAction` to an action on `InfiniteCarrier`.

The lift is pointwise on levels; coherence is preserved using
`parents_equivariant`.
-/

universe u

open SymmetryAction

variable {Cell : Nat → Type u} [Substrate Cell]

namespace SymmetryAction

/-- Pointwise lift of a `SymmetryAction` to the infinite carrier. -/
def actInf (S : SymmetryAction (Cell := Cell)) (g : S.G) :
    InfiniteCarrier (Cell := Cell) → InfiniteCarrier (Cell := Cell) :=
  fun U =>
    { cell := fun L => S.act (L := L) g (U.cell L)
      coh := by
        intro L
        -- Goal: `S.act g (U.cell L)` is a parent of `S.act g (U.cell (L+1))`.
        -- Use equivariance of `parents` to rewrite the parent set as an image.
        -- Then witness is exactly `U.cell L`.
        rw [S.parents_equivariant (L := L) g (U.cell (L + 1))]
        exact Finset.mem_image.2 ⟨U.cell L, U.coh L, rfl⟩ }

@[simp] theorem actInf_cell (S : SymmetryAction (Cell := Cell)) (g : S.G)
    (U : InfiniteCarrier (Cell := Cell)) (L : Nat) :
    (S.actInf (Cell := Cell) g U).cell L = S.act (L := L) g (U.cell L) :=
  rfl

theorem actInf_one (S : SymmetryAction (Cell := Cell))
    (U : InfiniteCarrier (Cell := Cell)) :
    S.actInf (Cell := Cell) (1 : S.G) U = U := by
  ext L
  simp [SymmetryAction.actInf, S.act_one]

theorem actInf_mul (S : SymmetryAction (Cell := Cell))
    (g h : S.G) (U : InfiniteCarrier (Cell := Cell)) :
    S.actInf (Cell := Cell) (g * h) U =
      S.actInf (Cell := Cell) g (S.actInf (Cell := Cell) h U) := by
  ext L
  simp [SymmetryAction.actInf, S.act_mul]

/-- Projection/level commutation as a simp-lemma. -/
@[simp] theorem proj_actInf (S : SymmetryAction (Cell := Cell)) (g : S.G)
    (U : InfiniteCarrier (Cell := Cell)) (L : Nat) :
    (InfiniteCarrier.proj (Cell := Cell) (S.actInf (Cell := Cell) g U) L)
      = S.act (L := L) g (InfiniteCarrier.proj (Cell := Cell) U L) :=
  rfl

end SymmetryAction

end LayerA
end PillarA
