import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarA.Update.TailEliminationDtN
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary

set_option autoImplicit false

/-!
# Tree-of-Cliques: canonical dependent scale-breaking axis (Phase 7 critical path)

This module provides a **parameter-free** `ScaleBreakingAxisD` for Tree-of-Cliques:

* carrier at scale `k`: boundary-boundary matrices `S k := Matrix (Boundary b k) (Boundary b k) ℝ`;
* REAL tower: stabilized DtN on the Tree-of-Cliques Laplacian (`DtNStabilized.dtn_stabilized`);
* IDEAL tower: canonical uniform refinement (`CoarsenBoundary.idealTower`);
* coarsen map: block-summation over `π_k` fibers (`CoarsenBoundary.coarsenMat`);
* diagnostics: mismatch-based (`axis_fromMismatchD`) using Frobenius norm.

    External inputs are limited to the policy `p : Policy b` and the normalization floor
    `eps > 0`.
-/

namespace PillarA
namespace Physics
namespace Instances
namespace TreeOfCliques

noncomputable section

open _root_.PillarA
open _root_.PillarA.Update
open _root_.PillarA.Physics

namespace ToC

variable {b : Nat}

/-- Boundary family at scale `k`. -/
abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

/-- Carrier family at scale `k`: boundary-boundary matrices. -/
abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

/-! ## Canonical observer and mismatch family -/

/-- Observe a boundary matrix as a `LinOp` via `mulVec`. -/
noncomputable def Obs (b : Nat) : OpObserverD (S b) (α b) := by
  classical
  refine { op := ?_ }
  intro k M
  exact _root_.PillarA.Update.linOpOfMatrix (α := α b k) M

/-- Frobenius-norm mismatch on each boundary type `α k`. -/
noncomputable def M (b : Nat) : ∀ k, MismatchFunctional (α := α b k) := by
  classical
  intro k
  exact _root_.PillarA.Update.MismatchFunctional.NormDiff.mkId (α := α b k)

/-! ## Canonical qualitative axis (towers + coarsen) -/


/-- Canonical qualitative dependent axis (diagnostics set to `0`). -/
def axis0 (b : Nat) (p : _root_.PillarA.LayerA.Policy b) :
    ScaleBreakingAxisD (S b) :=
  { coarsen := fun k =>
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat (b := b) (k := k)
    , ideal := fun k =>
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.idealTower (b := b) k
    , real := fun k =>
        _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p) (k := k)
    , breakMeasure := fun _ => 0
    , breakMeasureIdeal := fun _ => 0 }

/-! ## Phase-7 target: mismatch-upgraded canonical axis -/

/-- Fully canonical dependent axis: `axis0` upgraded with mismatch-based diagnostics. -/
noncomputable def axis_canonicalD
    (p : _root_.PillarA.LayerA.Policy b) :
    ScaleBreakingAxisD (S b) :=
  axis_fromMismatchD
    (S := S b) (α := α b)
    (A := axis0 (b := b) (p := p))
    (Obs := Obs b)
    (M := M b)
    (eps := p.eps)
    (eps_pos := p.eps_pos)



end ToC

end

end TreeOfCliques
end Instances
end Physics
end PillarA
