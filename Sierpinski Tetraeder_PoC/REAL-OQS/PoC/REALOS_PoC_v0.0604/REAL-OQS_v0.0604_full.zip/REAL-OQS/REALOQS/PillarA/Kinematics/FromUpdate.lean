import Mathlib

import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option autoImplicit false
set_option linter.style.longLine false

/-!
REALOQS / Pillar A / Layer A: Kinematics anchor from the update pipeline

This file provides a minimal, substrate-agnostic *bridge* from the update layer
(`TwoStageApprox` + its observation contract) to kinematics objects:

* A canonical discrete spacetime whose events are `(time, finestCell)`.
* A construction of a `DiscreteSpacetime.WorldTube` from a time-indexed run of states
  by marking those finest cells that satisfy an observer predicate.

This does **not** inject any continuum geometry. It is meant as a stable interface
for later layers to strengthen (e.g. nontrivial causal steps, spatial metrics, proper
-time costs) once additional structure becomes available.
-/

namespace PillarA
namespace Kinematics

open PillarA.Update

namespace FromUpdate

universe u

variable {b : Nat} (A : TwoStageApprox b)

/-- Canonical event type: discrete time paired with a finest-level cell. -/
abbrev Event : Type u := Nat × A.FinestCell

/-- Canonical discrete spacetime on `(time, cell)`.

The one-step causal relation advances time by one while keeping the cell label fixed.
This is a minimal placeholder; later layers can refine `step`.
-/
noncomputable def canonicalSpacetime : DiscreteSpacetime (Event (A := A)) where
  τ := Prod.fst
  step := fun x y => y.1 = x.1 + 1 ∧ y.2 = x.2
  step_tau := by
    intro x y h
    simpa using h.1

/-- Embedding of cells into events at a fixed time `n`. -/
def eventEmbed (n : Nat) : A.FinestCell ↪ Event (A := A) where
  toFun := fun w => (n, w)
  inj' := by
    intro a b h
    -- compare second components
    exact congrArg Prod.snd h

/-- The set of observed finest cells at a given state, expressed as a `Finset`.

This uses classical decidability for the observer predicate.
-/
noncomputable def observedCells
    [C : TwoStageApprox.AllCellsConsistency (A := A)]
    (m : SubsystemMode A.FinestCell) (s : A.S) : Finset A.FinestCell := by
  classical
  exact A.finestCells.filter (fun w => decide (C.Obs w (A.pipeline m s)))

/-- A worldtube induced by an observed-cells predicate along a time-indexed run of states.

`run n` is interpreted as the internal state at discrete time `n`.
-/
noncomputable def worldTubeOfRun
    [C : TwoStageApprox.AllCellsConsistency (A := A)]
    (m : SubsystemMode A.FinestCell) (run : Nat → A.S) :
    (canonicalSpacetime (A := A)).WorldTube := by
  classical
  refine ⟨?_, ?_⟩
  · intro n
    exact (observedCells (A := A) (m := m) (s := run n)).map (eventEmbed (A := A) n)
  · intro n x hx
    -- `x` comes from mapping `w ↦ (n,w)` so it is automatically adapted to slice `n`.
    rcases Finset.mem_map.mp hx with ⟨w, hw, rfl⟩
    rfl

end FromUpdate

end Kinematics
end PillarA
