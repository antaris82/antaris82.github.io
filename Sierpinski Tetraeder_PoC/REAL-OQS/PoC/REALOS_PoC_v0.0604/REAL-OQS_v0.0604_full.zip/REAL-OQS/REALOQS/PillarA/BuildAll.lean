import REALOQS.PillarA.All

/-!
# Pillar A BuildAll

Convenience build target to compile the full Pillar A developer umbrella
(including IDEAL adapters and scaffold layers).

This is intentionally not the recommended import for downstream users.
-/
