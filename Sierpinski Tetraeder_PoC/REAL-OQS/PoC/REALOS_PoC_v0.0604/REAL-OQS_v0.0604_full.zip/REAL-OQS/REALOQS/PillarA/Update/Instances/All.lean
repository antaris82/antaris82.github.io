/-
Deprecated umbrella: concrete update instances must live outside `PillarA/Update/*`
(import policy: Update must not import Ideal).

This module is kept only for backwards compatibility with older import paths.
-/
import REALOQS.PillarA.Update.Instances.TreeOfCliquesApprox
import REALOQS.PillarA.Update.Instances.TreeOfCliquesDtNSemantics
