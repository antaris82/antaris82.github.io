import Mathlib
import REALOQS.PillarA.Ideal.TreeOfCliques.Boundary

set_option autoImplicit false

/-!
# Tree-of-Cliques: canonical boundary coarsening (`π_k`) and matrix coarsen/refine

Purely combinatorial infrastructure on the boundary addresses:

* `π_k : Boundary b (k+1) → Boundary b k` via `List.dropLast`;
* `coarsenMat` as block-summation over `π_k`-fibers;
* `refineMat` as the canonical constant section (uniform refinement);
* sanity lemmas `coarsenMat (refineMat A) = A` and `coarsenMat (idealTower (k+1)) = idealTower k`.

No dynamics, no DtN.
-/

namespace PillarA
namespace Ideal
namespace TreeOfCliques
namespace CoarsenBoundary

noncomputable section

open scoped BigOperators

variable {b k : Nat}

/-- Abbreviation for the Tree-of-Cliques boundary type at level `k`. -/
abbrev Boundary (b k : Nat) : Type := _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

/-!
## `π_k : Boundary (k+1) → Boundary k`
-/

/-- Parent / prefix map on boundary addresses: drop the last digit. -/
def π (b k : Nat) : Boundary b (k + 1) → Boundary b k := by
  intro x
  refine ⟨x.1.dropLast, ?_⟩
  have hxlen : x.1.length = k + 1 :=
    (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length b (k + 1) x.1).1 x.2
  have hdrop : x.1.dropLast.length = k := by
    calc
      x.1.dropLast.length = x.1.length - 1 := List.length_dropLast (xs := x.1)
      _ = k := by simp [hxlen]
  exact (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length b k x.1.dropLast).2 hdrop

/-!
## Helper: canonical children
-/

/-- Append one digit to a boundary address (canonical child). -/
def mkChild (b k : Nat) (i : Boundary b k) (d : Fin b) : Boundary b (k + 1) := by
  refine ⟨i.1 ++ [d], ?_⟩
  have hi_len : i.1.length = k :=
    (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length b k i.1).1 i.2
  have hlen : (i.1 ++ [d]).length = k + 1 := by
    simp [List.length_append, hi_len]
  exact (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length b (k + 1) (i.1 ++ [d])).2 hlen

@[simp]
theorem π_mkChild (b k : Nat) (i : Boundary b k) (d : Fin b) : π b k (mkChild b k i d) = i := by
  classical
  apply Subtype.ext
  simp [π, mkChild, List.dropLast_append_of_ne_nil]

theorem mkChild_injective (b k : Nat) (i : Boundary b k) : Function.Injective (mkChild b k i) := by
  classical
  intro d₁ d₂ h
  have haddr : (i.1 ++ [d₁]) = (i.1 ++ [d₂]) := by
    simpa [mkChild] using congrArg Subtype.val h
  have hsing : ([d₁] : List (Fin b)) = [d₂] :=
    List.append_cancel_left haddr
  exact (List.singleton_inj).1 hsing

/-!
## Fibers and matrix coarsen/refine
-/

/-- The `π`-fiber over a boundary node `i` at scale `k`. -/
def fiber (b k : Nat) (i : Boundary b k) : Finset (Boundary b (k + 1)) :=
  Finset.univ.filter (fun x => π b k x = i)

@[simp]
theorem mem_fiber_iff (b k : Nat) (i : Boundary b k) (x : Boundary b (k + 1)) :
    x ∈ fiber b k i ↔ π b k x = i := by
  classical
  simp [fiber]

theorem fiber_eq_image_mkChild (b k : Nat) (i : Boundary b k) :
    fiber b k i = (Finset.univ : Finset (Fin b)).image (mkChild b k i) := by
  classical
  ext x
  constructor
  · intro hx
    have hπ : π b k x = i := (mem_fiber_iff b k i x).1 hx
    have hπ_val : x.1.dropLast = i.1 := congrArg Subtype.val hπ
    have hxlen : x.1.length = k + 1 :=
      (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length b (k + 1) x.1).1 x.2
    have hx_ne : x.1 ≠ [] := by
      apply List.ne_nil_of_length_pos
      simp [hxlen]
    let d : Fin b := x.1.getLast hx_ne
    have hx_recon : x.1.dropLast ++ [d] = x.1 := by
      dsimp [d]
      exact (List.dropLast_append_getLast (l := x.1) hx_ne)
    have hx_addr : i.1 ++ [d] = x.1 := by
      rw [hπ_val.symm]
      exact hx_recon
    refine Finset.mem_image.2 ?_
    refine ⟨d, by simp, ?_⟩
    apply Subtype.ext
    simp [mkChild, hx_addr]
  · intro hx
    rcases Finset.mem_image.1 hx with ⟨d, hd, rfl⟩
    simp [fiber, π_mkChild]

theorem fiber_card (b k : Nat) (i : Boundary b k) : (fiber b k i).card = b := by
  classical
  have hEq : fiber b k i = (Finset.univ : Finset (Fin b)).image (mkChild b k i) :=
    fiber_eq_image_mkChild b k i
  have hinj : Function.Injective (mkChild b k i) := mkChild_injective b k i
  have hcard :=
    Finset.card_image_of_injective
      (s := (Finset.univ : Finset (Fin b)))
      (f := mkChild b k i)
      hinj
  rw [hEq]
  calc
    (Finset.image (mkChild b k i) (Finset.univ : Finset (Fin b))).card
        = (Finset.univ : Finset (Fin b)).card := hcard
    _ = b := by simp

/-- Coarsen a boundary matrix by block-summation over `π`-fibers. -/
noncomputable def coarsenMat (b k : Nat) :
    Matrix (Boundary b (k + 1)) (Boundary b (k + 1)) ℝ →
      Matrix (Boundary b k) (Boundary b k) ℝ :=
  fun M i j =>
    (fiber b k i).sum (fun x => (fiber b k j).sum (fun y => M x y))

/-- Canonical refinement section: constant on fibers, normalized by `b^2`. -/
noncomputable def refineMat (b k : Nat) :
    Matrix (Boundary b k) (Boundary b k) ℝ →
      Matrix (Boundary b (k + 1)) (Boundary b (k + 1)) ℝ :=
  fun A x y => A (π b k x) (π b k y) / ((b : ℝ) ^ 2)

private theorem sum_const_real {α : Type} (s : Finset α) (c : ℝ) :
    s.sum (fun _ => c) = (s.card : ℝ) * c := by
  classical
  simp [Finset.sum_const, nsmul_eq_mul]

/-- Sanity: coarsening the canonical refinement recovers the original matrix (requires `0 < b`). -/
theorem coarsenMat_refineMat (b k : Nat)
    (hb : 0 < b)
    (A : Matrix (Boundary b k) (Boundary b k) ℝ) :
    coarsenMat b k (refineMat b k A) = A := by
  classical
  ext i j
  let Fi : Finset (Boundary b (k + 1)) := fiber b k i
  let Fj : Finset (Boundary b (k + 1)) := fiber b k j
  have hFi_card : Fi.card = b := by
    dsimp [Fi]
    exact fiber_card b k i
  have hFj_card : Fj.card = b := by
    dsimp [Fj]
    exact fiber_card b k j

  have hxπ : ∀ x ∈ Fi, π b k x = i := by
    intro x hx
    have hx' := hx
    dsimp [Fi] at hx'
    exact (mem_fiber_iff b k i x).1 hx'
  have hyπ : ∀ y ∈ Fj, π b k y = j := by
    intro y hy
    have hy' := hy
    dsimp [Fj] at hy'
    exact (mem_fiber_iff b k j y).1 hy'

  have hconst :
      Fi.sum (fun x => Fj.sum (fun y => refineMat b k A x y))
        = Fi.sum (fun x => Fj.sum (fun y => A i j / ((b : ℝ) ^ 2))) := by
    refine Finset.sum_congr rfl ?_
    intro x hx
    refine Finset.sum_congr rfl ?_
    intro y hy
    simp [refineMat, hxπ x hx, hyπ y hy]

  have hsum :
      Fi.sum (fun x => Fj.sum (fun y => A i j / ((b : ℝ) ^ 2)))
        = (Fi.card : ℝ) * ((Fj.card : ℝ) * (A i j / ((b : ℝ) ^ 2))) := by
    calc
      Fi.sum (fun x => Fj.sum (fun y => A i j / ((b : ℝ) ^ 2)))
          = Fi.sum (fun _ => (Fj.card : ℝ) * (A i j / ((b : ℝ) ^ 2))) := by
              refine Finset.sum_congr rfl ?_
              intro x hx
              exact (sum_const_real (s := Fj) (c := A i j / ((b : ℝ) ^ 2)))
      _   = (Fi.card : ℝ) * ((Fj.card : ℝ) * (A i j / ((b : ℝ) ^ 2))) := by
              exact (sum_const_real (s := Fi)
                (c := (Fj.card : ℝ) * (A i j / ((b : ℝ) ^ 2))))

  have hb0 : (b : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt hb)
  have hb2 : ((b : ℝ) ^ 2) ≠ 0 := pow_ne_zero 2 hb0

  calc
    (coarsenMat b k (refineMat b k A)) i j
        = Fi.sum (fun x => Fj.sum (fun y => refineMat b k A x y)) := by
            simp [coarsenMat, Fi, Fj]
    _   = Fi.sum (fun x => Fj.sum (fun y => A i j / ((b : ℝ) ^ 2))) := hconst
    _   = (Fi.card : ℝ) * ((Fj.card : ℝ) * (A i j / ((b : ℝ) ^ 2))) := hsum
    _   = (b : ℝ) * ((b : ℝ) * (A i j / ((b : ℝ) ^ 2))) := by
            simp [hFi_card, hFj_card]
    _   = A i j := by
      have hcancel : ((b : ℝ) ^ 2) * (A i j / ((b : ℝ) ^ 2)) = A i j := by
        field_simp [hb2]
      calc
        (b : ℝ) * ((b : ℝ) * (A i j / ((b : ℝ) ^ 2)))
            = ((b : ℝ) ^ 2) * (A i j / ((b : ℝ) ^ 2)) := by
                simp [pow_two, mul_assoc]
        _ = A i j := hcancel

/-!
## Canonical IDEAL tower on boundary matrices
-/

/-- Canonical IDEAL tower on boundary matrices, defined by uniform refinement. -/
noncomputable def idealTower (b : Nat) : ∀ k, Matrix (Boundary b k) (Boundary b k) ℝ
  | 0 => by
      classical
      exact fun i j => if i = j then 1 else 0
  | k + 1 => refineMat b k (idealTower b k)

/-- IDEAL tower is scale-invariant under canonical coarsening (requires `0 < b`). -/
theorem coarsenMat_idealTower (b k : Nat) (hb : 0 < b) :
    coarsenMat b k (idealTower b (k + 1)) = idealTower b k := by
  simpa [idealTower] using
    (coarsenMat_refineMat (b := b) (k := k) hb (idealTower b k))

end

end CoarsenBoundary
end TreeOfCliques
end Ideal
end PillarA
