import REALOQS.PillarA.Ideal.TreeOfCliques.Vertex

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

/-- Boundary at level `k`: all addresses of length exactly `k`. -/
abbrev Boundary (b k : Nat) : Type := ↥(cellsAtLevel b k)

/-- The full vertex set contains the boundary (since it contains all levels ≤ k). -/
theorem cellsAtLevel_subset_cellsUpTo (b : Nat) :
    ∀ k : Nat, cellsAtLevel b k ⊆ cellsUpTo b k
  | 0 => by
      intro a ha
      -- Rewrite the goal to `a ∈ cellsAtLevel b 0`.
      simp [cellsUpTo]
      exact ha
  | k+1 => by
      intro a ha
      -- Unfolding `cellsUpTo` rewrites the goal to a membership disjunction.
      -- Close with the right disjunct given by `ha`.
      simp [cellsUpTo]
      exact Or.inr ha

/-- Inclusion of boundary nodes into the full vertex type. -/
def boundaryEmbedding (b k : Nat) : Boundary b k → Vertex b k := by
  intro x
  refine ⟨x.1, ?_⟩
  -- Note: `⊆` for finsets is `∀ ⦃a⦄, a ∈ A → a ∈ B` with implicit element.
  exact (cellsAtLevel_subset_cellsUpTo b k) x.2

/-- Interior set at depth `k`: vertices up to `k` excluding the boundary at `k`. -/
def interiorSet (b k : Nat) : Finset (Addr b) :=
  (cellsUpTo b k) \ (cellsAtLevel b k)

/-- Interior type at depth `k`. -/
abbrev Interior (b k : Nat) : Type := ↥(interiorSet b k)

/-- Inclusion of interior nodes into the full vertex type. -/
def interiorEmbedding (b k : Nat) : Interior b k → Vertex b k := by
  intro x
  refine ⟨x.1, ?_⟩
  exact (Finset.mem_sdiff.mp x.2).1

end TreeOfCliques
end Ideal
end PillarA
