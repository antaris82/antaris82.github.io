import REALOQS.PillarA.Core.Gates


set_option linter.style.longLine false

/-!
REALOQS / Pillar A / Layer A: Dirichlet Form ↔ Laplacian Quadratic Form

This module provides the discrete **Dirichlet energy** (conductance form) and proves the
key identity

  `𝓔_c(f) = ⟪f, (L_c · f)⟫`

for the Laplacian `L_c` defined in `Gates.lean`, assuming symmetry of conductances.

This is the minimal, discrete “generator semantics” hook needed for the later Pillar‑B AQFT
lift (KMS/modular theory): energies are represented as quadratic forms of the (symmetric)
generator.

The Markov property is provided only as a **gate hook** at Pillar‑A level; the fully
functional-analytic proof belongs to Pillar B.
-/

set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace LayerA

section Dirichlet

variable {V : Type} [Fintype V] [DecidableEq V]

/-! ### Dirichlet energy -/

/-- Off-diagonal part of a weight: it is forced to `0` on the diagonal. -/
def offDiag (c : Weight V) (i j : V) : ℝ := if j = i then 0 else c i j

/-- Discrete Dirichlet energy

`𝓔_c(f) = (1/2) ∑_{i,j} cᵒᶠᶠ(i,j) (f(i)-f(j))^2`.

We use `offDiag` to align exactly with the Laplacian convention in `Gates.lean`
(diagonal ignored in `degree`).
-/
noncomputable def dirichletEnergy (c : Weight V) (f : V → ℝ) : ℝ := (1 / 2 : ℝ) * ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j)^2

/-- Quadratic form `⟪f, Λ f⟫` with the standard dot product on `V → ℝ`. -/
def quadForm (Λ : Matrix V V ℝ) (f : V → ℝ) : ℝ :=
  ∑ i, f i * (Λ.mulVec f) i

/-! ### Helper double sums -/

def Sii (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f i) ^ 2

def Sij (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f i) * (f j)

def Sjj (c : Weight V) (f : V → ℝ) : ℝ := ∑ i : V, ∑ j : V, offDiag c i j * (f j) ^ 2

lemma degree_eq_sum_offDiag (c : Weight V) (i : V) :
    degree c i = ∑ j : V, offDiag c i j := by
  simp [degree, offDiag]

lemma Sii_eq_degree (c : Weight V) (f : V → ℝ) :
    Sii c f = ∑ i : V, (degree c i) * (f i) ^ 2 := by
  classical
  -- By definition of $S_{ii}$, we can rewrite it using the linearity of summation.
  simp [PillarA.LayerA.Sii, PillarA.LayerA.degree];
  -- By definition of `offDiag`, we can split the sum into two parts: when `j = i` and when `j ≠ i`.
  simp [PillarA.LayerA.offDiag];
  -- By factoring out $f(x)^2$ from the inner sum, we can rewrite the left-hand side as the sum of $f(x)^2$ multiplied by the sum of $c(x,j)$ over $j$ where $j \neq x$.
  simp [mul_comm, Finset.mul_sum]

omit [Fintype V] in
lemma offDiag_symm_of_symm
    (c : Weight V) (hsymm : ∀ i j, c i j = c j i) (i j : V) :
    offDiag c i j = offDiag c j i := by
  by_cases h : j = i
  · subst h; simp [offDiag]
  · have h' : i ≠ j := by exact ne_comm.mp h
    simp [offDiag, h, h', hsymm]

lemma Sjj_eq_degree_of_symm
    (c : Weight V) (hsymm : ∀ i j, c i j = c j i) (f : V → ℝ) :
    Sjj c f = ∑ j : V, (degree c j) * (f j) ^ 2 := by
  classical
  -- By definition of $degree$, we can rewrite the sum as $\sum_{j} \sum_{i} offDiag c i j * (f j)^2$.
  have h_sum_eq : ∑ j, ∑ i, offDiag c i j * (f j) ^ 2 = ∑ j, (degree c j) * (f j) ^ 2 := by
    -- By definition of offDiag, we can rewrite the sum as ∑ j, ∑ i, c i j * f j^2.
    simp [offDiag];
    exact Finset.sum_congr rfl fun i hi => by rw [ show PillarA.LayerA.degree c i = ∑ j : V, if j = i then 0 else c i j by rfl ] ; rw [ Finset.sum_mul _ _ _ ] ; exact Finset.sum_congr rfl fun j hj => by aesop;
  -- By definition of $Sjj$, we can rewrite the sum as $\sum_{i} \sum_{j} offDiag c i j * (f j)^2$.
  have h_sum_eq : ∑ i, ∑ j, offDiag c i j * (f j) ^ 2 = ∑ j, ∑ i, offDiag c i j * (f j) ^ 2 := by
    exact Finset.sum_comm;
  convert h_sum_eq.trans ‹_› using 1

lemma dirichletEnergy_expand (c : Weight V) (f : V → ℝ) :
    dirichletEnergy c f = (1 / 2 : ℝ) * (Sii c f - 2 * Sij c f + Sjj c f) := by
  classical
  -- By expanding the sum in the Dirichlet energy, we can split it into three separate sums.
  have h_expand : ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2 = ∑ i : V, ∑ j : V, offDiag c i j * (f i) ^ 2 - 2 * ∑ i : V, ∑ j : V, offDiag c i j * (f i) * (f j) + ∑ i : V, ∑ j : V, offDiag c i j * (f j) ^ 2 := by
    simp +decide only [sub_sq, mul_assoc, mul_left_comm, Finset.mul_sum _ _ _];
    -- By linearity of summation, we can split the sum into three separate sums.
    simp [mul_sub, mul_add, Finset.sum_add_distrib, Finset.sum_sub_distrib];
    -- By commutativity of multiplication, we can rearrange the terms in the sum.
    simp [mul_assoc, mul_comm, mul_left_comm];
  convert congr_arg ( fun x : ℝ => ( 1 / 2 : ℝ ) * x ) h_expand using 1

lemma quadForm_laplacian_eq_degree_sub_Sij (c : Weight V) (f : V → ℝ) :
    quadForm (laplacian c) f
      = (∑ i : V, (degree c i) * (f i) ^ 2) - Sij c f := by
  classical
  -- By definition of the Laplacian, we can split the sum into two parts: the sum over i = j and the sum over i ≠ j. The sum over i = j is Sii, and the sum over i ≠ j is -Sij.
  have h_split : quadForm (laplacian c) f = ∑ i, f i * (∑ j, (laplacian c i j) * f j) := by
    exact rfl
  -- By definition of the Laplacian, we can split the sum into two parts: the sum over i = j and the sum over i ≠ j. The sum over i = j is Sii, and the sum over i ≠ j is -Sij. Therefore, we can write:
  have h_split : ∑ i, f i * (∑ j, (laplacian c i j) * f j) = ∑ i, f i * (degree c i * f i - ∑ j, offDiag c i j * f j) := by
    congr with i ; simp +decide [ PillarA.LayerA.laplacian, PillarA.LayerA.degree, PillarA.LayerA.offDiag ];
    simp +decide [ Finset.sum_ite, Finset.filter_eq, Finset.filter_ne, sub_eq_add_neg ];
    simp +decide [ Finset.filter_ne' ];
    exact mul_eq_mul_left_iff.mp rfl
  -- By definition of Sij, we can rewrite the sum as Sii - Sij.
  have h_Sij : ∑ i, f i * (∑ j, offDiag c i j * f j) = Sij c f := by
    exact Finset.sum_congr rfl fun i hi => by rw [ Finset.mul_sum _ _ _ ] ; exact Finset.sum_congr rfl fun j hj => by ring;
  simp_all +decide [ mul_sub, mul_assoc, mul_comm, pow_two ]

theorem gate_DIRICHLET_EQ_LAPLACIAN_QUAD
    (c : Weight V)
    (hsymm : ∀ i j, c i j = c j i)
    (f : V → ℝ) :
    dirichletEnergy c f = quadForm (laplacian c) f := by
  classical
  -- By combining the results from `dirichletEnergy_expand` and `quadForm_laplacian_eq_degree_sub_Sij`, we can conclude the proof.
  have h_final : dirichletEnergy c f = (1 / 2 : ℝ) * (Sii c f - 2 * Sij c f + Sjj c f) ∧ quadForm (laplacian c) f = (∑ i : V, (degree c i) * (f i) ^ 2) - Sij c f := by
    exact ⟨ dirichletEnergy_expand c f, quadForm_laplacian_eq_degree_sub_Sij c f ⟩;
  linarith [ Sii_eq_degree c f, Sjj_eq_degree_of_symm c hsymm f ]

theorem gate_DIRICHLET_NONNEG
    (c : Weight V) (hnonneg : ∀ i j, 0 ≤ c i j) (f : V → ℝ) :
    0 ≤ dirichletEnergy c f := by
  classical
  unfold dirichletEnergy
  -- `offDiag c i j ≥ 0` follows from `hnonneg` (and `0` on the diagonal).
  have hoff : ∀ i j, 0 ≤ offDiag c i j := by
    intro i j
    by_cases h : j = i
    · subst h; simp [offDiag]
    · simp [offDiag, h, hnonneg]
  -- each summand is nonnegative: `offDiag * (Δ)^2`.
  have hterm : ∀ i j, 0 ≤ offDiag c i j * (f i - f j) ^ 2 := by
    intro i j
    exact mul_nonneg (hoff i j) (sq_nonneg (f i - f j))
  -- sum over finite sets preserves nonnegativity.
  have : 0 ≤ ∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2 := by
    refine Finset.sum_nonneg ?_
    intro i hi
    refine Finset.sum_nonneg ?_
    intro j hj
    exact hterm i j
  -- multiply by 1/2 ≥ 0.
  nlinarith

/-! ### Markov property (contract hook, non-vacuous) -/

/-!
The Markov property of a Dirichlet form is a key ingredient for later analytic structure
(e.g. semigroups and positivity). At Pillar‑A level we do **not** attempt the analytic
proof; instead we expose a *non-vacuous* contract.

We fix a canonical normal contraction: `clamp01(x) = max 0 (min 1 x)`.
The Markov contract requires the energy to be non-increasing under this contraction.

Layer B / Pillar B can strengthen this to arbitrary normal contractions.
-/

/-- Canonical clamp into the interval `[0,1]`. -/
def clamp01 (x : ℝ) : ℝ := max (0 : ℝ) (min (1 : ℝ) x)

/-!
### Nonexpansiveness of `clamp01`

`DirichletMarkovHook.mkOfNonneg` needs a pointwise contraction estimate for `clamp01`.
This estimate is exposed as a standalone lemma so later constructors can depend on a single reusable result.
-/

/-- `clamp01` is nonexpansive (1‑Lipschitz) on `ℝ`. -/
lemma clamp01_nonexpansive (x y : ℝ) : |clamp01 x - clamp01 y| ≤ |x - y| := by
  -- Direct finite case split on the order of `x,y` relative to `0` and `1`.
  unfold PillarA.LayerA.clamp01;
  cases max_cases ( 0 : ℝ ) ( Min.min 1 x ) <;> cases max_cases ( 0 : ℝ ) ( Min.min 1 y ) <;> cases min_cases ( 1 : ℝ ) x <;> cases min_cases ( 1 : ℝ ) y <;> cases abs_cases ( x - y ) <;> cases abs_cases ( Max.max 0 ( Min.min 1 x ) - Max.max 0 ( Min.min 1 y ) ) <;> linarith

/-- Squared-distance form of `clamp01_nonexpansive`. -/
lemma clamp01_sq_le (x y : ℝ) : (clamp01 x - clamp01 y) ^ 2 ≤ (x - y) ^ 2 := by
  -- `sq_le_sq` rewrites the goal into an absolute-value inequality.
  simpa [sq_le_sq] using (clamp01_nonexpansive (x := x) (y := y))

/-- Markov (contraction) property hook for the Dirichlet energy (non-vacuous contract). -/
class DirichletMarkovHook (c : Weight V) : Prop where
  markov_clamp01 : ∀ f : V → ℝ,
    dirichletEnergy c (fun v => clamp01 (f v)) ≤ dirichletEnergy c f

/-- Re-export gate form provided by an instance `[DirichletMarkovHook c]`. -/
theorem gate_DIRICHLET_MARKOV_CLAMP01 (c : Weight V) [DirichletMarkovHook (c := c)] (f : V → ℝ) :
    dirichletEnergy c (fun v => clamp01 (f v)) ≤ dirichletEnergy c f := DirichletMarkovHook.markov_clamp01 (c := c) f

/--
Construct a `DirichletMarkovHook` under the natural assumption that all weights are nonnegative.

This avoids the (false) unconditional constructor: with negative weights, the Markov (clamp) property can fail
(see the commented counterexample above).
-/
def DirichletMarkovHook.mkOfNonneg (c : Weight V) (h : ∀ i j, 0 ≤ c i j) :
    DirichletMarkovHook (c := c) := by
  classical
  refine ⟨?_⟩
  intro f
  -- Outline:
  -- * expand `dirichletEnergy`;
  -- * use `offDiag c i j ≥ 0` (from `h`) and that `clamp01` is 1-Lipschitz on `ℝ` to compare each term
  --   `(clamp01 (f i) - clamp01 (f j))^2 ≤ (f i - f j)^2`;
  -- * sum termwise and multiply by `1/2 ≥ 0`.
  --
  -- Apply the nonexpansiveness estimate from `clamp01_sq_le`.
  unfold dirichletEnergy
  have hoff : ∀ i j, 0 ≤ offDiag c i j := by
    intro i j
    by_cases hji : j = i
    · subst hji; simp [offDiag]
    · simpa [offDiag, hji] using h i j
  have hterm : ∀ i j,
      offDiag c i j * (clamp01 (f i) - clamp01 (f j)) ^ 2
        ≤ offDiag c i j * (f i - f j) ^ 2 := by
    intro i j
    exact mul_le_mul_of_nonneg_left (clamp01_sq_le (x := f i) (y := f j)) (hoff i j)
  have hsum :
      (∑ i : V, ∑ j : V, offDiag c i j * (clamp01 (f i) - clamp01 (f j)) ^ 2)
        ≤ (∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2) := by
    refine Finset.sum_le_sum ?_
    intro i hi
    refine Finset.sum_le_sum ?_
    intro j hj
    simpa using hterm i j
  have hhalf : 0 ≤ (1 / 2 : ℝ) := by norm_num
  exact mul_le_mul_of_nonneg_left hsum hhalf

end Dirichlet

end LayerA

end PillarA
