import Mathlib
import REALOQS.PillarA.Ideal.Substrate
import REALOQS.PillarA.Update.Seed

set_option autoImplicit false

namespace PillarA

namespace Ideal

namespace Adapter

/-!
# IDEAL seed adapter

Phase 4 goal: IDEAL-specific seed key types live in `Ideal/Adapter/*`.

This file merely specializes the generic `Update.SeedSpec` to the IDEAL address
type `Addr b`.
-/

open PillarA.Ideal

abbrev IdealSeedSpec (b : Nat) : Type := PillarA.Update.SeedSpec (Addr b)

end Adapter

end Ideal

end PillarA
