import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD

set_option linter.style.longLine false
set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Faithfulness requirements for scale-breaking diagnostics (dependent)

This is the varying-scale analogue of `ScaleBreakingFaithfulness.lean`.

Goal: make the **laws** and **faithfulness contracts** expressible when both
the carrier `S k` and the interface `α k` depend on the scale index `k`.

Important: Pillar A's `LinOp` is intentionally an abstract operator carrier.
Therefore, "mismatch positivity" can only be demanded **on the concrete
normalized observed operators that actually occur in the axis**, not on *all*
operators.  The laws derivation below only ever needs positivity for the
`(real k)` vs `coarsen(real (k+1))` pair.

No physics is proven here; all nontrivial properties are exposed as explicit
contracts.
-/

namespace PillarA
namespace Physics

open PillarA.Update

noncomputable section

/-!
## Gate lemma: observed equality ⇒ zero mismatch diagnostic (dependent)

This is the dependent counterpart of
`ScaleBreakingMismatch.gate_breakMeasure_zero_of_observed_eq`.

It uses only the minimal contract `MismatchFunctional.mismatch_self`.
-/

theorem gate_breakMeasure_fromMismatch_onTowerD_zero_of_observed_eq
    {S : Nat → Type} {α : Nat → Type}
    (coarsen : ∀ k, S (k + 1) → S k) (tower : ∀ k, S k)
    (Obs : OpObserverD S α) (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) (k : Nat)
    (hEq :
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)) =
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (coarsen k (tower (k + 1))))) :
    (breakMeasure_fromMismatch_onTowerD
        (S := S) (α := α) coarsen tower Obs M eps eps_pos) k = 0 := by
  -- Use only `mismatch_self` after rewriting the second argument via `hEq`.
  have h0 :
      (M k).mismatch
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
            (Obs.op k (coarsen k (tower (k + 1))))) = 0 := by
    calc
      (M k).mismatch
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
          (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
            (Obs.op k (coarsen k (tower (k + 1)))))
          = (M k).mismatch
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k)))
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k))) := by
                simpa using
                  congrArg
                    (fun X => (M k).mismatch
                      (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (tower k))) X)
                    hEq.symm
      _ = 0 := (M k).mismatch_self _
  -- Unfold the diagnostic at `k` and apply `h0`.
  simp [breakMeasure_fromMismatch_onTowerD, h0]


/-!
## Faithfulness contracts for mismatch-based diagnostics (dependent)

These are the minimal hooks needed to later register `ScaleBreakingAxisD.LawsD`
for a mismatch-based axis produced by `axis_fromMismatchD`.

Key point: the only mismatch positivity we require is for the *actual pair*
`(real k)` vs `coarsen(real (k+1))` that occurs in the REAL diagnostic.
-/

structure ScaleBreakingFaithfulnessD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) : Prop where
  eps_pos : eps > 0

  /-- Under IDEAL scale invariance, observation is invariant (after coarsening). -/
  ideal_observed_eq_of_scaleInvariantD :
    A.scaleInvariantD → ∀ k,
      Obs.op k (A.ideal k) = Obs.op k (A.coarsen k (A.ideal (k + 1)))

  /-- If REAL breaks scale invariance, then the **normalized** observation differs at some level. -/
  real_normed_observed_neq_of_breaksScaleD :
    A.breaksScaleD → ∃ k,
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)) ≠
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (A.coarsen k (A.real (k + 1))))

  /-- Mismatch positivity for the REAL tower's normalized observation pair. -/
  mismatch_pos_of_real_normed_observed_neq :
    ∀ k,
      normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)) ≠
        normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
          (Obs.op k (A.coarsen k (A.real (k + 1)))) →
        0 < (M k).mismatch
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos (Obs.op k (A.real k)))
              (normalizeTrace (α := α k) (M k).P (M k).T eps eps_pos
                (Obs.op k (A.coarsen k (A.real (k + 1)))))


/-!
## Building `LawsD` for a mismatch axis given faithfulness

This is a direct dependent analogue of
`Laws_fromMismatch_withFaithfulness` (constant version).

It is *purely formal*: it relies only on the fields of
`ScaleBreakingFaithfulnessD` and on the gate lemma above.
-/

noncomputable def LawsD_fromMismatch_withFaithfulnessD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ)
    (F : ScaleBreakingFaithfulnessD (A := A) (Obs := Obs) (M := M) eps) :
    ScaleBreakingAxisD.LawsD
      (axis_fromMismatchD (S := S) (α := α) (A := A) Obs M eps F.eps_pos) := by
  refine ⟨?_, ?_⟩
  · intro hSI k
    have hObs := F.ideal_observed_eq_of_scaleInvariantD hSI k
    have hEq :
        normalizeTrace (α := α k) (M k).P (M k).T eps F.eps_pos (Obs.op k (A.ideal k)) =
          normalizeTrace (α := α k) (M k).P (M k).T eps F.eps_pos
            (Obs.op k (A.coarsen k (A.ideal (k + 1)))) := by
      simp [hObs]
    have h0 :=
      gate_breakMeasure_fromMismatch_onTowerD_zero_of_observed_eq
        (S := S) (α := α)
        (coarsen := A.coarsen)
        (tower := A.ideal)
        (Obs := Obs) (M := M)
        (eps := eps) (eps_pos := F.eps_pos)
        (k := k) hEq
    simpa [axis_fromMismatchD, breakMeasure_fromMismatchIdealD] using h0
  · intro hBS
    rcases F.real_normed_observed_neq_of_breaksScaleD hBS with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    have hPos := F.mismatch_pos_of_real_normed_observed_neq (k := k) hk
    simpa [axis_fromMismatchD, breakMeasure_fromMismatchRealD, breakMeasure_fromMismatch_onTowerD]
      using hPos

end
end Physics
end PillarA
