import REALOQS.PillarA.Core.RegionCore
import REALOQS.PillarA.Core.InfiniteCarrierSymmetry

set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# CylinderSets (Core, Phase 3)

For a fixed level `L`, a region `R : RegionAt Cell L` determines a *cylinder set*
in `InfiniteCarrier Cell` by pulling back membership at level `L`.

We additionally provide two small gates:

* monotonicity under region inclusion,
* compatibility with the symmetry lift from `SymmetryAction` to `InfiniteCarrier`.

Convention note:

`SymmetryAction.actRegion` is defined by `Finset.image`. With this convention,
the clean set-theoretic statement is naturally expressed using a preimage under
the *inverse* lift:

`cyl (g • R) = (actInf g⁻¹) ⁻¹' (cyl R)`.
-/

universe u

open RegionCore

namespace CylinderSets

variable {Cell : Nat → Type u} [Substrate Cell]

/-- Cylinder set associated to a level-`L` region. -/
def cyl {L : Nat} (R : RegionAt Cell L) : Set (InfiniteCarrier (Cell := Cell)) :=
  fun U => U.cell L ∈ R

@[simp] theorem mem_cyl {L : Nat} (U : InfiniteCarrier (Cell := Cell)) (R : RegionAt Cell L) :
    U ∈ cyl (Cell := Cell) R ↔ U.cell L ∈ R := Iff.rfl

/-- Monotonicity: region inclusion implies cylinder inclusion. -/
theorem cyl_mono {L : Nat} {R R' : RegionAt Cell L} (h : R ⊆ R') :
    cyl (Cell := Cell) R ⊆ cyl (Cell := Cell) R' := by
  intro U hU
  exact h hU

open SymmetryAction

/-!
## Symmetry compatibility

We only require the group axioms already present in `SymmetryAction`.
The two inverse identities are derived once locally.
-/

private theorem act_inv_act
    {L : Nat} (S : SymmetryAction (Cell := Cell)) (g : S.G) (x : Cell L) :
    S.act (L := L) (g⁻¹) (S.act (L := L) g x) = x := by
  have hmul := S.act_mul (L := L) (g := g⁻¹) (h := g) x
  -- `hmul : act (g⁻¹*g) x = act g⁻¹ (act g x)`
  calc
    S.act (L := L) (g⁻¹) (S.act (L := L) g x)
        = S.act (L := L) (g⁻¹ * g) x := by
            exact hmul.symm
    _ = S.act (L := L) (1 : S.G) x := by
          simp
    _ = x := by
          simp [S.act_one]

private theorem act_act_inv
    {L : Nat} (S : SymmetryAction (Cell := Cell)) (g : S.G) (x : Cell L) :
    S.act (L := L) g (S.act (L := L) (g⁻¹) x) = x := by
  have hmul := S.act_mul (L := L) (g := g) (h := g⁻¹) x
  -- `hmul : act (g*g⁻¹) x = act g (act g⁻¹ x)`
  calc
    S.act (L := L) g (S.act (L := L) (g⁻¹) x)
        = S.act (L := L) (g * g⁻¹) x := by
            exact hmul.symm
    _ = S.act (L := L) (1 : S.G) x := by
          simp
    _ = x := by
          simp [S.act_one]

/-- Symmetry compatibility, expressed as a preimage identity. -/
theorem cyl_actRegion_preimage
    {L : Nat} (S : SymmetryAction (Cell := Cell)) [DecidableEq (Cell L)]
    (g : S.G) (R : RegionAt Cell L) :
    cyl (Cell := Cell) (actRegion (Cell := Cell) S (L := L) g R)
      = (fun U => S.actInf (Cell := Cell) (g⁻¹) U) ⁻¹' (cyl (Cell := Cell) R) := by
  ext U
  constructor
  · intro h
    -- `h : U.cell L ∈ (R.image (S.act g))`
    rcases Finset.mem_image.1 h with ⟨x, hxR, hx⟩
    have hx' : S.act (L := L) (g⁻¹) (U.cell L) = x := by
      calc
        S.act (L := L) (g⁻¹) (U.cell L)
            = S.act (L := L) (g⁻¹) (S.act (L := L) g x) := by
                -- rewrite `U.cell L` using `hx`
                simp [hx.symm]
        _ = x := act_inv_act (Cell := Cell) (L := L) S g x
    have hpre : S.act (L := L) (g⁻¹) (U.cell L) ∈ R := by
      -- rewrite to `x` and use `hxR`
      rw [hx']
      exact hxR
    -- goal is a preimage-membership; reduce to `hpre`
    simp [SymmetryAction.actInf]
    exact hpre
  · intro h
    -- `h` means `S.act g⁻¹ (U.cell L) ∈ R`.
    have h' : U ∈ (fun U => S.actInf (Cell := Cell) (g⁻¹) U) ⁻¹' cyl (Cell := Cell) R := h
    -- simplify `h'` in place
    simp [SymmetryAction.actInf] at h'
    have hxR : S.act (L := L) (g⁻¹) (U.cell L) ∈ R := by
      exact h'
    refine Finset.mem_image.2 ?_
    refine ⟨S.act (L := L) (g⁻¹) (U.cell L), hxR, ?_⟩
    -- Close the witness equation using the derived inverse law.
    exact (act_act_inv (Cell := Cell) (L := L) S g (U.cell L))

end CylinderSets

end LayerA
end PillarA
