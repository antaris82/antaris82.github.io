import Mathlib

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Discrete spacetime (interface) -- v0.11h

Pillar A must be able to talk about **discrete** spacetime objects without injecting
a continuum manifold or a Lorentz metric as an axiom.

This module provides a minimal notion of a discrete spacetime:

* an underlying type `X` of discrete "events" / nodes,
* a discrete time function `τ : X → ℕ`,
* a one-step causal relation `step : X → X → Prop` that advances time by exactly one.

Extended objects are handled in `WorldTube` (time-indexed finite sets of nodes).
-/

namespace PillarA
namespace Kinematics

universe u

/-- A discrete spacetime: time stamp + one-step causal relation.

Universe-polymorphic in `X` (Phase 9), so downstream layers are not forced into `Type 0`.
-/
structure DiscreteSpacetime (X : Type u) where
  τ : X → Nat
  step : X → X → Prop
  step_tau : ∀ {x y}, step x y → τ y = τ x + 1

namespace DiscreteSpacetime

variable {X : Type u} (ST : DiscreteSpacetime X)

/-- The time-slice (hypersurface) at integer time `n`. -/
def Sigma (n : Nat) : Set X := {x | ST.τ x = n}

/-- A discrete worldline as a time-indexed sequence of nodes with valid causal steps. -/
structure Worldline where
  x : Nat → X
  step_ok : ∀ n, ST.step (x n) (x (n+1))

/-- A time-indexed finite subset of nodes, representing an extended object at each time. -/
structure WorldTube where
  W : Nat → Finset X
  adapted : ∀ n x, x ∈ W n → ST.τ x = n

/-- A choice of "centerline" inside a worldtube (no dynamics assumed yet).

Universe note (Phase 9): this must live in the same universe as `X`, not in `Type 0`.
-/
def Centerline (T : WorldTube ST) : Type u := {γ : Nat → X // ∀ n, γ n ∈ T.W n}

/-- Predicate: a given centerline stays inside the tube and is causal w.r.t. the step relation. -/
def IsCausalCenterline (ST : DiscreteSpacetime X) (T : WorldTube ST) (γ : Nat → X) : Prop :=
  (∀ n, γ n ∈ T.W n) ∧ (∀ n, ST.step (γ n) (γ (n+1)))

/-- Gate: a causal centerline induces a worldline by forgetting tube-membership. -/
def gate_centerline_is_worldline (T : WorldTube ST) (γ : Nat → X)
    (h : IsCausalCenterline ST T γ) : Worldline ST := by
  refine ⟨γ, ?_⟩
  intro n
  exact h.2 n

/-- If a tube is adapted, every member of the tube at time `n` lies on the slice `Sigma n`. -/
theorem gate_tube_subset_slice (T : WorldTube ST) (n : Nat) :
    ∀ x, x ∈ T.W n → x ∈ ST.Sigma n := by
  intro x hx
  exact T.adapted n x hx

/-- An *empty-step* discrete spacetime instance with no causal steps.

This is a testing/bootstrapping hook and should not be used in the default physics path.
-/
def mkEmpty (X : Type u) [Inhabited X] : DiscreteSpacetime X := by
  refine ⟨?_, ?_, ?_⟩
  · exact fun _ => 0
  · exact fun _ _ => False
  · intro x y h
    cases h

end DiscreteSpacetime

end Kinematics
end PillarA
