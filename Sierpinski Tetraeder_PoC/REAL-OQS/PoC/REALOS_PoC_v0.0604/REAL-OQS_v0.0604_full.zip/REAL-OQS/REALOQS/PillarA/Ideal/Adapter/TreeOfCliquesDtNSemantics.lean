import REALOQS.PillarA.Update.TailEliminationDtN
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox

set_option autoImplicit false

namespace PillarA
namespace Update
namespace Instances

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS

/-!
# Tree-of-Cliques: `TailElimDtNSemantics` for the Phase-4 carrier

We connect the concrete update carrier defined in
`Update.Instances.TreeOfCliquesApprox` to the semantic contract
`TailElimDtNSemantics`.

Phase 4: Stage-1 is a **genuine** DtN reduction. The adapter state stores the full
block operator on `B ⊕ I`; Stage-1 replaces the boundary block by `DtN(L)` and
zeros the cross blocks.
-/

namespace TreeOfCliquesDtNSemantics

open TreeOfCliquesApprox

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b := TreeOfCliquesApprox.mk (b := b) p

/-- Concrete `TailElimDtNSemantics` instance for the Tree-of-Cliques carrier. -/
noncomputable def mk :
    PillarA.Update.TailElimDtNSemantics (A := A (p := p)) := by
  classical
  refine
    { V := V (p := p)
      instFintypeV := inferInstance
      instDecEqV := inferInstance
      split := sSplit (p := p)
      L := fun st => fullMatrix (p := p) st
      inv := fun st => interiorInv (p := p) st
      boundaryOp := fun st => st.LBB
      boundaryOp_def := by
        intro st
        -- boundaryOp is definitional equal to the `BB` block of the full matrix.
        simp [blockBB_fullMatrix (p := p) st]
      stage1_boundaryOp_eq_DtN := by
        intro st
        -- `stage1 = integrateTail ∘ truncateTail = reduce` in this carrier.
        simp [TreeOfCliquesApprox.mk, TwoStageApprox.stage1, TreeOfCliquesApprox.reduce] }

end TreeOfCliquesDtNSemantics

end

end Instances
end Update
end PillarA
