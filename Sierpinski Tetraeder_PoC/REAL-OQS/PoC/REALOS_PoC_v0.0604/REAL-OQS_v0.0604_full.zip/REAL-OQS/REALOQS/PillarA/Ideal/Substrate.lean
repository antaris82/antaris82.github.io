import Mathlib

set_option linter.style.longLine false



set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace Ideal

/-!
# IDEAL Substrate (Address Tree Scaffold)

This file formalizes a minimal *hierarchically addressable* substrate for Pillar A.

We model cell addresses as finite words over an alphabet of size `b`:
`Addr b := List (Fin b)`.

Compatibility note (Lean v4.24 / Mathlib snapshots):
We avoid `Finset.bind` and avoid relying on `Fintype (Vector ...)` instances by
representing words of length `k` as functions `Fin k → Fin b` and mapping via `List.ofFn`.
-/

abbrev Addr (b : Nat) := List (Fin b)

def level {b : Nat} (a : Addr b) : Nat := a.length

def child {b : Nat} (a : Addr b) (d : Fin b) : Addr b := a ++ [d]

def children {b : Nat} (a : Addr b) : Finset (Addr b) := Finset.univ.image (fun d : Fin b => child a d)

/-- All addresses at a fixed level `k` (finite). -/
def cellsAtLevel (b : Nat) (k : Nat) : Finset (Addr b) := (Finset.univ : Finset (Fin k → Fin b)).image (fun f => List.ofFn f)

/-- All addresses up to depth `L`. -/
def cellsUpTo (b : Nat) : Nat → Finset (Addr b)
| 0     => cellsAtLevel b 0
| L+1   => (cellsUpTo b L) ∪ (cellsAtLevel b (L+1))

theorem mem_cellsAtLevel_iff_length
    (b : Nat) (k : Nat) (a : Addr b) :
    a ∈ cellsAtLevel b k ↔ a.length = k := by
  /-
  PROVIDED SOLUTION
  - (`→`) If `a ∈ image (List.ofFn) univ`, then `a = List.ofFn f` for some `f : Fin k → Fin b`.
    Hence `a.length = k` using `List.length_ofFn`.
  - (`←`) If `a.length = k`, define `f : Fin k → Fin b` by `f i := a.get ⟨i, by ...⟩`.
    Then `List.ofFn f = a`, so `a` is in the image.
  -/
  constructor;
  · unfold PillarA.Ideal.cellsAtLevel; aesop;
  · intro ha
    have h_eq : ∃ f : Fin k → Fin b, List.ofFn f = a := by
      rw [ ← ha ];
      exact ⟨ fun i => a.get i, by rw [ List.ofFn_get ] ⟩;
    unfold PillarA.Ideal.cellsAtLevel; aesop;

theorem mem_children_length
    {b : Nat} (a : Addr b) (x : Addr b) :
    x ∈ children a → x.length = a.length + 1 := by
  /-
  PROVIDED SOLUTION
  `x ∈ children a` means `∃ d, x = a ++ [d]`. Then compute lengths.
  -/
  -- By definition of `children`, if `x` is in the children of `a`, then there exists
  -- some `d` such that `x = a ++ [d]`.
  intro hx
  obtain ⟨d, hd⟩ : ∃ d, x = a ++ [d] := by
    -- By definition of `children`, if `x` is in the children of `a`, then there exists
    -- some `d` such that `x = a ++ [d]`. This follows directly from the definition of
    -- `children`.
    simp [PillarA.Ideal.children] at hx;
    -- By definition of `child`, if `child a d = x`, then `x = a ++ [d]`.
    obtain ⟨d, hd⟩ := hx;
    use d;
    rw [←hd];
    simp [PillarA.Ideal.child];
  -- By definition of `List.length`, the length of `a ++ [d]` is `a.length + 1`.
  simp [hd, List.length_append]

theorem children_subset_next_level
    (b : Nat) (k : Nat) (a x : Addr b)
    (ha : a ∈ cellsAtLevel b k) :
    x ∈ children a → x ∈ cellsAtLevel b (k+1) := by
  /-
  PROVIDED SOLUTION
  Use `mem_cellsAtLevel_iff_length` for `a` and `x`, plus `mem_children_length`.
  -/
  -- If `x ∈ children a`, then `x = a ++ [d]` for some digit `d`.
  -- Hence `x` has length `k+1` and therefore belongs to `cellsAtLevel b (k+1)`.
  intro hx
  obtain ⟨d, hd⟩ : ∃ d : Fin b, x = a ++ [d] := by
    unfold PillarA.Ideal.children at hx; aesop;
  -- Since `a ∈ cellsAtLevel b k`, we know `a.length = k`.
  -- Appending one digit increases the length to `k+1`.
  have h_len : x.length = k + 1 := by
    unfold PillarA.Ideal.cellsAtLevel at ha; aesop;
  -- Since $x$ has length $k+1$, it must be in $cellsAtLevel b (k+1)$ by definition.
  apply (mem_cellsAtLevel_iff_length b (k + 1) x).mpr h_len

theorem card_cellsAtLevel
    (b : Nat) (k : Nat) :
    (cellsAtLevel b k).card = b^k := by
  /-
  PROVIDED SOLUTION
  `cellsAtLevel` is the image of `Finset.univ : Finset (Fin k → Fin b)`.
  Use injectivity of `List.ofFn` to get `card (image _ univ) = card univ`.
  Then `card (Fin k → Fin b) = (card (Fin b))^(card (Fin k)) = b^k`.
  -/
  -- The cardinality of the image of a function is equal to the cardinality of the domain.
  have h_card_image :
      (Finset.image (fun f : Fin k → Fin b => List.ofFn f)
          (Finset.univ : Finset (Fin k → Fin b))).card
        =
      Finset.card (Finset.univ : Finset (Fin k → Fin b)) := by
    exact Finset.card_image_of_injective _ fun f g h => by simpa [ funext_iff ] using h;
  aesop

end Ideal

end PillarA
