import REALOQS.PillarA.Core.RegionNet

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# Core/BInterfaces: StateNet

**Phase 9 (preparation for Pillar B/C):**

This file defines a *pure interface* for a state assignment to regions with
functorial restriction maps.

No attempt is made to model positivity, normalization, or operator-algebraic
structure here; these belong to Pillar B/C.
-/

universe u v

/-- A presheaf of state carriers indexed by a `RegionNet`.

`State r` is an abstract carrier (later: normal states, density operators,
KMS states, etc.).

`restrict` is the contravariant functorial map along `a ≤ b`.
-/
structure StateNet (Ω : Type u) where
  RN : RegionNet Ω
  State : RN.Region → Type v
  restrict : ∀ {a b : RN.Region}, a ≤ b → State b → State a
  restrict_id : ∀ (a : RN.Region) (ρ : State a), restrict (a := a) (b := a) (le_rfl) ρ = ρ
  restrict_comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) (ρ : State c),
    restrict (a := a) (b := b) hab (restrict (a := b) (b := c) hbc ρ) =
      restrict (a := a) (b := c) (le_trans hab hbc) ρ

namespace StateNet

variable {Ω : Type u} (SN : StateNet (Ω := Ω))

instance : SemilatticeSup SN.RN.Region := by
  infer_instance

theorem gate_STATE_restrict_id (a : SN.RN.Region) (ρ : SN.State a) :
    SN.restrict (a := a) (b := a) (le_rfl) ρ = ρ :=
  SN.restrict_id a ρ

theorem gate_STATE_restrict_comp {a b c : SN.RN.Region}
    (hab : a ≤ b) (hbc : b ≤ c) (ρ : SN.State c) :
    SN.restrict (a := a) (b := b) hab (SN.restrict (a := b) (b := c) hbc ρ) =
      SN.restrict (a := a) (b := c) (le_trans hab hbc) ρ :=
  SN.restrict_comp hab hbc ρ

end StateNet

end LayerA
end PillarA
