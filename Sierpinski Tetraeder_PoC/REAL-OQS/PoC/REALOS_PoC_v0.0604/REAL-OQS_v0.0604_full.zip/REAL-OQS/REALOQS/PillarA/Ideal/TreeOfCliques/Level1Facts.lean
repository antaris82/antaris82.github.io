import REALOQS.PillarA.Ideal.TreeOfCliques.SmallScales
import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

/-!
# Tree-of-Cliques: Level-1 normal forms

This file contains *purely list-theoretic* facts about boundary addresses at level `1`
and their interaction with the canonical parent map `π` on boundary nodes.

No graph / Laplacian / DtN infrastructure is used here.
-/

namespace Level1Facts

variable {b : Nat}

/-- Every boundary address at level `1` is a singleton list `[d]`. -/
theorem boundary1_val_eq_singleton (x : Boundary b 1) : ∃ d : Fin b, (x : Addr b) = [d] := by
  have hxlen : (x : Addr b).length = 1 :=
    (mem_cellsAtLevel_iff_length b 1 (x : Addr b)).1 x.2
  rcases (List.length_eq_one_iff).1 hxlen with ⟨d, hd⟩
  exact ⟨d, hd⟩

/-- On level `1`, the parent map `π` always yields the unique boundary node at level `0`. -/
@[simp] theorem pi_boundary1_eq_rootB0 (b : Nat) (x : Boundary b 1) :
    CoarsenBoundary.π b 0 x = rootB0 b := by
  classical
  apply Subtype.ext
  rcases boundary1_val_eq_singleton (b := b) x with ⟨d, hd⟩
  -- Reduce to the singleton-list computation.
  -- `rootB0` has value `[]` and `dropLast [d] = []`.
  simp [CoarsenBoundary.π, rootB0_val, hd]

/-- The `π`-fiber over `rootB0` at `k=0` is all of `Boundary b 1`. -/
theorem fiber_rootB0_eq_univ (b : Nat) :
    CoarsenBoundary.fiber b 0 (rootB0 b) = (Finset.univ : Finset (Boundary b 1)) := by
  classical
  ext x
  -- Membership in the fiber is the predicate `π x = rootB0`, which is always true at level `1`.
  simp [CoarsenBoundary.fiber]

end Level1Facts

end TreeOfCliques
end Ideal
end PillarA
