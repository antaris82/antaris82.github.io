/-
REALOQS / Pillar A / Scaffold: heavy developer umbrella

This module bundles a broad set of Pillar-A scaffolds intended mainly for
interactive development and experimentation (e.g. with downstream).

It is intentionally heavy; prefer `REALOQS.PillarA.Interface` for the canonical
substrate-agnostic surface.
-/

import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.Core.NoetherHooks
import REALOQS.PillarA.Core.Determinism
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Ideal.Adapter.IdealSymmetryNoether
import REALOQS.PillarA.Core.DirichletLaplacianBridge

-- Update surface
import REALOQS.PillarA.Update.Step
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver
import REALOQS.PillarA.Update.MismatchDriver
import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.Update.TailEliminationDtN

-- Kinematics and hooks
import REALOQS.PillarA.Kinematics.FrameChange
import REALOQS.PillarA.Kinematics.KinematicsHooks
import REALOQS.PillarA.Kinematics.Worldline
import REALOQS.PillarA.Kinematics.ProperTime
import REALOQS.PillarA.Kinematics.Clock
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.SpatialMetric
import REALOQS.PillarA.Kinematics.Causality
import REALOQS.PillarA.Kinematics.ProperTimeFromMetric
import REALOQS.PillarA.Kinematics.SpacetimeRegions

-- Resistance metric
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Core.ResistanceMetricCanonical

-- IDEAL helpers
import REALOQS.PillarA.Ideal.Adapter.LCPMeasure
import REALOQS.PillarA.OQS.DtN
import REALOQS.PillarA.OQS.LiebRobinsonHook
import REALOQS.PillarA.OQS.SplitInvariants
import REALOQS.PillarA.Ideal.Adapter.Foliation
import REALOQS.PillarA.Ideal.Adapter.SpacetimePaths

-- Physics hooks
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Physics.ScaleBreakingMismatch
import REALOQS.PillarA.Physics.ScaleBreakingFaithfulness

-- Geometry hooks (dimension / heat-kernel)
import REALOQS.PillarA.Geometry.DimensionHooks

-- RG scaffolds (scale windows / error budgets)
import REALOQS.PillarA.RG.ScaleWindow

-- Symmetry scaffolds (approx isometries / Poincaré-like families)
import REALOQS.PillarA.Symmetry.ApproxIsometry
import REALOQS.PillarA.Symmetry.ApproxPoincare
