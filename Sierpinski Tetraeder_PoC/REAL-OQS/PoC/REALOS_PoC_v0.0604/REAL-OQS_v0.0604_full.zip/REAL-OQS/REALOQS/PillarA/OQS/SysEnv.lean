import Mathlib

set_option linter.style.longLine false



set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace OQS

/-!
# System / Environment Split (Scaffold)

We represent an explicit split of degrees of freedom as a *type-level partition*

  V ≃ B ⊕ I

where
- `B` = boundary / system interface,
- `I` = interior / eliminated environment.

This is the most downstream-friendly representation because it makes block matrices
and Schur complements straightforward via `Matrix.reindex`.
-/

/-- A type-level partition `V ≃ B ⊕ I` carrying the needed instances. -/
structure Split (V : Type) [Fintype V] [DecidableEq V] where
  B : Type
  I : Type
  instFintypeB : Fintype B
  instDecEqB : DecidableEq B
  instFintypeI : Fintype I
  instDecEqI : DecidableEq I
  e : V ≃ Sum B I

attribute [instance] Split.instFintypeB Split.instDecEqB

attribute [instance] Split.instFintypeI Split.instDecEqI

namespace Split

variable {V : Type} [Fintype V] [DecidableEq V]

variable (s : Split V)

/-- Reindex a matrix on `V` to a matrix on `B ⊕ I`. -/
def reindex (M : Matrix V V ℝ) : Matrix (Sum s.B s.I) (Sum s.B s.I) ℝ := Matrix.reindex s.e s.e M

def blockBB (M : Matrix V V ℝ) : Matrix s.B s.B ℝ := fun b1 b2 => (s.reindex M) (Sum.inl b1) (Sum.inl b2)

def blockBI (M : Matrix V V ℝ) : Matrix s.B s.I ℝ := fun b i => (s.reindex M) (Sum.inl b) (Sum.inr i)

def blockIB (M : Matrix V V ℝ) : Matrix s.I s.B ℝ := fun i b => (s.reindex M) (Sum.inr i) (Sum.inl b)

def blockII (M : Matrix V V ℝ) : Matrix s.I s.I ℝ := fun i1 i2 => (s.reindex M) (Sum.inr i1) (Sum.inr i2)

theorem reindex_transpose (M : Matrix V V ℝ) :
    Matrix.transpose (s.reindex M) = s.reindex (Matrix.transpose M) := by
  /-
  PROVIDED SOLUTION
  `Matrix.reindex` commutes with transpose: unfold and use extensionality.
  -/
  -- `Matrix.reindex` commutes with transpose.
  -- The lemma `Matrix.transpose_reindex` provides this fact directly.
  apply Matrix.transpose_reindex

theorem blockBB_transpose_of_symm
    (M : Matrix V V ℝ)
    (h : Matrix.transpose M = M) :
    Matrix.transpose (s.blockBB M) = s.blockBB M := by
  /-
  PROVIDED SOLUTION
  Use `reindex_transpose` and `h`.
  -/
  ext i j;
  -- By definition of transpose, we have that (h i j) = h j i.
  apply congr_fun (congr_fun h (s.e.symm (Sum.inl i))) (s.e.symm (Sum.inl j))

theorem blockII_transpose_of_symm
    (M : Matrix V V ℝ)
    (h : Matrix.transpose M = M) :
    Matrix.transpose (s.blockII M) = s.blockII M := by
  ext i j
  -- `blockII M i j = M (e.symm (inr i)) (e.symm (inr j))` and symmetry swaps the arguments.
  apply congr_fun (congr_fun h (s.e.symm (Sum.inr i))) (s.e.symm (Sum.inr j))

end Split

end OQS

end PillarA
