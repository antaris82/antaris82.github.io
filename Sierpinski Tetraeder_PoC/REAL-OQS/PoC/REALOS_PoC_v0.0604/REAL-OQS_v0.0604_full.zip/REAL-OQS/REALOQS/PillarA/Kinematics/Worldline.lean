import Mathlib
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Worldlines vs. Worldtubes (discrete, no continuum input)

Motivation for Pillar A:
- A "worldline" (ℕ → V) is a convenient mathematical idealization.
- A realistic object is extended: at each time step it occupies a *finite region* of sites.
  This is modeled as a "worldtube" (ℕ → Finset V).

Pillar A only fixes the minimal discrete interface and a stable set of gate names.
No dynamics, geometry, or SR interpretation is assumed.
-/

namespace PillarA
namespace Kinematics

/-- A (discrete-time) worldline is a sequence of sites/events. -/
abbrev Worldline (V : Type) := ℕ → V

/-- A (discrete-time) worldtube is an extended object: a finite set of sites per time step. -/
abbrev WorldTube (V : Type) := ℕ → Finset V

/-- Nonempty occupancy at every time step. -/
def TubeNonempty {V : Type} (W : WorldTube V) : Prop := ∀ n, (W n).Nonempty

/-- A centerline is a worldline selecting an occupied site at each time. -/
def IsCenterline {V : Type} (W : WorldTube V) (γ : Worldline V) : Prop := ∀ n, γ n ∈ W n

/-!
### Gate name (non-vacuous)

Historically this file exposed a vacuous gate of the form `IsCenterline → True`.
That was useful as a stable *name* for downstream plumbing, but it erased content.

We keep the identifier for compatibility, but give it a **nonvacuous type**:
it simply re-exports the definitional content of `IsCenterline`.
-/

/-- Gate: a centerline provides membership witnesses at every time step.

This lemma is definitionally `id`, but it is not vacuous (`→ True`).
-/
theorem gate_CENTERLINE_IS_WORLDLINE {V : Type} (W : WorldTube V) (γ : Worldline V) :
    IsCenterline (V := V) W γ → ∀ n, γ n ∈ W n := by
  intro h
  exact h

/-!
## Choice axis (contract)

Selecting a centerline from a nonempty worldtube uses choice.
Pillar A makes this explicit as a *non-vacuous contract* so later layers can:
- either assume classical choice,
- or specify a canonical selection rule (e.g. minimal id, energy minimizer, barycenter, ...).
-/

class WorldTubeChoiceAxis (V : Type) where
  chooseCenterline : ∀ (W : WorldTube V), TubeNonempty (V := V) W → Worldline V
  choose_spec : ∀ (W : WorldTube V) (hW : TubeNonempty (V := V) W),
    IsCenterline (V := V) W (chooseCenterline W hW)

namespace WorldTubeChoiceAxis

/-- downstream hook: centralized `deferred proof` for the choice axis. -/
noncomputable def mkClassicalChoice (V : Type) : WorldTubeChoiceAxis V := by
  refine ⟨?_, ?_⟩
  · intro W hW
    classical
    -- placeholder choice (witness from `Finset.Nonempty`)
    exact fun n => Classical.choose (hW n)
  · intro W hW
    classical
    intro n
    -- key obligation: chosen element is in the finset
    exact Classical.choose_spec (hW n)

end WorldTubeChoiceAxis

/-- Gate: under a choice axis, every nonempty worldtube placeholder proofs a centerline. -/
theorem gate_TUBE_HAS_CENTERLINE {V : Type} [WorldTubeChoiceAxis V]
    (W : WorldTube V) (hW : TubeNonempty (V := V) W) :
    ∃ γ : Worldline V, IsCenterline (V := V) W γ := by
  refine ⟨WorldTubeChoiceAxis.chooseCenterline (V := V) W hW, ?_⟩
  exact WorldTubeChoiceAxis.choose_spec (V := V) W hW

end Kinematics
end PillarA
