import Mathlib

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Substrate class (Core, Phase 1)

This file introduces a *minimal* substrate contract for Pillar A Core:

* a refinement level index (`Nat`),
* a type of cells per level, finite and with decidable equality,
* immediate `parents`/`children` interfaces.

No laws are enforced at Phase 1; those can be layered on later.
-/

universe u

/--
`Substrate Cell` is the minimal combinatorial contract for a refinement substrate.

* `Cell L` is the type of cells at level `L`.
* Each level is finite (`Fintype`) and supports decidable equality.
* `parents` maps a fine cell (level `L+1`) to the finite set of its immediate parents (level `L`).
* `children` maps a cell to the finite set of its immediate refinements.

Multiple parents are allowed (IFS overlaps etc.).
-/
class Substrate (Cell : Nat → Type u) : Type (u + 1) where
  instDecEq : ∀ L : Nat, DecidableEq (Cell L)
  instFintype : ∀ L : Nat, Fintype (Cell L)
  parents : ∀ {L : Nat}, Cell (L + 1) → Finset (Cell L)
  children : ∀ {L : Nat}, Cell L → Finset (Cell (L + 1))

attribute [instance] Substrate.instDecEq
attribute [instance] Substrate.instFintype

namespace Substrate

variable {Cell : Nat → Type u} [Substrate Cell]

/-- Immediate parent relation induced by `parents`. -/
def ParentRel {L : Nat} (c : Cell (L + 1)) (p : Cell L) : Prop :=
  p ∈ Substrate.parents c

/-- Immediate child relation induced by `children`. -/
def ChildRel {L : Nat} (p : Cell L) (c : Cell (L + 1)) : Prop :=
  c ∈ Substrate.children p

/-- One-step refinement on a finite set of cells. -/
def refineSet {L : Nat} (S : Finset (Cell L)) : Finset (Cell (L + 1)) :=
  S.biUnion (fun c => Substrate.children c)

/-- One-step coarsening on a finite set of cells. -/
def coarsenSet {L : Nat} (S : Finset (Cell (L + 1))) : Finset (Cell L) :=
  S.biUnion (fun c => Substrate.parents c)

/-- Monotonicity of `refineSet` w.r.t. set inclusion. -/
theorem refineSet_mono {L : Nat} {S T : Finset (Cell L)} (h : S ⊆ T) :
    refineSet (Cell := Cell) S ⊆ refineSet (Cell := Cell) T := by
  intro x hx
  rcases Finset.mem_biUnion.mp hx with ⟨c, hcS, hxchild⟩
  exact Finset.mem_biUnion.mpr ⟨c, h hcS, hxchild⟩

/-- Monotonicity of `coarsenSet` w.r.t. set inclusion. -/
theorem coarsenSet_mono {L : Nat} {S T : Finset (Cell (L + 1))} (h : S ⊆ T) :
    coarsenSet (Cell := Cell) S ⊆ coarsenSet (Cell := Cell) T := by
  intro x hx
  rcases Finset.mem_biUnion.mp hx with ⟨c, hcS, hxpar⟩
  exact Finset.mem_biUnion.mpr ⟨c, h hcS, hxpar⟩

end Substrate

/--
`DeterministicSubstrate` is an optional strengthening: each fine cell has a unique parent.

This is *not* required for `Substrate` and is intended for tree-like address substrates.
-/
class DeterministicSubstrate (Cell : Nat → Type u) [Substrate Cell] : Type (u + 1) where
  parent : ∀ {L : Nat}, Cell (L + 1) → Cell L
  parents_eq_singleton_parent :
    ∀ {L : Nat} (c : Cell (L + 1)),
      Substrate.parents c = {parent c}

namespace DeterministicSubstrate

variable {Cell : Nat → Type u} [Substrate Cell] [DeterministicSubstrate Cell]

theorem parent_mem_parents {L : Nat} (c : Cell (L + 1)) :
    (DeterministicSubstrate.parent (Cell := Cell) c) ∈ Substrate.parents c := by
  simp [DeterministicSubstrate.parents_eq_singleton_parent (Cell := Cell) c]

end DeterministicSubstrate

end LayerA

end PillarA
