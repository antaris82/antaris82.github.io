import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# InfiniteCarrier (Core, Phase 1)

`InfiniteCarrier Cell` is the purely combinatorial inverse-limit style carrier
for an "infinite" substrate object: a coherent choice of one cell at each level.

No symmetry, nets, or analysis is used here.
-/

universe u

variable {Cell : Nat → Type u} [Substrate Cell]

/--
An infinite carrier is a coherent chain of cells across all refinement levels.

* `cell L` is the chosen cell at level `L`.
* `coh L` states that the level-`L` cell is a parent of the level-`L+1` cell.
-/
structure InfiniteCarrier (Cell : Nat → Type u) [Substrate Cell] : Type (u + 1) where
  cell : ∀ L : Nat, Cell L
  coh : ∀ L : Nat, cell L ∈ Substrate.parents (Cell := Cell) (cell (L + 1))

namespace InfiniteCarrier

variable (U V : InfiniteCarrier (Cell := Cell))

@[ext] theorem ext (h : ∀ L : Nat, U.cell L = V.cell L) : U = V := by
  cases U with
  | mk cellU cohU =>
    cases V with
    | mk cellV cohV =>
      have hc : cellU = cellV := by
        funext L
        exact h L
      subst hc
      have hcoh : cohU = cohV := by
        funext L
        exact Subsingleton.elim (cohU L) (cohV L)
      cases hcoh
      rfl

/-- Definitional projection alias. -/
abbrev proj (U : InfiniteCarrier (Cell := Cell)) (L : Nat) : Cell L := U.cell L

@[simp] theorem proj_def (U : InfiniteCarrier (Cell := Cell)) (L : Nat) : U.proj L = U.cell L :=
  rfl

end InfiniteCarrier

end LayerA
end PillarA
