import Mathlib
import REALOQS.PillarA.Kinematics.ProperTime
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option autoImplicit false
open scoped BigOperators

/-!
REALOQS / Pillar A / Layer A: Operational clock (discrete, foliation-aware hook)

Goal:
- Represent a *physical clock* as an internal state machine whose readout accumulates
  "ticks" along a (discrete) trajectory.
- Provide a theorem that a canonical accumulator clock operationalizes the discrete
  proper-time functional `properTimeUpTo`.

This is strictly Pillar-A level: no Lorentzian metric is assumed.
Foliation-awareness enters by allowing the trajectory to be a `DiscreteSpacetime.Worldline`,
so that "ticks" correspond to advancing one leaf `Σ_n` at each step.
-/

namespace PillarA
namespace Kinematics

/-- A (discrete) physical clock: internal state + per-step update + readout.

The update may depend on:
- the step index `n`,
- the current and next events `x y`,
- and the internal state.

`read` returns a nonnegative (extended) value to match `StepCost`.
-/
structure Clock (V : Type) where
  Q : Type
  init : Q
  step : Nat → V → V → Q → Q
  read : Q → ENNReal

namespace Clock

variable {V : Type} (C : Clock V)

/-- Run the clock along a worldline for `N` steps, returning the internal state. -/
def run (γ : Worldline V) : Nat → C.Q
| 0     => C.init
| (n+1) => C.step n (γ n) (γ (n+1)) (run γ n)

/-- Readout after `N` steps along a worldline. -/
def reading (γ : Worldline V) (N : Nat) : ENNReal := C.read (C.run γ N)

/-- Readout after `N` steps along a *spacetime* worldline (foliation-respecting). -/
def readingST {X : Type} (ST : DiscreteSpacetime X) (C : Clock X)
    (γ : ST.Worldline) (N : Nat) : ENNReal := C.reading (V := X) γ.x N

end Clock

/-- Contract: a clock operationalizes a per-step cost `cost` iff its readout increments
exactly by `cost x y` on each step and starts at `0`. -/
structure Operationalizes {V : Type} (C : Clock V) (cost : StepCost V) : Prop where
  read_init : C.read C.init = 0
  read_step : ∀ n x y q, C.read (C.step n x y q) = C.read q + cost x y

namespace Operationalizes

variable {V : Type} {C : Clock V} {cost : StepCost V}

/-- Main gate: if `C` operationalizes `cost`, then its reading equals the discrete proper time. -/
theorem gate_reading_eq_properTimeUpTo (h : Operationalizes (C := C) (cost := cost))
    (γ : Worldline V) :
    ∀ N, C.reading γ N = properTimeUpTo (V := V) cost γ N := by
  intro N
  induction N with
  | zero =>
      simp [Clock.reading, Clock.run, properTimeUpTo, h.read_init]
  | succ N ih =>
      -- reduce to `ih` by adding the same increment on both sides
      simpa [Clock.reading, Clock.run, properTimeUpTo, Finset.sum_range_succ, h.read_step] using
        congrArg (fun t => t + cost (γ N) (γ (N + 1))) ih

/-- Foliation-aware form: along any `DiscreteSpacetime.Worldline`, readingST equals proper time
computed on the underlying sequence `γ.x`. -/
theorem gate_readingST_eq_properTimeUpTo (ST : DiscreteSpacetime V)
    (h : Operationalizes (C := C) (cost := cost)) (γ : ST.Worldline) :
    ∀ N, Clock.readingST (ST := ST) (C := C) γ N = properTimeUpTo (V := V) cost γ.x N := by
  intro N
  -- unfold `readingST` and reduce to the worldline theorem
  simpa [Clock.readingST] using gate_reading_eq_properTimeUpTo (C := C) (cost := cost) h γ.x N

/-- Canonical accumulator clock: internal state is the accumulated proper time. -/
noncomputable def accumulator (V : Type) (cost : StepCost V) : Clock V where
  Q := ENNReal
  init := 0
  step := fun _ x y q => q + cost x y
  read := fun q => q

/-- The accumulator operationalizes `cost`. -/
theorem gate_accumulator_operationalizes (V : Type) (cost : StepCost V) :
    Operationalizes (C := accumulator (V := V) cost) (cost := cost) := by
  refine ⟨?_, ?_⟩
  · simp [accumulator]
  · intro n x y q
    simp [accumulator]

/-- downstream-target theorem: the accumulator reads exactly `properTimeUpTo`. -/
theorem theorem_CLOCK_accumulator_reads_properTimeUpTo {V : Type}
    (cost : StepCost V) (γ : Worldline V) (N : Nat) :
    (accumulator (V := V) cost).reading γ N = properTimeUpTo (V := V) cost γ N := by
  have h := gate_accumulator_operationalizes (V := V) cost
  simpa using (gate_reading_eq_properTimeUpTo (C := accumulator (V := V) cost) (cost := cost) h γ N)

end Operationalizes

end Kinematics
end PillarA
