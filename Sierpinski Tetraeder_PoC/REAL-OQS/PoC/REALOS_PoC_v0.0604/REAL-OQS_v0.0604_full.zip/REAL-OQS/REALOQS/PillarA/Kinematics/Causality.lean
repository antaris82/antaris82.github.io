import Mathlib
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.SpatialMetric
import REALOQS.PillarA.Core.ResistanceMetric

set_option linter.style.longLine false


set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Discrete causality constraints (speed limit) -- v0.11h-full

To connect discrete substrates to relativistic language later (proper time, worldtubes, lightcones),
Pillar A needs a *non-continuum* notion of causal constraint.

We model this as a **speed limit contract**: there is a constant `c` (in suitable units) such that
any one-step causal transition `step x y` cannot exceed spatial displacement `dist(x,y) ≤ c`.

This is intentionally abstract and does not assume a Lorentzian structure.
-/

namespace PillarA
namespace Kinematics

open PillarA.LayerA

/-- A speed-limit contract for a discrete spacetime equipped with a resistance metric. -/
structure CausalSpeedLimit {X : Type}
    (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) : Type where
  /-- maximal per-step displacement (Pillar-A units). -/
  c : ENNReal
  /-- any allowed step is bounded by `c` in the chosen spatial metric. -/
  step_bound : ∀ {x y : X}, ST.step x y → dist (rm := rm) x y ≤ c

namespace CausalSpeedLimit

variable {X : Type} {ST : DiscreteSpacetime X} {rm : ResistanceMetric X}

/-- A causal worldline (already enforces step correctness, but records the speed bound). -/
def WorldlineBounded (SL : CausalSpeedLimit ST rm) (γ : ST.Worldline) : Prop := ∀ n, dist (rm := rm) (γ.x n) (γ.x (n+1)) ≤ SL.c

/-- Gate: any spacetime worldline is bounded if its steps satisfy the speed bound. -/
theorem gate_worldline_bounded (SL : CausalSpeedLimit ST rm) (γ : ST.Worldline) :
    WorldlineBounded (ST := ST) (rm := rm) SL γ := by
  intro n
  exact SL.step_bound (γ.step_ok n)

end CausalSpeedLimit

end Kinematics
end PillarA
