import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.BoundaryPorts

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Tail / elimination interface (Core, Phase 5)

Pillar A needs a substrate-agnostic place to express:

> “Eliminate the tail of an approximant and return effective boundary data.”

This file introduces **pure interfaces** (hooks), without committing to any physics.

* `TailInterface` provides an abstract tail object at level `L`.
* `TailEliminationHook` is a hook that maps
  `(Approximant, Tail, BoundaryPorts) ↦ EffectiveBoundaryData`.

Concrete realizations (e.g. DtN/Schur/Kron) are implemented as instances.
-/

universe u v

/-- A tail object associated to a substrate at refinement level `L`.

This is intentionally unconstrained; later phases can add laws (e.g. compatibility
under refinement/coarsening, equivariance, etc.).
-/
class TailInterface (Cell : Nat → Type u) where
  Tail : Nat → Type v

namespace TailInterface

variable {Cell : Nat → Type u} [TailInterface (Cell := Cell)]

abbrev TailAt (L : Nat) : Type v := TailInterface.Tail (Cell := Cell) L

end TailInterface

/-- Hook: eliminate a tail and produce effective boundary data.

This is an *interface only*. It does not prescribe how `TailAt L` is computed.
-/
class TailEliminationHook (Cell : Nat → Type u) [TailInterface (Cell := Cell)] where
  EffectiveBoundaryData : Nat → Type v
  eliminate : ∀ {L : Nat} [DecidableEq (Cell L)],
    Approximant Cell L → TailInterface.TailAt (Cell := Cell) L →
    BoundaryPorts Cell L → EffectiveBoundaryData L

namespace TailEliminationHook

variable {Cell : Nat → Type u} [TailInterface (Cell := Cell)] [TailEliminationHook (Cell := Cell)]

abbrev EBD (L : Nat) : Type v := TailEliminationHook.EffectiveBoundaryData (Cell := Cell) L

end TailEliminationHook

end LayerA

end PillarA
