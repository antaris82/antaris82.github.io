import Mathlib
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver


set_option linter.style.longLine false

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Scale-breaking measures from mismatch functional -- v0.11h-full

This module builds **canonical quantitative measures** from the rev8-style mismatch functional
(MD-5):

* normalize both operators by a deterministic trace⊥-based scale,
* remove the nullmode by projecting with a Π⊥-projector,
* apply a nonnegative divergence `D`.

At Pillar A this remains interface-level:
- `coarsen` is abstract,
- `op` is an abstract observation map,
- faithfulness (zero ↔ equality / positive ↔ inequality) is delegated to later.

We explicitly define **two** diagnostics:
- one for the REAL tower,
- one for the IDEAL tower.
This avoids the common interface pitfall where a single diagnostic is implicitly assumed to
serve both towers.
-/

namespace PillarA

namespace Physics

open PillarA.Update

/-- Re-export of the stable observation interface from `Update`. -/
abbrev OpObserver (S : Type) (α : Type) := PillarA.Update.OpObserver S α

/-- Generic mismatch-based diagnostic for an arbitrary tower `tower : ℕ → S`.

Intended reading:
`μ(k) = D( Π Â_k Π , Π Â_{k+1→k} Π )`
where
* `Â_k` observes `tower k`, and
* `Â_{k+1→k}` observes `coarsen k (tower (k+1))`.
-/
noncomputable def breakMeasure_fromMismatch_onTower {S α : Type}
    (coarsen : Nat → S → S) (tower : Nat → S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal := fun k =>
    let Ak : NormalizedOp (α := α) := normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))
    let Acoarse : NormalizedOp (α := α) :=
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))
    M.mismatch Ak Acoarse

/-- REAL diagnostic: mismatch applied to the REAL tower of a `ScaleBreakingAxis`. -/
noncomputable def breakMeasure_fromMismatchReal {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal := breakMeasure_fromMismatch_onTower (α := α) A.coarsen A.real Obs M eps eps_pos

/-- IDEAL diagnostic: mismatch applied to the IDEAL tower of a `ScaleBreakingAxis`. -/
noncomputable def breakMeasure_fromMismatchIdeal {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal := breakMeasure_fromMismatch_onTower (α := α) A.coarsen A.ideal Obs M eps eps_pos

/-- Equip an existing qualitative axis with mismatch-based diagnostics on BOTH towers. -/
noncomputable def axis_fromMismatch {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0) : ScaleBreakingAxis S :=
  { coarsen := A.coarsen,
    ideal := A.ideal,
    real := A.real,
    breakMeasure := breakMeasure_fromMismatchReal (A := A) Obs M eps eps_pos,
    breakMeasureIdeal := breakMeasure_fromMismatchIdeal (A := A) Obs M eps eps_pos }

/-!
## Gate lemmas (interface-level)

At Pillar A we register the obligations (faithfulness and commutation properties) as named
lemmas that can be reused once the relevant concrete ingredients are fixed:
- `coarsen` is implemented concretely,
- `Obs.op` is fixed concretely,
- and the mismatch functional is proven faithful for these choices.
-/

/-- Gate: if the normalized observed operators agree, then the mismatch-based diagnostic is zero.

This statement is independent of whether the tower is IDEAL or REAL.
-/
theorem gate_breakMeasure_zero_of_observed_eq {S α : Type}
    (coarsen : Nat → S → S) (tower : Nat → S)
    (Obs : OpObserver S α) (M : MismatchFunctional (α := α))
    (eps : ℝ) (eps_pos : eps > 0) (k : Nat)
    (hEq : normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)) =
          normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))) :
    (breakMeasure_fromMismatch_onTower (α := α) coarsen tower Obs M eps eps_pos) k = 0 := by
  -- Interface-level gate: if the *normalized* observed operators agree, then the mismatch must vanish.
  -- We only use the minimal contract `MismatchFunctional.mismatch_self`.
  have h0 : M.mismatch
      (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
      (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1))))) = 0 := by
    -- rewrite the second argument using `hEq`, then apply `mismatch_self`.
    calc
      M.mismatch
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (coarsen k (tower (k + 1)))))
          = M.mismatch
              (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k)))
              (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))) := by
                simpa using congrArg (fun X => M.mismatch
                    (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (tower k))) X) hEq.symm
      _ = 0 := M.mismatch_self _
  -- unfold the break measure at `k` and apply `h0`
  simp [breakMeasure_fromMismatch_onTower, h0]

/-- `ScaleBreakingAxis.Laws` for the mismatch-based axis.

This cannot be derived from the abstract interfaces alone. Therefore this definition is
a *constructor* that packages explicit proofs of the two law fields.
-/
def Laws_fromMismatch {S α : Type}
    (A : ScaleBreakingAxis S) (Obs : OpObserver S α)
    (M : MismatchFunctional (α := α)) (eps : ℝ) (eps_pos : eps > 0)
    (hIdeal :
      (axis_fromMismatch (A := A) Obs M eps eps_pos).scaleInvariant →
        ∀ k, (axis_fromMismatch (A := A) Obs M eps eps_pos).breakMeasureIdeal k = 0)
    (hReal :
      (axis_fromMismatch (A := A) Obs M eps eps_pos).breaksScale →
        ∃ k, 0 < (axis_fromMismatch (A := A) Obs M eps eps_pos).breakMeasure k) :
    ScaleBreakingAxis.Laws (axis_fromMismatch (A := A) Obs M eps eps_pos) :=
  ScaleBreakingAxis.Laws.ofProofs
    (A := axis_fromMismatch (A := A) Obs M eps eps_pos)
    hIdeal hReal

end Physics
end PillarA
