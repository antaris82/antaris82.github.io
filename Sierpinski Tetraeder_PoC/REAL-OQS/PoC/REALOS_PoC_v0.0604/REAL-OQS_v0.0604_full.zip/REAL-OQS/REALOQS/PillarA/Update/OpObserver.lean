import Mathlib
import REALOQS.PillarA.Update.MismatchFunctional

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Operator observation interface (MD-5 glue) -- v0.11h-full

Pillar A needs a stable notion of observing an abstract state `S` as an operator on
functions over some finite interface type `α`.

We place this in `Update` (rather than `Physics`) to avoid cyclic dependencies:
- `Physics` builds diagnostics from observations,
- `Update` and OQS semantics can also manufacture such observations.
-/

namespace PillarA
namespace Update

/-
NOTE (Phase 2 upgrade): At Pillar A we keep interfaces in the small universe.
The core `LinOp` and `MismatchFunctional` infrastructure in this repository is
`α : Type` (i.e. `Type 0`). Until that core is made universe-polymorphic, the
dependent observer must also live in `Type`.
-/

/-- Constant (scale-independent) type family helper (Update layer).

Defined here to keep `Update` independent from `Physics`.
-/
def constFamily (S : Type) : Nat → Type := fun _ => S

/-- Observe a state `S` as a (not-necessarily-linear-at-Pillar-A) operator on `α → ℝ`. -/
structure OpObserver (S : Type) (α : Type) where
  op : S → LinOp (α := α)

/-- Dependent observer: the carrier `S k` and interface `α k` may vary with the scale `k`. -/
structure OpObserverD (S : Nat → Type) (α : Nat → Type) where
  op : ∀ k, S k → LinOp (α := α k)

namespace OpObserver

/-- Promote a constant observer to the dependent observer over constant families. -/
def toD {S : Type} {α : Type} (Obs : OpObserver S α) :
    OpObserverD (constFamily S) (constFamily α) :=
  { op := fun _ s => Obs.op s }

@[simp] theorem toD_op {S : Type} {α : Type} (Obs : OpObserver S α) (k : Nat) (s : S) :
    (toD (S := S) (α := α) Obs).op k s = Obs.op s := rfl

end OpObserver

namespace OpObserverD

/-- Demote a dependent observer over constant families to a constant observer.

This picks the `k = 0` component; it is a left-inverse for `OpObserver.toD`.
-/
def toConst {S : Type} {α : Type}
    (Obs : OpObserverD (constFamily S) (constFamily α)) : OpObserver S α :=
  { op := Obs.op 0 }

@[simp] theorem toConst_toD {S : Type} {α : Type} (Obs : OpObserver S α) :
    (OpObserverD.toConst (S := S) (α := α) (OpObserver.toD (S := S) (α := α) Obs)) = Obs := by
  rfl

end OpObserverD


/-- Family of observers, one per scale `k` (convenience abbreviation). -/
abbrev OpObserverFam (S : Nat → Type) (α : Nat → Type) := ∀ k, OpObserver (S k) (α k)

namespace OpObserverFam

/-- Convert a dependent observer into a family of observers. -/
def ofD {S : Nat → Type} {α : Nat → Type} (Obs : OpObserverD S α) : OpObserverFam S α :=
  fun k => { op := Obs.op k }

/-- Convert a family of observers into a dependent observer. -/
def toD {S : Nat → Type} {α : Nat → Type} (F : OpObserverFam S α) : OpObserverD S α :=
  { op := fun k => (F k).op }

@[simp] theorem ofD_toD {S : Nat → Type} {α : Nat → Type} (F : OpObserverFam S α) :
    ofD (toD (S := S) (α := α) F) = F := by
  funext k
  -- Unfold once so that the goal becomes a definitional equality on the one-field structure.
  cases hk : F k with
  | mk op =>
      -- After rewriting by `hk`, both sides are definitional.
      simp [OpObserverFam.ofD, OpObserverFam.toD, hk]

@[simp] theorem toD_ofD {S : Nat → Type} {α : Nat → Type} (Obs : OpObserverD S α) :
    toD (S := S) (α := α) (ofD Obs) = Obs := by
  cases Obs
  rfl

end OpObserverFam

end Update
end PillarA
