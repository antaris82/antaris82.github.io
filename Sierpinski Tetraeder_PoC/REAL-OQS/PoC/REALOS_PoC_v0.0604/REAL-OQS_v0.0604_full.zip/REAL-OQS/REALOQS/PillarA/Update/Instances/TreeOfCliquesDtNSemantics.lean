/-
Deprecated: Tree-of-Cliques DtN semantics instances were moved to
`REALOQS.PillarA.Ideal.Adapter.*` to satisfy import policy (Update must not import Ideal).

This module is kept only for backwards compatibility with older import paths.
It intentionally provides no concrete instances.
-/
import REALOQS.PillarA.Update.TailEliminationDtN

namespace REALOQS.PillarA.Update.Instances

-- Intentionally empty.

end REALOQS.PillarA.Update.Instances
