import Mathlib
import REALOQS.PillarA.OQS.DtNStabilized

set_option autoImplicit false
open scoped BigOperators

/-!
# Analytical criteria for eliminating the `det(LII_stabilized) ≠ 0` gate

`DtNStabilized` intentionally keeps **well-posedness** of the stabilized interior block behind
an explicit gate `det(LII_stabilized) ≠ 0`.

This file provides *mathematical sufficient conditions* implying that gate automatically.

Currently implemented (fully formal):

* **PSD + strictly positive jitter** ⇒ `stabilize(A, δ)` is positive definite ⇒ det ≠ 0.

This is the right shape for graph Laplacians:
`symm(blockII L)` is expected to be positive semidefinite, while `δ(A)` is strictly positive
by construction (`Policy.eps > 0`).

Further criteria (not yet formalized here):
* strict diagonal dominance / M-matrix arguments
* connectivity / Dirichlet Laplacian coercivity
-/

namespace PillarA
namespace OQS
namespace Split
namespace DtNStabilized

noncomputable section

open PillarA.LayerA

variable {V : Type} [Fintype V] [DecidableEq V]
variable (s : PillarA.OQS.Split V)

variable {b : Nat}

/-!
## Core lemma: `PosSemidef A` and `0 < δ` imply `det(stabilize A δ) ≠ 0`
-/

theorem det_stabilize_ne_zero_of_posSemidef
    {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) (hA : A.PosSemidef)
    {δ : ℝ} (hδ : 0 < δ) :
    (stabilize (ι := ι) A δ).det ≠ 0 := by
  classical
  -- Identity is positive definite, hence so is `δ • I` for `δ > 0`.
  have hI : (1 : Matrix ι ι ℝ).PosDef := by
    simpa using (Matrix.PosDef.one (n := ι) (R := ℝ))
  have hδI : (δ • (1 : Matrix ι ι ℝ)).PosDef := hI.smul hδ
  -- `A + δ•I` is positive definite if `A` is positive semidefinite and `δ•I` is positive definite.
  have hpos : (A + δ • (1 : Matrix ι ι ℝ)).PosDef :=
    Matrix.PosDef.posSemidef_add (A := A) (B := δ • (1 : Matrix ι ι ℝ)) hA hδI

  -- Positive definite matrices are units, hence their determinant is a unit, hence nonzero.
  have hunit : IsUnit (A + δ • (1 : Matrix ι ι ℝ)) := Matrix.PosDef.isUnit hpos
  have hdetUnit : IsUnit ((A + δ • (1 : Matrix ι ι ℝ)).det) :=
    (Matrix.isUnit_iff_isUnit_det (A + δ • (1 : Matrix ι ι ℝ))).1 hunit

  have hdet : ((A + δ • (1 : Matrix ι ι ℝ)).det) ≠ 0 := by
    rcases hdetUnit with ⟨u, hu⟩
    -- `u` is a unit in `ℝ`, hence nonzero; rewrite the determinant using `hu`.
    simpa [hu] using (u.ne_zero)

  -- Rewrite back to `stabilize`.
  simpa [stabilize] using hdet


/-!
## Consequence for the stabilized interior block `LII_stabilized`

If `symm(blockII L)` is positive semidefinite, then the canonical jitter `deltaSPD` (strictly
positive by `Policy.eps_pos`) forces `det(LII_stabilized p L) ≠ 0`.
-/

theorem det_LII_stabilized_ne_zero_of_posSemidef
    (p : Policy b) (L : Matrix V V ℝ)
    (hpsd : (symm (ι := s.I) (s.blockII L)).PosSemidef) :
    (LII_stabilized (s := s) (p := p) L).det ≠ 0 := by
  classical
  -- abbreviate the symmetrized interior block
  let A : Matrix s.I s.I ℝ := symm (ι := s.I) (s.blockII L)
  have hδ : 0 < deltaNum (p := p) (ι := s.I) A := deltaNum_pos (p := p) (ι := s.I) A
  -- apply the core lemma
  have hdet : (stabilize (ι := s.I) A (deltaNum (p := p) (ι := s.I) A)).det ≠ 0 :=
    det_stabilize_ne_zero_of_posSemidef (A := A) (hA := hpsd) (hδ := hδ)
  -- `deltaNum` is just an alias for `deltaSPD`, so this is exactly the gate for `LII_stabilized`.
  simpa [LII_stabilized, A, deltaNum, deltaSPD] using hdet

end

end DtNStabilized
end Split
end OQS
end PillarA
