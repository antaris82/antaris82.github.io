import Mathlib
import REALOQS.PillarA.Core.Policy


set_option linter.style.longLine false

set_option autoImplicit false

/-!
# Determinism ladder (D0/D1) and policy-hash stability (Pillar A)

This module fixes **what Pillar A can prove** vs **what Pillar A only demands as a contract**.

* **Provable in Pillar A (no contracts):**
  - All *derived* policy parameters are definitional functions of `Policy.key`.
    (Because `Policy.key` is injective.)

* **Contracts (Layer B obligations):**
  - A concrete policy hash function (`PolicyHash`).
  - Export/serialization stability (`ExportLaws`): exports must depend only on the
    semantic key (and the artifact/step), not on hidden implementation choices.

Dieses Modul enthält kein `deferred proof`; es fixiert nur Gates und explizite Contracts.
-/

namespace PillarA

namespace LayerA

namespace Determinism

/-- Determinism levels used as a documentation/contract handle. -/
inductive Level where
  | D0 : Level
  | D1 : Level
  deriving DecidableEq, Repr

variable {b : Nat}

/-! ## Policy hash (contract) -/

/-- Abstract policy hash function used by Layer B for drift prevention.

Contract:
* `hash` depends only on the semantic key `Policy.key`.
* On the supported policy domain, `hash` is key-injective.
-/
structure PolicyHash (b : Nat) where
  hash : Policy b → Nat
  depends_only_on_key : ∀ p q : Policy b, Policy.key p = Policy.key q → hash p = hash q
  key_of_hash : ∀ p q : Policy b, hash p = hash q → Policy.key p = Policy.key q

/-! ## D0: derived policy parameters are functions of the key (provable) -/

/-- D0 gate: equality of semantic keys forces equality of all derived parameters.

This is *provable* in Pillar A because `Policy.key` is injective.
-/
theorem gate_D0_DERIVED_PARAMS_OF_KEY (p q : Policy b)
    (hkey : Policy.key p = Policy.key q) :
    (Policy.K_max p = Policy.K_max q) ∧
    (Policy.eps0 p = Policy.eps0 q) ∧
    (Policy.alphaDenom p = Policy.alphaDenom q) ∧
    (∀ k, Policy.alpha p k = Policy.alpha q k) := by
  have hpq : p = q := Policy.key_injective (b := b) hkey
  simpa using (Policy.gate_POLICY_derived_stable (b := b) (p := p) (q := q) hpq)

/-! ## Policy-hash stability (provable from `PolicyHash`) -/

/-- Gate: key equality is equivalent to hash equality (for a given `PolicyHash`).

This is provable from the `PolicyHash` contract fields; no additional assumptions.
-/
theorem gate_POLICY_HASH_STABLE (H : PolicyHash b) (p q : Policy b) :
    (Policy.key p = Policy.key q → H.hash p = H.hash q) ∧
    (H.hash p = H.hash q → Policy.key p = Policy.key q) := by
  refine ⟨?_, ?_⟩
  · intro h; exact H.depends_only_on_key p q h
  · intro h; exact H.key_of_hash p q h

/-! ## Export determinism (contract) -/

/-- A minimal representation of exported artifacts.

Layer B may strengthen this to an actual byte-encoding; Pillar A only requires stability.
-/
structure ExportBundle where
  payload : String

/-- Export interface (Layer B contract): exports depend only on policy and the artifact.

Note: Lean functions are pure, but this contract prevents *semantic drift* by forcing
exports to depend only on `Policy.key` rather than on any hidden/derived values.
-/
structure Exporter (b : Nat) (Artifact : Type) where
  emit : Policy b → Nat → Artifact → ExportBundle

/-- D1 export stability contract: exports must depend only on the semantic key.

This is a **Layer B obligation** (cannot be proven for arbitrary exporters).
-/
class ExportLaws {Artifact : Type} (E : Exporter b Artifact) : Prop where
  depends_only_on_key :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a

/-- Re-exported D1 gate: statement form used by downstream modules.

No `deferred proof` here; proofs are supplied by providing an instance `[ExportLaws E]`.
-/
theorem gate_D1_EXPORT_DEPENDS_ONLY_ON_KEY {Artifact : Type} (E : Exporter b Artifact)
    [ExportLaws (b := b) E] :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a :=
  ExportLaws.depends_only_on_key (E := E)

/-- Build `ExportLaws` from an explicit proof that `emit` depends only on the semantic key. -/
def ExportLaws.mkOfKeyInvariant {Artifact : Type} (E : Exporter b Artifact)
    (h : ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a) :
    ExportLaws (b := b) E :=
  ⟨h⟩

end Determinism

end LayerA

end PillarA
