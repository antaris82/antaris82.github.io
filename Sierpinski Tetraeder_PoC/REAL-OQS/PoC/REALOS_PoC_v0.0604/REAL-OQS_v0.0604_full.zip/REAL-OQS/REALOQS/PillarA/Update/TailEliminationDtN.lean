import Mathlib
import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver
import REALOQS.PillarA.OQS.DtN



set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Tail-elimination semantics as DtN (Schur/Kron) -- v0.11h-full

This module adds the missing *semantic hook* for the central project statement:

> "Stage1" of the update pipeline is **tail elimination**, and tail elimination is
> implemented as a **Dirichlet-to-Neumann (DtN) / Schur complement / Kron reduction**.

Pillar A still keeps the carrier state space `S` abstract, but it must provide a stable
place to assert (and later prove) the equality:

  observe(stage1(s)) = DtN( fullOperator(s) )

All heavy proofs are intentionally left to downstream/Lean via `placeholder proof`.
-/

namespace PillarA
namespace Update

open scoped BigOperators

open PillarA.OQS

/-- Convert a matrix into a `LinOp` on `α → ℝ` via `mulVec`. -/
def linOpOfMatrix {α : Type} [Fintype α] [DecidableEq α]
    (M : Matrix α α ℝ) : LinOp (α := α) :=
  ⟨fun f => M.mulVec f⟩

/-- Semantic contract: stage1 is DtN-elimination on a fixed split `V ≃ B ⊕ I`.

Interpretation:
* `L s` is the full (pre-elimination) operator of the state `s` on `V`.
* `boundaryOp s` is the *observed* boundary operator (intended: BB-block / effective operator).
* `inv s` is a witness that the interior block is invertible (possibly after deterministic
  jitter; see `OQS.DtN`).
* `stage1_boundaryOp_eq_DtN` is the key semantic link.

This does **not** prescribe how `truncateTail` or `integrateTail` are implemented; it only
pins down the semantic meaning of `stage1`.
-/
structure TailElimDtNSemantics {b : Nat} (A : TwoStageApprox b) where
  V : Type
  [instFintypeV : Fintype V]
  [instDecEqV : DecidableEq V]

  split : OQS.Split V

  /-- Full operator associated to a state (intended: Laplacian / generator). -/
  L : A.S → Matrix V V ℝ

  /-- Inverse witness of the interior block used in DtN
  (may include deterministic stabilization). -/
  inv : ∀ s : A.S, Split.InteriorInv (s := split) (L s)

  /-- Observed boundary operator on the interface degrees of freedom. -/
  boundaryOp : A.S → Matrix split.B split.B ℝ

  /-- Optional definitional tie: boundaryOp is the BB-block of the full operator.

  This is useful when the state is literally a full operator. If the state already stores
  a reduced operator, choose any compatible extension `L` and prove this by a
  separate compatibility lemma.
  -/
  boundaryOp_def : ∀ s, boundaryOp s = split.blockBB (L s)

  /-- Core semantic equation: stage1 computes the DtN of the previous full operator.

  This is the formal Pillar-A statement of "tail elimination".
  -/
  stage1_boundaryOp_eq_DtN : ∀ s, boundaryOp (A.stage1 s) = split.DtN_of (L s) (inv s)

attribute [instance] TailElimDtNSemantics.instFintypeV TailElimDtNSemantics.instDecEqV

namespace TailElimDtNSemantics

variable {b : Nat} {A : TwoStageApprox b}

/-- A canonical operator observer derived from `boundaryOp`. -/
def opObserver (Sem : TailElimDtNSemantics A) : OpObserver A.S Sem.split.B :=
  ⟨fun s => linOpOfMatrix (α := Sem.split.B) (Sem.boundaryOp s)⟩

/-- Gate: after stage1, the observed operator equals the DtN of the previous full operator. -/
theorem gate_STAGE1_IS_DTN (Sem : TailElimDtNSemantics A) (s : A.S) :
    (Sem.opObserver.op (A.stage1 s)) =
      linOpOfMatrix (α := Sem.split.B) (Sem.split.DtN_of (Sem.L s) (Sem.inv s)) := by
  -- extensionality for `LinOp` (pointwise on the underlying function)
  ext f x
  -- unfold the derived observer and reduce to the matrix-level semantic equation
  simpa [TailElimDtNSemantics.opObserver, linOpOfMatrix] using
    congrArg
      (fun M : Matrix Sem.split.B Sem.split.B ℝ => (M.mulVec f) x)
      (Sem.stage1_boundaryOp_eq_DtN s)

end TailElimDtNSemantics

end Update
end PillarA
