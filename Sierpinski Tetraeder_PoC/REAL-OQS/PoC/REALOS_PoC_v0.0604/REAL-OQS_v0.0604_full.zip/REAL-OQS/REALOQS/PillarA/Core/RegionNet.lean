import Mathlib
set_option linter.style.longLine false


set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Region / Net interface (AQFT preparation)

This module fixes a *stable, purely discrete* index interface for later AQFT lifts.

Core idea:
- Regions form a partially ordered set (intended: inclusion / refinement).
- The index is **directed**: for any two regions there is a region containing both.
  (In practice provided by a `sup` / join operation.)
- Optionally we attach a **boundary** operator that is *functorial under refinement*
  (monotone w.r.t. the region order).

No continuum structure is assumed.
-/

universe u v w

/-! ## Region index structures -/

/--
`RegionNet Ω` packages:

* an abstract region type `Region`,
* an inclusion/refinement order (as `PartialOrder`),
* a join-like operation (`SemilatticeSup`) giving directedness,
* a top region (`OrderTop`) and monotone semantics `carrier : Region → Set Ω`.

This is deliberately small and stable. Pillar B can interpret `carrier` as the underlying
subset of sites (`Ω`) and refine it to geometric / causal notions later.
-/
structure RegionNet (Ω : Type u) where
  Region : Type v
  /-- The region order is provided as a `SemilatticeSup`.

  We intentionally do **not** store a separate `PartialOrder`/`LE` instance here,
  since `SemilatticeSup` already provides one; storing both creates competing `LE`
  instances and can make typeclass inference get stuck.
  -/
  instSup : SemilatticeSup Region
  /-- A distinguished “top” region, not packaged as a typeclass to avoid another competing `LE`.
  Use `RN.top` and `RN.le_top` instead of `⊤`/`le_top`.
  -/
  top : Region
  le_top : (letI := instSup; ∀ a : Region, a ≤ top)
  carrier : Region → Set Ω
  carrier_mono : ∀ {a b : Region}, (letI := instSup; a ≤ b) → carrier a ⊆ carrier b

namespace RegionNet

variable {Ω : Type u}

instance (RN : RegionNet Ω) : SemilatticeSup RN.Region := RN.instSup

@[simp] theorem carrier_mono' (RN : RegionNet Ω) {a b : RN.Region} (hab : a ≤ b) :
    RN.carrier a ⊆ RN.carrier b := by
  simpa using RN.carrier_mono (a := a) (b := b) hab

/-! ### Named “gates” (stable hooks for later layers) -/

theorem gate_REGION_le_refl (RN : RegionNet Ω) (a : RN.Region) : a ≤ a := by
  exact le_rfl

theorem gate_REGION_le_trans (RN : RegionNet Ω) {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) :
    a ≤ c := by
  exact le_trans hab hbc

theorem gate_REGION_le_antisymm (RN : RegionNet Ω) {a b : RN.Region} (hab : a ≤ b) (hba : b ≤ a) :
    a = b := by
  exact le_antisymm hab hba

/-- Directedness (existence of a common upper bound) derived from `sup`. -/
theorem directed (RN : RegionNet Ω) :
    ∀ a b : RN.Region, ∃ c : RN.Region, a ≤ c ∧ b ≤ c := by
  intro a b
  refine ⟨a ⊔ b, ?_, ?_⟩
  · exact le_sup_left
  · exact le_sup_right

theorem gate_REGION_directed (RN : RegionNet Ω) (a b : RN.Region) :
    ∃ c : RN.Region, a ≤ c ∧ b ≤ c := directed (RN := RN) a b

/-- Convenience: `top` is an upper bound for every region. -/
theorem le_top' (RN : RegionNet Ω) (a : RN.Region) : a ≤ RN.top := by
  simpa using (RN.le_top a)

end RegionNet

/-! ## Optional boundary operator (functoriality under refinement) -/

/--
A boundary extension of a region net.

`boundary` is required to be monotone:
`a ≤ b → boundary a ≤ boundary b`.

This is the precise, stable notion of “boundary functoriality under refinement”
needed later (parent/child compatibility, refinement/shift stability, …).
-/
structure RegionNetWithBoundary (Ω : Type u) where
  base : RegionNet Ω
  boundary : base.Region → base.Region
  boundary_mono : (letI := base.instSup; Monotone boundary)

namespace RegionNetWithBoundary

variable {Ω : Type u} (RNb : RegionNetWithBoundary Ω)

instance : SemilatticeSup RNb.base.Region := RNb.base.instSup

@[simp] theorem boundary_mono' {a b : RNb.base.Region} (hab : a ≤ b) :
    RNb.boundary a ≤ RNb.boundary b := (RNb.boundary_mono hab)

theorem gate_BOUNDARY_functorial {a b : RNb.base.Region} (hab : a ≤ b) :
    RNb.boundary a ≤ RNb.boundary b := boundary_mono' (RNb := RNb) hab

end RegionNetWithBoundary

/-! ## Optional complement / environment operator -/

/--
A complement extension of a region net.

This enables stable “environment/complement” bookkeeping in later layers:
`env(r) := compl(r)`.

Only minimal algebraic structure is assumed:
- antitone (order-reversing)
- involutive (`compl (compl r) = r`)

No Boolean algebra laws are postulated at Pillar A.
-/
structure RegionNetWithCompl (Ω : Type u) where
  base : RegionNet Ω
  compl : base.Region → base.Region
  compl_antitone : (letI := base.instSup; Antitone compl)
  compl_involutive : ∀ r : base.Region, compl (compl r) = r

namespace RegionNetWithCompl

variable {Ω : Type u} (RNc : RegionNetWithCompl Ω)

instance : SemilatticeSup RNc.base.Region := RNc.base.instSup

@[simp] theorem compl_antitone' {a b : RNc.base.Region} (hab : a ≤ b) :
    RNc.compl b ≤ RNc.compl a := (RNc.compl_antitone hab)

theorem gate_COMPL_antitone {a b : RNc.base.Region} (hab : a ≤ b) :
    RNc.compl b ≤ RNc.compl a := compl_antitone' (RNc := RNc) hab

@[simp] theorem compl_compl (r : RNc.base.Region) : RNc.compl (RNc.compl r) = r := RNc.compl_involutive r

theorem gate_COMPL_involutive (r : RNc.base.Region) : RNc.compl (RNc.compl r) = r := RNc.compl_involutive r

end RegionNetWithCompl

/-! ## Canonical region nets -/

/-- Canonical “regions are sets” region net. -/
def SetRegionNet (Ω : Type u) : RegionNet Ω where
  Region := Set Ω
  instSup := inferInstance
  top := Set.univ
  le_top := by
    intro a x hx
    trivial
  carrier := fun r => r
  carrier_mono := by
    intro a b hab
    simpa using hab

/--
Canonical **finite** region net: regions are `Finset Ω`.

This is the workhorse for later concrete AQFT constructions where locality is indexed by
finite collections of sites.
-/
def FinsetRegionNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] : RegionNet Ω where
  Region := Finset Ω
  instSup := inferInstance
  top := Finset.univ
  le_top := by
    intro a
    exact Finset.subset_univ a
  carrier := fun r => (r : Set Ω)
  carrier_mono := by
    intro a b hab
    intro x hx
    exact hab hx

/-- Canonical “regions are sets” region net with complement as environment operator. -/
def SetRegionNetWithCompl (Ω : Type u) : RegionNetWithCompl Ω where
  base := SetRegionNet Ω
  compl := fun r => Set.compl r
  compl_antitone := by
    intro a b hab
    -- Antitone by direct contrapositive (no reliance on lemma names).
    intro x hx
    -- `hx : x ∉ b`; to show `x ∉ a`.
    intro ha
    exact hx (hab ha)
  compl_involutive := by
    intro r
    classical
    -- Use set extensionality lemma (not the `ext` tactic).
    -- This avoids reliance on an `[ext]` lemma for the `Region` alias.
    apply Set.ext
    intro x
    constructor
    · intro hx
      -- `x ∈ (compl r).compl` means `x ∉ compl r`.
      change x ∉ Set.compl r at hx
      -- If `x ∉ r` then `x ∈ compl r`, contradicting `hx`.
      by_contra hr
      have : x ∈ Set.compl r := by
        -- `x ∈ compl r` is definitionaly `x ∉ r`.
        exact hr
      exact hx this
    · intro hx
      -- To show `x ∈ (compl r).compl`, unfold membership in the complement.
      change x ∉ Set.compl r
      intro hxcr
      -- `hxcr : x ∈ compl r` is a proof that `x ∉ r`.
      exact hxcr hx

/-! ## Substrate-specific embeddings

Substrate-specific embeddings (e.g. IDEAL address trees) must live outside `Core`.

* IDEAL embedding: `REALOQS.PillarA.Ideal.Adapter.RegionNetEmbedding`
-/

/-! ## Nets over regions (isotony / functoriality skeleton) -/

namespace Net

variable {Ω : Type u} (RN : RegionNet Ω)

-- Work in the region order associated to `RN`.
-- The order comes from `RN.instSup` (via the global instance declared in `RegionNet`).

/--
Minimal “net” interface: assigns a type to each region, with inclusion maps
respecting identity and composition.

Pillar B will refine `Obj r` to a *local algebra* and `map` to a *∗-homomorphism*.
-/
structure PreNet where
  Obj : RN.Region → Type w
  map : ∀ {a b : RN.Region}, a ≤ b → Obj a → Obj b
  map_id : ∀ (a : RN.Region) (x : Obj a), map (a := a) (b := a) (le_rfl) x = x
  map_comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c) (x : Obj a),
      map (a := b) (b := c) hbc (map (a := a) (b := b) hab x) =
        map (a := a) (b := c) (le_trans hab hbc) x

end Net

end LayerA

end PillarA
