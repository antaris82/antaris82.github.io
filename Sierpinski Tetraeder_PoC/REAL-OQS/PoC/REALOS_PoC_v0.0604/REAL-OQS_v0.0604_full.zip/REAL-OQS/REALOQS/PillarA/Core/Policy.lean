import Mathlib

set_option autoImplicit false

open scoped BigOperators

namespace PillarA
namespace LayerA

/-!
# Deterministic Policy (Lean object)

A `Policy b` contains only the *truncation regulator* needed to choose a finite
Tree-of-Cliques approximant. All other quantities used on the strict Pillar-A
path are derived canonically from `(b, L_max)`.

This file contains only discrete / algebraic objects; no continuum structure is
assumed.
-/

/-- Historical ground-choice tags retained for documentation compatibility. -/
inductive GroundRule where
  | minId : GroundRule
  | minLex : GroundRule
  deriving DecidableEq, Repr

/-- Minimal policy input for a fixed branching factor `b`: only the truncation
regulator survives as primitive data. -/
structure Policy (b : Nat) where
  /-- Maximum depth / truncation level (regulator, not ontic data). -/
  L_max : Nat

namespace Policy

variable {b : Nat}

/-- A small semantic key for drift prevention.

Since all strict-path quantities are derived canonically from `(b, L_max)`, the
semantic key reduces to the truncation regulator alone.
-/
abbrev Key (_b : Nat) := Nat

/-- Deterministic key of a policy. -/
def key (p : Policy b) : Key b := p.L_max

theorem key_congr {p q : Policy b} (h : p = q) : p.key = q.key := by
  cases h
  rfl

theorem key_injective {p q : Policy b} (h : p.key = q.key) : p = q := by
  cases p with
  | mk Lp =>
    cases q with
    | mk Lq =>
      cases h
      rfl

/-- Canonical constructor: a policy is determined by its truncation regulator. -/
def canonical (b : Nat) (L_max : Nat) : Policy b :=
  { L_max := L_max }

theorem canonical_eq_iff {L1 L2 : Nat} :
    canonical (b := b) L1 = canonical (b := b) L2 ↔ L1 = L2 := by
  constructor
  · intro h
    cases h
    rfl
  · intro h
    subst h
    rfl

/-! ## Canonically derived parameters -/

/-- Fixed integration level (`L_int := 1` in the canonical reduction). -/
def L_int (_p : Policy b) : Nat := 1

/-- `K_max := max(L_max - 1, 0)` (implemented as `Nat.pred`). -/
def K_max (p : Policy b) : Nat := Nat.pred p.L_max

theorem K_max_def (p : Policy b) : p.K_max = Nat.pred p.L_max := rfl

/-- Deterministic ground choice on the strict path: fixed canonical rule. -/
def groundRule (_p : Policy b) : GroundRule := GroundRule.minId

/-- Canonical ToC-derived scale ratio from the branching factor.

This removes `rStar` from the primitive policy surface. -/
noncomputable def rStar (_p : Policy b) : ℝ := 1 / ((b : ℝ) + 1)

/-- Canonical step size elimination (`η := 1`, absorbed into weights elsewhere). -/
noncomputable def eta (_p : Policy b) : ℝ := (1 : ℝ)

/-- Float64 machine epsilon as a *mathematical constant* `2^(-52)`.

This is used only to provide a deterministic, refactor-stable regularization
scale. It does not assert anything about floating-point execution.
-/
noncomputable def epsMach64 : ℝ := (2 : ℝ) ^ (-52 : ℤ)

/-- Canonical floor regularization scale `ε_floor := sqrt(ε_mach)`. -/
noncomputable def epsFloor64 : ℝ := Real.sqrt epsMach64

/-- Positivity of the machine-epsilon constant. -/
theorem epsMach64_pos : (0 : ℝ) < epsMach64 := by
  have h2 : (0 : ℝ) < (2 : ℝ) := by norm_num
  simpa [epsMach64] using (zpow_pos h2 (-52 : ℤ))

/-- Positivity of the canonical floor scale `ε_floor = sqrt(ε_mach)`. -/
theorem epsFloor64_pos : (0 : ℝ) < epsFloor64 := by
  have h : (0 : ℝ) < epsMach64 := epsMach64_pos
  simpa [epsFloor64] using (Real.sqrt_pos.2 h)

/-- Canonical regularization parameter `ε := ε_floor`. -/
noncomputable def eps (_p : Policy b) : ℝ := epsFloor64

/-- Positivity of the policy epsilon `ε`. -/
theorem eps_pos (p : Policy b) : (0 : ℝ) < p.eps := by
  simpa [Policy.eps] using epsFloor64_pos

/-- Canonical initial scale `ε0 := max(r_*^{L_max}, ε_floor)`. -/
noncomputable def eps0 (p : Policy b) : ℝ := max (p.rStar ^ p.L_max) epsFloor64

/-! ### Canonical normalized scale weights `α_k` -/

/-- Denominator `∑_{j=1..K_max} r_*^j` used for normalized weights. -/
noncomputable def alphaDenom (p : Policy b) : ℝ :=
  (Finset.Icc (1 : Nat) p.K_max).sum (fun j => p.rStar ^ j)

/-- Normalized scale weight `α_k`.

Convention:
- outside `k ∈ [1..K_max]`, `α_k = 0`.
- if the denominator is zero (degenerate choice), division uses field conventions.
  Normalization properties are stated as separate gates/lemmas under assumptions.
-/
noncomputable def alpha (p : Policy b) (k : Nat) : ℝ :=
  if k ∈ Finset.Icc (1 : Nat) p.K_max then
    (p.rStar ^ k) / p.alphaDenom
  else
    0

theorem alpha_eq_zero_of_not_mem (p : Policy b) {k : Nat}
    (hk : k ∉ Finset.Icc (1 : Nat) p.K_max) : p.alpha k = 0 := by
  simp [Policy.alpha, hk]

theorem alpha_eq_div_of_mem (p : Policy b) {k : Nat}
    (hk : k ∈ Finset.Icc (1 : Nat) p.K_max) :
    p.alpha k = (p.rStar ^ k) / p.alphaDenom := by
  simp [Policy.alpha, hk]

/-! ## Stability / "hash" style gates -/

/-- "Policy-hash stability" in the logical sense:

If policies are equal, all derived parameters are equal.
-/
theorem gate_POLICY_derived_stable {p q : Policy b} (h : p = q) :
    (p.K_max = q.K_max) ∧
    (p.eps0 = q.eps0) ∧
    (p.alphaDenom = q.alphaDenom) ∧
    (∀ k, p.alpha k = q.alpha k) := by
  cases h
  refine ⟨rfl, ?_⟩
  refine ⟨rfl, ?_⟩
  refine ⟨rfl, ?_⟩
  intro k
  rfl

end Policy

end LayerA
end PillarA
