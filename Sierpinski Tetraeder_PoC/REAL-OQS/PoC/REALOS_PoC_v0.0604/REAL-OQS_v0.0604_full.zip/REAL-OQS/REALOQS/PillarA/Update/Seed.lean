import Mathlib
import REALOQS.PillarA.Core.Selection

set_option autoImplicit false
set_option linter.style.commandStart false

namespace PillarA

namespace Update

/-!
# Seed specification (substrate-agnostic contract)

Phase 4 goal: `PillarA.Update.*` must not import `PillarA.Ideal.*`.

A *seed* is modeled as a deterministic function that maps a *key* (e.g. a cell,
a region, a subsystem descriptor) and a step index to a `UInt64`.

This is purely formal: we only express simple invariances via `StableUnder`.
Any concrete hashing or entropy source belongs to later layers.
-/

universe u

/-- Abstract seed specification for an arbitrary key type. -/
structure SeedSpec (Key : Type u) where
  seed : Key → Nat → UInt64

namespace SeedSpec

variable {Key : Type u} (S : SeedSpec Key)

/-- Trivial determinism: `seed` is a function. -/
theorem deterministic (k : Key) (n : Nat) :
    S.seed k n = S.seed k n := by
  rfl

/-- Canonicality under a key equivalence (e.g. relabelling/normal form). -/
def StableUnder (e : Key ≃ Key) : Prop := ∀ k n, S.seed (e k) n = S.seed k n

theorem stable_id : S.StableUnder (Equiv.refl Key) := by
  intro k n
  rfl

theorem stable_comp {e1 e2 : Key ≃ Key}
    (h1 : S.StableUnder e1) (h2 : S.StableUnder e2) :
    S.StableUnder (e1.trans e2) := by
  intro k n
  -- `trans` composes equivalences: apply `e1` then `e2`.
  have h2' : S.seed (e2 (e1 k)) n = S.seed (e1 k) n := h2 (e1 k) n
  have h1' : S.seed (e1 k) n = S.seed k n := h1 k n
  simpa [SeedSpec.StableUnder] using h2'.trans h1'

end SeedSpec

end Update

end PillarA
