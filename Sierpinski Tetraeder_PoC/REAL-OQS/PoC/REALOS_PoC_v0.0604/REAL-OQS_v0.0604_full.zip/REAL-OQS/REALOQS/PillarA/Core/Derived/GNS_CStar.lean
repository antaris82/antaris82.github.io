import Mathlib.Data.Complex.Basic
import Mathlib.Analysis.InnerProductSpace.Basic

import REALOQS.PillarA.Core.Derived.GNS

/-!
# Derived GNS / C⋆ compatibility shim

Historically this file carried a project-local placeholder marker for an
intended C⋆-over-`ℂ` regime. That surrogate has been removed.

Policy going forward:

* analytic C⋆ structure comes from Mathlib typeclasses,
* REALOQS may only add light wrappers/bridges,
* no project-local replacement marker is kept here.

This file remains only as an inert compatibility node for older imports while
the actual C⋆ path lives on the Mathlib-based Pillar-B side.
-/

set_option autoImplicit false

namespace PillarA
namespace Derived

section CStar

/--
Compatibility constant recording that this shim is intentionally inert. Any
future C⋆-specific development should quantify directly over Mathlib
assumptions instead of introducing a local marker.
-/
def gnsCStarShim : Unit := ()

end CStar

end Derived
end PillarA
