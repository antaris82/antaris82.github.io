import Mathlib
import REALOQS.PillarA.Kinematics.FrameChange

/-!
REALOQS / Pillar A / Layer A: Kinematics Hooks (downstream targets) -- v0.11 (2026-01-22)

Abstract predicates to encode:
- inertial frame change: timeIndependent U
- non-inertial attached frame: ¬ timeIndependent U (witness via relChange ≠ 1)
- pointwise rest frames: ∃ gₙ s.t. gₙ • vₙ = 0
- global rest frame: ∃ g0 s.t. g0 • vₙ = 0 for all n
-/

namespace PillarA
namespace Kinematics

section PointwiseRest

variable {Vel : Type} [Zero Vel]
variable {G : Type} [Group G] [MulAction G Vel]

/-- A discrete "velocity history". -/
abbrev VelHist (Vel : Type) := ℕ → Vel

def hasPointwiseRestFrame (v : VelHist Vel) : Prop := ∃ (g : ℕ → G), ∀ n, g n • v n = 0

def hasGlobalRestFrame (v : VelHist Vel) : Prop := ∃ (g0 : G), ∀ n, g0 • v n = 0

theorem gate_GLOBAL_REST_IMPLIES_POINTWISE (v : VelHist Vel) :
    hasGlobalRestFrame (Vel := Vel) (G := G) v → hasPointwiseRestFrame (Vel := Vel) (G := G) v := by
  intro h
  rcases h with ⟨g0, hg0⟩
  refine ⟨fun _ => g0, ?_⟩
  intro n
  simpa using hg0 n

end PointwiseRest

section FrameNonInertial

variable {S : Type}

def nonInertial (U : Frame S) : Prop := ∃ n, relChange (S := S) U n ≠ 1

theorem gate_NONINERTIAL_IMP_NOT_TIMEINDEP (U : Frame S) :
    nonInertial (S := S) U → ¬ timeIndependent (S := S) U := by
  intro h
  exact gate_NONINERTIAL_IF_RELCHANGE_NE_ID (S := S) U h

end FrameNonInertial

end Kinematics
end PillarA
