import REALOQS.PillarA.Ideal.IdealSymmetryNoether

/-!
# IDEAL Adapter: IdealSymmetryNoether

Thin re-export wrapper (Phase 8 import policy).
-/
