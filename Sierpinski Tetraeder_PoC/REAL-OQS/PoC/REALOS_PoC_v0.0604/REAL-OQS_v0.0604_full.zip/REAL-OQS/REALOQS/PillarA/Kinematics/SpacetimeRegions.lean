import Mathlib
import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option linter.style.longLine false


set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Regions from discrete spacetime slices / worldtubes -- v0.11h

This module provides the missing cross-link:

* DiscreteSpacetime slices `Sigma n` are natural **regions** (sets of nodes),
* a WorldTube provides a time-indexed family of finite regions,
* these fit directly into the general `RegionNet` abstraction (`SetRegionNet`).

This prepares the AQFT-lift where regions index local algebras.
-/

namespace PillarA
namespace Kinematics

open DiscreteSpacetime
open PillarA.LayerA

variable {X : Type}

/-- Use the canonical region net on `X` (regions are sets, order is inclusion). -/
abbrev SpacetimeRegionNet (_ST : DiscreteSpacetime X) : LayerA.RegionNet X :=
  LayerA.SetRegionNet X

/-- The time slice at `n` as a region. -/
def sliceRegion (ST : DiscreteSpacetime X) (n : Nat) : (SpacetimeRegionNet (X := X) ST).Region := by
  -- `SpacetimeRegionNet ST` is definitionally `SetRegionNet X`, so regions are sets.
  simpa [SpacetimeRegionNet] using (ST.Sigma n)

/-- A worldtube time-slice as a region (coercing the finset to a set). -/
def tubeRegion (ST : DiscreteSpacetime X) (T : WorldTube ST) (n : Nat) : Set X := (T.W n : Set X)

/-- Gate: an adapted tube slice lies inside the corresponding hypersurface slice. -/
theorem gate_tubeRegion_subset_slice (ST : DiscreteSpacetime X) (T : WorldTube ST) (n : Nat) :
    tubeRegion (ST := ST) T n ⊆ ST.Sigma n := by
  intro x hx
  -- `hx : x ∈ (T.W n : Set X)` is just `x ∈ T.W n`
  exact T.adapted n x hx

end Kinematics
end PillarA
