import Mathlib
import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.RegionCore

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Subsystem selection (core contract)

Phase 4 goal: abstract “subsystem selection” so that `PillarA.Update.*` can be
substrate-agnostic and does not import `PillarA.Ideal.*`.

This file defines a minimal, purely combinatorial contract:

* Given an `Approximant Cell L`, select a *region* (a finite set of visible cells).
* Require the chosen region to be a subset of the visible cells.

More refined laws (equivariance, stability under refinement, etc.) are expected
in later phases via additional structures.
-/

open RegionCore

universe u

/-- A selector chooses a region of visible cells in an approximant. -/
structure Selector (Cell : Nat → Type u) [Substrate Cell] (L : Nat) where
  choose : Approximant Cell L → RegionCore.RegionAt Cell L
  choose_subset : ∀ A : Approximant Cell L, choose A ⊆ A.cells

namespace Selector

variable {Cell : Nat → Type u} [Substrate Cell] {L : Nat}

/-- Trivial selector: select all visible cells. Useful as a build-stable default. -/
def all : Selector Cell L :=
  { choose := fun A => A.cells
    choose_subset := by
      intro A
      exact subset_rfl }

end Selector

end LayerA

end PillarA
