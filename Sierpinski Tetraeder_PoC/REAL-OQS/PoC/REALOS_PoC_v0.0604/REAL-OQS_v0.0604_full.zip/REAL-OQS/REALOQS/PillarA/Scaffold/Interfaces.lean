/-
DEPRECATED (compatibility wrapper)

Use `REALOQS.PillarA.Scaffold.All` for the heavy scaffold umbrella.
Prefer `REALOQS.PillarA.Interface` for the canonical, substrate-agnostic API.
-/

import REALOQS.PillarA.Scaffold.All
