import Mathlib
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNStabilizedSemantics
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
import REALOQS.PillarA.Ideal.Adapter.InfiniteCarrierInstance
import REALOQS.PillarA.Ideal.TreeOfCliques.SmallScales
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalD
import REALOQS.PillarA.Core.MatrixNorms

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace Adapter
namespace TreeOfCliquesAQFTHandoff

noncomputable section

open PillarA.LayerA
open TreeOfCliquesDtNStabilizedSemantics
open PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized

variable {b : Nat}

/-- Semantic witness used to hand the stabilized ToC boundary operator
    to later AQFT stages. -/
abbrev Sem (p : Policy b) :=
  TreeOfCliquesDtNStabilizedSemantics.mk (p := p)

/-- Concrete stabilized ToC state space used by the AQFT handoff. -/
abbrev State (p : Policy b) : Type :=
  (TreeOfCliquesDtNStabilizedSemantics.A (p := p)).S

/-- Scalar boundary signal extracted from the stabilized DtN boundary operator. -/
noncomputable def signal (p : Policy b) (st : State p) : ℝ :=
  MatrixNorm.frob ((Sem p).boundaryOp st)

/-- Canonical inverse temperature assigned by the boundary-op handoff. -/
noncomputable def beta (p : Policy b) (st : State p) : ℝ :=
  1 + signal p st

theorem signal_nonneg (p : Policy b) (st : State p) : 0 ≤ signal p st := by
  unfold signal
  simp [MatrixNorm.frob]

theorem beta_pos (p : Policy b) (st : State p) : 0 < beta p st := by
  have hs : 0 ≤ signal p st := signal_nonneg (p := p) (st := st)
  have h1 : (0 : ℝ) < 1 := by norm_num
  have h : 0 < 1 + signal p st := add_pos_of_pos_of_nonneg h1 hs
  simpa [beta]

theorem beta_nonneg (p : Policy b) (st : State p) : 0 ≤ beta p st := by
  exact le_of_lt (beta_pos (p := p) (st := st))

/-! ## Strict A-side export surface for the canonical AQFT bridge -/

/-- Boundary carrier exported from the stabilized ToC approximant. -/
abbrev Ω (p : Policy b) : Type := B (p := p)

instance instFintypeOmega (p : Policy b) : Fintype (Ω (p := p)) := by
  infer_instance

instance instDecidableEqOmega (p : Policy b) : DecidableEq (Ω (p := p)) := by
  classical
  infer_instance

/-- The exported ToC boundary carrier is nonempty whenever the branching alphabet is nontrivial. -/
theorem omega_nonempty_of_pos_base (p : Policy b) [Fact (0 < b)] :
    Nonempty (Ω (p := p)) := by
  change Nonempty (_root_.PillarA.Ideal.IdealCell b p.L_max)
  exact ⟨_root_.PillarA.Ideal.Adapter.InfiniteCarrierInstance.canonicalCell
    b (Fact.out : 0 < b) p.L_max⟩

/-- At truncation level `0`, the exported ToC boundary carrier contains the root cell. -/
theorem omega_nonempty_of_Lmax_eq_zero (p : Policy b) (hk : p.L_max = 0) :
    Nonempty (Ω (p := p)) := by
  change Nonempty (_root_.PillarA.Ideal.TreeOfCliques.Boundary b p.L_max)
  rw [hk]
  exact ⟨_root_.PillarA.Ideal.TreeOfCliques.rootB0 b⟩

/-- Preferred nonemptiness instance for the exported ToC boundary carrier.

This captures the mathematically relevant regime `0 < b`. The degenerate root-only
case `L_max = 0` is still available separately via `omega_nonempty_of_Lmax_eq_zero`. -/
instance instNonemptyOmegaOfPosBase (p : Policy b) [Fact (0 < b)] :
    Nonempty (Ω (p := p)) :=
  omega_nonempty_of_pos_base (b := b) p

/-- Stage-0 reduced operator state from the canonical ToC Laplacian. -/
abbrev st0 (p : Policy b) : ReducedOpState p :=
  stLap (p := p)

/-- Stage-1 stabilized DtN/Kron reduction. -/
abbrev st1 (p : Policy b) : ReducedOpState p :=
  reduce (p := p) (st0 (p := p))

/-- Canonical boundary operator exported to Pillar B. -/
abbrev L (p : Policy b) : Matrix (Ω (p := p)) (Ω (p := p)) ℝ :=
  (st1 (p := p)).LBB

@[simp] theorem L_def (p : Policy b) : L (p := p) = (st1 (p := p)).LBB := rfl


private theorem blockBI_transpose_eq_blockIB_of_symm
    (p : Policy b)
    (M : Matrix (TreeOfCliquesApproxDtNStabilized.V (p := p))
      (TreeOfCliquesApproxDtNStabilized.V (p := p)) ℝ)
    (hM : Matrix.transpose M = M) :
    Matrix.transpose ((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockBI M) =
      (TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockIB M := by
  ext i j
  have hji :=
    congrArg
      (fun N : Matrix (TreeOfCliquesApproxDtNStabilized.V (p := p))
          (TreeOfCliquesApproxDtNStabilized.V (p := p)) ℝ =>
        N (((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).e).symm (Sum.inr i))
          (((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).e).symm (Sum.inl j)))
      hM
  simpa [PillarA.OQS.Split.blockBI, PillarA.OQS.Split.blockIB, Matrix.transpose_apply] using hji

private theorem blockIB_transpose_eq_blockBI_of_symm
    (p : Policy b)
    (M : Matrix (TreeOfCliquesApproxDtNStabilized.V (p := p))
      (TreeOfCliquesApproxDtNStabilized.V (p := p)) ℝ)
    (hM : Matrix.transpose M = M) :
    Matrix.transpose ((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockIB M) =
      (TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockBI M := by
  ext i j
  have hij :=
    congrArg
      (fun N : Matrix (TreeOfCliquesApproxDtNStabilized.V (p := p))
          (TreeOfCliquesApproxDtNStabilized.V (p := p)) ℝ =>
        N (((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).e).symm (Sum.inl i))
          (((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).e).symm (Sum.inr j)))
      hM
  simpa [PillarA.OQS.Split.blockBI, PillarA.OQS.Split.blockIB, Matrix.transpose_apply] using hij

private theorem symm_transpose_eq_self
    {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    Matrix.transpose (PillarA.OQS.Split.DtNStabilized.symm (ι := ι) A) =
      PillarA.OQS.Split.DtNStabilized.symm (ι := ι) A := by
  ext i j
  -- unfold symmetrization and transpose; use distributivity and commutativity
  simp [PillarA.OQS.Split.DtNStabilized.symm, Matrix.transpose_apply, mul_add,
    add_comm]

private theorem stabilize_transpose_eq_self_of_transpose_eq
    {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) (δ : ℝ)
    (hA : Matrix.transpose A = A) :
    Matrix.transpose (PillarA.OQS.Split.DtNStabilized.stabilize A δ) =
      PillarA.OQS.Split.DtNStabilized.stabilize A δ := by
  ext i j
  by_cases hij : i = j
  · subst hij
    simp [PillarA.OQS.Split.DtNStabilized.stabilize, Matrix.transpose_apply]
  · have hAji : A j i = A i j := by
      -- extract symmetry at indices `(i,j)` from `transpose A = A`
      simpa [Matrix.transpose_apply] using
        congrArg (fun M : Matrix ι ι ℝ => M i j) hA
    have hji : ¬j = i := by
      simpa [eq_comm] using hij
    simp [PillarA.OQS.Split.DtNStabilized.stabilize, Matrix.transpose_apply, hij, hji, hAji]

private theorem transpose_inv_eq_of_transpose_eq
    {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ)
    (hA : Matrix.transpose A = A)
    (hdet : A.det ≠ 0) :
    Matrix.transpose A⁻¹ = A⁻¹ := by
  have hInv : PillarA.LayerA.TwoSidedInv A A⁻¹ :=
    PillarA.LayerA.gate_DTN_WELLPOSED_canonical (A := A) hdet
  have hLeft : Matrix.transpose A⁻¹ * A = 1 := by
    have h := congrArg Matrix.transpose hInv.2
    simpa [Matrix.transpose_mul, Matrix.transpose_one, hA] using h
  calc
    Matrix.transpose A⁻¹ = Matrix.transpose A⁻¹ * 1 := by simp
    _ = Matrix.transpose A⁻¹ * (A * A⁻¹) := by rw [hInv.2]
    _ = (Matrix.transpose A⁻¹ * A) * A⁻¹ := by rw [Matrix.mul_assoc]
    _ = 1 * A⁻¹ := by rw [hLeft]
    _ = A⁻¹ := by simp

/-- Symmetry of the canonical real boundary operator exported to Pillar B. -/
theorem L_transpose_eq (p : Policy b) : Matrix.transpose (L (p := p)) = L (p := p) := by
  classical
  rw [L_def]
  rw [TreeOfCliquesApproxDtNStabilized.reduce_LBB_eq_dtn_stab (p := p)]
  let s := TreeOfCliquesApproxDtNStabilized.sSplit (p := p)
  let M : Matrix (TreeOfCliquesApproxDtNStabilized.V (p := p))
      (TreeOfCliquesApproxDtNStabilized.V (p := p)) ℝ :=
    TreeOfCliquesApproxDtNStabilized.L0 (p := p)
  let A : Matrix s.I s.I ℝ :=
    PillarA.OQS.Split.DtNStabilized.LII_stabilized (s := s) (p := p) (L := M)
  have hM : Matrix.transpose M = M := by
    simpa [M] using (TreeOfCliquesApproxDtNStabilized.gate_L0_admissible (p := p)).1
  have hBB : Matrix.transpose (s.blockBB M) = s.blockBB M :=
    PillarA.OQS.Split.blockBB_transpose_of_symm (s := s) (M := M) hM
  have hBI : Matrix.transpose (s.blockBI M) = s.blockIB M :=
    blockBI_transpose_eq_blockIB_of_symm (p := p) (M := M) hM
  have hIB : Matrix.transpose (s.blockIB M) = s.blockBI M :=
    blockIB_transpose_eq_blockBI_of_symm (p := p) (M := M) hM
  have hA : Matrix.transpose A = A := by
    dsimp [A, M]
    let S : Matrix s.I s.I ℝ :=
      PillarA.OQS.Split.DtNStabilized.symm (ι := s.I)
        ((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockII
          (TreeOfCliquesApproxDtNStabilized.L0 (p := p)))
    have hS : Matrix.transpose S = S := by
      dsimp [S]
      simpa using
        (symm_transpose_eq_self
          (((TreeOfCliquesApproxDtNStabilized.sSplit (p := p)).blockII
            (TreeOfCliquesApproxDtNStabilized.L0 (p := p)))))
    simpa [S] using
      (stabilize_transpose_eq_self_of_transpose_eq
        (A := S)
        (δ := PillarA.OQS.Split.DtNStabilized.deltaSPD (p := p) S)
        hS)
  have hdetA : A.det ≠ 0 := by
    dsimp [A, M]
    simpa [TreeOfCliquesApproxDtNStabilized.LII_stab0,
      TreeOfCliquesApproxDtNStabilized.L0, TreeOfCliquesApproxDtNStabilized.sSplit,
      TreeOfCliquesApproxDtNStabilized.k] using
      (show (TreeOfCliquesApproxDtNStabilized.LII_stab0 (p := p)).det ≠ 0 from
        (TreeOfCliquesApproxDtNStabilized.hdet0_inst (p := p)))
  have hAinv : Matrix.transpose A⁻¹ = A⁻¹ :=
    transpose_inv_eq_of_transpose_eq (A := A) hA hdetA
  calc
    Matrix.transpose
        (TreeOfCliques.DtNStabilized.dtn_stabilized_of_det
          (b := b) (p := p) (k := TreeOfCliquesApproxDtNStabilized.k (p := p))
          (hdet := by
            simpa [TreeOfCliques.DtNStabilized.LII_stab,
              TreeOfCliques.DtNStabilized.s,
              TreeOfCliques.DtNStabilized.L,
              TreeOfCliquesApproxDtNStabilized.LII_stab0,
              TreeOfCliquesApproxDtNStabilized.L0,
              TreeOfCliquesApproxDtNStabilized.sSplit,
              TreeOfCliquesApproxDtNStabilized.k] using hdetA))
        =
          Matrix.transpose
            (s.blockBB M - (s.blockBI M * A⁻¹ * s.blockIB M)) := by
          simp
            [TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
            TreeOfCliques.DtNStabilized.s,
            TreeOfCliques.DtNStabilized.L,
            PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
            PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
            PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
            PillarA.LayerA.DtN, A, M, s]
    _ =
        Matrix.transpose (s.blockBB M) -
          (Matrix.transpose (s.blockIB M) *
            Matrix.transpose A⁻¹ *
            Matrix.transpose (s.blockBI M)) := by
          simp [Matrix.transpose_sub, Matrix.transpose_mul, Matrix.mul_assoc]
    _ = s.blockBB M - (s.blockBI M * A⁻¹ * s.blockIB M) := by
          simp [hBB, hBI, hIB, hAinv, Matrix.mul_assoc]
    _ = TreeOfCliques.DtNStabilized.dtn_stabilized_of_det
          (b := b) (p := p) (k := TreeOfCliquesApproxDtNStabilized.k (p := p))
          (hdet := by
            simpa [TreeOfCliques.DtNStabilized.LII_stab,
              TreeOfCliques.DtNStabilized.s,
              TreeOfCliques.DtNStabilized.L,
              TreeOfCliquesApproxDtNStabilized.LII_stab0,
              TreeOfCliquesApproxDtNStabilized.L0,
              TreeOfCliquesApproxDtNStabilized.sSplit,
              TreeOfCliquesApproxDtNStabilized.k] using hdetA) := by
          simp
            [TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
            TreeOfCliques.DtNStabilized.s,
            TreeOfCliques.DtNStabilized.L,
            PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
            PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
            PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
            PillarA.LayerA.DtN, A, M, s]

/-- Canonical complexified Hamiltonian matrix exported to the
    full-KMS path. -/
noncomputable def HC (p : Policy b) :
    Matrix (Ω (p := p)) (Ω (p := p)) Complex :=
  fun i j => (L (p := p) i j : Complex)

@[simp] theorem HC_apply (p : Policy b) (i j : Ω (p := p)) :
    HC (p := p) i j = (L (p := p) i j : Complex) := rfl

/-- Hermiticity of the canonical complexified boundary operator
    exported to Pillar B. -/
theorem HC_isHermitian (p : Policy b) :
    Matrix.IsHermitian (HC (p := p)) := by
  dsimp [Matrix.IsHermitian, HC]
  ext i j
  have hij : L (p := p) j i = L (p := p) i j := by
    have h :=
      congrArg
        (fun M : Matrix (Ω (p := p)) (Ω (p := p)) ℝ => M i j)
        (L_transpose_eq (p := p))
    simpa [Matrix.transpose_apply] using h
  simp [hij]

/-- Canonical dependent scale-breaking axis used for the A-side AQFT handoff. -/
noncomputable abbrev axis (p : Policy b) :=
  PillarA.Physics.Instances.TreeOfCliques.ToC.axis_canonicalD (b := b) (p := p)

/-- Deterministic argmax scan for `breakMeasure` on the finite window `0..n`.

Tie-breaking is canonical: if the new value is greater-or-equal, keep the later
index.
-/
def argmaxBreakUpTo
    (A : PillarA.Physics.ScaleBreakingAxisD
      (PillarA.Physics.Instances.TreeOfCliques.ToC.S b)) : Nat → Nat
  | 0 => 0
  | n + 1 =>
      let k := argmaxBreakUpTo A n
      if A.breakMeasure k ≤ A.breakMeasure (n + 1) then n + 1 else k

/-- Canonical scale-selection window exported from Pillar A. -/
def kWindow (p : Policy b) : Nat := p.K_max

/-- Deterministic choice of the scale at which the AQFT handoff samples A-diagnostics. -/
noncomputable def kStar (p : Policy b) : Nat :=
  argmaxBreakUpTo (b := b) (axis (b := b) p) (kWindow p)

/-- Real-valued diagnostic signal extracted from the canonical axis at scale `k`. -/
noncomputable def signalAt (p : Policy b) (k : Nat) : ℝ :=
  ((axis (b := b) p).breakMeasure k).toReal

/-- Canonical scalar signal extracted from Pillar A for the AQFT bridge. -/
noncomputable def signalFromA (p : Policy b) : ℝ :=
  signalAt (b := b) p (kStar (b := b) p)

/-- Canonical inverse temperature derived from the Pillar-A signal. -/
noncomputable def betaFromA (p : Policy b) : ℝ :=
  1 + |signalFromA (b := b) p|

theorem betaFromA_pos (p : Policy b) : 0 < betaFromA (b := b) p := by
  have h0 : (0 : ℝ) < 1 := by norm_num
  have habs : 0 ≤ |signalFromA (b := b) p| := abs_nonneg _
  have h1 : (1 : ℝ) ≤ 1 + |signalFromA (b := b) p| :=
    le_add_of_nonneg_right habs
  have hβ : (1 : ℝ) ≤ betaFromA (b := b) p := by
    change (1 : ℝ) ≤ 1 + |signalFromA (b := b) p|
    exact h1
  exact lt_of_lt_of_le h0 hβ

/-- Number of local configuration values exported from the ToC scale window. -/
def dFromA (p : Policy b) : Nat :=
  kWindow p + 1

theorem dFromA_pos (p : Policy b) : 0 < dFromA (b := b) p := by
  simp [dFromA, kWindow]

/-- Canonical local-value embedding exported from the ToC break profile. -/
noncomputable def phiFromA (p : Policy b) : Fin (dFromA (b := b) p) → ℝ :=
  fun i => signalAt (b := b) p i.1

end

end TreeOfCliquesAQFTHandoff
end Adapter
end Ideal
end PillarA
