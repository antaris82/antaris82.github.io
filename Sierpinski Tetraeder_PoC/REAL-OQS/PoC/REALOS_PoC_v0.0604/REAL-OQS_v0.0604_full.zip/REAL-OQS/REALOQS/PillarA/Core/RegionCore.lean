import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Region core (Core, Phase 1)

This module defines a minimal region notion built only from:

* level-indexed cells `Cell L`,
* refinement/coarsening via `children`/`parents`.

No IDEAL (or any other substrate) is imported or assumed.
The intent is that later modules (e.g. `Core/RegionNet`) can be expressed over
this substrate-agnostic core interface.
-/

universe u

namespace RegionCore

variable {Cell : Nat → Type u}

/-- Regions at a fixed level are just finite sets of level-`L` cells. -/
abbrev RegionAt (Cell : Nat → Type u) (L : Nat) : Type u :=
  Finset (Cell L)

namespace RegionAt

variable {L : Nat}

/-- Set-valued view of a region. -/
def carrier (R : RegionAt Cell L) : Set (Cell L) := fun x => x ∈ R

/-- The singleton region consisting of a single cell. -/
def singleton (c : Cell L) : RegionAt Cell L := {c}

end RegionAt

/-- One-step refinement of a region via the substrate's `children`. -/
def refineAt [Substrate Cell] {L : Nat} (R : RegionAt Cell L) : RegionAt Cell (L + 1) :=
  Substrate.refineSet (Cell := Cell) R

/-- One-step coarsening of a region via the substrate's `parents`. -/
def coarsenAt [Substrate Cell] {L : Nat} (R : RegionAt Cell (L + 1)) : RegionAt Cell L :=
  Substrate.coarsenSet (Cell := Cell) R

end RegionCore

end LayerA

end PillarA
