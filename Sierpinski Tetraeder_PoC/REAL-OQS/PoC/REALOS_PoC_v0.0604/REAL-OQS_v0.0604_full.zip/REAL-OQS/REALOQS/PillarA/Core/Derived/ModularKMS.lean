import Mathlib.Data.Complex.Basic

import REALOQS.PillarA.Core.ToC.AQFTSubstrate

/-!
# Derived modular/KMS hooks (Phase II scaffold)

This file is Phase II scaffolding.

Tomita–Takesaki / modular theory is typically formulated for von Neumann
algebras (W*-algebras). If Mathlib does not yet provide the required
infrastructure for our targets, we keep modular/KMS as an IDEAL-level surface in
`AQFTSubstrate`.

This module is the place where a future derived construction can live, without
reintroducing gates in Pillar B.
-/

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

/-- Placeholder hook class for future derived modular/KMS data. -/
class HasDerivedModularKMS (A : Type u) where
  StateOn : Type u
  isState : StateOn → Prop
  mkModularKMSData : ∀ ω : StateOn, isState ω → Type u

end Derived
end PillarA
