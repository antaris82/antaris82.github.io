import Mathlib.Data.Complex.Basic

import REALOQS.PillarA.Core.Exports
import REALOQS.PillarB.AQFT.StarAlgebra

/-!
# AQFT substrate inside Pillar A (IDEAL / ToC)

This file is the **strictness anchor**: analytic/operator-algebraic assumptions
needed for later AQFT layers (GNS, modular theory, KMS, Haag–Kastler, etc.) are
centralized here.

Architectural rule:
If something is an *assumption*, it lives in Pillar A.
If something is *derived*, it lives in Pillar B or above.

At this stage we keep the substrate purely structural. Later work can replace
these fields by actual derivations from Mathlib theorems.
-/

set_option autoImplicit false

namespace PillarA
namespace ToC

universe u v

/--
`AQFTSubstrate` is the IDEAL-level bundle from which higher-layer AQFT
constructions are meant to be derived.

We keep the algebra abstract and reuse Pillar B's `StarAlgebra` bundle as the
unifying interface.

`GNSData` and `ModularKMSData` are intentionally kept as data surfaces in Pillar A
so that Pillar B can be strictly non-gated immediately.
-/
structure AQFTSubstrate (A : Type u) where
  SA : PillarB.AQFT.StarAlgebra A

  /-- State space on `A` (abstract at the IDEAL layer). -/
  StateOn : Type u

  /-- Evaluation of a state on an observable. -/
  eval : StateOn → A → Complex

  /-- IDEAL-level predicate: `s` is a lawful state. -/
  isState : StateOn → Prop

  /-- IDEAL-level GNS outputs for a state. -/
  GNSData : StateOn → Type (u + 1)

  /-- IDEAL-level modular/KMS outputs for a state. -/
  ModularKMSData : StateOn → Type (u + 1)

attribute [instance] AQFTSubstrate.SA

end ToC
end PillarA
