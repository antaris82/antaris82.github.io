import Mathlib

/-!
REALOQS / Pillar A / Layer A: Sys/Env/Tail split invariants (foundation) -- v0.11 (2026-01-22)

This file formalizes the minimal *partition semantics* that later connects to:
- local DtN (integrate interior degrees of freedom into boundary)
- global DtN (integrate exterior degrees of freedom into boundary)
- tail initialization (integrate cut tail into finest-cell boundaries at n=0)

Here we only fix the set-theoretic invariants (disjointness / coverage / ownership).

These invariants are intended to be used as Gates for downstream/Lean hardening
against double counting.
-/

namespace PillarA
namespace OQS

/-!
Sys/Env/Tail split invariants (set-level, Finset based).

Note: `PillarA.OQS` already contains a type-level `Split` (in `SysEnv.lean`).
To avoid name clashes, this module nests the Finset-based split under
`SysEnvTail`.
-/

namespace SysEnvTail

open scoped BigOperators

section Split

variable {α : Type}

/-- A triple split of degrees of freedom. -/
structure Split where
  sys : Finset α
  env : Finset α
  tail : Finset α
  disj_sys_env : Disjoint sys env
  disj_sys_tail : Disjoint sys tail
  disj_env_tail : Disjoint env tail

/-- Optional: "no double counting" on the whole domain `Ω` (coverage). -/
def covers (Ω : Finset α) (s : Split (α := α)) : Prop := by
  classical
  exact s.sys ∪ s.env ∪ s.tail = Ω

/-- Gate: membership in sys excludes membership in env and tail. -/
theorem gate_mem_sys_not_mem_env (s : Split (α := α)) {x : α} (hx : x ∈ s.sys) : x ∉ s.env := by
  intro hxE
  exact (Finset.disjoint_left.1 s.disj_sys_env hx hxE)

theorem gate_mem_sys_not_mem_tail (s : Split (α := α)) {x : α} (hx : x ∈ s.sys) : x ∉ s.tail := by
  intro hxT
  exact (Finset.disjoint_left.1 s.disj_sys_tail hx hxT)

theorem gate_mem_env_not_mem_tail (s : Split (α := α)) {x : α} (hx : x ∈ s.env) : x ∉ s.tail := by
  intro hxT
  exact (Finset.disjoint_left.1 s.disj_env_tail hx hxT)

/--
`uniqueOwner s x` expresses the intended **"at most one"** semantics:
`x` is not allowed to belong to two different components simultaneously.

Note: This is redundant given the fields `disj_*` of `Split`, but it is useful as a
named predicate for later "no double counting" gates.
-/
def uniqueOwner (s : Split (α := α)) (x : α) : Prop := ¬ ((x ∈ s.sys ∧ x ∈ s.env)
      ∨ (x ∈ s.sys ∧ x ∈ s.tail)
      ∨ (x ∈ s.env ∧ x ∈ s.tail))

/-- Gate: disjointness implies uniqueOwner. -/
theorem gate_disjoint_implies_uniqueOwner (s : Split (α := α)) (x : α) :
    uniqueOwner (s := s) x := by
  unfold uniqueOwner
  intro h
  rcases h with hse | hrest
  · rcases hse with ⟨hs, he⟩
    exact (Finset.disjoint_left.1 s.disj_sys_env hs he)
  · rcases hrest with hst | het
    · rcases hst with ⟨hs, ht⟩
      exact (Finset.disjoint_left.1 s.disj_sys_tail hs ht)
    · rcases het with ⟨he, ht⟩
      exact (Finset.disjoint_left.1 s.disj_env_tail he ht)

/--
If we additionally assume `covers Ω s`, then each `x ∈ Ω` is owned by *exactly one* component.

This is the canonical "partition" form that is stable for later accounting lemmas.
-/
def ownerTrichotomy (s : Split (α := α)) (x : α) : Prop := (x ∈ s.sys ∧ x ∉ s.env ∧ x ∉ s.tail)
    ∨ (x ∈ s.env ∧ x ∉ s.sys ∧ x ∉ s.tail)
    ∨ (x ∈ s.tail ∧ x ∉ s.sys ∧ x ∉ s.env)

/-- Gate: `covers` + `Split.disj_*` gives a constructive trichotomy for any `x ∈ Ω`. -/
theorem gate_covers_ownerTrichotomy (Ω : Finset α) (s : Split (α := α))
    (hc : covers (α := α) Ω s) {x : α} (hx : x ∈ Ω) : ownerTrichotomy (s := s) x := by
  classical
  -- rewrite membership in Ω into membership in the union
  have hΩ : Ω = s.sys ∪ s.env ∪ s.tail := by
    simpa [covers] using hc.symm
  have hxU : x ∈ s.sys ∪ s.env ∪ s.tail := by
    simpa [hΩ] using hx
  -- split membership in the union
  rcases Finset.mem_union.1 hxU with hxSE | hxT
  · rcases Finset.mem_union.1 hxSE with hxS | hxE
    · left
      refine ⟨hxS, ?_, ?_⟩
      · exact gate_mem_sys_not_mem_env (s := s) (α := α) hxS
      · exact gate_mem_sys_not_mem_tail (s := s) (α := α) hxS
    · right; left
      refine ⟨hxE, ?_, ?_⟩
      · intro hxS
        exact (Finset.disjoint_left.1 s.disj_sys_env hxS hxE)
      · exact gate_mem_env_not_mem_tail (s := s) (α := α) hxE
  · right; right
    refine ⟨hxT, ?_, ?_⟩
    · intro hxS
      exact (Finset.disjoint_left.1 s.disj_sys_tail hxS hxT)
    · intro hxE
      exact (Finset.disjoint_left.1 s.disj_env_tail hxE hxT)

end Split

end SysEnvTail
end OQS
end PillarA
