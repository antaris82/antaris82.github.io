/-
REALOQS / Pillar A / Core: Export surface

This module is the *core-only* umbrella for Pillar A.

Design intent:
- Substrate-agnostic.
- No IDEAL-specific imports.
- No gauge/matter/physics/geometry scaffolds.

Use `REALOQS.PillarA.Interface` for the canonical Pillar-A interface (kernel + hooks),
and `REALOQS.PillarA.All` for the heavy developer umbrella.
-/

import Mathlib

-- Core contracts and gates
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.Determinism
import REALOQS.PillarA.Core.Gates

-- Substrate-agnostic core interfaces
import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.RegionCore
import REALOQS.PillarA.Core.Selection
import REALOQS.PillarA.Core.SymmetryAction
import REALOQS.PillarA.Core.InfiniteCarrier
import REALOQS.PillarA.Core.InfiniteCarrierSymmetry
import REALOQS.PillarA.Core.CylinderSets
import REALOQS.PillarA.Core.SymmetryCoverageGates

-- Tail/boundary interfaces
import REALOQS.PillarA.Core.BoundaryPorts
import REALOQS.PillarA.Core.TailInterface
import REALOQS.PillarA.Core.TailEliminationCoherence
import REALOQS.PillarA.Core.VacuumOffsetHook

-- Discrete operator blocks
import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarA.Core.DirichletLaplacianBridge
import REALOQS.PillarA.Core.MatrixNorms

-- Resistance metric (interface + canonical grounded solve)
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Core.ResistanceMetricCanonical

-- Region nets (AQFT-lift preparation)
import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Core.NoetherHooks
import REALOQS.PillarA.Core.DynamicsEquivariant

-- Pillar B/C handoff contracts
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarA.Core.BInterfaces.StateNet
import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarA.Core.BInterfaces.ChannelNet
import REALOQS.PillarA.Core.BInterfaces.CovariantNets
import REALOQS.PillarA.Core.BInterfaces.RelativeEntropyHook
