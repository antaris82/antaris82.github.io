import Mathlib
import REALOQS.PillarA.OQS.DtN
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Core.Gates

set_option autoImplicit false
open scoped BigOperators

/-!
# OQS DtN with deterministic stabilization (Tikhonov / jitter)

Motivation (links to the TomS ↔ antaris discussion):
Subsystem reductions (RG / tail elimination) must be *dynamical* operations, not just
"direct sum" decompositions. In the IDEAL→REAL pipeline this is realized by a DtN/Kron step,
i.e. eliminating interior degrees of freedom to obtain an effective boundary operator.

In pure Pillar A, we intentionally avoid analytic claims (M-matrices, spectral bounds, ...).
But we can still **fix a canonical, deterministic regularization rule** and expose it as a
constructive interface:

  A ↦ A_stab := symm(A) + δ(A)·I,   δ(A) := ε · max(1, ||A||_F)

where `ε := Policy.eps` is the deterministic floor scale (derived from `float64` machine eps).

This file defines:
* `InteriorInvStabilized` – inverse witness for the stabilized interior block
* `DtN_stabilized_of`    – regularized DtN (Schur complement with stabilized inverse)
* `dtn_stabilized_of_det` – constructor from the gate `det(A_stab) ≠ 0`

No claim is made that `det(A_stab) ≠ 0` holds automatically; later layers can provide
conditions implying it (e.g. connectivity + positivity + coercivity).
-/

namespace PillarA
namespace OQS
namespace Split

noncomputable section

open PillarA.LayerA

variable {V : Type} [Fintype V] [DecidableEq V]
variable (s : PillarA.OQS.Split V)

namespace DtNStabilized

variable {b : Nat}

/-- Symmetrization `symm(A) := (A + Aᵀ)/2` over `ℝ`. -/
noncomputable def symm {ι : Type} [Fintype ι] (A : Matrix ι ι ℝ) : Matrix ι ι ℝ :=
  (1 / 2 : ℝ) • (A + Matrix.transpose A)

/-- Deterministic stabilization `A + δ·I`. -/
noncomputable def stabilize {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) (δ : ℝ) : Matrix ι ι ℝ :=
  A + δ • (1 : Matrix ι ι ℝ)

/-- Canonical jitter `δ(A) = ε * max(1, ||A||_F)` using the policy floor `ε = p.eps`. -/
noncomputable def deltaSPD (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) : ℝ :=
  PillarA.LayerA.MatrixNorm.deltaSPD (ι := ι) p.eps A

/-!
## Policy transparency

`deltaSPD` is intended as a **numerical** (float64-style) stabilization magnitude.

* It depends only on the policy floor `p.eps` and the Frobenius norm of the matrix.
* It is *not* meant to represent a physical parameter.

To make this separation explicit, we provide the alias `deltaNum` and a few small
lemmas exposing its dependence on `p.eps`.
-/

/-- Alias marking the jitter magnitude as a **numerical** stabilization quantity. -/
noncomputable abbrev deltaNum (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) : ℝ :=
  deltaSPD (p := p) (ι := ι) A

@[simp] lemma deltaSPD_eq_deltaNum (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    deltaSPD (p := p) (ι := ι) A = deltaNum (p := p) (ι := ι) A := rfl

@[simp] lemma deltaNum_def (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    deltaNum (p := p) (ι := ι) A = p.eps * max 1 (PillarA.LayerA.MatrixNorm.frob (ι := ι) A) := by
  simp [deltaNum, deltaSPD, PillarA.LayerA.MatrixNorm.deltaSPD]

lemma deltaNum_pos (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    0 < deltaNum (p := p) (ι := ι) A := by
  simpa [deltaNum, deltaSPD] using
    (PillarA.LayerA.MatrixNorm.deltaSPD_pos (ι := ι) (ε := p.eps) (A := A) p.eps_pos)

lemma deltaNum_ge_eps (p : Policy b) {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) :
    p.eps ≤ deltaNum (p := p) (ι := ι) A := by
  -- `max 1 ||A||_F ≥ 1` and `p.eps > 0`.
  have hmax : (1 : ℝ) ≤ max 1 (PillarA.LayerA.MatrixNorm.frob (ι := ι) A) := by
    exact le_max_left _ _
  have h := mul_le_mul_of_nonneg_left hmax (le_of_lt p.eps_pos)
  -- rewrite `deltaNum` into `p.eps * max ...`
  simpa [deltaNum_def, mul_one] using h

/-- Stabilized interior block used for regularized DtN elimination. -/
noncomputable def LII_stabilized (p : Policy b) (L : Matrix V V ℝ) :
    Matrix s.I s.I ℝ :=
  let A : Matrix s.I s.I ℝ := symm (ι := s.I) (s.blockII L)
  stabilize A (deltaSPD (p := p) A)

/-- Inverse witness for the stabilized interior block (Tikhonov / jittered). -/
structure InteriorInvStabilized (p : Policy b) (L : Matrix V V ℝ) where
  inv : Matrix s.I s.I ℝ
  invOK : PillarA.LayerA.TwoSidedInv (LII_stabilized (s := s) (p := p) L) inv

/-- Build a stabilized inverse witness from the *gate* `det(LII_stabilized) ≠ 0`.

Phase 5 policy: the inverse is chosen **canonically** as `A⁻¹` (no `Classical.choose`), and the
gate is used only to justify the two-sided inverse laws.
-/
def interiorInvStabilized_of_det
    (p : Policy b) (L : Matrix V V ℝ)
    (hdet : (LII_stabilized (s := s) (p := p) L).det ≠ 0) :
    InteriorInvStabilized (s := s) (p := p) L := by
  classical
  let A : Matrix s.I s.I ℝ := LII_stabilized (s := s) (p := p) L
  refine ⟨A⁻¹, ?_⟩
  simpa [A] using
    (PillarA.LayerA.gate_DTN_WELLPOSED_canonical (ι := s.I) (A := A) hdet)


/-- Deterministic regularized DtN using the built-in inverse of the stabilized interior block.

No well-posedness claim is attached to this definition; it is purely the Schur complement
expression with the canonical Tikhonov-stabilized inverse `(LII_stabilized p L)⁻¹`.

Use `interiorInvStabilized_of_det` (or later analytical criteria) to justify identities
that require a true inverse.
-/
noncomputable def DtN_stabilized (p : Policy b) (L : Matrix V V ℝ) :
    Matrix s.B s.B ℝ :=
  PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := (LII_stabilized (s := s) (p := p) L)⁻¹)

/-- Regularized DtN induced from `L` using the stabilized interior inverse witness.

This is the Schur complement expression, but with `LII⁻¹` replaced by
`(symm(LII) + δ·I)⁻¹`. This is the deterministic regularization step that later
layers can justify analytically and use computationally.
-/
noncomputable def DtN_stabilized_of (p : Policy b) (L : Matrix V V ℝ)
    (w : InteriorInvStabilized (s := s) (p := p) L) :
    Matrix s.B s.B ℝ :=
  PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := w.inv)

/-- Convenience constructor: `det(LII_stabilized) ≠ 0` ⇒ regularized DtN. -/
noncomputable def dtn_stabilized_of_det
    (p : Policy b) (L : Matrix V V ℝ)
    (hdet : (LII_stabilized (s := s) (p := p) L).det ≠ 0) :
    Matrix s.B s.B ℝ :=
  DtN_stabilized_of (s := s) (p := p) (L := L)
    (w := interiorInvStabilized_of_det (s := s) (p := p) (L := L) hdet)

end DtNStabilized

end

end Split
end OQS
end PillarA
