import Mathlib
import REALOQS.PillarA.OQS.SysEnv
import REALOQS.PillarA.Core.Gates


import Mathlib.Tactic.GeneralizeProofs

namespace Harmonic.GeneralizeProofs
-- Harmonic `generalize_proofs` tactic

open Lean Meta Elab Parser.Tactic Elab.Tactic Mathlib.Tactic.GeneralizeProofs
def mkLambdaFVarsUsedOnly' (fvars : Array Expr) (e : Expr) : MetaM (Array Expr × Expr) := do
  let mut e := e
  let mut fvars' : List Expr := []
  for i' in [0:fvars.size] do
    let fvar := fvars[fvars.size - i' - 1]!
    e ← mkLambdaFVars #[fvar] e (usedOnly := false) (usedLetOnly := false)
    match e with
    | .letE _ _ v b _ => e := b.instantiate1 v
    | .lam _ _ _b _ => fvars' := fvar :: fvars'
    | _ => unreachable!
  return (fvars'.toArray, e)

partial def abstractProofs' (e : Expr) (ty? : Option Expr) : MAbs Expr := do
  if (← read).depth ≤ (← read).config.maxDepth then
    MAbs.withRecurse <| visit (← instantiateMVars e) ty?
  else
    return e
where
  visit (e : Expr) (ty? : Option Expr) : MAbs Expr := do
    if (← read).config.debug then
      if let some ty := ty? then
        unless ← isDefEq (← inferType e) ty do
          throwError "visit: type of{indentD e}\nis not{indentD ty}"
    if e.isAtomic then
      return e
    else
      checkCache (e, ty?) fun _ ↦ do
        if ← isProof e then
          visitProof e ty?
        else
          match e with
          | .forallE n t b i =>
            withLocalDecl n i (← visit t none) fun x ↦ MAbs.withLocal x do
              mkForallFVars #[x] (← visit (b.instantiate1 x) none)
                (usedOnly := false) (usedLetOnly := false)
          | .lam n t b i => do
            withLocalDecl n i (← visit t none) fun x ↦ MAbs.withLocal x do
              let ty'? ←
                if let some ty := ty? then
                  let .forallE _ _ tyB _ ← pure ty
                    | throwError "Expecting forall in abstractProofs .lam"
                  pure <| some <| tyB.instantiate1 x
                else
                  pure none
              mkLambdaFVars #[x] (← visit (b.instantiate1 x) ty'?)
                (usedOnly := false) (usedLetOnly := false)
          | .letE n t v b _ =>
            let t' ← visit t none
            withLetDecl n t' (← visit v t') fun x ↦ MAbs.withLocal x do
              mkLetFVars #[x] (← visit (b.instantiate1 x) ty?) (usedLetOnly := false)
          | .app .. =>
            e.withApp fun f args ↦ do
              let f' ← visit f none
              let argTys ← appArgExpectedTypes f' args ty?
              let mut args' := #[]
              for arg in args, argTy in argTys do
                args' := args'.push <| ← visit arg argTy
              return mkAppN f' args'
          | .mdata _ b  => return e.updateMData! (← visit b ty?)
          | .proj _ _ b => return e.updateProj! (← visit b none)
          | _           => unreachable!
  visitProof (e : Expr) (ty? : Option Expr) : MAbs Expr := do
    let eOrig := e
    let fvars := (← read).fvars
    let e := e.withApp' fun f args => f.beta args
    if e.withApp' fun f args => f.isAtomic && args.all fvars.contains then return e
    let e ←
      if let some ty := ty? then
        if (← read).config.debug then
          unless ← isDefEq ty (← inferType e) do
            throwError m!"visitProof: incorrectly propagated type{indentD ty}\nfor{indentD e}"
        mkExpectedTypeHint e ty
      else pure e
    if (← read).config.debug then
      unless ← Lean.MetavarContext.isWellFormed (← getLCtx) e do
        throwError m!"visitProof: proof{indentD e}\nis not well-formed in the current context\n\
          fvars: {fvars}"
    let (fvars', pf) ← mkLambdaFVarsUsedOnly' fvars e
    if !(← read).config.abstract && !fvars'.isEmpty then
      return eOrig
    if (← read).config.debug then
      unless ← Lean.MetavarContext.isWellFormed (← read).initLCtx pf do
        throwError m!"visitProof: proof{indentD pf}\nis not well-formed in the initial context\n\
          fvars: {fvars}\n{(← mkFreshExprMVar none).mvarId!}"
    let pfTy ← instantiateMVars (← inferType pf)
    let pfTy ← abstractProofs' pfTy none
    if let some pf' ← MAbs.findProof? pfTy then
      return mkAppN pf' fvars'
    MAbs.insertProof pfTy pf
    return mkAppN pf fvars'
partial def withGeneralizedProofs' {α : Type} [Inhabited α] (e : Expr) (ty? : Option Expr)
    (k : Array Expr → Array Expr → Expr → MGen α) :
    MGen α := do
  let propToFVar := (← get).propToFVar
  let (e, generalizations) ← MGen.runMAbs <| abstractProofs' e ty?
  let rec
    go [Inhabited α] (i : Nat) (fvars pfs : Array Expr)
        (proofToFVar propToFVar : ExprMap Expr) : MGen α := do
      if h : i < generalizations.size then
        let (ty, pf) := generalizations[i]
        let ty := (← instantiateMVars (ty.replace proofToFVar.get?)).cleanupAnnotations
        withLocalDeclD (← mkFreshUserName `pf) ty fun fvar => do
          go (i + 1) (fvars := fvars.push fvar) (pfs := pfs.push pf)
            (proofToFVar := proofToFVar.insert pf fvar)
            (propToFVar := propToFVar.insert ty fvar)
      else
        withNewLocalInstances fvars 0 do
          let e' := e.replace proofToFVar.get?
          modify fun s => { s with propToFVar }
          k fvars pfs e'
  go 0 #[] #[] (proofToFVar := {}) (propToFVar := propToFVar)

partial def generalizeProofsCore'
    (g : MVarId) (fvars rfvars : Array FVarId) (target : Bool) :
    MGen (Array Expr × MVarId) := go g 0 #[]
where
  go (g : MVarId) (i : Nat) (hs : Array Expr) : MGen (Array Expr × MVarId) := g.withContext do
    let tag ← g.getTag
    if h : i < rfvars.size then
      let fvar := rfvars[i]
      if fvars.contains fvar then
        let tgt ← instantiateMVars <| ← g.getType
        let ty := (if tgt.isLet then tgt.letType! else tgt.bindingDomain!).cleanupAnnotations
        if ← pure tgt.isLet <&&> Meta.isProp ty then
          let tgt' := Expr.forallE tgt.letName! ty tgt.letBody! .default
          let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
          g.assign <| .app g' tgt.letValue!
          return ← go g'.mvarId! i hs
        if let some pf := (← get).propToFVar.get? ty then
          let tgt' := tgt.bindingBody!.instantiate1 pf
          let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
          g.assign <| .lam tgt.bindingName! tgt.bindingDomain! g' tgt.bindingInfo!
          return ← go g'.mvarId! (i + 1) hs
        match tgt with
        | .forallE n t b bi =>
          let prop ← Meta.isProp t
          withGeneralizedProofs' t none fun hs' pfs' t' => do
            let t' := t'.cleanupAnnotations
            let tgt' := Expr.forallE n t' b bi
            let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
            let lam ←
              mkLambdaFVars hs' g' (usedOnly := false) (usedLetOnly := false)
            g.assign <| mkAppN lam pfs'
            let (fvar', g') ← g'.mvarId!.intro1P
            g'.withContext do Elab.pushInfoLeaf <|
              .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
            if prop then
              MGen.insertFVar t' (.fvar fvar')
            go g' (i + 1) (hs ++ hs')
        | .letE n t v b _ =>
          withGeneralizedProofs' t none fun hs' pfs' t' => do
            withGeneralizedProofs' v t' fun hs'' pfs'' v' => do
              let tgt' := Expr.letE n t' v' b false
              let g' ← mkFreshExprSyntheticOpaqueMVar tgt' tag
              let lam ←
                mkLambdaFVars (hs' ++ hs'') g' (usedOnly := false) (usedLetOnly := false)
              g.assign <| mkAppN lam (pfs' ++ pfs'')
              let (fvar', g') ← g'.mvarId!.intro1P
              g'.withContext do Elab.pushInfoLeaf <|
                .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
              go g' (i + 1) (hs ++ hs' ++ hs'')
        | _ => unreachable!
      else
        let (fvar', g') ← g.intro1P
        g'.withContext do Elab.pushInfoLeaf <|
          .ofFVarAliasInfo { id := fvar', baseId := fvar, userName := ← fvar'.getUserName }
        go g' (i + 1) hs
    else if target then
      withGeneralizedProofs' (← g.getType) none fun hs' pfs' ty' => do
        let g' ← mkFreshExprSyntheticOpaqueMVar ty' tag
        g.assign <| mkAppN (← mkLambdaFVars hs' g' (usedOnly := false) (usedLetOnly := false)) pfs'
        return (hs ++ hs', g'.mvarId!)
    else
      return (hs, g)

end GeneralizeProofs

open Lean Elab Parser.Tactic Elab.Tactic Mathlib.Tactic.GeneralizeProofs
partial def generalizeProofs'
    (g : MVarId) (fvars : Array FVarId) (target : Bool) (config : Config := {}) :
    MetaM (Array Expr × MVarId) := do
  let (rfvars, g) ← g.revert fvars (clearAuxDeclsInsteadOfRevert := true)
  g.withContext do
    let s := { propToFVar := ← initialPropToFVar }
    GeneralizeProofs.generalizeProofsCore' g fvars rfvars target |>.run config |>.run' s

elab (name := generalizeProofsElab'') "generalize_proofs" config?:(Parser.Tactic.config)?
    hs:(ppSpace colGt binderIdent)* loc?:(location)? : tactic => withMainContext do
  let config ← elabConfig (mkOptionalNode config?)
  let (fvars, target) ←
    match expandOptLocation (Lean.mkOptionalNode loc?) with
    | .wildcard => pure ((← getLCtx).getFVarIds, true)
    | .targets t target => pure (← getFVarIds t, target)
  liftMetaTactic1 fun g => do
    let (pfs, g) ← generalizeProofs' g fvars target config
    g.withContext do
      let mut lctx ← getLCtx
      for h in hs, fvar in pfs do
        if let `(binderIdent| $s:ident) := h then
          lctx := lctx.setUserName fvar.fvarId! s.getId
        Expr.addLocalVarInfoForBinderIdent fvar h
      Meta.withLCtx lctx (← Meta.getLocalInstances) do
        let g' ← Meta.mkFreshExprSyntheticOpaqueMVar (← g.getType) (← g.getTag)
        g.assign g'
        return g'.mvarId!

end Harmonic
set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace OQS

/-!
# DtN (Schur/Kron) as System–Environment Elimination (Scaffold)

Given a split `V ≃ B ⊕ I` and a full operator `L : Matrix V V ℝ`, we define blocks
`LBB, LBI, LIB, LII`. The Dirichlet-to-Neumann (DtN) response on the boundary is the
Schur complement:

  Λ := LBB - LBI * LII⁻¹ * LIB

## Key hardening change (DtN well-posedness)

Previously this module accepted an arbitrary matrix `LIIinv`. This is too weak for the
Pillar-A foundation because it does not record *that* `LIIinv` is an actual inverse of
the interior block `LII`.

We therefore introduce an explicit *witness* structure `InteriorInv` carrying
`inv : Matrix I I ℝ` together with a two-sided inverse proof obligation
`TwoSidedInv (LII) inv`.

This makes the OQS DtN interface aligned with the Layer-A gate style (`TwoSidedInv`)
and enables later proofs about uniqueness/well-posedness without depending on `Matrix.inv`.

This file includes:
* a semantic lemma: `boundaryFlux_eq_DtN_mulVec` (pure algebra; no inverse needed),
* a well-posedness lemma: `blockII_mulVec_interiorSolve` (requires the inverse witness).
-/

namespace Split

variable {V : Type} [Fintype V] [DecidableEq V]

variable (s : PillarA.OQS.Split V)

open PillarA.LayerA

/-! ### Inverse witness for the interior block -/

/-- Witness that the interior block `LII` is invertible,
without using `Matrix.inv` in the statement. -/
structure InteriorInv (L : Matrix V V ℝ) where
  /-- candidate inverse for `LII := s.blockII L` -/
  inv : Matrix s.I s.I ℝ
  /-- two-sided inverse law: `inv * LII = 1` and `LII * inv = 1` -/
  invOK : PillarA.LayerA.TwoSidedInv (s.blockII L) inv

/-!
## Minimal well-posedness axis (contract)

Pillar A needs an explicit *axis* that separates:

* what is purely algebraic (Schur complement identities), from
* what requires **graph/Laplacian hypotheses** (positivity + connectivity) to guarantee
  the existence of an inverse witness for the interior block.

We therefore expose a non-vacuous contract, parameterized by two predicates:

* `PosWeights` – expresses the positivity / M-matrix nature needed for invertibility;
* `ConnInterior` – expresses the relevant connectivity of the eliminated interior.

Later Layer B can instantiate these predicates using the concrete weighted graph model
and prove the implication to `InteriorInv`.
-/

structure InteriorWellposedAxis (L : Matrix V V ℝ) where
  PosWeights : Prop
  ConnInterior : Prop
  inv_of_axis : PosWeights → ConnInterior → ∃ _w : InteriorInv (s := s) L, True

namespace InteriorWellposedAxis

variable {L : Matrix V V ℝ}

/-
NOTE (downstream): A previous draft tried `PosWeights := True` and `ConnInterior := True`
and then manufactured an `InteriorInv` for an arbitrary `L`. This is false in general
(it would imply that an arbitrary `LII := s.blockII L` is invertible).
We keep `mkWitnessAxis` below as a logically safe scaffold that does not claim global
invertibility.
-/
/--
Scaffold axis: `PosWeights` records *existence* of an interior inverse witness.

This avoids an incorrect global claim (you cannot derive invertibility of an arbitrary
`LII` from `True`). Layer B should later replace this with meaningful
positivity/connectivity predicates implying existence of `InteriorInv`.
-/
def mkWitnessAxis (L : Matrix V V ℝ) : InteriorWellposedAxis (s := s) L := by
  refine ⟨(∃ w : InteriorInv (s := s) L, True), True, ?_⟩
  intro hPos _hConn
  exact hPos

end InteriorWellposedAxis

/-! ### DtN, interior solve, and boundary flux -/

/-- DtN matrix induced from a full matrix `L` and an inverse witness for `LII`. -/
def DtN_of (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) : Matrix s.B s.B ℝ := PillarA.LayerA.DtN
    (LBB := s.blockBB L)
    (LBI := s.blockBI L)
    (LIB := s.blockIB L)
    (LIIinv := w.inv)

/-- Interior elimination given boundary potential `φ` (requires an inverse witness). -/
def interiorSolve (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    s.I → ℝ :=
  fun i => - (w.inv.mulVec ((s.blockIB L).mulVec φ)) i

/-- Boundary flux induced by boundary potential `φ` and interior state `uI`. -/
def boundaryFlux (L : Matrix V V ℝ) (φ : s.B → ℝ) (uI : s.I → ℝ) :
    s.B → ℝ :=
  fun b => (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec uI b

/-!
### Pure algebraic semantic lemma

If we eliminate the interior as `uI := - inv * (LIB * φ)`, then

  boundaryFlux(L, φ, uI) = DtN(L, inv) * φ.

This lemma does **not** use the fact that `inv` is an actual inverse; it is purely the
Schur complement algebra.
-/

theorem boundaryFlux_eq_DtN_mulVec
    (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    s.boundaryFlux L φ (s.interiorSolve L w φ)
      =
    (s.DtN_of L w).mulVec φ := by
  classical
  -- Abbreviations.
  let rhsI : s.I → ℝ := ((s.blockIB L).mulVec φ)
  let wI : s.I → ℝ := w.inv.mulVec rhsI
  let M : Matrix s.B s.B ℝ := (s.blockBI L) * w.inv * (s.blockIB L)

  funext b

  -- Main component identity (after unfolding the definitions).
  have hMain :
      (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec (fun i => - wI i) b
        =
      ((s.blockBB L) + (-M)).mulVec φ b := by
    -- Pull the minus sign out of the boundary `mulVec`.
    have hNeg :
        (s.blockBI L).mulVec (fun i => - wI i) b
          =
        - (s.blockBI L).mulVec wI b := by
      simp [Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, mul_neg]

    -- Compose the nested `mulVec` applications into one `mulVec` of the product matrix.
    have hComp :
        M.mulVec φ b = (s.blockBI L).mulVec wI b := by
      simp [M, wI, rhsI, Matrix.mul_assoc, Matrix.mulVec_mulVec]

    -- Move the leading minus into the matrix.
    have hNegMat : (-M).mulVec φ b = - (M.mulVec φ b) := by
      simp [M, Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, neg_mul]

    have hInteriorTerm :
        (s.blockBI L).mulVec (fun i => - wI i) b = (-M).mulVec φ b := by
      calc
        (s.blockBI L).mulVec (fun i => - wI i) b
            = - (s.blockBI L).mulVec wI b := by
              exact hNeg
        _   = - (M.mulVec φ b) := by
              exact congrArg Neg.neg hComp.symm
        _   = (-M).mulVec φ b := by
              exact hNegMat.symm

    -- Linearity of `mulVec` in the matrix argument, evaluated at `b`.
    have hAdd :
        ((s.blockBB L) + (-M)).mulVec φ b
          =
        (s.blockBB L).mulVec φ b + (-M).mulVec φ b := by
      simp [Matrix.mulVec, dotProduct, Finset.sum_add_distrib, add_mul]

    calc
      (s.blockBB L).mulVec φ b + (s.blockBI L).mulVec (fun i => - wI i) b
          = (s.blockBB L).mulVec φ b + (-M).mulVec φ b := by
              simp [hInteriorTerm]
      _   = ((s.blockBB L) + (-M)).mulVec φ b := by
              simp [hAdd]

  -- Unfold the definitions of flux and DtN.
  have hw : s.interiorSolve L w φ = fun i => - wI i := by
    funext i
    simp [interiorSolve, wI, rhsI]

  -- Reduce the goal to the already established component identity `hMain`.
  -- Note: `PillarA.LayerA.DtN` is defined as `LBB - LBI * LIIinv * LIB`.
  simpa [boundaryFlux, DtN_of, PillarA.LayerA.DtN, sub_eq_add_neg, hw, M] using hMain

/-!
### Well-posedness lemma (uses the inverse witness)

The elimination `uI := - inv * (LIB * φ)` actually satisfies the interior equation

  LII * uI = - LIB * φ,

provided `inv` is a two-sided inverse of `LII`.
-/

theorem blockII_mulVec_interiorSolve
    (L : Matrix V V ℝ) (w : InteriorInv (s := s) L) (φ : s.B → ℝ) :
    (s.blockII L).mulVec (s.interiorSolve L w φ)
      =
    - (s.blockIB L).mulVec φ := by
  classical
  -- Abbreviate the right-hand side vector.
  let rhs : s.I → ℝ := (s.blockIB L).mulVec φ
  -- Use the right-inverse law `LII * inv = 1`.
  have hL : (s.blockII L) * w.inv = (1 : Matrix s.I s.I ℝ) := w.invOK.2

  -- Compose mulVec through a product matrix
  -- (needed in reverse direction of `Matrix.mulVec_mulVec`).
  have hMulVec : (s.blockII L).mulVec (w.inv.mulVec rhs) = ((s.blockII L) * w.inv).mulVec rhs := by
    have h' : ((s.blockII L) * w.inv).mulVec rhs = (s.blockII L).mulVec (w.inv.mulVec rhs) := by
      simp [Matrix.mulVec_mulVec]
    exact h'.symm

  -- Helper: `1.mulVec rhs = rhs`.
  have hOne : (1 : Matrix s.I s.I ℝ).mulVec rhs = rhs := by
    funext i
    classical
    -- Expand the identity matrix and evaluate the resulting sum.
    simp [Matrix.mulVec, Matrix.one_apply, dotProduct]

  -- Main calculation.
  funext i
  calc
    ((s.blockII L).mulVec (s.interiorSolve L w φ)) i
        = - ((s.blockII L).mulVec (w.inv.mulVec rhs)) i := by
            simp [interiorSolve, rhs, Matrix.mulVec, dotProduct,
              Finset.sum_neg_distrib, mul_neg]
    _   = - (((s.blockII L) * w.inv).mulVec rhs) i := by
            simp [hMulVec]
    _   = - ((1 : Matrix s.I s.I ℝ).mulVec rhs) i := by
            simp [hL]
    _   = (- rhs) i := by
            simp [hOne]
    _   = (- (s.blockIB L).mulVec φ) i := by
            simp [rhs]

end Split

end OQS

end PillarA
