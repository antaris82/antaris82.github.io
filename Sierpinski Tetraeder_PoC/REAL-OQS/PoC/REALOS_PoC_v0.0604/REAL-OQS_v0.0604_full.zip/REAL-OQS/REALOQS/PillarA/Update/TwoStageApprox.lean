import REALOQS.PillarA.Update.ApproximationPipeline

/-!
REALOQS / Pillar A / Update

This module is a *stability alias* that provides the historical import path

  `REALOQS.PillarA.Update.TwoStageApprox`

for the two-stage approximation interface defined in
`REALOQS.PillarA.Update.ApproximationPipeline`.

Rationale:
* Many downstream modules (and meta-audits) refer to this path.
* Keeping the alias avoids widespread import churn.
* No new axioms or content are introduced here.
-/
