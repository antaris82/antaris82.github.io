import Mathlib
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.SubstrateClass
import REALOQS.PillarA.Core.Selection
import REALOQS.PillarA.Core.SymmetryAction

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Two-stage approximation pipeline (contract surface)
-- v0.11d (2026-01-24)

Phase 4 refactor goal:
  `PillarA.Update.*` must be substrate-agnostic and must not import `PillarA.Ideal.*`.

We express the two approximation stages as *operators* on a single carrier type `S`.

Stages:
  - Stage 1 (Init): truncate/cut tails + integrate tails on finest cells → REAL0.
  - Stage 2 (Select): subsystem selection (region vs all cells) + local/global hooks.

We keep this file analysis-free: no numerics/linear algebra, only a stable interface.

Important: properties that are not derivable from bare operator symbols are encoded as
fields/typeclass obligations, so later implementations must supply proofs.
-/

namespace PillarA
namespace Update

universe u

/-! ## Mode selection -/

/-- Selection mode on a (finite) index type `α`: a selected region or all cells. -/
inductive SubsystemMode (α : Type u) where
  | region (R : Finset α)
  | allCells

namespace SubsystemMode

variable {α : Type u}

/-- Single-cell selection as a singleton region. -/
def single [DecidableEq α] (w : α) : SubsystemMode α :=
  SubsystemMode.region ({w} : Finset α)

end SubsystemMode

/-!
## Two-stage operator interface (single carrier type)

Key point:
  Laws like idempotence/monotonicity/all-cells consistency are not derivable from the
  raw operators, so we encode them as obligations.

We also parameterize by an abstract substrate `Cell : Nat → Type` so the selection mode
can range over the *finest-level cells* `Cell policy.L_max` without importing any concrete
IDEAL address tree.
-/

structure TwoStageApprox (b : Nat) where
  (policy : _root_.PillarA.LayerA.Policy b)
  (Cell : Nat → Type u)
  [instSubstrate : PillarA.LayerA.Substrate Cell]
  (S : Type)
  (truncateTail : S → S)
  (integrateTail : S → S)
  (select : SubsystemMode (Cell policy.L_max) → S → S)
  /- Stage-1 contract (projection-like preprocessing) -/
  truncate_idem : ∀ s : S, truncateTail (truncateTail s) = truncateTail s
  integrate_idem : ∀ s : S, integrateTail (integrateTail s) = integrateTail s
  stage1_idem : ∀ s : S,
    integrateTail (truncateTail (integrateTail (truncateTail s))) =
    integrateTail (truncateTail s)

attribute [instance] TwoStageApprox.instSubstrate

namespace TwoStageApprox

variable {b : Nat} (A : TwoStageApprox b)

abbrev FinestCell : Type u := A.Cell A.policy.L_max

def finestCells : Finset A.FinestCell :=
  -- purely combinatoric: all finest-level cells are available via `Fintype` from the substrate
  Finset.univ

def stage1 (s : A.S) : A.S := A.integrateTail (A.truncateTail s)

def pipeline (m : SubsystemMode A.FinestCell) (s : A.S) : A.S := A.select m (A.stage1 s)

/-! ### Definitional equalities (stable names, no sorries) -/

theorem gate_STAGE1_DEF (s : A.S) : A.stage1 s = A.integrateTail (A.truncateTail s) := by
  rfl

theorem gate_PIPELINE_DEF (m : SubsystemMode A.FinestCell) (s : A.S) :
    A.pipeline m s = A.select m (A.integrateTail (A.truncateTail s)) := by
  rfl

/-! ### Stage-1 laws are fields of `TwoStageApprox` -/

theorem gate_TRUNCATE_IDEMPOTENT :
    (∀ s : A.S, A.truncateTail (A.truncateTail s) = A.truncateTail s) := A.truncate_idem

theorem gate_INTEGRATE_IDEMPOTENT :
    (∀ s : A.S, A.integrateTail (A.integrateTail s) = A.integrateTail s) := A.integrate_idem

theorem gate_STAGE1_IDEMPOTENT :
    (∀ s : A.S,
      A.integrateTail (A.truncateTail (A.integrateTail (A.truncateTail s))) =
      A.integrateTail (A.truncateTail s)) := A.stage1_idem

/-!
### Constructors

We provide:
* `mkOfLaws`: fully explicit constructor.
* `mkIdStage1`: safe placeholder with stage-1 operators as `id` so the laws hold by `rfl`.
-/

def mkOfLaws
    {b : Nat}
    (policy : _root_.PillarA.LayerA.Policy b)
    (Cell : Nat → Type u) [PillarA.LayerA.Substrate Cell]
    (S : Type)
    (truncateTail integrateTail : S → S)
    (select : SubsystemMode (Cell policy.L_max) → S → S)
    (truncate_idem : ∀ s : S, truncateTail (truncateTail s) = truncateTail s)
    (integrate_idem : ∀ s : S, integrateTail (integrateTail s) = integrateTail s)
    (stage1_idem : ∀ s : S,
      integrateTail (truncateTail (integrateTail (truncateTail s))) =
      integrateTail (truncateTail s)) : TwoStageApprox b :=
  { policy := policy
    Cell := Cell
    S := S
    truncateTail := truncateTail
    integrateTail := integrateTail
    select := select
    truncate_idem := truncate_idem
    integrate_idem := integrate_idem
    stage1_idem := stage1_idem }

def mkIdStage1
    {b : Nat}
    (policy : _root_.PillarA.LayerA.Policy b)
    (Cell : Nat → Type u) [PillarA.LayerA.Substrate Cell]
    (S : Type)
    (_truncateTail _integrateTail : S → S)
    (select : SubsystemMode (Cell policy.L_max) → S → S) : TwoStageApprox b := by
  refine
    { policy := policy
      Cell := Cell
      S := S
      truncateTail := id
      integrateTail := id
      select := select
      truncate_idem := ?_
      integrate_idem := ?_
      stage1_idem := ?_ }
  · intro s; rfl
  · intro s; rfl
  · intro s; rfl

/-!
## Monotonicity (typeclass obligation)

Monotonicity needs a preorder on `S`, so we express it as a typeclass.
-/

class MonotoneLaws [Preorder A.S] : Prop where
  truncate_monotone : Monotone A.truncateTail
  integrate_monotone : Monotone A.integrateTail
  select_monotone : ∀ m : SubsystemMode A.FinestCell, Monotone (A.select m)

def MonotoneLaws.mkOf [Preorder A.S]
    (hTr : Monotone A.truncateTail)
    (hIn : Monotone A.integrateTail)
    (hSel : ∀ m : SubsystemMode A.FinestCell, Monotone (A.select m)) :
    MonotoneLaws (A := A) :=
  ⟨hTr, hIn, hSel⟩

theorem gate_PIPELINE_MONOTONE [Preorder A.S]
    [h : MonotoneLaws (A := A)] (m : SubsystemMode A.FinestCell) : Monotone (A.pipeline m) := by
  intro s t hst
  have htr : A.truncateTail s ≤ A.truncateTail t := (MonotoneLaws.truncate_monotone (A := A)) hst
  have hint :
      A.integrateTail (A.truncateTail s) ≤ A.integrateTail (A.truncateTail t) :=
    (MonotoneLaws.integrate_monotone (A := A)) htr
  exact (MonotoneLaws.select_monotone (A := A) m) hint

/-!
## "All cells" vs "selected region" pointwise consistency (contract)

We parameterize an observer `Obs` that extracts the `w`-component of a state.
To keep the contract minimal and substrate-agnostic, we express the "single-cell"
case via singleton regions.

Phase-1 strengthening: we make the observer itself a first-class structure and
require **non-vacuity** of the predicate (for each cell, it is neither identically
`True` nor identically `False` as a predicate on states).

This eliminates the previous `placeholder constructorObserver` escape hatch from productive code.
-/

/-- Observer predicate with explicit non-vacuity witnesses. -/
structure Observer where
  /-- Observation predicate at the finest-cell level. -/
  Obs : A.FinestCell → A.S → Prop
  /-- Congruence: observation respects definitional equality of states. -/
  obs_congr : ∀ w s t, s = t → Obs w s → Obs w t
  /-- Non-vacuity (positive witness): for every cell there exists a state observed as `True`. -/
  true_witness : ∀ w : A.FinestCell, ∃ s : A.S, Obs w s
  /-- Non-vacuity (negative witness): for every cell there exists a state observed as `False`. -/
  false_witness : ∀ w : A.FinestCell, ∃ s : A.S, ¬ Obs w s

/-- Pointwise consistency between singleton selection and the all-cells selection. -/
class AllCellsConsistency where
  observer : Observer (A := A)
  allcells_pointwise :
    ∀ s : A.S,
      (∀ w ∈ A.finestCells,
        observer.Obs w (A.pipeline (SubsystemMode.single w) s)) →
      (∀ w ∈ A.finestCells,
        observer.Obs w (A.pipeline SubsystemMode.allCells s))

namespace AllCellsConsistency

variable {b : Nat} {A : TwoStageApprox b}

@[simp] def Obs (C : AllCellsConsistency (A := A)) : A.FinestCell → A.S → Prop :=
  C.observer.Obs

def obs_congr (C : AllCellsConsistency (A := A)) :
    ∀ w s t, s = t → C.Obs w s → C.Obs w t :=
  C.observer.obs_congr

def true_witness (C : AllCellsConsistency (A := A)) :
    ∀ w : A.FinestCell, ∃ s : A.S, C.Obs w s :=
  C.observer.true_witness

def false_witness (C : AllCellsConsistency (A := A)) :
    ∀ w : A.FinestCell, ∃ s : A.S, ¬ C.Obs w s :=
  C.observer.false_witness

end AllCellsConsistency

theorem gate_ALLCELLS_POINTWISE
    [C : AllCellsConsistency (A := A)]
    (s : A.S) :
    (∀ w ∈ A.finestCells, C.Obs w (A.pipeline (SubsystemMode.single w) s)) →
    (∀ w ∈ A.finestCells, C.Obs w (A.pipeline SubsystemMode.allCells s)) :=
  C.allcells_pointwise s

/-!
## Equivariance wiring (Symmetry ↔ Update)

`PillarA.Core.SymmetryAction` provides the *abstract* equivariance contracts.

This module makes them usable by the update pipeline by:
* defining a natural action on `SubsystemMode` induced from a level-wise action on cells,
* bundling equivariance obligations for the stage-1 operators and the selection operator,
* exposing a stable gate theorem that the full pipeline commutes with the symmetry.

No concrete symmetry instance is provided here; downstream models supply those.
-/

open PillarA.LayerA

namespace Equivariance

variable {b : Nat} (A : TwoStageApprox b)

abbrev Cell := A.Cell

/-- Action on selection modes induced by the cell action at the finest level. -/
noncomputable def actMode
    (S : SymmetryAction (Cell := A.Cell)) (g : S.G) :
    SubsystemMode A.FinestCell → SubsystemMode A.FinestCell :=
  by
    classical
    intro m
    cases m with
    | region R =>
        exact SubsystemMode.region (R.image (S.act (L := A.policy.L_max) g))
    | allCells =>
        exact SubsystemMode.allCells

/-- Predicate: a mode is invariant under a given symmetry action. -/
def ModeInvariant (S : SymmetryAction (Cell := A.Cell)) (m : SubsystemMode A.FinestCell) : Prop :=
  ∀ g : S.G, actMode (A := A) S g m = m

/--
Equivariance laws required for the two-stage approximation pipeline.

This is the missing *wiring layer* between the symmetry contracts and the update stack.
-/
class Laws (S : SymmetryAction (Cell := A.Cell)) where
  /-- Action on the carrier state space. -/
  actS : S.G → A.S → A.S
  /-- Stage-1 preprocessing operators commute with the symmetry. -/
  truncate_equivariant : ∀ g s, actS g (A.truncateTail s) = A.truncateTail (actS g s)
  integrate_equivariant : ∀ g s, actS g (A.integrateTail s) = A.integrateTail (actS g s)
  /-- Selection commutes, provided the mode is transformed accordingly. -/
  select_equivariant : ∀ g m s,
      actS g (A.select m s) = A.select (actMode (A := A) S g m) (actS g s)

namespace Laws

variable {A} {S : SymmetryAction (Cell := A.Cell)}

theorem gate_STAGE1_EQUIVARIANT [h : Laws (A := A) S] (g : S.G) (s : A.S) :
    h.actS g (A.stage1 s) = A.stage1 (h.actS g s) := by
  -- unfold `stage1` and use the field obligations
  simp [TwoStageApprox.stage1, h.integrate_equivariant, h.truncate_equivariant]

theorem gate_PIPELINE_EQUIVARIANT [h : Laws (A := A) S]
    (g : S.G) (m : SubsystemMode A.FinestCell) (s : A.S) :
    h.actS g (A.pipeline m s) = A.pipeline (actMode (A := A) S g m) (h.actS g s) := by
  -- `pipeline m s = select m (stage1 s)`; rewrite, then apply equivariance
  simp [TwoStageApprox.pipeline, gate_STAGE1_EQUIVARIANT (A := A) (S := S) (g := g) (s := s),
    h.select_equivariant]

/--
Stage-1 as an equivariant update kernel (Core contract re-used in Update).

This is the *concrete instantiation* of
`PillarA.LayerA.SymmetryAction.UpdateKernelEquivariant` for `stage1`.
-/
def stage1KernelEquivariant
    [h : Laws (A := A) S] :
    PillarA.LayerA.SymmetryAction.UpdateKernelEquivariant (S := S) (State := A.S) where
  actState := h.actS
  step := A.stage1
  step_equivariant := by
    intro g s
    simpa using gate_STAGE1_EQUIVARIANT (A := A) (S := S) (g := g) (s := s)

/--
If a mode is invariant, the full pipeline for that mode is an equivariant update kernel.
-/
def pipelineKernelEquivariant
    [h : Laws (A := A) S] (m : SubsystemMode A.FinestCell)
    (hm : ModeInvariant (A := A) S m) :
    PillarA.LayerA.SymmetryAction.UpdateKernelEquivariant (S := S) (State := A.S) where
  actState := h.actS
  step := A.pipeline m
  step_equivariant := by
    intro g s
    have := gate_PIPELINE_EQUIVARIANT (A := A) (S := S) (g := g) (m := m) (s := s)
    -- use mode invariance to drop the transformed mode
    simpa [ModeInvariant, hm g] using this

end Laws

end Equivariance

end TwoStageApprox

end Update
end PillarA
