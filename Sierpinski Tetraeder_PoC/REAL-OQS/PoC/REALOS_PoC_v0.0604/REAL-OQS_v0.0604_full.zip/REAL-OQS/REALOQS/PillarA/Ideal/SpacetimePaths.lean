import Mathlib
import REALOQS.PillarA.Ideal.Foliation
import REALOQS.PillarA.Kinematics.Worldline
import REALOQS.PillarA.Kinematics.DiscreteSpacetime

set_option linter.style.longLine false


set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Discrete spacetime paths on the address foliation

This file provides the minimal glue between:
- the address-tree foliation (`Sigma`, `τ`, prefix order), and
- kinematic trajectories (`Worldline`, `WorldTube`).

The intent is **not** to assert SR/GR, but to make the combinatorial notion of
"leafing through hypersurfaces" explicit in Lean.
-/

namespace PillarA
namespace Ideal

open PillarA.Kinematics

section AddrPaths

variable {b : Nat}

/-- Discrete time-stamp on addresses: depth (= list length). -/
def τ (b : Nat) : Addr b → Nat := fun a => a.length

/-- The slice (hypersurface) at depth `n` as a set (backed by the finite `cellsAtLevel`). -/
def Sigma (b : Nat) (n : Nat) : Set (Addr b) := {a | a ∈ cellsAtLevel b n}

/-- Prefix order on addresses (notation used throughout Pillar A). -/
notation:50 a " ⪯ " x => a <+: x

/-- One-step causal advance on addresses: `y` is a direct child of `x`.

This is the discrete notion of "future step" used for the address-tree spacetime.
-/
def AddrStep (x y : Addr b) : Prop := ∃ d : Fin b, y = child x d

/-- The canonical discrete spacetime on the address foliation. -/
def AddrSpacetime (b : Nat) : PillarA.Kinematics.DiscreteSpacetime (Addr b) where
  τ := τ b
  step := AddrStep (b := b)
  step_tau := by
    intro x y h
    rcases h with ⟨d, rfl⟩
    -- `child` appends one digit; `length` increases by 1.
    simp [child, τ, List.length_append]

theorem gate_addrSpacetime_mem_slice_iff (n : Nat) (a : Addr b) :
    a ∈ (AddrSpacetime b).Sigma n ↔ a ∈ Sigma b n := by
  -- LHS is definitional: `ST.τ a = n`; RHS is membership in the finite slice.
  change ((AddrSpacetime b).τ a = n) ↔ a ∈ cellsAtLevel b n
  -- `τ` is `length` on addresses.
  simpa [PillarA.Kinematics.DiscreteSpacetime.Sigma, AddrSpacetime, Sigma, τ] using
    (mem_cellsAtLevel_iff_length b n a).symm

abbrev AddrWorldline (b : Nat) := Worldline (Addr b)

abbrev AddrWorldTube (b : Nat) := WorldTube (Addr b)

/-- A worldline is foliation-adapted if its `n`-th event lies on `Σ_n`. -/
def IsFoliationAdapted (γ : AddrWorldline b) : Prop := ∀ n, τ (b := b) (γ n) = n

/-- A worldline is causal (future-directed) if it follows the prefix order stepwise. -/
def IsCausalChain (γ : AddrWorldline b) : Prop := ∀ n, (γ n) ⪯ (γ (n+1))

/-- A worldtube is foliation-adapted if every event it contains at step `n` lies on `Σ_n`. -/
def IsFoliationAdaptedTube (W : AddrWorldTube b) : Prop := ∀ n x, x ∈ W n → τ (b := b) x = n

/-- A worldtube is causal if for each event at step `n` there exists a future event in the tube
at step `n+1` extending it in the prefix order. -/
def IsCausalTube (W : AddrWorldTube b) : Prop := ∀ n x, x ∈ W n → ∃ y, y ∈ W (n+1) ∧ x ⪯ y

/-- Gate: foliation-adapted worldtube implies every event is on the matching slice. -/
theorem gate_adaptedTube_mem_sigma (W : AddrWorldTube b) (h : IsFoliationAdaptedTube (b := b) W)
    (n : Nat) (x : Addr b) (hx : x ∈ W n) : x ∈ Sigma b n := by
  -- membership in the finite slice is equivalent to having the correct length
  have hxlen : x.length = n := by
    simpa [IsFoliationAdaptedTube, τ] using h n x hx
  simpa [Sigma] using (mem_cellsAtLevel_iff_length b n x).2 hxlen

/-- Gate: foliation-adapted implies membership in the corresponding slice. -/
theorem gate_adapted_mem_sigma (γ : AddrWorldline b) (h : IsFoliationAdapted (b := b) γ) (n : Nat) :
    γ n ∈ Sigma b n := by
  have hxlen : (γ n).length = n := by
    simpa [IsFoliationAdapted, τ] using h n
  simpa [Sigma] using (mem_cellsAtLevel_iff_length b n (γ n)).2 hxlen

/-- Gate: causal chain implies nondecreasing `τ` along the trajectory. -/
theorem gate_causal_tau_mono (γ : AddrWorldline b) (h : IsCausalChain (b := b) γ) :
    ∀ n, τ (b := b) (γ n) ≤ τ (b := b) (γ (n+1)) := by
  intro n
  -- `a <+: x` implies `length a ≤ length x`.
  rcases h n with ⟨t, ht⟩
  have hlen' : (γ n).length + t.length = (γ (n+1)).length := by
    simpa [List.length_append] using congrArg List.length ht
  have hlen : (γ (n+1)).length = (γ n).length + t.length := hlen'.symm
  -- Now `m ≤ m + k` and rewrite the RHS using `hlen`.
  have : (γ n).length ≤ (γ (n+1)).length := by
    -- Rewrite the RHS using `hlen` and apply `Nat.le_add_right`.
    -- This avoids `simpa` lints and does not rely on simp-normal forms.
    rw [hlen]
    exact Nat.le_add_right (γ n).length t.length
  simp [τ]
  exact this

/-- Gate: prefix order implies monotonicity of `τ` (= length). -/
theorem gate_precedes_tau_le {a x : Addr b} (h : a ⪯ x) : τ (b := b) a ≤ τ (b := b) x := by
  rcases h with ⟨t, ht⟩
  have hlen' : a.length + t.length = x.length := by
    simpa [List.length_append] using congrArg List.length ht
  have hlen : x.length = a.length + t.length := hlen'.symm
  have : a.length ≤ x.length := by
    -- Rewrite the RHS using `hlen` and apply `Nat.le_add_right`.
    rw [hlen]
    exact Nat.le_add_right a.length t.length
  simp [τ]
  exact this

/-!
## Adapter: from (prefix + foliation) worldlines to `DiscreteSpacetime.Worldline`

In the address-tree model, the canonical step relation is **direct child** (`AddrStep`).
However, earlier convenience predicates use only the prefix order (`⪯`) and foliation
adaptation (`τ(γ n)=n`). Together, these imply that each step extends the address by
exactly one digit, hence is a direct child step.

This lemma provides the missing glue needed to use foliation-aware kinematics (`ST.Worldline`)
and therefore foliation-aware clocks.
-/

/-- Prefix + length increment by 1 implies "direct child". -/
theorem gate_precedes_len_succ_implies_child {a x : Addr b}
    (hpre : a ⪯ x) (hlen : x.length = a.length + 1) :
    ∃ d : Fin b, x = child a d := by
  rcases hpre with ⟨t, rfl⟩
  -- Reduce to the suffix list `t` in `a ++ t`.
  have htlen : t.length = 1 := by
    have : a.length + t.length = a.length + 1 := by
      simpa [List.length_append] using hlen
    exact Nat.add_left_cancel this
  -- A list of length 1 is a singleton.
  cases t with
  | nil =>
      -- Contradiction: `0 ≠ 1`.
      cases htlen
  | cons d t' =>
      have ht'len : t'.length = 0 := by
        -- From `succ t'.length = 1 = succ 0` infer `t'.length = 0`.
        have : Nat.succ t'.length = 1 := by
          simpa using htlen
        have : Nat.succ t'.length = Nat.succ 0 := by
          simpa using this
        exact Nat.succ_inj.mp this
      have ht' : t' = [] := by
        exact (List.length_eq_zero_iff).1 ht'len
      subst ht'
      refine ⟨d, ?_⟩
      -- `child a d` is definitionally `a` with one digit appended.
      simp [child]

/-- Build a spacetime-worldline (`ST.Worldline`) from an address-worldline that is
foliation-adapted and causal in the prefix order. -/
def toSTWorldline (γ : AddrWorldline b)
    (hadapt : IsFoliationAdapted (b := b) γ)
    (hcausal : IsCausalChain (b := b) γ) :
    (AddrSpacetime b).Worldline := by
  refine
    { x := γ
      step_ok := ?_ }
  intro n
  have hpre : (γ n) ⪯ (γ (n+1)) := hcausal n

  have hx : (γ (n+1)).length = n + 1 := by
    simpa [IsFoliationAdapted, τ] using hadapt (n+1)
  have hy : (γ n).length = n := by
    simpa [IsFoliationAdapted, τ] using hadapt n

  have hlen : (γ (n+1)).length = (γ n).length + 1 := by
    calc
      (γ (n+1)).length = n + 1 := hx
      _ = (γ n).length + 1 := by
        -- Rewrite the RHS using `hy : (γ n).length = n`.
        simp [hy]

  rcases gate_precedes_len_succ_implies_child (b := b) (a := γ n) (x := γ (n+1)) hpre hlen with ⟨d, hd⟩
  exact ⟨d, hd⟩

end AddrPaths

end Ideal
end PillarA
