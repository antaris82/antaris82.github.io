import REALOQS.PillarA.Ideal.TreeOfCliques.Laplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Split
import REALOQS.PillarA.OQS.DtN

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

open scoped BigOperators

noncomputable section

open PillarA.OQS
open PillarA.LayerA

/-!
Phase 2 (part 2): Dirichlet-to-Neumann (DtN) on Tree-of-Cliques.

For each level `k`, we have:
* a finite vertex set `V_k`,
* a canonical boundary `B_k` and interior `I_k`, and
* the Laplacian matrix `L_k` induced from the derived conductance.

This file wires these into the generic `OQS.Split` + `OQS.DtN` layer.

Important: `DtN` requires an **inverse witness** for the interior block.
In Pillar A we expose this as a *gate* assumption (e.g. via `det ≠ 0`),
without committing to analytic claims.
-/

namespace DtN

variable (b k : Nat)

abbrev V := Vertex b k
abbrev B := Boundary b k
abbrev I := Interior b k

abbrev s : PillarA.OQS.Split (V (b := b) (k := k)) := split (b := b) (k := k)

abbrev L : Matrix (V (b := b) (k := k)) (V (b := b) (k := k)) ℝ :=
  PillarA.Ideal.TreeOfCliques.laplacian
    (b := b) (k := k)

/-- Convenience: the interior block `LII` for the Tree-of-Cliques Laplacian. -/
abbrev LII : Matrix (I (b := b) (k := k)) (I (b := b) (k := k)) ℝ :=
  (s (b := b) (k := k)).blockII (L (b := b) (k := k))

/-- Build an `InteriorInv` witness from the *gate* assumption `det(LII) ≠ 0`. -/
def interiorInv_of_det
    (hdet : (LII (b := b) (k := k)).det ≠ 0) :
    PillarA.OQS.Split.InteriorInv (s := s (b := b) (k := k)) (L (b := b) (k := k)) := by
  classical
  -- Deterministic choice: use the built-in inverse `A⁻¹` (no `Classical.choose`).
  let A : Matrix (I (b := b) (k := k)) (I (b := b) (k := k)) ℝ :=
    (LII (b := b) (k := k))
  refine ⟨A⁻¹, ?_⟩
  -- `det(A) ≠ 0` ensures the canonical inverse satisfies the two-sided inverse laws.
  simpa [A] using
    (PillarA.LayerA.gate_DTN_WELLPOSED_canonical (ι := I (b := b) (k := k)) (A := A) hdet)

/-- DtN matrix induced from `L_k`, requiring only the gate `det(LII) ≠ 0`. -/
def dtn_of_det
    (hdet : (LII (b := b) (k := k)).det ≠ 0) :
    Matrix (B (b := b) (k := k)) (B (b := b) (k := k)) ℝ :=
  (s (b := b) (k := k)).DtN_of (L := L (b := b) (k := k))
    (w := interiorInv_of_det (b := b) (k := k) hdet)

end DtN

end

end TreeOfCliques
end Ideal
end PillarA
