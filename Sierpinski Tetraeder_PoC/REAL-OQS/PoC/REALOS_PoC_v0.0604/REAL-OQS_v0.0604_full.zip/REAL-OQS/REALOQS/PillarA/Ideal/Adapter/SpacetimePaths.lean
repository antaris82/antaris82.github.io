import REALOQS.PillarA.Ideal.SpacetimePaths

/-!
# IDEAL Adapter: SpacetimePaths

Thin re-export wrapper (Phase 8 import policy).
-/
