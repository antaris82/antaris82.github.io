import REALOQS.PillarA.Ideal.TreeOfCliques.DtN
import REALOQS.PillarA.OQS.DtNStabilized

set_option autoImplicit false
open scoped BigOperators

/-!
# Tree-of-Cliques: stabilized DtN (canonical jitter)

Specialization of `PillarA.OQS.DtNStabilized` to the Tree-of-Cliques substrate.

Pipeline:
`conductance → Laplacian L_k → Split(B_k,I_k) → DtN_stabilized(L_k)`,

with the remaining well-posedness requirement kept as a gate:
`det( symm(LII) + δ·I ) ≠ 0`.
-/

namespace PillarA
namespace Ideal
namespace TreeOfCliques

noncomputable section

open PillarA.OQS
open PillarA.LayerA

namespace DtNStabilized

variable {b : Nat}

abbrev s (k : Nat) : PillarA.OQS.Split (Vertex b k) :=
  split (b := b) (k := k)

abbrev L (k : Nat) : Matrix (Vertex b k) (Vertex b k) ℝ :=
  PillarA.Ideal.TreeOfCliques.laplacian (b := b) (k := k)

/-- Stabilized interior block used for Tree-of-Cliques DtN.

We keep indices as `((s k).I)` to avoid transport issues; for this concrete split
it is definally the same as `Interior b k`.
-/
abbrev LII_stab (p : PillarA.LayerA.Policy b) (k : Nat) :
    Matrix ((s (b := b) k).I) ((s (b := b) k).I) ℝ :=
  PillarA.OQS.Split.DtNStabilized.LII_stabilized
    (s := s (b := b) k) (p := p) (L := L (b := b) k)

/-- Regularized DtN for Tree-of-Cliques, gated by `det(LII_stab) ≠ 0`. -/
noncomputable def dtn_stabilized_of_det
    (p : PillarA.LayerA.Policy b) (k : Nat)
    (hdet : (LII_stab (b := b) p k).det ≠ 0) :
    Matrix ((s (b := b) k).B) ((s (b := b) k).B) ℝ :=
  PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det
    (s := s (b := b) k) (p := p) (L := L (b := b) k) hdet

end DtNStabilized

end

end TreeOfCliques
end Ideal
end PillarA
