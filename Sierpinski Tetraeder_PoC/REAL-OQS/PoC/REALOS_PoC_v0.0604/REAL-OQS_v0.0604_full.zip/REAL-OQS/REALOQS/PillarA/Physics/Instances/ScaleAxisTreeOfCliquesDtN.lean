import Mathlib
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNSemantics
import REALOQS.PillarA.Physics.ScaleBreakingMismatch

set_option autoImplicit false

/-!
# Phase 4 instance wiring: Tree-of-Cliques + DtN observation → mismatch-based scale axis

This module does **not** attempt to define the qualitative (coarsening/towers) part of a
`ScaleBreakingAxis`. Instead, it provides a *canonical* way to equip an existing axis
on the Tree-of-Cliques carrier with **nontrivial diagnostics** derived from a DtN-based
operator observer.

Key output:
* `scaleAxisTreeOfCliquesDtN` : attaches `breakMeasure` / `breakMeasureIdeal` via
  `axis_fromMismatch` using `Sem.opObserver` and the Frobenius-norm mismatch.

This replaces the "default" use of
`ScaleBreakingAxis.placeholder constructor` in development examples:
`breakMeasure` is no longer definitionally `0` but computed from a mismatch hook.
-/

namespace PillarA
namespace Physics

noncomputable section

open PillarA.Update

namespace Instances
namespace TreeOfCliques

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b :=
  PillarA.Update.Instances.TreeOfCliquesApprox.mk (b := b) p

abbrev Sem : PillarA.Update.TailElimDtNSemantics (A := (A (p := p))) :=
  PillarA.Update.Instances.TreeOfCliquesDtNSemantics.mk (b := b) p

/-- Canonical mismatch functional on the DtN boundary type.

It is the Frobenius norm of the operator difference.
We choose the identity projector here; gauge-null removal can be refined later.
-/
noncomputable def mismatchFunctional
    [Fintype (Sem (p := p)).split.B] [DecidableEq (Sem (p := p)).split.B] :
    MismatchFunctional (α := (Sem (p := p)).split.B) :=
  MismatchFunctional.NormDiff.mkId (α := (Sem (p := p)).split.B)

/-- Attach mismatch-based diagnostics to an existing qualitative axis on the Tree-of-Cliques
carrier type, using the DtN observer.

`eps` is the normalization floor used by `normalizeTrace` (still a placeholder in Pillar A),
but keeping it explicit makes the API future-proof.
-/
noncomputable def scaleAxisTreeOfCliquesDtN
    [Fintype (Sem (p := p)).split.B] [DecidableEq (Sem (p := p)).split.B]
    (SB : ScaleBreakingAxis ((A (p := p)).S))
    (eps : ℝ) (eps_pos : 0 < eps) :
    ScaleBreakingAxis ((A (p := p)).S) :=
  axis_fromMismatch
    (A := SB)
    (Obs := (Sem (p := p)).opObserver)
    (M := mismatchFunctional (p := p))
    (eps := eps)
    (eps_pos := eps_pos)

end TreeOfCliques
end Instances

end
end Physics
end PillarA
