import Mathlib
import REALOQS.PillarA.Ideal.Substrate
import REALOQS.PillarA.Ideal.LCPMeasure

set_option autoImplicit false

/-!
REALOQS / Pillar A / Ideal: Foliations

This file is intentionally lightweight.

Important: `PillarA.Ideal.lcp` is defined in `LCPMeasure.lean` (address-level LCP).
We keep this module free of competing `lcp` definitions to ensure a stable import
surface (in particular for `REALOQS.PillarA.Interface`).

Any foliation/causal-structure claims are introduced elsewhere.
-/

namespace PillarA
namespace Ideal

open scoped BigOperators

/-- If `a` is a prefix of `x` and has the same length, then `a = x`. -/
lemma eq_of_prefix_of_length_eq {α : Type} {a x : List α}
    (h : a <+: x) (ha : a.length = x.length) : a = x := by
  rcases h with ⟨t, rfl⟩
  -- `ha : a.length = (a ++ t).length` forces `t = []`.
  have ha' : a.length = a.length + t.length := by
    -- `(a ++ t).length = a.length + t.length`
    simpa [List.length_append] using ha
  have htlen : t.length = 0 := by
    -- from `a.length = a.length + t.length` infer `t.length = 0`
    have : a.length + t.length = a.length + 0 := by
      simpa [Nat.add_zero] using ha'.symm
    exact Nat.add_left_cancel this
  have ht : t = [] := by
    -- `List.length_eq_zero_iff : t.length = 0 ↔ t = []`
    exact (List.length_eq_zero_iff.mp htlen)
  subst ht
  simp

/-
Notes:
- The canonical address-level LCP is `PillarA.Ideal.lcp` (see `LCPMeasure`).
- If a generic list-level LCP is ever needed, define it under a different name
  (e.g. `lcpList`) to avoid constant-name clashes.
-/

end Ideal
end PillarA
