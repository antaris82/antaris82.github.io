import Mathlib

import REALOQS.PillarA.Core.Determinism
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Deterministic export wiring (policy hash + exporter)

`PillarA.Core.Determinism` fixes *what can be proven in the kernel* vs.
*what must be demanded as a contract* from later layers.

This module makes those contracts usable in the update layer by providing:

* a stable (pure) export identifier derived from `(PolicyHash, step)`,
* a minimal "export plan" that connects an abstract state to an exported artifact,
* gate theorems exposing the determinism obligations in an end-to-end form.

No concrete hashing or serialization is implemented here.
-/

namespace PillarA
namespace Update

open PillarA.LayerA
open PillarA.LayerA.Determinism

namespace DeterministicExport

variable {b : Nat}

/-- A stable export identifier derived from a policy hash and the step index.

This is intentionally simple and pure; later layers may strengthen the scheme.
-/
def exportId (H : PolicyHash b) (p : Policy b) (step : Nat) : Nat :=
  (H.hash p) * 65537 + step

/-- Gate: `exportId` depends only on `Policy.key` (given `PolicyHash`). -/
theorem gate_EXPORTID_DEPENDS_ONLY_ON_KEY
    (H : PolicyHash b) (p q : Policy b) (step : Nat)
    (hkey : Policy.key p = Policy.key q) :
    exportId (b := b) H p step = exportId (b := b) H q step := by
  simp [exportId, H.depends_only_on_key p q hkey]

/-- A minimal end-to-end export plan.

* `policy` is the semantic policy that should be hashed/embedded into the export.
* `observe` extracts an `Artifact` from the internal `State`.
* `E.emit` produces the actual (abstract) export bundle.
-/
structure Plan (State Artifact : Type) where
  policy : Policy b
  H : PolicyHash b
  E : Exporter b Artifact
  observe : State → Artifact

namespace Plan

variable {State Artifact : Type}

/-- The policy/step derived identifier for this plan. -/
def id (P : Plan (b := b) State Artifact) (step : Nat) : Nat :=
  exportId (b := b) P.H P.policy step

/-- Emit an export bundle from a state. -/
def emit (P : Plan (b := b) State Artifact) (step : Nat) (s : State) : ExportBundle :=
  P.E.emit P.policy step (P.observe s)

end Plan

/-- Gate: if an exporter satisfies `ExportLaws`, its output depends only on the semantic key. -/
theorem gate_EXPORT_DEPENDS_ONLY_ON_KEY
    {Artifact : Type} (E : Exporter b Artifact) [ExportLaws (b := b) E] :
    ∀ (p q : Policy b) (step : Nat) (a : Artifact),
      Policy.key p = Policy.key q → E.emit p step a = E.emit q step a :=
  Determinism.gate_D1_EXPORT_DEPENDS_ONLY_ON_KEY (b := b) E

variable {Artifact : Type}

/-- Specialized constructor: attach a determinism/export plan to a `TwoStageApprox`. -/
def mkPlanFromTwoStage
    (A : TwoStageApprox b)
    (H : PolicyHash b)
    (E : Exporter b Artifact)
    (observe : A.S → Artifact) :
    Plan (b := b) A.S Artifact :=
  { policy := A.policy
    H := H
    E := E
    observe := observe }

/-- Emit an export of the stage-1 state. -/
def emitStage1 {State Artifact : Type}
    (P : Plan (b := b) State Artifact)
    (A : TwoStageApprox b) (step : Nat)
    (coerce : A.S → State) (s : A.S) : ExportBundle :=
  P.emit step (coerce (A.stage1 s))

/-- Emit an export of the full pipeline output (for a chosen mode). -/
def emitPipeline {State Artifact : Type}
    (P : Plan (b := b) State Artifact)
    (A : TwoStageApprox b) (m : SubsystemMode A.FinestCell)
    (step : Nat) (coerce : A.S → State) (s : A.S) : ExportBundle :=
  P.emit step (coerce (A.pipeline m s))

end DeterministicExport

end Update
end PillarA
