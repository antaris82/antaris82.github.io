/-
REALOQS / Pillar A: heavy developer umbrella

This module is a convenience import for interactive development.
It intentionally pulls in IDEAL adapters and the retained scaffold layers
(physics / geometry / symmetry / kinematics).

Recommended usage:
- Downstream / public: `import REALOQS.PillarA.Interface`
- Internal dev:       `import REALOQS.PillarA.All`
-/

-- Canonical, substrate-agnostic API surface
import REALOQS.PillarA.Interface

-- IDEAL adapters (optional substrate instantiation)
import REALOQS.PillarA.Ideal.Adapter.Substrate
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance
import REALOQS.PillarA.Ideal.Adapter.InfiniteCarrierInstance
import REALOQS.PillarA.Ideal.Adapter.Seed
import REALOQS.PillarA.Ideal.Adapter.Foliation
import REALOQS.PillarA.Ideal.Adapter.SpacetimePaths
import REALOQS.PillarA.Ideal.Adapter.RegionNetEmbedding
import REALOQS.PillarA.Ideal.Adapter.LCPMeasure
import REALOQS.PillarA.Ideal.Adapter.IdealSymmetryNoether
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff

-- Derived IDEAL instance: Tree-of-Cliques (address-tree graph)
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAll

-- Concrete update instances for Tree-of-Cliques (Phase 3)
import REALOQS.PillarA.Ideal.Adapter.UpdateInstancesAll

-- Phase 4: nontrivial mismatch functional (norm-difference)
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff

-- Physics hooks (mass/scale-breaking)
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Physics.ScaleBreakingMismatch
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarA.Physics.ScaleBreakingFaithfulness
import REALOQS.PillarA.Physics.ScaleBreakingFaithfulnessD

-- Phase 4: wiring Tree-of-Cliques + DtN observer into mismatch-based scale diagnostics
import REALOQS.PillarA.Physics.Instances.ScaleAxisTreeOfCliquesDtN
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalD
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalLawsD
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesBoundaryK1Shape

-- Geometry hooks (spectral dimension / heat kernel proxies)
import REALOQS.PillarA.Geometry.DimensionHooks

-- Additional retained scaffold umbrella (kept for downstream workflows)
import REALOQS.PillarA.Scaffold.All
