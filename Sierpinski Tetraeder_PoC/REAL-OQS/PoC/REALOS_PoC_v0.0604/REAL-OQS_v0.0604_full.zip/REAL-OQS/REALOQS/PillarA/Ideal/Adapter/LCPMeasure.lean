import REALOQS.PillarA.Ideal.LCPMeasure

/-!
# IDEAL Adapter: LCPMeasure

Thin re-export wrapper (Phase 8 import policy).
-/
