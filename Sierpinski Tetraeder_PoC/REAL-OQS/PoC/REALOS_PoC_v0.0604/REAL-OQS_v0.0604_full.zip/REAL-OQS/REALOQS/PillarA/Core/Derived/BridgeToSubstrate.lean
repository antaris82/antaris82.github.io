import REALOQS.PillarA.Core.Derived.GNS
import REALOQS.PillarA.Core.Derived.ModularKMS
import REALOQS.PillarA.Core.ToC.AQFTSubstrate

/-!
# Phase II bridge: Derived hooks -> AQFTSubstrate fields

This module provides glue so that, when a type `A` has a
`PillarA.Derived.HasDerivedGNS A` instance (resp. `HasDerivedModularKMS A`), one
can build an `AQFTSubstrate A` whose `GNSData` and/or `ModularKMSData` fields are
compatible with those derived builders.

Key point
`AQFTSubstrate.GNSData` and `AQFTSubstrate.ModularKMSData` are *type families*
`StateOn → Type u`, while the Phase II hooks provide constructors that require a
proof of `isState`.

So we bridge by setting
- `GNSData ω := isState ω → (derived output)`
- `ModularKMSData ω := isState ω → (derived output)`

This keeps Pillar B ungated, while allowing downstream code to request the proof
when it wants to actually build the derived object.
-/

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

/-- IDEAL-level `AQFTSubstrate` whose GNS data is compatible with `HasDerivedGNS`. -/
noncomputable def mkAQFTSubstrate_fromDerivedGNS
    (A : Type u)
    (SA : PillarB.AQFT.StarAlgebra A)
    [h : HasDerivedGNS A] :
    PillarA.ToC.AQFTSubstrate A := by
  classical
  refine
    { SA := SA
      StateOn := h.StateOn
      eval := fun _ _ => 0
      isState := h.isState
      GNSData := fun w => h.isState w → PillarA.Derived.GNSData A
      ModularKMSData := fun _ => PUnit
    }

/-- IDEAL-level `AQFTSubstrate` whose modular/KMS data is compatible with `HasDerivedModularKMS`. -/
noncomputable def mkAQFTSubstrate_fromDerivedModularKMS
    (A : Type u)
    (SA : PillarB.AQFT.StarAlgebra A)
    [h : HasDerivedModularKMS A] :
    PillarA.ToC.AQFTSubstrate A := by
  classical
  refine
    { SA := SA
      StateOn := h.StateOn
      eval := fun _ _ => 0
      isState := h.isState
      GNSData := fun _ => PUnit
      ModularKMSData := fun w => h.isState w → Type u
    }

end Derived
end PillarA
