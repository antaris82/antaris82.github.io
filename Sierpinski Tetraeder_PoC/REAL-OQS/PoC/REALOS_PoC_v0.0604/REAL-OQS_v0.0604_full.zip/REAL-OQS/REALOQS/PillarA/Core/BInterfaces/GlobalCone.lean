import REALOQS.PillarA.Core.BInterfaces.StateNet

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# Global cones (Core/BInterfaces, Phase 5)

A `GlobalStateCone SN` is a compatible family of local states: for each region `r`
we have a state `ω r`, and all restriction maps commute.

The key constructor `GlobalStateCone.fromTop` builds such a family from a single
state on the distinguished top region `SN.RN.top`.
-/

universe u v

/-- A compatible family of local states (a cone over the restriction maps). -/
structure GlobalStateCone {Ω : Type u} (SN : StateNet (Ω := Ω)) where
  ω : ∀ r : SN.RN.Region, SN.State r
  compat : ∀ {a b : SN.RN.Region} (hab : a ≤ b),
    SN.restrict hab (ω b) = ω a

namespace GlobalStateCone

variable {Ω : Type u} {SN : StateNet (Ω := Ω)}

theorem gate_cone_compat (C : GlobalStateCone (SN := SN)) {a b : SN.RN.Region} (hab : a ≤ b) :
    SN.restrict hab (C.ω b) = C.ω a :=
  C.compat hab

/-- Build a global cone by restricting a distinguished state on the top region. -/
def fromTop (ρTop : SN.State SN.RN.top) : GlobalStateCone (SN := SN) where
  ω r := SN.restrict (RegionNet.le_top' (RN := SN.RN) r) ρTop
  compat := by
    intro a b hab
    -- `b ≤ top` by definition of the distinguished top region
    have hbc : b ≤ SN.RN.top := RegionNet.le_top' (RN := SN.RN) b
    -- the two proofs of `a ≤ top` coincide by subsingleton-elimination (Prop)
    have hatop :
        (le_trans hab hbc) = (RegionNet.le_top' (RN := SN.RN) a) := by
      apply Subsingleton.elim
    -- functoriality of restriction
    have hcomp :
        SN.restrict (a := a) (b := b) hab (SN.restrict (a := b) (b := SN.RN.top) hbc ρTop) =
          SN.restrict (a := a) (b := SN.RN.top) (le_trans hab hbc) ρTop :=
      SN.restrict_comp hab hbc ρTop
    simpa [hatop] using hcomp

theorem gate_cone_fromTop_compat (ρTop : SN.State SN.RN.top)
    {a b : SN.RN.Region} (hab : a ≤ b) :
    SN.restrict hab ((fromTop (SN := SN) ρTop).ω b) = (fromTop (SN := SN) ρTop).ω a :=
  (fromTop (SN := SN) ρTop).compat hab

end GlobalStateCone

end LayerA
end PillarA
