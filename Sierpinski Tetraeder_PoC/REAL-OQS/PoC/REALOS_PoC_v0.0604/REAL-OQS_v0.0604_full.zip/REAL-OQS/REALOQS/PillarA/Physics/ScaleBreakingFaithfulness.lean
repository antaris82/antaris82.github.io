import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatch

set_option linter.style.longLine false
set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Faithfulness requirements for scale-breaking diagnostics

The mismatch-based diagnostics (`breakMeasure...`) are only useful if they are *faithful*:

1. IDEAL scale invariance should imply **observed equality** under coarsening.
2. Observed equality should imply **zero mismatch** (already available as a gate).
3. REAL scale breaking should yield **observed inequality** for some level.
4. That observed inequality should imply **positive mismatch**.

Important: Pillar A's `LinOp` is an intentionally abstract operator carrier.
Therefore, mismatch positivity can only be demanded **on the concrete normalized
observed operators that actually occur in the axis**, not on *all* operators.

No physics is proven here; all nontrivial parts are exposed as explicit contracts.
-/

namespace PillarA
namespace Physics

open PillarA.Update

variable {S α : Type}

/-- Faithfulness requirements for mismatch-based scale breaking on a fixed observation type `α`.

This is phrased in terms of the *observed operators* (after coarsening), not in terms of
underlying state semantics.
-/
structure ScaleBreakingFaithfulness
    (A : ScaleBreakingAxis S) (Obs : OpObserver (S := S) (α := α))
    (M : MismatchFunctional (α := α)) (eps : ℝ) : Prop where
  eps_pos : eps > 0

  /-- Under IDEAL scale invariance, observation is invariant (after coarsening). -/
  ideal_observed_eq_of_scaleInvariant :
    A.scaleInvariant → ∀ k,
      Obs.op (A.ideal k) = Obs.op (A.coarsen k (A.ideal (k+1)))

  /-- If REAL breaks scale invariance, then the **normalized** observation differs at some level. -/
  real_normed_observed_neq_of_breaksScale :
    A.breaksScale → ∃ k,
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)) ≠
        normalizeTrace (α := α) M.P M.T eps eps_pos
          (Obs.op (A.coarsen k (A.real (k + 1))))

  /-- Mismatch positivity for the REAL tower's normalized observation pair. -/
  mismatch_pos_of_real_normed_observed_neq :
    ∀ k,
      normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)) ≠
        normalizeTrace (α := α) M.P M.T eps eps_pos
          (Obs.op (A.coarsen k (A.real (k + 1)))) →
        0 < M.mismatch
          (normalizeTrace (α := α) M.P M.T eps eps_pos (Obs.op (A.real k)))
          (normalizeTrace (α := α) M.P M.T eps eps_pos
            (Obs.op (A.coarsen k (A.real (k + 1)))))

/-- Build the `ScaleBreakingAxis.Laws` for the mismatch-based axis assuming faithfulness. -/
noncomputable def Laws_fromMismatch_withFaithfulness
    (A : ScaleBreakingAxis S) (Obs : OpObserver (S := S) (α := α))
    (M : MismatchFunctional (α := α)) (eps : ℝ)
    (F : ScaleBreakingFaithfulness (A := A) (Obs := Obs) (M := M) eps) :
    ScaleBreakingAxis.Laws (axis_fromMismatch (A := A) Obs M eps F.eps_pos) := by
  refine
    { breakMeasureIdeal_zero_of_scaleInvariant := ?_
      breakMeasure_pos_of_breaksScale := ?_ }
  · intro hSI k
    have hObs :
        Obs.op (A.ideal k) = Obs.op (A.coarsen k (A.ideal (k + 1))) :=
      F.ideal_observed_eq_of_scaleInvariant hSI k
    have hEq :
        normalizeTrace M.P M.T eps (by exact F.eps_pos) (Obs.op (A.ideal k)) =
          normalizeTrace M.P M.T eps (by exact F.eps_pos)
            (Obs.op (A.coarsen k (A.ideal (k + 1)))) := by
      simp [hObs]
    simpa [axis_fromMismatch, breakMeasure_fromMismatchIdeal] using
      gate_breakMeasure_zero_of_observed_eq
        (tower := A.ideal) (coarsen := A.coarsen) (Obs := Obs) (M := M) (eps := eps)
        (eps_pos := F.eps_pos) (k := k) hEq
  · intro hBS
    rcases F.real_normed_observed_neq_of_breaksScale hBS with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    have hPos := F.mismatch_pos_of_real_normed_observed_neq (k := k) hk
    simpa [axis_fromMismatch, breakMeasure_fromMismatchReal, breakMeasure_fromMismatch_onTower]
      using hPos

end Physics
end PillarA
