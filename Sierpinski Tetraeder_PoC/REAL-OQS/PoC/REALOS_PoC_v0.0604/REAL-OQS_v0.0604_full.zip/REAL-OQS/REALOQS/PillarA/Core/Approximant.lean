import Mathlib
import REALOQS.PillarA.Core.SubstrateClass

set_option autoImplicit false

namespace PillarA

namespace LayerA

/-!
# Approximants (Core, Phase 1)

An `Approximant` is the **visible part** of a substrate at a fixed refinement level `L`.

Phase 1 keeps this intentionally light:
it is just a wrapper around a finite set of level-`L` cells, with a few helper functions.
-/

universe u

/-- A finite visible selection of level-`L` cells. -/
structure Approximant (Cell : Nat → Type u) (L : Nat) where
  cells : Finset (Cell L)

namespace Approximant

variable {Cell : Nat → Type u} {L : Nat}

instance : Coe (Approximant Cell L) (Finset (Cell L)) := ⟨Approximant.cells⟩

@[simp] theorem coe_cells (A : Approximant Cell L) : (A : Finset (Cell L)) = A.cells := rfl

def card (A : Approximant Cell L) : Nat := A.cells.card

/-- Full approximant: all cells at level `L`. -/
def full (Cell : Nat → Type u) (L : Nat) [Substrate Cell] : Approximant Cell L :=
  ⟨Finset.univ⟩

/-- One-step refinement of the visible part via the substrate's `children`. -/
def refine [Substrate Cell] (A : Approximant Cell L) : Approximant Cell (L + 1) :=
  ⟨Substrate.refineSet (Cell := Cell) A.cells⟩

/-- One-step coarsening of the visible part via the substrate's `parents`. -/
def coarsen [Substrate Cell] (A : Approximant Cell (L + 1)) : Approximant Cell L :=
  ⟨Substrate.coarsenSet (Cell := Cell) A.cells⟩

end Approximant

end LayerA

end PillarA
