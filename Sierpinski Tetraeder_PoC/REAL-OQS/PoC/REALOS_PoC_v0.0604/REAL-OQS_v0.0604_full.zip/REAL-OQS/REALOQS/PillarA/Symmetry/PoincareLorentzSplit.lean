import Mathlib
import REALOQS.PillarA.Symmetry.ApproxPoincare


set_option autoImplicit false

namespace PillarA

namespace Symmetry

section Exact

variable {V : Type} [AddCommGroup V] [Module ℝ V]

structure Poincare (V : Type) [AddCommGroup V] [Module ℝ V] : Type where
  a : V
  L : V ≃ₗ[ℝ] V

namespace Poincare

variable {V : Type} [AddCommGroup V] [Module ℝ V]

def actPoint (p : Poincare V) (x : V) : V := p.L x + p.a

def actVel (p : Poincare V) (v : V) : V := p.L v

theorem gate_displacement_depends_only_on_Lorentz (p : Poincare V) (x y : V) :
    (p.actPoint y - p.actPoint x) = p.actVel (y - x) := by
  -- By definition of `actPoint` and `actVel`, we have:
  have h_diff : p.actPoint y - p.actPoint x = (p.L y + p.a) - (p.L x + p.a) := by
    -- By definition of `actPoint`, we have `p.actPoint
    -- y = p.L y + p.a` and `p.actPoint x = p.L x + p.a`.
    simp [PillarA.Symmetry.Poincare.actPoint];
  -- By definition of `actVel`, we have `p.actVel (y - x) = p.L (y - x)`.
  have h_actVel : p.actVel (y - x) = p.L (y - x) := by
    rfl;
  -- By simplifying the right-hand side of h_diff, we can
  -- see that it matches the right-hand side of h_actVel.
  simp [h_diff, h_actVel]

theorem gate_stepVelocity_depends_only_on_Lorentz (p : Poincare V) (γ : ℕ → V) (n : ℕ) :
    (p.actPoint (γ (n+1)) - p.actPoint (γ n)) = p.actVel (γ (n+1) - γ n) := by
  -- By definition of Poincare action, we have p.actPoint 
  -- (γ (n + 1)) = p.L (γ (n + 1)) + p.a and p.actPoint (γ n) = p.L (γ n) + p.a.
  simp [PillarA.Symmetry.Poincare.actPoint, PillarA.Symmetry.Poincare.actVel]

end Poincare

end Exact

section ApproxHook

variable {X : Type} {d : Dist X}

structure VelocityHook (P : ApproxPoincare X d) (V : Type)
    [AddCommGroup V] [Module ℝ V] : Type where
  vel : X → X → V
  rotLin : P.Rot → (V →ₗ[ℝ] V)
  boostLin : P.Boost → (V →ₗ[ℝ] V)
  trans_invariant : ∀ (t : P.Trans) (x y : X), vel (P.τ t x) (P.τ t y) = vel x y
  rot_covariant : ∀ (r : P.Rot) (x y : X), vel (P.ρ r x) (P.ρ r y) = (rotLin r) (vel x y)
  boost_covariant : ∀ (b : P.Boost) (x y : X), vel (P.β b x) (P.β b y) = (boostLin b) (vel x y)

namespace VelocityHook

variable {V : Type} [AddCommGroup V] [Module ℝ V]

variable {P : ApproxPoincare X d} (H : VelocityHook (X := X) (d := d) P V)

def stepVel (γ : ℕ → X) (n : ℕ) : V := H.vel (γ n) (γ (n+1))

theorem gate_stepVel_trans (t : P.Trans) (γ : ℕ → X) (n : ℕ) :
    H.stepVel (γ := fun k => P.τ t (γ k)) n = H.stepVel (γ := γ) n := by
  simp [VelocityHook.stepVel, H.trans_invariant]

theorem gate_stepVel_rot (r : P.Rot) (γ : ℕ → X) (n : ℕ) :
    H.stepVel (γ := fun k => P.ρ r (γ k)) n = H.rotLin r (H.stepVel (γ := γ) n) := by
  simp [VelocityHook.stepVel, H.rot_covariant]

theorem gate_stepVel_boost (b : P.Boost) (γ : ℕ → X) (n : ℕ) :
    H.stepVel (γ := fun k => P.β b (γ k)) n = H.boostLin b (H.stepVel (γ := γ) n) := by
  simp [VelocityHook.stepVel, H.boost_covariant]

end VelocityHook

end ApproxHook

end Symmetry
end PillarA
