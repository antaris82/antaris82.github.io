import Mathlib
import REALOQS.PillarA.Ideal.Substrate
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance
import REALOQS.PillarA.Core.DirichletLaplacianBridge
import REALOQS.PillarA.Core.SymmetryAction

set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A

# Symmetry hook on IDEAL (Noether analogue without continuum)

Goal:
  Provide a purely discrete, IDEAL-level symmetry interface:
  - a canonical automorphism family of the address tree (`DigitPerm`),
  - induced actions on addresses / level words,
  - and stable gate theorem names connecting symmetry to invariance of
    Dirichlet energy and Laplacian quadratic forms.

Nontrivial algebraic/matrix lemmas are proved explicitly (no `deferred proof`).
-/

namespace PillarA
namespace Ideal

open scoped BigOperators
open PillarA.Ideal
open _root_.PillarA.LayerA

namespace IdealSymmetry

/-! ## Canonical address-tree symmetries -/

variable {b : Nat}

/-- Digit-level symmetry: permutations of the alphabet `Fin b`. -/
abbrev DigitPerm (b : Nat) := Equiv.Perm (Fin b)

/-- Action on addresses: map each digit by the permutation. -/
def actAddr (σ : DigitPerm b) : Addr b → Addr b := List.map σ

@[simp] lemma actAddr_nil (σ : DigitPerm b) : actAddr (b := b) σ [] = ([] : Addr b) := by
  simp [actAddr]

@[simp] lemma actAddr_cons (σ : DigitPerm b) (d : Fin b) (a : Addr b) :
    actAddr (b := b) σ (d :: a) = (σ d) :: actAddr (b := b) σ a := by
  simp [actAddr]

@[simp] lemma actAddr_length (σ : DigitPerm b) (a : Addr b) :
    (actAddr (b := b) σ a).length = a.length := by
  simp [actAddr]

/-- Address automorphism induced by a digit permutation. -/
def addrEquiv (σ : DigitPerm b) : (Addr b ≃ Addr b) :=
{ toFun := actAddr (b := b) σ
  invFun := actAddr (b := b) σ.symm
  left_inv := by
    intro a
    simp [actAddr]
  right_inv := by
    intro a
    simp [actAddr] }

/-- Gate: prefix relation is preserved under digit permutations. -/
theorem gate_actAddr_preserves_prefix {σ : DigitPerm b} {w a : Addr b} :
    w <:+ a → actAddr (b := b) σ w <:+ actAddr (b := b) σ a := by
  intro h
  rcases h with ⟨t, rfl⟩
  refine ⟨actAddr (b := b) σ t, ?_⟩
  simp [actAddr, List.map_append]

/-! ## Finite level model: words of fixed length -/

/-- Canonical finite representation of level-`k` addresses. -/
abbrev LevelWord (b k : Nat) := Fin k → Fin b

/-- Action on level words: post-compose with the digit permutation. -/
def actWord {k : Nat} (σ : DigitPerm b) : LevelWord b k → LevelWord b k := fun f => σ ∘ f

/-- Convert a level word to an address (list) of length `k`. -/
def wordToAddr {k : Nat} (f : LevelWord b k) : Addr b := List.ofFn f

/-- Gate: compatibility of `wordToAddr` with the address action. -/
theorem gate_wordToAddr_equivariant {k : Nat} (σ : DigitPerm b) (f : LevelWord b k) :
    wordToAddr (b := b) (k := k) (actWord (b := b) (k := k) σ f)
      = actAddr (b := b) σ (wordToAddr (b := b) (k := k) f) := by
  -- `List.map` distributes over `List.ofFn`.
  simp [wordToAddr, actWord, actAddr]

/-! ## Phase 6: Core symmetry action instance for IDEAL -/

section CoreSymmetryAction

open PillarA.LayerA

variable {L : Nat}

/-- Action of a digit permutation on a level-indexed IDEAL cell. -/
def actIdealCell (σ : DigitPerm b) : IdealCell b L → IdealCell b L := by
  intro c
  refine ⟨actAddr (b := b) σ c.1, ?_⟩
  apply (mem_cellsAtLevel_iff_length b L (actAddr (b := b) σ c.1)).2
  have hc_len : c.1.length = L := (mem_cellsAtLevel_iff_length b L c.1).1 c.2
  -- `actAddr` preserves length.
  simp [actAddr_length (b := b) σ c.1, hc_len]

@[simp] lemma actIdealCell_val (σ : DigitPerm b) (c : IdealCell b L) :
    (actIdealCell (b := b) (L := L) σ c).1 = actAddr (b := b) σ c.1 := rfl

@[simp] lemma actIdealCell_one (c : IdealCell b L) :
    actIdealCell (b := b) (L := L) (1 : DigitPerm b) c = c := by
  ext
  simp [actIdealCell, actAddr]

@[simp] lemma actIdealCell_mul (σ τ : DigitPerm b) (c : IdealCell b L) :
    actIdealCell (b := b) (L := L) (σ * τ) c
      = actIdealCell (b := b) (L := L) σ (actIdealCell (b := b) (L := L) τ c) := by
  ext
  simp [actIdealCell, actAddr, List.map_map]

theorem actIdealCell_leftInv (σ : DigitPerm b) :
    Function.LeftInverse (actIdealCell (b := b) (L := L) σ.symm)
      (actIdealCell (b := b) (L := L) σ) := by
  intro c
  ext
  simp [actIdealCell, actAddr, List.map_map]

theorem actIdealCell_rightInv (σ : DigitPerm b) :
    Function.RightInverse (actIdealCell (b := b) (L := L) σ.symm)
      (actIdealCell (b := b) (L := L) σ) := by
  intro c
  ext
  simp [actIdealCell, actAddr, List.map_map]

theorem actIdealCell_bijective (σ : DigitPerm b) :
    Function.Bijective (actIdealCell (b := b) (L := L) σ) := by
  refine ⟨(actIdealCell_leftInv (b := b) (L := L) σ).injective,
          (actIdealCell_rightInv (b := b) (L := L) σ).surjective⟩

lemma actAddr_take (σ : DigitPerm b) (a : Addr b) (n : Nat) :
    (actAddr (b := b) σ a).take n = actAddr (b := b) σ (a.take n) := by
  induction n generalizing a with
  | zero =>
      simp [actAddr]
  | succ n ih =>
      cases a with
      | nil =>
          simp [actAddr]
      | cons d a =>
          simp [actAddr]

lemma parent_equivariant (σ : DigitPerm b) (c : IdealCell b (L + 1)) :
    IdealCell.parent (b := b) (L := L) (actIdealCell (b := b) (L := L + 1) σ c)
      = actIdealCell (b := b) (L := L) σ (IdealCell.parent (b := b) (L := L) c) := by
  ext
  -- `parent` is `take L`, and `actAddr` commutes with `take`.
  simp [IdealCell.parent, actIdealCell, actAddr]

lemma actAddr_child (σ : DigitPerm b) (a : Addr b) (d : Fin b) :
    actAddr (b := b) σ (Ideal.child a d) = Ideal.child (actAddr (b := b) σ a) (σ d) := by
  simp [Ideal.child, actAddr, List.map_append]

lemma child_equivariant (σ : DigitPerm b) (p : IdealCell b L) (d : Fin b) :
    actIdealCell (b := b) (L := L + 1) σ (IdealCell.child (b := b) (L := L) p d)
      = IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) (σ d) := by
  ext
  simp [IdealCell.child, actIdealCell, actAddr_child]

/-- Canonical symmetry action on IDEAL induced by digit permutations. -/
noncomputable def symmetryAction (b : Nat) : 
PillarA.LayerA.SymmetryAction (Cell := IdealCell b) := by
  classical
  refine
    { G := DigitPerm b
      instGroup := by infer_instance
      act := fun {L} σ c => actIdealCell (b := b) (L := L) σ c
      act_one := by
        intro L c
        simp
      act_mul := by
        intro L σ τ c
        simp
      act_bijective := by
        intro L σ
        exact actIdealCell_bijective (b := b) (L := L) σ
      parents_equivariant := by
        intro L σ c
        classical
        -- For the IDEAL substrate instance, `parents` is definitionaly a singleton.
        have hParents (q : IdealCell b (L + 1)) :
            Substrate.parents (Cell := IdealCell b) q
              = ({IdealCell.parent (b := b) (L := L) q} : Finset (IdealCell b L)) := rfl
        -- Reduce to the commuting lemma `parent_equivariant`.
        ext x
        constructor
        · intro hx
          have hx0 : x ∈ ({IdealCell.parent (b := b) (L := L)
              (actIdealCell (b := b) (L := L + 1) σ c)} : Finset (IdealCell b L)) := by
            simpa [hParents (q := actIdealCell (b := b) (L := L + 1) σ c)] using hx
          have hx1 : x = IdealCell.parent (b := b) (L := L)
              (actIdealCell (b := b) (L := L + 1) σ c) :=
            Finset.mem_singleton.1 hx0
          -- RHS is also a singleton image.
          have : x ∈ ({actIdealCell (b := b) (L := L) σ (IdealCell.parent (b := b) (L := L) c)}
              : Finset (IdealCell b L)) := by
            simp [hx1, parent_equivariant (b := b) (L := L) σ c]
          -- Convert back to the RHS.
          simpa [hParents (q := c), Finset.image_singleton] using this
        · intro hx
          -- Unfold RHS to a singleton and read off the element.
          have hx0 : x ∈ ({actIdealCell (b := b) (L := L) σ (IdealCell.parent (b := b) (L := L) c)}
              : Finset (IdealCell b L)) := by
            simpa [hParents (q := c), Finset.image_singleton] using hx
          have hx1 : x = actIdealCell (b := b) (L := L) σ (IdealCell.parent (b := b) (L := L) c) :=
            Finset.mem_singleton.1 hx0
          have : x ∈ ({IdealCell.parent (b := b) (L := L)
              (actIdealCell (b := b) (L := L + 1) σ c)} : Finset (IdealCell b L)) := by
            simp [hx1, parent_equivariant (b := b) (L := L) σ c]
          simpa [hParents (q := actIdealCell (b := b) (L := L + 1) σ c)] using this
      children_equivariant := by
        intro L σ p
        classical
        have hChildren (q : IdealCell b L) :
            Substrate.children (Cell := IdealCell b) q
              = (Finset.univ : Finset (Fin b)).image
                  (fun d : Fin b => IdealCell.child (b := b) (L := L) q d) := rfl
        ext x
        constructor
        · intro hx
          -- Unfold LHS membership to get a digit `d`.
          have hx0 : x ∈ (Finset.univ : Finset (Fin b)).image
              (fun d : Fin b =>
                IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) d) := by
            simpa [hChildren (q := actIdealCell (b := b) (L := L) σ p)] using hx
          rcases Finset.mem_image.1 hx0 with ⟨d, _hduniv, hxd⟩
          -- Choose the preimage digit `σ.symm d`.
          let y : IdealCell b (L + 1) := IdealCell.child (b := b) (L := L) p (σ.symm d)
          have hy : y ∈ Substrate.children (Cell := IdealCell b) p := by
            have : y ∈ (Finset.univ : Finset (Fin b)).image
                (fun d : Fin b => IdealCell.child (b := b) (L := L) p d) := by
              exact Finset.mem_image.2 ⟨σ.symm d, Finset.mem_univ _, rfl⟩
            simpa [hChildren (q := p)] using this
          -- `act y` is exactly the required child (use `child_equivariant`).
          have hAct : actIdealCell (b := b) (L := L + 1) σ y
              = IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) d := by
            -- `σ (σ.symm d) = d`.
            simpa [y, Equiv.apply_symm_apply] using
              (child_equivariant (b := b) (L := L) σ p (σ.symm d))
          have : actIdealCell (b := b) (L := L + 1) σ y = x := by
            -- `hxd` is `child ... d = x`.
            simpa [hxd] using hAct
          exact Finset.mem_image.2 ⟨y, hy, this⟩
        · intro hx
          -- Unfold RHS membership: `x = act y` with `y ∈ children p`.
          rcases Finset.mem_image.1 hx with ⟨y, hy, rfl⟩
          -- Unfold `hy` to get a digit `d` with `y = child p d`.
          have hy0 : y ∈ (Finset.univ : Finset (Fin b)).image
              (fun d : Fin b => IdealCell.child (b := b) (L := L) p d) := by
            simpa [hChildren (q := p)] using hy
          rcases Finset.mem_image.1 hy0 with ⟨d, _hduniv, hyd⟩
          -- Now `act (child p d) = child (act p) (σ d)`.
          have hAct : actIdealCell (b := b) (L := L + 1) σ y
              = IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) (σ d) := by
            simpa [hyd.symm] using (child_equivariant (b := b) (L := L) σ p d)
          -- The RHS element is in the children set of `act p` by construction.
          have hmem : IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) (σ d)
              ∈ Substrate.children (Cell := IdealCell b) (actIdealCell (b := b) (L := L) σ p) := by
            have : IdealCell.child (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) (σ d)
                ∈ (Finset.univ : Finset (Fin b)).image
                    (fun d : Fin b =>
                      IdealCell.child 
                      (b := b) (L := L) (actIdealCell (b := b) (L := L) σ p) d) := by
              exact Finset.mem_image.2 ⟨σ d, Finset.mem_univ _, rfl⟩
            rw [hChildren (q := actIdealCell (b := b) (L := L) σ p)]
            exact this
          simpa [hAct] using hmem
    }

/-
Register the IDEAL action as the default `SymmetryAction` on level-indexed IDEAL cells.
This is the Phase-6 "IDEAL provides the instance" deliverable.
-/
noncomputable instance (b : Nat) : PillarA.LayerA.SymmetryAction (Cell := IdealCell b) :=
  symmetryAction (b := b)

end CoreSymmetryAction

/-! ## Symmetry → invariance hooks (finite graph semantics) -/

section Finite

variable {V : Type} [Fintype V] [DecidableEq V]

/-- Weight invariance under a permutation symmetry. -/
def WeightInvariant (σ : Equiv.Perm V) (c : Weight V) : Prop := ∀ i j, c (σ i) (σ j) = c i j

/-- Pullback of a function along a permutation. -/
def pull (σ : Equiv.Perm V) (f : V → ℝ) : V → ℝ := fun v => f (σ v)

/-- Convenience: Laplacian quadratic form for a conductance weight.

This is defined locally (rather than globally) to avoid cross-module name coupling.
-/
noncomputable abbrev laplacianQuadForm (c : Weight V) (f : V → ℝ) : ℝ :=
  quadForm (laplacian c) f

/-- Permutation matrix (real-valued) representing `σ` on `V`. -/
def permMatrix (σ : Equiv.Perm V) : Matrix V V ℝ := fun i j => if σ j = i then 1 else 0

/-- Gate: Dirichlet energy is invariant under a symmetry of the weight. -/
theorem gate_DIRICHLET_invariant_under_perm
    (σ : Equiv.Perm V) (c : Weight V) (f : V → ℝ)
    (hinv : WeightInvariant σ c) :
    dirichletEnergy c (pull σ f) = dirichletEnergy c f := by
  classical
  -- `offDiag` is stable under simultaneous permutation of both indices.
  have hoff :
      ∀ i j : V, offDiag c (σ.symm i) (σ.symm j) = offDiag c i j := by
    intro i j
    by_cases hji : j = i
    · subst hji
      simp [offDiag]
    · have hsymm : σ.symm j ≠ σ.symm i := by
        intro hij
        apply hji
        have : σ (σ.symm j) = σ (σ.symm i) := congrArg σ hij
        simpa using this
      have hc : c (σ.symm i) (σ.symm j) = c i j := by
        simpa using (hinv (σ.symm i) (σ.symm j)).symm
      simp [offDiag, hji, hsymm, hc]
  -- Reindex the double sum defining Dirichlet energy.
  have hsum :
      (∑ i : V, ∑ j : V, offDiag c i j * (f (σ i) - f (σ j)) ^ 2)
        =
      (∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2) := by
    -- First reindex the outer sum (i ↦ σ⁻¹ i).
    have houter :
        (∑ i : V, ∑ j : V, offDiag c i j * (f (σ i) - f (σ j)) ^ 2)
          =
        (∑ i : V, ∑ j : V, offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2) := by
      simpa using
        (Fintype.sum_equiv σ
          (fun i : V =>
            ∑ j : V, offDiag c i j * (f (σ i) - f (σ j)) ^ 2)
          (fun i : V =>
            ∑ j : V, offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2)
          (by intro i; simp))
    -- Then reindex the inner sum (j ↦ σ⁻¹ j), for each fixed i.
    have hinner :
        ∀ i : V,
          (∑ j : V, offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2)
            =
          (∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2) := by
      intro i
      simpa using
        (Fintype.sum_equiv σ
          (fun j : V => offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2)
          (fun j : V => offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2)
          (by intro j; simp))
    have hstep :
        (∑ i : V, ∑ j : V, offDiag c i j * (f (σ i) - f (σ j)) ^ 2)
          =
        (∑ i : V, ∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2) := by
      calc
        (∑ i : V, ∑ j : V, offDiag c i j * (f (σ i) - f (σ j)) ^ 2)
            =
          (∑ i : V, ∑ j : V, offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2) := houter
        _ =
          (∑ i : V, ∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2) := by
          refine Fintype.sum_congr
            (fun i : V =>
              ∑ j : V, offDiag c (σ.symm i) j * (f i - f (σ j)) ^ 2)
            (fun i : V =>
              ∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2)
            (by intro i; simpa using hinner i)
    -- Finally use the weight invariance transported to `offDiag`.
    have hstep' :
        (∑ i : V, ∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2)
          =
        (∑ i : V, ∑ j : V, offDiag c i j * (f i - f j) ^ 2) := by
      refine Fintype.sum_congr
        (fun i : V =>
          ∑ j : V, offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2)
        (fun i : V => ∑ j : V, offDiag c i j * (f i - f j) ^ 2)
        (by
          intro i
          refine Fintype.sum_congr
            (fun j : V => offDiag c (σ.symm i) (σ.symm j) * (f i - f j) ^ 2)
            (fun j : V => offDiag c i j * (f i - f j) ^ 2)
            (by intro j; simp [hoff i j]))
    exact hstep.trans hstep'
  -- Close the original goal by unfolding Dirichlet energy and rewriting via `hsum`.
  simp [PillarA.LayerA.dirichletEnergy, pull, hsum]


/-- Gate: Laplacian quadratic form is invariant under a symmetry of the weight. -/
theorem gate_LAPLACIAN_QUAD_invariant_under_perm
    (σ : Equiv.Perm V) (c : Weight V) (f : V → ℝ)
    (hinv : WeightInvariant σ c) :
    laplacianQuadForm c (pull σ f) = laplacianQuadForm c f := by
  classical
  -- `offDiag` is invariant under simultaneous permutation of both indices.
  have hoff : ∀ i j : V, offDiag c (σ i) (σ j) = offDiag c i j := by
    intro i j
    by_cases h : j = i
    · subst h
      simp [PillarA.LayerA.offDiag]
    · have hσ : σ j ≠ σ i := by
        intro hij
        apply h
        exact σ.injective hij
      -- Off diagonal, `offDiag` reduces to `c`, and `hinv` provides the invariance.
      simp [PillarA.LayerA.offDiag, h, hσ, hinv i j]

  -- Degrees are invariant since they are row-sums of `offDiag`.
  have hdeg : ∀ i : V, degree c (σ i) = degree c i := by
    intro i
    -- Unfold and reindex the sum using the permutation.
    have hreindex :
        (∑ j : V, offDiag c (σ i) j) = (∑ j : V, offDiag c (σ i) (σ j)) := by
      simpa using
        (Fintype.sum_equiv σ.symm
          (fun j : V => offDiag c (σ i) j)
          (fun j : V => offDiag c (σ i) (σ j))
          (by intro j; simp))
    have hcongr :
        (∑ j : V, offDiag c (σ i) (σ j)) = (∑ j : V, offDiag c i j) := by
      refine Fintype.sum_congr
        (fun j : V => offDiag c (σ i) (σ j))
        (fun j : V => offDiag c i j)
        (by intro j; simpa using (hoff i j))
    calc
      degree c (σ i) = (∑ j : V, offDiag c (σ i) j) := by
        simpa using (PillarA.LayerA.degree_eq_sum_offDiag (c := c) (i := σ i))
      _ = (∑ j : V, offDiag c (σ i) (σ j)) := hreindex
      _ = (∑ j : V, offDiag c i j) := hcongr
      _ = degree c i := by
        simpa using (PillarA.LayerA.degree_eq_sum_offDiag (c := c) (i := i)).symm

  -- Laplacian entries are invariant under simultaneous permutation.
  have hlap : ∀ i j : V, laplacian c (σ i) (σ j) = laplacian c i j := by
    intro i j
    by_cases h : j = i
    · subst h
      simp [PillarA.LayerA.laplacian, hdeg]
    · have hij : i ≠ j := by
        simpa [eq_comm] using h
      have hc : c (σ i) (σ j) = c i j := by
        simpa using hinv i j
      simp [PillarA.LayerA.laplacian, hij, hc]

  -- Expand the quadratic form and reindex both sums.
  unfold laplacianQuadForm
  -- `quadForm` is defined as `∑ i, x i * (∑ j, W i j * x j)`.
  simp [pull, PillarA.LayerA.quadForm]
  -- Outer reindex (i ↦ σ⁻¹ i).
  have houter :
      (∑ i : V, f (σ i) * (∑ j : V, laplacian c i j * f (σ j)))
        =
      (∑ i : V, f i * (∑ j : V, laplacian c (σ.symm i) j * f (σ j))) := by
    simpa using
      (Fintype.sum_equiv σ
        (fun i : V => f (σ i) * (∑ j : V, laplacian c i j * f (σ j)))
        (fun i : V => f i * (∑ j : V, laplacian c (σ.symm i) j * f (σ j)))
        (by intro i; simp))

  -- Inner reindex (j ↦ σ⁻¹ j) for each fixed `i`.
  have hinner :
      ∀ i : V,
        (∑ j : V, laplacian c (σ.symm i) j * f (σ j))
          =
        (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j) := by
    intro i
    simpa using
      (Fintype.sum_equiv σ
        (fun j : V => laplacian c (σ.symm i) j * f (σ j))
        (fun j : V => laplacian c (σ.symm i) (σ.symm j) * f j)
        (by intro j; simp))

  have hstep :
      (∑ i : V, f i * (∑ j : V, laplacian c (σ.symm i) j * f (σ j)))
        =
      (∑ i : V, f i * (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j)) := by
    refine Fintype.sum_congr
      (fun i : V => f i * (∑ j : V, laplacian c (σ.symm i) j * f (σ j)))
      (fun i : V => f i * (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j))
      (by intro i; simp [hinner i])

  have hstep' :
      (∑ i : V, f i * (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j))
        =
      (∑ i : V, f i * (∑ j : V, laplacian c i j * f j)) := by
    refine Fintype.sum_congr
      (fun i : V => f i * (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j))
      (fun i : V => f i * (∑ j : V, laplacian c i j * f j))
      (by
        intro i
        have :
            (∑ j : V, laplacian c (σ.symm i) (σ.symm j) * f j)
              =
            (∑ j : V, laplacian c i j * f j) := by
          refine Fintype.sum_congr
            (fun j : V => laplacian c (σ.symm i) (σ.symm j) * f j)
            (fun j : V => laplacian c i j * f j)
            (by
              intro j
              -- Use entrywise invariance of the Laplacian.
              have hij : laplacian c (σ.symm i) (σ.symm j) = laplacian c i j := by
                simpa using (hlap (σ.symm i) (σ.symm j)).symm
              simp [hij])
        simp [this])

  -- Assemble the chain.
  exact (houter.trans (hstep.trans hstep'))

/-- Gate (Noether-style): symmetry implies commutation of the generator with the representation.

Intended final form (to be proved later):

`permMatrix σ ⬝ laplacian c = laplacian c ⬝ permMatrix σ`

or equivalently a conjugation invariance.
-/
theorem gate_NOETHER_COMMUTE_LAPLACIAN
    (σ : Equiv.Perm V) (c : Weight V)
    (hinv : WeightInvariant σ c) :
    permMatrix σ * (laplacian c) = (laplacian c) * permMatrix σ := by
  classical

  -- `offDiag` is invariant under simultaneous permutation of both indices.
  have hoff : ∀ i j : V, offDiag c (σ i) (σ j) = offDiag c i j := by
    intro i j
    by_cases h : j = i
    · subst h
      simp [PillarA.LayerA.offDiag]
    · have hσ : σ j ≠ σ i := by
        intro hij
        apply h
        exact σ.injective hij
      simp [PillarA.LayerA.offDiag, h, hσ, hinv i j]

  -- Degrees are invariant since they are row-sums of `offDiag`.
  have hdeg : ∀ i : V, degree c (σ i) = degree c i := by
    intro i
    have hreindex :
        (∑ j : V, offDiag c (σ i) j) = (∑ j : V, offDiag c (σ i) (σ j)) := by
      simpa using
        (Fintype.sum_equiv σ.symm
          (fun j : V => offDiag c (σ i) j)
          (fun j : V => offDiag c (σ i) (σ j))
          (by intro j; simp))
    have hcongr :
        (∑ j : V, offDiag c (σ i) (σ j)) = (∑ j : V, offDiag c i j) := by
      refine Fintype.sum_congr
        (fun j : V => offDiag c (σ i) (σ j))
        (fun j : V => offDiag c i j)
        (by intro j; simpa using (hoff i j))
    calc
      degree c (σ i) = (∑ j : V, offDiag c (σ i) j) := by
        simpa using (PillarA.LayerA.degree_eq_sum_offDiag (c := c) (i := σ i))
      _ = (∑ j : V, offDiag c (σ i) (σ j)) := hreindex
      _ = (∑ j : V, offDiag c i j) := hcongr
      _ = degree c i := by
        simpa using (PillarA.LayerA.degree_eq_sum_offDiag (c := c) (i := i)).symm

  -- Laplacian entries are invariant under simultaneous permutation.
  have hlap : ∀ i j : V, laplacian c (σ i) (σ j) = laplacian c i j := by
    intro i j
    by_cases hij : i = j
    · subst hij
      simp [PillarA.LayerA.laplacian, hdeg]
    · have hc : c (σ i) (σ j) = c i j := by
        simpa using hinv i j
      simp [PillarA.LayerA.laplacian, hij, hc]

  -- Show commutation by entrywise calculation: multiplying by `permMatrix σ` permutes rows/cols.
  ext i j

  have hmul_left : (permMatrix σ * laplacian c) i j = laplacian c (σ.symm i) j := by
    have hterm :
        ∀ k : V,
          permMatrix σ i k * laplacian c k j
            = (if k = σ.symm i then laplacian c k j else 0) := by
      intro k
      by_cases hk : k = σ.symm i
      · subst hk
        simp [permMatrix]
      · have hσk : σ k ≠ i := by
          intro hski
          apply hk
          have := congrArg σ.symm hski
          simpa using this
        simp [permMatrix, hk, hσk]
    simp [Matrix.mul_apply, hterm]

  have hmul_right : (laplacian c * permMatrix σ) i j = laplacian c i (σ j) := by
    have hterm :
        ∀ k : V,
          laplacian c i k * permMatrix σ k j
            = (if k = σ j then laplacian c i k else 0) := by
      intro k
      by_cases hk : k = σ j
      · subst hk
        simp [permMatrix]
      · have hsj : σ j ≠ k := by
          simpa [eq_comm] using hk
        simp [permMatrix, hsj, hk]
    simp [Matrix.mul_apply, hterm]

  calc
    (permMatrix σ * laplacian c) i j
        = laplacian c (σ.symm i) j := hmul_left
    _ = laplacian c i (σ j) := by
        simpa using (hlap (σ.symm i) j).symm
    _ = (laplacian c * permMatrix σ) i j := by
        symm
        exact hmul_right

end Finite

end IdealSymmetry

end Ideal
end PillarA
