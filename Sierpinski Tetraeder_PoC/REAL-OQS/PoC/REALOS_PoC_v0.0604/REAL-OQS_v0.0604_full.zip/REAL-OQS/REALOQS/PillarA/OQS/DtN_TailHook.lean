import Mathlib
import REALOQS.PillarA.Core.TailInterface
import REALOQS.PillarA.OQS.DtN

set_option autoImplicit false

namespace PillarA

namespace OQS

/-!
# DtN as a Tail-Elimination hook (Phase 5)

This file provides a **minimal adapter** that exposes the existing DtN/Schur
elimination (`OQS.DtN`) as an instance of the substrate-agnostic core interface
`LayerA.TailEliminationHook`.

Notes:
* This is intentionally lightweight and does not prescribe how the tail is computed.
* The current adapter ignores the `Approximant` and `BoundaryPorts` inputs; later
  phases can refine the interface (e.g. boundary degrees of freedom tied to regions).
-/

open scoped BigOperators

open PillarA.LayerA

section

variable {V : Type} [Fintype V]

-- Tail data needed to compute a DtN boundary operator:
-- * a split `V ≃ B ⊕ I`,
-- * a full operator `L : Matrix V V ℝ`,
-- * an inverse witness for the interior block `LII`.
-- This is **not** claimed to exist for arbitrary `L`; it is a carrier for later proofs.
structure DtNTailData where
  -- The `DecidableEq V` instance under which the split/inverse witness were formed.
  -- We store this explicitly to avoid definitional-equality problems coming from
  -- `OQS.Split V` being parameterized by the instance `DecidableEq V`.
  decV : DecidableEq V
  -- A type-level partition `V ≃ B ⊕ I`.
  --
  -- Note: this is `Split V` *under* the stored `decV` instance.
  --
  split : @OQS.Split V _ decV
  -- Full operator on `V`.
  fullOp : Matrix V V ℝ
  -- Inverse witness for the interior block, formed under the stored `decV`.
  inv : @OQS.Split.InteriorInv V _ decV split fullOp
-- Effective boundary data produced by DtN elimination.
-- We return the boundary operator together with the chosen split.
abbrev DtNBoundaryData : Type _ :=
  Σ decV : DecidableEq V, Σ s : @OQS.Split V _ decV, Matrix s.B s.B ℝ
-- NOTE (typeclass arguments):
--
-- `TailEliminationHook.eliminate` is polymorphic in a per-level instance
-- `[DecidableEq (Cell L)]`. For the constant family `Cell L := V`, this is a
-- `DecidableEq V` argument.
--
-- Here we do not try to override that instance. The tail object `t` and the
-- returned boundary data are both typed using whatever `DecidableEq V` is in
-- scope at the call site, which keeps the implicit instance arguments in
-- `OQS.Split V` definitionally consistent.
--
-- The only thing we need to ensure is that `TailAt` reduces to our concrete tail
-- carrier; we therefore name the `TailInterface` instance.
--
-- Provide a tail type for the constant cell family `Cell L := V`.
instance instTailInterface_const : TailInterface (Cell := fun _ : Nat => V) where
  Tail := fun _ => DtNTailData (V := V)

-- Provide DtN elimination as a `TailEliminationHook`.
instance instTailEliminationHook_const : TailEliminationHook (Cell := fun _ : Nat => V) where
  EffectiveBoundaryData := fun _ => DtNBoundaryData (V := V)
  eliminate := by
    intro L
    intro _dec
    intro A t bp
    -- currently ignore `A` and `bp`; they will matter once boundary ports are linked to splits
    cases t with
    | mk decV split fullOp inv =>
        -- Work under the instance carried by the tail object.
        letI : DecidableEq V := decV
        refine ⟨decV, ⟨split, ?_⟩⟩
        simpa using (OQS.Split.DtN_of (s := split) fullOp inv)

end

end OQS

end PillarA
