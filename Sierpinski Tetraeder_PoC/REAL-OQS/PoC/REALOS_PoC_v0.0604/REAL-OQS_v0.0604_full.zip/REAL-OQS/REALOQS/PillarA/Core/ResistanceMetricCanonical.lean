import Mathlib
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Core.Gates

set_option linter.style.longLine false


set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Canonical grounded resistance (contracts + gates)
-- v0.11b (2026-01-24)

This module closes the Pillar-A gap where the resistance metric existed only
as a signature/interface.

We expose a *canonical* finite-approximant recipe (vNext.3-canonical):
- choose a deterministic ground node `g`,
- form a grounded minor of the Laplacian `L`,
- symmetrize,
- add deterministic SPD-jitter `δ(A) := ε * max(1, ||A||_F)` (Policy-driven),
- solve `(S + δ I) x = b` for `b = e_u - e_v` (reduced),
- set `R(u,v) := bᵀx` if the solve succeeds, else `R(u,v)=∞`.

Pillar A does **not** attempt analysis proofs; it packages the construction as
*data + explicit gate propositions* to be discharged later (downstream/Lean).
-/

namespace PillarA
namespace LayerA

open scoped BigOperators

noncomputable section

namespace CanonicalResistance

section

variable {b n : Nat}

abbrev V := Fin (Nat.succ n)
abbrev I := Fin n

/-- Deterministic ground choice for `Fin (succ n)` in Pillar A.

Note: for `Fin`, both `minId` and `minLex` collapse to `0`. If later we model
nontrivial id/lex orderings, this definition can be refined without changing the
rest of the interface.
-/
def ground (_p : Policy b) : V (n := n) := 0

/-- Index embedding excluding the ground index (uses `succAbove`). -/
def embedExcl (g : V (n := n)) : I (n := n) → V (n := n) := Fin.succAbove g

/-- Grounded minor by removing row/col `g`. -/
def groundedMinor
    (g : V (n := n))
    (L : Matrix (V (n := n)) (V (n := n)) ℝ) :
    Matrix (I (n := n)) (I (n := n)) ℝ := L.submatrix (embedExcl (n := n) g) (embedExcl (n := n) g)

/-- Symmetrization `S := (A + Aᵀ)/2`. -/
def symm (A : Matrix (I (n := n)) (I (n := n)) ℝ) : Matrix (I (n := n)) (I (n := n)) ℝ :=
  ((1 / 2 : ℝ) • (A + A.transpose))

/-- Stabilization `A ↦ A + δ I` with scalar `δ`. -/
def stabilized (A : Matrix (I (n := n)) (I (n := n)) ℝ) (δ : ℝ) : Matrix (I (n := n)) (I (n := n)) ℝ := A + δ • (1 : Matrix (I (n := n)) (I (n := n)) ℝ)

/-- Reduced RHS `b = e_u - e_v`, expressed on the grounded index set. -/
def rhs (g : V (n := n)) (u v : V (n := n)) : (I (n := n) → ℝ) := fun i =>
    let j := embedExcl (n := n) g i
    (if j = u then 1 else 0) - (if j = v then 1 else 0)

/-- Dot product `bᵀx = ∑ᵢ bᵢ xᵢ`. -/
def dot (b x : I (n := n) → ℝ) : ℝ := ∑ i, b i * x i

/-- Componentwise solve relation `A x = b`. -/
def solves (A : Matrix (I (n := n)) (I (n := n)) ℝ) (b x : I (n := n) → ℝ) : Prop := ∀ i, (∑ j, A i j * x j) = b i

/-- Deterministic SPD jitter `δ(A) = ε * max(1, ||A||_F)`.

`ε` is taken from the policy (`Policy.eps`).
-/
def delta (p : Policy b) (A : Matrix (I (n := n)) (I (n := n)) ℝ) : ℝ := MatrixNorm.deltaSPD (ι := I (n := n)) (Policy.eps p) A

/-- Canonical stabilized system matrix from `(policy, L, ground)`. -/
def systemMatrix
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n)) :
    Matrix (I (n := n)) (I (n := n)) ℝ := let S := symm (n := n) (groundedMinor (n := n) g L)
  stabilized (n := n) S (delta (n := n) p S)

/-! ### Gate propositions for the canonical solve -/

/-- Gate: stabilized matrix is (two-sided) invertible.

This is stronger than pairwise solvability and is useful for later AQFT lifts.
-/
def gate_STABILIZED_INVERTIBLE
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n)) : Prop := ∃ Ainv : Matrix (I (n := n)) (I (n := n)) ℝ,
    TwoSidedInv (systemMatrix (n := n) p L g) Ainv

/-- Gate: if the solver succeeds for `(u,v)`, then there exists a witness `x` and
    `R(u,v) = ofReal(bᵀx)` for the canonical system matrix. -/
def gate_RESISTANCE_SOLVE_WITNESS
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n))
    (success : V (n := n) → V (n := n) → Prop)
    (rm : ResistanceMetric (V (n := n))) : Prop := ∀ u v, u ≠ v → success u v →
    ∃ x : I (n := n) → ℝ,
      solves (n := n) (A := systemMatrix (n := n) p L g) (b := rhs (n := n) g u v) x
      ∧ rm.R u v = ENNReal.ofReal (dot (n := n) (rhs (n := n) g u v) x)

/-- Gate: disconnection / solver failure gives `∞`. -/
def gate_RESISTANCE_FAIL_TOP
    (success : V (n := n) → V (n := n) → Prop)
    (rm : ResistanceMetric (V (n := n))) : Prop := ∀ u v, u ≠ v → ¬ success u v → rm.R u v = ⊤

/-- Gate: symmetry of `success` (expected for undirected graphs). -/
def gate_SUCCESS_SYMM (success : V (n := n) → V (n := n) → Prop) : Prop := ∀ u v, success u v ↔ success v u

/-!
## Minimal assumptions axis for resistance well-posedness (contract)

Pillar A cannot (and should not) attempt the full spectral/M-matrix theory needed to prove
invertibility of grounded Laplacians. However, for the **Pillar A → Layer B / Pillar B**
interfaces we must record *which hypotheses are intended* to justify well-posedness.

We therefore expose a non-vacuous contract encoding the intended axis:

* symmetric, nonnegative conductances (`c`) and
* (graph) connectivity

⇒ stabilized grounded system is invertible
⇒ the resistance solve succeeds for all `u≠v` (hence resistances are finite).

Layer B supplies the concrete graph connectivity predicate and discharges the obligations.
-/

structure ResistanceWellposedAxis where
  policy : Policy b
  c : PillarA.LayerA.Weight (V (n := n))
  c_symm : ∀ i j, c i j = c j i
  c_nonneg : ∀ i j, 0 ≤ c i j
  /-- Connectivity predicate (left abstract at Pillar-A level). -/
  Connected : Prop
  /-- Solver-success predicate to be used in `CanonicalResistanceSpec`. -/
  success : V (n := n) → V (n := n) → Prop
  /-- Axis step 1: connectivity implies stabilized invertibility
      (grounded, symmetrized, jittered). -/
  invertible_of_connected :
    Connected → gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy (PillarA.LayerA.laplacian c)
      (ground (b := b) (n := n) policy)
  /-- Axis step 2: connectivity implies pairwise solver success (for `u≠v`). -/
  success_of_connected :
    Connected → ∀ u v, u ≠ v → success u v

namespace ResistanceWellposedAxis

variable (A : ResistanceWellposedAxis (b := b) (n := n))

/-- Canonical symmetrized/nonnegative closure of an arbitrary conductance weight.

This is a **Pillar-A convenience**: it allows us to build a nontrivial
`ResistanceWellposedAxis` without assuming symmetry/nonnegativity of the input.
Later layers may prefer to take `c` itself together with hypotheses.
-/
def canonWeight (c : PillarA.LayerA.Weight (V (n := n))) :
    PillarA.LayerA.Weight (V (n := n)) :=
  fun i j => max (max (c i j) 0) (max (c j i) 0)

theorem canonWeight_symm (c : PillarA.LayerA.Weight (V (n := n))) :
    (∀ i j, canonWeight (n := n) c i j = canonWeight (n := n) c j i) := by
  intro i j
  simp [canonWeight, max_comm]

theorem canonWeight_nonneg (c : PillarA.LayerA.Weight (V (n := n))) :
    (∀ i j, 0 ≤ canonWeight (n := n) c i j) := by
  intro i j
  have h₁ : (0 : ℝ) ≤ max (c i j) 0 := by exact le_max_right _ _
  exact le_trans h₁ (le_max_left _ _)

/-- A fully-specified axis constructor (no hidden `deferred proof`).

This is the preferred constructor once later layers provide a concrete
connectivity notion and solver success predicate.
-/
def mkOf
    (policy : Policy b)
    (c : PillarA.LayerA.Weight (V (n := n)))
    (c_symm : ∀ i j, c i j = c j i)
    (c_nonneg : ∀ i j, 0 ≤ c i j)
    (Connected : Prop)
    (success : V (n := n) → V (n := n) → Prop)
    (invertible_of_connected :
      Connected → gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy (PillarA.LayerA.laplacian c)
        (ground (b := b) (n := n) policy))
    (success_of_connected : Connected → ∀ u v, u ≠ v → success u v) :
    ResistanceWellposedAxis (b := b) (n := n) :=
  { policy := policy
    c := c
    c_symm := c_symm
    c_nonneg := c_nonneg
    Connected := Connected
    success := success
    invertible_of_connected := invertible_of_connected
    success_of_connected := success_of_connected }

/-- Pillar-A constructor that yields a **non-vacuous** axis without assuming
anything about the input weight.

`Connected` is defined to be the stabilized invertibility gate itself, and
`success u v` is defined as the existence of a solution to the canonical system
for RHS `e_u - e_v`. From the gate witness (a two-sided inverse), solvability
follows by explicitly taking `x := Ainv.mulVec b`.

This keeps the axis logically strong (it does not assert false connectivity),
and it avoids embedding analytic graph theory into Pillar A.
-/
def mkNonvacuous
    (policy : Policy b)
    (c_in : PillarA.LayerA.Weight (V (n := n))) :
    ResistanceWellposedAxis (b := b) (n := n) := by
  classical
  let c : PillarA.LayerA.Weight (V (n := n)) := canonWeight (n := n) c_in
  let g : V (n := n) := ground (b := b) (n := n) policy
  let L : Matrix (V (n := n)) (V (n := n)) ℝ := PillarA.LayerA.laplacian c
  let A : Matrix (I (n := n)) (I (n := n)) ℝ := systemMatrix (b := b) (n := n) policy L g
  refine
    { policy := policy
      c := c
      c_symm := canonWeight_symm (n := n) c_in
      c_nonneg := canonWeight_nonneg (n := n) c_in
      Connected := gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy L g
      success := fun u v => ∃ x : I (n := n) → ℝ,
        solves (n := n) (A := A) (b := rhs (n := n) g u v) x
      invertible_of_connected := by
        intro h; exact h
      success_of_connected := by
        intro hConn u v _huv
        rcases hConn with ⟨Ainv, hInv⟩
        refine ⟨Ainv.mulVec (rhs (n := n) g u v), ?_⟩
        -- show `A * (Ainv * b) = b` using the two-sided inverse gate
        intro i
        have hAA : A * Ainv = (1 : Matrix (I (n := n)) (I (n := n)) ℝ) := by
          simpa [A] using hInv.2
        have hmul : A.mulVec (Ainv.mulVec (rhs (n := n) g u v)) = rhs (n := n) g u v := by
          calc
            A.mulVec (Ainv.mulVec (rhs (n := n) g u v))
                = (A * Ainv).mulVec (rhs (n := n) g u v) := by
                    exact (Matrix.mulVec_mulVec (rhs (n := n) g u v) A Ainv)
            _ = (1 : Matrix (I (n := n)) (I (n := n)) ℝ).mulVec (rhs (n := n) g u v) := by
                    simp [hAA]
            _ = rhs (n := n) g u v := by
                    simp
        -- unfold `solves` (componentwise) and read off the `i`th component of `mulVec`.
        simpa [solves, Matrix.mulVec] using congrArg (fun f => f i) hmul
      }

end ResistanceWellposedAxis

/-!
## Canonical resistance spec (data + gates)

We do **not** define `rm.R` from `L` in Pillar A, because that would require
choosing a solver and proving wellposedness. Instead we package the expected
relationship as gate propositions.
-/

structure CanonicalResistanceSpec where
  policy : Policy b
  L : Matrix (V (n := n)) (V (n := n)) ℝ
  g : V (n := n)
  g_def : g = ground (b := b) (n := n) policy
  success : V (n := n) → V (n := n) → Prop
  rm : ResistanceMetric (V (n := n))
  invertible : gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy L g
  solve_witness : gate_RESISTANCE_SOLVE_WITNESS (b := b) (n := n) policy L g success rm
  fail_top : gate_RESISTANCE_FAIL_TOP (n := n) success rm
  success_symm : gate_SUCCESS_SYMM (n := n) success
  laws : ResistanceMetricLaws rm

namespace CanonicalResistanceSpec

variable (S : CanonicalResistanceSpec (b := b) (n := n))

/-- The canonical jitter computed from the spec's policy and grounded/symmetrized minor. -/
def δ : ℝ := let A := symm (n := n) (groundedMinor (n := n) S.g S.L)
  delta (n := n) S.policy A

/-- Convenience: induced distance `d(u,v) = sqrt(R(u,v))`. -/
def dist : V (n := n) → V (n := n) → ENNReal := LayerA.dist S.rm

/-- Gate-derived: if `success u v` holds (and `u≠v`), then the resistance is finite. -/
theorem gate_success_finite {u v : V (n := n)}
    (huv : u ≠ v) (hs : S.success u v) :
    S.rm.R u v ≠ (⊤ : ENNReal) := by
  obtain ⟨x, _hxSol, hR⟩ := S.solve_witness u v huv hs
  -- `ENNReal.ofReal _` is never `⊤`.
  simp [hR]

/-- Deterministic positivity of the jitter `δ` (uses policy's `ε>0`). -/
theorem gate_delta_pos : (0 : ℝ) < S.δ := by
  have hε : (0 : ℝ) < Policy.eps S.policy := Policy.eps_pos (b := b) S.policy
  dsimp [CanonicalResistanceSpec.δ, delta]
  exact
    MatrixNorm.deltaSPD_pos (ι := I (n := n)) (ε := Policy.eps S.policy) hε
      (symm (n := n) (groundedMinor (n := n) S.g S.L))

end CanonicalResistanceSpec

end  -- section

end CanonicalResistance

end  -- noncomputable section

end LayerA
end PillarA
