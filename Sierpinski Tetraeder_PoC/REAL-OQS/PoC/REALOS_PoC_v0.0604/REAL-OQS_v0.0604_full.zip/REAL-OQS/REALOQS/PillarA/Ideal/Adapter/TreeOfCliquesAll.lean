/-
IDEAL adapter re-export: Tree-of-Cliques substrate.

Import policy note:
Outside of `REALOQS.PillarA.Ideal.*`, IDEAL-specific modules must be imported
via `REALOQS.PillarA.Ideal.Adapter.*` wrappers.
-/

import REALOQS.PillarA.Ideal.TreeOfCliques.All
