import Mathlib


set_option autoImplicit false

/-!
REALOQS / Pillar A / RG scaffold: scale windows and error budgets

Purpose (Pillar A):
- Make "scale windows" first-class objects: a finite index interval [kmin,kmax].
- Attach an error budget function ε(k) that later layers can use to express
  approximate symmetries / quasi-isometries / effective laws on a window.

Notes:
- This is an interface module. Theorems may remain `deferred proof` so downstream can accept them.
- We use the index type `Nat` on purpose; later layers can refine this to physical scales.
- The error budget codomain is `ENNReal` (extended nonnegative reals)
  to support "infinite" error when needed.
-/

namespace PillarA

namespace RG

/-- A finite scale window [kmin,kmax] equipped with an error budget ε(k). -/
structure ScaleWindow where
  kmin : Nat
  kmax : Nat
  hk : kmin ≤ kmax
  eps : Nat → ENNReal

namespace ScaleWindow

/-- Membership predicate for a scale index in the window. -/
def In (W : ScaleWindow) (k : Nat) : Prop := W.kmin ≤ k ∧ k ≤ W.kmax

/-- Successor-pair membership: both `k` and `k+1` lie inside the window. -/
def inSucc (W : ScaleWindow) (k : Nat) : Prop := W.In k ∧ W.In (k + 1)

@[simp] theorem inSucc_iff (W : ScaleWindow) (k : Nat) :
    W.inSucc k ↔ (W.In k ∧ W.In (k + 1)) := Iff.rfl

@[simp] theorem in_iff (W : ScaleWindow) (k : Nat) : W.In k ↔ W.kmin ≤ k ∧ k ≤ W.kmax := by
  rfl

/-- The lower endpoint is always inside the window. -/
theorem kmin_in (W : ScaleWindow) : W.In W.kmin := by
  exact ⟨le_rfl, W.hk⟩

/-- The upper endpoint is always inside the window. -/
theorem kmax_in (W : ScaleWindow) : W.In W.kmax := by
  exact ⟨W.hk, le_rfl⟩

/-- Length (number of steps) of the window. -/
def length (W : ScaleWindow) : Nat := W.kmax - W.kmin

/-- Error budget at scale `k` (semantic meaning is supplied by later layers). -/
def epsAt (W : ScaleWindow) (k : Nat) : ENNReal := W.eps k

/-- Supremum error over indices inside the window (as a canonical bound witness). -/
noncomputable def epsSup (W : ScaleWindow) : ENNReal := ⨆ k : {k // W.In k}, W.eps k

/-- Any in-window error is bounded by `epsSup`. -/
theorem eps_le_epsSup (W : ScaleWindow) (k : Nat) (hk : W.In k) :
    W.eps k ≤ W.epsSup := by
  -- Standard lattice fact (`le_iSup`); kept as an downstream target.
  -- By definition of `epsSup`, we know that for any `k` in the window, `W.eps k ≤ W.epsSup`.
  have h_eps_le_epsSup : ∀ (k : Nat), W.In k → W.eps k ≤ W.epsSup := by
    exact fun k hk => le_iSup_of_le ⟨ k, hk ⟩ le_rfl;
  exact h_eps_le_epsSup k hk

/-- Build a sub-window [kmin',kmax'] contained in W (eps is inherited). -/
def sub (W : ScaleWindow)
    (kmin' kmax' : Nat)
    (_hmin : W.kmin ≤ kmin')
    (_hmax : kmax' ≤ W.kmax)
    (h : kmin' ≤ kmax') : ScaleWindow := { kmin := kmin', kmax := kmax', hk := h, eps := W.eps }

/-- Any index in the sub-window is also in the original window. -/
theorem in_of_in_sub
    (W : ScaleWindow)
    (kmin' kmax' : Nat)
    (hmin : W.kmin ≤ kmin')
    (hmax : kmax' ≤ W.kmax)
    (h : kmin' ≤ kmax')
    (k : Nat) :
    (sub W kmin' kmax' hmin hmax h).In k → W.In k := by
  intro hk
  refine ⟨le_trans hmin hk.1, le_trans hk.2 hmax⟩


/-- Relax the error budget on the same index interval by taking pointwise `max` with `M`. -/
def relax (W : ScaleWindow) (M : ENNReal) : ScaleWindow :=
  { kmin := W.kmin,
    kmax := W.kmax,
    hk := W.hk,
    eps := fun k => max (W.eps k) M }

/-- `relax` makes the window budget at least `M` (hence also its `epsSup`). -/
theorem epsSup_relax_ge (W : ScaleWindow) (M : ENNReal) :
    M ≤ (relax W M).epsSup := by
  have hk : (relax W M).In W.kmin := by
    simpa [relax, In] using (relax W M).kmin_in
  have hMk : M ≤ (relax W M).eps W.kmin := by
    simp [relax]
  have hle : (relax W M).eps W.kmin ≤ (relax W M).epsSup :=
    (relax W M).eps_le_epsSup W.kmin hk
  exact le_trans hMk hle

/-!
### Contracts for later RG / ApproxSymmetry layers

We keep these as `Prop`-level hooks; later modules can:
- assume them,
- prove them for concrete RG constructions,
- transport them along refinements/coarse-grainings.
-/

/-- Placeholder contract: ε(k) is nonincreasing with the index (coarser ⇒ less error). -/
def EpsMonotone (W : ScaleWindow) : Prop := ∀ {i j : Nat}, i ≤ j → W.eps j ≤ W.eps i

/-- Placeholder contract: ε is bounded on the window. -/
def EpsBounded (W : ScaleWindow) : Prop := ∃ M : ENNReal, ∀ k, W.In k → W.eps k ≤ M

/-- `epsSup` yields a canonical boundedness witness. -/
theorem epsBounded_of_epsSup (W : ScaleWindow) : W.EpsBounded := by
  refine ⟨W.epsSup, ?_⟩
  intro k hk
  exact W.eps_le_epsSup k hk

end ScaleWindow

end RG

end PillarA
