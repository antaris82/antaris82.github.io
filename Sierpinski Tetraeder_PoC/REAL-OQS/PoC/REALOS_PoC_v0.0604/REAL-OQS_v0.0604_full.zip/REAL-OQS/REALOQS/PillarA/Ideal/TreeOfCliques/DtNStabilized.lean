/-
Tree-of-Cliques DtN (stabilized): umbrella module.

This file intentionally contains **no definitions**.
It re-exports:

* `DtNStabilizedDefs`  : the gated stabilized DtN construction (`..._of_det`)
* `DtNStabilizedGate`  : discharge of the determinant gate for all scales + parameter-free wrapper
-/

import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilizedDefs
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilizedGate
