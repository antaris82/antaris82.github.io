import Mathlib
import Mathlib.Data.Matrix.Mul
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalD
import REALOQS.PillarA.Physics.ScaleBreakingFaithfulnessD
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.PillarA.Update.TailEliminationDtN

set_option linter.style.longLine false
set_option autoImplicit false

/-!
# Phase 4 closure: LawsD for the canonical Tree-of-Cliques dependent axis

This file provides a **fully proved** `ScaleBreakingAxisD.LawsD` instance for the
canonical ToC dependent axis

`PillarA.Physics.Instances.TreeOfCliques.ToC.axis_canonicalD`.

Key idea (Phase 4): for the chosen mismatch functional `NormDiff.mkId`, the
normalization trace functional is constant (`T := fun _ => 1`). Hence
`normalizeTrace` reduces to a *fixed nonzero scalar rescaling*, and faithfulness
can be proved without additional gates.

The proofs here are purely algebraic and rely only on:
- `matrixOfLinOp` for the delta-basis,
- Frobenius-square positivity (`MatrixNorm.frobSq_pos_of_ne_zero`),
- the fact that `Obs` observes matrices via `linOpOfMatrix`.
-/

namespace PillarA
namespace Physics
namespace Instances
namespace TreeOfCliques

noncomputable section

open _root_.PillarA
open _root_.PillarA.Update
open _root_.PillarA.Physics

namespace ToC

open _root_.PillarA.Update.MismatchFunctional
open _root_.PillarA.Update.MismatchFunctional.NormDiff

variable {b : Nat}

/-! ## Matrix/observer lemmas for the delta-basis representation -/

namespace NormDiffLemmas

variable {α : Type}

/-!
We avoid referring to `Matrix.dotProduct` explicitly. Instead we unfold `Matrix.mulVec`
via the root constant `dotProduct` and use the project-local `delta`.
-/

section WithFintype

variable [Fintype α] [DecidableEq α]

/-- Multiplying by the delta basis vector picks out the corresponding column entry. -/
lemma mulVec_delta (M : Matrix α α ℝ) (i j : α) :
    (M.mulVec (delta (α := α) j)) i = M i j := by
  classical
  simp [Matrix.mulVec, dotProduct, delta, mul_ite]

/-- `matrixOfLinOp` recovers a matrix from the `mulVec` operator (`linOpOfMatrix`). -/
@[simp] theorem matrixOfLinOp_linOpOfMatrix (M : Matrix α α ℝ) :
    matrixOfLinOp (α := α) (_root_.PillarA.Update.linOpOfMatrix (α := α) M) = M := by
  classical
  ext i j
  simpa [matrixOfLinOp, _root_.PillarA.Update.linOpOfMatrix] using
    (mulVec_delta (α := α) (M := M) (i := i) (j := j))

/-- `linOpOfMatrix` is injective because `matrixOfLinOp` is a left inverse. -/
theorem linOpOfMatrix_injective :
    Function.Injective (_root_.PillarA.Update.linOpOfMatrix (α := α)) := by
  intro M N h
  have hm := congrArg (matrixOfLinOp (α := α)) h
  simpa [matrixOfLinOp_linOpOfMatrix] using hm

end WithFintype

section WithDecEq

variable [DecidableEq α]

/-- Scalar multiplication commutes with `matrixOfLinOp`. -/
@[simp] theorem matrixOfLinOp_smul (r : ℝ) (A : LinOp (α := α)) :
    matrixOfLinOp (α := α) (r • A) = r • matrixOfLinOp (α := α) A := by
  classical
  ext i j
  simp [matrixOfLinOp]


end WithDecEq

/-- `projectOp` with the identity projector is definitional identity. -/
@[simp] theorem projectOp_idProjector (A : LinOp (α := α)) :
    projectOp (idProjector (α := α)) A = A := by
  ext f x
  rfl

/-! ### Normalization lemmas

These are used to turn equalities of normalized operators into equalities of
their unnormalized observables. For `NormDiff.mkId` the trace functional is
constant `1`, hence the normalization is a fixed rescaling by `(max eps 1)⁻¹`.
-/

/-- Normalization with a constant trace functional (`fun _ => 1`) is fixed rescaling. -/
theorem normalizeTrace_const_one
    (P : NullModeProjector α) (eps : ℝ) (eps_pos : 0 < eps)
    (A : NormalizedOp (α := α)) :
    normalizeTrace (α := α) P (fun _ => (1:ℝ)) eps eps_pos A =
      (max eps (1:ℝ))⁻¹ • A := by
  simp [normalizeTrace, one_div, abs_one]

/-! `mkId` packages a nontrivial mismatch and is defined only under
`[Fintype α] [DecidableEq α]`. We keep these assumptions explicit here. -/

/-- Specialized normalization for `NormDiff.mkId`. -/
@[simp] theorem normalizeTrace_mkId
    (eps : ℝ) (eps_pos : 0 < eps) (A : NormalizedOp (α := α))
    [Fintype α] [DecidableEq α] :
    normalizeTrace (α := α) (mkId (α := α)).P (mkId (α := α)).T eps eps_pos A =
      (max eps (1:ℝ))⁻¹ • A := by
  simp [MismatchFunctional.NormDiff.mkId, MismatchFunctional.NormDiff.mk,
    normalizeTrace, one_div, abs_one]

/-- The fixed normalization scale factor is nonzero. -/
theorem normalizeTrace_const_one_scale_ne_zero (eps : ℝ) :
    (max eps (1:ℝ))⁻¹ ≠ (0:ℝ) := by
  have hpos : 0 < max eps (1:ℝ) := by
    have : (0:ℝ) < (1:ℝ) := by norm_num
    exact lt_of_lt_of_le this (le_max_right _ _)
  exact inv_ne_zero (ne_of_gt hpos)

/-- Cancel a nonzero scalar on matrices (over `ℝ`). -/
theorem smul_cancel_matrix {r : ℝ} (hr : r ≠ 0) {M N : Matrix α α ℝ} :
    r • M = r • N → M = N := by
  intro h
  ext i j
  have hij : (r • M) i j = (r • N) i j :=
    congrArg (fun X : Matrix α α ℝ => X i j) h
  have hij' : r * M i j = r * N i j := by
    simpa using hij
  have hcases : r = 0 ∨ M i j = N i j := by
    have : M i j = N i j ∨ r = 0 := (mul_eq_mul_left_iff).1 hij'
    simpa [or_comm] using this
  cases hcases with
  | inl h0 => exact False.elim (hr h0)
  | inr hEq => exact hEq

/-- Cancel a nonzero scalar on `LinOp` (pointwise scalar multiplication). -/
theorem smul_cancel_linOp {r : ℝ} (hr : r ≠ 0) {A B : LinOp (α := α)} :
    r • A = r • B → A = B := by
  intro h
  ext f x
  have hx : ((r • A).apply f) x = ((r • B).apply f) x :=
    congrArg (fun T : LinOp (α := α) => (T.apply f) x) h
  have hx' : r * (A.apply f x) = r * (B.apply f x) := by
    simpa using hx
  have hcases : r = 0 ∨ A.apply f x = B.apply f x := by
    have : A.apply f x = B.apply f x ∨ r = 0 := (mul_eq_mul_left_iff).1 hx'
    simpa [or_comm] using this
  cases hcases with
  | inl h0 => exact False.elim (hr h0)
  | inr hEq => exact hEq

end NormDiffLemmas



/-! ## FaithfulnessD and LawsD for the canonical axis -/

open NormDiffLemmas

/-- Fully proved faithfulness contract for the canonical ToC qualitative axis (`axis0`). -/
noncomputable def faithfulness_axis0
    (p : _root_.PillarA.LayerA.Policy b)
    (eps : ℝ) (eps_pos : eps > 0) :
    _root_.PillarA.Physics.ScaleBreakingFaithfulnessD
      (A := axis0 (b := b) (p := p))
      (Obs := Obs b)
      (M := M b)
      eps := by
  classical
  refine
    { eps_pos := eps_pos
      ideal_observed_eq_of_scaleInvariantD := ?_
      real_normed_observed_neq_of_breaksScaleD := ?_
      mismatch_pos_of_real_normed_observed_neq := ?_ }

  · intro hSI k
    -- `scaleInvariantD` is `coarsen ideal = ideal`; transport through `Obs.op`.
    simpa using congrArg (fun s => (Obs b).op k s) (hSI k).symm

  · intro hBS
    rcases hBS with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    intro hEq

    have hScale : (max eps (1:ℝ))⁻¹ ≠ (0:ℝ) :=
      NormDiffLemmas.normalizeTrace_const_one_scale_ne_zero (eps := eps)

    -- Rewrite `normalizeTrace` (for `mkId`) into a fixed rescaling.
    have hEq' :
        (max eps (1:ℝ))⁻¹ • (Obs b).op k ((axis0 (b := b) (p := p)).real k) =
          (max eps (1:ℝ))⁻¹ •
            (Obs b).op k
              ((axis0 (b := b) (p := p)).coarsen k
                ((axis0 (b := b) (p := p)).real (k + 1))) := by
      -- `M b k = NormDiff.mkId`.
      simpa [ToC.M, NormDiffLemmas.normalizeTrace_mkId] using hEq

    -- Cancel the nonzero scale factor.
    have hObsEq :
        (Obs b).op k ((axis0 (b := b) (p := p)).real k) =
          (Obs b).op k
            ((axis0 (b := b) (p := p)).coarsen k
              ((axis0 (b := b) (p := p)).real (k + 1))) :=
      NormDiffLemmas.smul_cancel_linOp (α := α b k) hScale hEq'

    -- `Obs` is `linOpOfMatrix`, hence injective.
    have hMatEq :
        (axis0 (b := b) (p := p)).real k =
          (axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1)) := by
      have hinj := NormDiffLemmas.linOpOfMatrix_injective (α := α b k)
      have :
          _root_.PillarA.Update.linOpOfMatrix
              (α := α b k)
              ((axis0 (b := b) (p := p)).real k) =
            _root_.PillarA.Update.linOpOfMatrix
              (α := α b k)
              ((axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1))) := by
        simpa [Obs] using hObsEq
      exact hinj this

    -- Contradict the witnessed break `hk : coarsen(real (k+1)) ≠ real k`.
    exact hk hMatEq.symm

  · intro k hNe
    -- Prove mismatch positivity for the REAL tower pair at level `k`.
    let Mk : _root_.PillarA.Update.MismatchFunctional (α := α b k) := M b k
    let op1 : LinOp (α := α b k) := (Obs b).op k ((axis0 (b := b) (p := p)).real k)
    let op2 : LinOp (α := α b k) :=
      (Obs b).op k
        ((axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1)))
    let A1 : NormalizedOp (α := α b k) := normalizeTrace (α := α b k) Mk.P Mk.T eps eps_pos op1
    let A2 : NormalizedOp (α := α b k) := normalizeTrace (α := α b k) Mk.P Mk.T eps eps_pos op2

    have hScale : (max eps (1:ℝ))⁻¹ ≠ (0:ℝ) :=
      NormDiffLemmas.normalizeTrace_const_one_scale_ne_zero (eps := eps)

    -- If the matrix of the (projected) difference were zero, we could derive `A1 = A2`.
    have hMatrix_ne_zero :
        matrixOfLinOp (α := α b k) (projectOp Mk.P (A1 + (-A2))) ≠ 0 := by
      intro h0

      -- For `mkId`, `Mk.P = idProjector`; hence projection is identity.
      have h0' : matrixOfLinOp (α := α b k) (A1 + (-A2)) = 0 := by
        simpa [Mk, ToC.M, NormDiffLemmas.projectOp_idProjector] using h0

      have hMatEq0 :
          matrixOfLinOp (α := α b k) A1 + (- matrixOfLinOp (α := α b k) A2) = 0 := by
        simpa [matrixOfLinOp_add, matrixOfLinOp_neg] using h0'

      have hMatEq : matrixOfLinOp (α := α b k) A1 = matrixOfLinOp (α := α b k) A2 := by
        have := congrArg (fun X => X + matrixOfLinOp (α := α b k) A2) hMatEq0
        -- `(X + -Y) + Y = X + (-Y + Y) = X`.
        simpa [add_assoc] using this

      -- Rewrite the normalized ops as fixed rescalings (mkId).
      have hA1 : A1 = (max eps (1:ℝ))⁻¹ • op1 := by
        simp [A1, Mk, ToC.M, NormDiffLemmas.normalizeTrace_mkId]
      have hA2 : A2 = (max eps (1:ℝ))⁻¹ • op2 := by
        simp [A2, Mk, ToC.M, NormDiffLemmas.normalizeTrace_mkId]

      have hMat1 :
          matrixOfLinOp (α := α b k) A1 = (max eps (1:ℝ))⁻¹ • matrixOfLinOp (α := α b k) op1 := by
        simp [hA1]

      have hMat2 :
          matrixOfLinOp (α := α b k) A2 = (max eps (1:ℝ))⁻¹ • matrixOfLinOp (α := α b k) op2 := by
        simp [hA2]

      -- `op1/op2` are observed matrices via `linOpOfMatrix`.
      have hop1 : matrixOfLinOp (α := α b k) op1 = (axis0 (b := b) (p := p)).real k := by
        simp [op1, Obs, NormDiffLemmas.matrixOfLinOp_linOpOfMatrix]
      have hop2 :
          matrixOfLinOp (α := α b k) op2 =
            (axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1)) := by
        simp [op2, Obs, NormDiffLemmas.matrixOfLinOp_linOpOfMatrix]

      -- Deduce equality of the underlying matrices.
      have hScaledMatEq :
          (max eps (1:ℝ))⁻¹ • (axis0 (b := b) (p := p)).real k =
            (max eps (1:ℝ))⁻¹ •
              (axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1)) := by
        -- rewrite `hMatEq` using `hMat1/hMat2/hop1/hop2`.
        simpa [hMat1, hMat2, hop1, hop2] using hMatEq

      have hUnscaledMatEq :
          (axis0 (b := b) (p := p)).real k =
            (axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1)) :=
        NormDiffLemmas.smul_cancel_matrix (α := α b k) hScale hScaledMatEq

      -- Back to operator equality.
      have hObsEq : op1 = op2 := by
        have h :
            _root_.PillarA.Update.linOpOfMatrix (α := α b k) ((axis0 (b := b) (p := p)).real k) =
              _root_.PillarA.Update.linOpOfMatrix
                (α := α b k)
                ((axis0 (b := b) (p := p)).coarsen k ((axis0 (b := b) (p := p)).real (k + 1))) := by
          simpa using congrArg (_root_.PillarA.Update.linOpOfMatrix (α := α b k)) hUnscaledMatEq
        simpa [op1, op2, Obs] using h

      have : A1 = A2 := by
        -- Use the explicit scaling forms.
        simp [hA1, hA2, hObsEq]
      exact hNe this

    -- Apply the NormDiff positivity lemma (matrix ≠ 0 ⇒ mismatch > 0).
    have hPos : 0 < mismatch (α := α b k) (idProjector (α := α b k)) A1 A2 := by
      exact mismatch_pos_of_matrix_ne_zero (α := α b k)
        (P := idProjector (α := α b k)) (A := A1) (B := A2) (by
          simpa [Mk, ToC.M] using hMatrix_ne_zero)

    -- Convert from `mismatch` to `Mk.mismatch`.
    have hEq :
        Mk.mismatch A1 A2 =
          mismatch (α := α b k) (idProjector (α := α b k)) A1 A2 := by
      simp [Mk, ToC.M, MismatchFunctional.NormDiff.mkId, MismatchFunctional.NormDiff.mk]
    rw [hEq]
    exact hPos


/-- The canonical dependent ToC axis satisfies `ScaleBreakingAxisD.LawsD` (fully proved). -/
noncomputable instance axis_canonicalD_LawsD
    (p : _root_.PillarA.LayerA.Policy b) :
    _root_.PillarA.Physics.ScaleBreakingAxisD.LawsD
      (_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.axis_canonicalD
        (b := b) (p := p)) := by
  classical
  -- Build the laws from mismatch + the proved faithfulness contract.
  simpa [ToC.axis_canonicalD, ToC.axis0, ToC.Obs, ToC.M] using
    (_root_.PillarA.Physics.LawsD_fromMismatch_withFaithfulnessD
      (S := S b) (α := α b)
      (A := axis0 (b := b) (p := p))
      (Obs := Obs b)
      (M := M b)
      (eps := p.eps)
      (F := faithfulness_axis0 (b := b) (p := p) (eps := p.eps) (eps_pos := p.eps_pos)))

end ToC

end

end TreeOfCliques
end Instances
end Physics
end PillarA
