import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Laplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Split
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.OQS.DtNStabilized
import REALOQS.PillarA.OQS.DtNStabilizedCriteria
import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace Adapter

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS
open PillarA.Update

/-!
# Tree-of-Cliques: `TwoStageApprox` carrier with DtN-stabilized interior inverse witness

This carrier is structurally analogous to `TreeOfCliquesApprox`, but the state additionally
stores a *witness* that the **stabilized** interior block is invertible (via `det ≠ 0`).

Phase-8 minimalism originally kept the assembled operator block-diagonal (zero B–I cross blocks),
so that DtN collapsed to `LBB` by computation. Phase 1 removes that shortcut at the
**representation level**: the state now stores explicit cross blocks `LBI`/`LIB`, and the assembled
operator is *not* definitional block-diagonal anymore.

Phase 3 change: stage-1 (`integrateTail`) is now a **genuine stabilized DtN/Kron elimination**.
We compute `DtN_stabilized_of (fullMatrix st)` using the canonical stabilized inverse witness
derived from `st.hdet`, store it in `LBB`, and zero out the cross blocks (`LBI := 0`, `LIB := 0`).
This removes the last identity shortcut: DtN is no longer trivial by construction.
-/

namespace TreeOfCliquesApproxDtNStabilized

variable {b : Nat} (p : Policy b)

abbrev k : Nat := p.L_max
abbrev B : Type := TreeOfCliques.Boundary b (k p)
abbrev I : Type := TreeOfCliques.Interior b (k p)
abbrev V : Type := TreeOfCliques.Vertex b (k p)
abbrev sSplit : PillarA.OQS.Split (V p) := TreeOfCliques.split (b := b) (k := k p)

/-- Canonical operator source: Tree-of-Cliques Laplacian at level `k := p.L_max`. -/
abbrev L0 : Matrix (V p) (V p) ℝ :=
  TreeOfCliques.laplacian (b := b) (k := k p)

/-- Name anchor: the canonical Laplacian operator is admissible. -/
theorem gate_L0_admissible :
    PillarA.LayerA.AdmissibleOp (V := V p) (L0 (p := p)) := by
  classical
  simpa [L0, TreeOfCliques.laplacian] using
    TreeOfCliques.gate_LAPLACIAN_ADMISSIBLE_treeOfCliques (b := b) (k := k p)

/-!
## Phase 2: block extraction from the canonical Laplacian

We expose all four blocks of `L0` via the split `sSplit`. These are mere abbreviations,
meant to serve as stable rewrite anchors.
-/

abbrev LBB0 : Matrix (B p) (B p) ℝ := (sSplit p).blockBB (L0 (p := p))
abbrev LII0 : Matrix (I p) (I p) ℝ := (sSplit p).blockII (L0 (p := p))
abbrev LBI0 : Matrix (B p) (I p) ℝ := (sSplit p).blockBI (L0 (p := p))
abbrev LIB0 : Matrix (I p) (B p) ℝ := (sSplit p).blockIB (L0 (p := p))

@[simp] lemma LBB0_def : LBB0 (p := p) = (sSplit p).blockBB (L0 (p := p)) := rfl
@[simp] lemma LII0_def : LII0 (p := p) = (sSplit p).blockII (L0 (p := p)) := rfl
@[simp] lemma LBI0_def : LBI0 (p := p) = (sSplit p).blockBI (L0 (p := p)) := rfl
@[simp] lemma LIB0_def : LIB0 (p := p) = (sSplit p).blockIB (L0 (p := p)) := rfl

/-!
## Phase 3: canonical stabilization gate for the Laplacian source `L0`

We expose the stabilized interior block and its original gate form
`det(LII_stabilized(L0)) ≠ 0` as rewrite-stable abbreviations.

Strong form: the gate is discharged automatically by `hpsd0_proved`.
-/

/-- Stabilized interior block of the canonical Laplacian source `L0`. -/
abbrev LII_stab0 : Matrix (I p) (I p) ℝ :=
  PillarA.OQS.Split.DtNStabilized.LII_stabilized
    (s := sSplit p) (p := p) (L := L0 (p := p))

/-- Single gate input for derived states: `det(LII_stabilized(L0)) ≠ 0`. -/
abbrev hdet0 : Prop := (LII_stab0 (p := p)).det ≠ 0

/-- Weakened structural gate: the symmetrized interior block is positive semidefinite. -/
abbrev hpsd0 : Prop :=
  (PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))).PosSemidef

/-!
### Strong closure of the Laplacian gate

To eliminate the remaining "external" assumption `hdet0`, we certify the sufficient
condition `hpsd0 : PosSemidef (symm LII0)` for the **derived** Tree-of-Cliques Laplacian.

This uses the already-formalized Dirichlet identity

* `dirichletEnergy c f = quadForm (laplacian c) f`

and the nonnegativity of Dirichlet energy under `c ≥ 0`.
Together this yields nonnegativity of the Laplacian quadratic form, and hence
positive semidefiniteness of the interior block (by testing with boundary-zero extensions).
-/

abbrev c0 : PillarA.LayerA.Weight (V p) :=
  fun x y => TreeOfCliques.conductance (b := b) (k := k p) x y

lemma c0_symm : ∀ i j : V p, c0 (p := p) i j = c0 (p := p) j i := by
  intro i j
  simpa [c0] using (TreeOfCliques.conductance_symm (x := i) (y := j))

lemma c0_nonneg : ∀ i j : V p, 0 ≤ c0 (p := p) i j := by
  intro i j
  simpa [c0] using (TreeOfCliques.conductance_nonneg (x := i) (y := j))

lemma quadForm_L0_nonneg (f : V p → ℝ) :
    0 ≤ PillarA.LayerA.quadForm (L0 (p := p)) f := by
  classical
  -- Rewrite `L0` to the canonical Laplacian `LayerA.laplacian c0`.
  have hEq :
      PillarA.LayerA.dirichletEnergy (c0 (p := p)) f =
        PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c0 (p := p))) f :=
    PillarA.LayerA.gate_DIRICHLET_EQ_LAPLACIAN_QUAD
      (c := c0 (p := p)) (hsymm := c0_symm (p := p)) (f := f)
  have hNon : 0 ≤ PillarA.LayerA.dirichletEnergy (c0 (p := p)) f :=
    PillarA.LayerA.gate_DIRICHLET_NONNEG (c := c0 (p := p)) (hnonneg := c0_nonneg (p := p)) (f := f)
  have : 0 ≤ PillarA.LayerA.quadForm (PillarA.LayerA.laplacian (c0 (p := p))) f := by
    simpa [hEq] using hNon
  simpa [L0, TreeOfCliques.laplacian, c0] using this

lemma symm_LII0_eq (hT : Matrix.transpose (LII0 (p := p)) = LII0 (p := p)) :
    PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p)) = LII0 (p := p) := by
  classical
  -- `symm(A) = (A + Aᵀ)/2`, and `Aᵀ = A`.
  -- Be explicit about the rewrite `A + A = (2:ℝ) • A` (simp won't use `two_smul` backwards).
  calc
    PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))
        = (1 / 2 : ℝ) • ((LII0 (p := p)) + Matrix.transpose (LII0 (p := p))) := rfl
    _ = (1 / 2 : ℝ) • ((LII0 (p := p)) + (LII0 (p := p))) := by
      simp [hT]
    _ = (1 / 2 : ℝ) • ((2 : ℝ) • (LII0 (p := p))) := by
      simp [two_smul]
    _ = ((1 / 2 : ℝ) * 2) • (LII0 (p := p)) := by
      simp [smul_smul]
    _ = LII0 (p := p) := by
      norm_num

lemma quadForm_ext_eq_quadForm_blockII
    (L : Matrix (V p) (V p) ℝ) (x : I p → ℝ) :
    let g : Sum (B p) (I p) → ℝ := fun s =>
      match s with
      | Sum.inl _ => 0
      | Sum.inr i => x i
    let f : V p → ℝ := fun v => g ((sSplit p).e v)
    PillarA.LayerA.quadForm L f = PillarA.LayerA.quadForm ((sSplit p).blockII L) x := by
  classical
  intro g f
  -- Expand `quadForm` into explicit double sums (`mulVec` is definitional).
  change (∑ v : V p, f v * (∑ w : V p, L v w * f w))
      = (∑ i : I p, x i * (∑ j : I p, ((sSplit p).blockII L) i j * x j))

  -- Reindex the outer sum along `e : V ≃ B ⊕ I`.
  have houter :
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w)) := by
    simpa using
      (Fintype.sum_equiv (sSplit p).e
        (fun v : V p => f v * (∑ w : V p, L v w * f w))
        (fun s : Sum (B p) (I p) =>
          f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w))
        (by intro v; simp))

  -- Reindex the inner sum along `e : V ≃ B ⊕ I`.
  have hinner :
      ∀ s : Sum (B p) (I p),
        (∑ w : V p, L ((sSplit p).e.symm s) w * f w)
          =
        (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t)) := by
    intro s
    simpa using
      (Fintype.sum_equiv (sSplit p).e
        (fun w : V p => L ((sSplit p).e.symm s) w * f w)
        (fun t : Sum (B p) (I p) =>
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t))
        (by intro w; simp))

  -- `f (e.symm s) = g s`
  have hf : ∀ s : Sum (B p) (I p), f ((sSplit p).e.symm s) = g s := by
    intro s
    simp [f]

  -- Convert the full LHS into a sum on `B ⊕ I` with matrix entries pulled back by `e.symm`.
  have hLHS :
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t)) := by
    calc
      (∑ v : V p, f v * (∑ w : V p, L v w * f w))
          =
        (∑ s : Sum (B p) (I p),
          f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w)) := houter
      _ =
        (∑ s : Sum (B p) (I p),
          f ((sSplit p).e.symm s) *
            (∑ t : Sum (B p) (I p),
              L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t))) := by
        refine Fintype.sum_congr
          (fun s : Sum (B p) (I p) =>
            f ((sSplit p).e.symm s) * (∑ w : V p, L ((sSplit p).e.symm s) w * f w))
          (fun s : Sum (B p) (I p) =>
            f ((sSplit p).e.symm s) *
              (∑ t : Sum (B p) (I p),
                L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * f ((sSplit p).e.symm t)))
          (by
            intro s
            exact congrArg (fun z => f ((sSplit p).e.symm s) * z) (hinner s))
      _ = _ := by
        -- replace `f (e.symm _)` by `g _`
        simp [hf]

  -- Split the outer sum into boundary and interior parts.
  have hSplitOuter :
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t))
        =
      (∑ b : B p,
        g (Sum.inl b) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inl b)) ((sSplit p).e.symm t) * g t))
      +
      (∑ i : I p,
        g (Sum.inr i) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)) := by
    simp [Fintype.sum_sum_type]

  -- Inner split for a fixed interior index.
  have hInnerI :
      ∀ i : I p,
        (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)
          =
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j) := by
    intro i
    calc
      (∑ t : Sum (B p) (I p),
        L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)
          =
        (∑ b : B p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inl b)) * g (Sum.inl b))
        +
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * g (Sum.inr j)) := by
        simp [Fintype.sum_sum_type]
      _ =
        (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j) := by
        simp [g]

  -- Put everything together.
  calc
    (∑ v : V p, f v * (∑ w : V p, L v w * f w))
        =
      (∑ s : Sum (B p) (I p),
        g s * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm s) ((sSplit p).e.symm t) * g t)) := hLHS
    _ =
      (∑ b : B p,
        g (Sum.inl b) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inl b)) ((sSplit p).e.symm t) * g t))
      +
      (∑ i : I p,
        g (Sum.inr i) * (∑ t : Sum (B p) (I p),
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm t) * g t)) := hSplitOuter
    _ =
      (∑ i : I p,
        x i * (∑ j : I p,
          L ((sSplit p).e.symm (Sum.inr i)) ((sSplit p).e.symm (Sum.inr j)) * x j)) := by
        classical
        -- Boundary outer sum vanishes since `g (inl _) = 0`.
        -- Rewrite the interior inner sum using `hInnerI`.
        simp [g, hInnerI]
    _ =
      (∑ i : I p,
        x i * (∑ j : I p, ((sSplit p).blockII L) i j * x j)) := by
      simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, Matrix.reindex]


theorem hpsd0_proved : hpsd0 (p := p) := by
  classical
  -- Prove PSD of the interior block by testing the Laplacian quadratic form
  -- on boundary-zero extensions.
  -- First, `L0` is symmetric, hence so is `LII0`, and `symm(LII0) = LII0`.
  have hsymmL0 : Matrix.transpose (L0 (p := p)) = L0 (p := p) := (gate_L0_admissible (p := p)).1
  have hsymmLII : Matrix.transpose (LII0 (p := p)) = LII0 (p := p) :=
    PillarA.OQS.Split.blockII_transpose_of_symm (s := sSplit p) (M := L0 (p := p)) hsymmL0
  have hsymmEq :
      PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p)) = LII0 (p := p) :=
    symm_LII0_eq (p := p) hsymmLII

  -- Show `LII0` is positive semidefinite.
  have hLII : (LII0 (p := p)).PosSemidef := by
    -- `PosSemidef` is a conjunction: Hermitian + nonnegativity of the quadratic form.
    refine And.intro ?_ ?_
    · -- Hermitian over `ℝ` follows from symmetry.
      -- `IsHermitian` is the equation `Aᴴ = A`.
      dsimp [Matrix.IsHermitian]
      ext i j
      have hij : (LII0 (p := p)) j i = (LII0 (p := p)) i j := by
        -- from `transpose = self`
        have hij0 := congrArg (fun M : Matrix (I p) (I p) ℝ => M i j) hsymmLII
        simp [Matrix.transpose_apply] at hij0
        exact hij0
      -- `conjTranspose` entry is `star (A j i)`.
      simp [Matrix.conjTranspose, hij]
    · intro x
      -- boundary-zero extension
      let g : Sum (B p) (I p) → ℝ := fun s =>
        match s with
        | Sum.inl _ => 0
        | Sum.inr i => x i
      let f : V p → ℝ := fun v => g ((sSplit p).e v)
      have h0 : 0 ≤ PillarA.LayerA.quadForm (L0 (p := p)) f :=
        quadForm_L0_nonneg (p := p) f
      have hEq :
          PillarA.LayerA.quadForm (L0 (p := p)) f =
            PillarA.LayerA.quadForm (LII0 (p := p)) x := by
        simpa [f, g, LII0] using (quadForm_ext_eq_quadForm_blockII (p := p) (L := L0 (p := p)) x)
      -- Transfer nonnegativity.
      have hx : 0 ≤ PillarA.LayerA.quadForm (LII0 (p := p)) x := by
        simpa [hEq] using h0
      -- `quadForm` matches the `PosSemidef` predicate over `ℝ`.
      -- Avoid naming the dot-product constant explicitly; `simp` expands the notation.
      simpa [PillarA.LayerA.quadForm] using hx

  -- Rewrite to the required `symm(LII0)` form.
  simpa [hpsd0, hsymmEq] using hLII
theorem hdet0_of_hpsd0 (hpsd : hpsd0 (p := p)) : hdet0 (p := p) := by
  classical
  -- Apply the generic criterion `PSD(symm LII) ⇒ det(LII_stabilized) ≠ 0`.
  have :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
          (s := sSplit p) (p := p) (L := L0 (p := p))).det ≠ 0 := by
    simpa [LII0] using
      (PillarA.OQS.Split.DtNStabilized.det_LII_stabilized_ne_zero_of_posSemidef
        (s := sSplit p) (p := p) (L := L0 (p := p)) hpsd)
  simpa [hdet0, LII_stab0] using this

def hdet0_inst : hdet0 (p := p) := hdet0_of_hpsd0 (p := p) (hpsd0_proved (p := p))

/--
Bridge lemma: feed `hdet0` into the explicit determinant condition expected by
`ReducedOpState.hdet` when `LII := LII0`.
-/
lemma hdet0_to_stateHdet :
    hdet0 (p := p) →
      (let A : Matrix (I p) (I p) ℝ :=
        PillarA.OQS.Split.DtNStabilized.symm (ι := I p) (LII0 (p := p))
       (PillarA.OQS.Split.DtNStabilized.stabilize (ι := I p) A
          (PillarA.OQS.Split.DtNStabilized.deltaSPD (p := p) (ι := I p) A)).det ≠ 0) := by
  intro h
  simpa [hdet0, LII_stab0, PillarA.OQS.Split.DtNStabilized.LII_stabilized, LII0] using h


structure ReducedOpState (p : Policy b) where
  LII : Matrix (I p) (I p) ℝ
  LBB : Matrix (B p) (B p) ℝ
  LBI : Matrix (B p) (I p) ℝ
  LIB : Matrix (I p) (B p) ℝ
  /-- Deterministic, *numerical* invertibility witness for the stabilized interior block.

  Note: the stabilized block uses symmetrization, matching `Split.DtNStabilized.LII_stabilized`.
  -/
  hdet :
    let A : Matrix (I p) (I p) ℝ :=
      PillarA.OQS.Split.DtNStabilized.symm (ι := I p) LII
    (PillarA.OQS.Split.DtNStabilized.stabilize (ι := I p) A
        (PillarA.OQS.Split.DtNStabilized.deltaSPD (p := p) (ι := I p) A)).det ≠ 0

/-
`ext` support for `ReducedOpState`.

We ignore the proof field `hdet` using proof irrelevance (it is a `Prop`).
-/
@[ext] lemma ReducedOpState.ext
    {st st' : ReducedOpState p}
    (hII : st.LII = st'.LII)
    (hBB : st.LBB = st'.LBB)
    (hBI : st.LBI = st'.LBI)
    (hIB : st.LIB = st'.LIB) : st = st' := by
  cases st with
  | mk LII LBB LBI LIB hdet =>
    cases st' with
    | mk LII' LBB' LBI' LIB' hdet' =>
      cases hII; cases hBB; cases hBI; cases hIB
      have hh : hdet = hdet' := by
        -- `hdet` is a `Prop`, hence proofs are subsingleton.
        apply Subsingleton.elim
      cases hh
      rfl


/-!
## Phase 4: derived `ReducedOpState` builder from a source matrix

We provide a **single** canonical constructor `ofMatrix` turning a matrix on `V` into
the corresponding stored blocks, and a specialization `ofLaplacian` for the canonical
Tree-of-Cliques Laplacian source `L0`.

Crucial invariant (derived-only certificate):

* `fullMatrix (ofMatrix L hdet) = L`.

This is proved by explicit case-splitting on `(sSplit p).e` as requested.
-/

/-- Derived state from a matrix on `V` with the stabilized interior determinant gate. -/
def ofMatrix
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    ReducedOpState p := by
  classical
  refine
    { LII := (sSplit p).blockII L
      LBB := (sSplit p).blockBB L
      LBI := (sSplit p).blockBI L
      LIB := (sSplit p).blockIB L
      hdet := ?_ }
  -- The goal is exactly the unfolded `LII_stabilized` determinant condition
  -- for `LII := (sSplit p).blockII L`.
  simpa [PillarA.OQS.Split.DtNStabilized.LII_stabilized] using hdet

@[simp] lemma ofMatrix_LII
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LII = (sSplit p).blockII L := by rfl

@[simp] lemma ofMatrix_LBB
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LBB = (sSplit p).blockBB L := by rfl

@[simp] lemma ofMatrix_LBI
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LBI = (sSplit p).blockBI L := by rfl

@[simp] lemma ofMatrix_LIB
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    (ofMatrix (p := p) L hdet).LIB = (sSplit p).blockIB L := by rfl

/-- Derived state specialized to the canonical Laplacian source `L0`. -/
def ofLaplacian (h : hdet0 (p := p)) : ReducedOpState p :=
  ofMatrix (p := p) (L := L0 (p := p))
    (hdet := by
      -- Unify the gate type with the explicit `LII_stabilized` form.
      simpa [hdet0, LII_stab0] using h)

/--
Gate-weakened constructor: it suffices to provide the **structural** hypothesis
`hpsd0 : PosSemidef (symm LII0)`; the determinant gate is discharged automatically.

This is the recommended entry point once you have a Laplacian coercivity/connectivity proof
available.
-/
def ofLaplacian_of_posSemidef (hpsd : hpsd0 (p := p)) : ReducedOpState p :=
  ofLaplacian (p := p) (h := hdet0_of_hpsd0 (p := p) hpsd)

/-- Mask a boundary matrix to a selected region (zero outside). -/
def maskBB (R : Finset (B p)) (A : Matrix (B p) (B p) ℝ) : Matrix (B p) (B p) ℝ :=
  fun x y => (if x ∈ R then 1 else 0) * A x y * (if y ∈ R then 1 else 0)

/-- Mask a `B×I` block by zeroing out rows outside the region. -/
def maskBI (R : Finset (B p)) (A : Matrix (B p) (I p) ℝ) : Matrix (B p) (I p) ℝ :=
  fun b i => if b ∈ R then A b i else 0

/-- Mask an `I×B` block by zeroing out columns outside the region. -/
def maskIB (R : Finset (B p)) (A : Matrix (I p) (B p) ℝ) : Matrix (I p) (B p) ℝ :=
  fun i b => if b ∈ R then A i b else 0

@[simp] lemma maskBB_idem (R : Finset (B p)) (A : Matrix (B p) (B p) ℝ) :
    maskBB (p := p) R (maskBB (p := p) R A) = maskBB (p := p) R A := by
  classical
  ext x y
  by_cases hx : x ∈ R <;> by_cases hy : y ∈ R <;> simp [maskBB, hx, hy]

/-- Assemble a matrix on `B ⊕ I` from the stored blocks (including cross blocks). -/
def sumMatrix (st : ReducedOpState p) :
    Matrix (Sum (B p) (I p)) (Sum (B p) (I p)) ℝ
  | Sum.inl b1, Sum.inl b2 => st.LBB b1 b2
  | Sum.inl b,  Sum.inr i  => st.LBI b i
  | Sum.inr i,  Sum.inl b  => st.LIB i b
  | Sum.inr i1, Sum.inr i2 => st.LII i1 i2

/-- Full matrix on `V` obtained by reindexing the `B ⊕ I` block form back to `V`. -/
def fullMatrix (st : ReducedOpState p) : Matrix (V p) (V p) ℝ :=
  Matrix.reindex (sSplit p).e.symm (sSplit p).e.symm (sumMatrix (p := p) st)

@[simp] lemma blockBB_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockBB (fullMatrix (p := p) st) = st.LBB := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockBB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockII_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockII (fullMatrix (p := p) st) = st.LII := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockBI_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockBI (fullMatrix (p := p) st) = st.LBI := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockBI, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockIB_fullMatrix (st : ReducedOpState p) :
    (sSplit p).blockIB (fullMatrix (p := p) st) = st.LIB := by
  classical
  ext x y
  simp [PillarA.OQS.Split.blockIB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

/-!
## Phase 4: derived-only certificate for `ofMatrix` / `ofLaplacian`

Key invariant:

* `fullMatrix (ofMatrix L hdet) = L`.

We prove this by explicit case-splitting on `(sSplit p).e`.
-/

/-- Derived-only certificate: extracting blocks and reassembling gives back `L`. -/
lemma fullMatrix_ofMatrix
    (L : Matrix (V p) (V p) ℝ)
    (hdet :
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (L := L)).det ≠ 0) :
    fullMatrix (p := p) (ofMatrix (p := p) L hdet) = L := by
  classical
  ext v w
  -- Case split by the split equivalence `e : V ≃ B ⊕ I`.
  cases hv : (sSplit p).e v with
  | inl bv =>
      cases hw : (sSplit p).e w with
      | inl bw =>
          have hv' : (sSplit p).e.symm (Sum.inl bv) = v := by
            have : v = (sSplit p).e.symm (Sum.inl bv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inl bw) = w := by
            have : w = (sSplit p).e.symm (Sum.inl bw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          -- `BB` block.
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockBB,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
      | inr iw =>
          have hv' : (sSplit p).e.symm (Sum.inl bv) = v := by
            have : v = (sSplit p).e.symm (Sum.inl bv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inr iw) = w := by
            have : w = (sSplit p).e.symm (Sum.inr iw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          -- `BI` block.
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockBI,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
  | inr iv =>
      cases hw : (sSplit p).e w with
      | inl bw =>
          have hv' : (sSplit p).e.symm (Sum.inr iv) = v := by
            have : v = (sSplit p).e.symm (Sum.inr iv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inl bw) = w := by
            have : w = (sSplit p).e.symm (Sum.inl bw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          -- `IB` block.
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockIB,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']
      | inr iw =>
          have hv' : (sSplit p).e.symm (Sum.inr iv) = v := by
            have : v = (sSplit p).e.symm (Sum.inr iv) := by
              simpa using congrArg (sSplit p).e.symm hv
            simpa using this.symm
          have hw' : (sSplit p).e.symm (Sum.inr iw) = w := by
            have : w = (sSplit p).e.symm (Sum.inr iw) := by
              simpa using congrArg (sSplit p).e.symm hw
            simpa using this.symm
          -- `II` block.
          simp [fullMatrix, sumMatrix, ofMatrix, PillarA.OQS.Split.blockII,
            PillarA.OQS.Split.reindex, Matrix.reindex, hv, hw, hv', hw']

lemma fullMatrix_ofLaplacian (h : hdet0 (p := p)) :
    fullMatrix (p := p) (ofLaplacian (p := p) h) = L0 (p := p) := by
  classical
  -- Reduce to `fullMatrix_ofMatrix`.
  simpa [ofLaplacian] using
    (fullMatrix_ofMatrix (p := p) (L := L0 (p := p))
      (hdet := by
        simpa [hdet0, LII_stab0] using h))

/-!
## Phase 2: deterministic stabilized interior inverse witness

We now expose a canonical `InteriorInvStabilized` witness for the *assembled* operator
`fullMatrix st`, derived from the stored gate `st.hdet`.

Key requirement: **no** `Classical.choose` is used; the inverse is fixed as `A⁻¹` where
`A := LII_stabilized p (fullMatrix st)`.
-/

/-- Transport the stored `det ≠ 0` gate to the assembled operator `fullMatrix st`. -/
lemma hdet_LII_stabilized_fullMatrix (st : ReducedOpState p) :
    (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (fullMatrix (p := p) st)).det ≠ 0 := by
  classical
  -- `LII_stabilized` depends on `blockII`; `blockII_fullMatrix` rewrites it to `st.LII`.
  simpa [PillarA.OQS.Split.DtNStabilized.LII_stabilized] using st.hdet

/-- Canonical stabilized interior inverse witness for `fullMatrix st`, justified by `st.hdet`. -/
def invStab (st : ReducedOpState p) :
    PillarA.OQS.Split.DtNStabilized.InteriorInvStabilized
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st) := by
  classical
  exact
    PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st)
      (hdet := hdet_LII_stabilized_fullMatrix (p := p) st)

@[simp] lemma invStab_inv (st : ReducedOpState p) :
    (invStab (p := p) st).inv =
      (PillarA.OQS.Split.DtNStabilized.LII_stabilized
        (s := sSplit p) (p := p) (fullMatrix (p := p) st))⁻¹ := by
  classical
  simp [invStab, PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det]

/-- Region selection: keep the chosen boundary region, mask corresponding cross blocks. -/
def select (m : SubsystemMode (B p)) (st : ReducedOpState p) : ReducedOpState p := by
  classical
  cases m with
  | allCells =>
      exact st
  | region R =>
      refine
        { LII := st.LII
          LBB := maskBB (p := p) R st.LBB
          LBI := maskBI (p := p) R st.LBI
          LIB := maskIB (p := p) R st.LIB
          hdet := ?_ }
      simpa using st.hdet

/-!
## Phase 3: genuine stabilized DtN reduction (no `integrateTail := id`)
-/

/-- Stabilized DtN collapses to `LBB` whenever both cross blocks vanish. -/
lemma dtn_stabilized_fullMatrix_of_cross_zero (st : ReducedOpState p)
    (hBI : st.LBI = 0) (hIB : st.LIB = 0) :
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
        (s := sSplit p) (p := p) (L := fullMatrix (p := p) st)
        (w := invStab (p := p) st) = st.LBB := by
  classical
  -- `DtN_stabilized_of` is `LBB - LBI * inv * LIB`.
  simp [PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of, PillarA.LayerA.DtN, hBI, hIB]

/--
Stage-1 reduction: compute the stabilized DtN boundary operator and zero the cross blocks.

We keep the interior block and determinant gate as decoupled auxiliaries.
-/
def reduce (st : ReducedOpState p) : ReducedOpState p :=
  { LII := st.LII
    LBB := PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
      (s := sSplit p) (p := p) (L := fullMatrix (p := p) st) (w := invStab (p := p) st)
    LBI := 0
    LIB := 0
    hdet := st.hdet }

lemma dtn_stabilized_fullMatrix_of_reduced (st : ReducedOpState p) :
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of
        (s := sSplit p) (p := p) (L := fullMatrix (p := p) (reduce (p := p) st))
        (w := invStab (p := p) (reduce (p := p) st))
      = (reduce (p := p) st).LBB := by
  classical
  apply dtn_stabilized_fullMatrix_of_cross_zero (p := p) (st := reduce (p := p) st) <;> rfl

lemma reduce_idem (st : ReducedOpState p) :
    reduce (p := p) (reduce (p := p) st) = reduce (p := p) st := by
  classical
  apply ReducedOpState.ext (p := p)
  · simp [reduce]
  · -- LBB
    simpa [reduce] using (dtn_stabilized_fullMatrix_of_reduced (p := p) st)
  · simp [reduce]
  · simp [reduce]




/-!
## Phase 5: End-to-end specialization for the Laplacian-derived state

We specialize `reduce` to the derived Laplacian state `stLap` and show that the resulting
boundary operator equals the Tree-of-Cliques stabilized DtN
`TreeOfCliques.DtNStabilized.dtn_stabilized_of_det`.
-/


/--
Laplacian-derived state.

Strong form: the determinant gate `hdet0` is discharged automatically via `hpsd0_proved`.
-/
def stLap : ReducedOpState p :=
  ofLaplacian (p := p) (hdet0_inst (p := p))

lemma fullMatrix_stLap :
    fullMatrix (p := p) (stLap (p := p)) = L0 (p := p) := by
  simpa [stLap] using fullMatrix_ofLaplacian (p := p) (hdet0_inst (p := p))

/-- Cross blocks are zero after `reduce` (by definition). -/
lemma reduce_cross_zero_stLap :
    (reduce (p := p) (stLap (p := p))).LBI = 0 ∧
    (reduce (p := p) (stLap (p := p))).LIB = 0 := by
  simp [reduce, stLap]

/--
End-to-end: reducing the Laplacian-derived state yields the stabilized DtN computed
from the canonical Tree-of-Cliques Laplacian `L0`.
-/
lemma reduce_LBB_eq_dtn_stab :
    (reduce (p := p) (stLap (p := p))).LBB =
      TreeOfCliques.DtNStabilized.dtn_stabilized_of_det
        (b := b) (p := p) (k := k p)
        (hdet := by
          -- The required gate is definitionally the same as `hdet0_inst`.
          simpa [TreeOfCliques.DtNStabilized.LII_stab,
            TreeOfCliques.DtNStabilized.s,
            TreeOfCliques.DtNStabilized.L,
            LII_stab0, L0, sSplit, k] using
              (show (LII_stab0 (p := p)).det ≠ 0 from (hdet0_inst (p := p)))) := by
  classical
  -- Unfold the derived state and both DtN implementations.
  -- The result is the same stabilized Schur complement.
  simp [reduce, stLap, ofLaplacian,
    TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
    TreeOfCliques.DtNStabilized.s,
    TreeOfCliques.DtNStabilized.L,
    PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
    PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
    PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
    PillarA.OQS.Split.DtNStabilized.LII_stabilized,
    PillarA.LayerA.DtN,
    invStab_inv,
    L0, sSplit, k]


/--
Concrete `TwoStageApprox` at `policy.L_max`.

* `truncateTail := id`
* `integrateTail := reduce` (genuine stabilized DtN computation)
* selection masks the chosen boundary region.
-/
def mk : PillarA.Update.TwoStageApprox b where
  policy := p
  Cell := (PillarA.Ideal.IdealCell b : Nat → Type)
  S := ReducedOpState p
  truncateTail := id
  integrateTail := fun s => reduce (p := p) s
  select := fun m s => select (p := p) m s
  truncate_idem := by intro s; rfl
  integrate_idem := by intro s; simpa using (reduce_idem (p := p) s)
  stage1_idem := by
    intro s
    -- `truncateTail = id`, so stage-1 idempotence is `reduce_idem`.
    simpa using (reduce_idem (p := p) s)

end TreeOfCliquesApproxDtNStabilized

end

end Adapter
end Ideal
end PillarA
