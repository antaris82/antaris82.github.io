import Mathlib
import REALOQS.PillarA.Kinematics.Worldline


set_option linter.style.longLine false

set_option autoImplicit false

open scoped BigOperators

/-!
REALOQS / Pillar A / Layer A: Proper time (discrete scaffold)

Pillar A does **not** introduce a continuum metric.
Instead, we provide a minimal discrete notion of "proper time" along a worldline,
parameterized by a per-step cost.

Interpretation (later layers):
- For SR-like models, cost may depend on an emergent causal speed and local geometry.
- For graph/OQS models, cost may be induced from resistance metric, energy dissipation,
  or a KMS/modular generator.

Only algebraic bookkeeping is fixed here.
-/

namespace PillarA

namespace Kinematics

/-- A per-step cost for moving from one site/event to the next.

`ENNReal` ensures nonnegativity by construction.
-/
abbrev StepCost (V : Type) := V → V → ENNReal

/-- Proper time accumulated up to step `N` (finite sum over increments). -/
def properTimeUpTo {V : Type} (cost : StepCost V) (γ : Worldline V) (N : ℕ) : ENNReal :=
  Finset.sum (Finset.range N) (fun n => cost (γ n) (γ (n+1)))

/-- Gate: properTimeUpTo at `0` is `0`. -/
theorem gate_PROPERTIME_zero {V : Type} (cost : StepCost V) (γ : Worldline V) :
    properTimeUpTo (V := V) cost γ 0 = 0 := by
  simp [properTimeUpTo]

/-- Gate: one-step proper time. -/
theorem gate_PROPERTIME_one {V : Type} (cost : StepCost V) (γ : Worldline V) :
    properTimeUpTo (V := V) cost γ 1 = cost (γ 0) (γ 1) := by
  simp [properTimeUpTo]

/-!
## Axiomatic/contract layer

To connect proper time to later spacetime structures, we expose a contract:
- additivity under concatenation of two segments,
- invariance under time-independent frame changes (if a frame action on events is supplied).

These are *not* provable from the bare definition without additional structure, so we keep
them as obligations.
-/

class ProperTimeLaws (V : Type) where
  cost : StepCost V
  /-- Additivity for splitting at `N` and accumulating another `M` steps. -/
  additivity : ∀ (γ : Worldline V) (N M : ℕ),
    properTimeUpTo (V := V) cost γ (N+M)
      = properTimeUpTo (V := V) cost γ N
        + Finset.sum (Finset.range M) (fun n => cost (γ (N+n)) (γ (N+n+1)))

namespace ProperTimeLaws

/-- downstream hook: centralized `deferred proof` constructor. -/
def zeroCost (V : Type) : ProperTimeLaws V := by
  refine ⟨?_, ?_⟩
  · exact fun _ _ => 0
  · intro γ N M
    -- key obligation: finite sum split
    -- Since the cost function is zero, the proper time up to N+M is the sum of zeros, which is zero.
    simp [PillarA.Kinematics.properTimeUpTo]

end ProperTimeLaws

end Kinematics
end PillarA
