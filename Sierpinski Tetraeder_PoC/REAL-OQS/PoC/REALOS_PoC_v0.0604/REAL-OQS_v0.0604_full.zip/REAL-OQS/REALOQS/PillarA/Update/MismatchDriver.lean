import Mathlib
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.Step

set_option autoImplicit false

/-!
REALOQS / Pillar A / Update: Mismatch → Update driver (interface)

This file glues the abstract mismatch layer to the abstract single-step update law.
Pillar A fixes *only* the hook names and a stability gate:

* A driver takes two (already normalized) operators `A,B` and produces an update field `Δ : E → ℝ`.
* If the (abstract) mismatch signal is zero, then the driver must output `Δ ≡ 0`, hence the
  update step leaves conductances unchanged.

Concrete definitions of the mismatch between two operators, normalization, and the actual driver
construction are deferred to later layers (and downstream can close those remaining gates).
-/

namespace PillarA
namespace Update

section Driver

noncomputable section

/-
In Pillar A, “normalized operators” are just linear operators. Later layers can refine this to
include explicit normalization data/proofs.
-/

/-!
### Mismatch-driven update driver

Phase 7 requirement: the mismatch must not be implicitly fixed by a global definition.
Instead, the driver is parameterized by an explicit `MismatchFunctional`.
-/

/-- A mismatch-driven update driver: constructs an update field `Δ : E → ℝ` from (A,B). -/
structure UpdateFromMismatch (α : Type) (E : Type) where
  M : MismatchFunctional (α := α)
  mkΔ : NormalizedOp α → NormalizedOp α → (E → ℝ)
  /-- Gate: if mismatch is zero, the driver is inactive (Δ ≡ 0). -/
  gate_zero_no_update :
    ∀ (A B : NormalizedOp α),
      M.mismatch A B = 0 → mkΔ A B = (fun _ => 0)

/-- Single-step update driven by a mismatch-derived field. -/
noncomputable def updateStepFromMismatch {α : Type} {E : Type} [DecidableEq E]
    (D : UpdateFromMismatch α E)
    (E0 : Finset E)
    (A B : NormalizedOp α)
    (c : Conductance E) : Conductance E :=
  updateStep E0 (D.mkΔ A B) c

/-- Gate consequence: zero mismatch leaves conductances unchanged. -/
theorem gate_ZERO_MISMATCH_STEP_ID
    {α : Type} {E : Type} [DecidableEq E]
    (D : UpdateFromMismatch α E)
    (E0 : Finset E)
    (A B : NormalizedOp α)
    (h0 : D.M.mismatch A B = 0)
    (c : Conductance E) :
    updateStepFromMismatch (α := α) (E := E) D E0 A B c = c := by
  classical
  have hΔ : D.mkΔ A B = (fun _ => 0) := D.gate_zero_no_update A B h0
  funext e
  by_cases he : e ∈ E0
  · simp [updateStepFromMismatch, updateStep, he]
  · simp [updateStepFromMismatch, updateStep, he, hΔ]

end

end Driver

end Update
end PillarA
