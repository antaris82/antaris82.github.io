import Mathlib
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver

set_option linter.style.longLine false
set_option autoImplicit false

/-!
REALOQS / Pillar A / Layer A: Scale-breaking measures from mismatch functional (dependent)

This is the dependent (varying-scale) analogue of `ScaleBreakingMismatch.lean`.

Key point: both the carrier `S k` and the interface `α k` may change with `k`.
This is the minimal interface-level scaffolding needed for Phase 7.
-/

namespace PillarA

namespace Physics


open PillarA.Update

/-- Generic mismatch-based diagnostic for an arbitrary varying-scale tower `tower : ∀ k, S k`.

Intended reading (schematic):
`μ(k) = D_k( Π_k Â_k Π_k , Π_k Â_{k+1→k} Π_k )`.

At Pillar A this remains interface-level:
- `coarsen` is abstract,
- `Obs.op` is abstract,
- the mismatch functional is an explicit hook per scale.
-/
noncomputable def breakMeasure_fromMismatch_onTowerD
    {S : Nat → Type} {α : Nat → Type}
    (coarsen : ∀ k, S (k + 1) → S k)
    (tower : ∀ k, S k)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  fun k =>
    let Mk := M k
    let Ak : NormalizedOp (α := α k) :=
      normalizeTrace (α := α k) Mk.P Mk.T eps eps_pos (Obs.op k (tower k))
    let Acoarse : NormalizedOp (α := α k) :=
      normalizeTrace (α := α k) Mk.P Mk.T eps eps_pos (Obs.op k (coarsen k (tower (k + 1))))
    Mk.mismatch Ak Acoarse

/-- REAL diagnostic: mismatch applied to the REAL tower of a `ScaleBreakingAxisD`. -/
noncomputable def breakMeasure_fromMismatchRealD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTowerD (S := S) (α := α) A.coarsen A.real Obs M eps eps_pos

/-- IDEAL diagnostic: mismatch applied to the IDEAL tower of a `ScaleBreakingAxisD`. -/
noncomputable def breakMeasure_fromMismatchIdealD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTowerD (S := S) (α := α) A.coarsen A.ideal Obs M eps eps_pos

/-- Equip an existing qualitative dependent axis with mismatch-based diagnostics on BOTH towers. -/
noncomputable def axis_fromMismatchD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : ScaleBreakingAxisD S :=
  { coarsen := A.coarsen
    , ideal := A.ideal
    , real := A.real
    , breakMeasure := breakMeasure_fromMismatchRealD (S := S) (α := α) A Obs M eps eps_pos
    , breakMeasureIdeal := breakMeasure_fromMismatchIdealD (S := S) (α := α) A Obs M eps eps_pos }

end Physics

end PillarA
