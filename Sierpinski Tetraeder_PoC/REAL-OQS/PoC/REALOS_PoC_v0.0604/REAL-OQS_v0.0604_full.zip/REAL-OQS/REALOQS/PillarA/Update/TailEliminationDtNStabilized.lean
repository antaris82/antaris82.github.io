import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.OQS.DtNStabilized

set_option autoImplicit false

namespace PillarA
namespace Update

open scoped BigOperators

noncomputable section

open PillarA.OQS

/-!
# Tail elimination semantics (DtN, stabilized)

This is the stabilized analogue of `Update.TailEliminationDtN`.

Instead of requiring an honest inverse of the interior block `LII`, we use
the deterministic stabilized interior block

`LII_stabilized = (1/2)(LII + LIIᵀ) + δ I`

and an inverse witness for this stabilized block. The stabilizing parameter δ
is read from the global `Policy b`.

The purpose of this module is to provide a semantic contract that can be used
to connect a concrete update carrier to the stabilized DtN construction.
-/

structure TailElimDtNStabilizedSemantics {b : Nat} (A : TwoStageApprox b) where
  /-- full vertex type for the operator -/
  V : Type
  instFintypeV : Fintype V
  instDecEqV : DecidableEq V
  /-- split defining boundary/interior decomposition -/
  split : Split V
  /-- full operator on V -/
  L : A.S → Matrix V V ℝ
  /-- stabilized interior inverse witness -/
  invStab : ∀ s : A.S,
    Split.DtNStabilized.InteriorInvStabilized (s := split) (p := A.policy) (L s)
  /-- boundary observable (typically blockBB(L(...)) or a derived boundary operator) -/
  boundaryOp : A.S → Matrix split.B split.B ℝ
  /-- semantic contract: stage-1 boundary observable matches stabilized DtN -/
  stage1_boundaryOp_eq : ∀ s : A.S,
    boundaryOp (A.stage1 s) =
      Split.DtNStabilized.DtN_stabilized_of (s := split) (p := A.policy) (L s) (invStab s)

attribute [instance] TailElimDtNStabilizedSemantics.instFintypeV
attribute [instance] TailElimDtNStabilizedSemantics.instDecEqV

end

end Update
end PillarA
