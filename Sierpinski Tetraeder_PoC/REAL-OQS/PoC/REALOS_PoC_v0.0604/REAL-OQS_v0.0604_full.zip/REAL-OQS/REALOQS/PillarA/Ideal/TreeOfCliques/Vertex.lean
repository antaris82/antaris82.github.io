import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

/--
Vertices of the Tree-of-Cliques approximant at depth `k`.

Definition: all IDEAL addresses up to depth `k`, i.e. elements of `cellsUpTo b k`.
This is *purely derived* from the address-tree scaffold in `Ideal.Substrate`.
-/
abbrev Vertex (b k : Nat) : Type := ↥(cellsUpTo b k)

namespace Vertex

/-- Underlying address. -/
def addr {b k : Nat} (v : Vertex b k) : Addr b := v.1

/-- Depth / level of a vertex (address length). -/
def depth {b k : Nat} (v : Vertex b k) : Nat := v.addr.length

/-- Addresses in `cellsUpTo b k` have length at most `k`. -/
theorem mem_cellsUpTo_length_le (b k : Nat) (a : Addr b) :
    a ∈ cellsUpTo b k → a.length ≤ k := by
  intro ha
  induction k with
  | zero =>
      -- `cellsUpTo b 0 = cellsAtLevel b 0` and `a.length = 0`.
      have hlen : a.length = 0 := by
        have ha0 : a ∈ cellsAtLevel b 0 := by
          -- Rewrite the hypothesis `ha : a ∈ cellsUpTo b 0` into the level form.
          have ha' := ha
          simp [cellsUpTo] at ha'
          exact ha'
        exact (mem_cellsAtLevel_iff_length b 0 a).1 ha0
      simp [hlen]
  | succ k ih =>
      -- Unfolding `cellsUpTo` produces a membership disjunction.
      have ha' : a ∈ cellsUpTo b k ∨ a ∈ cellsAtLevel b (k + 1) := by
        have ha'' := ha
        simp [cellsUpTo] at ha''
        exact ha''
      cases ha' with
      | inl hprev =>
          exact Nat.le_trans (ih hprev) (Nat.le_succ k)
      | inr hlast =>
          have hlen : a.length = k + 1 := (mem_cellsAtLevel_iff_length b (k + 1) a).1 hlast
          exact le_of_eq hlen

/-- Depth bound for a vertex in `Vertex b k`. -/
theorem depth_le {b k : Nat} (v : Vertex b k) : v.depth ≤ k :=
  mem_cellsUpTo_length_le b k v.1 v.2

/-- Monotone embedding `Vertex b k ↪ Vertex b (k+1)`. -/
def castSucc {b k : Nat} : Vertex b k → Vertex b (k + 1) := by
  intro v
  refine ⟨v.1, ?_⟩
  -- After unfolding `cellsUpTo`, `simp` can close the goal using `v.2`.
  simp [cellsUpTo, v.2]

/-- Finset monotonicity: `cellsUpTo b k ⊆ cellsUpTo b (k+1)`. -/
theorem cellsUpTo_subset_succ (b k : Nat) : cellsUpTo b k ⊆ cellsUpTo b (k + 1) := by
  intro a ha
  -- After unfolding `cellsUpTo`, `simp` can close the goal using `ha`.
  simp [cellsUpTo, ha]

end Vertex

end TreeOfCliques
end Ideal
end PillarA
