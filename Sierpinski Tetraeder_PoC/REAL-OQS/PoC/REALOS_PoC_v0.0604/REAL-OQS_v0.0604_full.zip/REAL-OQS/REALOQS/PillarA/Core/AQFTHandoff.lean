import Mathlib
import REALOQS.PillarA.Core.RegionNet

set_option autoImplicit false

namespace PillarA
namespace LayerA

/-!
# A → B AQFT handoff data (core, B-free)

This module defines the raw data that Pillar A may hand to Pillar B when an
AQFT layer is to be built *canonically from A-output*.

Design constraints:
- Pillar A remains **B-free**: no `MatterTemplate`, no AQFT imports.
- The handoff carries only raw region/configuration/operator data.
- The handoff may still be **state-parametrized**; choosing a canonical global
  state is deferred to later closure phases if it cannot yet be derived in A.
-/

universe u v

/-- Raw AQFT handoff data produced by Pillar A and consumable by Pillar B. -/
structure AQFTHandoffData where
  Ω : Type u
  instFintypeΩ : Fintype Ω
  instDecEqΩ : DecidableEq Ω
  RN : RegionNet Ω
  State : Type v
  stage1 : State → State
  boundaryOp : State → Matrix Ω Ω ℝ
  cfgArity : Nat
  cfgArity_pos : 0 < cfgArity
  beta : State → ℝ
  beta_pos : ∀ s : State, 0 < beta s
  phi : Fin cfgArity → ℝ

attribute [instance] AQFTHandoffData.instFintypeΩ AQFTHandoffData.instDecEqΩ

namespace AQFTHandoffData

variable (H : AQFTHandoffData)

instance : SemilatticeSup H.RN.Region := by
  infer_instance

theorem gate_cfgArity_pos : 0 < H.cfgArity :=
  H.cfgArity_pos

theorem gate_beta_pos (s : H.State) : 0 < H.beta s :=
  H.beta_pos s

end AQFTHandoffData

end LayerA
end PillarA
