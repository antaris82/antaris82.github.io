import REALOQS.PillarA.BuildAll
import REALOQS.PillarB.BuildAll
import REALOQS.PillarC.BuildAll
import REALOQS.Examples.BuildAll

/-!
# BuildAll

Single-entry build target for `lake build` to compile the active theory core
(Pillar A, Pillar B, Pillar C, plus maintained examples) without any meta-audit
surfaces.
-/
