#!/usr/bin/env python3
"""Import policy checker for REALOQS.

Rules enforced (Pillar A):
  (R1) No `REALOQS.PillarA.Core.*` module may import `REALOQS.PillarA.Ideal.*`.
  (R2) No `REALOQS.PillarA.Update.*` module may import `REALOQS.PillarA.Ideal.*`.
  (R3) Outside of the `REALOQS.PillarA.Ideal.*` subtree, any import of
       `REALOQS.PillarA.Ideal.*` must go through `REALOQS.PillarA.Ideal.Adapter.*`.

Rules enforced (Pillar B):
  (B1) No `REALOQS.PillarB.*` module may import `REALOQS.PillarA.Ideal.*`.
  (B2) `REALOQS/PillarB/Interface.lean` may only import:
       - `REALOQS.PillarA.Core.Exports`
       - `Mathlib.*` (if needed later)
  (B3) No `REALOQS.PillarB.*` module may import `REALOQS.PillarA.All`.

This checker is intentionally conservative: it only inspects explicit
`import ...` lines.
"""

from __future__ import annotations

import pathlib
import sys
from typing import Iterable, List, Tuple


def iter_lean_files(root: pathlib.Path) -> Iterable[pathlib.Path]:
    for p in root.rglob("*.lean"):
        # skip .lake / build artifacts if present
        if any(part in {".lake", "build"} for part in p.parts):
            continue
        yield p


def parse_imports(path: pathlib.Path) -> List[str]:
    imports: List[str] = []
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        text = path.read_text(encoding="utf-8", errors="replace")
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("import "):
            continue
        mod = s[len("import ") :].strip()
        if mod:
            imports.append(mod)
    return imports


def main() -> int:
    # script is located at REALOQS/tools/check_import_policy.py
    script = pathlib.Path(__file__).resolve()
    realoqs_root = script.parent.parent

    pillarA_root = realoqs_root / "PillarA"
    pillarB_root = realoqs_root / "PillarB"

    if not pillarA_root.exists():
        print(f"ERROR: expected {pillarA_root} to exist", file=sys.stderr)
        return 2

    violations: List[Tuple[str, str, str]] = []

    # ----------------
    # Pillar A checks
    # ----------------
    for f in iter_lean_files(pillarA_root):
        rel = f.relative_to(realoqs_root)
        rel_str = str(rel).replace("\\", "/")

        imports = parse_imports(f)
        for mod in imports:
            if "REALOQS.PillarA.Ideal." not in mod:
                continue

            in_ideal = rel_str.startswith("PillarA/Ideal/")
            in_core = rel_str.startswith("PillarA/Core/")
            in_update = rel_str.startswith("PillarA/Update/")

            # (R1)
            if in_core:
                violations.append((rel_str, mod, "R1: Core must not import Ideal"))
                continue
            # (R2)
            if in_update:
                violations.append((rel_str, mod, "R2: Update must not import Ideal"))
                continue
            # (R3)
            if not in_ideal and not mod.startswith("REALOQS.PillarA.Ideal.Adapter."):
                violations.append((rel_str, mod, "R3: non-Ideal must import via Ideal.Adapter"))

    # ----------------
    # Pillar B checks
    # ----------------
    if pillarB_root.exists():
        for f in iter_lean_files(pillarB_root):
            rel = f.relative_to(realoqs_root)
            rel_str = str(rel).replace("\\", "/")
            imports = parse_imports(f)

            # (B2) interface restriction
            if rel_str == "PillarB/Interface.lean":
                for mod in imports:
                    ok = (
                        mod == "REALOQS.PillarA.Core.Exports"
                        or mod.startswith("Mathlib")
                    )
                    if not ok:
                        violations.append((rel_str, mod, "B2: PillarB.Interface import restricted"))

            for mod in imports:
                # (B1) forbid Ideal imports
                if "REALOQS.PillarA.Ideal." in mod:
                    violations.append((rel_str, mod, "B1: PillarB must not import PillarA.Ideal"))
                # (B3) forbid PillarA.All imports
                if mod == "REALOQS.PillarA.All" or mod.startswith("REALOQS.PillarA.All."):
                    violations.append((rel_str, mod, "B3: PillarB must not import PillarA.All"))

    if violations:
        print("Import policy violations detected:\n", file=sys.stderr)
        for (file_path, mod, rule) in violations:
            print(f"  - {file_path}: import {mod}  [{rule}]", file=sys.stderr)
        return 1

    print("Import policy OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
