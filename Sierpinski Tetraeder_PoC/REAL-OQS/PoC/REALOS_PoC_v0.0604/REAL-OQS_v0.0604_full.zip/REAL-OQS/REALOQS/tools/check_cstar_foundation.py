#!/usr/bin/env python3
"""C* foundation audit for REALOQS.

Purpose:
  Enforce the repo-wide C0 closure policy:
    * Mathlib is the only approved analytic C*-foundation.
    * REALOQS may add light bundles/bridges on top of Mathlib.
    * Project-local placeholder/surrogate C*-marker classes must not reappear.

This checker is intentionally conservative. It does not try to prove that every
C*-use is semantically correct; it only blocks the specific regressions that C0
was meant to eliminate.
"""

from __future__ import annotations

import pathlib
import re
import sys
from dataclasses import dataclass
from typing import Iterable, List


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    kind: str
    text: str


_DEF_PATTERNS = [
    re.compile(r"^\s*class\s+IsCStarOverComplex\b"),
    re.compile(r"^\s*class\s+MyCStar\b"),
    re.compile(r"^\s*class\s+AbstractCStar\b"),
    re.compile(r"^\s*class\s+FakeCStar\b"),
]

_USE_PATTERNS = [
    re.compile(r"\bIsCStarOverComplex\b"),
    re.compile(r"\bMyCStar\b"),
    re.compile(r"\bAbstractCStar\b"),
    re.compile(r"\bFakeCStar\b"),
]

_IMPORT_PATTERN = re.compile(r"^\s*import\s+REALOQS\.PillarA\.Core\.Derived\.GNS_CStar\b")



def iter_lean_files(root: pathlib.Path) -> Iterable[pathlib.Path]:
    for p in root.rglob("*.lean"):
        if any(part in {".lake", "build"} for part in p.parts):
            continue
        yield p



def strip_lean_comments(text: str) -> str:
    """Remove Lean line/block comments while preserving line count.

    This is intentionally lightweight but handles nested `/- ... -/` comments.
    """

    out: List[str] = []
    i = 0
    n = len(text)
    block_depth = 0
    while i < n:
        if block_depth == 0 and text.startswith("--", i):
            while i < n and text[i] != "\n":
                i += 1
            continue
        if text.startswith("/-", i):
            block_depth += 1
            i += 2
            continue
        if block_depth > 0 and text.startswith("-/", i):
            block_depth -= 1
            i += 2
            continue
        ch = text[i]
        if block_depth > 0:
            if ch == "\n":
                out.append("\n")
            else:
                out.append(" ")
        else:
            out.append(ch)
        i += 1
    return "".join(out)



def scan_file(repo_root: pathlib.Path, path: pathlib.Path) -> List[Finding]:
    try:
        raw_text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raw_text = path.read_text(encoding="utf-8", errors="replace")

    text = strip_lean_comments(raw_text)
    rel = str(path.relative_to(repo_root)).replace("\\", "/")
    findings: List[Finding] = []

    lines = text.splitlines()
    file_mentions_cstar = "CStar" in text

    for lineno, line in enumerate(lines, start=1):
        if _IMPORT_PATTERN.search(line):
            findings.append(Finding(rel, lineno, "banned-import", line.strip()))

        for rx in _DEF_PATTERNS:
            if rx.search(line):
                findings.append(Finding(rel, lineno, "banned-definition", line.strip()))

        if file_mentions_cstar:
            for rx in _USE_PATTERNS:
                if rx.search(line):
                    findings.append(Finding(rel, lineno, "banned-symbol-use", line.strip()))
            if "trivial : True" in line:
                findings.append(Finding(rel, lineno, "cstar-placeholder", line.strip()))

    return findings



def main() -> int:
    script = pathlib.Path(__file__).resolve()
    realoqs_root = script.parent.parent

    if not (realoqs_root / "PillarA").exists() or not (realoqs_root / "PillarB").exists():
        print(f"ERROR: expected REALOQS repo root at {realoqs_root}", file=sys.stderr)
        return 2

    findings: List[Finding] = []
    for path in iter_lean_files(realoqs_root):
        findings.extend(scan_file(realoqs_root, path))

    if findings:
        print("C* foundation audit failed:\n", file=sys.stderr)
        for finding in findings:
            print(
                f"  - {finding.path}:{finding.line}: [{finding.kind}] {finding.text}",
                file=sys.stderr,
            )
        return 1

    print("C* foundation audit OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
