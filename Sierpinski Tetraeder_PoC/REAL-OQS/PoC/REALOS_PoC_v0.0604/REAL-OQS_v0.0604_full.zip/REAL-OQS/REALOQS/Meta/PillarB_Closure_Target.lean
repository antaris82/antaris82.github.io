import REALOQS.Meta.PillarB_NoConfigHarnessInCriticalPath

set_option autoImplicit false

namespace Meta
namespace PillarB_Closure_Target

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
open _root_.PillarB.AQFT.Derived.TreeOfCliquesExtendedFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

@[simp] theorem toc_closure_target_marker [Fact (0 < b)] :
    (modularDatum_top_ToC (b := b) (p := p)).topKMS.state =
      ρTop (b := b) (p := p) := by
  rfl

end
end PillarB_Closure_Target
end Meta
