import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableDynamicsDecision

/-
Decision surface for the observable dynamical closure question.

This file intentionally does not claim that the additive observable top path is
already dynamically closed.  It only records that the relevant preservation
question is now formalized on the active ToC surface.
-/

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

/-- D0 marker: the observable top state is still the restriction-defined top
state on the additive subnet. -/
@[simp] theorem toc_observable_top_state_restriction_marker :
    observableTopState_is_restriction_defined (b := b) (p := p) := by
  exact observableTopState_is_restriction_defined (b := b) (p := p)

/-- D0 marker: the observable quasilocal state is still the restriction-derived
quasilocal lift, not a new dynamical/KMS object. -/
@[simp] theorem toc_observable_quasilocal_restriction_marker :
    observableQuasiLocal_is_restriction_defined (b := b) (p := p) := by
  exact observableQuasiLocal_is_restriction_defined (b := b) (p := p)

/-- D1 marker: the top observable carrier inside the rich top algebra is now a
named object on the active ToC path. -/
@[simp] theorem toc_observable_top_carrier_marker
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A := by
  rfl

/-- D2a marker: the raw top-level basis generators for the additive observable
carrier are explicitly named on the active ToC path. -/
@[simp] theorem toc_observable_top_basisGen_marker
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) ↔
      A ∈ _root_.PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  rfl

/-- D2a marker: every top-level basis generator is already known to lie in the
observable top carrier. -/
theorem toc_basis_generator_mem_observableTop
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    topBasisGenerator_ToC (b := b) (p := p)
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact topBasisGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) hu A

/-- D2a normalization marker: at time `0`, the rich top dynamics sends every
canonical `L`-ball basis generator back into the observable top carrier. -/
theorem toc_zero_maps_basic_ball_generator_to_observableTop
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (_root_.PillarB.AQFT.Derived.boundaryBallFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
          (_root_.PillarB.AQFT.Derived.boundaryBallFromL
            (Ω := Ω (b := b) (p := p))
            (L := L (b := b) (p := p)) i))
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_zero_maps_basic_ball_generator_to_observableTop
    (b := b) (p := p) i A

/-- D2d marker: the canonical observable-ball generators now have a dedicated
wrapper on the active ToC path. -/
@[simp] theorem toc_observable_ball_generator_marker
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (_root_.PillarB.AQFT.Derived.boundaryBallFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    observableBallGenerator_ToC (b := b) (p := p) i A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact observableBallGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) i A

/-- D2d marker: a direct escape witness is now formalized strongly enough to
refute the full observable-top preservation claim. -/
theorem toc_observable_escape_witness_blocks_closure
    (hw : observableDynEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact observableDynEscapeWitness_not_preserves_N_add_top
    (b := b) (p := p) hw

/-- D2d marker: a same-ball localization escape witness is tracked separately,
and it only refutes the stronger D2c Ansatz, not D2d itself. -/
theorem toc_sameBall_escape_witness_blocks_sameBall_ansatz
    (hw : observableDynSameBallLocalizationEscapeWitness (b := b) (p := p)) :
    ¬ dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p) := by
  exact observableDynSameBallLocalizationEscapeWitness_not_preserves
    (b := b) (p := p) hw


/-- D2d positive criterion marker: if every canonical `L`-ball already equals
the top region, observable-top preservation follows immediately. This is the
exact positive reduction now available for future `L_max > 1` ToC shape work. -/
theorem toc_observable_dynamics_closed_of_allBalls_eq_top
    (hball : ∀ i : Ω (b := b) (p := p),
      boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i =
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_allBalls_eq_top
    (b := b) (p := p) hball

/-- D2d stronger positive criterion marker: nonvanishing off-diagonal entries of
the exported boundary operator already force every canonical ball to be top, and
hence force observable-top preservation. -/
theorem toc_observable_dynamics_closed_of_offdiag_nonzero
    (hoff : ∀ ⦃x y : Ω (b := b) (p := p)⦄, x ≠ y →
      L (b := b) (p := p) x y ≠ 0) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_offdiag_nonzero
    (b := b) (p := p) hoff

/-- D2d partial closure marker: on the concrete ToC handoff surface with
`L_max = 1`, the observable top carrier is already the full rich top carrier,
so D2 closes positively. -/
theorem toc_observable_dynamics_closed_of_Lmax_eq_one
    (hL : p.L_max = 1) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_Lmax_eq_one
    (b := b) (p := p) hL

/-- D2d marker: if all canonical observable-ball generators are preserved in
the observable top carrier, the full D2 closure statement follows. -/
theorem toc_observable_ball_generator_reduction_marker
    (hball : dyn_top_ToC_preserves_observableBallGenerators
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_observableBallGenerators
    (b := b) (p := p) hball

/-- D2a reduction marker: global observable-top preservation is reduced to the
generator-image problem. -/
theorem toc_observable_dynamics_reduction_marker
    (hgen : ∀ (t : ℝ) ⦃A : RichTopAlg (b := b) (p := p)⦄,
      A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) →
        (dyn_top_ToC (b := b) (p := p)).α t A ∈
          observableTopCarrier_ToC (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_basisGenerators
    (b := b) (p := p) hgen



/-- `L > 1` marker: the first concrete `k=2` handoff target is now explicit as
its own predicate on the real exported level-2 boundary operator. -/
@[simp] theorem toc_handoff_Lmax_eq_two_crossParentBlockConstant_marker :
    handoff_Lmax_eq_two_crossParentBlockConstant (b := b) ↔
      handoff_Lmax_eq_two_crossParentBlockConstant (b := b) := by
  rfl

/-- `L > 1` marker: the level-2-to-level-1 coarsening target is likewise named
explicitly on the real exported handoff operator. -/
@[simp] theorem toc_handoff_Lmax_eq_two_coarsens_to_handoff_k1_marker :
    handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) ↔
      handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) := by
  rfl

/-- `L > 1` positive local marker: under the two concrete level-2 handoff
hypotheses, every cross-parent level-2 entry of the real exported boundary
operator is already nonzero. -/
theorem toc_handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  exact handoff_Lmax_eq_two_crossParent_entry_ne_zero
    (b := b) hconst hcoarsen hij hx hy

/-- `L > 1` positive local marker: under the same two concrete level-2 handoff
hypotheses, every cross-parent level-2 point already lies in the canonical
ball of the real exported boundary operator. -/
theorem toc_handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (hconst : handoff_Lmax_eq_two_crossParentBlockConstant (b := b))
    (hcoarsen : handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  exact handoff_Lmax_eq_two_boundaryBall_contains_crossParent
    (b := b) hconst hcoarsen hxy



/-- `L > 1` marker: a single stronger level-2 refinement target now subsumes
both the coarsening target and the cross-parent block-constancy target on the
real exported handoff operator. -/
@[simp] theorem toc_handoff_Lmax_eq_two_refines_handoff_k1_marker :
    handoff_Lmax_eq_two_refines_handoff_k1 (b := b) ↔
      handoff_Lmax_eq_two_refines_handoff_k1 (b := b) := by
  rfl

/-- `L > 1` marker: the stronger refinement target implies the concrete
level-2-to-level-1 coarsening target. -/
theorem toc_handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine
    (hb : 0 < b)
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_coarsens_to_handoff_k1 (b := b) := by
  exact _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.handoff_Lmax_eq_two_coarsens_to_handoff_k1_of_refine (b := b) hb href

/-- `L > 1` marker: the stronger refinement target also implies the cross-parent
fiber-block constancy predicate. -/
theorem toc_handoff_Lmax_eq_two_crossParentBlockConstant_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b)) :
    handoff_Lmax_eq_two_crossParentBlockConstant (b := b) := by
  exact _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.handoff_Lmax_eq_two_crossParentBlockConstant_of_refine (b := b) href

/-- `L > 1` positive local marker: under the stronger refinement target, every
cross-parent level-2 entry of the real exported handoff operator is already
nonzero. -/
theorem toc_handoff_Lmax_eq_two_crossParent_entry_ne_zero_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {i j : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1}
    (hij : i ≠ j)
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hx : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x = i)
    (hy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y = j) :
    L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)) x y ≠ 0 := by
  exact _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.handoff_Lmax_eq_two_crossParent_entry_ne_zero_of_refine
    (b := b) href hij hx hy

/-- `L > 1` positive local marker: under the stronger refinement target, every
cross-parent level-2 point already lies in the canonical ball of the real
exported handoff operator. -/
theorem toc_handoff_Lmax_eq_two_boundaryBall_contains_crossParent_of_refine
    (href : handoff_Lmax_eq_two_refines_handoff_k1 (b := b))
    {x y : Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))}
    (hxy : _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 x ≠
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.π b 1 y) :
    y ∈ boundaryBallFromL
      (Ω := Ω (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b)))
      (L := L (b := b) (p := ({ L_max := 2 } : _root_.PillarA.LayerA.Policy b))) x := by
  exact _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.handoff_Lmax_eq_two_boundaryBall_contains_crossParent_of_refine
    (b := b) href hxy

/-- D2 marker: the observable dynamical closure question has an explicit
classical decision surface on the active ToC path. -/
theorem toc_observable_dynamics_decision_surface :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) ∨
      ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  exact dyn_top_ToC_preserves_N_add_top_or_not (b := b) (p := p)

/-- D2 normalization marker: the rich top minus-dynamics preserves the
observable top carrier at time `0`. -/
theorem toc_observable_dynamics_zero_marker :
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α 0)
      (observableTopCarrier_ToC (b := b) (p := p)) :=
  dyn_top_ToC_zero_preserves_N_add_top (b := b) (p := p)

end
end PillarB_ObservableDynamicsDecision


/-- D2c marker: every distinguished ToC basis region is a canonical `L`-ball. -/
@[simp] theorem toc_basis_region_eq_basic_ball
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u) :
    ∃ i : Ω (b := b) (p := p),
      u = boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i := by
  exact basic_region_eq_boundaryBallFromL (b := b) (p := p) hu

/-- D2c marker: same-ball localization of canonical basis-ball generators would
be sufficient for full observable-top preservation. -/
example : dyn_top_ToC_preserves_basic_ball_generator_localization (b := b) (p := p) →
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro h
  exact dyn_top_ToC_preserves_N_add_top_of_preserves_basic_ball_generator_localization
    (b := b) (p := p) h

/-- D2c time-zero sanity check. -/
example (i : Ω (b := b) (p := p))
    {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i ≤
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) 0 h A)) := by
  exact dyn_top_ToC_zero_preserves_basic_ball_generator_localization
    (b := b) (p := p) i A

end Meta
