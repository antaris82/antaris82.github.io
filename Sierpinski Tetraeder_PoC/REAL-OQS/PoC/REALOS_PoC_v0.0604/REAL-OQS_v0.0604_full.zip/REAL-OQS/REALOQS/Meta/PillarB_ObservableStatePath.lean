import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableStatePath

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
variable [Fact (0 < b)]

/-- The additive observable ToC subnet carries the induced local `StateNet`
obtained by restricting the rich local states. -/
theorem toc_observable_state_net :
    _root_.PillarA.LayerA.StateNet (Ω := Ω (b := b) (p := p)) :=
  SN_add_ToC (b := b) (p := p)

/-- The additive observable top state restricts to the additive local state on
any region. -/
theorem toc_observable_state_restrict_top
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    (SN_add_ToC (b := b) (p := p)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_add_ToC (b := b) (p := p)).LAN.RN) r)
        (ρAdd_top (b := b) (p := p)) =
      ρAdd_region (b := b) (p := p) r :=
  ρAdd_region_eq_restrict_top (b := b) (p := p) r

/-- The additive observable quasilocal state restricts to the corresponding
additive local state on every region. -/
theorem toc_observable_quasilocal_restrict
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))
        (Φ_add_FromA (b := b) (p := p))
        r =
      ρAdd_region (b := b) (p := p) r :=
  restrictToRegion_Φ_add_FromA (b := b) (p := p) r

end
end PillarB_ObservableStatePath
end Meta
