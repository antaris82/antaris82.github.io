import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ActivePath

noncomputable section

open _root_.PillarB.AQFT.Derived
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

@[simp] theorem toc_net_eq_boundaryMatrixLocalNet [Fact (0 < b)] :
    N_ToC (b := b) (p := p) =
      boundaryMatrixLocalNet (Ω := Ω (b := b) (p := p)) := by
  rfl

@[simp] theorem toc_rich_net_eq_toc_net [Fact (0 < b)] :
    N_rich_ToC (b := b) (p := p) = N_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem toc_rich_net_eq_boundaryMatrixRichNet [Fact (0 < b)] :
    N_rich_ToC (b := b) (p := p) =
      boundaryMatrixRichNet (Ω := Ω (b := b) (p := p)) := by
  rfl

@[simp] theorem toc_topStrong_eq_boundaryDensityStateAtBeta [Fact (0 < b)] :
    ρTopStrong (b := b) (p := p) =
      boundaryDensityStateAtBeta
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem toc_top_eq_boundaryMatrixTop [Fact (0 < b)] :
    ρTop (b := b) (p := p) =
      boundaryMatrixTop
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

end
end PillarB_ActivePath
end Meta
