import REALOQS.Meta.PillarB_RichAudit
import REALOQS.Meta.PillarB_ObservableAudit
import REALOQS.Meta.PillarB_ObservableDynamicsDecision
import REALOQS.Meta.PillarB_BQ8_Closed
import REALOQS.Meta.PillarB_BQ9_Closed

/-!
# Meta BuildAll

Optional build target for the consolidated Pillar B audit surfaces.

Grouping:
- `PillarB_RichAudit` packages the maintained rich/completion path.
- `PillarB_ObservableAudit` packages the additive observable subnet path.
- `PillarB_BQ8_Closed` / `PillarB_BQ9_Closed` remain the final closure markers.

This file is intentionally not imported by `REALOQS.BuildAll`.
-/
