import REALOQS.Meta.PillarB_ActivePath
import REALOQS.Meta.PillarB_NoConfigHarnessInCriticalPath
import REALOQS.Meta.PillarB_Closure_Target
import REALOQS.Meta.PillarB_StrictSurface
import REALOQS.Meta.PillarB_Closure_FromA_Strict

/-!
# Pillar B rich-path audit umbrella

Consolidated import surface for the maintained rich/completion branch of Pillar B.
This path carries the matrix/KMS/GNS/modular/quasilocal closure machinery and
remains separate from the additive observable subnet audit surface.
-/
