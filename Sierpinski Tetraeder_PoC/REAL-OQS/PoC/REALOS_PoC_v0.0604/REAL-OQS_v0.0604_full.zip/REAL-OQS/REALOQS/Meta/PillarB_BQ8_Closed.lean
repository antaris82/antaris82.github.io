import REALOQS.Meta.PillarB_StrictSurface

set_option autoImplicit false

namespace Meta
namespace PillarB_BQ8_Closed

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

theorem bq8_closed_marker [Fact (0 < b)] :
    N_ToC (b := b) (p := p) =
      _root_.PillarB.AQFT.Derived.boundaryMatrixLocalNet
        (Ω := Ω (b := b) (p := p)) := by
  rfl

end
end PillarB_BQ8_Closed
end Meta
