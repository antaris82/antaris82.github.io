import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_HK_Observable_Strict

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

/-- The additive observable ToC subnet satisfies injective isotony. -/
theorem toc_observable_isotony :
    _root_.PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_add_ToC (b := b) (p := p)) :=
  isotony_ToC_add (b := b) (p := p)

/-- The additive observable ToC subnet satisfies locality. -/
theorem toc_observable_locality :
    _root_.PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_add_ToC (b := b) (p := p))
      (D := _root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))) :=
  locality_ToC_add (b := b) (p := p)

/-- The additive observable ToC subnet satisfies basis-relative additivity. -/
theorem toc_observable_additivity_on_basis :
    _root_.PillarB.AQFT.Gates.HaagKastler.AdditivityOnBasis
      (N := N_add_ToC (b := b) (p := p))
      (B_add_ToC (b := b) (p := p)) :=
  additivity_basis_ToC_add (b := b) (p := p)

/-- The active observable HK package is now available on the ToC additive path. -/
def toc_observable_minimal :
    _root_.PillarB.AQFT.Gates.HaagKastler.ObservableMinimal
      (N := N_add_ToC (b := b) (p := p))
      (_root_.PillarB.AQFT.Derived.boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p)))
      (B_add_ToC (b := b) (p := p)) where
  isotony := toc_observable_isotony (b := b) (p := p)
  locality := toc_observable_locality (b := b) (p := p)
  additivityOnBasis := toc_observable_additivity_on_basis (b := b) (p := p)

end
end PillarB_HK_Observable_Strict
end Meta
