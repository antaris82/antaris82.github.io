import REALOQS.PillarC.Interface

/-!
# Pillar C canonical forwarder

This is the recommended entry point for `import REALOQS.PillarC`.
It forwards to the canonical, substrate-agnostic API surface:

- `REALOQS.PillarC.Interface`
-/
