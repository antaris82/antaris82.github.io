import Mathlib
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesAxisCanonicalD
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarB.AQFT.Derived.MatterFromPillarA

set_option autoImplicit false

/-!
# Example: Tree-of-Cliques signal/β/matter extraction from Pillar A

This module now separates three strict layers:

1. **signal extraction from A**,
2. **β extraction from that signal**,
3. a fully **derived** `MatterTemplate` whose remaining data `(d, φ)` are also
   built from the same canonical ToC scale profile.

No claims of physical correctness are made at this stage; the goal is
*determinism + non-vacuity* on the strict ToC → Pillar-A path.
-/

namespace REALOQS
namespace Examples
namespace TreeOfCliques_MatterFromA

noncomputable section

open _root_.PillarA
open _root_.PillarA.LayerA
open _root_.PillarA.Physics
open _root_.PillarB
open _root_.PillarB.AQFT
open _root_.PillarB.AQFT.Derived

namespace ToC

variable {b : Nat}

/-- Canonical dependent axis from Pillar A instances. -/
noncomputable abbrev axis
    (p : Policy b) :=
  _root_.PillarA.Physics.Instances.TreeOfCliques.ToC.axis_canonicalD
    (b := b) (p := p)

/-- Deterministic argmax scan for `breakMeasure` on the finite window `0..n`.

Tie-breaking is canonical: if the new value is greater-or-equal, keep the later
index.
-/
def argmaxBreakUpTo
    (A : ScaleBreakingAxisD (_root_.PillarA.Physics.Instances.TreeOfCliques.ToC.S b)) :
    Nat → Nat
  | 0 => 0
  | n + 1 =>
      let k := argmaxBreakUpTo A n
      if A.breakMeasure k ≤ A.breakMeasure (n + 1) then n + 1 else k

/-- Canonical scale-selection window from the policy. -/
def kWindow (p : Policy b) : Nat := p.K_max

/-- Deterministic choice of the scale at which we sample the A-diagnostic. -/
noncomputable def kStar (p : Policy b) : Nat :=
  argmaxBreakUpTo (b := b) (axis (b := b) p) (kWindow p)

/-- Real-valued diagnostic signal extracted from the canonical axis at scale `k`. -/
noncomputable def signalAt
    (p : Policy b)
    (k : Nat) : ℝ :=
  ((axis (b := b) p).breakMeasure k).toReal

/-- Canonical scalar signal extracted from Pillar A. -/
noncomputable def signalFromA (p : Policy b) : ℝ :=
  signalAt (b := b) p (kStar (b := b) p)

/-- Canonical inverse temperature derived from the Pillar-A signal. -/
noncomputable def betaFromA (p : Policy b) : ℝ :=
  betaFromSignal (signalFromA (b := b) p)

/-- Number of local configuration values derived from the ToC scale window. -/
def dFromA (p : Policy b) : Nat :=
  kWindow p + 1

theorem dFromA_pos (p : Policy b) : 0 < dFromA (b := b) p := by
  simp [dFromA, kWindow]

/-- Canonical local-value embedding derived from the ToC break profile.

The finite value set is indexed by the strict scale window `0..K_max`; each
value is embedded as the real mismatch signal at the corresponding scale.
-/
noncomputable def phiFromA
    (p : Policy b) : Fin (dFromA (b := b) p) → ℝ :=
  fun i => signalAt (b := b) p i.1

/-- Fully derived matter template from the canonical ToC profile. -/
noncomputable def matterFromA
    (p : Policy b) : MatterTemplate :=
  { d := dFromA (b := b) p
    d_pos := dFromA_pos (b := b) p
    β := betaFromA (b := b) p
    φ := phiFromA (b := b) p }

theorem betaFromA_pos (p : Policy b) :
    0 < betaFromA (b := b) p := by
  simpa [betaFromA] using
    (betaFromSignal_pos (signalFromA (b := b) p))

theorem matterFromA_beta_pos (p : Policy b) :
    0 < (matterFromA (b := b) p).β := by
  simpa [matterFromA, betaFromA] using
    (betaFromSignal_pos (signalFromA (b := b) p))

theorem beta_pos (p : Policy b) :
    0 < (matterFromA (b := b) p).β := by
  simpa using matterFromA_beta_pos (b := b) p

@[simp] theorem matterFromA_d (p : Policy b) :
    (matterFromA (b := b) p).d = dFromA (b := b) p := rfl

@[simp] theorem matterFromA_phi (p : Policy b) :
    (matterFromA (b := b) p).φ = phiFromA (b := b) p := rfl

end ToC

end
end TreeOfCliques_MatterFromA
end Examples
end REALOQS
