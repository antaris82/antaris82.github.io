import Mathlib

import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
import REALOQS.PillarB.AQFT.Derived.LocalConfigNet
import REALOQS.PillarB.AQFT.Gates.SplitProperty
import REALOQS.PillarB.AQFT.HaagKastler.SupportFull
import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_AQFT_HK_Instances

noncomputable section

open _root_.PillarB
open _root_.PillarB.AQFT

/-!
# Phase 8 (Examples): minimal Haag–Kastler / Split / KMS instances for strict ToC nets

This module provides **compile-time, concrete witnesses** for a few long-term
AQFT “gate surfaces”, in a way that remains compatible with the current
lightweight Pillar-B design:

* `Gates.SplitProperty` witness (factor-through via the larger algebra)
* a concrete `KMSState` using **trivial dynamics** and the **zero functional**
* a tiny “spectrum condition” witness (support = forward cone)

The goal is **not** physical realism, but ensuring the interfaces are
**populatable by derived instances**.
-/

/-! ## Generic KMS demo: trivial dynamics + constant functional -/

namespace KMSDemo

variable {A : Type} (SA : _root_.PillarB.AQFT.StarAlgebra A)

/-- Constant functional on any carrier `A`.

This is intentionally *not* claimed to be positive/normalized; it only
serves to populate the KMS strip interface without additional structure.
-/
def oneState : _root_.PillarB.AQFT.StateOn A :=
  { toFun := fun _ => 1 }

@[simp] theorem oneState_apply (a : A) : (oneState (A := A)) a = 1 := rfl

/-- Trivial dynamics: every time-evolution map is the identity *-homomorphism. -/
def trivialDyn : _root_.PillarB.AQFT.StarAlgDynamics (SA := SA) :=
  { α := fun _t => _root_.PillarB.AQFT.StarAlgHom.id SA
    map_zero := rfl
    map_add := by
      intro s t
      -- Both sides are the identity *-homomorphism; extensionality suffices.
      apply _root_.PillarB.AQFT.StarAlgHom.ext
      intro x
      rfl }

/-- Constant functional is invariant under any dynamics (hence under the trivial one). -/
theorem one_invariant :
    _root_.PillarB.AQFT.IsInvariant (SA := SA)
      (trivialDyn (SA := SA)) (oneState (A := A)) := by
  intro t a
  simp [trivialDyn, oneState]

/-- KMS strip condition for the trivial dynamics and the constant functional at `β = 1`. -/
theorem one_kmsStrip :
    _root_.PillarB.AQFT.KMSStrip (SA := SA)
      (trivialDyn (SA := SA)) 1 (oneState (A := A)) := by
  intro a b
  refine ⟨fun _z : Complex => 1, ?_, ?_, ?_, ?_⟩
  · exact
      (differentiableOn_const (c := (1 : Complex)) :
        DifferentiableOn Complex (fun _z : Complex => (1 : Complex))
          {z : Complex | 0 < z.im ∧ z.im < (1 : ℝ)})
  · exact
      (continuousOn_const (c := (1 : Complex)) :
        ContinuousOn (fun _z : Complex => (1 : Complex))
          {z : Complex | 0 ≤ z.im ∧ z.im ≤ (1 : ℝ)})
  · intro t
    simp [trivialDyn, oneState]
  · intro t
    simp [trivialDyn, oneState]

/-- Bundle: a concrete (though not physically meaningful) KMS state at `β = 1`. -/
def oneKMSState : _root_.PillarB.AQFT.KMSState (SA := SA) :=
  { β := 1
    dyn := trivialDyn (SA := SA)
    state := oneState (A := A)
    isKMS :=
      { beta_pos := by
          norm_num
        invariant := one_invariant (SA := SA)
        kmsStrip := one_kmsStrip (SA := SA) } }

end KMSDemo

/-! ## Split property demo: factor through the larger algebra -/

namespace SplitDemo

universe u

variable {Ω : Type u}
variable (N : _root_.PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω))

/-- A split witness for any refinement `a ≤ b`:

Take the intermediate algebra as `F := N(b)` and maps

`N(a) --incl--> N(b) --id--> N(b)`.

`isTypeI` stays a **named gate** at this stage.
-/
def splitWitness_trivial
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    _root_.PillarB.AQFT.Gates.SplitWitness (N := N) hab :=
  { F := N.LAN.Alg b
    SF := N.SA b
    ι₁ := N.inclHom (a := a) (b := b) hab
    ι₂ := _root_.PillarB.AQFT.StarAlgHom.id (N.SA b)
    comp_eq := by
      apply _root_.PillarB.AQFT.StarAlgHom.ext
      intro x
      rfl
    isTypeI := _root_.PillarB.AQFT.Gates.TypeIPlaceholder }

theorem splitProperty_trivial : _root_.PillarB.AQFT.Gates.SplitProperty (N := N) := by
  intro a b hab
  exact ⟨splitWitness_trivial (N := N) hab⟩

end SplitDemo

/-! ## Tiny spectrum witness (support = ForwardCone) -/

namespace SpectrumDemo

open _root_.PillarB.AQFT.HaagKastler

/-- Trivial representation data for `G = PUnit`. -/
def repDataPUnit : RepData PUnit where
  H := PUnit
  U := fun _ => Equiv.refl _

/-- Spectrum witness: choose `support := ForwardCone` (tautologically positive-energy). -/
def spectrumWitnessForward : SpectrumWitness where
  support := ForwardCone
  support_subset_forward := by
    intro p hp
    exact hp

def spectrumConditionPUnit : SpectrumCondition PUnit where
  rep := repDataPUnit
  spec := spectrumWitnessForward

end SpectrumDemo

/-! ## Instantiations for the Tree-of-Cliques derived net -/

namespace ToC

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)
abbrev N_ToC : _root_.PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.localStarAlgebraNet
    (Ω := Ω (b := b) (p := p)) ((T (b := b) p).d)

theorem splitProperty_ToC :
    _root_.PillarB.AQFT.Gates.SplitProperty (N := N_ToC (b := b) (p := p)) := by
  exact SplitDemo.splitProperty_trivial (N := N_ToC (b := b) (p := p))

/-!
A concrete KMS state on the **quasilocal** carrier is intentionally out of scope
here. As a minimal non-vacuous instantiation we provide a KMS state on the
local algebra at a chosen region.
-/

variable (r : (N_ToC (b := b) (p := p)).LAN.RN.Region)

def kms_local_demo :
    _root_.PillarB.AQFT.KMSState (SA := (N_ToC (b := b) (p := p)).SA r) :=
  KMSDemo.oneKMSState (SA := (N_ToC (b := b) (p := p)).SA r)

end ToC

end

end TreeOfCliques_AQFT_HK_Instances
end Examples
end REALOQS
