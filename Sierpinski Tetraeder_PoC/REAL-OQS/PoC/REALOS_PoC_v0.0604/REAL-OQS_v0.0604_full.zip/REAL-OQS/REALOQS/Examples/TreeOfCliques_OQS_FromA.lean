import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
import REALOQS.Examples.TreeOfCliques_OQS_CompilerFromA

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_OQS_FromA

/-!
# Phase 8/9 (Example): end-to-end OQS surface derived from the strict A/B handoff

This module specializes the strict compiler to the canonical exported stage-1
state `st1 := reduce(stLap)` from the A/B handoff and re-exports the resulting
channel/semantics on the handoff carrier `Ω(p)`.
-/

noncomputable section

namespace ToC

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
open REALOQS.Examples.TreeOfCliques_OQS_CompilerFromA.ToC

variable {b : Nat}

/-- The canonical stage-1 A/B state entering Pillar C. -/
abbrev st1AB (p : _root_.PillarA.LayerA.Policy b) :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.st1 (b := b) p

/-- End-to-end A/B → C channel on the exported handoff carrier. -/
def Φ_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  compileChannel (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_isCP
    (p : _root_.PillarA.LayerA.Policy b) :
    (Φ_oqs_fromA (b := b) p).isCP := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_isCP (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_isTP
    (p : _root_.PillarA.LayerA.Policy b) :
    (Φ_oqs_fromA (b := b) p).isTP := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_isTP (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_hasStinespring
    (p : _root_.PillarA.LayerA.Policy b) :
    _root_.PillarC.OQS.HasStinespring (Φ_oqs_fromA (b := b) p) := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_hasStinespring (b := b) p (st1AB (b := b) p)

/-- Derived semigroup specialized to the canonical A/B handoff state. -/
def S_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedSemigroup (b := b) p (st1AB (b := b) p)

/-- Derived generator specialized to the canonical A/B handoff state. -/
def G_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedGenerator (b := b) p (st1AB (b := b) p)

/-- Derived process specialized to the canonical A/B handoff state. -/
def P_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedProcess (b := b) p (st1AB (b := b) p)

theorem G_oqs_fromA_generates
    (p : _root_.PillarA.LayerA.Policy b) :
    (G_oqs_fromA (b := b) p).Generates (S_oqs_fromA (b := b) p) := by
  simpa [G_oqs_fromA, S_oqs_fromA, st1AB] using
    derivedGenerator_generates (b := b) p (st1AB (b := b) p)

theorem P_oqs_fromA_memoryLaw
    (p : _root_.PillarA.LayerA.Policy b) :
    (P_oqs_fromA (b := b) p).memoryLaw := by
  simpa [P_oqs_fromA, st1AB] using
    derivedProcess_memoryLaw (b := b) p (st1AB (b := b) p)

end ToC

end
end TreeOfCliques_OQS_FromA
end Examples
end REALOQS
