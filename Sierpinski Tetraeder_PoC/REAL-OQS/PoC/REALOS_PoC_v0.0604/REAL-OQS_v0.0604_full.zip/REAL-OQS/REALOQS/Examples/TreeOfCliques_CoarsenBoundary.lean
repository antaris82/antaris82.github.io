import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary

set_option autoImplicit false

/-!
# Tree-of-Cliques: canonical boundary coarsening (`π_k`) and matrix coarsen/refine

This `Examples` module is a thin re-export wrapper.
The canonical definitions live in
`REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary`.
-/

namespace REALOQS
namespace Examples
namespace TreeOfCliques_CoarsenBoundary

noncomputable section

namespace ToC

export _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary
  (Boundary π mkChild π_mkChild mkChild_injective
   fiber mem_fiber_iff fiber_eq_image_mkChild fiber_card
   coarsenMat refineMat coarsenMat_refineMat
   idealTower coarsenMat_idealTower)

end ToC

end
end TreeOfCliques_CoarsenBoundary
end Examples
end REALOQS
