import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
import REALOQS.PillarB.AQFT.Derived.QuasiLocalStateFromConfigNet

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_AQFT_Derived

/-!
# Legacy / exogenous Tree-of-Cliques AQFT witness

This module retains the **older exogenous AQFT path** where the local-value count
`d` and the top configuration `σ0` are supplied from outside.

It is kept only for backwards compatibility and comparison. It is **not** part of
the strict closure path `A → B`, which now runs through
`REALOQS.Examples.TreeOfCliques_AQFT_FromA`.
-/

noncomputable section

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
open _root_.PillarB.AQFT.Derived

variable {b : Nat}

/-- The concrete site type induced by the Tree-of-Cliques approximant. -/
abbrev Ω (p : _root_.PillarA.LayerA.Policy b) : Type :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.V (p := p)

namespace ToC

variable (p : _root_.PillarA.LayerA.Policy b)

-- We keep instances local to avoid any global pollution.
instance : Fintype (Ω (p := p)) := by
  infer_instance

instance : DecidableEq (Ω (p := p)) := by
  classical
  exact Classical.decEq _

variable (d : Nat)

-- A user-supplied top configuration (required for the evaluation state).
variable (σ0 : Cfg (Ω := Ω (p := p)) d (Finset.univ : Finset (Ω (p := p))))

/-- Tree-of-Cliques specialized derived local *-algebra net. -/
abbrev LSAN_ToC : _root_.PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω (p := p)) :=
  localStarAlgebraNet (Ω := Ω (p := p)) d

/-- Tree-of-Cliques specialized derived state net (canonical). -/
abbrev SN_ToC : _root_.PillarA.LayerA.StateNet (Ω := Ω (p := p)) :=
  stateNet (Ω := Ω (p := p)) d

/-- Tree-of-Cliques specialized global cone from the evaluation top state. -/
abbrev Cone_ToC :
    _root_.PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω (p := p)) d) :=
  globalCone (Ω := Ω (p := p)) d σ0

/-- Tree-of-Cliques specialized quasilocal state obtained by lifting the cone. -/
def Φ_ToC (p : _root_.PillarA.LayerA.Policy b) (d : Nat)
    (σ0 : Cfg (Ω := Ω (b := b) p) d (Finset.univ : Finset (Ω (b := b) p))) :
    _root_.PillarB.AQFT.StateOn
      (_root_.PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω (b := b) p)
        (N := localStarAlgebraNet (Ω := Ω (b := b) p) d)) :=
  quasiLocalState (Ω := Ω (b := b) p) d σ0

/-! ## Minimal regression gate (restriction recovers the cone) -/

example :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω (p := p))
        (N := localStarAlgebraNet (Ω := Ω (p := p)) d) (Φ_ToC (b := b) p d σ0)
        (Finset.univ : Finset (Ω (p := p))) =
      (globalConeQL (Ω := Ω (p := p)) d σ0).ω
        (Finset.univ : Finset (Ω (p := p))) := by
  simpa [Φ_ToC] using
    (_root_.PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω (p := p)) (N := localStarAlgebraNet (Ω := Ω (p := p)) d)
      (C := globalConeQL (Ω := Ω (p := p)) d σ0)
      (r := (Finset.univ : Finset (Ω (p := p)))))

end ToC

end

end TreeOfCliques_AQFT_Derived
end Examples
end REALOQS
