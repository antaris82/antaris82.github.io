import Mathlib

import REALOQS.Examples.TreeOfCliques_CoarsenBoundary
import REALOQS.PillarC.OQS.Channel
import REALOQS.PillarC.OQS.Stinespring
import REALOQS.PillarC.OQS.Finite.RectKraus

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_OQS_FromCoarsen

noncomputable section

open scoped BigOperators

namespace ToC

open REALOQS.Examples.TreeOfCliques_CoarsenBoundary.ToC

/-!
# Phase 7 (Example): an OQS channel derived from canonical boundary coarsening

This file constructs a **deterministic** example of a (gate-level) CPTP channel
on boundary matrix algebras derived from the canonical parent map `π`.

We keep the semantics deliberately lightweight:

* we expose a **rectangular Kraus** shape (input/output dimensions can differ),
* we define a canonical Kraus family implementing a **partial-trace-like**
  coarse map on the boundary product structure `Boundary (k+1) ≈ Boundary k × Fin b`,
* the `CPTPChannel` is populated with **nontrivial** CP/TP gate predicates.

No analytic operator theory is used here.
-/

variable {b k : Nat}

abbrev Mat (α : Type) := _root_.PillarC.OQS.Finite.RectKraus.Mat α

abbrev RectMat (α β : Type) := _root_.PillarC.OQS.Finite.RectKraus.RectMat α β

abbrev RectKrausOps (α β : Type) (r : Nat) :=
  _root_.PillarC.OQS.Finite.RectKraus.RectKrausOps α β r

/-! ## Rectangular Kraus packaging (Example-level only) -/

/-- Rectangular Kraus action `ρ ↦ ∑ᵢ Kᵢ ρ Kᵢ⋆` for `Kᵢ : α ← β`. -/
abbrev rectKrausMap
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Mat β → Mat α :=
  _root_.PillarC.OQS.Finite.RectKraus.rectKrausMap (α := α) (β := β) r K

/-- Trace-preservation gate for rectangular Kraus families: `∑ᵢ Kᵢ⋆ Kᵢ = 1`. -/
abbrev RectKrausTP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Prop :=
  _root_.PillarC.OQS.Finite.RectKraus.RectKrausTP (α := α) (β := β) r K

/-- CP gate: “there exists a rectangular Kraus representation with `r` terms”. -/
abbrev IsRectKrausCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (Φ : Mat β → Mat α) : Prop :=
  _root_.PillarC.OQS.Finite.RectKraus.IsRectKrausCP (α := α) (β := β) r Φ

/-- Package a rectangular Kraus map as a (gate-level) `CPTPChannel`. -/
abbrev rectKrausChannel
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    _root_.PillarC.OQS.CPTPChannel (Mat β) (Mat α) :=
  _root_.PillarC.OQS.Finite.RectKraus.rectKrausChannel (α := α) (β := β) r K

theorem rectKrausChannel_isCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    (rectKrausChannel (α := α) (β := β) r K).isCP := by
  simpa [rectKrausChannel] using
    (_root_.PillarC.OQS.Finite.RectKraus.rectKrausChannel_isCP (α := α) (β := β) r K)

/-! ## The Tree-of-Cliques coarse channel (partial trace on the child digit) -/

/-- Canonical Kraus family implementing a partial-trace-like coarse map. -/
def ptraceKraus (b k : Nat) :
    RectKrausOps (Boundary b k) (Boundary b (k + 1)) b :=
  fun d =>
    fun i x => if x = mkChild b k i d then (1 : Complex) else 0

/-- The induced coarse map on boundary matrix algebras. -/
def ptraceMap (b k : Nat) :
    Mat (Boundary b (k + 1)) → Mat (Boundary b k) :=
  rectKrausMap (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k)

/-- `CPTPChannel` package for `ptraceMap` (gate-level CP/TP are nontrivial predicates). -/
def ptraceCPTP (b k : Nat) :
    _root_.PillarC.OQS.CPTPChannel (Mat (Boundary b (k + 1))) (Mat (Boundary b k)) :=
  rectKrausChannel (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k)

theorem ptraceCPTP_isCP (b k : Nat) : (ptraceCPTP b k).isCP := by
  -- Unfold once and exhibit the Kraus family.
  change IsRectKrausCP (α := Boundary b k) (β := Boundary b (k + 1)) b
      (rectKrausMap (α := Boundary b k) (β := Boundary b (k + 1)) b (ptraceKraus b k))
  exact ⟨ptraceKraus b k, rfl⟩

/-! ## Minimal Stinespring witness (still gate-level) -/

/-- A minimal Stinespring witness for `ptraceCPTP` using an explicit `Fin b` environment.

At this layer, `dilationEq` is only a gate predicate, so we keep the witness
structural and avoid analytic commitments.
-/
def stinespring_ptrace (b k : Nat) (hb : 0 < b) :
    _root_.PillarC.OQS.StinespringDilation (ptraceCPTP b k) := by
  let Φ := ptraceCPTP b k
  refine
    { E := Fin b
      V := fun ρ => (Φ.map ρ, ⟨0, hb⟩)
      discard := fun be => be.1
      dilationEq :=
        ∀ ρ : Mat (Boundary b (k + 1)),
          (fun be : Mat (Boundary b k) × Fin b => be.1) (Φ.map ρ, ⟨0, hb⟩) = Φ.map ρ }

-- We expose the existence gate only when `b > 0` (so the `Fin b` environment is inhabited).
theorem hasStinespring_ptrace (b k : Nat) (hb : 0 < b) :
    _root_.PillarC.OQS.HasStinespring (ptraceCPTP b k) := by
  exact ⟨stinespring_ptrace (b := b) (k := k) hb⟩

end ToC

end

end TreeOfCliques_OQS_FromCoarsen
end Examples
end REALOQS
