import Mathlib
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarA.Update.TailEliminationDtN
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.Examples.TreeOfCliques_RealTower_FromDtNStabilized
import REALOQS.Examples.TreeOfCliques_CoarsenBoundary

set_option autoImplicit false

/-!
# Tree-of-Cliques: varying-scale scale-breaking axis harness (build-only)

This module is a **typing harness** for Phase 7.

It shows that we can express a `ScaleBreakingAxisD` where both

* the interface `α k` (boundary type) and
* the carrier `S k` (here: boundary-boundary matrices)

depend on the scale `k`, and that we can define a mismatch-based diagnostic
`breakMeasure k` without constant-Σ hacks.

The REAL tower is provided by stabilized DtN with a canonically discharged
invertibility gate.
-/

namespace REALOQS
namespace Examples
namespace TreeOfCliques_ScaleAxisHarness

noncomputable section

open _root_.PillarA
open _root_.PillarA.Update
open _root_.PillarA.Physics

namespace ToC

open _root_.PillarA.LayerA

variable {b : Nat}

/-- Boundary family at scale `k`. -/
abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

/-- Carrier family at scale `k`: boundary-boundary matrices. -/
abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

/-- REAL tower on the boundary, provided by stabilized DtN (gate discharged). -/
noncomputable abbrev realTower (b : Nat) (p : Policy b) : ∀ k, S b k :=
  _root_.REALOQS.Examples.TreeOfCliques_RealTower_FromDtNStabilized.ToC.realTower
    (b := b) (p := p)

/-! ## Canonical observer and mismatch family -/

/-- Observe a boundary matrix as a `LinOp` via `mulVec`. -/
noncomputable def Obs (b : Nat) : OpObserverD (S b) (α b) := by
  classical
  refine { op := ?_ }
  intro k M
  exact _root_.PillarA.Update.linOpOfMatrix (α := α b k) M

/-- Frobenius-norm mismatch on each boundary type `α k`. -/
noncomputable def M (b : Nat) : ∀ k, MismatchFunctional (α := α b k) := by
  classical
  intro k
  exact _root_.PillarA.Update.MismatchFunctional.NormDiff.mkId (α := α b k)

/-! ## Harness axis (qualitative skeleton + mismatch upgrade) -/

/-- A qualitative dependent axis skeleton (diagnostics set to `0`).

`coarsen` and `ideal` remain parameters; `real` is provided by stabilized DtN.
-/
def axis0
    (p : Policy b)
    (coarsen : ∀ k, S b (k + 1) → S b k)
    (ideal : ∀ k, S b k) :
    ScaleBreakingAxisD (S b) :=
  { coarsen := coarsen
    , ideal := ideal
    , real := realTower (b := b) (p := p)
    , breakMeasure := fun _ => 0
    , breakMeasureIdeal := fun _ => 0 }

/-- Mismatch-upgraded axis: replaces `breakMeasure/*Ideal` by mismatch diagnostics. -/
noncomputable def axis
    (p : Policy b)
    (coarsen : ∀ k, S b (k + 1) → S b k)
    (ideal : ∀ k, S b k)
    (eps : ℝ) (eps_pos : eps > 0) :
    ScaleBreakingAxisD (S b) :=
  axis_fromMismatchD
    (S := S b) (α := α b)
    (A := axis0 (b := b) p coarsen ideal)
    (Obs := Obs b)
    (M := M b)
    (eps := eps) (eps_pos := eps_pos)

/-!
## Phase 7.C: canonical coarsen and IDEAL tower
-/

/-- Canonical coarsening on boundary matrices induced by `π_k`. -/
noncomputable abbrev coarsenCanonical (b : Nat) : ∀ k, S b (k + 1) → S b k :=
  fun k =>
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat (b := b) (k := k)

/-- Canonical IDEAL tower induced by uniform refinement (`refineMat`). -/
noncomputable abbrev idealCanonical (b : Nat) : ∀ k, S b k :=
  _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.idealTower (b := b)

/-- Phase-7 target: a fully canonical axis (no `coarsen/ideal` parameters). -/
noncomputable def axis_canonical
    (p : Policy b) :
    ScaleBreakingAxisD (S b) :=
  axis
    (b := b) (p := p)
    (coarsen := coarsenCanonical (b := b))
    (ideal := idealCanonical (b := b))
    (eps := p.eps) (eps_pos := p.eps_pos)

end ToC

end
end TreeOfCliques_ScaleAxisHarness
end Examples
end REALOQS
