import Mathlib
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized

set_option autoImplicit false

/-!
# Tree-of-Cliques: stabilized DtN end-to-end (concrete under gate)

This file is intentionally **build-only**.

It shows that we can construct a *concrete* `ReducedOpState` for the stabilized DtN
carrier **provided** the single determinant gate

`det (LII_stabilized (L0)) ≠ 0`

is supplied.

No numerical claims are made.
-/

namespace REALOQS
namespace Examples
namespace TreeOfCliques_EndToEnd_StabilizedConcrete

noncomputable section

namespace ToC

open _root_.PillarA.LayerA

open _root_.PillarA.Ideal.Adapter
open _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized

variable {b : Nat} (p : _root_.PillarA.LayerA.Policy b)

/-!
## Concrete state (under the gate)
-/

variable (h : hdet0 (p := p))

/-- A concrete Laplacian-derived state exists under the single gate `hdet0`. -/
abbrev st : ReducedOpState p := ofLaplacian (p := p) h

-- Smoke test: stage-1 is available and typechecks.
abbrev A : _root_.PillarA.Update.TwoStageApprox.{0} b := mk (b := b) p

abbrev st_stage1 : (A (p := p)).S := (A (p := p)).stage1 (st (p := p) h)

/-!
## Sanity lemmas

These connect the concrete state to the canonical Laplacian source `L0`, and to
the stabilized DtN reduction.
-/

theorem fullMatrix_st : fullMatrix (p := p) (st (p := p) h) = L0 (p := p) := by
  simpa [st] using fullMatrix_ofLaplacian (p := p) h

theorem reduce_LBB_st :
    (reduce (p := p) (st (p := p) h)).LBB =
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized_of_det
        (b := b) (p := p) (k := k p)
        (hdet := by
          -- The required gate is definitional (same as `hdet0`).
          simpa [_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab,
            _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s,
            _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L,
            LII_stab0, L0, sSplit, k] using (show (LII_stab0 (p := p)).det ≠ 0 from h)) := by
  -- Reuse the end-to-end lemma from the adapter (and unfold `st`).
  simpa [st, stLap] using reduce_LBB_eq_dtn_stab (p := p)

end ToC

end
end TreeOfCliques_EndToEnd_StabilizedConcrete
end Examples
end REALOQS
