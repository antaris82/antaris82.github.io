import Mathlib
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized

set_option autoImplicit false

/-!
# Tree-of-Cliques: REAL tower from stabilized DtN (build-only)

`k ↦ DtN_stabilized(L_k)` as a boundary-boundary matrix on `Boundary b k`.

The stabilized determinant gate is discharged canonically in
`PillarA.Ideal.TreeOfCliques.DtNStabilizedGate`, so this tower is parameter-free.
-/

namespace REALOQS
namespace Examples
namespace TreeOfCliques_RealTower_FromDtNStabilized

noncomputable section

namespace ToC

open _root_.PillarA

variable {b : Nat}

/-- Boundary family at scale `k` for Tree-of-Cliques. -/
abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

/-- Carrier family at scale `k`: boundary-boundary matrices. -/
abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

/-- The REAL tower: stabilized DtN on the Tree-of-Cliques Laplacian at each scale. -/
noncomputable def realTower (p : _root_.PillarA.LayerA.Policy b) : ∀ k, S b k :=
  fun k =>
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
      (b := b) (p := p) (k := k)

end ToC

end
end TreeOfCliques_RealTower_FromDtNStabilized
end Examples
end REALOQS
