import REALOQS.PillarB.Interface

/-!
# Pillar B canonical forwarder

This is the recommended entry point for `import REALOQS.PillarB`.
It forwards to the canonical, substrate-agnostic API surface:

- `REALOQS.PillarB.Interface`

Design intent:
- Pillar B depends on Pillar A only through its core exports.
- No IDEAL adapters.
- No heavy umbrellas.
-/
