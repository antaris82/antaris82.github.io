import REALOQS.PillarA.Interface

/-!
# Pillar A canonical forwarder

This is the recommended entry point for `import REALOQS.PillarA`.
It forwards to the canonical, substrate-agnostic API surface:

- `REALOQS.PillarA.Interface`

For the heavy developer umbrella (incl. IDEAL adapters and scaffolds), use:

- `REALOQS.PillarA.All`
-/
