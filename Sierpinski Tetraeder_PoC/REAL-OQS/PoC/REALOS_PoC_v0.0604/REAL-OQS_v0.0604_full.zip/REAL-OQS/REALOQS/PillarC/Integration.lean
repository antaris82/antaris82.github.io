import REALOQS.PillarC.Integration.BuildAll

set_option autoImplicit false

/-!
# Pillar C Integration (Phase 9)

Recommended entry point for Phase-9 cross-pillar glue.

Modules:
- `PillarC.Integration.Locality`: locality / influence hooks for net-indexed channels
- `PillarC.Integration.DerivedSpacetime`:
  derive a `PillarA.Kinematics.DiscreteSpacetime` from influence
- `PillarC.Integration.TailElimAsChannel`:
  export Pillar-A tail-elimination as a Pillar-C channel

All constructs are deliberately gate-oriented and avoid analytic commitments.
-/

namespace PillarC
namespace Integration

-- No additional declarations here; this file is a canonical forwarder.

end Integration
end PillarC
