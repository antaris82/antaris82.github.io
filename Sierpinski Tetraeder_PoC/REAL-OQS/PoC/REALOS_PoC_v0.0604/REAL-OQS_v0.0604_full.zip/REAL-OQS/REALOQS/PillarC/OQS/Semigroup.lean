import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS

/-!

# OQS: Markov semigroups (Phase 8)

A *Markov semigroup* on a carrier `A` is represented as a family of CPTP
channels indexed by a time parameter.

For Phase 8 we use **discrete time** (`Nat`) to avoid importing any additional
algebraic hierarchy (e.g. additive monoids on a general time type). A later
refinement can switch to `ℝ≥0` (or an abstract ordered additive monoid) without
changing the rest of Pillar C.

At this stage we keep the interface intentionally lightweight:
- no continuity / strong continuity requirements
- no generator is constructed here (see `Lindblad.lean` for a hook)

The laws are given on the underlying functions. This avoids committing to a
particular category structure on channels.
-/

universe u

/-- A (gate-level) Markov semigroup of CPTP channels on `A` (discrete time). -/
structure MarkovSemigroup (A : Type u) where
  Φ : Nat → CPTPChannel A A
  map_zero : ∀ x : A, (Φ 0).toChannel.map x = x
  map_add : ∀ (t s : Nat) (x : A),
    (Φ (t + s)).toChannel.map x = (Φ t).toChannel.map ((Φ s).toChannel.map x)

namespace MarkovSemigroup

variable {A : Type u} (S : MarkovSemigroup (A := A))

@[simp] theorem gate_map_zero (x : A) : (S.Φ 0).toChannel.map x = x :=
  S.map_zero x

theorem gate_map_add (t s : Nat) (x : A) :
    (S.Φ (t + s)).toChannel.map x = (S.Φ t).toChannel.map ((S.Φ s).toChannel.map x) :=
  S.map_add t s x


end MarkovSemigroup

end OQS
end PillarC
