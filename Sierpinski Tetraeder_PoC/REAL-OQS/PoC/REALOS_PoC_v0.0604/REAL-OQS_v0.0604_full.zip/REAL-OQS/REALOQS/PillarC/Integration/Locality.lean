import Mathlib

import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

/-!
REALOQS / Pillar C / Integration: Locality & support skeletons (Phase 9)

Goal:
- Provide a *stable, gate-oriented* surface to talk about locality/support of
  OQS channels on region-indexed AQFT nets.

This is intentionally minimalist:
- no analytic structure
- no vN algebra commitments
- influence/support propagation is encoded as a *predicate* to be strengthened later
- naturality w.r.t. isotony is required as the only hard law
-/

namespace PillarC
namespace Integration

open PillarA.LayerA

universe u v w

/--
A channel acting on every local algebra of a `LocalAlgebraNet`, natural w.r.t. isotony.

Interpretation (Heisenberg picture): `map r` updates observables localized in region `r`.

Later layers can refine this to *-homomorphisms, CP maps, or normal maps.
-/
structure NetChannel {Ω : Type u} (LAN : LocalAlgebraNet (Ω := Ω)) where
  map : ∀ r : LAN.RN.Region, LAN.Alg r → LAN.Alg r
  respects_incl : ∀ {a b : LAN.RN.Region} (hab : a ≤ b) (x : LAN.Alg a),
      LAN.incl hab (map a x) = map b (LAN.incl hab x)

namespace NetChannel

variable {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)}

instance : CoeFun (NetChannel LAN) (fun _ => ∀ r : LAN.RN.Region, LAN.Alg r → LAN.Alg r) where
  coe Φ := Φ.map

@[simp] theorem gate_respects_incl (Φ : NetChannel LAN)
    {a b : LAN.RN.Region} (hab : a ≤ b) (x : LAN.Alg a) :
    LAN.incl hab (Φ.map a x) = Φ.map b (LAN.incl hab x) :=
  Φ.respects_incl hab x

end NetChannel

/--
Attach a *site-level* influence relation to a net channel.

`inf x y` is intended to mean:
"a one-tick application of the channel can make observables at site `y`
 depend on degrees of freedom at site `x`".

We keep this as a hook (a Prop-valued relation) because the precise definition
depends on the chosen localization semantics (support of observables, conditional
expectations, split property, Lieb–Robinson type bounds, ...).
-/
structure ChannelInfluence {Ω : Type u} (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) where
  /-- Raw influence predicate (non-reflexive in general). -/
  inf0 : Ω → Ω → Prop

namespace ChannelInfluence
variable {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)} {Φ : NetChannel LAN}

/--
A strictness predicate for influence: there exists at least one genuinely off-diagonal influence.

This rules out the degenerate diagonal influence relation.
-/
def inf (I : ChannelInfluence LAN Φ) (x y : Ω) : Prop := x = y ∨ I.inf0 x y

/-- Reflexivity holds definitionally for `inf`. -/
@[simp] theorem sound (I : ChannelInfluence LAN Φ) (x : Ω) : I.inf x x := Or.inl rfl

/-- The diagonal influence relation: only `x` influences `x`.

This provides a canonical baseline `ChannelInfluence` instance that is
definitionally sound and never requires additional structure.
-/
def diagonal (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) : ChannelInfluence LAN Φ :=
  { inf0 := fun _ _ => False }

/--
A strictness predicate for influence. There exists at least one genuinely off-diagonal influence.
This rules out the degenerate diagonal influence relation.
-/
def Nondegenerate (I : ChannelInfluence LAN Φ) : Prop :=
    ∃ x y : Ω, x ≠ y ∧ I.inf0 x y

/-- The diagonal influence relation is degenerate: it cannot be nondegenerate. -/
theorem diagonal_degenerate (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) :
      ¬ Nondegenerate (LAN := LAN) (Φ := Φ)
          (ChannelInfluence.diagonal (LAN := LAN) (Φ := Φ)) := by
    intro h
    rcases h with ⟨x, y, hxy, hinf⟩
    cases hinf

end ChannelInfluence

end Integration
end PillarC
