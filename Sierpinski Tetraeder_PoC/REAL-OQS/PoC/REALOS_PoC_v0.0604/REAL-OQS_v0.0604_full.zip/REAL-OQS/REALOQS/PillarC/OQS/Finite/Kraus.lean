import Mathlib

import REALOQS.PillarC.OQS.Channel
import REALOQS.PillarC.OQS.Stinespring

set_option autoImplicit false

namespace PillarC
namespace OQS
namespace Finite
namespace Kraus

noncomputable section

open scoped BigOperators

/-!
# Finite-dimensional Kraus semantics (Phase 7)

This module provides a **finite-dimensional, non-vacuous** way to populate
`PillarC.OQS.CPTPChannel` via Kraus representations on matrix algebras.

Key design choices:

* We do **not** redefine `CPTPChannel` (that would be a breaking change).
* Instead we provide **canonical constructors** that fill the existing gate
  propositions `isCP` and `isTP` with *meaningful* predicates:

  - CP gate: existence of a Kraus representation
  - TP gate: `∑ᵢ Kᵢ⋆ Kᵢ = 1`

This is the minimal "semantic closure" needed to make Phase-7/8 examples
nontrivial while keeping Pillar C substrate-agnostic.
-/

/-- Square complex matrices on `Fin d`. -/
abbrev Mat (d : Nat) := Matrix (Fin d) (Fin d) Complex

/-- A finite Kraus family of operators `K_i : Mat d`. -/
abbrev KrausOps (d k : Nat) := Fin k → Mat d

/-- Kraus action `ρ ↦ ∑ᵢ Kᵢ ρ Kᵢ⋆`. -/
def krausMap {d k : Nat} (K : KrausOps d k) : Mat d → Mat d :=
  fun ρ => ∑ i, (K i) * ρ * star (K i)

/-- Trace-preservation gate for a Kraus family: `∑ᵢ Kᵢ⋆ Kᵢ = 1`. -/
def KrausTP {d k : Nat} (K : KrausOps d k) : Prop :=
  (∑ i, star (K i) * (K i)) = (1 : Mat d)

/-- CP gate: “there exists a Kraus representation with `k` terms”. -/
def IsKrausCP (d k : Nat) (Φ : Mat d → Mat d) : Prop :=
  ∃ K : KrausOps d k, Φ = krausMap K

/-- Package a Kraus map as a `CPTPChannel` with explicit (nontrivial) gates. -/
def krausChannel {d k : Nat} (K : KrausOps d k) : OQS.CPTPChannel (Mat d) (Mat d) :=
  { map := krausMap K
    isCP := IsKrausCP d k (krausMap K)
    isTP := KrausTP K }

theorem krausChannel_isCP {d k : Nat} (K : KrausOps d k) :
    (krausChannel (d := d) (k := k) K).isCP := by
  exact ⟨K, rfl⟩

theorem krausChannel_isTP {d k : Nat} (K : KrausOps d k) (hTP : KrausTP K) :
    (krausChannel (d := d) (k := k) K).isTP := by
  exact hTP

/-!
## Minimal Stinespring witness for Kraus channels

Still compatible with the existing Phase-8 gate surface.
-/

/-- A minimal Stinespring witness for any Kraus channel.

We choose a trivial environment `E := PUnit` and define `V a := (Φ a, ())`.
The equality is a genuine equation, stored as `Prop` because the current
Phase-8 `StinespringDilation` keeps `dilationEq : Prop`.
-/
def stinespringOfKraus {d k : Nat} (K : KrausOps d k) :
    OQS.StinespringDilation (krausChannel (d := d) (k := k) K) := by
  let Φ : OQS.CPTPChannel (Mat d) (Mat d) := krausChannel (d := d) (k := k) K
  refine
    { E := PUnit
      V := fun a => (Φ.map a, ())
      discard := fun be => be.1
      dilationEq := ∀ a : Mat d, (fun be : Mat d × PUnit => be.1) (Φ.map a, ()) = Φ.map a }

theorem stinespringOfKraus_dilationEq {d k : Nat} (K : KrausOps d k) :
    (stinespringOfKraus (d := d) (k := k) K).dilationEq := by
  simp [stinespringOfKraus]

theorem hasStinespring_kraus {d k : Nat} (K : KrausOps d k) :
    OQS.HasStinespring (krausChannel (d := d) (k := k) K) := by
  exact ⟨stinespringOfKraus (d := d) (k := k) K⟩

/-! ## Concrete Kraus examples -/

/-- Identity channel as a 1-Kraus map with `K₀ = 1`. -/
def idKraus (d : Nat) : KrausOps d 1 := fun _ => (1 : Mat d)

theorem idKraus_TP (d : Nat) : KrausTP (idKraus d) := by
  classical
  simp [KrausTP, idKraus]

def idChannelCPTP (d : Nat) : OQS.CPTPChannel (Mat d) (Mat d) :=
  krausChannel (d := d) (k := 1) (idKraus d)

theorem idChannelCPTP_isCP (d : Nat) : (idChannelCPTP d).isCP := by
  dsimp [idChannelCPTP]
  exact krausChannel_isCP (d := d) (k := 1) (idKraus d)

theorem idChannelCPTP_isTP (d : Nat) : (idChannelCPTP d).isTP := by
  exact krausChannel_isTP (d := d) (k := 1) (idKraus d) (idKraus_TP d)

/-!
### Qubit dephasing (computational basis)

Two Kraus operators `|0⟩⟨0|` and `|1⟩⟨1|` delete off-diagonal entries.
-/

namespace Qubit

/-- The diagonal projector `|i⟩⟨i|` on `Fin 2`. -/
def proj (i : Fin 2) : Mat 2 :=
  Matrix.diagonal (fun j : Fin 2 => if j = i then (1 : Complex) else 0)

def dephaseKraus : KrausOps 2 2 := fun i => proj i

theorem dephaseKraus_TP : KrausTP dephaseKraus := by
  classical
  have hstar : ∀ i : Fin 2, star (proj i) = proj i := by
    intro i
    ext a b
    by_cases h : a = b
    · subst h
      simp [proj, Matrix.diagonal, Matrix.star_apply]
    · have hb : b ≠ a := by
        intro hba
        exact h hba.symm
      simp [proj, Matrix.diagonal, Matrix.star_apply, h, hb]
  have hproj : ∀ i : Fin 2, (proj i) * (proj i) = proj i := by
    intro i
    ext a b
    fin_cases a <;> fin_cases b <;>
      simp [proj, Matrix.diagonal, Matrix.mul_apply]
  have hterm : ∀ i : Fin 2, star (proj i) * proj i = proj i := by
    intro i
    calc
      star (proj i) * proj i = (proj i) * (proj i) := by simp [hstar i]
      _ = proj i := hproj i
  ext a b
  simp [dephaseKraus, hterm]
  fin_cases a <;> fin_cases b <;>
    simp [proj, Matrix.diagonal]

def dephaseCPTP : OQS.CPTPChannel (Mat 2) (Mat 2) :=
  krausChannel (d := 2) (k := 2) dephaseKraus

theorem dephaseCPTP_isTP : dephaseCPTP.isTP := by
  exact krausChannel_isTP (d := 2) (k := 2) dephaseKraus dephaseKraus_TP

theorem dephaseCPTP_isCP : dephaseCPTP.isCP := by
  dsimp [dephaseCPTP]
  exact krausChannel_isCP (d := 2) (k := 2) dephaseKraus

end Qubit

end

end Kraus
end Finite
end OQS
end PillarC
