import Mathlib

import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarC.Integration.Locality
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet

set_option autoImplicit false

/-!
REALOQS / Pillar C / Integration: Derived discrete spacetime from influence (Phase 9)

This file provides a minimal construction turning a *site-level influence relation*
into a `PillarA.Kinematics.DiscreteSpacetime`.

Events are pairs `(t, x)` where `t : ℕ` is the RG tick index and `x : Ω` is a site.
The one-step causal relation advances `t` by exactly one and follows the influence relation.

This avoids injecting any continuum geometry: time is just the update index, and
`inf` is an abstract Prop hook that later layers can derive from channel locality.
-/

namespace PillarC
namespace Integration

open PillarA.Kinematics
open PillarA.LayerA

universe u

/-- Canonical event type for RG-time and a site label (universe-polymorphic). -/
abbrev Event (Ω : Type u) : Type u := Nat × Ω

/-- Discrete spacetime induced by a site-level influence relation. -/
def spacetimeOfInfluence (Ω : Type u) (inf : Ω → Ω → Prop) :
    DiscreteSpacetime (Event Ω) where
  τ := Prod.fst
  step := fun e₁ e₂ => e₂.1 = e₁.1 + 1 ∧ inf e₁.2 e₂.2
  step_tau := by
    intro x y h
    simpa using h.1

/-- Convenience: build a spacetime from a `ChannelInfluence` witness. -/
def spacetimeOfChannel
    {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)}
    {Φ : NetChannel LAN} (I : ChannelInfluence LAN Φ)
    (_nd : ChannelInfluence.Nondegenerate (LAN := LAN) (Φ := Φ) I) :
    DiscreteSpacetime (Event Ω) :=
  spacetimeOfInfluence Ω I.inf
end Integration
end PillarC
