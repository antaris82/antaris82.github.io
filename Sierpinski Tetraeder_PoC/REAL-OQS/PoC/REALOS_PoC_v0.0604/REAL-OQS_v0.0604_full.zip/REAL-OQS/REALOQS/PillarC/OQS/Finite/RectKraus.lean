import Mathlib

import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS
namespace Finite
namespace RectKraus

noncomputable section

open scoped BigOperators

/-!
# Rectangular Kraus maps (Phase 7)

Some coarse-graining channels change the Hilbert space dimension.

This module provides a **rectangular Kraus** packaging

`Mat β → Mat α` with Kraus operators `Kᵢ : α ← β`.

We keep the semantics purely algebraic:

* CP gate: existence of a rectangular Kraus representation
* TP gate: `∑ᵢ Kᵢ† Kᵢ = 1` on the input space

No analytic positivity theory is imported.
-/

abbrev Mat (α : Type) := Matrix α α Complex

abbrev RectMat (α β : Type) := Matrix α β Complex

abbrev RectKrausOps (α β : Type) (r : Nat) := Fin r → RectMat α β

/-- Rectangular Kraus action `ρ ↦ ∑ᵢ Kᵢ ρ Kᵢ†` for `Kᵢ : α ← β`. -/
def rectKrausMap
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Mat β → Mat α :=
  fun ρ => ∑ i, (K i) * ρ * Matrix.conjTranspose (K i)

/-- Trace-preservation gate for rectangular Kraus families: `∑ᵢ Kᵢ† Kᵢ = 1`. -/
def RectKrausTP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) : Prop :=
  (∑ i, Matrix.conjTranspose (K i) * (K i)) = (1 : Mat β)

/-- CP gate: “there exists a rectangular Kraus representation with `r` terms”. -/
def IsRectKrausCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (Φ : Mat β → Mat α) : Prop :=
  ∃ K : RectKrausOps α β r, Φ = rectKrausMap (α := α) (β := β) r K

/-- Package a rectangular Kraus map as a (gate-level) `CPTPChannel`. -/
def rectKrausChannel
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    _root_.PillarC.OQS.CPTPChannel (Mat β) (Mat α) :=
  { map := rectKrausMap (α := α) (β := β) r K
    isCP := IsRectKrausCP (α := α) (β := β) r (rectKrausMap (α := α) (β := β) r K)
    isTP := RectKrausTP (α := α) (β := β) r K }

theorem rectKrausChannel_isCP
    {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (r : Nat) (K : RectKrausOps α β r) :
    (rectKrausChannel (α := α) (β := β) r K).isCP := by
  exact ⟨K, rfl⟩

end

end RectKraus
end Finite
end OQS
end PillarC
