import REALOQS.PillarC.OQS.Semigroup

set_option autoImplicit false

namespace PillarC
namespace OQS

/-!
# OQS: Lindblad / GKSL hook (Phase 8)

This file introduces a minimal interface for a Lindblad (GKSL) generator.

We intentionally do not formalize Hilbert spaces, operator algebras, or
bounded operators here. The generator is represented as an abstract endomorphism
`A → A` with a predicate `isGKSL`.

A later refinement can:
- instantiate `A` as a space of states or observables,
- connect `isGKSL` to complete positivity of the induced semigroup,
- provide analytic/continuity assumptions.
-/

universe u

/-- A Lindblad generator candidate on `A`. -/
structure LindbladGenerator (A : Type u) where
  L : A → A
  /-- Gate predicate: "this generator is of GKSL type".

  At Phase 8 this is a semantic hook that later layers can replace with the
  standard operator-algebraic / analytic GKSL condition.
  -/
  isGKSL : Prop

namespace LindbladGenerator

variable {A : Type u} (G : LindbladGenerator (A := A))

/-- Gate predicate: `G` generates the semigroup `S`.

Phase-8 meaning: we use a purely *discrete-time* evolution law that depends
only on the underlying functions.  Later refinements can replace this by the
continuous-time GKSL master equation and its analytic side conditions.

The present law reads:

`S(t+1)(x) = G.L (S(t)(x))`.

This avoids any exogenous linear/algebraic structure at this layer.
-/
def Generates (S : MarkovSemigroup (A := A)) : Prop :=
  ∀ (t : Nat) (x : A), (S.Φ (t + 1)).toChannel.map x = G.L ((S.Φ t).toChannel.map x)

end LindbladGenerator

end OQS
end PillarC
