import REALOQS.PillarC.Integration.Locality
import REALOQS.PillarC.Integration.DerivedSpacetime
import REALOQS.PillarC.Integration.TailElimAsChannel

/-!
# Pillar C Integration BuildAll (Phase 9)

Convenience build target for the Phase-9 integration surface:
- locality/support hooks
- influence-induced discrete spacetime
- tail-elimination as a channel
-/
