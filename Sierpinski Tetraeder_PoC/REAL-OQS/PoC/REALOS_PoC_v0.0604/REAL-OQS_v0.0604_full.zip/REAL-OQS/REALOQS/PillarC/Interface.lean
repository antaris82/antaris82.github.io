import REALOQS.PillarA.Interface
import REALOQS.PillarB.Interface
import REALOQS.PillarC.OQS
import REALOQS.PillarC.Integration

set_option autoImplicit false

namespace PillarC

/-!
# Pillar C Interface (Phase 8)

Pillar C is the "full OQS" layer: channels, dilations, Markov and non-Markov
dynamics.

Design intent:
- Keep Pillar C substrate-agnostic.
- Expose only stable *contract surfaces* (structures + gate predicates).
- Allow later refinement to operator-algebraic CPTP maps (Pillar B) and to
  region-indexed locality/causality (Phase 9).

This interface currently forwards to the Phase-8 OQS umbrella.
-/

end PillarC
