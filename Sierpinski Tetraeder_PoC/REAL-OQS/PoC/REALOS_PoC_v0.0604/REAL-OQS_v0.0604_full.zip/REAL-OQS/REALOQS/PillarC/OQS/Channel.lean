import Mathlib

set_option autoImplicit false

namespace PillarC
namespace OQS

/-!
# OQS: Channels (Phase 8)

A *channel* is introduced as a plain function `A → B`.

`CPTPChannel` is a refinement shell: CP/TP are **gate propositions**.
At this stage we do not infer/prove CP/TP globally; downstream layers
(finite-dimensional Kraus/Stinespring, or C*-algebraic CP maps in Pillar B)
will populate these gates with the correct semantics.
-/

universe u v w

/-- A plain channel as a function `A → B`. -/
structure Channel (A : Type u) (B : Type v) where
  map : A → B

namespace Channel

variable {A : Type u} {B : Type v} {C : Type w}

instance : CoeFun (Channel A B) (fun _ => A → B) where
  coe Φ := Φ.map

/-- Identity channel. -/
def id (A : Type u) : Channel A A := ⟨fun x => x⟩

/-- Composition of channels. -/
def comp (Φ : Channel A B) (Ψ : Channel B C) : Channel A C :=
  ⟨fun x => Ψ.map (Φ.map x)⟩

@[simp] theorem map_id (x : A) : (id A).map x = x := rfl

@[simp] theorem map_comp (Φ : Channel A B) (Ψ : Channel B C) (x : A) :
    (comp Φ Ψ).map x = Ψ.map (Φ.map x) := rfl

end Channel

/-- A refined channel intended to represent CPTP maps.

At Phase 8/9 we model CP/TP as *properties* that can be strengthened later.
-/
structure CPTPChannel (A : Type u) (B : Type v) extends Channel A B where
  /-- Gate predicate: "Φ is completely positive". -/
  isCP : Prop
  /-- Gate predicate: "Φ is trace/state preserving". -/
  isTP : Prop

namespace CPTPChannel

variable {A : Type u} {B : Type v} {C : Type w}

instance : CoeFun (CPTPChannel A B) (fun _ => A → B) where
  coe Φ := Φ.toChannel.map

/-- Build a `CPTPChannel` from a plain `Channel` and explicit gate propositions.

This constructor is the preferred Phase-8/9 interface: it avoids silently
asserting CP/TP (e.g. by setting them to `True`).
-/
def ofChannel (Φ : Channel A B) (cp tp : Prop) : CPTPChannel A B :=
  { toChannel := Φ
    isCP := cp
    isTP := tp }

/-- Identity CPTP-channel with explicit gate propositions. -/
def id (A : Type u) (cp tp : Prop) : CPTPChannel A A :=
  ofChannel (Channel.id A) cp tp

/-- Composition of CPTP channels.

We preserve CP/TP gate propositions by conjunction.
-/
def comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) : CPTPChannel A C :=
  { toChannel := Channel.comp Φ.toChannel Ψ.toChannel
    isCP := Φ.isCP ∧ Ψ.isCP
    isTP := Φ.isTP ∧ Ψ.isTP }

@[simp] theorem map_id (cp tp : Prop) (x : A) :
    (id (A := A) cp tp).toChannel.map x = x := rfl

@[simp] theorem map_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) (x : A) :
    (comp Φ Ψ).toChannel.map x = Ψ.toChannel.map (Φ.toChannel.map x) := rfl

/-- Gate lemma: CP is stable under composition (as encoded here). -/
theorem gate_cp_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) :
    (comp Φ Ψ).isCP ↔ (Φ.isCP ∧ Ψ.isCP) := Iff.rfl

/-- Gate lemma: TP is stable under composition (as encoded here). -/
theorem gate_tp_comp (Φ : CPTPChannel A B) (Ψ : CPTPChannel B C) :
    (comp Φ Ψ).isTP ↔ (Φ.isTP ∧ Ψ.isTP) := Iff.rfl

end CPTPChannel

end OQS
end PillarC
