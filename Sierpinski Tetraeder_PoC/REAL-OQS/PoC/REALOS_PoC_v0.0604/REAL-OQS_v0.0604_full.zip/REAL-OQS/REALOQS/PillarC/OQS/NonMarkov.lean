import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS

/-!
# OQS: Non-Markovian hooks (Phase 8)

Phase 8 introduces Pillar C as the "full OQS" layer. For non-Markovian
dynamics we provide a lightweight placeholder interface, intended to be refined
later (e.g. process tensors, memory kernels, or generalized dynamical maps).

No attempt is made here to encode the full higher-order CP structure.
-/

universe u

/-- A discrete-time non-Markovian evolution model on `A`.

`step n` is the n-th update channel. `memoryLaw` is a gate predicate that can
later be strengthened to a process-tensor axiomatisation.
-/
structure NonMarkovProcess (A : Type u) where
  step : Nat → CPTPChannel A A
  /-- Memory/non-Markov law, left as a gate predicate.

  At Phase 8 we only record that some memory principle is intended. Later
  refinements can replace this with a process-tensor / higher-order CP
  formulation.
  -/
  memoryLaw : Prop

end OQS
end PillarC
