import REALOQS.PillarC.OQS.Finite.Kraus
import REALOQS.PillarC.OQS.Finite.RectKraus

/-!
# Pillar C / OQS / Finite umbrella (Phase 7–8)

Finite-dimensional semantic helpers for CPTP channels.
-/
