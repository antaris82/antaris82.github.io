import Mathlib

import REALOQS.PillarA.Update.TailEliminationDtN
import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

/-!
REALOQS / Pillar C / Integration: Tail-elimination as a channel (Phase 9)

This module connects the Pillar-A update pipeline to Pillar-C channels:

* `stage1` (tail elimination) is exported as a `Channel` on the carrier state space.
* A CPTP-wrapper is provided via *explicit gate propositions* (no silent CP/TP claims).
* The key semantic gate `stage1_boundaryOp_eq_DtN` remains in Pillar A; we re-expose it.

Note:
We do **not** prove CP/TP here. If you want to assert CP/TP for `stage1`, you must do so by
supplying the corresponding propositions (and later proofs) explicitly.
-/

namespace PillarC
namespace Integration

open PillarC.OQS
open PillarA.Update

universe u

/-- Stage-1 update as a plain channel on the carrier state space. -/
def stage1Channel {b : Nat} (A : TwoStageApprox b) : Channel A.S A.S :=
  ⟨A.stage1⟩

/-- Stage-1 update as a CPTP-channel wrapper with explicit gate propositions.

This avoids hardcoding `True` for CP/TP at the integration boundary.
-/
def stage1CPTP {b : Nat} (A : TwoStageApprox b) (cp tp : Prop) : CPTPChannel A.S A.S :=
  CPTPChannel.ofChannel (stage1Channel (A := A)) cp tp

/-- Re-export the core semantic equation as a Phase-9 gate. -/
theorem gate_stage1_is_DtN
    {b : Nat} {A : TwoStageApprox b}
    (Sem : TailElimDtNSemantics A) (s : A.S) :
    (Sem.opObserver.op (A.stage1 s)) =
      linOpOfMatrix (α := Sem.split.B) (Sem.split.DtN_of (Sem.L s) (Sem.inv s)) := by
  simpa using
    (PillarA.Update.TailElimDtNSemantics.gate_STAGE1_IS_DTN (Sem := Sem) (s := s))

end Integration
end PillarC
