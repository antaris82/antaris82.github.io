import REALOQS.PillarC.Interface

/-!
# Pillar C BuildAll

Convenience build target to compile the full Pillar C surface
(without introducing any executables).
-/
