import Mathlib

import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixKMSFromL

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

/-!
# Explicit nontriviality witnesses for the boundary matrix dynamics

This file closes the semantic gap left by the purely algebraic construction of
`boundaryDyn`: whenever the diagonal of `L` has a genuine gap, one can exhibit
an explicit time and an explicit matrix witness on which the `L`-dependent
boundary evolution is not the identity.
-/

noncomputable section

universe u

variable {Ω : Type u}

/-- Matrix unit supported at the single entry `(i,j)`. -/
def boundaryMatrixUnit [DecidableEq Ω] (i j : Ω) : Mat Ω :=
  fun x y => if x = i ∧ y = j then 1 else 0

@[simp] theorem boundaryMatrixUnit_apply [DecidableEq Ω]
    (i j x y : Ω) :
    boundaryMatrixUnit (Ω := Ω) i j x y =
      if x = i ∧ y = j then 1 else 0 := rfl

@[simp] theorem boundaryMatrixUnit_apply_self [DecidableEq Ω]
    (i j : Ω) :
    boundaryMatrixUnit (Ω := Ω) i j i j = 1 := by
  simp [boundaryMatrixUnit]

theorem phasePair_eq_neg_one_at_gapTime
    (L : Matrix Ω Ω ℝ) {i j : Ω}
    (hdiag : L i i ≠ L j j) :
    phaseMinusR L (Real.pi / (L j j - L i i)) i *
      phasePlusR L (Real.pi / (L j j - L i i)) j = -1 := by
  have hgap : L j j - L i i ≠ 0 :=
    sub_ne_zero.mpr (Ne.symm hdiag)
  rw [← boundaryKMSExp_real (Ω := Ω) (L := L)
    (t := Real.pi / (L j j - L i i)) (i := i) (j := j)]
  have hcancel :
      (L j j - L i i) * (Real.pi / (L j j - L i i)) = Real.pi := by
    field_simp [hgap]
  have harg :
      (Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
          (((Real.pi / (L j j - L i i) : ℝ) : Complex)) =
        Complex.I * (Real.pi : Complex) := by
    simpa [mul_assoc] using
      congrArg (fun x : ℝ => Complex.I * (x : Complex)) hcancel
  rw [harg]
  simpa [mul_comm] using Complex.exp_pi_mul_I

theorem phasePair_ne_one_at_gapTime
    (L : Matrix Ω Ω ℝ) {i j : Ω}
    (hdiag : L i i ≠ L j j) :
    phaseMinusR L (Real.pi / (L j j - L i i)) i *
      phasePlusR L (Real.pi / (L j j - L i i)) j ≠ 1 := by
  rw [phasePair_eq_neg_one_at_gapTime (Ω := Ω) (L := L) (i := i) (j := j) hdiag]
  norm_num

theorem boundaryDynMap_matrixUnit_ne_self_at_gapTime [DecidableEq Ω]
    (L : Matrix Ω Ω ℝ) {i j : Ω}
    (hdiag : L i i ≠ L j j) :
    boundaryDynMap (Ω := Ω) L (Real.pi / (L j j - L i i))
      (boundaryMatrixUnit (Ω := Ω) i j) ≠
        boundaryMatrixUnit (Ω := Ω) i j := by
  intro hEq
  have hentry :
      boundaryDynMap (Ω := Ω) L (Real.pi / (L j j - L i i))
        (boundaryMatrixUnit (Ω := Ω) i j) i j =
          boundaryMatrixUnit (Ω := Ω) i j i j := by
    exact congrArg (fun A : Mat Ω => A i j) hEq
  exact phasePair_ne_one_at_gapTime (Ω := Ω) (L := L) (i := i) (j := j) hdiag <| by
    simpa [boundaryDynMap, boundaryMatrixUnit, mul_assoc] using hentry

/-- Explicit matrix-level nontriviality witness extracted from a diagonal gap in `L`. -/
theorem boundaryDynMap_nontrivial_of_exists_diag_ne [DecidableEq Ω]
    (L : Matrix Ω Ω ℝ) (hgap : ∃ i j, L i i ≠ L j j) :
    ∃ t : ℝ, ∃ A : Mat Ω, boundaryDynMap (Ω := Ω) L t A ≠ A := by
  rcases hgap with ⟨i, j, hdiag⟩
  refine ⟨Real.pi / (L j j - L i i), boundaryMatrixUnit (Ω := Ω) i j, ?_⟩
  exact boundaryDynMap_matrixUnit_ne_self_at_gapTime
    (L := L) (i := i) (j := j) hdiag

/-- Bundled dynamics-level nontriviality witness extracted from a diagonal gap in `L`. -/
theorem boundaryDyn_nontrivial_of_exists_diag_ne [DecidableEq Ω] [Fintype Ω]
    (L : Matrix Ω Ω ℝ) (hgap : ∃ i j, L i i ≠ L j j) :
    ∃ t : ℝ, ∃ A : Mat Ω, (boundaryDyn (Ω := Ω) L).α t A ≠ A := by
  rcases boundaryDynMap_nontrivial_of_exists_diag_ne (Ω := Ω) L hgap with ⟨t, A, hA⟩
  refine ⟨t, A, ?_⟩
  simpa [boundaryDyn_alpha_apply] using hA

end
end Derived
end AQFT
end PillarB
