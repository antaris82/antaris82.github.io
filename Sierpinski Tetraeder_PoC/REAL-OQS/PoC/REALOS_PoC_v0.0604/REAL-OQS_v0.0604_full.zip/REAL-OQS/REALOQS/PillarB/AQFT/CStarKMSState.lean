import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# C⋆-level KMS bundle

This file upgrades the lightweight `KMSState` (based on `StateOn`) by bundling a
**strong C⋆-state** together with a chosen dynamics and a proof of the KMS strip
condition.

Design intent:

* Keep `KMSState` as the minimal repo-wide surface.
* Provide `CStarKMSStateOn` as the stronger analytic witness, and a bridge back
  to `KMSState` via `CStarStateOn.toStateOn`.

This is the KMS-2 milestone of the strict full-Hamiltonian plan.
-/

universe u

/-- Strong KMS bundle on a complex C⋆-algebra carrier.

The KMS predicate is still stated on the lightweight `StateOn` layer (see
`PillarB.AQFT.KMS`). We therefore store a `CStarStateOn` and feed its
`toStateOn` view into the KMS witness.
-/
structure CStarKMSStateOn (A : Type u)
    [CStarAlgebra A] [NormedAlgebra ℂ A] where
  β : ℝ
  dyn : StarAlgDynamics (SA := starAlgebraOfCStar A)
  state : CStarStateOn A
  isKMS : IsKMS (SA := starAlgebraOfCStar A) (D := dyn) β state.toStateOn

namespace CStarKMSStateOn

section Basic

variable {A : Type u}
variable [CStarAlgebra A] [NormedAlgebra ℂ A]

variable (K : CStarKMSStateOn A)

theorem beta_pos : 0 < K.β := K.isKMS.beta_pos

theorem invariant : IsInvariant (SA := starAlgebraOfCStar A) K.dyn K.state.toStateOn :=
  K.isKMS.invariant

/-- Forget the strong state carrier and return to the minimal `KMSState` surface.

This is the intended compatibility bridge for the existing repo-wide KMS layer.
-/
def toKMSState (K : CStarKMSStateOn A) : KMSState (SA := starAlgebraOfCStar A) where
  β := K.β
  dyn := K.dyn
  state := K.state.toStateOn
  isKMS := K.isKMS

@[simp] theorem toKMSState_beta (K : CStarKMSStateOn A) : K.toKMSState.β = K.β := rfl

@[simp] theorem toKMSState_state_apply (K : CStarKMSStateOn A) (a : A) :
    K.toKMSState.state a = K.state.toCLM a := rfl

end Basic

end CStarKMSStateOn

end AQFT
end PillarB
