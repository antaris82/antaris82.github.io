import Mathlib.Analysis.Normed.Operator.ContinuousLinearMap

import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# PillarB/AQFT: strong C⋆-state layer

`StateOn` remains the intentionally lightweight carrier `A → ℂ` used across the
existing repo surface. This file adds the **strong analytic layer** on top of
that minimal surface, without forcing an immediate global refactor.

Design rule:

* `StateOn` stays minimal and widely reusable.
* `CStarStateOn` is the stronger witness for complex C⋆ carriers.
* The bridge `CStarStateOn.toStateOn` lets legacy code (for example the current
  KMS layer) reuse the stronger state witness through the existing `StateOn`
  API.

This implements C2 from the C⋆ hardening plan:

* the carrier is a `ContinuousLinearMap`, so linearity and continuity are built in,
* positivity and normalization are attached as explicit proofs,
* the old lightweight `StateOn` surface remains available via coercion/bridge.
-/

universe u

/-- Strong state carrier on a complex C⋆-algebra: a continuous complex-linear
functional together with positivity and normalization.

This is intentionally tied **directly** to Mathlib's `CStarAlgebra` carrier, so
the name `CStarStateOn` is semantically honest at the type level rather than
only through later bridge lemmas.
-/
structure CStarStateOn (A : Type u)
    [CStarAlgebra A] [NormedAlgebra ℂ A] where
  toCLM : A →L[ℂ] ℂ
  positive' : ∀ a : A, IsRealNonneg (toCLM (star a * a))
  normalized' : toCLM 1 = 1

namespace CStarStateOn

section Basic

variable {A : Type u}
variable [CStarAlgebra A] [NormedAlgebra ℂ A]

instance : CoeFun (CStarStateOn A) (fun _ => A → ℂ) :=
  ⟨fun φ a => φ.toCLM a⟩

/-- Forget the analytic carrier and keep only the minimal `StateOn` surface. -/
def toStateOn (φ : CStarStateOn A) : StateOn A :=
  { toFun := fun a => φ.toCLM a }

@[simp] theorem coe_apply (φ : CStarStateOn A) (a : A) : φ a = φ.toCLM a := rfl

@[simp] theorem toStateOn_apply (φ : CStarStateOn A) (a : A) : φ.toStateOn a = φ.toCLM a := rfl

theorem normalized (φ : CStarStateOn A) : φ.toCLM 1 = 1 :=
  φ.normalized'

theorem positive (φ : CStarStateOn A) (a : A) :
    IsRealNonneg (φ.toCLM (star a * a)) :=
  φ.positive' a

@[ext] theorem ext {φ ψ : CStarStateOn A} (h : ∀ a : A, φ a = ψ a) : φ = ψ := by
  cases φ with
  | mk φclm φpos φnorm =>
    cases ψ with
    | mk ψclm ψpos ψnorm =>
      have hclm : φclm = ψclm := by
        ext a
        exact h a
      cases hclm
      have hpos : φpos = ψpos := by
        apply Subsingleton.elim
      have hnorm : φnorm = ψnorm := by
        apply Subsingleton.elim
      cases hpos
      cases hnorm
      rfl

end Basic

section CStarBridge

variable {A : Type u}
variable [CStarAlgebra A] [NormedAlgebra ℂ A]

/-- The strong C⋆-state yields a normalized lightweight state witness on the
canonical bundled `StarAlgebra` carried by the same C⋆ type. -/
theorem toStateOn_normalized (φ : CStarStateOn A) :
    IsNormalized (starAlgebraOfCStar A) φ.toStateOn := by
  change φ.toCLM 1 = 1
  exact φ.normalized'

/-- The strong C⋆-state yields a positive lightweight state witness on the
canonical bundled `StarAlgebra` carried by the same C⋆ type. -/
theorem toStateOn_positive (φ : CStarStateOn A) :
    IsPositive (starAlgebraOfCStar A) φ.toStateOn := by
  intro a
  change IsRealNonneg (φ.toCLM (star a * a))
  exact φ.positive' a

end CStarBridge

end CStarStateOn

end AQFT
end PillarB
