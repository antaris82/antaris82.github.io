import REALOQS.PillarB.AQFT.HaagKastler.SupportFull
import REALOQS.PillarB.Gates.HaagKastler.Covariance

/-!
# Haag–Kastler: Spectrum condition (gate)

In the usual (Minkowski) AQFT formulation, the spectrum condition constrains the
joint energy-momentum spectrum of the unitary translation representation to lie
in the forward light cone.

Within REAL-OQS we treat this as a **gate**: we do not attempt to derive or
construct spectral measures; instead we demand that the user provides a
representation witness together with a momentum support that is certified to be
contained in the forward cone.

This gate is intentionally abstract and compatible with non-standard symmetry
groups by allowing the user to choose the translation group `T`.
-/

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

/-!
## Gate-level wrapper

We wrap the AQFT-level `PillarB.AQFT.HaagKastler.SpectrumCondition` witness so
that it can be bundled together with other Haag–Kastler gates.

The parameter `N` pins the gate to a concrete local *-algebra net.
-/

structure SpectrumCondition (N : LocalStarAlgebraNet (Ω := Ω)) (T : Type v) where
  witness : PillarB.AQFT.HaagKastler.SpectrumCondition (G := T)

def SpectrumCondition.InForwardCone
    {N : LocalStarAlgebraNet (Ω := Ω)} {T : Type v}
    (SC : SpectrumCondition N T) : Prop :=
  SC.witness.spec.support ⊆ ForwardCone

theorem SpectrumCondition.inForwardCone
    {N : LocalStarAlgebraNet (Ω := Ω)} {T : Type v}
    (SC : SpectrumCondition N T) : SC.InForwardCone :=
  SC.witness.spec.support_subset_forward

end HaagKastler

end Gates
end AQFT
end PillarB
