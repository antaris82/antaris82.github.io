import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.HaagKastler.Support

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler: Time-slice / primitive causality gate

The time-slice axiom is typically formulated for nets on spacetimes:
the algebra of a region containing a Cauchy surface determines the algebra of
its domain of dependence.

This file keeps the notion of "causal completion" abstract, via a closure-type
operator on regions.

No concrete spacetime model and no IDEAL imports are required.
-/

universe u

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

/-!
## Abstract causal completion operator

We model the domain-of-dependence / causal completion as a closure-like map on regions.
-/

structure CausalCompletion where
  cl : N.LAN.RN.Region → N.LAN.RN.Region
  extensive : ∀ r, r ≤ cl r
  monotone : ∀ {a b}, a ≤ b → cl a ≤ cl b
  idempotent : ∀ r, cl (cl r) = cl r

namespace CausalCompletion

variable {N}

theorem le_cl (CC : CausalCompletion (N := N)) (r : N.LAN.RN.Region) : r ≤ CC.cl r :=
  CC.extensive r

end CausalCompletion

/-!
## Time-slice gate

We leave the predicate "this region is a time-slice" abstract.
The axiom demands that the isotony inclusion `A(r) → A(cl r)` is a *-isomorphism.
-/

def TimeSlice (CC : CausalCompletion (N := N)) (isTimeSlice : N.LAN.RN.Region → Prop) : Prop :=
  ∀ r : N.LAN.RN.Region,
    isTimeSlice r →
      ∃ e : StarAlgIso (SA := N.SA r) (SB := N.SA (CC.cl r)),
        e.hom = N.inclHom (CC.extensive r)

theorem gate_timeSlice_iso
    {CC : CausalCompletion (N := N)} {isTimeSlice : N.LAN.RN.Region → Prop}
    (hTS : TimeSlice (N := N) CC isTimeSlice)
    (r : N.LAN.RN.Region) (hr : isTimeSlice r) :
    ∃ e : StarAlgIso (SA := N.SA r) (SB := N.SA (CC.cl r)),
      e.hom = N.inclHom (CC.extensive r) :=
  hTS r hr

end HaagKastler

end Gates
end AQFT
end PillarB
