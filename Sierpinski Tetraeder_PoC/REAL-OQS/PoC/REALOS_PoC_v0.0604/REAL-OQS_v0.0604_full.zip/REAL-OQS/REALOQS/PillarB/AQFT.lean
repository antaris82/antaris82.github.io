import REALOQS.PillarB.AQFT.StarAlgebra
import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.State
import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.CStarKMSState
import REALOQS.PillarB.AQFT.StateNet
import REALOQS.PillarB.AQFT.GlobalCone
import REALOQS.PillarB.AQFT.QuasiLocal.Carrier
import REALOQS.PillarB.AQFT.QuasiLocal.Structure
import REALOQS.PillarB.AQFT.QuasiLocal.StarAlgebra
import REALOQS.PillarB.AQFT.QuasiLocal.Completion
import REALOQS.PillarB.AQFT.QuasiLocal.StateLift
import REALOQS.PillarB.AQFT.GNS
import REALOQS.PillarB.AQFT.KMS
import REALOQS.PillarB.AQFT.TimeOrientation
import REALOQS.PillarB.AQFT.TimeReversal
import REALOQS.PillarB.AQFT.RelativeEntropy
import REALOQS.PillarB.AQFT.Derived.FiniteWeightState
import REALOQS.PillarB.AQFT.Derived.GibbsStateOnConfig
import REALOQS.PillarB.AQFT.Derived.EnergyFromBoundaryOp
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixObservableBasis
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveSubnet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveProperties
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveDynamics
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveDynamicsDecision
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixRichNetNonAdditive
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixQuasiLocalClosure
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocality
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixSplitProperty
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullExp
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixPhases
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDynamicsFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGibbsState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixPhysicalGibbs
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDensityState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGNS
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixModular
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixTimeReversal
import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesExtendedFromPillarA

/-!
# Pillar B: AQFT (strict umbrella)

Convenience forwarder for the maintained Pillar B surface.

This umbrella now exposes two coordinated but distinct derived branches:

- the **rich/completion path**, carrying the matrix/KMS/GNS/modular/quasilocal
  machinery used in the strict B-closure path, and
- the **additive observable path**, derived as a subnet of the rich path and
  carrying the basis-relative Haag--Kastler structure.

Design intent:
- re-export the maintained theory core and the active ToC→B bridge surface,
- keep the rich/completion and additive observable layers simultaneously
  available without conflating their roles,
- leave legacy / scaffold modules outside this umbrella.
-/
