import Mathlib.Analysis.InnerProductSpace.Basic

import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.State

import REALOQS.PillarA.Core.ToC.AQFTSubstrate

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# GNS interface (B3.0)

Strictness update:
This file no longer introduces a free-floating gate-oriented `GNS` structure.

Instead, the IDEAL-level substrate in Pillar A is the single source of
assumptions. Pillar B only defines a thin wrapper that *references* the
substrate.

Later, the `GNSData` field in the substrate should be replaced by an actual
derivation theorem (existence/uniqueness of GNS) so that this layer becomes
fully derived.
-/

universe u v

/--
Concrete B-side GNS package used by the strict finite matrix path.

This remains intentionally lightweight: we record the representation carrier,
its left action by local observables, a chosen cyclic vector, and the explicit
state-reconstruction identity. This is sufficient for the finite matrix-based
derived constructions without pretending that the full abstract GNS theorem has
already been internalized globally.
-/
structure GNSDatum {A : Type u} (SA : StarAlgebra A) (ω : StateOn A) where
  H : Type v
  instNormedAddCommGroup : NormedAddCommGroup H
  instNormedSpace : NormedSpace ℂ H
  sesq : H → H → ℂ
  pi : A → H →L[ℂ] H
  pi_add : ∀ a b ξ, pi (SA.add a b) ξ = pi a ξ + pi b ξ
  pi_mul : ∀ a b ξ, pi (SA.mul a b) ξ = pi a (pi b ξ)
  pi_one : ∀ ξ, pi SA.one ξ = ξ
  cyclicVec : H
  cyclic : ∀ ξ : H, ∃ a : A, pi a cyclicVec = ξ
  state_from_cyclic : ∀ a : A, ω a = sesq cyclicVec (pi a cyclicVec)

attribute [instance] GNSDatum.instNormedAddCommGroup GNSDatum.instNormedSpace

/--
A `GNS` package in Pillar B is just the `GNSData` provided by the Pillar A
substrate.
-/
abbrev GNS {A : Type u} (S : PillarA.ToC.AQFTSubstrate A) (ω : S.StateOn) : Type (u + 1) :=
  S.GNSData ω

end AQFT
end PillarB
