import REALOQS.PillarB.AQFT.QuasiLocal.Carrier

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace QuasiLocal

/-!
# QuasiLocal universal property (B2.0)

B2.0 (points 13–14): carrier-level universal property.

A family `f_r : Alg r → B` extends uniquely to a function
`Carrier N → B` provided it is compatible with the isotony maps.
-/

universe u w

variable {Ω : Type u}

/-- Compatibility (coherence) of a family `f` with isotony. -/
def Compatible (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B) : Prop :=
  ∀ {a b : N.LAN.RN.Region} (hab : a ≤ b) (x : N.LAN.Alg a),
    f b (N.LAN.incl (a := a) (b := b) hab x) = f a x

/-- Predicate: `g : Carrier N → B` extends the family `f`. -/
def Extends (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (g : Carrier (Ω := Ω) N → B)
    (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B) : Prop :=
  ∀ (r : N.LAN.RN.Region) (x : N.LAN.Alg r),
    g (ι (Ω := Ω) N (r := r) x) = f r x

private theorem compatible_respects_rel
    (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f)
    {x y : Pre (Ω := Ω) N} (hxy : Rel (Ω := Ω) N x y) :
    f x.1 x.2 = f y.1 y.2 := by
  rcases hxy with ⟨t, hx, hy, hEq⟩
  -- Move both sides to the common upper region `t`.
  have hx' : f x.1 x.2 = f t (N.LAN.incl (a := x.1) (b := t) hx x.2) :=
    (hf (a := x.1) (b := t) hx x.2).symm
  have hy' : f y.1 y.2 = f t (N.LAN.incl (a := y.1) (b := t) hy y.2) :=
    (hf (a := y.1) (b := t) hy y.2).symm
  -- Use equality in the fiber `Alg t`.
  have ht :
      f t (N.LAN.incl (a := x.1) (b := t) hx x.2) =
        f t (N.LAN.incl (a := y.1) (b := t) hy y.2) := by
    exact congrArg (fun z => f t z) hEq
  exact hx'.trans (ht.trans hy'.symm)

/-- The canonical lift from a compatible family to the quasilocal carrier. -/
def lift (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f) : Carrier (Ω := Ω) N → B :=
  Quot.lift
    (fun p : Pre (Ω := Ω) N => f p.1 p.2)
    (by
      intro x y hxy
      exact compatible_respects_rel (Ω := Ω) N f hf hxy)

@[simp] theorem lift_ι (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f)
    (r : N.LAN.RN.Region) (x : N.LAN.Alg r) :
    lift (Ω := Ω) N f hf (ι (Ω := Ω) N (r := r) x) = f r x :=
  rfl

theorem lift_extends (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f) :
    Extends (Ω := Ω) N (lift (Ω := Ω) N f hf) f := by
  intro r x
  rfl

theorem lift_unique (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f)
    (g : Carrier (Ω := Ω) N → B)
    (hg : Extends (Ω := Ω) N g f) :
    g = lift (Ω := Ω) N f hf := by
  funext q
  refine Quot.inductionOn q (fun p => ?_) 
  -- `q` is represented by a fiber element.
  simpa [lift, Extends] using (hg p.1 p.2)

/-- Existence and uniqueness of the extension (carrier-level UP). -/
theorem existsUnique_extension (N : LocalStarAlgebraNet (Ω := Ω))
    {B : Type w} (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : Compatible (Ω := Ω) N f) :
    ∃! g : Carrier (Ω := Ω) N → B, Extends (Ω := Ω) N g f := by
  refine ⟨lift (Ω := Ω) N f hf, lift_extends (Ω := Ω) N f hf, ?_⟩
  intro g hg
  exact lift_unique (Ω := Ω) N f hf g hg

end QuasiLocal
end AQFT
end PillarB
