import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Data.Complex.Basic
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

/-!
# Derived: finite-weight expectation states

A reusable construction for **finite** probability-weighted expectation values.

This is purely algebraic (no positivity/normalization is enforced by default).
Normalization can be added later as a separate gate (`IsNormalized`).
-/

open scoped BigOperators

universe u

variable {X : Type u} [Fintype X]

noncomputable section

/-- Partition function / normalizer for weights `w`. -/
def Z (w : X → ℝ) : ℝ := by
  classical
  exact (Finset.univ : Finset X).sum (fun x => w x)

/-- Normalized weights `μ x := w x / Z`. Requires `Z ≠ 0`. -/
def μ (w : X → ℝ) (_hZ : Z (X := X) w ≠ 0) : X → ℝ :=
  fun x => w x / Z (X := X) w

/-- Expectation value `E_w[f] := ∑ (μ x) * f x` on a finite type.

We deliberately use multiplication after coercing `(μ x : ℝ)` into `ℂ`.
This avoids needing an explicit `SMul ℝ ℂ` instance in scope.
-/
def expect (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) (f : X → Complex) : Complex :=
  by
    classical
    exact (Finset.univ : Finset X).sum
      (fun x => ((μ (X := X) w hZ x : ℝ) : Complex) * f x)

/-- The associated `StateOn (X → ℂ)` given by finite weights `w`. -/
def expectationState (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) : StateOn (X → Complex) :=
  { toFun := expect (X := X) w hZ }

@[simp] theorem expectationState_apply (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) (f : X → Complex) :
    (expectationState (X := X) w hZ) f = expect (X := X) w hZ f := rfl

end

end Derived
end AQFT
end PillarB
