import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# PillarB/AQFT: Global cones for state nets

This is a convenience re-export layer for Pillar A's `GlobalStateCone` interface,
now that we have a concrete `StateNet` instance (B1.2b).
-/

universe u

-- Re-export (via abbreviation) for convenience in Pillar B namespace.
abbrev GlobalStateCone {Ω : Type u} (SN : PillarA.LayerA.StateNet (Ω := Ω)) :=
  PillarA.LayerA.GlobalStateCone (SN := SN)

end AQFT
end PillarB
