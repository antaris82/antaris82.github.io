import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace QuasiLocal

/-!
# QuasiLocal carrier (B2.0)

We form a carrier as a quotient of the disjoint union `Σ r, Alg r`.
Two representatives are identified if they become equal after embedding
into a common upper region.

At B2.0 we only provide:
- the carrier `Carrier N`
- injections `ι` from each fiber
- the coherence lemma `ι (incl hab x) = ι x`.
-/

universe u

variable {Ω : Type u}

/-- Pre-carrier: disjoint union of fibers. -/
abbrev Pre (N : LocalStarAlgebraNet (Ω := Ω)) :=
  Σ r : N.LAN.RN.Region, N.LAN.Alg r

/-- Defining relation: equality after embedding into a common upper region. -/
def Rel (N : LocalStarAlgebraNet (Ω := Ω)) (x y : Pre (Ω := Ω) N) : Prop :=
  ∃ t : N.LAN.RN.Region,
    ∃ hx : x.1 ≤ t,
      ∃ hy : y.1 ≤ t,
        N.LAN.incl (a := x.1) (b := t) hx x.2 =
          N.LAN.incl (a := y.1) (b := t) hy y.2

theorem rel_refl (N : LocalStarAlgebraNet (Ω := Ω)) (x : Pre (Ω := Ω) N) :
    Rel (Ω := Ω) N x x := by
  refine ⟨x.1, le_rfl, le_rfl, rfl⟩

theorem rel_symm (N : LocalStarAlgebraNet (Ω := Ω)) {x y : Pre (Ω := Ω) N} :
    Rel (Ω := Ω) N x y → Rel (Ω := Ω) N y x := by
  intro h
  rcases h with ⟨t, hx, hy, hxy⟩
  exact ⟨t, hy, hx, hxy.symm⟩

theorem rel_trans (N : LocalStarAlgebraNet (Ω := Ω)) {x y z : Pre (Ω := Ω) N} :
    Rel (Ω := Ω) N x y → Rel (Ω := Ω) N y z → Rel (Ω := Ω) N x z := by
  intro hxy hyz
  rcases hxy with ⟨t1, hx1, hy1, hxy⟩
  rcases hyz with ⟨t2, hy2, hz2, hyz⟩
  -- Use directedness via `sup`.
  let t : N.LAN.RN.Region := t1 ⊔ t2
  have ht1 : t1 ≤ t := le_sup_left
  have ht2 : t2 ≤ t := le_sup_right
  have hx : x.1 ≤ t := le_trans hx1 ht1
  have hy1' : y.1 ≤ t := le_trans hy1 ht1
  have hy2' : y.1 ≤ t := le_trans hy2 ht2
  have hz : z.1 ≤ t := le_trans hz2 ht2

  -- Push both equalities to `t` and chain them.
  have hxy_t :
      N.LAN.incl (a := x.1) (b := t) hx x.2 =
        N.LAN.incl (a := y.1) (b := t) hy1' y.2 := by
    have h := congrArg (fun w => N.LAN.incl (a := t1) (b := t) ht1 w) hxy
    have hx_comp := N.LAN.incl_comp (a := x.1) (b := t1) (c := t) hx1 ht1 x.2
    have hy_comp := N.LAN.incl_comp (a := y.1) (b := t1) (c := t) hy1 ht1 y.2
    simpa [hx_comp, hy_comp] using h

  have hyz_t :
      N.LAN.incl (a := y.1) (b := t) hy2' y.2 =
        N.LAN.incl (a := z.1) (b := t) hz z.2 := by
    have h := congrArg (fun w => N.LAN.incl (a := t2) (b := t) ht2 w) hyz
    have hy_comp := N.LAN.incl_comp (a := y.1) (b := t2) (c := t) hy2 ht2 y.2
    have hz_comp := N.LAN.incl_comp (a := z.1) (b := t2) (c := t) hz2 ht2 z.2
    simpa [hy_comp, hz_comp] using h

  refine ⟨t, hx, hz, ?_⟩
  -- Align the two proofs `y.1 ≤ t` by proof irrelevance.
  have hy_eq : hy1' = hy2' := by
    apply Subsingleton.elim
  cases hy_eq
  exact hxy_t.trans hyz_t

/-- Setoid induced by `Rel`. -/
def relSetoid (N : LocalStarAlgebraNet (Ω := Ω)) : Setoid (Pre (Ω := Ω) N) where
  r := Rel (Ω := Ω) N
  iseqv :=
    ⟨rel_refl (Ω := Ω) N,
      (by
        intro x y h
        exact rel_symm (Ω := Ω) N (x := x) (y := y) h),
      (by
        intro x y z hxy hyz
        exact rel_trans (Ω := Ω) N (x := x) (y := y) (z := z) hxy hyz)⟩

/-- The quasilocal carrier. -/
abbrev Carrier (N : LocalStarAlgebraNet (Ω := Ω)) :=
  Quot (relSetoid (Ω := Ω) N)

/-- Canonical injection of a fiber into the quasilocal carrier. -/
def ι (N : LocalStarAlgebraNet (Ω := Ω)) {r : N.LAN.RN.Region} (x : N.LAN.Alg r) :
    Carrier (Ω := Ω) N :=
  Quot.mk (relSetoid (Ω := Ω) N) ⟨r, x⟩

theorem ι_incl (N : LocalStarAlgebraNet (Ω := Ω))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) (x : N.LAN.Alg a) :
    ι (Ω := Ω) N (r := b) (N.LAN.incl (a := a) (b := b) hab x) =
      ι (Ω := Ω) N (r := a) x := by
  apply Quot.sound
  refine ⟨b, le_rfl, hab, ?_⟩
  -- Use the isotony identity law on region `b`.
  exact N.LAN.incl_id b (N.LAN.incl (a := a) (b := b) hab x)

end QuasiLocal
end AQFT
end PillarB
