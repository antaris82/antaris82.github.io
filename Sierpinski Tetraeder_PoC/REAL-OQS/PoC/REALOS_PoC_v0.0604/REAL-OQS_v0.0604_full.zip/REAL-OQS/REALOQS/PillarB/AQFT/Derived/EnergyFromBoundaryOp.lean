import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarB.AQFT.Derived.GibbsStateOnConfig

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

/-!
# Derived: energy and Gibbs top state from a boundary operator

This module makes the "physics choice" explicit and isolated:

* a boundary operator `L : Matrix Ω Ω ℝ` (e.g. an `LBB` output from Pillar A stage-1),
* a `MatterTemplate` containing `(d, β, φ)` where `φ : Fin d → ℝ` embeds discrete
  configuration values into reals.

From this we define:

* `energyFromBoundaryOp : Cfg d univ → ℝ` using the quadratic form `⟪x, L x⟫`,
* `gibbsTopState_fromBoundaryOp : StateOn (Alg d univ)` via `gibbsTopState`.

No IDEAL imports occur here.
-/

open scoped BigOperators

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

noncomputable section

/-- Quadratic form `⟪f, Λ f⟫` with the standard dot product on `Ω → ℝ`.

This is a universe-polymorphic copy of `PillarA.LayerA.quadForm`, which is
currently fixed to `V : Type` (universe `0`). We keep the definition here
so that `EnergyFromBoundaryOp` works for any `Ω : Type u`.
-/
def quadFormU (Λ : Matrix Ω Ω ℝ) (f : Ω → ℝ) : ℝ :=
  ∑ i, f i * (Λ.mulVec f) i

/-- Remaining explicit "matter" inputs for the derived Gibbs state harness. -/
structure MatterTemplate where
  /-- number of local configuration values -/
  d : Nat
  /-- ensure `Fin d` is inhabited (needed to build a canonical top configuration) -/
  d_pos : 0 < d
  /-- inverse temperature -/
  β : ℝ
  /-- embedding of discrete values into reals -/
  φ : Fin d → ℝ

namespace MatterTemplate

/-- Canonical `0`-value in `Fin d` (requires `d_pos`). -/
def zero (T : MatterTemplate) : Fin T.d :=
  ⟨0, T.d_pos⟩

end MatterTemplate

/-- Canonical top configuration: constant `0` assignment. -/
def cfgDefault (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) :=
  fun _ => T.zero

omit [DecidableEq Ω] in
theorem cfg_nonempty (T : MatterTemplate) :
    Nonempty (Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω)) :=
  ⟨cfgDefault (Ω := Ω) T⟩

/-- Convert a top configuration into a real vector using the embedding `φ`. -/
def realVecOfCfg (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → Ω → ℝ :=
  fun σ i =>
    T.φ (σ ⟨i, by simp⟩)

/-- Energy functional induced by a boundary operator matrix. -/
def energyFromBoundaryOp (L : Matrix Ω Ω ℝ) (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → ℝ :=
  fun σ =>
    quadFormU (Ω := Ω) L (realVecOfCfg (Ω := Ω) T σ)

/-- Canonical Gibbs top state induced by a boundary operator, given a `MatterTemplate`. -/
def gibbsTopState_fromBoundaryOp (L : Matrix Ω Ω ℝ) (T : MatterTemplate) :
    StateOn (Alg (Ω := Ω) T.d (Finset.univ : Finset Ω)) := by
  classical
  let E : Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → ℝ :=
    energyFromBoundaryOp (Ω := Ω) L T
  have hcfg : Nonempty (Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω)) :=
    cfg_nonempty (Ω := Ω) T
  exact gibbsTopState (Ω := Ω) T.d T.β E (hcfg := hcfg)

end

end Derived
end AQFT
end PillarB
