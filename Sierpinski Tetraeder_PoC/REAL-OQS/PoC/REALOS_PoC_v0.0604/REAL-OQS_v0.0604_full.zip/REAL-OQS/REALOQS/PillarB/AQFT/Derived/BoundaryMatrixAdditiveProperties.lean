import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveSubnet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocality
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixSplitProperty
import REALOQS.PillarB.Gates.HaagKastler.Isotony
import REALOQS.PillarB.Gates.HaagKastler.Locality
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler

universe u

section BoundaryMatrixAdditiveProperties

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

abbrev AdditiveBoundaryNet (B : RegionBasis (N := RichBoundaryNet (Ω := Ω))) :=
  boundaryMatrixAdditiveNet (Ω := Ω) (B := B)

variable (B : RegionBasis (N := RichBoundaryNet (Ω := Ω)))

/-- The additive subnet uses the same distinguished regions as the ambient rich
boundary-matrix net. -/
def boundaryMatrixAdditiveBasis :
    RegionBasis (N := AdditiveBoundaryNet (Ω := Ω) B) where
  basic := B.basic

/-- Every rich basis-generator inside `r` is represented by an additive
basis-generator with the same underlying rich value. -/
theorem rich_basisGenSet_has_additive_preimage
    {r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region}
    {y : (RichBoundaryNet (Ω := Ω)).LAN.Alg r}
    (hy : y ∈ basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r) :
    ∃ z : (AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r,
      z.1 = y ∧
      z ∈ basisGenSet
        (N := AdditiveBoundaryNet (Ω := Ω) B)
        (boundaryMatrixAdditiveBasis (Ω := Ω) B) r := by
  rcases hy with ⟨u, hu, hur, x, rfl⟩
  let xadd : (AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg u :=
    ⟨x, boundaryMatrixAdditiveGenerated_of_basic (Ω := Ω) (B := B) hu x⟩
  refine ⟨((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl hur xadd), rfl, ?_⟩
  exact mem_basisGenSet_of_basic
    (N := AdditiveBoundaryNet (Ω := Ω) B)
    (B := boundaryMatrixAdditiveBasis (Ω := Ω) B)
    hu hur xadd

/-- Lift an additive-fiber `*`-subalgebra at `r` to a rich-fiber `*`-subalgebra
by forgetting down to the ambient rich carrier. -/
def boundaryMatrixAdditiveSubalgebraLift
    (r : (RichBoundaryNet (Ω := Ω)).LAN.RN.Region)
    (U : StarSubalgebra ((AdditiveBoundaryNet (Ω := Ω) B).SA r)) :
    StarSubalgebra ((RichBoundaryNet (Ω := Ω)).SA r) where
  carrier :=
    { x | ∃ hx : boundaryMatrixAdditiveGenerated (Ω := Ω) B r x,
        ((⟨x, hx⟩ : (AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r)) ∈ U.carrier }
  zero_mem := by
    refine ⟨GeneratedBy.zero (SA := (RichBoundaryNet (Ω := Ω)).SA r)
      (basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r), ?_⟩
    simpa using U.zero_mem
  one_mem := by
    refine ⟨GeneratedBy.one (SA := (RichBoundaryNet (Ω := Ω)).SA r)
      (basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r), ?_⟩
    simpa using U.one_mem
  add_mem := by
    intro x y hx hy
    rcases hx with ⟨hxg, hxU⟩
    rcases hy with ⟨hyg, hyU⟩
    refine ⟨GeneratedBy.add (SA := (RichBoundaryNet (Ω := Ω)).SA r) hxg hyg, ?_⟩
    simpa using U.add_mem hxU hyU
  mul_mem := by
    intro x y hx hy
    rcases hx with ⟨hxg, hxU⟩
    rcases hy with ⟨hyg, hyU⟩
    refine ⟨GeneratedBy.mul (SA := (RichBoundaryNet (Ω := Ω)).SA r) hxg hyg, ?_⟩
    simpa using U.mul_mem hxU hyU
  neg_mem := by
    intro x hx
    rcases hx with ⟨hxg, hxU⟩
    refine ⟨GeneratedBy.neg (SA := (RichBoundaryNet (Ω := Ω)).SA r) hxg, ?_⟩
    simpa using U.neg_mem hxU
  star_mem := by
    intro x hx
    rcases hx with ⟨hxg, hxU⟩
    refine ⟨GeneratedBy.star (SA := (RichBoundaryNet (Ω := Ω)).SA r) hxg, ?_⟩
    simpa using U.star_mem hxU

/-- The additive subnet inherits injective isotony maps from the ambient rich
boundary-matrix net. -/
theorem boundaryMatrixAdditiveIsotony :
    Gates.HaagKastler.Isotony (N := AdditiveBoundaryNet (Ω := Ω) B) := by
  intro a b hab A C h
  apply Subtype.ext
  apply boundaryMatrixIncl_injective (Ω := Ω) hab
  exact congrArg (boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) b) h

/-- The additive subnet has the same region net as the rich one, hence the same
carrier-disjointness predicate. -/
abbrev boundaryMatrixAdditiveCarrierDisjoint :
    HaagKastler.Region.CausalDisjoint
      (RN := (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN) :=
  boundaryMatrixCarrierDisjoint (Ω := Ω)

/-- Locality descends from the rich net to the additive observable subnet. -/
theorem boundaryMatrixAdditiveLocality :
    Gates.HaagKastler.Locality
      (N := AdditiveBoundaryNet (Ω := Ω) B)
      (D := boundaryMatrixAdditiveCarrierDisjoint (Ω := Ω) (B := B)) := by
  intro a b hab x y
  change ((AdditiveBoundaryNet (Ω := Ω) B).SA (a ⊔ b)).mul
      (((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl
        (show a ≤ a ⊔ b from le_sup_left)) x)
      (((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl
        (show b ≤ a ⊔ b from le_sup_right)) y)
    =
    ((AdditiveBoundaryNet (Ω := Ω) B).SA (a ⊔ b)).mul
      (((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl
        (show b ≤ a ⊔ b from le_sup_right)) y)
      (((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl
        (show a ≤ a ⊔ b from le_sup_left)) x)
  apply Subtype.ext
  simpa [boundaryMatrixAdditiveCarrierDisjoint] using
    (gate_locality_commute
      (N := RichBoundaryNet (Ω := Ω))
      (D := boundaryMatrixCarrierDisjoint (Ω := Ω))
      (boundaryMatrixLocality (Ω := Ω)) hab x.1 y.1)

/-- The additive observable subnet satisfies basis-relative additivity by
construction. -/
theorem boundaryMatrixAdditiveAdditivityOnBasis :
    AdditivityOnBasis
      (N := AdditiveBoundaryNet (Ω := Ω) B)
      (boundaryMatrixAdditiveBasis (Ω := Ω) B) := by
  intro r A U hU
  let V : StarSubalgebra ((RichBoundaryNet (Ω := Ω)).SA r) :=
    boundaryMatrixAdditiveSubalgebraLift (Ω := Ω) (B := B) r U
  have hBasisV :
      basisGenSet (N := RichBoundaryNet (Ω := Ω)) B r ⊆ V.carrier := by
    intro y hy
    rcases rich_basisGenSet_has_additive_preimage (Ω := Ω) (B := B) hy with
      ⟨z, hzval, hzbasis⟩
    have hzU : z ∈ U.carrier := hU hzbasis
    have hzEq :
        z = (⟨y,
          generatedBy_of_mem
            (SA := (RichBoundaryNet (Ω := Ω)).SA r) hy⟩ :
            (AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r) := by
      apply Subtype.ext
      exact hzval
    refine ⟨generatedBy_of_mem (SA := (RichBoundaryNet (Ω := Ω)).SA r) hy, ?_⟩
    exact hzEq ▸ hzU
  have hAV : A.1 ∈ V.carrier := A.2 V hBasisV
  rcases hAV with ⟨hAGen, hAU⟩
  have hEq : (⟨A.1, hAGen⟩ : (AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r) = A := by
    apply Subtype.ext
    rfl
  exact hEq ▸ hAU

end BoundaryMatrixAdditiveProperties

end

end Derived
end AQFT
end PillarB
