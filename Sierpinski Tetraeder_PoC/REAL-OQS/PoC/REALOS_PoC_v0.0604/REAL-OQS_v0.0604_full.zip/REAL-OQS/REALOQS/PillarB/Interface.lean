/-
REALOQS / Pillar B: canonical interface

Pillar B provides the minimal AQFT layer on top of Pillar A:
  - concrete local algebras (later: C*-AQFT)
  - concrete states and restriction maps
  - (later) quasilocal / inductive-limit construction

Import discipline:
- This file must remain minimal and depend on Pillar A only via
  `REALOQS.PillarA.Core.Exports`.
- No IDEAL adapters.
- No `REALOQS.PillarA.All`.
-/

import REALOQS.PillarA.Core.Exports
