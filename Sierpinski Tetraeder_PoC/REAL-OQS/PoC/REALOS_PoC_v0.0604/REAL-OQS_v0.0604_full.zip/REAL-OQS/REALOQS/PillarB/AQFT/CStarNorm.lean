import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Analysis.CStarAlgebra.Classes
import Mathlib.Analysis.CStarAlgebra.Hom
import Mathlib.Algebra.Star.StarAlgHom

import REALOQS.PillarB.AQFT.StarAlgebra

/-!
Pillar B (AQFT) — B1.0b: C⋆/norm layer (mandatory)

This file is the **canonical analytic C⋆ layer** for Pillar B.

Design rule:

* We deliberately *reuse* Mathlib's C⋆-algebra classes
  (`CStarAlgebra`, `NonUnitalCStarAlgebra`) as the source of truth.
* We do **not** introduce a second proprietary class such as a project-local
  alternative to `CStarAlgebra`.
* Project-local code in this file is restricted to **light bundles** and
  **bridges** back into the minimal bundled `StarAlgebra` layer used elsewhere
  in the repo.

So the intended layering is:

* `StarAlgebra` = lightweight algebraic core,
* `CStarAlgebra` = analytic/norm-strong layer from Mathlib,
* `starAlgebraOfCStar` = canonical forgetful bridge from the analytic layer
  back to the lightweight bundled surface.

Key outputs:
* Bundles for (non-unital) complex C⋆-algebras.
* Canonical constructors `ofType` for those bundles.
* Abbreviations for (non-unital) ⋆-algebra homomorphisms.
* A bridge `starAlgebraOfCStar` turning a Mathlib `CStarAlgebra` into our bundled `StarAlgebra`.
* A bridge `starAlgHomOfStarAlgHom` turning a Mathlib `A →⋆ₐ[ℂ] B` into our bundled `StarAlgHom`.
-/

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u v

/-- A bundled non-unital complex C⋆-algebra.

We make the universe level explicit (`.{u}`) so that bundles can live in different universes,
and hom-types can be universe-polymorphic without forcing additional constraints.
-/
structure NonUnitalCStarAlgebraBundle where
  Carrier : Type u
  inst : NonUnitalCStarAlgebra Carrier

attribute [instance] NonUnitalCStarAlgebraBundle.inst

/-- A bundled (unital) complex C⋆-algebra. -/
structure CStarAlgebraBundle where
  Carrier : Type u
  inst : CStarAlgebra Carrier

attribute [instance] CStarAlgebraBundle.inst

namespace NonUnitalCStarAlgebraBundle

/-- Canonical bundle constructor from a Mathlib non-unital C⋆ carrier. -/
def ofType (A : Type u) [NonUnitalCStarAlgebra A] : NonUnitalCStarAlgebraBundle where
  Carrier := A
  inst := inferInstance

@[simp] theorem carrier_ofType (A : Type u) [NonUnitalCStarAlgebra A] :
    (ofType A).Carrier = A := rfl

end NonUnitalCStarAlgebraBundle

namespace CStarAlgebraBundle

/-- Canonical bundle constructor from a Mathlib unital C⋆ carrier. -/
def ofType (A : Type u) [CStarAlgebra A] : CStarAlgebraBundle where
  Carrier := A
  inst := inferInstance

@[simp] theorem carrier_ofType (A : Type u) [CStarAlgebra A] :
    (ofType A).Carrier = A := rfl

/-- Forget unitality. -/
def toNonUnital (A : CStarAlgebraBundle) : NonUnitalCStarAlgebraBundle where
  Carrier := A.Carrier
  inst := by
    -- `CStarAlgebra` extends `NonUnitalCStarAlgebra` in Mathlib.
    infer_instance

end CStarAlgebraBundle

/-!
## Homs
-/

/-- Non-unital ⋆-algebra homs between bundled non-unital C⋆-algebras. -/
abbrev NonUnitalStarHom
    (A : NonUnitalCStarAlgebraBundle.{u})
    (B : NonUnitalCStarAlgebraBundle.{v}) :=
  A.Carrier →⋆ₙₐ[ℂ] B.Carrier

/-- Unital ⋆-algebra homs between bundled C⋆-algebras. -/
abbrev StarHom (A : CStarAlgebraBundle.{u}) (B : CStarAlgebraBundle.{v}) :=
  A.Carrier →⋆ₐ[ℂ] B.Carrier

namespace NonUnitalStarHom

/-- Identity (non-unital) ⋆-algebra hom. -/
def id (A : NonUnitalCStarAlgebraBundle) : NonUnitalStarHom A A :=
  _root_.NonUnitalStarAlgHom.id ℂ A.Carrier

/-- Composition (non-unital) ⋆-algebra hom. -/
def comp {A B C : NonUnitalCStarAlgebraBundle}
    (g : NonUnitalStarHom B C) (f : NonUnitalStarHom A B) :
    NonUnitalStarHom A C :=
  _root_.NonUnitalStarAlgHom.comp g f

@[simp] theorem id_apply (A : NonUnitalCStarAlgebraBundle) (x : A.Carrier) : id A x = x := by
  simp [id]

@[simp] theorem comp_apply {A B C : NonUnitalCStarAlgebraBundle}
    (g : NonUnitalStarHom B C) (f : NonUnitalStarHom A B)
    (x : A.Carrier) : comp g f x = g (f x) := by
  simp [comp]

end NonUnitalStarHom

namespace StarHom

/-- Identity (unital) ⋆-algebra hom. -/
def id (A : CStarAlgebraBundle) : StarHom A A :=
  _root_.StarAlgHom.id ℂ A.Carrier

/-- Composition (unital) ⋆-algebra hom. -/
def comp {A B C : CStarAlgebraBundle} (g : StarHom B C) (f : StarHom A B) : StarHom A C :=
  _root_.StarAlgHom.comp g f

@[simp] theorem id_apply (A : CStarAlgebraBundle) (x : A.Carrier) : id A x = x := by
  simp [id]

@[simp] theorem comp_apply {A B C : CStarAlgebraBundle}
    (g : StarHom B C) (f : StarHom A B) (x : A.Carrier) : comp g f x = g (f x) := by
  simp [comp]

end StarHom

/-!
## Bridge: Mathlib C⋆-algebra → bundled `StarAlgebra`

Our B1.0a `StarAlgebra` is a *bundle* that does not rely on typeclass inference.
For C⋆-algebras from Mathlib we provide a canonical bundled instance.
-/

/-- Canonical bundled `StarAlgebra` carried by a Mathlib `CStarAlgebra`. -/
def starAlgebraOfCStar (A : Type u) [CStarAlgebra A] : StarAlgebra A :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := star
    add_assoc := by intro x y z; simp [add_assoc]
    add_comm := by intro x y; simp [add_comm]
    add_zero := by intro x; simp
    zero_add := by intro x; simp
    add_left_neg := by intro x; simp
    mul_assoc := by intro x y z; simp [mul_assoc]
    one_mul := by intro x; simp
    mul_one := by intro x; simp
    left_distrib := by intro x y z; simp [mul_add]
    right_distrib := by intro x y z; simp [add_mul]
    zero_mul := by intro x; simp
    mul_zero := by intro x; simp
    star_involutive := by intro x; simp
    star_add := by intro x y; simp
    star_mul := by intro x y; simp
    star_one := by simp
    star_zero := by simp }

@[simp] theorem starAlgebraOfCStar_zero (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).zero = (0 : A) := rfl

@[simp] theorem starAlgebraOfCStar_one (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).one = (1 : A) := rfl

@[simp] theorem starAlgebraOfCStar_add (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).add = ((· + ·) : A → A → A) := rfl

@[simp] theorem starAlgebraOfCStar_mul (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).mul = ((· * ·) : A → A → A) := rfl

@[simp] theorem starAlgebraOfCStar_neg (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).neg = (Neg.neg : A → A) := rfl

@[simp] theorem starAlgebraOfCStar_star (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).star = (star : A → A) := rfl

/-- Bridge: Mathlib unital ⋆-algebra hom → bundled `StarAlgHom`. -/
def starAlgHomOfStarAlgHom {A : Type u} {B : Type v} [CStarAlgebra A] [CStarAlgebra B]
    (f : A →⋆ₐ[ℂ] B) :
    StarAlgHom (starAlgebraOfCStar A) (starAlgebraOfCStar B) :=
  { toFun := fun x => f x
    isHom :=
      { map_zero := by
          simp [starAlgebraOfCStar]
        map_one := by
          simp [starAlgebraOfCStar]
        map_add := by
          intro x y
          simp [starAlgebraOfCStar]
        map_mul := by
          intro x y
          simp [starAlgebraOfCStar]
        map_neg := by
          intro x
          simp [starAlgebraOfCStar]
        map_star := by
          intro x
          simpa [starAlgebraOfCStar] using (map_star f x) } }

@[simp] theorem starAlgHomOfStarAlgHom_apply {A : Type u} {B : Type v}
    [CStarAlgebra A] [CStarAlgebra B] (f : A →⋆ₐ[ℂ] B) (x : A) :
    starAlgHomOfStarAlgHom f x = f x := rfl

end AQFT
end PillarB
