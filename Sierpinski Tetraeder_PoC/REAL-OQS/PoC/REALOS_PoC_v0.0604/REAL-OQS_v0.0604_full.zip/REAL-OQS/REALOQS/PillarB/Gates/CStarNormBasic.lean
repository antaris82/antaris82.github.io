import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Analysis.CStarAlgebra.Hom
import Mathlib.Analysis.Normed.Group.Basic

import REALOQS.PillarB.AQFT.CStarNorm

/-!
Pillar B (AQFT) — B1.0b gate: C⋆/norm layer

This gate file is intentionally small: it witnesses that the C⋆-algebra/norm layer
is available in Mathlib and can be used from within the REAL-OQS namespace.
The proofs are direct invocations of Mathlib lemmas.
-/

set_option autoImplicit false

namespace PillarB
namespace Gates

universe u v

section CStarLaws

variable {A : Type u}

-- C⋆-identity in the `CStarRing` form provided by Mathlib.
theorem gate_cstar_norm_star_mul_self [NonUnitalCStarAlgebra A] (x : A) :
    ‖star x * x‖ = ‖x‖ * ‖x‖ := by
  simpa using (CStarRing.norm_star_mul_self (x := x))

-- Star is an isometry (NormedStarGroup) in C⋆ settings.
theorem gate_norm_star [NonUnitalCStarAlgebra A] (x : A) : ‖star x‖ = ‖x‖ := by
  simp

end CStarLaws

section IsometryOfInjectiveHom

variable {A : Type u} {B : Type v}

-- Injective ⋆-homomorphisms between (non-unital) C⋆-algebras are isometries.
theorem gate_nonunital_star_alg_hom_isometry
    [NonUnitalCStarAlgebra A] [NonUnitalCStarAlgebra B]
    (φ : A →⋆ₙₐ[ℂ] B) (hφ : Function.Injective φ) : Isometry φ := by
  simpa using (NonUnitalStarAlgHom.isometry (φ := φ) hφ)

-- Hence they preserve norms pointwise.
theorem gate_nonunital_star_alg_hom_norm_map
    [NonUnitalCStarAlgebra A] [NonUnitalCStarAlgebra B]
    (φ : A →⋆ₙₐ[ℂ] B) (hφ : Function.Injective φ) (x : A) : ‖φ x‖ = ‖x‖ := by
  have hIso : Isometry φ := gate_nonunital_star_alg_hom_isometry (φ := φ) hφ
  -- `dist x 0 = ‖x‖` and `φ 0 = 0`, so isometry gives norm preservation.
  simpa [dist_eq_norm, map_zero] using (hIso.dist_eq x 0)

end IsometryOfInjectiveHom

end Gates
end PillarB
