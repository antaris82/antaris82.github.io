import REALOQS.PillarB.AQFT.StateNet
import REALOQS.PillarA.Core.BInterfaces.GlobalCone

set_option autoImplicit false

namespace PillarB
namespace Examples

/-!
# Pillar B / Examples: Finite classical harness (no functional-analysis overhead)

This file provides a concrete `LocalStarAlgebraNet` and the induced `StateNet`
instance, without relying on C⋆-analysis.

Model (minimal, robust):
- Region index: `SetRegionNet (Fin n)` from Pillar A.
- Local algebra carrier: constant commutative *-algebra `Fin n → ℂ` on every region.
- Isotony maps: identity.
- *-structure: bundled `StarAlgebra` with `star := id` (commutative case).
- States: functionals `A → ℂ` as in `PillarB.AQFT.StateOn`.

This is intentionally a harness/sanity check; it is not meant to encode locality
or additivity.
-/

namespace FiniteClassical

open PillarA
open PillarB.AQFT

/-- Bundled commutative `StarAlgebra` on `Fin n → ℂ` with `star := id`. -/
def piStarAlgebra (n : Nat) : StarAlgebra (Fin n → Complex) :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := fun f => f

    add_assoc := by
      intro a b c
      funext i
      simp [add_assoc]
    add_comm := by
      intro a b
      funext i
      simp [add_comm]
    add_zero := by
      intro a
      funext i
      simp
    zero_add := by
      intro a
      funext i
      simp
    add_left_neg := by
      intro a
      funext i
      simp

    mul_assoc := by
      intro a b c
      funext i
      simp [mul_assoc]
    one_mul := by
      intro a
      funext i
      simp
    mul_one := by
      intro a
      funext i
      simp
    left_distrib := by
      intro a b c
      funext i
      simp [left_distrib]
    right_distrib := by
      intro a b c
      funext i
      simp [right_distrib]
    zero_mul := by
      intro a
      funext i
      simp
    mul_zero := by
      intro a
      funext i
      simp

    star_involutive := by
      intro a
      rfl
    star_add := by
      intro a b
      rfl
    star_mul := by
      intro a b
      -- `star := id`, so this is commutativity.
      funext i
      simp [mul_comm]
    star_one := rfl
    star_zero := rfl }

/-- A concrete `LocalAlgebraNet` with constant fiber `Fin n → ℂ` and identity isotony. -/
def localAlgebraNet (n : Nat) : PillarA.LayerA.LocalAlgebraNet (Ω := Fin n) where
  RN := PillarA.LayerA.SetRegionNet (Fin n)
  Alg := fun _r => Fin n → Complex
  incl := by
    intro _a _b _hab f
    exact f
  incl_id := by
    intro _a x
    rfl
  incl_comp := by
    intro _a _b _c _hab _hbc x
    rfl

/-- Concrete `LocalStarAlgebraNet` built from the constant fiber harness. -/
def localStarNet (n : Nat) : PillarB.AQFT.LocalStarAlgebraNet (Ω := Fin n) where
  LAN := localAlgebraNet n
  SA := fun _r => piStarAlgebra n
  incl_isHom := by
    intro a b hab
    -- Isotony is identity on carriers.
    exact
      { map_zero := rfl
        map_one := rfl
        map_add := by intro x y; rfl
        map_mul := by intro x y; rfl
        map_neg := by intro x; rfl
        map_star := by intro x; rfl }

/-- The induced Pillar-A `StateNet` (states as functionals, restriction by pullback). -/
def stateNet (n : Nat) : PillarA.LayerA.StateNet (Ω := Fin n) :=
  (localStarNet n).toStateNet

/-- A concrete state: evaluation at index `i`. -/
def evalState {n : Nat} (i : Fin n) : StateOn (Fin n → Complex) :=
  { toFun := fun f => f i }

/-- A canonical global cone obtained by restricting an evaluation state on the top region. -/
def globalCone (n : Nat) (i : Fin n) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet n) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet n) (evalState i)

end FiniteClassical

end Examples
end PillarB
