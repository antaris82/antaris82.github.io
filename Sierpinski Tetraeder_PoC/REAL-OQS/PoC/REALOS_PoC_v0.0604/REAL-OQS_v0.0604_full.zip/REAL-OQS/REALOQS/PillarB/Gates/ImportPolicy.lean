import REALOQS.PillarB.Interface

/-
# Pillar B Import Policy Gate

This module is a stable CI anchor.
The actual import-policy enforcement is done by `REALOQS/tools/check_import_policy.py`.

The Lean-side gate is intentionally lightweight:
- it ensures the canonical Pillar B entry point compiles,
- and it sanity-checks that Pillar-A core handoff interfaces are reachable.
-/

-- Smoke checks (symbols exported via `REALOQS.PillarA.Core.Exports`).
#check PillarA.LayerA.LocalAlgebraNet
#check PillarA.LayerA.StateNet
#check PillarA.LayerA.GlobalStateCone
