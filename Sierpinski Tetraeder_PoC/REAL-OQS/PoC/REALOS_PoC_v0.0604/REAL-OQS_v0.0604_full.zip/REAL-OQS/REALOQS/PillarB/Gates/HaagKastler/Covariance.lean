import REALOQS.PillarA.Core.BInterfaces.CovariantNets
import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.HaagKastler.Support

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler: Covariance gate

We express covariance for a local *-algebra net via:

* a group action on regions (`RegionAction` from Pillar A),
* maps on local algebras compatible with isotony (`naturality`),
* and the requirement that those maps are *-algebra homomorphisms.

We additionally include the usual group-action laws for the algebra action,
up to the necessary dependent casts induced by equalities of acted regions.
-/

universe u v

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

section

variable (N : LocalStarAlgebraNet (Ω := Ω))
variable {G : Type v} [Group G]

/-!
## Dependent casts for region-indexed algebra fibers
-/

private def castAlg {r s : N.LAN.RN.Region} (h : r = s) : N.LAN.Alg r → N.LAN.Alg s := by
  intro x
  cases h
  simpa using x

/-!
## Covariant action structure

This is the data + coherence that turns a local net into a covariant net,
refined with the *-homomorphism requirement.
-/

structure CovariantAction where
  RA : PillarA.LayerA.CovariantNets.RegionAction (RN := N.LAN.RN) (G := G)
  actAlg : ∀ g : G, ∀ r : N.LAN.RN.Region, N.LAN.Alg r → N.LAN.Alg (RA.act g r)
  naturality :
    ∀ (g : G) {a b : N.LAN.RN.Region} (hab : a ≤ b) (x : N.LAN.Alg a),
      actAlg g b (N.LAN.incl hab x) =
        N.LAN.incl (RA.act_le (RN := N.LAN.RN) (G := G) g hab) (actAlg g a x)
  actAlg_isStarHom :
    ∀ (g : G) (r : N.LAN.RN.Region),
      IsStarAlgHom (N.SA r) (N.SA (RA.act g r)) (actAlg g r)

  /-- Identity law for the algebra action (dependent cast along `RA.act_one`). -/
  actAlg_one :
    ∀ (r : N.LAN.RN.Region) (x : N.LAN.Alg r),
      castAlg (N := N) (h := RA.act_one r) (actAlg (1 : G) r x) = x

  /-- Multiplication law for the algebra action (dependent cast along `RA.act_mul`). -/
  actAlg_mul :
    ∀ (g h : G) (r : N.LAN.RN.Region) (x : N.LAN.Alg r),
      castAlg (N := N) (h := RA.act_mul g h r) (actAlg (g * h) r x) =
        actAlg g (RA.act h r) (actAlg h r x)

end

namespace CovariantAction

variable {G : Type v} [Group G]
variable {N : LocalStarAlgebraNet (Ω := Ω)}

theorem gate_naturality (C : CovariantAction (Ω := Ω) (N := N) (G := G))
    (g : G) {a b : N.LAN.RN.Region} (hab : a ≤ b) (x : N.LAN.Alg a) :
    C.actAlg g b (N.LAN.incl hab x) =
      N.LAN.incl (C.RA.act_le (RN := N.LAN.RN) (G := G) g hab) (C.actAlg g a x) :=
  C.naturality g hab x

theorem gate_starHom (C : CovariantAction (Ω := Ω) (N := N) (G := G))
    (g : G) (r : N.LAN.RN.Region) :
    IsStarAlgHom (N.SA r) (N.SA (C.RA.act g r)) (C.actAlg g r) :=
  C.actAlg_isStarHom g r

end CovariantAction

/-!
## Covariance gate predicate

We package covariance as the existence of a `CovariantAction`.
-/

def Covariance (N : LocalStarAlgebraNet (Ω := Ω)) (G : Type v) [Group G] : Prop :=
  Nonempty (CovariantAction (Ω := Ω) (N := N) (G := G))

/-- Covariance relative to a prescribed region action `RA`.

This is useful when other parts of the theory (e.g. state covariance) already
fix a `RegionAction`, and one wants the algebra covariance to use the same one.
-/
def CovarianceWith (N : LocalStarAlgebraNet (Ω := Ω)) (G : Type v) [Group G]
    (RA : PillarA.LayerA.CovariantNets.RegionAction (RN := N.LAN.RN) (G := G)) : Prop :=
  ∃ C : CovariantAction (Ω := Ω) (N := N) (G := G), C.RA = RA

theorem CovarianceWith.mk {N : LocalStarAlgebraNet (Ω := Ω)} {G : Type v} [Group G]
    (C : CovariantAction (Ω := Ω) (N := N) (G := G)) :
    CovarianceWith (Ω := Ω) (N := N) (G := G) C.RA :=
  ⟨C, rfl⟩

end HaagKastler

end Gates
end AQFT
end PillarB
