import Mathlib

import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarA.Core.BInterfaces.StateNet
import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace Examples
namespace FiniteMatrix

noncomputable section

open scoped BigOperators

/-- Square complex matrices on `Fin d`. -/
abbrev Mat (d : Nat) := Matrix (Fin d) (Fin d) Complex

/-- Bundled `StarAlgebra` structure for `Mat d` (using Mathlib operations).

Note: `PillarB.AQFT.StarAlgebra` is intentionally minimal; it does **not**
include a `star_neg` axiom (it is derivable from additive structure if desired).
-/
def matSA (d : Nat) : AQFT.StarAlgebra (Mat d) :=
by
  classical
  -- Use the constructor explicitly (positional fields) to avoid relying on field labels
  -- that may be shadowed by lemma names in some environments.
  refine
    AQFT.StarAlgebra.mk (A := Mat d)
      0 1 (· + ·) (· * ·) (fun x => -x) star
      ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_
  · intro a b c; simp [add_assoc]
  · intro a b; simp [add_comm]
  · intro a; simp [add_zero]
  · intro a; simp [zero_add]
  · intro a; simp
  · intro a b c; simp [mul_assoc]
  · intro a; simp [one_mul]
  · intro a; simp [mul_one]
  · intro a b c; simp [mul_add]
  · intro a b c; simp [add_mul]
  · intro a; simp [zero_mul]
  · intro a; simp [mul_zero]
  · intro a; simp
  · intro a b; simp
  · intro a b; simp
  · simp
  · simp

/-- Local algebra net on `Ω = Fin n` with **constant** fiber `Mat d`.

Isotony maps are identities.
-/
def LAN (n d : Nat) : PillarA.LayerA.LocalAlgebraNet (Ω := Fin n) :=
  { RN := PillarA.LayerA.SetRegionNet (Ω := Fin n)
    Alg := fun _ => Mat d
    incl := fun {_a _b} _hab x => x
    incl_id := by
      intro a x
      rfl
    incl_comp := by
      intro a b c hab hbc x
      rfl }

/-- Local star-algebra net on `Ω = Fin n` with fiber `Mat d`.

Since inclusions are identities, the *-homomorphism laws are definitional.
-/
def LSAN (n d : Nat) : AQFT.LocalStarAlgebraNet (Ω := Fin n) :=
  { LAN := LAN n d
    SA := fun _ => matSA d
    incl_isHom := by
      intro a b hab
      refine
        { map_zero := rfl
          map_one := rfl
          map_add := by intro x y; rfl
          map_mul := by intro x y; rfl
          map_neg := by intro x; rfl
          map_star := by intro x; rfl } }

/-- State net: take the same matrix space as a placeholder for “states”, with identity restriction.

This is only meant as a *shape example* for the B-interfaces.
-/
def SN (n d : Nat) : PillarA.LayerA.StateNet (Ω := Fin n) :=
  { RN := PillarA.LayerA.SetRegionNet (Ω := Fin n)
    State := fun _ => Mat d
    restrict := fun {_a _b} _hab ρ => ρ
    restrict_id := by
      intro a ρ
      rfl
    restrict_comp := by
      intro a b c hab hbc ρ
      rfl }

end

end FiniteMatrix
end Examples
end PillarB
