import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet

/-!
# Haag–Kastler split property (gate-level)

We record a split-like property for local-algebra nets as a gate.

The full analytic split property is not encoded here; this file only captures
the abstract inclusion/interpolation shape.
-/

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace HaagKastler

universe u v w

open PillarA.LayerA

section

-- We pin the universe parameters of `LocalAlgebraNet` so that the intermediate
-- carrier `N` lives in the *same* universe as the local algebra carriers.
-- This avoids universe metavariables in the definition of `SplitProperty`.
variable {Ω : Type u} (LAN : LocalAlgebraNet.{u, v, w} (Ω := Ω))

/-- Split data for a net inclusion `a ≤ b`. -/
structure SplitData {a b : LAN.RN.Region} (hab : a ≤ b) where
  N : Type v
  i₁ : LAN.Alg a → N
  i₂ : N → LAN.Alg b
  i₁_inj : Function.Injective i₁
  i₂_inj : Function.Injective i₂
  compat : ∀ x : LAN.Alg a, i₂ (i₁ x) = LAN.incl (a := a) (b := b) hab x

namespace SplitData

/-- Trivial split data on the diagonal inclusion `a ≤ a`. -/
def refl (a : LAN.RN.Region) :
    SplitData (LAN := LAN) (a := a) (b := a) le_rfl where
  N := LAN.Alg a
  i₁ := id
  i₂ := id
  i₁_inj := by
    intro x y h
    simpa using h
  i₂_inj := by
    intro x y h
    simpa using h
  compat := by
    intro x
    simpa using (LAN.incl_id a x).symm

end SplitData

/-- Split property as a gate: every inclusion placeholder proofs some split data. -/
def SplitProperty : Prop :=
  ∀ {a b : LAN.RN.Region} (hab : a ≤ b),
    Nonempty (SplitData (LAN := LAN) (a := a) (b := b) hab)

theorem splitData_nonempty_refl (a : LAN.RN.Region) :
    Nonempty (SplitData (LAN := LAN) (a := a) (b := a) le_rfl) :=
  ⟨SplitData.refl (LAN := LAN) a⟩

end

end HaagKastler
end AQFT
end PillarB
