import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler: Isotony gate

In the usual Haag–Kastler formulation, isotony means:
if `a ≤ b` (region inclusion), then `A(a) ⊆ A(b)`.

In this repository, a local net already provides an inclusion morphism
`LAN.incl hab : Alg a → Alg b` and the bundled `StarAlgHom` version
`inclHom hab`.

The additional *gate* here is the usual strengthened isotony requirement
that these inclusions are **monomorphisms** (injective), so that one can
reason about local algebras as subalgebras of larger ones.
-/

universe u

variable {Ω : Type u}

namespace HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

/-- Haag–Kastler isotony as a gate: all isotony maps are injective. -/
def Isotony : Prop :=
  ∀ {a b : N.LAN.RN.Region} (hab : a ≤ b), Function.Injective (N.LAN.incl hab)

theorem gate_isotony_incl_injective (hIso : Isotony (N := N))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    Function.Injective (N.LAN.incl hab) :=
  hIso hab

theorem gate_isotony_inclHom_injective (hIso : Isotony (N := N))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    Function.Injective (N.inclHom hab) :=
  hIso hab

end HaagKastler

end Gates
end AQFT
end PillarB
