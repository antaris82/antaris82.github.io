import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

/-
# BoundaryMatrixAdditiveDynamics

Decision surface for the observable dynamical closure question.

This file intentionally stops before defining a restricted observable dynamics.
It only formalizes:
- the rich top observable carrier coming from `N_add_ToC.top`,
- the preservation predicate for the transported rich top dynamics, and
- elementary helper lemmas / decision markers.

A genuine observable dynamics should only be introduced later if preservation is
proved.
-/

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler
open PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

universe u

section Generic

variable {A : Type u}

/-- Elementary set-preservation predicate. -/
def PreservesSet (f : A → A) (S : Set A) : Prop :=
  ∀ ⦃x : A⦄, x ∈ S → f x ∈ S

end Generic

namespace TreeOfCliquesFromPillarA
namespace ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

/-- The rich top algebra on the active ToC path. -/
abbrev RichTopAlg [Fact (0 < b)] : Type :=
  (N_rich_ToC (b := b) (p := p)).LAN.Alg
    ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)

/-- The additive observable top algebra on the active ToC path. -/
abbrev AdditiveTopAlg [Fact (0 < b)] : Type :=
  (N_add_ToC (b := b) (p := p)).LAN.Alg
    ((N_add_ToC (b := b) (p := p)).LAN.RN.top)

section ObservableTop

variable [Fact (0 < b)]

/-- The top-level basis-generated set inside the rich ToC top algebra.  This is
the raw generating set from which the additive observable top carrier is built.
-/
def observableTopBasisGenSet_ToC : Set (RichTopAlg (b := b) (p := p)) :=
  PillarB.AQFT.Gates.HaagKastler.basisGenSet
    (N := N_rich_ToC (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)

@[simp] theorem mem_observableTopBasisGenSet_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) ↔
      A ∈ PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  rfl

/-- The observable top carrier inside the rich top fiber is exactly the
basis-generated carrier used by the additive observable subnet at the top
region. -/
def observableTopCarrier_ToC : Set (RichTopAlg (b := b) (p := p)) :=
  { A |
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A }

@[simp] theorem mem_observableTopCarrier_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      boundaryMatrixAdditiveGenerated
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)
        A := by
  rfl

/-- Every top-level basis generator already lies in the additive observable top
carrier. -/
theorem observableTopBasisGenSet_subset_observableTopCarrier_ToC :
    observableTopBasisGenSet_ToC (b := b) (p := p) ⊆
      observableTopCarrier_ToC (b := b) (p := p) := by
  intro A hA
  exact generatedBy_of_mem
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)) hA

/-- Top-level image of a rich basis-region element under the canonical isotony
map into the rich top fiber. -/
def topBasisGenerator_ToC
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RichTopAlg (b := b) (p := p) :=
  (N_rich_ToC (b := b) (p := p)).LAN.incl h A

/-- Every basic-region element gives a canonical generator in the rich top
fiber, hence belongs to the additive observable top carrier. -/
theorem topBasisGenerator_mem_observableTopCarrier_ToC
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    topBasisGenerator_ToC (b := b) (p := p)
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  have hgen :
      topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
          A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) := by
    exact mem_basisGenSet_of_basic
      (N := N_rich_ToC (b := b) (p := p))
      (B := B_ToC (b := b) (p := p))
      hu
      (_root_.PillarA.LayerA.RegionNet.le_top'
        (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
      A
  exact observableTopBasisGenSet_subset_observableTopCarrier_ToC
    (b := b) (p := p) hgen

/-- Time-transported image of a top-level basis generator under the rich top
minus dynamics.  This is the elementary object to analyze for D2a. -/
def dynImageTopBasisGenerator_ToC (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RichTopAlg (b := b) (p := p) :=
  (dyn_top_ToC (b := b) (p := p)).α t
    (topBasisGenerator_ToC (b := b) (p := p) h A)

@[simp] theorem topBasisGenerator_ToC_toMatrix
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RegionBlockMat.toMatrix
        (topBasisGenerator_ToC (b := b) (p := p) h A) =
      RegionBlockMat.toMatrix A := by
  exact boundaryMatrixRegionToMatrix_natural
    (Ω := Ω (b := b) (p := p)) h A

/-- Matrix-level form of the transported rich top image of a top basis
generator.  This is the concrete D2b object whose localization properties must
be analyzed. -/
@[simp] theorem dynImageTopBasisGenerator_ToC_toMatrix
    (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A) =
      (fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A) := by
  rw [dynImageTopBasisGenerator_ToC]
  rw [dyn_top_ToC_eq_boundaryMatrixTopDynMinus (b := b) (p := p)]
  rw [boundaryMatrixTopDynMinus_alpha_apply]
  rw [topBasisGenerator_ToC_toMatrix (b := b) (p := p) h A]
  rw [matrixToTopRegion_toMatrix]

/-- The rich top image of a basis generator belongs to the observable top
carrier as soon as its transported matrix image is again localized in some
basic region.  This is the key D2b reduction step from dynamics to localization
of matrix images. -/
theorem dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_regionLocalized
    (t : ℝ)
    {u v : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hv : (B_ToC (b := b) (p := p)).basic v)
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u)
    (hloc : RegionLocalized v
      ((fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A))) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  let Bv : (N_rich_ToC (b := b) (p := p)).LAN.Alg v :=
    ⟨(fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A), hloc⟩
  have hgen :
      topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) v)
          Bv ∈ observableTopCarrier_ToC (b := b) (p := p) :=
    topBasisGenerator_mem_observableTopCarrier_ToC
      (b := b) (p := p) hv Bv
  have hEq :
      dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A =
        topBasisGenerator_ToC (b := b) (p := p)
          (_root_.PillarA.LayerA.RegionNet.le_top'
            (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) v)
          Bv := by
    apply RegionBlockMat.ext
    rw [dynImageTopBasisGenerator_ToC_toMatrix (b := b) (p := p) t h A]
    rfl
  simpa [hEq] using hgen

/-- Ball-specialized D2b reduction: if the rich top image of a basis generator
is localized in a canonical `L`-ball, then it lies in the observable top
carrier. -/
theorem dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_basic_ball_regionLocalized
    (t : ℝ)
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (h : u ≤ (N_rich_ToC (b := b) (p := p)).LAN.RN.top)
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u)
    (hloc : RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      ((fullBoundaryDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)).α t
          (RegionBlockMat.toMatrix A))) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_regionLocalized
    (b := b) (p := p) t
    (u := u)
    (v := boundaryBallFromL (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p)) i)
    (B_ToC_basic_ball (b := b) (p := p) i)
    h A hloc

/-- At time `0`, every top-level basis generator is mapped back into the
observable top carrier.  This is the first concrete D2a sanity check for the
generator images. -/
theorem dyn_top_ToC_zero_maps_topBasisGenerator_to_observableTop
    {u : (N_rich_ToC (b := b) (p := p)).LAN.RN.Region}
    (hu : (B_ToC (b := b) (p := p)).basic u)
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg u) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN) u)
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  rw [dynImageTopBasisGenerator_ToC]
  rw [_root_.PillarB.AQFT.StarAlgDynamics.alpha_zero_apply
      (D := dyn_top_ToC (b := b) (p := p))]
  exact topBasisGenerator_mem_observableTopCarrier_ToC
    (b := b) (p := p) hu A

/-- The canonical `L`-ball basis generators also satisfy the D2a time-zero
sanity check. -/
theorem dyn_top_ToC_zero_maps_basic_ball_generator_to_observableTop
    (i : Ω (b := b) (p := p))
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    dynImageTopBasisGenerator_ToC (b := b) (p := p) 0
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_rich_ToC (b := b) (p := p)).LAN.RN)
          (boundaryBallFromL (Ω := Ω (b := b) (p := p))
            (L := L (b := b) (p := p)) i))
        A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  exact dyn_top_ToC_zero_maps_topBasisGenerator_to_observableTop
    (b := b) (p := p)
    (B_ToC_basic_ball (b := b) (p := p) i) A

/-- The observable top carrier viewed as a `*`-subalgebra of the rich top
fiber. -/
def observableTopSubalgebra_ToC :
    StarSubalgebra
      ((N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top)) where
  carrier := observableTopCarrier_ToC (b := b) (p := p)
  zero_mem := by
    exact GeneratedBy.zero
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      (PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
  one_mem := by
    exact GeneratedBy.one
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      (PillarB.AQFT.Gates.HaagKastler.basisGenSet
        (N := N_rich_ToC (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
  add_mem := by
    intro x y hx hy
    exact GeneratedBy.add
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx hy
  mul_mem := by
    intro x y hx hy
    exact GeneratedBy.mul
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx hy
  neg_mem := by
    intro x hx
    exact GeneratedBy.neg
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx
  star_mem := by
    intro x hx
    exact GeneratedBy.star
      (SA := (N_rich_ToC (b := b) (p := p)).SA
        ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
      hx

@[simp] theorem mem_observableTopSubalgebra_ToC_iff
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ (observableTopSubalgebra_ToC (b := b) (p := p)).carrier ↔
      A ∈ observableTopCarrier_ToC (b := b) (p := p) := by
  rfl

/-- Every additive observable top element has its canonical rich preimage in the
observable top carrier. -/
@[simp] theorem additiveTop_mem_observableTopCarrier_ToC
    (A : AdditiveTopAlg (b := b) (p := p)) :
    observableInclRich_ToC (b := b) (p := p)
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top) A ∈
      observableTopCarrier_ToC (b := b) (p := p) := by
  exact A.2

/-- Membership in the observable top carrier is equivalent to coming from a
canonical additive-top preimage. -/
theorem mem_observableTopCarrier_ToC_iff_exists_preimage
    (A : RichTopAlg (b := b) (p := p)) :
    A ∈ observableTopCarrier_ToC (b := b) (p := p) ↔
      ∃ B : AdditiveTopAlg (b := b) (p := p),
        observableInclRich_ToC (b := b) (p := p)
          ((N_add_ToC (b := b) (p := p)).LAN.RN.top) B = A := by
  constructor
  · intro hA
    refine ⟨⟨A, hA⟩, ?_⟩
    rfl
  · rintro ⟨B, rfl⟩
    exact additiveTop_mem_observableTopCarrier_ToC (b := b) (p := p) B

/-- D0 surface marker: the observable top state is currently only the
restriction-defined top state on the additive subnet. -/
@[simp] theorem observableTopState_is_restriction_defined :
    ρAdd_top (b := b) (p := p) =
      boundaryMatrixAdditiveTopFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

/-- D0 surface marker: the observable quasilocal state is currently only the
restriction-derived lift from the rich path. -/
@[simp] theorem observableQuasiLocal_is_restriction_defined :
    Φ_add_FromA (b := b) (p := p) =
      boundaryMatrixAdditiveQuasiLocalStateFromRich
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

/-- D1: preservation predicate for the rich top minus-dynamics acting on the
observable top carrier. -/
def dyn_top_ToC_preserves_N_add_top : Prop :=
  ∀ t : ℝ,
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α t)
      (observableTopCarrier_ToC (b := b) (p := p))

/-- Equivalent subalgebra-flavored formulation of the same top observable
preservation question. -/
def dyn_top_ToC_preserves_observableTopSubalgebra : Prop :=
  ∀ t : ℝ,
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α t)
      ((observableTopSubalgebra_ToC (b := b) (p := p)).carrier)





end ObservableTop

/-- Any distinguished basis region on the active ToC observable basis is
literally a canonical one-step `L`-ball. -/
theorem basic_region_eq_boundaryBallFromL
    {u : BoundaryRegion (Ω := Ω (b := b) (p := p))}
    (hu : (B_ToC (b := b) (p := p)).basic u) :
    ∃ i : Ω (b := b) (p := p),
      u = boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i := by
  change u ∈ (Finset.univ.image
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)))) at hu
  rcases Finset.mem_image.mp hu with ⟨i, _hiU, hi⟩
  exact ⟨i, hi.symm⟩

section ObservableTop

variable [Fact (0 < b)]

/-- D2c candidate property: every canonical `L`-ball generator remains localized
in its own canonical ball under the rich top minus-dynamics. -/
def dyn_top_ToC_preserves_basic_ball_generator_localization : Prop :=
  ∀ (t : ℝ) (i : Ω (b := b) (p := p))
      {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i ≤
        (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
      (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)),
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) t h A))

/-- D2c reduction: same-ball localization of all canonical basis-ball
 generators already implies full preservation of the observable top carrier. -/
theorem dyn_top_ToC_preserves_N_add_top_of_preserves_basic_ball_generator_localization
    (hball : dyn_top_ToC_preserves_basic_ball_generator_localization
      (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro t A hA
  exact GeneratedBy.preserved
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
    ((dyn_top_ToC (b := b) (p := p)).α t)
    (by
      intro y hy
      rcases hy with ⟨u, hu, hle, x, rfl⟩
      rcases basic_region_eq_boundaryBallFromL (b := b) (p := p) hu with ⟨i, rfl⟩
      exact dyn_top_ToC_maps_topBasisGenerator_to_observableTop_of_basic_ball_regionLocalized
        (b := b) (p := p) t
        (u := boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)
        hle i x (hball t i (h := hle) x))
    hA

/-- Time-zero sanity check for D2c: every canonical basis-ball generator stays
localized in its own ball at `t = 0`. -/
theorem dyn_top_ToC_zero_preserves_basic_ball_generator_localization
    (i : Ω (b := b) (p := p))
    {h : boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i ≤
      (N_rich_ToC (b := b) (p := p)).LAN.RN.top}
    (A : (N_rich_ToC (b := b) (p := p)).LAN.Alg
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)) :
    RegionLocalized
      (boundaryBallFromL (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)) i)
      (RegionBlockMat.toMatrix
        (dynImageTopBasisGenerator_ToC (b := b) (p := p) 0 h A)) := by
  rw [dynImageTopBasisGenerator_ToC_toMatrix (b := b) (p := p) 0 h A]
  rw [fullBoundaryDynMinus_alpha_apply]
  rw [fullBoundaryDynMapMinus_zero_apply]
  exact A.2

@[simp] theorem dyn_top_ToC_preserves_observableTopSubalgebra_iff :
    dyn_top_ToC_preserves_observableTopSubalgebra (b := b) (p := p) ↔
      dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  rfl

/-- Basic sanity check: at time `0`, the rich top dynamics preserves the
observable top carrier.  This is only a normalization marker, not the sought
all-times closure statement. -/
theorem dyn_top_ToC_zero_preserves_N_add_top :
    PreservesSet
      ((dyn_top_ToC (b := b) (p := p)).α 0)
      (observableTopCarrier_ToC (b := b) (p := p)) := by
  intro A hA
  rw [_root_.PillarB.AQFT.StarAlgDynamics.alpha_zero_apply
      (D := dyn_top_ToC (b := b) (p := p)) A]
  exact hA

/-- D2a reduction step: to prove full observable-top preservation, it suffices
to prove that the rich top dynamics sends every top-level basis generator back
into the additive observable top carrier. -/
theorem dyn_top_ToC_preserves_N_add_top_of_preserves_basisGenerators
    (hgen : ∀ (t : ℝ) ⦃A : RichTopAlg (b := b) (p := p)⦄,
      A ∈ observableTopBasisGenSet_ToC (b := b) (p := p) →
        (dyn_top_ToC (b := b) (p := p)).α t A ∈
          observableTopCarrier_ToC (b := b) (p := p)) :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  intro t A hA
  exact GeneratedBy.preserved
    (SA := (N_rich_ToC (b := b) (p := p)).SA
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top))
    ((dyn_top_ToC (b := b) (p := p)).α t)
    (fun y hy => hgen t hy)
    hA

/-- D2 surface: the preservation question is now formalized as a decidable
classical proposition on the active ToC observable top path. -/
noncomputable def dyn_top_ToC_preserves_N_add_top_decidable :
    Decidable (dyn_top_ToC_preserves_N_add_top (b := b) (p := p)) := by
  classical
  infer_instance

/-- D2 surface: classical case split for the observable dynamical closure
question.  This is a decision surface only; it is not yet a constructive
preservation or obstruction theorem. -/
theorem dyn_top_ToC_preserves_N_add_top_or_not :
    dyn_top_ToC_preserves_N_add_top (b := b) (p := p) ∨
      ¬ dyn_top_ToC_preserves_N_add_top (b := b) (p := p) := by
  classical
  exact em _

end ObservableTop

end ToC
end TreeOfCliquesFromPillarA

end

end Derived
end AQFT
end PillarB
