/-
REALOQS / Pillar B / AQFT: Export surface

Stable import target for the AQFT layer of Pillar B.

Design intent:
- depend on Pillar A only via its core exports (no IDEAL adapters, no heavy umbrellas)
- re-export the minimal concrete layers as they land (local nets, states, ...).
-/

import REALOQS.PillarA.Core.Exports

-- Pillar B AQFT public exports (B1.*)
import REALOQS.PillarB.AQFT.StarAlgebra
import REALOQS.PillarB.AQFT.CStarNorm

-- B1.1: concrete local nets
import REALOQS.PillarB.AQFT.LocalNet

-- B1.2a/b: minimal states and a StateNet instance
import REALOQS.PillarB.AQFT.State
import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.StateNet
import REALOQS.PillarB.AQFT.GlobalCone

-- B2.*: quasilocal carrier and state lift
import REALOQS.PillarB.AQFT.QuasiLocal.Carrier
import REALOQS.PillarB.AQFT.QuasiLocal.Structure
import REALOQS.PillarB.AQFT.QuasiLocal.StarAlgebra
import REALOQS.PillarB.AQFT.QuasiLocal.Completion
import REALOQS.PillarB.AQFT.QuasiLocal.StateLift

-- B3.*: GNS interface (gate-oriented)
import REALOQS.PillarB.AQFT.GNS

-- HK support structures (axioms as gates are under `REALOQS.PillarB.Gates.HaagKastler`).
import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.HaagKastler.SupportFull
