import REALOQS.PillarB.AQFT.QuasiLocal.Carrier
import REALOQS.PillarB.AQFT.GlobalCone
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT

namespace LocalStarAlgebraNet

universe u

variable {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω))

/-- Evaluate restriction in the induced `StateNet` (simp helper). -/
@[simp] theorem toStateNet_restrict_toFun
    {a b : N.LAN.RN.Region} (hab : a ≤ b)
    (ρ : StateOn (N.LAN.Alg b)) (x : N.LAN.Alg a) :
    ((LocalStarAlgebraNet.toStateNet (Ω := Ω) N).restrict hab ρ).toFun x =
      ρ.toFun (N.LAN.incl hab x) := by
  -- unfold the induced restriction (= pullback along the isotony hom)
  simp [LocalStarAlgebraNet.toStateNet, StateOn.restrict]

end LocalStarAlgebraNet

namespace QuasiLocal

universe u

variable {Ω : Type u}
variable (N : LocalStarAlgebraNet (Ω := Ω))

/-- The induced Pillar-A `StateNet` associated to `N`. -/
def SN : PillarA.LayerA.StateNet (Ω := Ω) :=
  LocalStarAlgebraNet.toStateNet (Ω := Ω) N

/-- Evaluation on the pre-carrier `Σ r, Alg r` given by a global cone. -/
def evalPre
    (C : PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) N))
    (p : Pre (Ω := Ω) N) : Complex :=
  (C.ω p.1).toFun p.2

theorem evalPre_respects
    (C : PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) N))
    {x y : Pre (Ω := Ω) N} :
    Rel (Ω := Ω) N x y → evalPre (Ω := Ω) N C x = evalPre (Ω := Ω) N C y := by
  intro h
  rcases h with ⟨t, hx, hy, hxy⟩

  -- Use cone compatibility to rewrite evaluation on `x` via the upper region `t`.
  have hx_at :
      (C.ω x.1).toFun x.2 =
        (C.ω t).toFun (N.LAN.incl (a := x.1) (b := t) hx x.2) := by
    have hcone : (SN (Ω := Ω) N).restrict hx (C.ω t) = C.ω x.1 :=
      C.compat hx
    have h1 := congrArg (fun s : StateOn (N.LAN.Alg x.1) => s.toFun x.2) hcone
    -- rewrite the LHS using the explicit restriction formula
    have h2 :
        ((SN (Ω := Ω) N).restrict hx (C.ω t)).toFun x.2 =
          (C.ω t).toFun (N.LAN.incl (a := x.1) (b := t) hx x.2) := by
      -- unfold `SN` and reduce to the simp-helper lemma
      simp [SN]
    exact h1.symm.trans h2

  have hy_at :
      (C.ω y.1).toFun y.2 =
        (C.ω t).toFun (N.LAN.incl (a := y.1) (b := t) hy y.2) := by
    have hcone : (SN (Ω := Ω) N).restrict hy (C.ω t) = C.ω y.1 :=
      C.compat hy
    have h1 := congrArg (fun s : StateOn (N.LAN.Alg y.1) => s.toFun y.2) hcone
    have h2 :
        ((SN (Ω := Ω) N).restrict hy (C.ω t)).toFun y.2 =
          (C.ω t).toFun (N.LAN.incl (a := y.1) (b := t) hy y.2) := by
      simp [SN]
    exact h1.symm.trans h2

  -- Now compare both via the common embedding equality `hxy`.
  calc
    evalPre (Ω := Ω) N C x = (C.ω x.1).toFun x.2 := by
      rfl
    _ = (C.ω t).toFun (N.LAN.incl (a := x.1) (b := t) hx x.2) := hx_at
    _ = (C.ω t).toFun (N.LAN.incl (a := y.1) (b := t) hy y.2) := by
      simp [hxy]
    _ = (C.ω y.1).toFun y.2 := by
      simpa using hy_at.symm
    _ = evalPre (Ω := Ω) N C y := by
      rfl

/-- The canonical quasilocal state induced by a compatible family of local states. -/
def stateLift
    (C : PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) N)) :
    StateOn (Carrier (Ω := Ω) N) where
  toFun :=
    Quot.lift
      (fun p => evalPre (Ω := Ω) N C p)
      (by
        intro x y h
        exact evalPre_respects (Ω := Ω) N C h)

@[simp] theorem stateLift_apply_ι
    (C : PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) N))
    {r : N.LAN.RN.Region} (x : N.LAN.Alg r) :
    (stateLift (Ω := Ω) N C).toFun (ι (Ω := Ω) N (r := r) x) =
      (C.ω r).toFun x := by
  simp [stateLift, evalPre, ι]

/-- Restrict a quasilocal state to a fixed region via the injection `ι`. -/
def restrictToRegion
    (Φ : StateOn (Carrier (Ω := Ω) N)) (r : N.LAN.RN.Region) :
    StateOn (N.LAN.Alg r) where
  toFun := fun x => Φ.toFun (ι (Ω := Ω) N (r := r) x)

@[simp] theorem restrictToRegion_apply
    (Φ : StateOn (Carrier (Ω := Ω) N))
    (r : N.LAN.RN.Region) (x : N.LAN.Alg r) :
    (restrictToRegion (Ω := Ω) N Φ r).toFun x = Φ.toFun (ι (Ω := Ω) N (r := r) x) := rfl

/-- Gate (B2.1): restricting the lifted quasilocal state recovers the original family. -/
theorem gate_restrictToRegion_stateLift
    (C : PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) N))
    (r : N.LAN.RN.Region) :
    restrictToRegion (Ω := Ω) N (stateLift (Ω := Ω) N C) r = C.ω r := by
  apply StateOn.ext
  intro x
  -- unfold restriction and use the computation on injections
  simp [restrictToRegion, stateLift_apply_ι]

end QuasiLocal

end AQFT
end PillarB
