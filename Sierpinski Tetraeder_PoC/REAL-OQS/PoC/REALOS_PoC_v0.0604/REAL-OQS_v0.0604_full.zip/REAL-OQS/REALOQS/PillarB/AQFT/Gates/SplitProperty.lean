import REALOQS.PillarB.Gates.SplitProperty

/-!
# Split property (compat import path)

The canonical definition of the split property gate lives in
`REALOQS.PillarB.Gates.SplitProperty`.

This file exists solely to provide the more granular import path
`REALOQS.PillarB.AQFT.Gates.SplitProperty`.
-/
