import Mathlib

import REALOQS.PillarB.AQFT.KMS
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullExp
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDensityState

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-!
# Full Hamiltonian dynamics with explicit time orientation (KMS-6a)

This file splits the former ambiguous full-Hamiltonian dynamics into two
explicit branches:

* `fullBoundaryDynPlus`  with `α⁺_t(A) = e^{+itH} A e^{-itH}`
* `fullBoundaryDynMinus` with `α⁻_t(A) = e^{-itH} A e^{+itH}`

Repo convention from KMS-6a onward:

* `Plus` = positive-time Heisenberg evolution
* `Minus` = negative-time / inverse Heisenberg evolution

The historical names `fullBoundaryDynMap`, `fullBoundaryDynHom`, `fullBoundaryDyn`
remain as compatibility aliases for the **plus** branch only.
-/

/-- Positive-time full Heisenberg action `A ↦ U_t^+ A (U_t^+)†`. -/
def fullBoundaryDynMapPlus (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) : Mat Ω :=
  unitaryFromLPlus (Ω := Ω) L t * A *
    Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t)

/-- Negative-time full Heisenberg action `A ↦ U_t^- A (U_t^-)†`. -/
def fullBoundaryDynMapMinus (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) : Mat Ω :=
  unitaryFromLMinus (Ω := Ω) L t * A *
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)

/-- Compatibility alias: the historical full dynamic map is the plus branch. -/
abbrev fullBoundaryDynMap (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) : Mat Ω :=
  fullBoundaryDynMapPlus (Ω := Ω) L t A

@[simp] theorem fullBoundaryDynMapPlus_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) (i j : Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t A i j =
      (unitaryFromLPlus (Ω := Ω) L t * A *
        Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t)) i j := rfl

@[simp] theorem fullBoundaryDynMapMinus_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) (i j : Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t A i j =
      (unitaryFromLMinus (Ω := Ω) L t * A *
        Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)) i j := rfl

@[simp] theorem fullBoundaryDynMap_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) (i j : Ω) :
    fullBoundaryDynMap (Ω := Ω) L t A i j =
      (unitaryFromLPlus (Ω := Ω) L t * A *
        Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t)) i j := rfl

@[simp] theorem fullBoundaryDynMapPlus_zero
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    fullBoundaryDynMapPlus (Ω := Ω) L t (0 : Mat Ω) = 0 := by
  simp [fullBoundaryDynMapPlus]

@[simp] theorem fullBoundaryDynMapMinus_zero
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    fullBoundaryDynMapMinus (Ω := Ω) L t (0 : Mat Ω) = 0 := by
  simp [fullBoundaryDynMapMinus]

@[simp] theorem fullBoundaryDynMap_zero
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    fullBoundaryDynMap (Ω := Ω) L t (0 : Mat Ω) = 0 :=
  fullBoundaryDynMapPlus_zero (Ω := Ω) L t

@[simp] theorem fullBoundaryDynMapPlus_add
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t (A + B) =
      fullBoundaryDynMapPlus (Ω := Ω) L t A +
      fullBoundaryDynMapPlus (Ω := Ω) L t B := by
  simp [fullBoundaryDynMapPlus, Matrix.mul_add, Matrix.add_mul, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMapMinus_add
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t (A + B) =
      fullBoundaryDynMapMinus (Ω := Ω) L t A +
      fullBoundaryDynMapMinus (Ω := Ω) L t B := by
  simp [fullBoundaryDynMapMinus, Matrix.mul_add, Matrix.add_mul, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMap_add
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L t (A + B) =
      fullBoundaryDynMap (Ω := Ω) L t A +
      fullBoundaryDynMap (Ω := Ω) L t B :=
  fullBoundaryDynMapPlus_add (Ω := Ω) L t A B

@[simp] theorem fullBoundaryDynMapPlus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t (-A) =
      -fullBoundaryDynMapPlus (Ω := Ω) L t A := by
  simp [fullBoundaryDynMapPlus, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMapMinus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t (-A) =
      -fullBoundaryDynMapMinus (Ω := Ω) L t A := by
  simp [fullBoundaryDynMapMinus, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMap_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L t (-A) =
      -fullBoundaryDynMap (Ω := Ω) L t A :=
  fullBoundaryDynMapPlus_neg (Ω := Ω) L t A

@[simp] theorem fullBoundaryDynMapPlus_smul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (c : ℂ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t (c • A) =
      c • fullBoundaryDynMapPlus (Ω := Ω) L t A := by
  simp [fullBoundaryDynMapPlus, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMapMinus_smul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (c : ℂ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t (c • A) =
      c • fullBoundaryDynMapMinus (Ω := Ω) L t A := by
  simp [fullBoundaryDynMapMinus, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMap_smul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (c : ℂ) (A : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L t (c • A) =
      c • fullBoundaryDynMap (Ω := Ω) L t A :=
  fullBoundaryDynMapPlus_smul (Ω := Ω) L t c A

@[simp] theorem fullBoundaryDynMapPlus_one
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    fullBoundaryDynMapPlus (Ω := Ω) L t (1 : Mat Ω) = 1 := by
  simp [fullBoundaryDynMapPlus,
    unitaryFromLPlus_mul_conjTranspose_self (Ω := Ω) L t hL]

@[simp] theorem fullBoundaryDynMapMinus_one
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    fullBoundaryDynMapMinus (Ω := Ω) L t (1 : Mat Ω) = 1 := by
  simp [fullBoundaryDynMapMinus,
    unitaryFromLMinus_mul_conjTranspose_self (Ω := Ω) L t hL]

@[simp] theorem fullBoundaryDynMap_one
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    fullBoundaryDynMap (Ω := Ω) L t (1 : Mat Ω) = 1 :=
  fullBoundaryDynMapPlus_one (Ω := Ω) L t hL

@[simp] theorem fullBoundaryDynMapPlus_star_map
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).star A) =
      (matrixStarAlgebraCStar Ω).star (fullBoundaryDynMapPlus (Ω := Ω) L t A) := by
  simp [fullBoundaryDynMapPlus, matrixStarAlgebraCStar_star_apply,
    Matrix.conjTranspose_mul, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMapMinus_star_map
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).star A) =
      (matrixStarAlgebraCStar Ω).star (fullBoundaryDynMapMinus (Ω := Ω) L t A) := by
  simp [fullBoundaryDynMapMinus, matrixStarAlgebraCStar_star_apply,
    Matrix.conjTranspose_mul, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMap_star_map
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).star A) =
      (matrixStarAlgebraCStar Ω).star (fullBoundaryDynMap (Ω := Ω) L t A) :=
  fullBoundaryDynMapPlus_star_map (Ω := Ω) L t A

@[simp] theorem fullBoundaryDynMapPlus_star
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    star (fullBoundaryDynMapPlus (Ω := Ω) L t A) =
      fullBoundaryDynMapPlus (Ω := Ω) L t (star A) := by
  simpa [matrixStarAlgebraCStar_star_apply, star_eq_conjTranspose] using
    (fullBoundaryDynMapPlus_star_map (Ω := Ω) L t A).symm

@[simp] theorem fullBoundaryDynMapMinus_star
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    star (fullBoundaryDynMapMinus (Ω := Ω) L t A) =
      fullBoundaryDynMapMinus (Ω := Ω) L t (star A) := by
  simpa [matrixStarAlgebraCStar_star_apply, star_eq_conjTranspose] using
    (fullBoundaryDynMapMinus_star_map (Ω := Ω) L t A).symm

@[simp] theorem fullBoundaryDynMap_star
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    star (fullBoundaryDynMap (Ω := Ω) L t A) =
      fullBoundaryDynMap (Ω := Ω) L t (star A) :=
  fullBoundaryDynMapPlus_star (Ω := Ω) L t A

@[simp] theorem fullBoundaryDynMapPlus_mul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω)
    (hL : Matrix.transpose L = L) :
    fullBoundaryDynMapPlus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).mul A B) =
      (matrixStarAlgebraCStar Ω).mul
        (fullBoundaryDynMapPlus (Ω := Ω) L t A)
        (fullBoundaryDynMapPlus (Ω := Ω) L t B) := by
  let U : Mat Ω := unitaryFromLPlus (Ω := Ω) L t
  calc
    fullBoundaryDynMapPlus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).mul A B)
        = U * A * B * Matrix.conjTranspose U := by
            simp [fullBoundaryDynMapPlus, matrixStarAlgebraCStar_mul_apply, U, Matrix.mul_assoc]
    _ = U * A * (1 : Mat Ω) * B * Matrix.conjTranspose U := by
            simp [Matrix.mul_assoc]
    _ = U * A * (Matrix.conjTranspose U * U) * B * Matrix.conjTranspose U := by
            rw [unitaryFromLPlus_conjTranspose_mul_self (Ω := Ω) L t hL]
    _ = (matrixStarAlgebraCStar Ω).mul
          (fullBoundaryDynMapPlus (Ω := Ω) L t A)
          (fullBoundaryDynMapPlus (Ω := Ω) L t B) := by
            simp [fullBoundaryDynMapPlus, matrixStarAlgebraCStar_mul_apply, U, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMapMinus_mul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω)
    (hL : Matrix.transpose L = L) :
    fullBoundaryDynMapMinus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).mul A B) =
      (matrixStarAlgebraCStar Ω).mul
        (fullBoundaryDynMapMinus (Ω := Ω) L t A)
        (fullBoundaryDynMapMinus (Ω := Ω) L t B) := by
  let U : Mat Ω := unitaryFromLMinus (Ω := Ω) L t
  calc
    fullBoundaryDynMapMinus (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).mul A B)
        = U * A * B * Matrix.conjTranspose U := by
            simp [fullBoundaryDynMapMinus, matrixStarAlgebraCStar_mul_apply, U, Matrix.mul_assoc]
    _ = U * A * (1 : Mat Ω) * B * Matrix.conjTranspose U := by
            simp [Matrix.mul_assoc]
    _ = U * A * (Matrix.conjTranspose U * U) * B * Matrix.conjTranspose U := by
            rw [unitaryFromLMinus_conjTranspose_mul_self (Ω := Ω) L t hL]
    _ = (matrixStarAlgebraCStar Ω).mul
          (fullBoundaryDynMapMinus (Ω := Ω) L t A)
          (fullBoundaryDynMapMinus (Ω := Ω) L t B) := by
            simp [fullBoundaryDynMapMinus, matrixStarAlgebraCStar_mul_apply, U, Matrix.mul_assoc]

@[simp] theorem fullBoundaryDynMap_mul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω)
    (hL : Matrix.transpose L = L) :
    fullBoundaryDynMap (Ω := Ω) L t ((matrixStarAlgebraCStar Ω).mul A B) =
      (matrixStarAlgebraCStar Ω).mul
        (fullBoundaryDynMap (Ω := Ω) L t A)
        (fullBoundaryDynMap (Ω := Ω) L t B) :=
  fullBoundaryDynMapPlus_mul (Ω := Ω) L t A B hL

@[simp] theorem fullBoundaryDynMapMinus_eq_fullBoundaryDynMapPlus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L t A =
      fullBoundaryDynMapPlus (Ω := Ω) L (-t) A := by
  simp [fullBoundaryDynMapMinus, fullBoundaryDynMapPlus,
    unitaryFromLMinus_eq_unitaryFromLPlus_neg]

@[simp] theorem fullBoundaryDynMapPlus_eq_fullBoundaryDynMapMinus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L t A =
      fullBoundaryDynMapMinus (Ω := Ω) L (-t) A := by
  calc
    fullBoundaryDynMapPlus (Ω := Ω) L t A
      = fullBoundaryDynMapPlus (Ω := Ω) L (-(-t)) A := by simp
    _ = fullBoundaryDynMapMinus (Ω := Ω) L (-t) A := by
      exact (fullBoundaryDynMapMinus_eq_fullBoundaryDynMapPlus_neg
        (Ω := Ω) L (-t) A).symm

/-- Positive-time full Heisenberg dynamics at fixed time as a bundled `*-hom`. -/
def fullBoundaryDynHomPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    StarAlgHom (matrixStarAlgebraCStar Ω) (matrixStarAlgebraCStar Ω) :=
  { toFun := fullBoundaryDynMapPlus (Ω := Ω) L t
    isHom :=
      { map_zero := fullBoundaryDynMapPlus_zero (Ω := Ω) L t
        map_one := fullBoundaryDynMapPlus_one (Ω := Ω) L t hL
        map_add := fullBoundaryDynMapPlus_add (Ω := Ω) L t
        map_mul := fun A B => fullBoundaryDynMapPlus_mul (Ω := Ω) L t A B hL
        map_neg := fullBoundaryDynMapPlus_neg (Ω := Ω) L t
        map_star := fullBoundaryDynMapPlus_star_map (Ω := Ω) L t } }

/-- Negative-time full Heisenberg dynamics at fixed time as a bundled `*-hom`. -/
def fullBoundaryDynHomMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    StarAlgHom (matrixStarAlgebraCStar Ω) (matrixStarAlgebraCStar Ω) :=
  { toFun := fullBoundaryDynMapMinus (Ω := Ω) L t
    isHom :=
      { map_zero := fullBoundaryDynMapMinus_zero (Ω := Ω) L t
        map_one := fullBoundaryDynMapMinus_one (Ω := Ω) L t hL
        map_add := fullBoundaryDynMapMinus_add (Ω := Ω) L t
        map_mul := fun A B => fullBoundaryDynMapMinus_mul (Ω := Ω) L t A B hL
        map_neg := fullBoundaryDynMapMinus_neg (Ω := Ω) L t
        map_star := fullBoundaryDynMapMinus_star_map (Ω := Ω) L t } }

/-- Compatibility alias: the historical full `*-hom` is the plus branch. -/
abbrev fullBoundaryDynHom
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    StarAlgHom (matrixStarAlgebraCStar Ω) (matrixStarAlgebraCStar Ω) :=
  fullBoundaryDynHomPlus (Ω := Ω) L t hL

@[simp] theorem fullBoundaryDynHomPlus_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    fullBoundaryDynHomPlus (Ω := Ω) L t hL A = fullBoundaryDynMapPlus (Ω := Ω) L t A := rfl

@[simp] theorem fullBoundaryDynHomMinus_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    fullBoundaryDynHomMinus (Ω := Ω) L t hL A = fullBoundaryDynMapMinus (Ω := Ω) L t A := rfl

@[simp] theorem fullBoundaryDynHom_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    fullBoundaryDynHom (Ω := Ω) L t hL A = fullBoundaryDynMap (Ω := Ω) L t A := rfl

@[simp] theorem fullBoundaryDynMapPlus_zero_apply
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L 0 A = A := by
  simp [fullBoundaryDynMapPlus, unitaryFromLPlus_zero (Ω := Ω) L]

@[simp] theorem fullBoundaryDynMapMinus_zero_apply
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L 0 A = A := by
  simp [fullBoundaryDynMapMinus, unitaryFromLMinus_zero (Ω := Ω) L]

@[simp] theorem fullBoundaryDyn_zero_apply
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L 0 A = A :=
  fullBoundaryDynMapPlus_zero_apply (Ω := Ω) L A

theorem fullBoundaryDynMapPlus_add_time
    (L : Matrix Ω Ω ℝ)
    (s t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapPlus (Ω := Ω) L (s + t) A =
      fullBoundaryDynMapPlus (Ω := Ω) L s
        (fullBoundaryDynMapPlus (Ω := Ω) L t A) := by
  calc
    fullBoundaryDynMapPlus (Ω := Ω) L (s + t) A
        = (unitaryFromLPlus (Ω := Ω) L s * unitaryFromLPlus (Ω := Ω) L t) * A *
            Matrix.conjTranspose
              (unitaryFromLPlus (Ω := Ω) L s * unitaryFromLPlus (Ω := Ω) L t) := by
              simp [fullBoundaryDynMapPlus, unitaryFromLPlus_add, Matrix.mul_assoc]
    _ = unitaryFromLPlus (Ω := Ω) L s *
          (unitaryFromLPlus (Ω := Ω) L t * A *
            Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t)) *
          Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L s) := by
            simp [Matrix.conjTranspose_mul, Matrix.mul_assoc]
    _ = fullBoundaryDynMapPlus (Ω := Ω) L s
          (fullBoundaryDynMapPlus (Ω := Ω) L t A) := by
            simp [fullBoundaryDynMapPlus, Matrix.mul_assoc]

theorem fullBoundaryDynMapMinus_add_time
    (L : Matrix Ω Ω ℝ)
    (s t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMapMinus (Ω := Ω) L (s + t) A =
      fullBoundaryDynMapMinus (Ω := Ω) L s
        (fullBoundaryDynMapMinus (Ω := Ω) L t A) := by
  calc
    fullBoundaryDynMapMinus (Ω := Ω) L (s + t) A
        = (unitaryFromLMinus (Ω := Ω) L s * unitaryFromLMinus (Ω := Ω) L t) * A *
            Matrix.conjTranspose
              (unitaryFromLMinus (Ω := Ω) L s * unitaryFromLMinus (Ω := Ω) L t) := by
              simp [fullBoundaryDynMapMinus, unitaryFromLMinus_add, Matrix.mul_assoc]
    _ = unitaryFromLMinus (Ω := Ω) L s *
          (unitaryFromLMinus (Ω := Ω) L t * A *
            Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)) *
          Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L s) := by
            simp [Matrix.conjTranspose_mul, Matrix.mul_assoc]
    _ = fullBoundaryDynMapMinus (Ω := Ω) L s
          (fullBoundaryDynMapMinus (Ω := Ω) L t A) := by
            simp [fullBoundaryDynMapMinus, Matrix.mul_assoc]

theorem fullBoundaryDynMap_add_time
    (L : Matrix Ω Ω ℝ)
    (s t : ℝ) (A : Mat Ω) :
    fullBoundaryDynMap (Ω := Ω) L (s + t) A =
      fullBoundaryDynMap (Ω := Ω) L s
        (fullBoundaryDynMap (Ω := Ω) L t A) :=
  fullBoundaryDynMapPlus_add_time (Ω := Ω) L s t A

/-- Positive-time full Heisenberg dynamics generated by the full Hamiltonian `L`. -/
def fullBoundaryDynPlus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := matrixStarAlgebraCStar Ω) :=
  { α := fun t => fullBoundaryDynHomPlus (Ω := Ω) L t hL
    map_zero := by
      apply StarAlgHom.ext
      intro A
      exact fullBoundaryDynMapPlus_zero_apply (Ω := Ω) L A
    map_add := by
      intro s t
      apply StarAlgHom.ext
      intro A
      exact fullBoundaryDynMapPlus_add_time (Ω := Ω) L s t A }

/-- Negative-time full Heisenberg dynamics generated by the full Hamiltonian `L`. -/
def fullBoundaryDynMinus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := matrixStarAlgebraCStar Ω) :=
  { α := fun t => fullBoundaryDynHomMinus (Ω := Ω) L t hL
    map_zero := by
      apply StarAlgHom.ext
      intro A
      exact fullBoundaryDynMapMinus_zero_apply (Ω := Ω) L A
    map_add := by
      intro s t
      apply StarAlgHom.ext
      intro A
      exact fullBoundaryDynMapMinus_add_time (Ω := Ω) L s t A }

/-- Compatibility alias: the historical full dynamics is the plus branch. -/
abbrev fullBoundaryDyn
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := matrixStarAlgebraCStar Ω) :=
  fullBoundaryDynPlus (Ω := Ω) L hL

@[simp] theorem fullBoundaryDynPlus_alpha_apply
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A : Mat Ω) :
    (fullBoundaryDynPlus (Ω := Ω) L hL).α t A =
      fullBoundaryDynMapPlus (Ω := Ω) L t A := rfl

@[simp] theorem fullBoundaryDynMinus_alpha_apply
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A : Mat Ω) :
    (fullBoundaryDynMinus (Ω := Ω) L hL).α t A =
      fullBoundaryDynMapMinus (Ω := Ω) L t A := rfl

@[simp] theorem fullBoundaryDyn_alpha_apply
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ) (A : Mat Ω) :
    (fullBoundaryDyn (Ω := Ω) L hL).α t A = fullBoundaryDynMap (Ω := Ω) L t A := rfl

section Invariance

variable [Nonempty Ω]

omit [Nonempty Ω] in
 theorem gibbsOpCore_mul_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    gibbsOpCore (Ω := Ω) L * unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L := by
  calc
    gibbsOpCore (Ω := Ω) L * unitaryFromLPlus (Ω := Ω) L t
        = hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) *
            hamExp (Ω := Ω) L (Complex.I * (t : ℂ)) := by
              simp [gibbsOpCore, unitaryFromLPlus]
    _ = hamExp (Ω := Ω) L ((-((1 : ℝ) : ℂ)) + Complex.I * (t : ℂ)) := by
              symm
              exact hamExp_add (Ω := Ω) L (-((1 : ℝ) : ℂ)) (Complex.I * (t : ℂ))
    _ = hamExp (Ω := Ω) L (Complex.I * (t : ℂ) + (-((1 : ℝ) : ℂ))) := by
              rw [add_comm]
    _ = unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L := by
              simpa [gibbsOpCore, unitaryFromLPlus] using
                (hamExp_add (Ω := Ω) L (Complex.I * (t : ℂ)) (-((1 : ℝ) : ℂ)))

omit [Nonempty Ω] in
 theorem gibbsOpCore_mul_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    gibbsOpCore (Ω := Ω) L * unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L := by
  rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
  exact gibbsOpCore_mul_unitaryFromLPlus (Ω := Ω) L (-t)

omit [Nonempty Ω] in
 theorem gibbsOpCore_mul_unitaryFromL
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    gibbsOpCore (Ω := Ω) L * unitaryFromL (Ω := Ω) L t =
      unitaryFromL (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L :=
  gibbsOpCore_mul_unitaryFromLPlus (Ω := Ω) L t

omit [Nonempty Ω] in
 theorem densityMatrixCore_mul_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    densityMatrixCore (Ω := Ω) L * unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L t * densityMatrixCore (Ω := Ω) L := by
  have hcommG := gibbsOpCore_mul_unitaryFromLPlus (Ω := Ω) L t
  calc
    densityMatrixCore (Ω := Ω) L * unitaryFromLPlus (Ω := Ω) L t
        = ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
            (gibbsOpCore (Ω := Ω) L * unitaryFromLPlus (Ω := Ω) L t)) := by
              simp [densityMatrixCore]
    _ = ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
            (unitaryFromLPlus (Ω := Ω) L t * gibbsOpCore (Ω := Ω) L)) := by
              rw [hcommG]
    _ = unitaryFromLPlus (Ω := Ω) L t * densityMatrixCore (Ω := Ω) L := by
              simp [densityMatrixCore]

omit [Nonempty Ω] in
 theorem densityMatrixCore_mul_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    densityMatrixCore (Ω := Ω) L * unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L t * densityMatrixCore (Ω := Ω) L := by
  rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
  exact densityMatrixCore_mul_unitaryFromLPlus (Ω := Ω) L (-t)

omit [Nonempty Ω] in
 theorem densityMatrixCore_mul_unitaryFromL
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    densityMatrixCore (Ω := Ω) L * unitaryFromL (Ω := Ω) L t =
      unitaryFromL (Ω := Ω) L t * densityMatrixCore (Ω := Ω) L :=
  densityMatrixCore_mul_unitaryFromLPlus (Ω := Ω) L t

theorem boundaryDensityState_invariant_fullDynPlus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) (t : ℝ) (A : Mat Ω) :
    boundaryDensityStateMat (Ω := Ω) L
      (fullBoundaryDynMapPlus (Ω := Ω) L t A)
    =
    boundaryDensityStateMat (Ω := Ω) L A := by
  let U : Mat Ω := unitaryFromLPlus (Ω := Ω) L t
  have hstate_left :=
    boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul
      (Ω := Ω) L hL (fullBoundaryDynMapPlus (Ω := Ω) L t A)
  have hstate_right :=
    boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul
      (Ω := Ω) L hL A
  rw [hstate_left, hstate_right]
  have hcommρ : densityMatrixCore (Ω := Ω) L * U = U * densityMatrixCore (Ω := Ω) L :=
    densityMatrixCore_mul_unitaryFromLPlus (Ω := Ω) L t
  calc
    matTrace (Ω := Ω)
        ((densityMatrixCore (Ω := Ω) L) * fullBoundaryDynMapPlus (Ω := Ω) L t A)
        = matTrace (Ω := Ω)
            (((densityMatrixCore (Ω := Ω) L) * U) * A * Matrix.conjTranspose U) := by
              simp [fullBoundaryDynMapPlus, U, Matrix.mul_assoc]
    _ = matTrace (Ω := Ω)
            ((U * densityMatrixCore (Ω := Ω) L) * A * Matrix.conjTranspose U) := by
              rw [hcommρ]
    _ = matTrace (Ω := Ω)
            (Matrix.conjTranspose U * (U * densityMatrixCore (Ω := Ω) L) * A) := by
              simpa [Matrix.mul_assoc] using
                (matTrace_mul_mul_mul_cycle (Ω := Ω)
                  (X := U * densityMatrixCore (Ω := Ω) L)
                  (Y := A)
                  (Z := Matrix.conjTranspose U))
    _ = matTrace (Ω := Ω)
            (((Matrix.conjTranspose U * U) * densityMatrixCore (Ω := Ω) L) * A) := by
              simp [Matrix.mul_assoc]
    _ = matTrace (Ω := Ω) ((densityMatrixCore (Ω := Ω) L) * A) := by
              rw [unitaryFromLPlus_conjTranspose_mul_self (Ω := Ω) L t hL]
              simp

theorem boundaryDensityState_invariant_fullDynMinus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) (t : ℝ) (A : Mat Ω) :
    boundaryDensityStateMat (Ω := Ω) L
      (fullBoundaryDynMapMinus (Ω := Ω) L t A)
    =
    boundaryDensityStateMat (Ω := Ω) L A := by
  rw [fullBoundaryDynMapMinus_eq_fullBoundaryDynMapPlus_neg (Ω := Ω) L t A]
  exact boundaryDensityState_invariant_fullDynPlus (Ω := Ω) L hL (-t) A

theorem boundaryDensityState_invariant_fullDyn
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) (t : ℝ) (A : Mat Ω) :
    boundaryDensityStateMat (Ω := Ω) L
      (fullBoundaryDynMap (Ω := Ω) L t A)
    =
    boundaryDensityStateMat (Ω := Ω) L A :=
  boundaryDensityState_invariant_fullDynPlus (Ω := Ω) L hL t A

end Invariance

end

end Derived
end AQFT
end PillarB
