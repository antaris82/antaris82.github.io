/-
REALOQS / Pillar B / Examples: Export surface (placeholder)

B0.0 intent:
- Keep a stable import target for Pillar-B example harnesses.
- Examples are not part of the core API, but they must remain buildable and
  serve as sanity checks for the interfaces.
-/
