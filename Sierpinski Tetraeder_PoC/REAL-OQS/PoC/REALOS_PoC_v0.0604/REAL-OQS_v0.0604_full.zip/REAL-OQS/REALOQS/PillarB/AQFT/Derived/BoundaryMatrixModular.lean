import REALOQS.PillarB.AQFT.KMS
import REALOQS.PillarB.AQFT.CStarKMSState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGNS
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u v

namespace ModularTransport

variable {A : Type u} {B : Type v}
variable {SA : StarAlgebra A} {SB : StarAlgebra B}

/-- Pull a lightweight state back along a `*-`isomorphism. -/
def transportState
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (φ : StateOn B) : StateOn A where
  toFun := fun a => φ (e.hom a)

@[simp] theorem transportState_apply
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (φ : StateOn B) (a : A) :
    transportState e φ a = φ (e.hom a) := rfl

/-- Transport a `*-`dynamics across a `*-`isomorphism. -/
def transportDynamics
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (D : StarAlgDynamics (SA := SB)) :
    StarAlgDynamics (SA := SA) where
  α := fun t => StarAlgHom.comp e.inv (StarAlgHom.comp (D.α t) e.hom)
  map_zero := by
    apply StarAlgHom.ext
    intro a
    simp [StarAlgDynamics.alpha_zero (D := D), StarAlgHom.comp_apply,
      e.left_inv]
  map_add := by
    intro s t
    apply StarAlgHom.ext
    intro a
    simp [StarAlgDynamics.alpha_add (D := D) s t, StarAlgHom.comp_apply,
      e.right_inv]

@[simp] theorem transportDynamics_alpha_apply
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (D : StarAlgDynamics (SA := SB))
    (t : ℝ) (a : A) :
    (transportDynamics e D).α t a = e.inv (D.α t (e.hom a)) := rfl

theorem transportInvariant
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (D : StarAlgDynamics (SA := SB))
    (φ : StateOn B)
    (hφ : IsInvariant (SA := SB) D φ) :
    IsInvariant (SA := SA) (transportDynamics e D) (transportState e φ) := by
  intro t a
  rw [transportState_apply, transportDynamics_alpha_apply, e.right_inv]
  exact hφ t (e.hom a)

theorem transportKMSStrip
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (D : StarAlgDynamics (SA := SB))
    (β : ℝ)
    (φ : StateOn B)
    (hφ : KMSStrip (SA := SB) D β φ) :
    KMSStrip (SA := SA) (transportDynamics e D) β (transportState e φ) := by
  intro a b
  rcases hφ (e.hom a) (e.hom b) with ⟨F, hDiff, hCont, hLower, hUpper⟩
  refine ⟨F, hDiff, hCont, ?_, ?_⟩
  · intro t
    rw [transportState_apply, transportDynamics_alpha_apply]
    rw [StarAlgHom.map_mul, e.right_inv]
    exact hLower t
  · intro t
    rw [transportState_apply, transportDynamics_alpha_apply]
    rw [StarAlgHom.map_mul, e.right_inv]
    exact hUpper t

theorem transportIsKMS
    (e : HaagKastler.StarAlgIso (SA := SA) (SB := SB))
    (D : StarAlgDynamics (SA := SB))
    (β : ℝ)
    (φ : StateOn B)
    (hφ : IsKMS (SA := SB) (D := D) β φ) :
    IsKMS (SA := SA) (D := transportDynamics e D) β (transportState e φ) where
  beta_pos := hφ.beta_pos
  invariant := transportInvariant e D φ hφ.invariant
  kmsStrip := transportKMSStrip e D β φ hφ.kmsStrip

end ModularTransport

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-- The concrete top-region `*-`algebra of the strict boundary block net. -/
abbrev boundaryMatrixModularTopSA :
    StarAlgebra ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω))) :=
  (boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixTopRegion (Ω := Ω))

/-- The strict minus-oriented top dynamics obtained by transporting the full
matrix dynamics across the concrete top-region `*-`isomorphism. -/
def boundaryMatrixTopDynMinus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := boundaryMatrixModularTopSA (Ω := Ω)) :=
  ModularTransport.transportDynamics
    (boundaryMatrixTopIsoMatrix (Ω := Ω))
    (fullBoundaryDynMinus (Ω := Ω) L hL)

@[simp] theorem boundaryMatrixTopDynMinus_alpha_apply
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L)
    (t : ℝ)
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω))) :
    (boundaryMatrixTopDynMinus (Ω := Ω) L hL).α t A =
      matrixToTopRegion (Ω := Ω)
        ((fullBoundaryDynMinus (Ω := Ω) L hL).α t (RegionBlockMat.toMatrix A)) := by
  rfl

section TopModular

variable [Nonempty Ω]
variable (L : Matrix Ω Ω ℝ) (β : ℝ)
variable (hβ : 0 < β) (hL : Matrix.transpose L = L)

/-- The top-region state is exactly the pullback of the strong matrix state along
`boundaryMatrixTopIsoMatrix`. -/
theorem boundaryMatrixTop_eq_transportState :
    ModularTransport.transportState
      (boundaryMatrixTopIsoMatrix (Ω := Ω))
      ((boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn) =
    boundaryMatrixTop (Ω := Ω) L β hL := by
  apply StateOn.ext
  intro A
  rw [ModularTransport.transportState_apply, boundaryMatrixTop_apply]
  change (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn.toFun
      ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom A) =
    boundaryDensityStateMatAtBeta (Ω := Ω) L β
      ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom A)
  exact boundaryDensityStateAtBeta_toStateOn_apply (Ω := Ω) L β hL
    ((boundaryMatrixTopIsoMatrix (Ω := Ω)).hom A)

/-- Strict top-region KMS datum obtained by transporting the concrete matrix KMS
state to the top block-matrix algebra. -/
def boundaryMatrixTopKMSMinusAtBeta :
    KMSState (SA := boundaryMatrixModularTopSA (Ω := Ω)) where
  β := β
  dyn := boundaryMatrixTopDynMinus (Ω := Ω) L hL
  state := boundaryMatrixTop (Ω := Ω) L β hL
  isKMS := by
    let hKMS :
        IsKMS
          (SA := boundaryMatrixModularTopSA (Ω := Ω))
          (D := ModularTransport.transportDynamics
            (boundaryMatrixTopIsoMatrix (Ω := Ω))
            (fullBoundaryDynMinus (Ω := Ω) L hL))
          β
          (ModularTransport.transportState
            (boundaryMatrixTopIsoMatrix (Ω := Ω))
            ((boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn)) :=
      ModularTransport.transportIsKMS
        (e := boundaryMatrixTopIsoMatrix (Ω := Ω))
        (D := fullBoundaryDynMinus (Ω := Ω) L hL)
        (β := β)
        (φ := (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn)
        ((boundaryFullKMSMinusAtBeta (Ω := Ω) L β hβ hL).isKMS)
    have hState :
        ModularTransport.transportState
          (boundaryMatrixTopIsoMatrix (Ω := Ω))
          ((boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn) =
        boundaryMatrixTop (Ω := Ω) L β hL :=
      boundaryMatrixTop_eq_transportState (Ω := Ω) L β hL
    change IsKMS
      (SA := boundaryMatrixModularTopSA (Ω := Ω))
      (D := ModularTransport.transportDynamics
        (boundaryMatrixTopIsoMatrix (Ω := Ω))
        (fullBoundaryDynMinus (Ω := Ω) L hL))
      β
      (boundaryMatrixTop (Ω := Ω) L β hL)
    exact hState ▸ hKMS

@[simp] theorem boundaryMatrixTopKMSMinusAtBeta_beta :
    (boundaryMatrixTopKMSMinusAtBeta (Ω := Ω) L β hβ hL).β = β := rfl

@[simp] theorem boundaryMatrixTopKMSMinusAtBeta_dyn :
    (boundaryMatrixTopKMSMinusAtBeta (Ω := Ω) L β hβ hL).dyn =
      boundaryMatrixTopDynMinus (Ω := Ω) L hL := rfl

@[simp] theorem boundaryMatrixTopKMSMinusAtBeta_state :
    (boundaryMatrixTopKMSMinusAtBeta (Ω := Ω) L β hβ hL).state =
      boundaryMatrixTop (Ω := Ω) L β hL := rfl

/-- Concrete B-side modular/KMS datum on the active top boundary path. -/
structure BoundaryMatrixModularDatum
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) where
  matrixKMS : CStarKMSStateOn (Mat Ω)
  topKMS : KMSState (SA := boundaryMatrixModularTopSA (Ω := Ω))
  gns : GNSDatum
    (SA := boundaryMatrixModularTopSA (Ω := Ω))
    (ω := boundaryMatrixTop (Ω := Ω) L β hL)
  matrixKMS_beta_eq : matrixKMS.β = β
  topKMS_beta_eq : topKMS.β = β
  topKMS_dyn_eq : topKMS.dyn = boundaryMatrixTopDynMinus (Ω := Ω) L hL
  topKMS_state_eq : topKMS.state = boundaryMatrixTop (Ω := Ω) L β hL
  state_from_cyclic : ∀ A,
    boundaryMatrixTop (Ω := Ω) L β hL A =
      gns.sesq gns.cyclicVec (gns.pi A gns.cyclicVec)

/-- Active B-side modular/KMS datum on the strict finite top boundary path. -/
def boundaryMatrixTopModularDatum :
    BoundaryMatrixModularDatum (Ω := Ω) L β hL where
  matrixKMS := boundaryFullKMSMinusAtBeta (Ω := Ω) L β hβ hL
  topKMS := boundaryMatrixTopKMSMinusAtBeta (Ω := Ω) L β hβ hL
  gns := boundaryMatrixTopGNSDatum (Ω := Ω) L β hL
  matrixKMS_beta_eq := by rfl
  topKMS_beta_eq := by rfl
  topKMS_dyn_eq := by rfl
  topKMS_state_eq := by rfl
  state_from_cyclic := by
    intro A
    change boundaryMatrixTop (Ω := Ω) L β hL A =
      boundaryMatrixGNSSesq (Ω := Ω) L β hL
        (boundaryMatrixGNSCyclicVec (Ω := Ω))
        (boundaryMatrixTopGNSPi (Ω := Ω) A (boundaryMatrixGNSCyclicVec (Ω := Ω)))
    exact boundaryMatrixTop_state_from_cyclic (Ω := Ω) L β hL A

@[simp] theorem boundaryMatrixTopModularDatum_matrixKMS :
    (boundaryMatrixTopModularDatum (L := L) (β := β) (hβ := hβ) (hL := hL)).matrixKMS =
      boundaryFullKMSMinusAtBeta (Ω := Ω) L β hβ hL := rfl

@[simp] theorem boundaryMatrixTopModularDatum_topKMS :
    (boundaryMatrixTopModularDatum (L := L) (β := β) (hβ := hβ) (hL := hL)).topKMS =
      boundaryMatrixTopKMSMinusAtBeta (Ω := Ω) L β hβ hL := rfl

@[simp] theorem boundaryMatrixTopModularDatum_gns :
    (boundaryMatrixTopModularDatum (L := L) (β := β) (hβ := hβ) (hL := hL)).gns =
      boundaryMatrixTopGNSDatum (Ω := Ω) L β hL := rfl

end TopModular

end

end Derived
end AQFT
end PillarB
