import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized
import REALOQS.PillarA.Physics.Instances.TreeOfCliquesBoundaryK1Shape
import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace Adapter
namespace TreeOfCliquesAQFTHandoff

noncomputable section

open PillarA.LayerA
open PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized

variable {b : Nat}

/-- On the concrete ToC→AQFT handoff path, if `L_max = 1` then the exported
boundary operator has constant diagonal. -/
theorem L_diag_indep_of_Lmax_eq_one
    (p : Policy b) (hL : p.L_max = 1) :
    ∀ x y : Ω (p := p), L (p := p) x x = L (p := p) y y := by
  rcases p with ⟨Lmax⟩
  cases hL
  intro x y
  let p1 : Policy b := { L_max := 1 }
  have hreduce :=
    _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.reduce_LBB_eq_dtn_stab
      (b := b) (p := p1)
  have hx :
      L (p := p1) x x =
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p1) 1) x x := by
    simpa [p1, L, st1, st0,
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized] using
      congrArg (fun M => M x x) hreduce
  have hy :
      L (p := p1) y y =
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p1) 1) y y := by
    simpa [p1, L, st1, st0,
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized] using
      congrArg (fun M => M y y) hreduce
  calc
    L (p := p1) x x
        = (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
            (b := b) (p := p1) 1) x x := hx
    _ = (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p1) 1) y y :=
        _root_.PillarA.Physics.Instances.TreeOfCliques.ToC.dtn_stabilized_k1_diag_indep
          (b := b) (p := p1) x y
    _ = L (p := p1) y y := hy.symm

/-- Consequently, there is no diagonal gap on the exported handoff operator when
`L_max = 1`. -/
theorem L_no_diag_gap_of_Lmax_eq_one
    (p : Policy b) (hL : p.L_max = 1) :
    ¬ ∃ x y : Ω (p := p), L (p := p) x x ≠ L (p := p) y y := by
  intro h
  rcases h with ⟨x, y, hxy⟩
  exact hxy (L_diag_indep_of_Lmax_eq_one (b := b) (p := p) hL x y)

end

end TreeOfCliquesAQFTHandoff
end Adapter
end Ideal
end PillarA

namespace PillarB
namespace AQFT
namespace Derived
namespace TreeOfCliquesFromPillarA

noncomputable section

variable {b : Nat}

namespace ToC

/-- Lift of the `L_max = 1` diagonal-independence audit to the concrete
`TreeOfCliquesFromPillarA` AQFT bridge aliases. -/
theorem L_diag_indep_of_Lmax_eq_one
    (p : _root_.PillarA.LayerA.Policy b) (hL : p.L_max = 1) :
    ∀ x y : Ω (b := b) (p := p),
      L (b := b) (p := p) x x = L (b := b) (p := p) y y :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_diag_indep_of_Lmax_eq_one
    (b := b) (p := p) hL

/-- Alias-level no-gap statement for the concrete ToC→AQFT bridge. -/
theorem L_no_diag_gap_of_Lmax_eq_one
    (p : _root_.PillarA.LayerA.Policy b) (hL : p.L_max = 1) :
    ¬ ∃ x y : Ω (b := b) (p := p),
        L (b := b) (p := p) x x ≠ L (b := b) (p := p) y y :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_no_diag_gap_of_Lmax_eq_one
    (b := b) (p := p) hL

end ToC

end

end TreeOfCliquesFromPillarA
end Derived
end AQFT
end PillarB
