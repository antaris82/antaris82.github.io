import Mathlib.Data.ZMod.Basic
import REALOQS.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.TimeOrientation
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixTimeReversal
import REALOQS.PillarB.Gates.HaagKastler.Isotony
import REALOQS.PillarB.Gates.HaagKastler.Locality
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocality
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixSplitProperty
import REALOQS.PillarB.Gates.HaagKastler.Spectrum
import REALOQS.PillarB.Gates.SplitProperty
import REALOQS.PillarA.Core.MatrixNorms

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived
namespace TreeOfCliquesExtendedFromPillarA

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
open _root_.PillarA.LayerA

variable {b : Nat}

namespace ToC

variable (p : _root_.PillarA.LayerA.Policy b)

/-- Canonical non-vacuous disjointness predicate used for the concrete ToC bridge net. -/
abbrev D_ToC : Region.CausalDisjoint (RN := (N_ToC (b := b) (p := p)).LAN.RN) :=
  _root_.PillarB.AQFT.Derived.boundaryMatrixCarrierDisjoint (Ω := Ω (b := b) (p := p))

/-- Concrete non-vacuous Haag–Kastler locality on the canonical ToC-from-A bridge net. -/
theorem locality_ToC :
    PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_ToC (b := b) (p := p))
      (D := D_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.boundaryMatrixLocality (Ω := Ω (b := b) (p := p))

/-- Concrete Haag–Kastler isotony on the canonical ToC-from-A bridge net. -/
theorem isotony_ToC :
    PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_ToC (b := b) (p := p)) := by
  intro a c hab
  exact
    _root_.PillarB.AQFT.Derived.boundaryMatrixIncl_injective
      (Ω := Ω (b := b) (p := p)) hab

/-- Distinguished top region of the concrete ToC bridge net. -/
abbrev topRegion : (N_ToC (b := b) (p := p)).LAN.RN.Region :=
  (Finset.univ : Finset (Ω (b := b) (p := p)))

/-- β-positivity on the canonical ToC bridge path. -/
theorem beta_pos_ToC : 0 < (T (b := b) (p := p)).β := by
  simpa [T] using
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)

@[simp] theorem T_beta_eq_betaFromA :
    (T (b := b) (p := p)).β =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p := rfl

/-- L-dependent energy scale used to tie B-side spectral data to the A-handoff. -/
noncomputable def energyScale_ToC : ℝ :=
  MatrixNorm.frob (L (b := b) (p := p))

theorem energyScale_nonneg_ToC : 0 ≤ energyScale_ToC (b := b) (p := p) := by
  unfold energyScale_ToC
  exact Real.sqrt_nonneg _


/-! ## Matrix carriers on the concrete ToC handoff -/

/-- Matrix-algebra carrier used for the ToC boundary operator. -/
abbrev MatrixA_ToC : Type :=
  _root_.PillarB.AQFT.Derived.Mat (Ω := Ω (b := b) (p := p))

/-- C⋆-bundled matrix *-algebra used by the strict full-Hamiltonian path. -/
abbrev MatrixCSA_ToC : _root_.PillarB.AQFT.StarAlgebra (MatrixA_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.matrixStarAlgebraCStar (Ω := Ω (b := b) (p := p))

/-- Local alias exposing the Pillar-A symmetry proof for the exported ToC matrix `L`. -/
theorem L_symm_ToC :
    Matrix.transpose (L (b := b) (p := p)) = L (b := b) (p := p) := by
  exact
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-! ## Strict full-Hamiltonian oriented path introduced in KMS-8 -/

/-- Positive-time full Heisenberg dynamics attached to the ToC handoff matrix `L`. -/
def matrixDynPlus_ToC :
    _root_.PillarB.AQFT.StarAlgDynamics (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.fullBoundaryDynPlus
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    (L_symm_ToC (b := b) (p := p))

/-- Negative-time full Heisenberg dynamics attached to the ToC handoff matrix `L`. -/
def matrixDynMinus_ToC :
    _root_.PillarB.AQFT.StarAlgDynamics (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.fullBoundaryDynMinus
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    (L_symm_ToC (b := b) (p := p))

/-- Explicit alias for the new strict full-minus ToC dynamics. -/
abbrev matrixDynFullMinus_ToC :
    _root_.PillarB.AQFT.StarAlgDynamics (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  matrixDynMinus_ToC (b := b) (p := p)

@[simp] theorem matrixDynPlus_ToC_orientation :
    _root_.PillarB.AQFT.boundaryMatrixDyn
      (Ω := Ω (b := b) (p := p))
      _root_.PillarB.AQFT.TimeOrientation.plus
      (L (b := b) (p := p))
      (L_symm_ToC (b := b) (p := p)) =
      matrixDynPlus_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixDynMinus_ToC_orientation :
    _root_.PillarB.AQFT.boundaryMatrixDyn
      (Ω := Ω (b := b) (p := p))
      _root_.PillarB.AQFT.TimeOrientation.minus
      (L (b := b) (p := p))
      (L_symm_ToC (b := b) (p := p)) =
      matrixDynMinus_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixDynFullMinus_ToC_eq_matrixDynMinus_ToC :
    matrixDynFullMinus_ToC (b := b) (p := p) = matrixDynMinus_ToC (b := b) (p := p) := by
  rfl

/-- Active public ToC dynamics name after KMS-9: the full-minus path. -/
abbrev matrixDyn_ToC :
    _root_.PillarB.AQFT.StarAlgDynamics (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  matrixDynMinus_ToC (b := b) (p := p)

@[simp] theorem matrixDyn_ToC_eq_matrixDynMinus_ToC :
    matrixDyn_ToC (b := b) (p := p) = matrixDynMinus_ToC (b := b) (p := p) := by
  rfl


/--
Time reversal intertwines the explicit ToC plus/minus full dynamics.

This records, at the ToC bridge level, that the strict KMS-8 path is not merely
`t ↦ -t` syntax but sits inside the oriented time-reversal framework added in
KMS-6a/KMS-7.
-/
theorem matrixTimeReversal_intertwines_ToC :
    _root_.PillarB.AQFT.TimeReversalIntertwines
      (A := MatrixA_ToC (b := b) (p := p))
      (SA := MatrixCSA_ToC (b := b) (p := p))
      (_root_.PillarB.AQFT.Derived.matrixTimeReversal
        (Ω := Ω (b := b) (p := p)))
      (matrixDynPlus_ToC (b := b) (p := p))
      (matrixDynMinus_ToC (b := b) (p := p) ) := by
  intro t A
  change
    _root_.PillarB.AQFT.Derived.matrixTimeReversalMap (Ω := Ω (b := b) (p := p))
      ((matrixDynPlus_ToC (b := b) (p := p)).α t A)
    =
    (matrixDynMinus_ToC (b := b) (p := p)).α t
      (_root_.PillarB.AQFT.Derived.matrixTimeReversalMap
        (Ω := Ω (b := b) (p := p)) A)
  rw [matrixDynPlus_ToC, matrixDynMinus_ToC]
  rw [_root_.PillarB.AQFT.Derived.fullBoundaryDynPlus_alpha_apply,
    _root_.PillarB.AQFT.Derived.fullBoundaryDynMinus_alpha_apply]
  exact _root_.PillarB.AQFT.Derived.matrixTimeReversal_fullBoundaryDynMapPlus
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p)) t A

section StrictFullMinusKMS

variable [Fact (0 < b)]

/--
Strong C⋆-level full-Hamiltonian KMS witness on the canonical ToC handoff,
attached to the **minus** branch and the derived `betaFromA` value.
-/
def matrixFullKMSMinus_ToC :
    _root_.PillarB.AQFT.CStarKMSStateOn (MatrixA_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.boundaryFullKMSMinusAtBeta
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (hβ := beta_pos_ToC (b := b) (p := p))
    (hL := L_symm_ToC (b := b) (p := p))

def matrixKMSFullMinus_ToC :
    _root_.PillarB.AQFT.KMSState (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  (matrixFullKMSMinus_ToC (b := b) (p := p)).toKMSState

/-- Explicit alias for the strict full-minus `KMSState` bridge. -/
abbrev matrixKMSStrict_ToC :
    _root_.PillarB.AQFT.KMSState (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  matrixKMSFullMinus_ToC (b := b) (p := p)

@[simp] theorem matrixFullKMSMinus_ToC_beta :
    (matrixFullKMSMinus_ToC (b := b) (p := p)).β = (T (b := b) (p := p)).β := by
  rfl

@[simp] theorem matrixFullKMSMinus_ToC_beta_eq_betaFromA :
    (matrixFullKMSMinus_ToC (b := b) (p := p)).β =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p := by
  rw [matrixFullKMSMinus_ToC_beta, T_beta_eq_betaFromA]

@[simp] theorem matrixFullKMSMinus_ToC_dyn :
    (matrixFullKMSMinus_ToC (b := b) (p := p)).dyn =
      matrixDynMinus_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixFullKMSMinus_ToC_state :
    (matrixFullKMSMinus_ToC (b := b) (p := p)).state =
      _root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (L_symm_ToC (b := b) (p := p)) := by
  rfl

@[simp] theorem matrixFullKMSMinus_ToC_state_apply (A : MatrixA_ToC (b := b) (p := p)) :
    (matrixFullKMSMinus_ToC (b := b) (p := p)).state A =
      _root_.PillarB.AQFT.Derived.boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        A := by
  exact _root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta_apply
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (L_symm_ToC (b := b) (p := p))
    A

@[simp] theorem matrixKMSFullMinus_ToC_beta :
    (matrixKMSFullMinus_ToC (b := b) (p := p)).β = (T (b := b) (p := p)).β := by
  rfl

@[simp] theorem matrixKMSFullMinus_ToC_beta_eq_betaFromA :
    (matrixKMSFullMinus_ToC (b := b) (p := p)).β =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p := by
  rw [matrixKMSFullMinus_ToC_beta, T_beta_eq_betaFromA]

@[simp] theorem matrixKMSFullMinus_ToC_dyn :
    (matrixKMSFullMinus_ToC (b := b) (p := p)).dyn =
      matrixDynMinus_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixKMSFullMinus_ToC_state :
    (matrixKMSFullMinus_ToC (b := b) (p := p)).state =
      (_root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (L_symm_ToC (b := b) (p := p))).toStateOn := by
  rfl

@[simp] theorem matrixKMSFullMinus_ToC_state_apply (A : MatrixA_ToC (b := b) (p := p)) :
    (matrixKMSFullMinus_ToC (b := b) (p := p)).state A =
      _root_.PillarB.AQFT.Derived.boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        A := by
  exact _root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta_toStateOn_apply
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (L_symm_ToC (b := b) (p := p))
    A

@[simp] theorem matrixKMSStrict_ToC_eq_matrixKMSFullMinus_ToC :
    matrixKMSStrict_ToC (b := b) (p := p) = matrixKMSFullMinus_ToC (b := b) (p := p) := by
  rfl

/-- Active public ToC KMS witness after KMS-9: the full-minus bridge path. -/
abbrev matrixKMS_ToC :
    _root_.PillarB.AQFT.KMSState (SA := MatrixCSA_ToC (b := b) (p := p)) :=
  matrixKMSFullMinus_ToC (b := b) (p := p)

@[simp] theorem matrixKMS_ToC_eq_matrixKMSFullMinus_ToC :
    matrixKMS_ToC (b := b) (p := p) = matrixKMSFullMinus_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixKMS_ToC_beta :
    (matrixKMS_ToC (b := b) (p := p)).β = (T (b := b) (p := p)).β := by
  rfl

@[simp] theorem matrixKMS_ToC_beta_eq_betaFromA :
    (matrixKMS_ToC (b := b) (p := p)).β =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p := by
  rw [matrixKMS_ToC_beta, T_beta_eq_betaFromA]

@[simp] theorem matrixKMS_ToC_dyn :
    (matrixKMS_ToC (b := b) (p := p)).dyn = matrixDyn_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem matrixKMS_ToC_state :
    (matrixKMS_ToC (b := b) (p := p)).state =
      (_root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (L_symm_ToC (b := b) (p := p))).toStateOn := by
  rfl

@[simp] theorem matrixKMS_ToC_state_apply (A : MatrixA_ToC (b := b) (p := p)) :
    (matrixKMS_ToC (b := b) (p := p)).state A =
      _root_.PillarB.AQFT.Derived.boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        A := by
  exact _root_.PillarB.AQFT.Derived.boundaryDensityStateAtBeta_toStateOn_apply
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (L_symm_ToC (b := b) (p := p))
    A

end StrictFullMinusKMS

section StrictMatrixState

variable [Fact (0 < b)]

/-- Strict local region state imported from the BQ-2 state-restriction
layer on the active ToC path. -/
abbrev ρRegion (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r) :=
  _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.ρRegion
    (b := b) (p := p) r

@[simp] theorem ρRegion_top :
    ρRegion (b := b) (p := p) (topRegion (b := b) (p := p)) =
      ρTop (b := b) (p := p) := by
  exact _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC.ρRegion_top
    (b := b) (p := p)

/--
Interim A→B modular/KMS datum.

During KMS-8 the local-region state is still the bridge state `ρRegion`, but the
semantic payload now records the symmetry of the exported Hamiltonian and the
chosen time orientation of the strict full-Hamiltonian path.
-/
structure HamiltonianKMSDatum
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) where
  β : ℝ
  beta_pos : 0 < β
  H : Matrix (Ω (b := b) (p := p)) (Ω (b := b) (p := p)) ℝ
  hHsymm : Matrix.transpose H = H
  dynOrientation : _root_.PillarB.AQFT.TimeOrientation
  state : StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r)

/-- Regionwise modular/KMS datum tied to the concrete ToC handoff. -/
def hamiltonianKMSDatum_region
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    HamiltonianKMSDatum (b := b) (p := p) r :=
  { β := (T (b := b) (p := p)).β
    beta_pos := beta_pos_ToC (b := b) (p := p)
    H := L (b := b) (p := p)
    hHsymm := L_symm_ToC (b := b) (p := p)
    dynOrientation := _root_.PillarB.AQFT.TimeOrientation.minus
    state := ρRegion (b := b) (p := p) r }

/-- Top-region modular/KMS datum tied to the concrete ToC handoff. -/
def hamiltonianKMSDatum_top :
    HamiltonianKMSDatum (b := b) (p := p) (topRegion (b := b) (p := p)) :=
  hamiltonianKMSDatum_region (b := b) (p := p) (topRegion (b := b) (p := p))

@[simp] theorem hamiltonianKMSDatum_top_H :
    (hamiltonianKMSDatum_top (b := b) (p := p)).H = L (b := b) (p := p) := rfl

@[simp] theorem hamiltonianKMSDatum_top_hHsymm :
    (hamiltonianKMSDatum_top (b := b) (p := p)).hHsymm =
      L_symm_ToC (b := b) (p := p) := rfl

@[simp] theorem hamiltonianKMSDatum_top_dynOrientation :
    (hamiltonianKMSDatum_top (b := b) (p := p)).dynOrientation =
      _root_.PillarB.AQFT.TimeOrientation.minus := rfl

theorem hamiltonianKMSDatum_top_state :
    (hamiltonianKMSDatum_top (b := b) (p := p)).state = ρTop (b := b) (p := p) := by
  change ρRegion (b := b) (p := p) (topRegion (b := b) (p := p)) =
      ρTop (b := b) (p := p)
  exact ρRegion_top (b := b) (p := p)

end StrictMatrixState

/-- Derived split witness for the concrete ToC bridge net, tied to A-handoff data.
It uses the explicit image of the smaller local algebra inside the larger one. -/
def splitWitness_ToC
    {a b' : (N_ToC (b := b) (p := p)).LAN.RN.Region} (hab : a ≤ b') :
    PillarB.AQFT.Gates.SplitWitness (N := N_ToC (b := b) (p := p)) hab :=
  _root_.PillarB.AQFT.Derived.boundaryMatrixSplitWitness
    (Ω := Ω (b := b) (p := p)) hab

/-- Concrete split property, now pinned to the strict A-handoff data. -/
theorem splitProperty_ToC :
    PillarB.AQFT.Gates.SplitProperty
      (N := N_ToC (b := b) (p := p)) :=
  _root_.PillarB.AQFT.Derived.boundaryMatrixSplitProperty
    (Ω := Ω (b := b) (p := p))

/-- The explicit ToC split witness is concretely Type I in the current finite gate
sense, via an explicit `*-`isomorphism back to the smaller local algebra. -/
theorem splitWitness_ToC_isTypeI
    {a b' : (N_ToC (b := b) (p := p)).LAN.RN.Region} (hab : a ≤ b') :
    (splitWitness_ToC (b := b) (p := p) hab).isTypeI :=
  _root_.PillarB.AQFT.Derived.boundaryMatrixSplitWitness_isTypeI
    (Ω := Ω (b := b) (p := p)) hab

section StrictSpectrumData

variable [Fact (0 < b)]

/-- Translation carrier for the A-bound spectrum witness. -/
abbrev TransGroup_ToC : Type := ZMod ((T (b := b) (p := p)).d)

/-- Representation carrier tied to the top ToC algebra and the derived local-value count. -/
abbrev RepCarrier_ToC : Type :=
  (TransGroup_ToC (b := b) (p := p)) ×
    ((N_ToC (b := b) (p := p)).LAN.Alg (topRegion (b := b) (p := p)))

/-- Canonical translation action on the representation carrier. -/
def shiftEquiv_ToC (g : TransGroup_ToC (b := b) (p := p)) :
    RepCarrier_ToC (b := b) (p := p) ≃ RepCarrier_ToC (b := b) (p := p) where
  toFun x := (x.1 + g, x.2)
  invFun x := (x.1 - g, x.2)
  left_inv := by
    intro x
    ext
    · exact add_sub_cancel_right x.1 g
    · rfl
  right_inv := by
    intro x
    ext
    · exact sub_add_cancel x.1 g
    · rfl

/-- Net-attached representation data using the concrete top algebra
and a derived translation carrier. -/
def repData_ToC : RepData (TransGroup_ToC (b := b) (p := p)) where
  H := RepCarrier_ToC (b := b) (p := p)
  U := shiftEquiv_ToC (b := b) (p := p)

/-- Canonical momentum point induced by the A-side boundary operator norm. -/
def momentumPoint_ToC : Momentum :=
  (energyScale_ToC (b := b) (p := p), 0, 0, 0)

/-- Canonical positive-energy support witness derived from the A-handoff operator `L`. -/
def spectrumWitness_ToC : SpectrumWitness where
  support := {momentumPoint_ToC (b := b) (p := p)}
  support_subset_forward := by
    intro q hq
    rcases Set.mem_singleton_iff.mp hq with rfl
    unfold ForwardCone forwardCone momentumPoint_ToC
    constructor
    · exact energyScale_nonneg_ToC (b := b) (p := p)
    · nlinarith [sq_nonneg (energyScale_ToC (b := b) (p := p))]

/-- Spectrum gate attached to the concrete ToC-from-A bridge net. -/
def spectrumCondition_ToC :
    PillarB.AQFT.Gates.HaagKastler.SpectrumCondition
      (N := N_ToC (b := b) (p := p))
      (T := TransGroup_ToC (b := b) (p := p)) where
  witness :=
    { rep := repData_ToC (b := b) (p := p)
      spec := spectrumWitness_ToC (b := b) (p := p) }

end StrictSpectrumData

end ToC

end

end TreeOfCliquesExtendedFromPillarA
end Derived
end AQFT
end PillarB
