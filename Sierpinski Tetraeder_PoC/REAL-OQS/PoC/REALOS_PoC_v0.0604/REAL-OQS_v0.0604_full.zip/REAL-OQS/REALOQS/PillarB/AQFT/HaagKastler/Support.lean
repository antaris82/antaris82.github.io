import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace HaagKastler

/-!
# Support definitions for Haag–Kastler style gates

This file contains small, substrate-agnostic helper structures that are useful
when stating Haag–Kastler axioms as *gates*.

Design constraints:
* no IDEAL imports (only Pillar A core + Pillar B AQFT minimal layer)
* minimal algebraic commitments (use the bundled `StarAlgebra` layer)
-/

universe u v

/-!
## Basic commutation predicate
-/

section Commute

variable {A : Type u} (SA : StarAlgebra A)

/-- `Commute SA x y` means `x` and `y` commute in the *-algebra `SA`. -/
def Commute (x y : A) : Prop :=
  SA.mul x y = SA.mul y x

theorem commute_symm {x y : A} : Commute SA x y → Commute SA y x := by
  intro h
  dsimp [Commute] at *
  simp [h]

end Commute

/-!
## *-algebra isomorphisms

We keep this lightweight: an isomorphism is a pair of *-homomorphisms that are
mutual inverses.
-/

section Iso

variable {A : Type u} {B : Type v}
variable (SA : StarAlgebra A) (SB : StarAlgebra B)

structure StarAlgIso where
  hom : StarAlgHom SA SB
  inv : StarAlgHom SB SA
  left_inv : ∀ x : A, inv (hom x) = x
  right_inv : ∀ y : B, hom (inv y) = y

namespace StarAlgIso

variable {SA : StarAlgebra A} {SB : StarAlgebra B}

theorem hom_injective (e : StarAlgIso (SA := SA) (SB := SB)) : Function.Injective e.hom := by
  intro x y h
  have := congrArg e.inv h
  simpa [e.left_inv] using this

theorem hom_surjective (e : StarAlgIso (SA := SA) (SB := SB)) : Function.Surjective e.hom := by
  intro y
  refine ⟨e.inv y, ?_⟩
  exact e.right_inv y

end StarAlgIso

end Iso

/-!
## Star-subalgebras and generation

We avoid Mathlib's typeclass machinery here by defining a small bundle and using
the "intersection-of-all-subalgebras" style generation predicate.
-/

section Subalgebra

variable {A : Type u} (SA : StarAlgebra A)

structure StarSubalgebra where
  carrier : Set A
  zero_mem : SA.zero ∈ carrier
  one_mem : SA.one ∈ carrier
  add_mem : ∀ {x y : A}, x ∈ carrier → y ∈ carrier → SA.add x y ∈ carrier
  mul_mem : ∀ {x y : A}, x ∈ carrier → y ∈ carrier → SA.mul x y ∈ carrier
  neg_mem : ∀ {x : A}, x ∈ carrier → SA.neg x ∈ carrier
  star_mem : ∀ {x : A}, x ∈ carrier → SA.star x ∈ carrier

/-- `GeneratedBy SA S x` means: every *-subalgebra of `SA` that contains `S` also contains `x`. -/
def GeneratedBy (S : Set A) (x : A) : Prop :=
  ∀ U : StarSubalgebra SA, (S ⊆ U.carrier) → x ∈ U.carrier

/-- `IsGeneratedBy SA S` means: `S` generates all of `A`. -/
def IsGeneratedBy (S : Set A) : Prop :=
  ∀ x : A, GeneratedBy (SA := SA) S x

theorem GeneratedBy.mono {S T : Set A} {x : A}
    (hST : S ⊆ T) (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) T x := by
  intro U hT
  apply hx U
  intro y hy
  exact hT (hST hy)

theorem IsGeneratedBy.mono {S T : Set A}
    (hST : S ⊆ T) (hS : IsGeneratedBy (SA := SA) S) :
    IsGeneratedBy (SA := SA) T := by
  intro x
  exact GeneratedBy.mono (SA := SA) hST (hS x)

theorem generatedBy_of_mem {S : Set A} {x : A} (hx : x ∈ S) :
    GeneratedBy (SA := SA) S x := by
  intro U hS
  exact hS hx

theorem GeneratedBy.zero (S : Set A) :
    GeneratedBy (SA := SA) S SA.zero := by
  intro U _hS
  exact U.zero_mem

theorem GeneratedBy.one (S : Set A) :
    GeneratedBy (SA := SA) S SA.one := by
  intro U _hS
  exact U.one_mem

theorem GeneratedBy.add {S : Set A} {x y : A}
    (hx : GeneratedBy (SA := SA) S x)
    (hy : GeneratedBy (SA := SA) S y) :
    GeneratedBy (SA := SA) S (SA.add x y) := by
  intro U hS
  exact U.add_mem (hx U hS) (hy U hS)

theorem GeneratedBy.mul {S : Set A} {x y : A}
    (hx : GeneratedBy (SA := SA) S x)
    (hy : GeneratedBy (SA := SA) S y) :
    GeneratedBy (SA := SA) S (SA.mul x y) := by
  intro U hS
  exact U.mul_mem (hx U hS) (hy U hS)

theorem GeneratedBy.neg {S : Set A} {x : A}
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (SA.neg x) := by
  intro U hS
  exact U.neg_mem (hx U hS)

theorem GeneratedBy.star {S : Set A} {x : A}
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (SA.star x) := by
  intro U hS
  exact U.star_mem (hx U hS)

/-- Pull back a `StarSubalgebra` along a `StarAlgHom`. -/
def StarSubalgebra.preimage {B : Type v}
    {SB : StarAlgebra B} (U : StarSubalgebra SB) (f : StarAlgHom SA SB) :
    StarSubalgebra SA where
  carrier := { x | f x ∈ U.carrier }
  zero_mem := by
    simpa [StarAlgHom.map_zero] using U.zero_mem
  one_mem := by
    simpa [StarAlgHom.map_one] using U.one_mem
  add_mem := by
    intro x y hx hy
    simpa [StarAlgHom.map_add] using U.add_mem hx hy
  mul_mem := by
    intro x y hx hy
    simpa [StarAlgHom.map_mul] using U.mul_mem hx hy
  neg_mem := by
    intro x hx
    simpa [StarAlgHom.map_neg] using U.neg_mem hx
  star_mem := by
    intro x hx
    simpa [StarAlgHom.map_star] using U.star_mem hx

theorem GeneratedBy.map {B : Type v} {SB : StarAlgebra B}
    {S : Set A} {T : Set B} {x : A}
    (f : StarAlgHom SA SB)
    (hST : ∀ y : A, y ∈ S → f y ∈ T)
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SB) T (f x) := by
  intro U hT
  let V : StarSubalgebra SA := StarSubalgebra.preimage (SA := SA) U f
  have hSV : S ⊆ V.carrier := by
    intro y hy
    exact hT (hST y hy)
  exact hx V hSV

theorem GeneratedBy.preserved {S : Set A} {x : A}
    (f : StarAlgHom SA SA)
    (hS : ∀ y : A, y ∈ S → GeneratedBy (SA := SA) S (f y))
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (f x) := by
  intro U hU
  let V : StarSubalgebra SA := StarSubalgebra.preimage (SA := SA) U f
  have hPre : S ⊆ V.carrier := by
    intro y hy
    exact hS y hy U hU
  exact hx V hPre

end Subalgebra

/-!
## Region disjointness interface

Haag–Kastler locality is stated relative to a predicate expressing
"(space-)like separation" / "causal disjointness".

We keep this abstract and only assume symmetry and monotonicity under shrinking.
-/

namespace Region

universe w

variable {Ω : Type w} (RN : PillarA.LayerA.RegionNet Ω)

structure CausalDisjoint where
  disj : RN.Region → RN.Region → Prop
  symm : ∀ {a b : RN.Region}, disj a b → disj b a
  mono_left : ∀ {a a' b : RN.Region}, a' ≤ a → disj a b → disj a' b
  mono_right : ∀ {a b b' : RN.Region}, b' ≤ b → disj a b → disj a b'

namespace CausalDisjoint

variable {RN : PillarA.LayerA.RegionNet Ω}

theorem symm' (D : CausalDisjoint (RN := RN)) {a b : RN.Region} (h : D.disj a b) : D.disj b a :=
  D.symm h

end CausalDisjoint

/-!
### Default disjointness from region carriers

This is **not** causal disjointness in general, but provides a canonical
baseline predicate when only set-theoretic separation is available.
-/

def carrierDisjoint : CausalDisjoint (RN := RN) where
  -- Use the generic `Disjoint` predicate (not `Set.Disjoint`) so that the file
  -- stays compatible with core Lean + Mathlib without relying on deprecated aliases.
  disj a b := Disjoint (RN.carrier a) (RN.carrier b)
  symm := by
    intro a b h
    exact h.symm
  mono_left := by
    intro a a' b haa' hdisj
    -- For `Set`, `≤` is definitional `⊆`, so we can feed `carrier_mono'` directly.
    have hmono : RN.carrier a' ≤ RN.carrier a := RN.carrier_mono' (a := a') (b := a) haa'
    exact hdisj.mono_left hmono
  mono_right := by
    intro a b b' hbb' hdisj
    have hmono : RN.carrier b' ≤ RN.carrier b := RN.carrier_mono' (a := b') (b := b) hbb'
    exact hdisj.mono_right hmono

end Region

end HaagKastler
end AQFT
end PillarB
