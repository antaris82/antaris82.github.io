import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.Gates.HaagKastler.Locality

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-- The active non-vacuous disjointness predicate for the boundary block net is
carrier disjointness of the underlying finite regions. -/
abbrev boundaryMatrixCarrierDisjoint :
    HaagKastler.Region.CausalDisjoint (RN := (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN) :=
  HaagKastler.Region.carrierDisjoint (RN := (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN)

/-- Disjointly supported perturbations have zero product. -/
theorem supportedOn_disjoint_mul_eq_zero
    {a b : BoundaryRegion Ω} {P Q : BoundaryMat Ω}
    (hP : SupportedOn a P) (hQ : SupportedOn b Q)
    (hdisj : Disjoint (a : Set Ω) (b : Set Ω)) :
    P * Q = 0 := by
  ext i j
  rw [Matrix.mul_apply]
  apply Finset.sum_eq_zero
  intro k hk
  by_cases hka : k ∈ a
  · have hkb_set : k ∉ (b : Set Ω) := by
      intro hkb
      have hkbot : k ∈ ((a : Set Ω) ⊓ (b : Set Ω)) := by
        exact ⟨hka, hkb⟩
      have : k ∈ (⊥ : Set Ω) := hdisj.le_bot hkbot
      simp at this
    have hkb : k ∉ b := by
      simpa using hkb_set
    have hzero : Q k j = 0 := hQ k j (Or.inl hkb)
    simp [hzero]
  · have hzero : P i k = 0 := hP i k (Or.inr hka)
    simp [hzero]

/-- Symmetric zero-product lemma for disjointly supported perturbations. -/
theorem supportedOn_disjoint_mul_eq_zero_symm
    {a b : BoundaryRegion Ω} {P Q : BoundaryMat Ω}
    (hP : SupportedOn a P) (hQ : SupportedOn b Q)
    (hdisj : Disjoint (a : Set Ω) (b : Set Ω)) :
    Q * P = 0 := by
  exact supportedOn_disjoint_mul_eq_zero (Ω := Ω) hQ hP hdisj.symm

/-- Localized boundary blocks in disjoint regions commute at the concrete matrix
level. -/
theorem regionBlockToMatrix_commute_of_disjoint
    {a b : BoundaryRegion Ω}
    (hdisj : Disjoint ((a : Set Ω)) ((b : Set Ω)))
    (A : RegionBlockMat Ω a) (B : RegionBlockMat Ω b) :
    RegionBlockMat.toMatrix A * RegionBlockMat.toMatrix B =
      RegionBlockMat.toMatrix B * RegionBlockMat.toMatrix A := by
  rcases exists_scalar_supported_perturb (Ω := Ω) A with ⟨α, P, hP, hA⟩
  rcases exists_scalar_supported_perturb (Ω := Ω) B with ⟨β, Q, hQ, hB⟩
  have hPQ0 : P * Q = 0 :=
    supportedOn_disjoint_mul_eq_zero (Ω := Ω) hP hQ hdisj
  have hQP0 : Q * P = 0 :=
    supportedOn_disjoint_mul_eq_zero_symm (Ω := Ω) hP hQ hdisj
  rw [hA, hB]
  simp [hPQ0, hQP0, mul_comm, mul_add, add_mul, smul_add,
    add_left_comm, add_comm, smul_smul]

/-- After embedding into the join region, local boundary blocks in carrier-
disjoint regions commute. -/
theorem regionBlockIncl_commute_of_disjoint
    {a b : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region}
    (hdisj : Disjoint
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN).carrier a)
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN).carrier b))
    (x : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg a)
    (y : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg b) :
    Commute (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA (a ⊔ b))
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show a ≤ a ⊔ b from le_sup_left)) x)
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show b ≤ a ⊔ b from le_sup_right)) y) := by
  change ((boundaryMatrixLocalNet (Ω := Ω)).SA (a ⊔ b)).mul
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show a ≤ a ⊔ b from le_sup_left)) x)
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show b ≤ a ⊔ b from le_sup_right)) y)
    =
    ((boundaryMatrixLocalNet (Ω := Ω)).SA (a ⊔ b)).mul
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show b ≤ a ⊔ b from le_sup_right)) y)
      (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
        (show a ≤ a ⊔ b from le_sup_left)) x)
  apply RegionBlockMat.ext
  simpa [boundaryMatrixLocalNet_incl_toMatrix] using
    regionBlockToMatrix_commute_of_disjoint (Ω := Ω) hdisj x y

/-- Concrete non-vacuous Haag–Kastler locality for the active boundary block
matrix net. -/
theorem boundaryMatrixLocality :
    Gates.HaagKastler.Locality
      (N := boundaryMatrixLocalNet (Ω := Ω))
      (D := boundaryMatrixCarrierDisjoint (Ω := Ω)) := by
  intro a b hab x y
  change Commute (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA (a ⊔ b))
    (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
      (show a ≤ a ⊔ b from le_sup_left)) x)
    (((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl
      (show b ≤ a ⊔ b from le_sup_right)) y)
  exact regionBlockIncl_commute_of_disjoint (Ω := Ω) hab x y

end

end Derived
end AQFT
end PillarB
