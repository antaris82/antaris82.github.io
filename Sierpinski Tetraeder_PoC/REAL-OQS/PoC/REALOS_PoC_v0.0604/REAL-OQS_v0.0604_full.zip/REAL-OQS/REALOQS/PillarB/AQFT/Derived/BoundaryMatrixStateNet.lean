import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.GlobalCone
import REALOQS.PillarB.AQFT.QuasiLocal.StateLift

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-- The induced Pillar-A `StateNet` carried by the boundary block-matrix net. -/
abbrev boundaryMatrixStateNet : PillarA.LayerA.StateNet (Ω := Ω) :=
  LocalStarAlgebraNet.toStateNet (Ω := Ω) (boundaryMatrixLocalNet (Ω := Ω))

/-- The distinguished top region of the boundary block-matrix net. -/
abbrev boundaryMatrixTopRegion :
    (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region :=
  (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top

section LocalStatesFromTopStrong

variable [Nonempty Ω]
variable (L : Matrix Ω Ω ℝ) (β : ℝ)
variable (hL : Matrix.transpose L = L)

/-- Local state obtained by restricting the strong top matrix state along the
canonical region-to-matrix embedding.

The codomain remains the lightweight local carrier `StateOn`, but the source of
this state is strictly the strong C⋆ state `boundaryDensityStateAtBeta` on the
full matrix algebra.
-/
def boundaryMatrixRegionStrong
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    StateOn ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg r) :=
  StateOn.restrict
    (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA r)
    (SB := matrixStarAlgebraCStar Ω)
    (boundaryMatrixRegionToMatrixHom (Ω := Ω) r)
    ((boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn)

/-- Lightweight local state surface: this is precisely the restriction of the
strong top state, viewed through the existing `StateOn` API. -/
abbrev boundaryMatrixRegion
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    StateOn ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg r) :=
  boundaryMatrixRegionStrong (Ω := Ω) L β hL r

/-- Top-region state obtained from the strong top matrix state. -/
abbrev boundaryMatrixTop :
    StateOn
      ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
        (boundaryMatrixTopRegion (Ω := Ω))) :=
  boundaryMatrixRegionStrong (Ω := Ω) L β hL (boundaryMatrixTopRegion (Ω := Ω))

@[simp] theorem boundaryMatrixRegionStrong_apply
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region)
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg r)) :
    (boundaryMatrixRegionStrong (Ω := Ω) L β hL r) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β (RegionBlockMat.toMatrix A) := by
  rw [boundaryMatrixRegionStrong, StateOn.restrict_apply]
  exact boundaryDensityStateAtBeta_toStateOn_apply (Ω := Ω) L β hL
    (RegionBlockMat.toMatrix A)

@[simp] theorem boundaryMatrixRegion_apply
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region)
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg r)) :
    (boundaryMatrixRegion (Ω := Ω) L β hL r) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β (RegionBlockMat.toMatrix A) :=
  boundaryMatrixRegionStrong_apply (Ω := Ω) L β hL r A

@[simp] theorem boundaryMatrixTop_apply
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      (boundaryMatrixTopRegion (Ω := Ω)))) :
    (boundaryMatrixTop (Ω := Ω) L β hL) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β (RegionBlockMat.toMatrix A) :=
  boundaryMatrixRegionStrong_apply (Ω := Ω) L β hL
    (boundaryMatrixTopRegion (Ω := Ω)) A

@[simp] theorem boundaryMatrixTop_eq_region_top :
    boundaryMatrixTop (Ω := Ω) L β hL =
      boundaryMatrixRegion (Ω := Ω) L β hL
        (boundaryMatrixTopRegion (Ω := Ω)) := by
  rfl

@[simp] theorem boundaryMatrixRegion_eq_regionStrong
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    boundaryMatrixRegion (Ω := Ω) L β hL r =
      boundaryMatrixRegionStrong (Ω := Ω) L β hL r := by
  rfl

/-- The local state on a smaller region is obtained by restricting the local
state on a larger region along isotony. -/
theorem boundaryMatrixRegionStrong_compat
    {a b : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b) :
    (boundaryMatrixStateNet (Ω := Ω)).restrict hab
      (boundaryMatrixRegionStrong (Ω := Ω) L β hL b) =
      boundaryMatrixRegionStrong (Ω := Ω) L β hL a := by
  apply StateOn.ext
  intro A
  simp [LocalStarAlgebraNet.toStateNet,
    boundaryMatrixRegionStrong, boundaryMatrixRegionToMatrix_natural (Ω := Ω) hab A]

/-- The top local state restricts to the derived local state on each region. -/
theorem boundaryMatrixRegion_eq_restrict_top
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    (boundaryMatrixStateNet (Ω := Ω)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top' (RN :=
          (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN) r)
        (boundaryMatrixTop (Ω := Ω) L β hL) =
      boundaryMatrixRegion (Ω := Ω) L β hL r := by
  change (boundaryMatrixStateNet (Ω := Ω)).restrict
      (_root_.PillarA.LayerA.RegionNet.le_top' (RN :=
        (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN) r)
      (boundaryMatrixRegionStrong (Ω := Ω) L β hL (boundaryMatrixTopRegion (Ω := Ω))) =
    boundaryMatrixRegionStrong (Ω := Ω) L β hL r
  exact boundaryMatrixRegionStrong_compat (Ω := Ω) L β hL
    (_root_.PillarA.LayerA.RegionNet.le_top' (RN :=
      (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN) r)

@[simp] theorem boundaryMatrixRegion_top :
    boundaryMatrixRegion (Ω := Ω) L β hL
      (boundaryMatrixTopRegion (Ω := Ω)) =
      boundaryMatrixTop (Ω := Ω) L β hL := by
  rfl

/-- The direct compatible family of local states obtained from the strong top
matrix state. -/
def boundaryMatrixStateConeFromStrongTop :
    PillarA.LayerA.GlobalStateCone (SN := boundaryMatrixStateNet (Ω := Ω)) where
  ω := boundaryMatrixRegion (Ω := Ω) L β hL
  compat := by
    intro a b hab
    exact boundaryMatrixRegionStrong_compat (Ω := Ω) L β hL hab

@[simp] theorem boundaryMatrixStateConeFromStrongTop_ω
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    (boundaryMatrixStateConeFromStrongTop (Ω := Ω) L β hL).ω r =
      boundaryMatrixRegion (Ω := Ω) L β hL r := by
  rfl

/-- The quasilocal state induced by the compatible family of local restrictions
of the strong top matrix state. -/
def boundaryMatrixQuasiLocalStateFromStrongTop :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω)
        (N := boundaryMatrixLocalNet (Ω := Ω))) :=
  QuasiLocal.stateLift
    (Ω := Ω)
    (N := boundaryMatrixLocalNet (Ω := Ω))
    (boundaryMatrixStateConeFromStrongTop (Ω := Ω) L β hL)

@[simp] theorem boundaryMatrixQuasiLocalStateFromStrongTop_restrict
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    QuasiLocal.restrictToRegion
        (Ω := Ω)
        (N := boundaryMatrixLocalNet (Ω := Ω))
        (boundaryMatrixQuasiLocalStateFromStrongTop (Ω := Ω) L β hL)
        r =
      boundaryMatrixRegion (Ω := Ω) L β hL r := by
  simpa [boundaryMatrixQuasiLocalStateFromStrongTop] using
    (QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω)
      (N := boundaryMatrixLocalNet (Ω := Ω))
      (C := boundaryMatrixStateConeFromStrongTop (Ω := Ω) L β hL)
      (r := r))

theorem boundaryMatrixRegion_normalized
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    IsNormalized ((boundaryMatrixLocalNet (Ω := Ω)).SA r)
      (boundaryMatrixRegion (Ω := Ω) L β hL r) := by
  apply StateOn.restrict_preserves_normalized
    (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA r)
    (SB := matrixStarAlgebraCStar Ω)
    (f := boundaryMatrixRegionToMatrixHom (Ω := Ω) r)
  simpa using
    (CStarStateOn.toStateOn_normalized
      (φ := boundaryDensityStateAtBeta (Ω := Ω) L β hL))

theorem boundaryMatrixRegion_positive
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    IsPositive ((boundaryMatrixLocalNet (Ω := Ω)).SA r)
      (boundaryMatrixRegion (Ω := Ω) L β hL r) := by
  apply StateOn.restrict_preserves_positive
    (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA r)
    (SB := matrixStarAlgebraCStar Ω)
    (f := boundaryMatrixRegionToMatrixHom (Ω := Ω) r)
  simpa using
    (CStarStateOn.toStateOn_positive
      (φ := boundaryDensityStateAtBeta (Ω := Ω) L β hL))

end LocalStatesFromTopStrong

end

end Derived
end AQFT
end PillarB
