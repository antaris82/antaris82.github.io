import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v w z

open StarAlgHom

/-!
# PillarB/Gates: Star-algebra homomorphism functoriality

This gate module fixes the basic categorical laws for `StarAlgHom`.
-/

section

variable {A : Type u} {B : Type v} {C : Type w} {D : Type z}
variable {SA : StarAlgebra A} {SB : StarAlgebra B} {SC : StarAlgebra C} {SD : StarAlgebra D}

theorem id_comp (f : StarAlgHom SA SB) :
    StarAlgHom.comp (StarAlgHom.id SB) f = f := by
  apply StarAlgHom.ext
  intro x
  rfl

theorem comp_id (f : StarAlgHom SA SB) :
    StarAlgHom.comp f (StarAlgHom.id SA) = f := by
  apply StarAlgHom.ext
  intro x
  rfl

theorem comp_assoc (h : StarAlgHom SC SD) (g : StarAlgHom SB SC) (f : StarAlgHom SA SB) :
    StarAlgHom.comp h (StarAlgHom.comp g f) = StarAlgHom.comp (StarAlgHom.comp h g) f := by
  apply StarAlgHom.ext
  intro x
  rfl

end

end Gates
end AQFT
end PillarB
