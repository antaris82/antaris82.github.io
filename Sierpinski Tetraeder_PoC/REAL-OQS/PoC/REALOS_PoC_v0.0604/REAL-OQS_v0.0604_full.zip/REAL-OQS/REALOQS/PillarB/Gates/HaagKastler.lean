import REALOQS.PillarB.Gates.HaagKastler.Isotony
import REALOQS.PillarB.Gates.HaagKastler.Locality
import REALOQS.PillarB.Gates.HaagKastler.Additivity
import REALOQS.PillarB.Gates.HaagKastler.StrongAdditivity
import REALOQS.PillarB.Gates.HaagKastler.BasisAdditivity
import REALOQS.PillarB.Gates.HaagKastler.Covariance
import REALOQS.PillarB.Gates.HaagKastler.TimeSlice
import REALOQS.PillarB.Gates.HaagKastler.Vacuum
import REALOQS.PillarB.Gates.HaagKastler.Spectrum

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler gates (bundle)

This file is a small umbrella import, plus lightweight bundlings of the
most commonly used subsets of Haag–Kastler axioms.
-/

universe u v

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

/-!
## Minimal HK package

The "minimal" HK package as used in many places consists of:

* Isotony (as injective inclusion morphisms),
* Locality (microcausality) relative to a disjointness predicate,
* Additivity (binary sup-additivity).

For observable/minimal-net work, see `ObservableMinimal` below, which swaps the
binary full-poset additivity gate for basis-relative additivity.

Covariance and time-slice are provided as separate gates because they require
additional external structure (group actions / causal completion operators).
-/

structure Minimal (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN)) where
  isotony : Isotony (N := N)
  locality : Locality (N := N) D
  additivity : Additivity (N := N)

/-- Basis-relative minimal HK package for an additive observable subnet. -/
structure ObservableMinimal
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (B : RegionBasis (N := N)) where
  isotony : Isotony (N := N)
  locality : Locality (N := N) D
  additivityOnBasis : AdditivityOnBasis (N := N) B

/-!
## Full HK package

`Full` extends `Minimal` with common additional axioms used in the
"strict/standard" AQFT formulation:

* strong (finite-cover) additivity,
* covariance under a group action,
* time-slice / primitive causality,
* existence and invariance of a vacuum state,
* spectrum condition (as a gate, i.e. as abstract representation data).

All of these require additional structure (actions, completion operators, ...),
so the bundle is parameterized accordingly.
-/

structure Full
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (G : Type v) [Group G]
    (C : CovariantStateAction (Ω := Ω) (G := G) N)
    (CC : CausalCompletion (N := N))
    (isTimeSlice : N.LAN.RN.Region → Prop)
    (T : Type v) [Group T] where
  minimal : Minimal (N := N) D
  strongAdditivity : StrongAdditivity (N := N)
  covariance : CovarianceWith (N := N) (G := G) C.RA
  timeSlice : TimeSlice (N := N) CC isTimeSlice
  /-- Chosen vacuum global state. -/
  vacuumState : GlobalState (Ω := Ω) N
  vacuumPhysical : IsPhysical (Ω := Ω) vacuumState
  vacuumInvariant : IsInvariant (Ω := Ω) (G := G) (C := C) vacuumState
  spectrum : SpectrumCondition (N := N) (T := T)

/-- Basis-relative full HK package for an additive observable subnet. -/
structure ObservableFull
    (N : LocalStarAlgebraNet (Ω := Ω))
    (D : Region.CausalDisjoint (RN := N.LAN.RN))
    (B : RegionBasis (N := N))
    (G : Type v) [Group G]
    (C : CovariantStateAction (Ω := Ω) (G := G) N)
    (CC : CausalCompletion (N := N))
    (isTimeSlice : N.LAN.RN.Region → Prop)
    (T : Type v) [Group T] where
  minimal : ObservableMinimal (N := N) D B
  strongAdditivityOnBasis : StrongAdditivityOnBasis (N := N) B
  covariance : CovarianceWith (N := N) (G := G) C.RA
  timeSlice : TimeSlice (N := N) CC isTimeSlice
  vacuumState : GlobalState (Ω := Ω) N
  vacuumPhysical : IsPhysical (Ω := Ω) vacuumState
  vacuumInvariant : IsInvariant (Ω := Ω) (G := G) (C := C) vacuumState
  spectrum : SpectrumCondition (N := N) (T := T)

end HaagKastler

end Gates
end AQFT
end PillarB
