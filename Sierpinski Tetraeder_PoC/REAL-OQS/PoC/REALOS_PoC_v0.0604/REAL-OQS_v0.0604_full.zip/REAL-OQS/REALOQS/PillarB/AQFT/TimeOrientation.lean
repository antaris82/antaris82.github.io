import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# Explicit time orientation for full Hamiltonian matrix dynamics (KMS-6a)

Repo-wide convention introduced in KMS-6a:

* `TimeOrientation.plus`  = positive-time Heisenberg evolution
* `TimeOrientation.minus` = negative-time / inverse Heisenberg evolution

For the strict Gibbs/KMS path with `ρ ∝ exp(-H)` and positive inverse
temperature, the active KMS branch will later attach to `.minus`.
-/

inductive TimeOrientation
  | plus
  | minus

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-- Matrix boundary dynamics with explicit time orientation. -/
def boundaryMatrixDyn
    (σ : TimeOrientation)
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := Derived.matrixStarAlgebraCStar Ω) :=
  match σ with
  | .plus => Derived.fullBoundaryDynPlus (Ω := Ω) L hL
  | .minus => Derived.fullBoundaryDynMinus (Ω := Ω) L hL

@[simp] theorem boundaryMatrixDyn_plus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryMatrixDyn (Ω := Ω) TimeOrientation.plus L hL =
      Derived.fullBoundaryDynPlus (Ω := Ω) L hL := rfl

@[simp] theorem boundaryMatrixDyn_minus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryMatrixDyn (Ω := Ω) TimeOrientation.minus L hL =
      Derived.fullBoundaryDynMinus (Ω := Ω) L hL := rfl

end

end AQFT
end PillarB
