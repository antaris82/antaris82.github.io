import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Split property (gate surface)

The **split property** is the standard AQFT substitute for a genuine
tensor-product factorization of observables associated to nested regions.

Since Pillar B is still intentionally lightweight (no von Neumann closures,
no Type-I classification theorems, no analytic machinery), we expose the split
property purely as an **existence gate** of a suitable intermediate algebra.

Concretely, for a net `N` and a refinement `a ≤ b` we ask for an intermediate
*-algebra `F` with *-homomorphisms

`N(a) → F → N(b)`

whose composite recovers the isotony map `N(a) → N(b)`, together with a gate
assertion that `F` is “Type I” in whatever encoding a later layer chooses.
-/

/-
Universe bookkeeping

`LocalStarAlgebraNet` contains `LocalAlgebraNet`, which depends on the universe
level of regions. If we keep that level implicit, `Nonempty (SplitWitness …)`
can pick up universe metavariables. We therefore make the region universe `w`
explicit in this gate surface.
-/

universe u v w

variable {Ω : Type u}

/-- A split witness for a specific refinement `a ≤ b` in a local net. -/
structure SplitWitness
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) where
  /-- Intermediate algebra carrier. -/
  -- We keep the intermediate carrier in the *same universe* as the local
  -- fibers of the underlying `LocalAlgebraNet` (see `LocalAlgebraNet.Alg`).
  -- This avoids universe metavariables downstream when forming `Nonempty`.
  F : Type v
  /-- *-algebra structure on the intermediate carrier. -/
  SF : StarAlgebra F
  /-- Inclusion `N(a) → F`. -/
  ι₁ : StarAlgHom (N.SA a) SF
  /-- Inclusion `F → N(b)`. -/
  ι₂ : StarAlgHom SF (N.SA b)
  /-- The composite recovers isotony. -/
  comp_eq : StarAlgHom.comp ι₂ ι₁ = N.inclHom (a := a) (b := b) hab
  /-- Gate: the intermediate algebra is “Type I”. -/
  isTypeI : Prop

/-- Split property: every refinement placeholder proofs a `SplitWitness`. -/
def SplitProperty (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)) : Prop :=
  ∀ {a b : N.LAN.RN.Region} (hab : a ≤ b), Nonempty (SplitWitness (N := N) hab)

/-- Minimal universe-stable interface placeholder for the Type-I gate.

This avoids introducing universe metavariables through carrier-dependent
nonemptiness statements while still keeping `isTypeI` visibly inhabited at the
current gate level.
-/
def TypeIPlaceholder : Prop := (0 : Nat) = 0


/--
Canonical interface-level split witness:
use the larger local algebra itself as the intermediate algebra.

This is the accepted **current closure level** for split whenever one only wants
a non-vacuous, net-attached factorization witness without additional analytic
Type-I machinery.
-/
def splitWitness_factorThroughLarger
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    SplitWitness (N := N) hab :=
  { F := N.LAN.Alg b
    SF := N.SA b
    ι₁ := N.inclHom (a := a) (b := b) hab
    ι₂ := StarAlgHom.id (N.SA b)
    comp_eq := by
      apply StarAlgHom.ext
      intro x
      rfl
    isTypeI := TypeIPlaceholder }

/--
Canonical interface-level split property obtained by factoring through the
larger local algebra.
-/
theorem splitProperty_factorThroughLarger
    (N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)) :
    SplitProperty (N := N) := by
  intro a b hab
  exact ⟨splitWitness_factorThroughLarger (N := N) hab⟩

namespace SplitProperty

variable {N : LocalStarAlgebraNet.{u, v, w} (Ω := Ω)}

theorem refl (h : SplitProperty (N := N)) (a : N.LAN.RN.Region) :
    Nonempty (SplitWitness (N := N) (a := a) (b := a) (le_rfl)) :=
  h (a := a) (b := a) (le_rfl)

end SplitProperty

end Gates
end AQFT
end PillarB
