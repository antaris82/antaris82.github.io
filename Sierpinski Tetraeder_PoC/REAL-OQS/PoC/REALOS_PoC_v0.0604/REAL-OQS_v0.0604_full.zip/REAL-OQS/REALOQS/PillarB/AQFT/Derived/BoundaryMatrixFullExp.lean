import Mathlib
import Mathlib.Analysis.Normed.Algebra.Exponential
import Mathlib.Analysis.Normed.Algebra.MatrixExponential

import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar

set_option autoImplicit false

open scoped Matrix.Norms.L2Operator

namespace PillarB
namespace AQFT
namespace Derived

/-!
# Full-Hamiltonian matrix exponential wrapper (KMS-3)

This file introduces the *intended* matrix-exponential carrier for the strict
full-Hamiltonian path.

At this stage we only define the objects (Hamiltonian complexification and the
matrix exponential wrapper). The subsequent milestones will use this to build

* the density matrix `ρ ∝ exp(-H)`, and
* the full Heisenberg dynamics `A ↦ exp(i t H) A exp(-i t H)`.

Compared to the current diagonal KMS path, this file depends on the full matrix
operator, not just its diagonal.
-/

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

/-- Canonical complexification of a real matrix operator. -/
noncomputable def fullHamiltonian (L : Matrix Ω Ω ℝ) : Mat Ω :=
  fun i j => (L i j : ℂ)

omit [Fintype Ω] [DecidableEq Ω] in
theorem fullHamiltonian_apply (L : Matrix Ω Ω ℝ) (i j : Ω) :
    fullHamiltonian (Ω := Ω) L i j = (L i j : ℂ) := rfl

attribute [simp] fullHamiltonian_apply

/-- Matrix exponential of the scaled Hamiltonian.

We use `NormedSpace.exp` on `Mat Ω` (matrix exponential as a Banach-algebra exponential).
-/
noncomputable def hamExp (L : Matrix Ω Ω ℝ) (z : ℂ) : Mat Ω :=
  NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (z • fullHamiltonian (Ω := Ω) L)

/-- Positive-time unitary branch `U_t^+ = exp(i t H)`. -/
noncomputable def unitaryFromLPlus (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (Complex.I * (t : ℂ))

/-- Negative-time unitary branch `U_t^- = exp(- i t H)`. -/
noncomputable def unitaryFromLMinus (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-Complex.I * (t : ℂ))

/-- Compatibility alias: the historical `unitaryFromL` is the **plus** branch. -/
noncomputable abbrev unitaryFromL (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  unitaryFromLPlus (Ω := Ω) L t
/-!
## KMS-3b: basic exponential lemmas for the full-Hamiltonian carrier

These lemmas are the minimal algebraic interface needed before introducing
density matrices and full Heisenberg dynamics.
-/

/-- `hamExp` at `0` is the identity matrix. -/
@[simp] theorem hamExp_zero (L : Matrix Ω Ω ℝ) :
    hamExp (Ω := Ω) L 0 = (1 : Mat Ω) := by
  simp [hamExp]

/-- Scalar multiples of the same Hamiltonian commute. -/
theorem hamExp_commute_arg (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    Commute (z • fullHamiltonian (Ω := Ω) L) (w • fullHamiltonian (Ω := Ω) L) := by
  simpa using ((Commute.refl (fullHamiltonian (Ω := Ω) L)).smul_left z).smul_right w

/-- Additivity of the exponential along the same Hamiltonian generator. -/
theorem hamExp_add (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    hamExp (Ω := Ω) L (z + w) =
      hamExp (Ω := Ω) L z * hamExp (Ω := Ω) L w := by
  have hcomm := hamExp_commute_arg (Ω := Ω) L z w
  simpa [hamExp, add_smul] using
    (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)

/-- Exponentials of the same Hamiltonian commute. -/
theorem hamExp_commute (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    Commute (hamExp (Ω := Ω) L z) (hamExp (Ω := Ω) L w) := by
  calc
    hamExp (Ω := Ω) L z * hamExp (Ω := Ω) L w
        = hamExp (Ω := Ω) L (z + w) := by
            symm
            exact hamExp_add (Ω := Ω) L z w
    _ = hamExp (Ω := Ω) L (w + z) := by rw [add_comm]
    _ = hamExp (Ω := Ω) L w * hamExp (Ω := Ω) L z := by
            exact hamExp_add (Ω := Ω) L w z

/-- The unitary candidate at time `0` is the identity. -/
@[simp] theorem unitaryFromL_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromL (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromL, unitaryFromLPlus]
  simp [hamExp_zero]

/-- The positive-time unitary branch at time `0` is the identity. -/
@[simp] theorem unitaryFromLPlus_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromLPlus (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromLPlus]
  simp [hamExp_zero]

/-- The negative-time unitary branch at time `0` is the identity. -/
@[simp] theorem unitaryFromLMinus_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromLMinus (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromLMinus]
  simp [hamExp_zero]

/-- Additivity of the full unitary flow along the same Hamiltonian generator. -/
theorem unitaryFromL_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromL (Ω := Ω) L (s + t) =
      unitaryFromL (Ω := Ω) L s * unitaryFromL (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (Complex.I * (t : ℂ))
  rw [show Complex.I * (((s + t : ℝ) : ℂ)) =
      Complex.I * (s : ℂ) + Complex.I * (t : ℂ) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (Complex.I * (s : ℂ)) (Complex.I * (t : ℂ))

/-- Additivity of the positive-time unitary flow. -/
theorem unitaryFromLPlus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromLPlus (Ω := Ω) L (s + t) =
      unitaryFromLPlus (Ω := Ω) L s * unitaryFromLPlus (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (Complex.I * (t : ℂ))
  rw [show Complex.I * (((s + t : ℝ) : ℂ)) =
      Complex.I * (s : ℂ) + Complex.I * (t : ℂ) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (Complex.I * (s : ℂ)) (Complex.I * (t : ℂ))

/-- Additivity of the negative-time unitary flow. -/
theorem unitaryFromLMinus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromLMinus (Ω := Ω) L (s + t) =
      unitaryFromLMinus (Ω := Ω) L s * unitaryFromLMinus (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (-Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (-Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (-Complex.I * (t : ℂ))
  rw [show -Complex.I * (((s + t : ℝ) : ℂ)) =
      (-Complex.I * (s : ℂ)) + (-Complex.I * (t : ℂ)) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (-Complex.I * (s : ℂ)) (-Complex.I * (t : ℂ))

/-- The negative branch is the positive branch evaluated at negative time. -/
theorem unitaryFromLMinus_eq_unitaryFromLPlus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L (-t) := by
  simp [unitaryFromLMinus, unitaryFromLPlus, mul_comm]

/-- The positive branch is the negative branch evaluated at negative time. -/
theorem unitaryFromLPlus_eq_unitaryFromLMinus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L (-t) := by
  exact Eq.symm <| by
    simpa [neg_neg] using
      (unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L (-t))


omit [Fintype Ω] [DecidableEq Ω] in
/-- If `L` is symmetric over `ℝ`, then its complexification is Hermitian. -/
theorem fullHamiltonian_isHermitian_of_transpose_eq
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    Matrix.IsHermitian (fullHamiltonian (Ω := Ω) L) := by
  classical
  dsimp [Matrix.IsHermitian, fullHamiltonian]
  ext i j
  have hij : L j i = L i j := by
    have h := congrArg (fun M : Matrix Ω Ω ℝ => M i j) hL
    simpa [Matrix.transpose_apply] using h
  -- `conj` fixes real scalars; transpose symmetry gives Hermitian symmetry
  simp [Matrix.conjTranspose_apply, hij]

/-!
## KMS-3c: conjugate-transpose interaction

These lemmas are used by the density-matrix step (KMS-4) to rewrite
`B†B = exp(-H)` under symmetry of `L`.
-/

theorem hamExp_conjTranspose
    (L : Matrix Ω Ω ℝ) (z : ℂ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (hamExp (Ω := Ω) L z) = hamExp (Ω := Ω) L (star z) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := z • H
  have hA : Matrix.conjTranspose A = (star z) • H := by
    simp [A, Matrix.conjTranspose_smul, hH]
  -- `conjTranspose (exp A) = exp (conjTranspose A)`
  simpa [hamExp, A, hA] using
    (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm

/-- Conjugate transpose swaps the positive-time branch to the negative-time branch. -/
theorem conjTranspose_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) =
      unitaryFromLMinus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (hamExp_conjTranspose (Ω := Ω) L (Complex.I * (t : ℂ)) hL)

/-- Conjugate transpose swaps the negative-time branch to the positive-time branch. -/
theorem conjTranspose_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) =
      unitaryFromLPlus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (hamExp_conjTranspose (Ω := Ω) L (-Complex.I * (t : ℂ)) hL)

/-- Unitarity identity `U(t)† U(t) = 1` under symmetry of `L`. -/
theorem unitaryFromL_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) *
        unitaryFromL (Ω := Ω) L t = (1 : Mat Ω) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := (Complex.I * (t : ℂ)) • H
  have hA_conj : Matrix.conjTranspose A = (-A) := by
    -- conjugate of `i*t` is `-i*t`, and `H` is Hermitian
    calc
      Matrix.conjTranspose A
          = (star (Complex.I * (t : ℂ))) • Matrix.conjTranspose H := by
              simp [A, Matrix.conjTranspose_smul]
      _ = (-(Complex.I * (t : ℂ))) • H := by
              simp [hH, star_mul, mul_comm]
      _ = -A := by
              simp [A, neg_smul]
  have hU :
      unitaryFromL (Ω := Ω) L t =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A := by
    rw [unitaryFromL, unitaryFromLPlus, hamExp]
  have hExp_conj :
      Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A) := by
    -- `conjTranspose (exp A) = exp (conjTranspose A) = exp (-A)`
    simpa [hA_conj] using
      (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm
  have hcomm : Commute (-A) A := (Commute.refl A).neg_left
  calc
    Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) * unitaryFromL (Ω := Ω) L t
        = Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hU]
    _ = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A)) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hExp_conj]
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) ((-A) + A) := by
              -- `exp((-A)+A) = exp(-A) * exp(A)` for commuting arguments
              symm
              simpa using
                (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)
    _ = (1 : Mat Ω) := by
              simp [NormedSpace.exp_zero]

/-- Positive-time branch: `U_+† U_+ = 1`. -/
theorem unitaryFromLPlus_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) *
        unitaryFromLPlus (Ω := Ω) L t = (1 : Mat Ω) := by
  simpa [unitaryFromL] using unitaryFromL_conjTranspose_mul_self (Ω := Ω) L t hL

/-- Unitarity identity `U(t) U(t)† = 1` under symmetry of `L`. -/
theorem unitaryFromL_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromL (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) = (1 : Mat Ω) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := (Complex.I * (t : ℂ)) • H
  have hA_conj : Matrix.conjTranspose A = (-A) := by
    calc
      Matrix.conjTranspose A
          = (star (Complex.I * (t : ℂ))) • Matrix.conjTranspose H := by
              simp [A, Matrix.conjTranspose_smul]
      _ = (-(Complex.I * (t : ℂ))) • H := by
              simp [hH, star_mul, mul_comm]
      _ = -A := by
              simp [A, neg_smul]
  have hU :
      unitaryFromL (Ω := Ω) L t =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A := by
    rw [unitaryFromL, unitaryFromLPlus, hamExp]
  have hExp_conj :
      Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A) := by
    simpa [hA_conj] using
      (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm
  have hcomm : Commute A (-A) := (Commute.refl A).neg_right
  calc
    unitaryFromL (Ω := Ω) L t * Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t)
        = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hU]
    _ = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A)) := by
              simp [hExp_conj]
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (A + (-A)) := by
              symm
              simpa using
                (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)
    _ = (1 : Mat Ω) := by
              simp [NormedSpace.exp_zero]

/-- Positive-time branch: `U_+ U_+† = 1`. -/
theorem unitaryFromLPlus_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromLPlus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) = (1 : Mat Ω) := by
  simpa [unitaryFromL] using unitaryFromL_mul_conjTranspose_self (Ω := Ω) L t hL

/-- Negative-time branch: `U_-† U_- = 1`. -/
theorem unitaryFromLMinus_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) *
        unitaryFromLMinus (Ω := Ω) L t = (1 : Mat Ω) := by
  calc
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) *
        unitaryFromLMinus (Ω := Ω) L t
        = Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L (-t)) *
            unitaryFromLPlus (Ω := Ω) L (-t) := by
              rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
    _ = (1 : Mat Ω) := by
          simpa using unitaryFromLPlus_conjTranspose_mul_self (Ω := Ω) L (-t) hL

/-- Negative-time branch: `U_- U_-† = 1`. -/
theorem unitaryFromLMinus_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromLMinus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) = (1 : Mat Ω) := by
  calc
    unitaryFromLMinus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)
        = unitaryFromLPlus (Ω := Ω) L (-t) *
            Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L (-t)) := by
              rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
    _ = (1 : Mat Ω) := by
          simpa using unitaryFromLPlus_mul_conjTranspose_self (Ω := Ω) L (-t) hL

end

end Derived
end AQFT
end PillarB
