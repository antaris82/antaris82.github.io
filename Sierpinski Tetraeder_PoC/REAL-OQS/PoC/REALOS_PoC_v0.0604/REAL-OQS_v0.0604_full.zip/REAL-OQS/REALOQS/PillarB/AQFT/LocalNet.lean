import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# PillarB/AQFT: Concrete local *-algebra nets

This file refines Pillar A's `LocalAlgebraNet` interface by attaching:

* a minimal `StarAlgebra` structure on each local carrier `Alg r`, and
* the requirement that each isotony map `incl` is a bundled `StarAlgHom`.
-/

universe u v

/-- A `LocalAlgebraNet` together with a *-algebra structure on each fiber and
the requirement that the inclusion maps are *-homomorphisms. -/
structure LocalStarAlgebraNet (Ω : Type u) where
  LAN : PillarA.LayerA.LocalAlgebraNet Ω
  SA : ∀ r : LAN.RN.Region, StarAlgebra (LAN.Alg r)
  incl_isHom :
    ∀ {a b : LAN.RN.Region} (hab : a ≤ b),
      IsStarAlgHom (SA a) (SA b) (LAN.incl hab)

namespace LocalStarAlgebraNet

variable {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω))

/-- The isotony map `incl` bundled as a `StarAlgHom`. -/
def inclHom {a b : N.LAN.RN.Region} (hab : a ≤ b) : StarAlgHom (N.SA a) (N.SA b) :=
  { toFun := N.LAN.incl hab
    isHom := N.incl_isHom hab }

@[simp] theorem inclHom_apply {a b : N.LAN.RN.Region} (hab : a ≤ b) (x : N.LAN.Alg a) :
    N.inclHom (a := a) (b := b) hab x = N.LAN.incl hab x := rfl

theorem inclHom_id (a : N.LAN.RN.Region) :
    N.inclHom (a := a) (b := a) (le_rfl) = StarAlgHom.id (N.SA a) := by
  apply StarAlgHom.ext
  intro x
  simpa [LocalStarAlgebraNet.inclHom] using (N.LAN.incl_id a x)

theorem inclHom_comp {a b c : N.LAN.RN.Region} (hab : a ≤ b) (hbc : b ≤ c) :
    StarAlgHom.comp (N.inclHom (a := b) (b := c) hbc) (N.inclHom (a := a) (b := b) hab) =
      N.inclHom (a := a) (b := c) (le_trans hab hbc) := by
  apply StarAlgHom.ext
  intro x
  simpa [LocalStarAlgebraNet.inclHom] using (N.LAN.incl_comp hab hbc x)

end LocalStarAlgebraNet

end AQFT
end PillarB
