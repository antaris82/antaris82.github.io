import Mathlib.Data.Real.Basic

import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# Relative entropy hooks (B3.2)

This file adds a **minimal, gate-oriented** surface for relative entropy
between states on a local algebra.

In full operator-algebraic AQFT one typically uses **Araki relative entropy**
for normal states on a von Neumann algebra. Mathlib does not currently provide
that development in the required generality, and Pillar B intentionally avoids
committing to a concrete vN encoding at this stage.

Hence we expose relative entropy as a *hook*:

* a functional `S : StateOn A → StateOn A → ℝ`,
* a small set of stable gate laws (nonnegativity, vanishing on the diagonal),
* further analytic content (Araki formula, monotonicity, lower semicontinuity,
  etc.) kept as explicit `Prop` gates.
-/

universe u

variable {A : Type u} {SA : StarAlgebra A}

/-- Relative entropy on an abstract local algebra (gate-oriented). -/
structure RelativeEntropy (SA : StarAlgebra A) where
  /-- The relative entropy functional. -/
  S : StateOn A → StateOn A → ℝ
  /-- Gate: nonnegativity. -/
  nonneg : ∀ φ ψ : StateOn A, 0 ≤ S φ ψ
  /-- Gate: vanishing on the diagonal. -/
  self_eq_zero : ∀ φ : StateOn A, S φ φ = 0
  /-- Gate: intended to represent “Araki type” (normal/vN) semantics. -/
  isAraki : Prop
  /-- Gate: data-processing / monotonicity under coarse-graining. -/
  dataProcessing : Prop

namespace RelativeEntropy

variable (H : RelativeEntropy (SA := SA))

@[simp] theorem self (φ : StateOn A) : H.S φ φ = 0 := H.self_eq_zero φ

theorem eq_zero_of_eq {φ ψ : StateOn A} (h : φ = ψ) : H.S φ ψ = 0 := by
  cases h
  simp

theorem nonneg' (φ ψ : StateOn A) : 0 ≤ H.S φ ψ := H.nonneg φ ψ

end RelativeEntropy

end AQFT
end PillarB
