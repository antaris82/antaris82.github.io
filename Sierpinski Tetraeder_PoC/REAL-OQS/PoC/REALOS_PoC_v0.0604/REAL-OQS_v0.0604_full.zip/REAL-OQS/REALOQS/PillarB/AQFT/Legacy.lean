import REALOQS.PillarB.AQFT.Derived.LocalConfigNet
import REALOQS.PillarB.AQFT.Derived.MatterFromPillarA
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixKMSFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixNontriviality
import REALOQS.PillarB.AQFT.Derived.StateFromConfigNet
import REALOQS.PillarB.AQFT.Derived.QuasiLocalStateFromConfigNet

/-!
# Pillar B AQFT legacy umbrella

This file groups maintained legacy / comparison modules that are intentionally
kept out of the active `REALOQS.PillarB.AQFT` umbrella after BQ-8.
-/
