import REALOQS.PillarB.AQFT.QuasiLocal.Carrier

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace QuasiLocal

/-!
# QuasiLocal *-algebra structure (B2.0 → B2.0+)

We upgrade the quasilocal **carrier** `Carrier N` to a bundled `StarAlgebra`
in the lightweight Pillar-B sense (`REALOQS.PillarB.AQFT.StarAlgebra`).

## Design

Because Pillar A's `RegionNet` includes a distinguished `top` region, every
local fiber embeds into `Alg RN.top`. In this situation the usual directed
colimit carrier is canonically equivalent to the top fiber.

We exploit this to:

1. define an equivalence `Carrier N ≃ Alg RN.top`, and
2. transport the `StarAlgebra` structure from the top fiber to `Carrier N`.

This yields a fully-defined *-algebra structure without choosing arbitrary
upper bounds on every operation.
-/

universe u

variable {Ω : Type u}

section ToTop

variable (N : LocalStarAlgebraNet (Ω := Ω))

private abbrev topR : N.LAN.RN.Region := N.LAN.RN.top

private def le_topR (r : N.LAN.RN.Region) : r ≤ topR (N := N) := by
  -- `RegionNet.le_top` is stored as a field (not as an `OrderTop` instance).
  simpa [topR] using (N.LAN.RN.le_top r)

/-- Embed a pre-element into the top fiber. -/
def toTopPre (p : Pre (Ω := Ω) N) : N.LAN.Alg (topR (N := N)) :=
  N.LAN.incl (a := p.1) (b := topR (N := N)) (le_topR (N := N) p.1) p.2

private theorem toTopPre_respects
    {x y : Pre (Ω := Ω) N} (hxy : Rel (Ω := Ω) N x y) :
    toTopPre (Ω := Ω) N x = toTopPre (Ω := Ω) N y := by
  rcases hxy with ⟨t, hx, hy, hEq⟩
  -- Push the equality in `Alg t` further up to `Alg top`.
  have ht : t ≤ topR (N := N) := le_topR (N := N) t
  have h' := congrArg (fun z => N.LAN.incl (a := t) (b := topR (N := N)) ht z) hEq

  -- Rewrite both sides using functoriality of `incl`.
  have hx_comp :=
    N.LAN.incl_comp (a := x.1) (b := t) (c := topR (N := N)) hx ht x.2
  have hy_comp :=
    N.LAN.incl_comp (a := y.1) (b := t) (c := topR (N := N)) hy ht y.2

  -- Also rewrite `toTopPre` as a single inclusion into `top`.
  have hx_top :
      N.LAN.incl (a := t) (b := topR (N := N)) ht (N.LAN.incl (a := x.1) (b := t) hx x.2) =
        toTopPre (Ω := Ω) N x := by
    -- compare `le_topR x.1` with `le_trans hx ht`
    have hle : le_trans hx ht = le_topR (N := N) x.1 := by
      apply Subsingleton.elim
    -- `incl_comp` yields the needed rewriting.
    simpa [toTopPre, hle] using hx_comp

  have hy_top :
      N.LAN.incl (a := t) (b := topR (N := N)) ht (N.LAN.incl (a := y.1) (b := t) hy y.2) =
        toTopPre (Ω := Ω) N y := by
    have hle : le_trans hy ht = le_topR (N := N) y.1 := by
      apply Subsingleton.elim
    simpa [toTopPre, hle] using hy_comp

  -- Conclude.
  simpa [hx_top, hy_top] using h'

/-- Map a quasilocal class to the top fiber. -/
def toTop : Carrier (Ω := Ω) N → N.LAN.Alg (topR (N := N)) :=
  Quot.lift (toTopPre (Ω := Ω) N)
    (by
      intro x y hxy
      exact toTopPre_respects (Ω := Ω) N (x := x) (y := y) hxy)

@[simp] theorem toTop_mk (p : Pre (Ω := Ω) N) :
    toTop (Ω := Ω) N (Quot.mk (relSetoid (Ω := Ω) N) p) = toTopPre (Ω := Ω) N p :=
  rfl

/-- Inject an element of the top fiber into the carrier. -/
def ofTop (x : N.LAN.Alg (topR (N := N))) : Carrier (Ω := Ω) N :=
  ι (Ω := Ω) N (r := topR (N := N)) x

@[simp] theorem toTop_ofTop (x : N.LAN.Alg (topR (N := N))) :
    toTop (Ω := Ω) N (ofTop (Ω := Ω) N x) = x := by
  classical
  -- Reduce to `incl_id` on the top region; unfold `ι` explicitly so the
  -- `Quot.lift` beta-rule can fire.
  have htop : le_topR (N := N) (topR (N := N)) = le_rfl := by
    apply Subsingleton.elim
  -- `incl_id` is stated with `le_rfl`; rewrite the proof and finish.
  have hx :
      N.LAN.incl (a := topR (N := N)) (b := topR (N := N)) (le_topR (N := N) (topR (N := N))) x =
        x := by
    -- rewrite the proof `top ≤ top` to `le_rfl`
    simpa [htop] using (N.LAN.incl_id (topR (N := N)) x)
  -- unfold `toTop`/`ofTop`/`ι` and compute the `Quot.lift`.
  simpa [toTop, ofTop, ι, toTopPre, topR, le_topR] using hx

@[simp] theorem ofTop_toTop (q : Carrier (Ω := Ω) N) :
    ofTop (Ω := Ω) N (toTop (Ω := Ω) N q) = q := by
  refine Quot.inductionOn q (fun p => ?_)
  -- `q` is represented by `p : Σ r, Alg r`.
  -- `ofTop (toTop ⟦p⟧)` is the injection of `p`'s image in the top fiber.
  -- Coherence: `ι (incl p) = ι p`.
  dsimp [ofTop, toTop]
  -- `Quot.lift` reduces on `Quot.mk`.
  simp [toTopPre]
  -- Apply the coherence lemma from `Carrier.lean`.
  simpa [topR] using (ι_incl (Ω := Ω) N (a := p.1) (b := topR (N := N))
    (le_topR (N := N) p.1) p.2)

/-- Canonical equivalence between the quasilocal carrier and the top fiber. -/
def equivTop : Carrier (Ω := Ω) N ≃ N.LAN.Alg (topR (N := N)) where
  toFun := toTop (Ω := Ω) N
  invFun := ofTop (Ω := Ω) N
  left_inv := ofTop_toTop (Ω := Ω) N
  right_inv := toTop_ofTop (Ω := Ω) N

@[simp] theorem equivTop_apply (q : Carrier (Ω := Ω) N) :
    (equivTop (Ω := Ω) N) q = toTop (Ω := Ω) N q := rfl

@[simp] theorem equivTop_symm_apply (x : N.LAN.Alg (topR (N := N))) :
    (equivTop (Ω := Ω) N).symm x = ofTop (Ω := Ω) N x := rfl

end ToTop

section StarAlgebraOnCarrier

variable (N : LocalStarAlgebraNet (Ω := Ω))

-- NOTE: `topR` is already a private name in the previous section;
-- use a distinct private abbreviation here to avoid a name collision.
private abbrev topR' : N.LAN.RN.Region := N.LAN.RN.top

/-- The induced `StarAlgebra` structure on the quasilocal carrier. -/
def carrierStarAlgebra : StarAlgebra (Carrier (Ω := Ω) N) := by
  classical
  let e := equivTop (Ω := Ω) N
  let SAtop := N.SA (topR' (N := N))
  -- Transport operations from the top fiber.
  let zeroC : Carrier (Ω := Ω) N := e.symm SAtop.zero
  let oneC : Carrier (Ω := Ω) N := e.symm SAtop.one
  let addC : Carrier (Ω := Ω) N → Carrier (Ω := Ω) N → Carrier (Ω := Ω) N :=
    fun a b => e.symm (SAtop.add (e a) (e b))
  let mulC : Carrier (Ω := Ω) N → Carrier (Ω := Ω) N → Carrier (Ω := Ω) N :=
    fun a b => e.symm (SAtop.mul (e a) (e b))
  let negC : Carrier (Ω := Ω) N → Carrier (Ω := Ω) N :=
    fun a => e.symm (SAtop.neg (e a))
  let starC : Carrier (Ω := Ω) N → Carrier (Ω := Ω) N :=
    fun a => e.symm (SAtop.star (e a))

  refine
    { zero := zeroC
      one := oneC
      add := addC
      mul := mulC
      neg := negC
      star := starC
      add_assoc := by
        intro a b c
        apply e.injective
        simpa [addC, e] using (SAtop.add_assoc (e a) (e b) (e c))
      add_comm := by
        intro a b
        apply e.injective
        simpa [addC, e] using (SAtop.add_comm (e a) (e b))
      add_zero := by
        intro a
        apply e.injective
        simpa [addC, zeroC, e] using (SAtop.add_zero (e a))
      zero_add := by
        intro a
        apply e.injective
        simpa [addC, zeroC, e] using (SAtop.zero_add (e a))
      add_left_neg := by
        intro a
        apply e.injective
        simpa [addC, negC, zeroC, e] using (SAtop.add_left_neg (e a))
      mul_assoc := by
        intro a b c
        apply e.injective
        simpa [mulC, e] using (SAtop.mul_assoc (e a) (e b) (e c))
      one_mul := by
        intro a
        apply e.injective
        simpa [mulC, oneC, e] using (SAtop.one_mul (e a))
      mul_one := by
        intro a
        apply e.injective
        simpa [mulC, oneC, e] using (SAtop.mul_one (e a))
      left_distrib := by
        intro a b c
        apply e.injective
        simpa [mulC, addC, e] using (SAtop.left_distrib (e a) (e b) (e c))
      right_distrib := by
        intro a b c
        apply e.injective
        simpa [mulC, addC, e] using (SAtop.right_distrib (e a) (e b) (e c))
      zero_mul := by
        intro a
        apply e.injective
        simpa [mulC, zeroC, e] using (SAtop.zero_mul (e a))
      mul_zero := by
        intro a
        apply e.injective
        simpa [mulC, zeroC, e] using (SAtop.mul_zero (e a))
      star_involutive := by
        intro a
        apply e.injective
        simpa [starC, e] using (SAtop.star_involutive (e a))
      star_add := by
        intro a b
        apply e.injective
        simpa [starC, addC, e] using (SAtop.star_add (e a) (e b))
      star_mul := by
        intro a b
        apply e.injective
        simpa [starC, mulC, e] using (SAtop.star_mul (e a) (e b))
      star_one := by
        apply e.injective
        simpa [starC, oneC, e] using SAtop.star_one
      star_zero := by
        apply e.injective
        simpa [starC, zeroC, e] using SAtop.star_zero }

end StarAlgebraOnCarrier

end QuasiLocal
end AQFT
end PillarB
