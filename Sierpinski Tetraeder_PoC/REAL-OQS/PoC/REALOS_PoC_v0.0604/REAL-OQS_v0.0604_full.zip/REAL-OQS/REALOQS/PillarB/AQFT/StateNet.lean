import REALOQS.PillarA.Core.BInterfaces.StateNet
import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# PillarB/AQFT: State nets as an instance from a local *-algebra net

This module implements B1.2b: given a concrete local *-algebra net, we obtain a
Pillar-A `StateNet` by taking states as functionals `A → ℂ` and restricting by
precomposition with the isotony maps (contravariant functor).
-/

universe u

namespace LocalStarAlgebraNet

variable {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω))

/-- Build a Pillar-A `StateNet` from a concrete local *-algebra net.

Carrier on each region `r`: `StateOn (Alg r)`.

Restriction along `a ≤ b`: pull back along the isotony *-hom `inclHom hab`.
-/
def toStateNet : PillarA.LayerA.StateNet (Ω := Ω) where
  RN := N.LAN.RN
  State := fun r => StateOn (N.LAN.Alg r)
  restrict := by
    intro a b hab ρ
    exact StateOn.restrict (SA := N.SA a) (SB := N.SA b) (N.inclHom hab) ρ
  restrict_id := by
    intro a ρ
    have hid :
        N.inclHom (a := a) (b := a) (le_rfl) = StarAlgHom.id (N.SA a) :=
      N.inclHom_id a
    -- unfold the definition of `restrict` and rewrite the isotony map to `id`
    -- then apply functoriality of `StateOn.restrict`.
    simpa [hid] using (StateOn.restrict_id (SA := N.SA a) (ψ := ρ))
  restrict_comp := by
    intro a b c hab hbc ρ
    -- `StateNet.restrict_comp` wants: restrict hab (restrict hbc ρ) = restrict (le_trans hab hbc) ρ
    -- Start from contravariant functoriality of `StateOn.restrict`.
    have h :=
      (StateOn.restrict_comp (SA := N.SA a) (SB := N.SA b) (SC := N.SA c)
        (g := N.inclHom (a := b) (b := c) hbc)
        (f := N.inclHom (a := a) (b := b) hab) (ψ := ρ)).symm
    -- Rewrite the composed isotony hom to the direct isotony hom.
    have hhom :=
      N.inclHom_comp (a := a) (b := b) (c := c) hab hbc
    simpa [hhom] using h

end LocalStarAlgebraNet

end AQFT
end PillarB
