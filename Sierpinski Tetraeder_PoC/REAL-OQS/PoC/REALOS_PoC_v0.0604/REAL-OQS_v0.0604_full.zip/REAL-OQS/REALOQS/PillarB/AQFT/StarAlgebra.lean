set_option autoImplicit false

namespace PillarB
namespace AQFT

/-!
# PillarB/AQFT: Minimal *-algebra layer

Lightweight bundle for *-algebras and *-homomorphisms, independent of Mathlib.
-/

universe u v w

/-- A minimal *-algebra bundle on a carrier `A`.

This is intentionally a small, self-contained axiom set for early Pillar B.
Later layers can add norms, topologies, completeness, C*-laws, and so on.
-/
structure StarAlgebra (A : Type u) where
  zero : A
  one : A
  add : A → A → A
  mul : A → A → A
  neg : A → A
  star : A → A
  add_assoc : ∀ a b c : A, add (add a b) c = add a (add b c)
  add_comm : ∀ a b : A, add a b = add b a
  add_zero : ∀ a : A, add a zero = a
  zero_add : ∀ a : A, add zero a = a
  add_left_neg : ∀ a : A, add (neg a) a = zero
  mul_assoc : ∀ a b c : A, mul (mul a b) c = mul a (mul b c)
  one_mul : ∀ a : A, mul one a = a
  mul_one : ∀ a : A, mul a one = a
  left_distrib : ∀ a b c : A, mul a (add b c) = add (mul a b) (mul a c)
  right_distrib : ∀ a b c : A, mul (add a b) c = add (mul a c) (mul b c)
  zero_mul : ∀ a : A, mul zero a = zero
  mul_zero : ∀ a : A, mul a zero = zero
  star_involutive : ∀ a : A, star (star a) = a
  star_add : ∀ a b : A, star (add a b) = add (star a) (star b)
  star_mul : ∀ a b : A, star (mul a b) = mul (star b) (star a)
  star_one : star one = one
  star_zero : star zero = zero

/-- Predicate (Prop bundle) stating that a function is a *-homomorphism between two `StarAlgebra` bundles.

Bundling the laws as a `Prop` makes extensionality of `StarAlgHom` straightforward.
-/
structure IsStarAlgHom {A : Type u} {B : Type v}
    (SA : StarAlgebra A) (SB : StarAlgebra B) (f : A → B) : Prop where
  map_zero : f SA.zero = SB.zero
  map_one : f SA.one = SB.one
  map_add : ∀ x y : A, f (SA.add x y) = SB.add (f x) (f y)
  map_mul : ∀ x y : A, f (SA.mul x y) = SB.mul (f x) (f y)
  map_neg : ∀ x : A, f (SA.neg x) = SB.neg (f x)
  map_star : ∀ x : A, f (SA.star x) = SB.star (f x)

/-- A bundled *-homomorphism between two `StarAlgebra` bundles.

We intentionally keep this minimal (no `FunLike`, no typeclass plumbing) to remain robust.
-/
structure StarAlgHom {A : Type u} {B : Type v}
    (SA : StarAlgebra A) (SB : StarAlgebra B) where
  toFun : A → B
  isHom : IsStarAlgHom SA SB toFun

instance {A : Type u} {B : Type v} {SA : StarAlgebra A} {SB : StarAlgebra B} :
    CoeFun (StarAlgHom SA SB) (fun _ => A → B) :=
  ⟨StarAlgHom.toFun⟩

namespace StarAlgHom

variable {A : Type u} {B : Type v} {C : Type w}
variable {SA : StarAlgebra A} {SB : StarAlgebra B} {SC : StarAlgebra C}

theorem map_zero (f : StarAlgHom SA SB) : f SA.zero = SB.zero :=
  f.isHom.map_zero

theorem map_one (f : StarAlgHom SA SB) : f SA.one = SB.one :=
  f.isHom.map_one

theorem map_add (f : StarAlgHom SA SB) (x y : A) : f (SA.add x y) = SB.add (f x) (f y) :=
  f.isHom.map_add x y

theorem map_mul (f : StarAlgHom SA SB) (x y : A) : f (SA.mul x y) = SB.mul (f x) (f y) :=
  f.isHom.map_mul x y

theorem map_neg (f : StarAlgHom SA SB) (x : A) : f (SA.neg x) = SB.neg (f x) :=
  f.isHom.map_neg x

theorem map_star (f : StarAlgHom SA SB) (x : A) : f (SA.star x) = SB.star (f x) :=
  f.isHom.map_star x

/-- Identity *-homomorphism. -/
def id (SA : StarAlgebra A) : StarAlgHom SA SA :=
  { toFun := fun x => x
    isHom :=
      { map_zero := rfl
        map_one := rfl
        map_add := by intro x y; rfl
        map_mul := by intro x y; rfl
        map_neg := by intro x; rfl
        map_star := by intro x; rfl } }

/-- Composition of *-homomorphisms. -/
def comp (g : StarAlgHom SB SC) (f : StarAlgHom SA SB) : StarAlgHom SA SC :=
  { toFun := fun x => g (f x)
    isHom :=
      { map_zero :=
          (congrArg g f.isHom.map_zero).trans g.isHom.map_zero
        map_one :=
          (congrArg g f.isHom.map_one).trans g.isHom.map_one
        map_add := by
          intro x y
          exact (congrArg g (f.isHom.map_add x y)).trans (g.isHom.map_add (f x) (f y))
        map_mul := by
          intro x y
          exact (congrArg g (f.isHom.map_mul x y)).trans (g.isHom.map_mul (f x) (f y))
        map_neg := by
          intro x
          exact (congrArg g (f.isHom.map_neg x)).trans (g.isHom.map_neg (f x))
        map_star := by
          intro x
          exact (congrArg g (f.isHom.map_star x)).trans (g.isHom.map_star (f x)) } }

@[simp] theorem id_apply (SA : StarAlgebra A) (x : A) : (id SA) x = x := rfl

@[simp] theorem comp_apply (g : StarAlgHom SB SC) (f : StarAlgHom SA SB) (x : A) :
    (comp g f) x = g (f x) := rfl

/-- Extensionality: a `StarAlgHom` is determined by its underlying function.

`isHom` is a Prop bundle, hence proof irrelevant.
-/
theorem ext {f g : StarAlgHom SA SB} (h : ∀ x : A, f x = g x) : f = g := by
  cases f with
  | mk f hf =>
    cases g with
    | mk g hg =>
      have hfg : f = g := funext h
      cases hfg
      have : hf = hg := by
        apply Subsingleton.elim
      cases this
      rfl

end StarAlgHom

end AQFT
end PillarB
