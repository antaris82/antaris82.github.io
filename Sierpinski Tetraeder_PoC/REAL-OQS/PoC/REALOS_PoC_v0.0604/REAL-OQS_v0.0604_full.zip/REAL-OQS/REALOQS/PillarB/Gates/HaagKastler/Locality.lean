import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.HaagKastler.Support

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler: Locality (microcausality) gate

Locality is stated relative to a user-provided predicate expressing
"causal disjointness" / "spacelike separation".

In a net of *-algebras, microcausality says that elements localized in
causally disjoint regions commute when embedded into a common larger region.

This file provides a *gate* definition that is independent of any concrete
spacetime model (no IDEAL imports).
-/

universe u

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

-- We use an abstract region-disjointness predicate.
variable (D : Region.CausalDisjoint (RN := N.LAN.RN))

private def inclLeft {a b : N.LAN.RN.Region} : N.LAN.Alg a → N.LAN.Alg (a ⊔ b) :=
  N.LAN.incl (show a ≤ a ⊔ b from le_sup_left)

private def inclRight {a b : N.LAN.RN.Region} : N.LAN.Alg b → N.LAN.Alg (a ⊔ b) :=
  N.LAN.incl (show b ≤ a ⊔ b from le_sup_right)

/-- Haag–Kastler locality as a gate.

For disjoint regions `a` and `b`, every `x ∈ A(a)` commutes with every `y ∈ A(b)`
after embedding both into the algebra of the join region `a ⊔ b`.

Notes:
* This uses only the semilattice structure on regions provided by `RegionNet`.
* If a development prefers a fixed ambient region (e.g. `top`), one can derive
  such a variant by further embedding into `top` using isotony.
-/
def Locality : Prop :=
  ∀ {a b : N.LAN.RN.Region},
    D.disj a b →
      ∀ (x : N.LAN.Alg a) (y : N.LAN.Alg b),
        Commute (SA := N.SA (a ⊔ b)) (inclLeft (N := N) (a := a) (b := b) x)
          (inclRight (N := N) (a := a) (b := b) y)

theorem gate_locality_commute (hLoc : Locality (N := N) (D := D))
    {a b : N.LAN.RN.Region} (hab : D.disj a b)
    (x : N.LAN.Alg a) (y : N.LAN.Alg b) :
    Commute (SA := N.SA (a ⊔ b)) (inclLeft (N := N) (a := a) (b := b) x)
      (inclRight (N := N) (a := a) (b := b) y) :=
  hLoc hab x y

end HaagKastler

end Gates
end AQFT
end PillarB
