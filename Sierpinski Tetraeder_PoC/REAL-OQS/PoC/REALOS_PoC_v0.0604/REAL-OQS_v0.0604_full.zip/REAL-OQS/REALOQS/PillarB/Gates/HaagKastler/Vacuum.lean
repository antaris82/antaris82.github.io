import REALOQS.PillarA.Core.BInterfaces.CovariantNets
import REALOQS.PillarB.AQFT.State
import REALOQS.PillarB.AQFT.StateNet
import REALOQS.PillarB.AQFT.GlobalCone

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

/-!
# Haag–Kastler: Vacuum state gates

In AQFT, the "vacuum" is often presented as a vacuum vector in a Hilbert-space
representation together with covariance and the spectrum condition.

Pillar B is intentionally *pre-representation*: we work with local algebras and
local state carriers. Therefore we express "vacuum" at the level of a global
state family (a compatible cone over restriction maps), with optional covariance
and uniqueness properties.

No IDEAL imports are required.
-/

universe u v

variable {Ω : Type u}

namespace HaagKastler

/-- Abbrev: the Pillar-A `StateNet` induced by a concrete local *-algebra net. -/
abbrev SN (N : LocalStarAlgebraNet Ω) : PillarA.LayerA.StateNet Ω := N.toStateNet

/-- A global state family: a compatible choice of local states on all regions. -/
abbrev GlobalState (N : LocalStarAlgebraNet Ω) :=
  PillarA.LayerA.GlobalStateCone (SN := SN N)

/-- Local physicality conditions for a global state family.

Since the *carrier* `StateOn` is just a functional, positivity and normalization
are separate gate predicates.
-/
def IsPhysical {N : LocalStarAlgebraNet Ω} (ω : GlobalState N) : Prop :=
  ∀ r : N.LAN.RN.Region,
    IsPositive (A := N.LAN.Alg r) (N.SA r) (ω.ω r) ∧
      IsNormalized (A := N.LAN.Alg r) (N.SA r) (ω.ω r)

section

variable {G : Type v} [Group G]

/--
A covariance structure for local states.

We reuse Pillar A's region action and add an action on the state fibers, with
a naturality condition expressing that restriction commutes with the symmetry.
-/
structure CovariantStateAction (N : LocalStarAlgebraNet Ω) where
  RA : PillarA.LayerA.CovariantNets.RegionAction (RN := (SN N).RN) (G := G)
  actState : ∀ g : G, ∀ r : (SN N).RN.Region,
    (SN N).State r → (SN N).State (RA.act g r)
  naturality :
    ∀ (g : G) {a b : (SN N).RN.Region} (hab : a ≤ b)
      (ψ : (SN N).State b),
      actState g a ((SN N).restrict hab ψ) =
        (SN N).restrict
          (RA.act_le (RN := (SN N).RN) (G := G) g hab)
          (actState g b ψ)

/-- Vacuum invariance: the global state family is fixed by the covariance action. -/
def IsInvariant {N : LocalStarAlgebraNet Ω}
    (C : CovariantStateAction (G := G) N)
    (ω : GlobalState N) : Prop :=
  ∀ (g : G) (r : (SN N).RN.Region),
    C.actState g r (ω.ω r) = ω.ω (C.RA.act g r)

/-- Uniqueness of the invariant vacuum among global states. -/
def IsUniqueInvariant {N : LocalStarAlgebraNet Ω}
    (C : CovariantStateAction (G := G) N)
    (ω₀ : GlobalState N) : Prop :=
  ∀ ω : GlobalState N,
    IsInvariant (G := G) (C := C) ω → ω = ω₀

end

end HaagKastler

end Gates
end AQFT
end PillarB
