import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarB.AQFT.Derived.LocalConfigNet
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

universe u

/-- The derived `StateNet` from the configuration-based `LocalStarAlgebraNet`. -/
def stateNet (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarA.LayerA.StateNet (Ω := Ω) :=
  (localStarAlgebraNet (Ω := Ω) d).toStateNet

/-- Evaluation state on the top region, given a top configuration. -/
def evalTop (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω)) :=
  { toFun := fun f => f σ0 }

/-- Global cone obtained by restricting a *top state* to all regions. -/

def globalCone_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet (Ω := Ω) d)
    (ρTop := ρTop)

/-- Global cone obtained by restricting `evalTop σ0` to all regions. -/
def globalCone (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarA.LayerA.GlobalStateCone (SN := stateNet (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := stateNet (Ω := Ω) d)
    (ρTop := evalTop (Ω := Ω) d σ0)

end Derived
end AQFT
end PillarB
