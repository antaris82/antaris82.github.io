import Mathlib

import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullExp

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

/-!
# Full-Hamiltonian density-matrix state (KMS-4)

This file implements the **full** (non-diagonal) finite-dimensional Gibbs/density-matrix
state carrier for the boundary matrix algebra.

Given the full Hamiltonian carrier from `BoundaryMatrixFullExp` we define:

* the half-Gibbs operator `B = exp((-1/2) H)`,
* the real normalizing partition value `Z = Re Tr(B† B)` (shown positive on nonempty carriers),
* the normalized sandwich functional

`φ(A) = (1/Z) * Tr(B† A B)`.

This functional is a genuine `CStarStateOn (Mat Ω)`:

* positivity is proved by rewriting `φ(A†A)` as a scaled trace of `(A B)† (A B)`,
* normalization is `φ(1)=1` by construction.

Important semantic restriction:
this file does not yet prove the KMS strip condition for the full dynamics.
It only provides the **density-matrix state** needed for the strict KMS-6 step.
-/

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω] [Nonempty Ω]

/-- Finite matrix trace as sum of diagonal entries. -/
def matTrace (A : Mat Ω) : ℂ :=
  ∑ i, A i i

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem matTrace_apply (A : Mat Ω) : matTrace (Ω := Ω) A = ∑ i, A i i := rfl

/-!
## Trace lemmas (needed for the explicit density matrix form)

We work with `matTrace` as the concrete diagonal-sum trace.
For KMS-4 completion we need:

* linearity under scalar multiplication,
* cyclicity `Tr(AB)=Tr(BA)`,
* the 3-cycle `Tr(XYZ)=Tr(ZXY)`.
-/

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem matTrace_smul (c : ℂ) (A : Mat Ω) :
    matTrace (Ω := Ω) (c • A) = c * matTrace (Ω := Ω) A := by
  classical
  unfold matTrace
  -- `∑ i, (c • A) i i = ∑ i, c * A i i` and pull `c` out of the sum
  simp [Matrix.smul_apply, smul_eq_mul]
  -- now `∑ i, c * A i i = c * ∑ i, A i i`
  simpa using (Finset.mul_sum (s := (Finset.univ : Finset Ω)) (a := c) (f := fun i => A i i)).symm

omit [DecidableEq Ω] [Nonempty Ω] in
theorem matTrace_mul_comm (A B : Mat Ω) :
    matTrace (Ω := Ω) (A * B) = matTrace (Ω := Ω) (B * A) := by
  classical
  unfold matTrace
  -- `Tr(AB) = ∑ i ∑ j A i j * B j i`
  calc
    (∑ i : Ω, (A * B) i i)
        = ∑ i : Ω, ∑ j : Ω, A i j * B j i := by
            classical
            simp [Matrix.mul_apply]
    _ = ∑ j : Ω, ∑ i : Ω, A i j * B j i := by
            classical
            -- swap summation order (rewrite to finset sums over `univ` and use `Finset.sum_comm`)
            simpa using
              (Finset.sum_comm
                (s := (Finset.univ : Finset Ω))
                (t := (Finset.univ : Finset Ω))
                (f := fun i j => A i j * B j i))
    _ = ∑ j : Ω, ∑ i : Ω, B j i * A i j := by
            classical
            refine Finset.sum_congr rfl ?_
            intro j hj
            refine Finset.sum_congr rfl ?_
            intro i hi
            simp [mul_comm]
    _ = ∑ j : Ω, (B * A) j j := by
            classical
            simp [Matrix.mul_apply]

omit [DecidableEq Ω] [Nonempty Ω] in
theorem matTrace_mul_mul_mul_cycle (X Y Z : Mat Ω) :
    matTrace (Ω := Ω) (X * Y * Z) = matTrace (Ω := Ω) (Z * X * Y) := by
  classical
  -- `Tr((XY)Z) = Tr(Z(XY))`
  simpa [mul_assoc] using
    (matTrace_mul_comm (Ω := Ω) (A := X * Y) (B := Z))

omit [Nonempty Ω] in
theorem re_matTrace_eq_sum_re_diag (A : Mat Ω) :
    (matTrace (Ω := Ω) A).re = ∑ i, (A i i).re := by
  classical
  unfold matTrace
  -- prove by induction on the diagonal index finset
  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
  · simp
  · intro a s ha ih
    simp [Finset.sum_insert, ha, ih, Complex.add_re]

/-- Half-Gibbs operator `B = exp((-1/2) H)` used for the sandwich state. -/
def gibbsHalf (L : Matrix Ω Ω ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-( ( (1:ℝ) / 2 : ℝ) : ℂ))

/-- Partition real value `Z = ∑ᵢ Re((B†B)ᵢᵢ)` used for normalization. -/
def boundaryDensityZ (L : Matrix Ω Ω ℝ) : ℝ :=
  ∑ i, ((star (gibbsHalf (Ω := Ω) L) * (gibbsHalf (Ω := Ω) L)) i i).re

/-- The unnormalized sandwich trace `Tr(B† A B)`. -/
def gibbsSandwichTrace (L : Matrix Ω Ω ℝ) (A : Mat Ω) : ℂ :=
  matTrace (Ω := Ω) (star (gibbsHalf (Ω := Ω) L) * A * (gibbsHalf (Ω := Ω) L))

/-- Linear sandwich functional `A ↦ (1/Z) * Tr(B† A B)`. -/
def gibbsSandwichLinear (L : Matrix Ω Ω ℝ) : Mat Ω →ₗ[ℂ] ℂ where
  toFun := fun A => ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹ * gibbsSandwichTrace (Ω := Ω) L A
  map_add' := by
    intro A B
    simp [gibbsSandwichTrace, matTrace, mul_add, add_mul, mul_assoc,
      Finset.sum_add_distrib]
  map_smul' := by
    intro c A
    have htrace :
        gibbsSandwichTrace (Ω := Ω) L (c • A) = c * gibbsSandwichTrace (Ω := Ω) L A := by
      unfold gibbsSandwichTrace matTrace
      simp only [Matrix.mul_apply, Finset.mul_sum, Finset.sum_mul,
        Matrix.smul_apply, smul_eq_mul, mul_assoc]
      refine Finset.sum_congr rfl ?_
      intro i hi
      refine Finset.sum_congr rfl ?_
      intro x hx
      refine Finset.sum_congr rfl ?_
      intro x_1 hx_1
      ring
    calc
      (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
          gibbsSandwichTrace (Ω := Ω) L (c • A)
          = (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
              (c * gibbsSandwichTrace (Ω := Ω) L A) := by rw [htrace]
      _ = c * ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
              gibbsSandwichTrace (Ω := Ω) L A) := by ring

/-- Continuous sandwich functional (finite dimensionality). -/
def gibbsSandwichCLM (L : Matrix Ω Ω ℝ) : Mat Ω →L[ℂ] ℂ where
  toLinearMap := gibbsSandwichLinear (Ω := Ω) L
  cont := by
    simpa using (gibbsSandwichLinear (Ω := Ω) L).continuous_of_finiteDimensional

/-!
## Explicit density matrix (ρ) for the sandwich functional

The sandwich functional
`φ(A) = (1/Z) * Tr(B† A B)`
can be written in the standard density-matrix form

`φ(A) = Tr(ρ A)`

with

`ρ = (1/Z) * (B * B†)`.

This uses cyclicity of `matTrace`.
-/

/-- Explicit density matrix for the KMS-4 sandwich state: `ρ = (1/Z) • (B * B†)`. -/
def densityMatrixSandwich (L : Matrix Ω Ω ℝ) : Mat Ω :=
  (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
    (gibbsHalf (Ω := Ω) L * star (gibbsHalf (Ω := Ω) L))

omit [Nonempty Ω] in
theorem gibbsSandwichTrace_eq_matTrace_density_mul
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    gibbsSandwichTrace (Ω := Ω) L A =
      matTrace (Ω := Ω)
        ((gibbsHalf (Ω := Ω) L * star (gibbsHalf (Ω := Ω) L)) * A) := by
  classical
  -- `Tr(B† A B) = Tr(B B† A)` by the 3-cycle
  have hcycle :=
    (matTrace_mul_mul_mul_cycle (Ω := Ω)
      (X := star (gibbsHalf (Ω := Ω) L)) (Y := A) (Z := gibbsHalf (Ω := Ω) L))
  simpa [gibbsSandwichTrace, mul_assoc] using hcycle

omit [Nonempty Ω] in
theorem gibbsSandwichCLM_eq_matTrace_density_mul
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    gibbsSandwichCLM (Ω := Ω) L A =
      matTrace (Ω := Ω) ((densityMatrixSandwich (Ω := Ω) L) * A) := by
  classical
  -- unfold the CLM to the underlying linear map (avoid expanding `matTrace` here)
  simp [gibbsSandwichCLM, gibbsSandwichLinear]
  have htr := gibbsSandwichTrace_eq_matTrace_density_mul (Ω := Ω) L A
  -- rewrite `Tr(B†AB)` as `Tr((B B†)A)` by cyclicity
  rw [htr]
  -- absorb the scalar `(1/Z)` into the density matrix and pull it through multiplication
  simp [densityMatrixSandwich, mul_assoc]
  -- close the remaining scalar-through-sum goal explicitly
  classical
  -- `∑ i, ...` is `Finset.univ.sum ...`
  simpa using
    (Finset.mul_sum (s := (Finset.univ : Finset Ω))
      (a := (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹))
      (f := fun i : Ω =>
        (gibbsHalf (Ω := Ω) L * (Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * A)) i i))

omit [DecidableEq Ω] [Nonempty Ω] in
/-- Existence of a nonzero matrix entry from `A ≠ 0`. -/
theorem exists_entry_ne_zero (A : Mat Ω) (hA : A ≠ 0) : ∃ i j, A i j ≠ 0 := by
  classical
  by_contra h
  have h0 : A = 0 := by
    ext i j
    by_contra hij
    exact h ⟨i, j, hij⟩
  exact hA h0

/-- Each term `star z * z` has nonnegative real part and zero imaginary part. -/
theorem density_isRealNonneg_star_mul_self_complex (z : ℂ) : IsRealNonneg (star z * z) := by
  refine ⟨?_, ?_⟩
  · change ((star z) * z).im = 0
    simp [Complex.mul_im]
    ring
  · change 0 ≤ ((star z) * z).re
    simp [Complex.mul_re]
    nlinarith [sq_nonneg z.re, sq_nonneg z.im]

/-- If `z ≠ 0`, then `Re(star z * z) > 0`. -/
theorem star_mul_self_re_pos {z : ℂ} (hz : z ≠ 0) : 0 < (star z * z).re := by
  have : z.re ≠ 0 ∨ z.im ≠ 0 := by
    by_contra h
    push_neg at h
    apply hz
    apply Complex.ext <;> simp [h.1, h.2]
  simp [Complex.mul_re] at *
  have hsq : 0 < z.re ^ 2 + z.im ^ 2 := by
    rcases this with h | h
    · have : 0 < z.re ^ 2 := sq_pos_of_ne_zero h
      nlinarith [this, sq_nonneg z.im]
    · have : 0 < z.im ^ 2 := sq_pos_of_ne_zero h
      nlinarith [this, sq_nonneg z.re]
  -- `Re(star z * z) = z.re^2 + z.im^2`
  nlinarith [hsq]

omit [DecidableEq Ω] [Nonempty Ω] in
/-- The diagonal entries of `A†A` are real and nonnegative. -/
theorem density_isRealNonneg_star_mul_self_diag (A : Mat Ω) (i : Ω) :
    IsRealNonneg (((star A) * A) i i) := by
  classical
  -- Expand the diagonal entry of `A†A` as a finite sum.
  rw [Matrix.mul_apply]
  -- We show closure of `IsRealNonneg` under finite sums.
  have hsum :
      IsRealNonneg (Finset.sum (Finset.univ : Finset Ω)
        (fun j => (star A i j) * A j i)) := by
    -- Induction on the index finset.
    refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
    · -- empty sum
      simp [IsRealNonneg]
    · intro a s ha hs
      have ha' : IsRealNonneg ((star A i a) * A a i) := by
        -- `star A i a = star (A a i)` for matrices over `ℂ`
        simpa [star_eq_conjTranspose] using
          density_isRealNonneg_star_mul_self_complex (A a i)
      rcases ha' with ⟨ha_im, ha_re⟩
      rcases hs with ⟨hs_im, hs_re⟩
      refine ⟨?_, ?_⟩
      · -- imaginary part
        -- imaginary part: use linearity of `im` and the induction hypotheses
        rw [Finset.sum_insert ha]
        rw [Complex.add_im]
        rw [ha_im, hs_im]
        simp
      · -- real part
        simpa [Finset.sum_insert, ha] using add_nonneg ha_re hs_re
  simpa using hsum


omit [Nonempty Ω] in
/-- The diagonal trace of `X†X` is real and nonnegative. -/
theorem isRealNonneg_matTrace_star_mul_self (X : Mat Ω) :
    IsRealNonneg (matTrace (Ω := Ω) (star X * X)) := by
  classical
  unfold matTrace
  have hdiag : ∀ i : Ω, IsRealNonneg (((star X) * X) i i) :=
    fun i => density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := X) i
  -- Induct over the diagonal index finset.
  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
  · simp [IsRealNonneg]
  · intro a s ha ih
    have ha' : IsRealNonneg (((star X) * X) a a) := hdiag a
    have hs' : IsRealNonneg (Finset.sum s (fun x => ((star X) * X) x x)) := ih
    rcases ha' with ⟨ha_im, ha_re⟩
    rcases hs' with ⟨hs_im, hs_re⟩
    refine ⟨?_, ?_⟩
    · -- imaginary part
      rw [Finset.sum_insert ha, Complex.add_im, ha_im, hs_im]
      simp
    · -- real part
      have hnn : 0 ≤ (((star X) * X) a a).re + (Finset.sum s (fun x => ((star X) * X) x x)).re :=
        add_nonneg ha_re hs_re
      simpa [Finset.sum_insert ha, Complex.add_re] using hnn

/-- Positivity of the partition real value `Z`. -/
theorem boundaryDensityZ_pos (L : Matrix Ω Ω ℝ) : 0 < boundaryDensityZ (Ω := Ω) L := by
  classical
  -- pick a nonzero entry of `B = gibbsHalf L`
  have hB_ne : gibbsHalf (Ω := Ω) L ≠ 0 := by
    -- `B * exp(+1/2 H) = 1` via `hamExp_add`, so `B ≠ 0`
    have hmul :
        gibbsHalf (Ω := Ω) L * hamExp (Ω := Ω) L (( ( (1:ℝ) / 2 : ℝ) : ℂ)) = (1 : Mat Ω) := by
      -- `hamExp_add` with z = -1/2 and w = +1/2
      have hadd := hamExp_add (Ω := Ω) L (-( ( (1:ℝ) / 2 : ℝ) : ℂ)) ((( (1:ℝ) / 2 : ℝ) : ℂ))
      -- `z+w=0`
      have hz : (-( ( (1:ℝ) / 2 : ℝ) : ℂ)) + ((( (1:ℝ) / 2 : ℝ) : ℂ)) = 0 := by
        simp
      -- rearrange
      simpa [gibbsHalf, hz] using (by
        -- from hadd: hamExp L (z+w) = hamExp L z * hamExp L w
        -- with z+w=0, lhs is hamExp L 0 = 1
        simpa [hz] using hadd.symm)
    intro h0
    -- then LHS is 0, contradiction
    have hmul0 : (0 : Mat Ω) = (1 : Mat Ω) := by
      have hmul' := hmul
      simp [h0] at hmul'
    exact (zero_ne_one (α := Mat Ω)) hmul0
  rcases exists_entry_ne_zero (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) hB_ne with ⟨i0, j0, hij0⟩
  -- show the diagonal entry `(B†B) j0 j0` has positive real part
  have hdiag_pos : 0 < ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re := by
    -- expand diagonal as sum over `i` of `star(B i j0) * B i j0`
    -- and use the positive term for `i0`
    have hterm_pos : 0 < (star (gibbsHalf (Ω := Ω) L i0 j0) * gibbsHalf (Ω := Ω) L i0 j0).re :=
      star_mul_self_re_pos hij0
    -- all terms are nonnegative
    have hterm_nonneg :
        ∀ i : Ω,
          0 ≤ (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      intro i
      exact (density_isRealNonneg_star_mul_self_complex (gibbsHalf (Ω := Ω) L i j0)).2
    -- compare with sum
    -- compute diagonal entry
    have hdiag :
        (star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0 =
          ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0) := by
      -- unfold multiplication and `star` for matrices
      classical
      -- `star` is `conjTranspose`
      simp [Matrix.mul_apply, star_eq_conjTranspose, Matrix.conjTranspose_apply]
    -- take real parts
    have hdiag_re :
        ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re =
          ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      classical
      -- take real parts
      simpa [hdiag] using congrArg Complex.re hdiag
    -- now show sum > 0
    -- `i0` term ≤ sum and term >0
    have hle : (star (gibbsHalf (Ω := Ω) L i0 j0) * gibbsHalf (Ω := Ω) L i0 j0).re ≤
        ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      classical
      exact Finset.single_le_sum (fun i _ => hterm_nonneg i) (by simp)
    have : 0 < ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re :=
      lt_of_lt_of_le hterm_pos hle
    rw [hdiag_re]
    exact this
  -- now `Z` is sum of diagonal real parts, so it dominates that positive diagonal
  unfold boundaryDensityZ
  -- `Z = Re(∑ i, (B†B) i i)` and each diagonal entry has zero imaginary part
  have hZ_ge : ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re ≤
      ∑ i, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re := by
    classical
    exact Finset.single_le_sum (fun i _ =>
      (density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i).2)
      (by simp)
  have hsum_pos : 0 < ∑ i, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re :=
    lt_of_lt_of_le hdiag_pos hZ_ge
  exact hsum_pos

@[simp] theorem boundaryDensityZ_ne_zero (L : Matrix Ω Ω ℝ) : boundaryDensityZ (Ω := Ω) L ≠ 0 :=
  ne_of_gt (boundaryDensityZ_pos (Ω := Ω) L)

/-- The sandwich functional sends the identity to `1`. -/
@[simp] theorem gibbsSandwich_one (L : Matrix Ω Ω ℝ) :
    gibbsSandwichCLM (Ω := Ω) L 1 = 1 := by
  classical
  have hZ : boundaryDensityZ (Ω := Ω) L ≠ 0 := boundaryDensityZ_ne_zero (Ω := Ω) L
  -- compute the trace on the identity
  have htrace : gibbsSandwichTrace (Ω := Ω) L 1 = ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ) := by
    unfold gibbsSandwichTrace
    -- simplify `B† * 1 * B = B† * B`
    simp [matTrace, boundaryDensityZ]
    -- reduce each diagonal entry to its real part (imaginary part is 0)
    -- (the diagonal of `B†B` is real by the `star_mul_self` lemma)
    classical
    apply Finset.sum_congr rfl
    intro i hi
    -- show `(B†B) i i = ((Re (B†B i i)) : ℂ)`
    have hiR : IsRealNonneg (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i) :=
      density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i
    -- `hiR.1` says imag part is 0
    have him : (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i).im = 0 := hiR.1
    -- conclude by ext
    apply Complex.ext
    · simp
    · simpa [him]
  -- unfold CLM and finish
  unfold gibbsSandwichCLM gibbsSandwichLinear
  have hZc : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)) ≠ 0 := by
    exact_mod_cast hZ
  simp [htrace, hZc]

/-- Closure of `IsRealNonneg` under multiplication by a nonnegative real scalar. -/
theorem density_IsRealNonneg_ofReal_mul {r : ℝ} {z : ℂ} (hr : 0 ≤ r) (hz : IsRealNonneg z) :
    IsRealNonneg (((r : ℝ) : ℂ) * z) := by
  rcases hz with ⟨hz_im, hz_re⟩
  refine ⟨?_, ?_⟩
  · simp [Complex.mul_im, hz_im]
  · simpa [Complex.mul_re, hz_im] using mul_nonneg hr hz_re

/-- Positivity of the sandwich functional on `A†A`. -/
theorem gibbsSandwich_positive (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    IsRealNonneg (gibbsSandwichCLM (Ω := Ω) L (star A * A)) := by
  classical
  have hZpos : 0 < boundaryDensityZ (Ω := Ω) L := boundaryDensityZ_pos (Ω := Ω) L
  have hZinv : 0 ≤ (boundaryDensityZ (Ω := Ω) L)⁻¹ := le_of_lt (inv_pos.2 hZpos)
  -- rewrite `B† (A†A) B = (A B)† (A B)`
  let B : Mat Ω := gibbsHalf (Ω := Ω) L
  have hrewrite : star B * (star A * A) * B = star (A * B) * (A * B) := by
    -- expand and reassociate
    simp [B, mul_assoc, star_mul, star_eq_conjTranspose]
  -- now the trace is a sum of diagonal `IsRealNonneg`
  -- We use the same diagonal argument as in the diagonal Gibbs state:
  unfold gibbsSandwichCLM gibbsSandwichLinear
  -- reduce to trace of `star (A*B) * (A*B)`
  have hz : IsRealNonneg (matTrace (Ω := Ω) (star (A * B) * (A * B))) := by
    simpa using isRealNonneg_matTrace_star_mul_self (Ω := Ω) (X := (A * B))
  -- apply scaling by the nonnegative real inverse
  have hzTrace : IsRealNonneg (gibbsSandwichTrace (Ω := Ω) L (star A * A)) := by
    -- rewrite `B† (A†A) B` to `(A B)† (A B)` inside the trace
    simpa [gibbsSandwichTrace, matTrace, hrewrite, mul_assoc] using hz
  have hscalar : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) =
      (((((boundaryDensityZ (Ω := Ω) L)⁻¹) : ℝ) : ℂ)) := by
    -- `ofReal` commutes with inversion on nonzero reals
    simp
  -- finish via the generic real-scalar closure lemma
  dsimp [gibbsSandwichCLM, gibbsSandwichLinear]
  -- rewrite the complex scalar `(Z : ℂ)⁻¹` as the embedded real inverse
  rw [hscalar]
  exact density_IsRealNonneg_ofReal_mul (r := (boundaryDensityZ (Ω := Ω) L)⁻¹) hZinv hzTrace

/-- Full-Hamiltonian density-matrix state as a genuine `CStarStateOn`. -/
def boundaryDensityState (L : Matrix Ω Ω ℝ) : CStarStateOn (Mat Ω) where
  toCLM := gibbsSandwichCLM (Ω := Ω) L
  positive' := gibbsSandwich_positive (Ω := Ω) L
  normalized' := gibbsSandwich_one (Ω := Ω) L

/-- Lightweight `StateOn` view of the full density-matrix state. -/
def boundaryDensityStateMat (L : Matrix Ω Ω ℝ) : StateOn (Mat Ω) :=
  (boundaryDensityState (Ω := Ω) L).toStateOn

/-!
## KMS-4 completion: explicit Gibbs form under symmetry of `L`

The sandwich construction is always a well-defined positive normalized state.
For the **physical Gibbs claim** we additionally assume symmetry of `L` over `ℝ`,
so that the complexified Hamiltonian is Hermitian.

Under this assumption we can identify the sandwich density matrix with the
canonical Gibbs operator `exp(-H)` (core `β = 1`).
-/

/-- Core Gibbs operator `G = exp(-H)` (i.e. `β=1`) built from the full Hamiltonian exponential. -/
def gibbsOpCore (L : Matrix Ω Ω ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ))

omit [Nonempty Ω] in
theorem gibbsHalf_star_eq
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L := by
  classical
  -- `star` on matrices is `conjTranspose`
  have h := hamExp_conjTranspose (Ω := Ω) L (-( ((1 : ℝ) / 2 : ℝ) : ℂ)) hL
  -- `star` on real scalars is trivial
  simpa [gibbsHalf, star_eq_conjTranspose] using h

omit [Nonempty Ω] in
theorem gibbsHalf_star_mul_self_eq_gibbsOpCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L := by
  classical
  -- first `B† = B`
  have hB : star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L :=
    gibbsHalf_star_eq (Ω := Ω) L hL

  -- work with the half exponent as a named scalar
  set a : ℂ := (-( ((1 : ℝ) / 2 : ℝ) : ℂ)) with ha

  -- `exp((a+a)H) = exp(aH) * exp(aH)`
  have hadd : hamExp (Ω := Ω) L (a + a) =
      hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa using (hamExp_add (Ω := Ω) L a a)

  -- scalar arithmetic: `a+a = -1` (in `ℂ`), proved without triggering the `-2⁻¹` parser pitfall
  have hscalar : a + a = (-((1 : ℝ) : ℂ)) := by
    have : (-( ((1 : ℝ) / 2 : ℝ) : ℂ) + (-( ((1 : ℝ) / 2 : ℝ) : ℂ))) =
        (-((1 : ℝ) : ℂ)) := by
      norm_num
    simpa [ha] using this

  -- rewrite the exponent on the LHS using `hscalar`
  have hadd1 :
      hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    have h1 : hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L (a + a) := by
      simpa using congrArg (fun z => hamExp (Ω := Ω) L z) hscalar.symm
    exact h1.trans hadd

  -- unfold to `gibbsOpCore = gibbsHalf * gibbsHalf`
  have this : gibbsOpCore (Ω := Ω) L =
      gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L := by
    simpa [gibbsOpCore, gibbsHalf, ha] using hadd1

  -- finish
  simp [hB, this]




omit [Nonempty Ω] in
theorem boundaryDensityZ_eq_re_matTrace_gibbsOpCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryDensityZ (Ω := Ω) L = (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re := by
  classical
  have hG :
      star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L :=
    gibbsHalf_star_mul_self_eq_gibbsOpCore (Ω := Ω) L hL
  -- unfold `Z` and rewrite `B†B` to the Gibbs operator
  unfold boundaryDensityZ
  have hG' :
      Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L =
        gibbsOpCore (Ω := Ω) L := by
    simpa using hG

  have hZ :
      (∑ i : Ω,
          ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re) =
        ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re := by
    simpa using congrArg (fun M : Mat Ω => ∑ i : Ω, (M i i).re) hG'
  -- now use `Re(Tr G) = ∑ Re(diag G)` without letting `simp` collapse the goal
  have hre :
      (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re =
        ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re :=
    re_matTrace_eq_sum_re_diag (Ω := Ω) (A := gibbsOpCore (Ω := Ω) L)
  -- finish
  have hStar_to_conj :
      (∑ i : Ω, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re) =
        ∑ i : Ω,
          ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re := by
    -- `star` on matrices is `conjTranspose`
    simp

  calc
    (∑ i : Ω, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re)
        = ∑ i : Ω,
            ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re :=
      hStar_to_conj
    _ = ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re := hZ
    _ = (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re := hre.symm

omit [Nonempty Ω] in
theorem matTrace_gibbsOpCore_im_eq_zero
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).im = 0 := by
  classical
  have hG :
      star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L =
        gibbsOpCore (Ω := Ω) L :=
    gibbsHalf_star_mul_self_eq_gibbsOpCore (Ω := Ω) L hL
  have hdiag_im :
      ∀ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).im = 0 := by
    intro i
    have hiR :
        IsRealNonneg (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i) :=
      density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i
    have him : (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i).im = 0 := hiR.1
    have hentry :
        ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i) =
          (gibbsOpCore (Ω := Ω) L) i i := by
      simpa using congrArg (fun M : Mat Ω => M i i) hG
    rw [← hentry]
    exact him
  unfold matTrace
  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?_ ?_
  · simp
  · intro a s ha ih
    have ha_im : ((gibbsOpCore (Ω := Ω) L) a a).im = 0 := hdiag_im a
    simp [Finset.sum_insert, ha, ha_im, ih, Complex.add_im]

omit [Nonempty Ω] in
theorem matTrace_gibbsOpCore_eq_ofReal_boundaryDensityZ
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L) =
      ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ) := by
  apply Complex.ext
  · simpa using (boundaryDensityZ_eq_re_matTrace_gibbsOpCore (Ω := Ω) L hL).symm
  · simpa using matTrace_gibbsOpCore_im_eq_zero (Ω := Ω) L hL



/-- Canonical Gibbs density matrix `ρ = (1/Z) * exp(-H)` under symmetry of `L`. -/
def densityMatrixCore (L : Matrix Ω Ω ℝ) : Mat Ω :=
  (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • gibbsOpCore (Ω := Ω) L

@[simp] theorem matTrace_densityMatrixCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    matTrace (Ω := Ω) (densityMatrixCore (Ω := Ω) L) = 1 := by
  have hZ : boundaryDensityZ (Ω := Ω) L ≠ 0 := boundaryDensityZ_ne_zero (Ω := Ω) L
  have hZc : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)) ≠ 0 := by
    exact_mod_cast hZ
  rw [show densityMatrixCore (Ω := Ω) L =
      ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • gibbsOpCore (Ω := Ω) L) by rfl]
  rw [matTrace_smul]
  rw [matTrace_gibbsOpCore_eq_ofReal_boundaryDensityZ (Ω := Ω) L hL]
  simp [hZc]

omit [Nonempty Ω] in
theorem densityMatrixSandwich_eq_densityMatrixCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    densityMatrixSandwich (Ω := Ω) L = densityMatrixCore (Ω := Ω) L := by
  classical
  unfold densityMatrixSandwich densityMatrixCore
  -- under symmetry, `B† = B`, hence `B * B† = B * B = exp(-H)`
  have hB : star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L :=
    gibbsHalf_star_eq (Ω := Ω) L hL
  -- avoid the `-2⁻¹` pretty-printer pitfall by naming the scalar exponent
  set a : ℂ := -(((1 : ℝ) / 2 : ℝ) : ℂ)
  have hadd : hamExp (Ω := Ω) L (a + a) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa [a] using (hamExp_add (Ω := Ω) L a a)

  have hscalar : a + a = -((1 : ℝ) : ℂ) := by
    -- purely scalar arithmetic
    have : (-(((1 : ℝ) / 2 : ℝ) : ℂ) + -(((1 : ℝ) / 2 : ℝ) : ℂ)) = -((1 : ℝ) : ℂ) := by
      norm_num
    simpa [a] using this

  have hadd1 : hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa [hscalar] using hadd

  have hBB : gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L := by
    -- `hadd1` gives `exp(-1) = exp(a) * exp(a)`
    have : gibbsOpCore (Ω := Ω) L =
        gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L := by
      simpa [gibbsOpCore, gibbsHalf, a] using hadd1
    simpa using this.symm

  simp [hB, hBB]

theorem boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    boundaryDensityStateMat (Ω := Ω) L A =
      matTrace (Ω := Ω) ((densityMatrixCore (Ω := Ω) L) * A) := by
  unfold boundaryDensityStateMat
  rw [CStarStateOn.toStateOn_apply]
  unfold boundaryDensityState
  rw [gibbsSandwichCLM_eq_matTrace_density_mul (Ω := Ω) L A]
  rw [densityMatrixSandwich_eq_densityMatrixCore (Ω := Ω) L hL]


end

end Derived
end AQFT
end PillarB
