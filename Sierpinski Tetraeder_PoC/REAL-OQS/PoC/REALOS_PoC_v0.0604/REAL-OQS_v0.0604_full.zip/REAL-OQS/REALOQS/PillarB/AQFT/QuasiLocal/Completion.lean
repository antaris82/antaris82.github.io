import REALOQS.PillarB.AQFT.QuasiLocal.StarAlgebra
import REALOQS.PillarB.AQFT.CStarNorm

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace QuasiLocal

/-!
# QuasiLocal completion hook (B2.1)

This module intentionally stays **gate-oriented**.

The quasilocal carrier `Carrier N` is already a directed-colimit style carrier
(and in our setup even canonically equivalent to the distinguished top fiber).
However, a *C⋆-completion* requires analytic structure that we do not want to
hard-code into the core of Pillar B at this stage.

Instead we provide a minimal *completion interface* that later layers (or
specialized instantiations) can implement:

* a target complex C⋆-algebra `A∞`,
* a *-homomorphism from the quasilocal *-algebra into `A∞` (in the lightweight
  bundled sense of `StarAlgHom`),
* gate predicates for isometricity / density / universal property.

Nothing in this file asserts existence.
-/

universe u v

variable {Ω : Type u}

open PillarB.AQFT

namespace Completion

/-- A *C⋆-completion* of the quasilocal *-algebra (as an interface).

`isIsometric`, `hasDenseRange`, and `hasUP` are **gate predicates**;
their concrete meaning is supplied by later layers.
-/
structure Data (N : LocalStarAlgebraNet (Ω := Ω)) where
  /-- Target C⋆-algebra (bundle). -/
  Ainf : CStarAlgebraBundle.{v}

  /-- The induced *-algebra structure on the quasilocal carrier. -/
  SAq : StarAlgebra (QuasiLocal.Carrier (Ω := Ω) N) :=
    QuasiLocal.carrierStarAlgebra (Ω := Ω) N

  /-- Bundled `StarAlgebra` on the target C⋆-algebra. -/
  SAt : StarAlgebra Ainf.Carrier :=
    AQFT.starAlgebraOfCStar Ainf.Carrier

  /-- The inclusion of the quasilocal *-algebra into the completion target. -/
  iota_inf : StarAlgHom SAq SAt

  /-- Gate: the inclusion preserves the intended norm (isometric). -/
  isIsometric : Prop

  /-- Gate: the image is dense (w.r.t. the target topology). -/
  hasDenseRange : Prop

  /-- Gate: universal property of the completion (C⋆-envelope style). -/
  hasUP : Prop

end Completion

end QuasiLocal
end AQFT
end PillarB
