import REALOQS.PillarB.AQFT.QuasiLocal.StateLift
import REALOQS.PillarB.AQFT.Derived.StateFromConfigNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

universe u

open PillarA

/-!
# Quasilocal state lift for the configuration net

Phase 4 operational closure:

* build a canonical `GlobalStateCone` from a top evaluation state,
* lift it to a quasilocal state via `QuasiLocal.stateLift`.
-/

/-- The derived configuration-based local *-algebra net (notation). -/
abbrev N (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω) :=
  localStarAlgebraNet (Ω := Ω) d

/-- The induced `StateNet` used by the quasilocal construction (notation). -/
abbrev SN (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat) :
    PillarA.LayerA.StateNet (Ω := Ω) :=
  PillarB.AQFT.QuasiLocal.SN (Ω := Ω) (N := N (Ω := Ω) d)

/-- Global cone (as required by `QuasiLocal.stateLift`) from a *top state*. -/

def globalConeQL_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := SN (Ω := Ω) d)
    (ρTop := ρTop)

/-- The canonical quasilocal state induced by a *top state*. -/
def quasiLocalState_fromTopState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (ρTop : StateOn (Alg (Ω := Ω) d (Finset.univ : Finset Ω))) :
    StateOn (PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω) (N := N (Ω := Ω) d)) :=
  PillarB.AQFT.QuasiLocal.stateLift (Ω := Ω) (N := N (Ω := Ω) d)
    (C := globalConeQL_fromTopState (Ω := Ω) d ρTop)

/-- Global cone (as required by `QuasiLocal.stateLift`) from a top configuration. -/
def globalConeQL (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarA.LayerA.GlobalStateCone (SN := SN (Ω := Ω) d) :=
  PillarA.LayerA.GlobalStateCone.fromTop (SN := SN (Ω := Ω) d)
    (ρTop := evalTop (Ω := Ω) d σ0)

/-- The canonical quasilocal state induced by the top evaluation state. -/
def quasiLocalState (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    StateOn (PillarB.AQFT.QuasiLocal.Carrier (Ω := Ω) (N := N (Ω := Ω) d)) :=
  PillarB.AQFT.QuasiLocal.stateLift (Ω := Ω) (N := N (Ω := Ω) d)
    (C := globalConeQL (Ω := Ω) d σ0)

/-! ## Small regression gates (restriction recovers the cone) -/

example (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω) (N := N (Ω := Ω) d)
        (quasiLocalState (Ω := Ω) d σ0) (Finset.univ : Finset Ω) =
      (globalConeQL (Ω := Ω) d σ0).ω (Finset.univ : Finset Ω) := by
  simpa [quasiLocalState] using
    (PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω) (N := N (Ω := Ω) d) (C := globalConeQL (Ω := Ω) d σ0)
      (r := (Finset.univ : Finset Ω)))

example (Ω : Type u) [Fintype Ω] [DecidableEq Ω] (d : Nat)
    (σ0 : Cfg (Ω := Ω) d (Finset.univ : Finset Ω)) :
    PillarB.AQFT.QuasiLocal.restrictToRegion (Ω := Ω) (N := N (Ω := Ω) d)
        (quasiLocalState (Ω := Ω) d σ0) (∅ : Finset Ω) =
      (globalConeQL (Ω := Ω) d σ0).ω (∅ : Finset Ω) := by
  simpa [quasiLocalState] using
    (PillarB.AQFT.QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω) (N := N (Ω := Ω) d) (C := globalConeQL (Ω := Ω) d σ0)
      (r := (∅ : Finset Ω)))

end Derived
end AQFT
end PillarB
