/-
# TreeOfCliquesFromPillarA

Strict ToC→B bridge surface.

This file now exposes both maintained ToC branches:

- the rich/completion matrix path (`N_rich_ToC`, `ρTop`, `Φ_FromA`, ...), and
- the additive observable subnet path (`N_add_ToC`, `ρAdd_top`, `Φ_add_FromA`, ...).

The observable path is derived from the A-exported boundary operator `L` and is
kept explicitly separate from the rich completion path.
-/

import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
import REALOQS.PillarB.AQFT.Derived.EnergyFromBoundaryOp
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixObservableBasis
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveSubnet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveProperties
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixQuasiLocalClosure
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGNS
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixModular

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived
namespace TreeOfCliquesFromPillarA

noncomputable section

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
open PillarB.AQFT.Derived
open PillarB.AQFT.QuasiLocal

variable {b : Nat}

namespace ToC

variable (p : _root_.PillarA.LayerA.Policy b)

/-- The concrete site type exported from Pillar A for the ToC→AQFT bridge. -/
abbrev Ω : Type :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.Ω (b := b) p

instance : Fintype (Ω (b := b) (p := p)) := by
  infer_instance

instance : DecidableEq (Ω (b := b) (p := p)) := by
  classical
  infer_instance

/-- Canonical boundary operator exported from Pillar A. -/
abbrev L : Matrix (Ω (b := b) (p := p)) (Ω (b := b) (p := p)) ℝ :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L (b := b) p

@[simp] lemma L_def :
    L (b := b) (p := p) =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L (b := b) p := rfl

/-- Canonical matter template induced by the strict A-side handoff.

This remains available as a derived observable hook, but it is no longer the
active carrier of the ToC top state in the strict B-closure path.
-/
noncomputable def T : MatterTemplate :=
  { d := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA (b := b) p
    d_pos := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA_pos (b := b) p
    β := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p
    φ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.phiFromA (b := b) p }

@[simp] theorem T_d :
    (T (b := b) (p := p)).d =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA (b := b) p := rfl

@[simp] theorem T_phi :
    (T (b := b) (p := p)).φ =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.phiFromA (b := b) p := rfl

/-- The active local net on the ToC handoff carrier is now matrix-based. -/
noncomputable abbrev N_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixLocalNet (Ω := Ω (b := b) (p := p))

/-- Architectural alias: the currently active ToC net is the rich/completion
matrix net.  The future additive observable net is intended to sit as a
subnet inside this carrier. -/
noncomputable abbrev N_rich_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  N_ToC (b := b) (p := p)

/-- Canonical observable basis on the rich ToC boundary-matrix net, derived
strictly from the A-side exported boundary operator `L`. -/
noncomputable abbrev B_ToC :
    _root_.PillarB.AQFT.Gates.HaagKastler.RegionBasis
      (N := N_rich_ToC (b := b) (p := p)) :=
  boundaryObservableBasisFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

/-- Finite family of canonical `L`-derived basis regions on the ToC carrier. -/
noncomputable def basisFamily_ToC : Finset (BoundaryRegion (Ω (b := b) (p := p))) :=
  boundaryObservableBasisFamilyFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

/-- Additive observable subnet on the ToC carrier, generated from the
canonical `L`-derived basis inside the rich matrix net. -/
noncomputable abbrev N_add_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixAdditiveNetFromL
    (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

/-- Fiberwise inclusion of the additive observable ToC subnet into the rich
ToC matrix net. -/
noncomputable abbrev observableInclRich_ToC
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    StarAlgHom
      ((N_add_ToC (b := b) (p := p)).SA r)
      ((N_rich_ToC (b := b) (p := p)).SA r) :=
  boundaryMatrixAdditiveInclRichHom
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    r

/-- Observable basis transported to the additive ToC subnet. -/
noncomputable abbrev B_add_ToC :
    _root_.PillarB.AQFT.Gates.HaagKastler.RegionBasis
      (N := N_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveBasis
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

/-- Injective isotony on the additive observable ToC subnet. -/
theorem isotony_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveIsotony
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

/-- Locality on the additive observable ToC subnet. -/
theorem locality_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_add_ToC (b := b) (p := p))
      (D := boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))) :=
  boundaryMatrixAdditiveLocality
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

/-- Basis-relative additivity on the additive observable ToC subnet. -/
theorem additivity_basis_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.AdditivityOnBasis
      (N := N_add_ToC (b := b) (p := p))
      (B_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveAdditivityOnBasis
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

@[simp] theorem B_ToC_basic_ball (i : Ω (b := b) (p := p)) :
    (B_ToC (b := b) (p := p)).basic
      (boundaryBallFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p)) i) := by
  change (boundaryObservableBasisFromL
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))).basic
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)
  exact boundaryObservableBasisFromL_basic_ball
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p)) i

/-- The `L`-derived canonical basis family covers the top region of the
rich ToC path. -/
theorem basisFamily_ToC_covers_top :
    _root_.PillarB.AQFT.Gates.HaagKastler.BasisCover
      (N := N_rich_ToC (b := b) (p := p))
      (basisFamily_ToC (b := b) (p := p))
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  change _root_.PillarB.AQFT.Gates.HaagKastler.BasisCover
      (N := boundaryMatrixRichNet (Ω := Ω (b := b) (p := p)))
      (boundaryObservableBasisFamilyFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)))
      ((boundaryMatrixRichNet (Ω := Ω (b := b) (p := p))).LAN.RN.top)
  exact boundaryObservableBasisFamilyFromL_covers_top
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))

section StrictMatrixState

variable [Fact (0 < b)]

/-- Strong top state on the full boundary matrix algebra, derived from `L` and `βFromA`. -/
noncomputable def ρTopStrong : CStarStateOn (Mat (Ω (b := b) (p := p))) :=
  boundaryDensityStateAtBeta
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

theorem ρTopStrong_apply (A : Mat (Ω (b := b) (p := p))) :
    ρTopStrong (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        A := by
  exact boundaryDensityStateAtBeta_apply
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

/-- The induced strict `StateNet` on the block-matrix ToC carrier. -/
noncomputable abbrev SN_ToC :
    PillarA.LayerA.StateNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixStateNet (Ω := Ω (b := b) (p := p))

/-- Distinguished top region of the strict block-matrix ToC net. -/
abbrev topRegion : (N_ToC (b := b) (p := p)).LAN.RN.Region :=
  boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p))

/-- Lightweight top state obtained from the strong matrix state. -/
noncomputable abbrev ρTop :
    StateOn
      ((N_ToC (b := b) (p := p)).LAN.Alg
        (topRegion (b := b) (p := p))) :=
  boundaryMatrixTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Local state obtained by restricting the strong matrix state to a region. -/
noncomputable abbrev ρRegionStrong
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixRegionStrong
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

/-- Local lightweight state surface on the ToC block net; by construction this
is exactly the restriction of `ρTopStrong`. -/
noncomputable abbrev ρRegion
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixRegion
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

@[simp] theorem ρTop_apply
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg
      (topRegion (b := b) (p := p)))) :
    ρTop (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixTop_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

@[simp] theorem ρRegionStrong_apply
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρRegionStrong (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixRegionStrong_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

@[simp] theorem ρRegion_apply
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρRegion (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixRegion_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

@[simp] theorem ρRegion_top :
    ρRegion (b := b) (p := p) (topRegion (b := b) (p := p)) =
      ρTop (b := b) (p := p) := by
  exact boundaryMatrixRegion_top
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Global cone obtained from the strong matrix top state by explicit regional
restriction. -/
noncomputable abbrev cone_FromA :
    PillarA.LayerA.GlobalStateCone (SN := SN_ToC (b := b) (p := p)) :=
  boundaryMatrixStateConeFromStrongTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- The resulting quasilocal state, derived from the strong top matrix state via
its compatible family of local restrictions. -/
noncomputable abbrev Φ_FromA :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω (b := b) (p := p))
        (N := N_ToC (b := b) (p := p))) :=
  boundaryMatrixQuasiLocalStateFromStrongTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

theorem restrictToRegion_univ_Φ_FromA :
    QuasiLocal.restrictToRegion (Ω := Ω (b := b) (p := p))
        (N := N_ToC (b := b) (p := p))
        (Φ_FromA (b := b) (p := p))
        (Finset.univ : Finset (Ω (b := b) (p := p))) =
      ρRegion (b := b) (p := p)
        (Finset.univ : Finset (Ω (b := b) (p := p))) := by
  change QuasiLocal.restrictToRegion
      (Ω := Ω (b := b) (p := p))
      (N := N_ToC (b := b) (p := p))
      (boundaryMatrixQuasiLocalStateFromStrongTop
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p))
      (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p))) =
    boundaryMatrixRegion
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))
      ((T (b := b) (p := p)).β)
      (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
      (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p)))
  exact boundaryMatrixQuasiLocalStateFromStrongTop_restrict
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p)))


/-- The induced strict `StateNet` on the additive observable ToC subnet. -/
noncomputable abbrev SN_add_ToC :
    PillarA.LayerA.StateNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixAdditiveStateNet
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

/-- Lightweight top state on the additive observable ToC subnet, obtained by
restricting the rich top state along the subnet inclusion. -/
noncomputable abbrev ρAdd_top :
    StateOn
      ((N_add_ToC (b := b) (p := p)).LAN.Alg
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top)) :=
  boundaryMatrixAdditiveTopFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Local additive observable state on the ToC subnet, obtained by restricting
the corresponding rich local state. -/
noncomputable abbrev ρAdd_region
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_add_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixAdditiveRegionFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

@[simp] theorem ρAdd_top_apply
    (A : ((N_add_ToC (b := b) (p := p)).LAN.Alg
      ((N_add_ToC (b := b) (p := p)).LAN.RN.top))) :
    ρAdd_top (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A.1) := by
  exact boundaryMatrixAdditiveTopFromRich_apply
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

@[simp] theorem ρAdd_region_apply
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_add_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρAdd_region (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A.1) := by
  exact boundaryMatrixAdditiveRegionFromRich_apply
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

/-- The additive observable top state restricts to the additive local state on
every region. -/
theorem ρAdd_region_eq_restrict_top
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    (SN_add_ToC (b := b) (p := p)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_add_ToC (b := b) (p := p)).LAN.RN) r)
        (ρAdd_top (b := b) (p := p)) =
      ρAdd_region (b := b) (p := p) r := by
  exact boundaryMatrixAdditiveRegionFromRich_eq_restrict_top
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

/-- Global cone on the additive observable ToC subnet obtained by restriction
of the rich local states. -/
noncomputable abbrev cone_add_FromA :
    PillarA.LayerA.GlobalStateCone (SN := SN_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveStateConeFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Quasilocal state on the additive observable ToC subnet obtained by lifting
the compatible family of restricted local states. -/
noncomputable abbrev Φ_add_FromA :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))) :=
  boundaryMatrixAdditiveQuasiLocalStateFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Restricting the additive observable quasilocal state to a region recovers
the corresponding additive local state. -/
theorem restrictToRegion_Φ_add_FromA
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))
        (Φ_add_FromA (b := b) (p := p))
        r =
      ρAdd_region (b := b) (p := p) r := by
  exact boundaryMatrixAdditiveQuasiLocalStateFromRich_restrict
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

/-- The concrete quasilocal carrier of the active ToC block-net. -/
noncomputable abbrev Ainf_FromA : Type :=
  QuasiLocal.Carrier
    (Ω := Ω (b := b) (p := p))
    (N := N_ToC (b := b) (p := p))

/-- Concrete BQ-3 closure: the active quasilocal ToC carrier is canonically
`*-`isomorphic to the full boundary matrix algebra. -/
noncomputable abbrev quasiLocalClosureIsoMatrix_FromA :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω (b := b) (p := p)))
      (SB := matrixStarAlgebraCStar (Ω (b := b) (p := p))) :=
  boundaryMatrixQuasiLocalIsoMatrix (Ω := Ω (b := b) (p := p))

/-! ## BQ-6 / BQ-7 surfacing on the active ToC path -/

/-- Active B-side GNS datum on the strict top-region ToC path. -/
noncomputable abbrev gnsDatum_top_ToC :
    GNSDatum
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p)))
      (ω := ρTop (b := b) (p := p)) :=
  boundaryMatrixTopGNSDatum
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Active transported top-region minus dynamics on the strict ToC path. -/
noncomputable abbrev dyn_top_ToC :
    StarAlgDynamics
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p))) :=
  boundaryMatrixTopDynMinus
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Active top-region KMS datum on the strict ToC path. -/
noncomputable abbrev kmsDatum_top_ToC :
    KMSState
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p))) :=
  boundaryMatrixTopKMSMinusAtBeta
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
    (hL := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

/-- Active B-side modular/KMS datum on the strict ToC top path. -/
noncomputable abbrev modularDatum_top_ToC :
    BoundaryMatrixModularDatum
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))
      (β := (T (b := b) (p := p)).β)
      (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) :=
  boundaryMatrixTopModularDatum
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
    (hL := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

@[simp] theorem gnsDatum_top_ToC_eq_boundaryMatrixTopGNSDatum :
    gnsDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopGNSDatum
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

omit [Fact (0 < b)] in
@[simp] theorem dyn_top_ToC_eq_boundaryMatrixTopDynMinus :
    dyn_top_ToC (b := b) (p := p) =
      boundaryMatrixTopDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem kmsDatum_top_ToC_eq_boundaryMatrixTopKMSMinusAtBeta :
    kmsDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopKMSMinusAtBeta
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_eq_boundaryMatrixTopModularDatum :
    modularDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopModularDatum
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_matrixKMS :
    (modularDatum_top_ToC (b := b) (p := p)).matrixKMS =
      boundaryFullKMSMinusAtBeta
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_topKMS :
    (modularDatum_top_ToC (b := b) (p := p)).topKMS = kmsDatum_top_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_gns :
    (modularDatum_top_ToC (b := b) (p := p)).gns = gnsDatum_top_ToC (b := b) (p := p) := by
  rfl

/-- Explicit cyclic state-reconstruction theorem on the active ToC top path. -/
theorem state_top_ToC_from_cyclic
    (A : (N_ToC (b := b) (p := p)).LAN.Alg (topRegion (b := b) (p := p))) :
    ρTop (b := b) (p := p) A =
      (gnsDatum_top_ToC (b := b) (p := p)).sesq
        (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec
        ((gnsDatum_top_ToC (b := b) (p := p)).pi A
          (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec) := by
  change ρTop (b := b) (p := p) A =
      (modularDatum_top_ToC (b := b) (p := p)).gns.sesq
        (modularDatum_top_ToC (b := b) (p := p)).gns.cyclicVec
        ((modularDatum_top_ToC (b := b) (p := p)).gns.pi A
          ((modularDatum_top_ToC (b := b) (p := p)).gns.cyclicVec))
  exact (modularDatum_top_ToC (b := b) (p := p)).state_from_cyclic A

end StrictMatrixState

end ToC

end

end TreeOfCliquesFromPillarA
end Derived
end AQFT
end PillarB
