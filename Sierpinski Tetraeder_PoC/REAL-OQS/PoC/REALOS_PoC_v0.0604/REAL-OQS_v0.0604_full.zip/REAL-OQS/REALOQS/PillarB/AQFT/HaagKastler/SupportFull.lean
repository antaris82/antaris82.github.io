import Mathlib.Data.Real.Basic
import REALOQS.PillarB.AQFT.HaagKastler.Support

/-!
# Haag–Kastler support ("full" / strict AQFT layer)

The existing `Support` file provides a lightweight algebraic infrastructure for
stating Haag–Kastler style axioms on *-algebra nets.

In standard AQFT one typically additionally assumes:

* a **vacuum representation** on a Hilbert space,
* a **spectrum condition** (positive energy for translations),
* and often strengthens additivity/time-slice in a C*-setting.

Pillar B is *gate-first*: we record these additional ingredients as **data
bundles and predicates** that can later be instantiated by concrete
constructions (e.g. via GNS) or by external proofs.

No IDEAL substrate imports are used.
-/

set_option autoImplicit false

namespace PillarB.AQFT.HaagKastler

universe u v w

/-!
## Minkowski momentum cone (minimal encoding)

We only need a syntactic carrier for the "forward light cone" to state the
spectrum condition as a gate.

We deliberately avoid committing to a particular spacetime formalization in
Pillar B; this file is purely an interface.
-/

abbrev Momentum : Type := ℝ × ℝ × ℝ × ℝ

def forwardCone (p : Momentum) : Prop :=
  let p0 : ℝ := p.1
  let p1 : ℝ := p.2.1
  let p2 : ℝ := p.2.2.1
  let p3 : ℝ := p.2.2.2
  0 ≤ p0 ∧ p0 ^ 2 ≥ p1 ^ 2 + p2 ^ 2 + p3 ^ 2

def ForwardCone : Set Momentum := {p | forwardCone p}

/-!
## Abstract (unitary) representations and spectrum witnesses

In a fully analytic development, the objects below would be instantiated by
bounded operators on a Hilbert space, and the spectrum would be derived from
the joint spectral measure of the translation representation.

Here we record the minimal *shape* required for the Haag–Kastler spectrum axiom.
-/

structure RepData (G : Type u) where
  /-- Carrier of the representation (intended: Hilbert space). -/
  H : Type v
  /--
  Action map.

  We store *bijectivity* as data (`H ≃ H`) instead of a bare `Prop`. This keeps
  the interface lightweight (no analytic imports) while avoiding vacuous
  placeholders like `Prop := True` (string literal; avoided by using `H ≃ H`).

  If you later upgrade to an inner product space, you can refine this to a
  `Unitary`/`LinearIsometryEquiv`-valued representation.
  -/
  U : G → H ≃ H

/-
NOTE:

`RepData` intentionally does **not** encode the group action laws; gates that
use `RepData` will impose those laws once a `[Group G]` instance is available.
-/

structure SpectrumWitness where
  /-- Candidate joint spectrum / spectral support. -/
  support : Set Momentum
  /-- Positive-energy constraint. -/
  support_subset_forward : support ⊆ ForwardCone

structure SpectrumCondition (G : Type u) where
  rep : RepData G
  spec : SpectrumWitness

/-
NOTE:

We deliberately do **not** bake an analytic notion of "spectrum of a
representation" into this file.

* The positive-energy constraint is captured by `SpectrumWitness`.
* The actual "realization" link between `rep` and `spec` is postponed to an
  analytic layer (e.g. via generators / spectral measures / GNS).

This keeps Pillar B's Haag–Kastler surface minimal and stable.
-/

end PillarB.AQFT.HaagKastler
