from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Optional
import numpy as np
import pandas as pd
import scipy.sparse as sp
import scipy.sparse.linalg as spla

@dataclass
class ResistanceResult:
    ok: bool
    message: str
    edge_df: Optional[pd.DataFrame]
    delta_R: float
    ground: int
    sampled: bool
    n_edges_total: int
    n_edges_used: int

def _reduce_vector(b_full: np.ndarray, ground: int) -> np.ndarray:
    # remove index ground
    return np.concatenate([b_full[:ground], b_full[ground+1:]])

def compute_edge_resistances(
    L: sp.csr_matrix,
    edges: List[Tuple[int,int]],
    *,
    ground: int = 0,
    eps_floor: float,
    max_edges_exact: int = 20000,
    batch_size: int = 32,
    sample_if_too_large: bool = True,
    rng_seed: int = 0,
) -> ResistanceResult:
    n = int(L.shape[0])
    g = int(ground)
    if not (0 <= g < n):
        raise ValueError("invalid ground")

    m = len(edges)
    use_idx = np.arange(m, dtype=np.int64)
    sampled = False
    if m > int(max_edges_exact):
        if not sample_if_too_large:
            return ResistanceResult(False, f"Too many edges ({m}) for exact computation; increase threshold.", None, 0.0, g, False, m, 0)
        rng = np.random.default_rng(int(rng_seed))
        use_idx = rng.choice(m, size=int(max_edges_exact), replace=False)
        use_idx = np.sort(use_idx)
        sampled = True

    # reduced Laplacian
    # Remove row/col g
    keep = np.ones(n, dtype=bool)
    keep[g] = False
    Lred = L[keep][:, keep].tocsc()
    S = (Lred + Lred.T) * 0.5
    fro = float(spla.norm(S, ord="fro"))
    delta_R = float(eps_floor * max(1.0, fro))
    A = S + sp.identity(S.shape[0], dtype=np.float64, format="csc") * delta_R

    try:
        lu = spla.splu(A)
    except Exception as e:
        return ResistanceResult(False, f"Factorization failed: {e}", None, delta_R, g, sampled, m, 0)

    records = []
    # batch solves
    for i0 in range(0, use_idx.size, int(batch_size)):
        idxs = use_idx[i0:i0+int(batch_size)]
        B = np.zeros((A.shape[0], idxs.size), dtype=np.float64)
        keys = []
        for j, k in enumerate(idxs):
            u,v = edges[int(k)]
            u=int(u); v=int(v)
            b_full = np.zeros((n,), dtype=np.float64)
            b_full[u] += 1.0
            b_full[v] -= 1.0
            b = _reduce_vector(b_full, g)
            B[:, j] = b
            keys.append((u,v))
        X = lu.solve(B)  # (n-1, batch)
        for j,(u,v) in enumerate(keys):
            b_full = np.zeros((n,), dtype=np.float64)
            b_full[u] += 1.0
            b_full[v] -= 1.0
            b = _reduce_vector(b_full, g)
            x = X[:, j]
            R = float(b @ x)
            if R < 0 and R > -1e-10:
                R = 0.0
            d = float(np.sqrt(max(R, 0.0)))
            uu, vv = (u,v) if u < v else (v,u)
            records.append((uu, vv, R, d))

    df = pd.DataFrame(records, columns=["u","v","R","d"])
    return ResistanceResult(True, "OK", df, delta_R, g, sampled, m, int(use_idx.size))
