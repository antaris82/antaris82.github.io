from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

@dataclass
class HarmonicEmbeddingResult:
    ok: bool
    message: str
    pos: np.ndarray     # (N,3)
    H: np.ndarray       # (N,m)
    boundary_vids: List[int]  # in base order
    delta_H: float

def boundary_from_addresses(addresses: List[List[Tuple[str,int]]], m: int) -> List[int]:
    # find (w="",i) addresses
    by_i = {i: None for i in range(m)}
    for vid, addrs in enumerate(addresses):
        for (w,i) in addrs:
            if w == "" and 0 <= int(i) < m:
                if by_i[int(i)] is None:
                    by_i[int(i)] = int(vid)
    missing = [i for i,v in by_i.items() if v is None]
    if missing:
        raise ValueError(f"Missing boundary vertices for indices: {missing}")
    return [by_i[i] for i in range(m)]

def harmonic_dirichlet_embedding(L: sp.csr_matrix, *, addresses: List[List[Tuple[str,int]]], base_pos: np.ndarray, eps_floor: float, jitter: bool=True) -> HarmonicEmbeddingResult:
    n = int(L.shape[0])
    m = int(base_pos.shape[0])
    try:
        B = boundary_from_addresses(addresses, m)
    except Exception as e:
        return HarmonicEmbeddingResult(False, str(e), np.zeros((n,3)), np.zeros((n,m)), [], 0.0)

    B_arr = np.array(B, dtype=np.int64)
    mask = np.ones(n, dtype=bool)
    mask[B_arr] = False
    I = np.where(mask)[0]
    if I.size == 0:
        H = np.eye(m, dtype=np.float64)
        return HarmonicEmbeddingResult(True, "Trivial (no interior).", base_pos.copy(), H, B, 0.0)

    L_II = L[I][:, I].tocsc()
    L_IB = L[I][:, B_arr].tocsc()

    delta_H = 0.0
    A = L_II
    if jitter:
        S = (L_II + L_II.T) * 0.5
        fro = float(spla.norm(S, ord="fro"))
        delta_H = float(eps_floor * max(1.0, fro))
        A = S + sp.identity(S.shape[0], dtype=np.float64, format="csc") * delta_H

    try:
        lu = spla.splu(A)
    except Exception as e:
        return HarmonicEmbeddingResult(False, f"Factorization failed: {e}", np.zeros((n,3)), np.zeros((n,m)), B, delta_H)

    H = np.zeros((n,m), dtype=np.float64)
    for j in range(m):
        H[B_arr[j], j] = 1.0

    for j in range(m):
        hB = H[B_arr, j]
        rhs = -L_IB.dot(hB)
        hI = lu.solve(rhs)
        H[I, j] = hI

    pos = H @ base_pos

    sdev = float(np.max(np.abs(np.sum(H, axis=1) - 1.0)))
    hmin = float(np.min(H))
    maxv = float(np.max(H))
    msg = f"OK (max|sum(H)-1|={sdev:.3e}, H∈[{hmin:.3e},{maxv:.3e}], δ_H={delta_H:.3e})"
    return HarmonicEmbeddingResult(True, msg, pos, H, B, delta_H)
