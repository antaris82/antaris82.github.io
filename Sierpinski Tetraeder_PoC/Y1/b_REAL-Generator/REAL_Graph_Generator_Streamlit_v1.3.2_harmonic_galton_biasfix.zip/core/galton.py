from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

@dataclass
class BranchStats:
    # Per-vertex statistics for the canonical random walk on an undirected weighted graph:
    # P(u->v) = c_uv / sum_{w~u} c_uw
    degree: np.ndarray      # (N,) int
    sum_c: np.ndarray       # (N,) float
    entropy: np.ndarray     # (N,) float (NaN if degree==0 or sum_c<=0)
    p1: np.ndarray          # (N,) float (max probability)
    p2: np.ndarray          # (N,) float (2nd max probability; NaN if degree<2)
    delta: np.ndarray       # (N,) float = log(p1/p2) (NaN if degree<2)

def build_edge_adjacency(n: int, edges: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build a CSR-like adjacency encoding for an undirected edge list.

    Returns
    -------
    indptr : (N+1,) int64
        Row pointers per vertex u.
    nbrs   : (2M,) int64
        Neighbor vertex id for each directed adjacency entry.
    eidx   : (2M,) int64
        Edge index k for each directed adjacency entry; conductance is c[k].
    """
    n = int(n)
    edges = np.asarray(edges, dtype=np.int64)
    if edges.ndim != 2 or edges.shape[1] != 2:
        raise ValueError("edges must be shape (M,2)")
    m = int(edges.shape[0])
    u = edges[:,0]; v = edges[:,1]

    deg = np.bincount(np.concatenate([u, v]), minlength=n).astype(np.int64)
    indptr = np.zeros(n+1, dtype=np.int64)
    indptr[1:] = np.cumsum(deg)

    nbrs = np.empty(2*m, dtype=np.int64)
    eidx = np.empty(2*m, dtype=np.int64)

    # cursor per node
    cur = indptr[:-1].copy()
    for k in range(m):
        a = int(u[k]); b = int(v[k])
        ia = int(cur[a]); cur[a] += 1
        ib = int(cur[b]); cur[b] += 1
        nbrs[ia] = b; eidx[ia] = k
        nbrs[ib] = a; eidx[ib] = k

    return indptr, nbrs, eidx

def branch_stats(indptr: np.ndarray, nbrs: np.ndarray, eidx: np.ndarray, c: np.ndarray, *, eps_floor: float=0.0) -> BranchStats:
    """
    Compute per-vertex branch statistics for the canonical random walk
    induced by undirected conductances c on edges.
    """
    indptr = np.asarray(indptr, dtype=np.int64)
    nbrs = np.asarray(nbrs, dtype=np.int64)
    eidx = np.asarray(eidx, dtype=np.int64)
    c = np.asarray(c, dtype=np.float64)

    n = indptr.shape[0] - 1
    # degree
    degree = (indptr[1:] - indptr[:-1]).astype(np.int64)

    # sum_c via bincount on directed entries
    weights_dir = c[eidx]
    sum_c = np.zeros(n, dtype=np.float64)
    # accumulate weights_dir over vertex rows
    # use indptr ranges in loop (fast enough; avoids building src array of length 2M for large M)
    for u in range(n):
        a = int(indptr[u]); b = int(indptr[u+1])
        if a == b:
            continue
        sum_c[u] = float(np.sum(weights_dir[a:b]))

    entropy = np.full(n, np.nan, dtype=np.float64)
    p1 = np.full(n, np.nan, dtype=np.float64)
    p2 = np.full(n, np.nan, dtype=np.float64)
    delta = np.full(n, np.nan, dtype=np.float64)

    eps = float(eps_floor)

    for u in range(n):
        a = int(indptr[u]); b = int(indptr[u+1])
        d = int(degree[u])
        s = float(sum_c[u])
        if d <= 0 or not np.isfinite(s) or s <= 0.0:
            continue
        p = weights_dir[a:b] / s
        # numerical guard: clip only for log stability; do not renormalize
        if eps > 0.0:
            p_clip = np.clip(p, eps, 1.0)
        else:
            p_clip = p
        entropy[u] = float(-np.sum(p_clip * np.log(p_clip)))

        # top-2
        if d == 1:
            p1[u] = float(p[0])
            continue
        # partial sort for speed
        # get indices of 2 largest probabilities
        idx = np.argpartition(p, -2)[-2:]
        # sort these two
        if p[idx[0]] >= p[idx[1]]:
            i1, i2 = int(idx[0]), int(idx[1])
        else:
            i1, i2 = int(idx[1]), int(idx[0])
        p1u = float(p[i1]); p2u = float(p[i2])
        p1[u] = p1u; p2[u] = p2u
        if p2u > 0.0:
            delta[u] = float(np.log((p1u + eps) / (p2u + eps)))

    return BranchStats(degree=degree, sum_c=sum_c, entropy=entropy, p1=p1, p2=p2, delta=delta)

def hitting_from_H(H: np.ndarray, boundary_vids: np.ndarray) -> Tuple[np.ndarray, float, float, float]:
    """
    Compute a simple 'uniform interior' hitting distribution proxy from the harmonic Dirichlet matrix H.
    Returns p_uniform (m,), sdev=max|sum(H)-1|, Hmin, Hmax.
    """
    H = np.asarray(H, dtype=np.float64)
    boundary_vids = np.asarray(boundary_vids, dtype=np.int64)
    n, m = H.shape
    mask = np.ones(n, dtype=bool)
    mask[boundary_vids] = False
    I = np.where(mask)[0]
    if I.size == 0:
        p = np.mean(H[boundary_vids], axis=0)
    else:
        p = np.mean(H[I], axis=0)
    sdev = float(np.max(np.abs(np.sum(H, axis=1) - 1.0)))
    hmin = float(np.min(H))
    hmax = float(np.max(H))
    return p.astype(np.float64), sdev, hmin, hmax
