from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from .utils import v2_factor

@dataclass
class IdealGraph:
    substrate: str
    L_max: int
    n_vertices: int
    edges: List[Tuple[int,int]]
    edge_level: np.ndarray
    is_trunk: np.ndarray
    vid: np.ndarray
    pos: np.ndarray        # (N,3)
    bary: np.ndarray       # (N,m) integer barycentric weights summing to 2^L_max
    level_min: np.ndarray
    level_max: np.ndarray
    addresses: List[List[Tuple[str,int]]]
    base_pos: np.ndarray   # (m,3)

def base_simplex(substrate: str) -> np.ndarray:
    if substrate == "SG":
        q0 = np.array([0.0, 0.0, 0.0])
        q1 = np.array([1.0, 0.0, 0.0])
        q2 = np.array([0.5, np.sqrt(3)/2, 0.0])
        return np.vstack([q0,q1,q2])
    if substrate == "ST":
        # Regular tetrahedron, centered-ish; choose canonical coords
        q0 = np.array([0.0, 0.0, 0.0])
        q1 = np.array([1.0, 0.0, 0.0])
        q2 = np.array([0.5, np.sqrt(3)/2, 0.0])
        q3 = np.array([0.5, np.sqrt(3)/6, np.sqrt(2/3)])
        return np.vstack([q0,q1,q2,q3])
    raise ValueError("substrate must be SG or ST")

def iter_words(S: List[int], L: int):
    if L == 0:
        yield ()
        return
    # iterative product, deterministic order lexicographic
    import itertools
    for w in itertools.product(S, repeat=L):
        yield w

def bary_from_word_and_vertex(word: Tuple[int,...], j: int, m: int) -> Tuple[np.ndarray, int]:
    # start with D=1, weights e_j
    w = np.zeros((m,), dtype=np.int64)
    w[int(j)] = 1
    D = 1
    for i in word:
        w[int(i)] += D
        D *= 2
    return w, D

def bary_scaled_to_Lmax(word: Tuple[int,...], j: int, m: int, L_max: int) -> np.ndarray:
    w, D = bary_from_word_and_vertex(word, j, m)
    l = len(word)
    scale = 2**(L_max - l)
    return (w * scale).astype(np.int64)

def level_min_from_bary(b: np.ndarray, L_max: int) -> int:
    # minimal level l such that point appears on denom 2^l grid
    # b sums to 2^L_max
    k = min(v2_factor(int(x)) for x in b)
    k = min(k, L_max)
    return int(L_max - k)

def generate_ideal_graph(substrate: str, L_max: int) -> IdealGraph:
    substrate = substrate.upper()
    base = base_simplex(substrate)
    m = base.shape[0]
    S = list(range(m))
    L_max = int(L_max)
    Dmax = 2**L_max

    # Build vertex dict from level L_max vertices (V_Lmax). For SG/ST, V_0 ⊂ ... ⊂ V_Lmax,
    # so V up to L_max equals V_Lmax, but Addr(x) should include multi-level addresses.
    key_to_vid: Dict[Tuple[int,...], int] = {}
    bary_list: List[np.ndarray] = []
    addr_sets: List[set] = []

    def get_vid(b_key: Tuple[int,...]) -> int:
        if b_key in key_to_vid:
            return key_to_vid[b_key]
        vid = len(bary_list)
        key_to_vid[b_key] = vid
        bary_list.append(np.array(b_key, dtype=np.int64))
        addr_sets.append(set())
        return vid

    # First pass: ensure we create the full vertex set V_Lmax
    for w in iter_words(S, L_max):
        for j in range(m):
            b = bary_scaled_to_Lmax(w, j, m, L_max)
            get_vid(tuple(int(x) for x in b))

    # Second pass: populate Addr(x) for all levels l=0..L_max (includes the empty word at l=0)
    for l in range(L_max + 1):
        for w in iter_words(S, l):
            w_str = "".join(str(x) for x in w)
            for j in range(m):
                b = bary_scaled_to_Lmax(w, j, m, L_max)
                vid = key_to_vid[tuple(int(x) for x in b)]
                addr_sets[vid].add((w_str, int(j)))

    # Convert address sets to lists (stable order)
    addresses: List[List[Tuple[str,int]]] = []
    for s in addr_sets:
        addresses.append(sorted(list(s), key=lambda t: (len(t[0]), t[0], int(t[1]))))

    bary = np.vstack(bary_list).astype(np.int64)
    n = bary.shape[0]

    # Positions from barycentric weights
    pos = (bary.astype(np.float64) @ base) / float(Dmax)

    # Level min/max
    level_min = np.array([level_min_from_bary(bary[i], L_max) for i in range(n)], dtype=np.int32)
    level_max = np.full((n,), L_max, dtype=np.int32)

    # Build edges union across levels with first-appearance level
    edge_to_level: Dict[Tuple[int,int], int] = {}
    for l in range(L_max + 1):
        for w in iter_words(S, l):
            for (a, b0) in base_edges(substrate):
                ba = bary_scaled_to_Lmax(w, a, m, L_max)
                bb = bary_scaled_to_Lmax(w, b0, m, L_max)
                ua = key_to_vid[tuple(int(x) for x in ba)]
                vb = key_to_vid[tuple(int(x) for x in bb)]
                u, v = (ua, vb) if ua < vb else (vb, ua)
                key = (u, v)
                if key not in edge_to_level or l < edge_to_level[key]:
                    edge_to_level[key] = l

    edges = sorted(edge_to_level.keys())
    edge_level = np.array([edge_to_level[e] for e in edges], dtype=np.int32)
    is_trunk = (edge_level == 0)

    vid_arr = np.arange(n, dtype=np.int32)
    return IdealGraph(
        substrate=substrate,
        L_max=L_max,
        n_vertices=n,
        edges=edges,
        edge_level=edge_level,
        is_trunk=is_trunk,
        vid=vid_arr,
        pos=pos.astype(np.float64),
        bary=bary,
        level_min=level_min,
        level_max=level_max,
        addresses=addresses,
        base_pos=base.astype(np.float64),
    )

def base_edges(substrate: str) -> List[Tuple[int,int]]:
    if substrate == "SG":
        return [(0,1),(1,2),(2,0)]
    if substrate == "ST":
        return [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
    raise ValueError("substrate must be SG or ST")
