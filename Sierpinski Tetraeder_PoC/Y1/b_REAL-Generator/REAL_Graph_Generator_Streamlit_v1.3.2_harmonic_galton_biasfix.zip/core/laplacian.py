from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import numpy as np
import scipy.sparse as sp

@dataclass
class Operators:
    adjacency: sp.csr_matrix
    laplacian: sp.csr_matrix

def build_operators(n: int, edges: List[Tuple[int,int]], conductance: np.ndarray) -> Operators:
    n = int(n)
    m = len(edges)
    c = np.asarray(conductance, dtype=np.float64)
    if c.shape[0] != m:
        raise ValueError("conductance length mismatch")
    rows = []
    cols = []
    dataA = []
    dataL = []
    diag = np.zeros((n,), dtype=np.float64)

    for k,(u,v) in enumerate(edges):
        w = float(c[k])
        u = int(u); v=int(v)
        rows += [u,v]
        cols += [v,u]
        dataA += [1.0,1.0]
        dataL += [-w,-w]
        diag[u] += w
        diag[v] += w

    # Laplacian off-diagonals
    L = sp.csr_matrix((dataL, (rows, cols)), shape=(n,n), dtype=np.float64)
    L = L + sp.diags(diag, format="csr")
    A = sp.csr_matrix((dataA, (rows, cols)), shape=(n,n), dtype=np.float64)
    return Operators(adjacency=A, laplacian=L)
