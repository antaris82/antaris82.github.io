from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Dict
import numpy as np

@dataclass
class ValidationReport:
    ok: bool
    issues: List[str]
    stats: Dict[str, float]

def validate_ideal(n: int, edges: List[Tuple[int,int]], edge_level: np.ndarray, is_trunk: np.ndarray) -> ValidationReport:
    issues = []
    n = int(n)
    if n <= 0:
        issues.append("n_vertices <= 0")
    if len(edges) != edge_level.shape[0]:
        issues.append("edge_level length mismatch")
    if len(edges) != is_trunk.shape[0]:
        issues.append("is_trunk length mismatch")
    # check u<v and bounds
    for (u,v) in edges[:min(len(edges), 50000)]:
        if not (0 <= u < n and 0 <= v < n):
            issues.append("edge endpoint out of bounds")
            break
        if not (u < v):
            issues.append("edge not canonical u<v")
            break
    # trunk correctness
    if np.any(is_trunk != (edge_level == 0)):
        issues.append("is_trunk inconsistent with edge_level==0")
    stats = {"n_vertices": float(n), "n_edges": float(len(edges)), "edge_level_min": float(np.min(edge_level)), "edge_level_max": float(np.max(edge_level))}
    return ValidationReport(ok=(len(issues)==0), issues=issues, stats=stats)

def validate_real_step(is_trunk: np.ndarray, c_prev: np.ndarray, c_curr: np.ndarray, eps_floor: float) -> List[str]:
    issues = []
    if np.any(c_curr < eps_floor*0.999):
        issues.append("conductance below eps_floor detected")
    # trunk fixed
    if np.any(np.abs(c_curr[is_trunk] - c_prev[is_trunk]) > 0):
        issues.append("trunk conductance changed")
    return issues
