from __future__ import annotations
import hashlib
import numpy as np

def eps_floor_float64() -> float:
    return float(np.sqrt(np.finfo(np.float64).eps))

def alpha_weights(r_star: float, K_max: int) -> np.ndarray:
    K_max = int(K_max)
    if K_max <= 0:
        return np.zeros((0,), dtype=np.float64)
    r = float(r_star)
    ks = np.arange(1, K_max+1, dtype=np.float64)
    w = np.power(r, ks)
    s = float(np.sum(w))
    if s <= 0:
        # fallback: uniform (deterministic)
        return np.ones((K_max,), dtype=np.float64)/float(K_max)
    return (w/s).astype(np.float64)

def mu_alpha(alpha: np.ndarray) -> float:
    if alpha.size == 0:
        return 0.0
    ks = np.arange(1, alpha.size+1, dtype=np.float64)
    return float(np.sum(alpha*ks))

def sha256_edges(edges_uv: np.ndarray) -> str:
    h = hashlib.sha256()
    h.update(edges_uv.astype(np.int64).tobytes())
    return h.hexdigest()

def v2_factor(n: int) -> int:
    # 2-adic valuation v2(n) for n>=0; define v2(0)=+inf -> return large
    if n == 0:
        return 10**9
    v = 0
    while (n & 1) == 0:
        n >>= 1
        v += 1
    return v
