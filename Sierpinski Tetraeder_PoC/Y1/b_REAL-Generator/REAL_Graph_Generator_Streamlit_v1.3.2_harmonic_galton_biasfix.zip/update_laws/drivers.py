from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from core.utils import alpha_weights, mu_alpha

class DeltaDriver:
    name: str = "base"
    def compute(self, *, edge_level: np.ndarray, K_max: int, r_star: float, amplitude: float, step: int) -> np.ndarray:
        raise NotImplementedError

@dataclass
class NullDriver(DeltaDriver):
    name: str = "NullDriver"
    def compute(self, *, edge_level: np.ndarray, K_max: int, r_star: float, amplitude: float, step: int) -> np.ndarray:
        return np.zeros_like(edge_level, dtype=np.float64)

@dataclass
class SymmetricScaleBreakDriver(DeltaDriver):
    name: str = "SymmetricScaleBreakDriver"
    def compute(self, *, edge_level: np.ndarray, K_max: int, r_star: float, amplitude: float, step: int) -> np.ndarray:
        if int(K_max) <= 0:
            return np.zeros_like(edge_level, dtype=np.float64)
        alpha = alpha_weights(float(r_star), int(K_max))
        mu = mu_alpha(alpha)
        return float(amplitude) * (edge_level.astype(np.float64) - float(mu))
