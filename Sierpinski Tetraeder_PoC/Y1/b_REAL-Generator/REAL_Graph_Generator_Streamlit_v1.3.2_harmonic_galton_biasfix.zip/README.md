# REAL-Graph Generator (Streamlit) — v1.3 (Harmonic Option C + Galton/Bias layer)

Implements:
- IDEAL SG/ST generator (finite cut-off multi-level bundle up to L_max)
- REAL conductance evolution (vNext.3-canonical)
- canonical resistance metric with explicit δ_R I
- **Option C**: harmonic Dirichlet embedding derived from L_n to keep B0 fixed (V0 boundary)

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Why harmonic embedding
Force/stress layouts can drift and place vertices outside B0.  
The harmonic embedding solves a Dirichlet problem on the current Laplacian and maps
x(v)=Σ_j h_j(v) q_j, with fixed boundary h_j(q_k)=δ_jk on V0.

Export includes harmonic positions and H-matrices per step.
