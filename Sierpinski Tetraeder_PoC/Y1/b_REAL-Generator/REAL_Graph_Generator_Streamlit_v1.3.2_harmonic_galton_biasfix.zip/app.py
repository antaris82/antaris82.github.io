from __future__ import annotations

import json
import tempfile
import time
from pathlib import Path
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.colors as pc
import scipy.sparse as sp
import streamlit as st

from core.ideal_generator import generate_ideal_graph, IdealGraph
from core.laplacian import build_operators
from core.resistance_metric import compute_edge_resistances, ResistanceResult
from core.harmonic_embedding import harmonic_dirichlet_embedding, HarmonicEmbeddingResult
from core.galton import build_edge_adjacency, branch_stats, hitting_from_H, BranchStats
from core.validation import validate_ideal, validate_real_step
from core.artifacts import export_ideal, export_real_step, export_manifest, zip_dir
from core.utils import eps_floor_float64, alpha_weights, mu_alpha, sha256_edges

from update_laws.drivers import NullDriver, SymmetricScaleBreakDriver

SCHEMA_VERSION = "REAL-vNext.3-canonical+deltaR+harmonic+galton-v1.3.2"

def _ideal_conductances(mode: str, edge_level: np.ndarray, r_star: float) -> np.ndarray:
    if mode == "IDEAL_combinatorial":
        return np.ones_like(edge_level, dtype=np.float64)
    if mode == "IDEAL_renorm_proxy":
        return np.power(float(r_star), -edge_level.astype(np.float64))
    raise ValueError("Unknown IDEAL mode")

def _driver(name: str):
    if name == "NullDriver":
        return NullDriver()
    if name == "SymmetricScaleBreakDriver":
        return SymmetricScaleBreakDriver()
    raise ValueError("Unknown driver")

def _bin_edges(scores: np.ndarray, n_bins: int) -> np.ndarray:
    n_bins = int(max(1, n_bins))
    if n_bins == 1 or scores.size == 0:
        return np.zeros_like(scores, dtype=np.int32)
    qs = np.linspace(0, 1, n_bins + 1)
    cuts = np.quantile(scores, qs)
    cuts = np.unique(cuts)
    if cuts.size <= 2:
        return np.zeros_like(scores, dtype=np.int32)
    inner = cuts[1:-1]
    b = np.digitize(scores, inner, right=False).astype(np.int32)
    if n_bins != (inner.size + 1):
        b = np.floor(b.astype(np.float64) * (n_bins / float(inner.size + 1))).astype(np.int32)
        b = np.clip(b, 0, n_bins - 1)
    return b

def _edge_trace_2d(pos: np.ndarray, edges: List[Tuple[int,int]], idxs: np.ndarray, color: str, width: float):
    xs=[]; ys=[]
    for i in idxs:
        u,v = edges[int(i)]
        xs += [pos[u,0], pos[v,0], None]
        ys += [pos[u,1], pos[v,1], None]
    return go.Scatter(x=xs, y=ys, mode="lines", line=dict(color=color, width=width), hoverinfo="skip")

def _edge_trace_3d(pos: np.ndarray, edges: List[Tuple[int,int]], idxs: np.ndarray, color: str, width: float):
    xs=[]; ys=[]; zs=[]
    for i in idxs:
        u,v = edges[int(i)]
        xs += [pos[u,0], pos[v,0], None]
        ys += [pos[u,1], pos[v,1], None]
        zs += [pos[u,2], pos[v,2], None]
    return go.Scatter3d(x=xs, y=ys, z=zs, mode="lines", line=dict(color=color, width=width), hoverinfo="skip")

def make_fig(pos: np.ndarray, edges: List[Tuple[int,int]], scores: Optional[np.ndarray], dim: int, n_bins: int, title: str):
    fig = go.Figure()
    M = len(edges)
    if scores is None:
        idxs = np.arange(M, dtype=np.int64)
        if dim == 2:
            fig.add_trace(_edge_trace_2d(pos, edges, idxs, "rgba(80,80,80,0.35)", 1.5))
        else:
            fig.add_trace(_edge_trace_3d(pos, edges, idxs, "rgba(80,80,80,0.35)", 3.0))
    else:
        bins = _bin_edges(scores, n_bins)
        colors = pc.sample_colorscale("Viridis", [i/max(1,n_bins-1) for i in range(n_bins)])
        for b in range(n_bins):
            idxs = np.where(bins==b)[0]
            if idxs.size==0:
                continue
            if dim == 2:
                fig.add_trace(_edge_trace_2d(pos, edges, idxs, colors[b], 2.5))
            else:
                fig.add_trace(_edge_trace_3d(pos, edges, idxs, colors[b], 5.0))

    if dim == 2:
        fig.add_trace(go.Scatter(x=pos[:,0], y=pos[:,1], mode="markers", marker=dict(size=5), hovertext=[f"vid={i}" for i in range(pos.shape[0])]))
        fig.update_xaxes(visible=False); fig.update_yaxes(visible=False, scaleanchor="x", scaleratio=1)
        fig.update_layout(height=620, title=title, showlegend=False)
    else:
        fig.add_trace(go.Scatter3d(x=pos[:,0], y=pos[:,1], z=pos[:,2], mode="markers", marker=dict(size=3), hovertext=[f"vid={i}" for i in range(pos.shape[0])]))
        fig.update_layout(height=650, title=title, showlegend=False, scene=dict(xaxis=dict(visible=False), yaxis=dict(visible=False), zaxis=dict(visible=False)))
    return fig

def scores_sc_logratio(c0: np.ndarray, c: np.ndarray, eps_floor: float) -> np.ndarray:
    c0 = np.asarray(c0, dtype=np.float64)
    c = np.asarray(c, dtype=np.float64)
    if c0.shape != c.shape:
        raise ValueError(f"Conductance arrays not aligned (c0.shape={c0.shape}, c.shape={c.shape}). Clear/redo simulation after changing substrate/L_max/IDEAL mode.")
    c0g = np.maximum(c0, eps_floor)
    cg = np.maximum(c, eps_floor)
    return np.log(cg/c0g)

def scores_sR(edge_R0: pd.DataFrame, edge_Rn: pd.DataFrame, eps_floor: float, edges: List[Tuple[int,int]]) -> np.ndarray:
    r0={(int(u),int(v)):float(R) for u,v,R in zip(edge_R0.u, edge_R0.v, edge_R0.R)}
    rn={(int(u),int(v)):float(R) for u,v,R in zip(edge_Rn.u, edge_Rn.v, edge_Rn.R)}
    out=np.zeros((len(edges),), dtype=np.float64)
    for k,(u,v) in enumerate(edges):
        key=(int(u),int(v)) if u<v else (int(v),int(u))
        if key in r0 and key in rn:
            R0=r0[key]; Rn=rn[key]
            out[k]=(Rn-R0)/(R0+eps_floor)
    return out

@st.cache_data(show_spinner=False)
def cached_ideal(substrate: str, L_max: int) -> IdealGraph:
    return generate_ideal_graph(substrate, int(L_max))

def main():
    st.set_page_config(page_title="REAL-Graph Generator (v1.3.2 harmonic+galton)", layout="wide")
    st.title("REAL-Graph Generator — v1.3.2 (Harmonic Option C + Galton/Bias layer)")
    st.caption("REAL-vNext.3-canonical update + resistance metric with explicit δ_R I + harmonic Dirichlet embedding (Option C) + Galton/Bias analysis outputs.")

    eps_floor = eps_floor_float64()

    with st.sidebar:
        st.header("IDEAL / REAL Parameters")
        substrate = st.selectbox("Substrate", ["SG","ST"], index=0)
        L_max = st.slider("L_max (cut-off)", min_value=0, max_value=(9 if substrate=="SG" else 7), value=(2 if substrate=="SG" else 2), step=1)
        ideal_mode = st.selectbox("IDEAL conductances", ["IDEAL_combinatorial","IDEAL_renorm_proxy"], index=0)

        st.markdown("---")
        st.subheader("REAL update (vNext.3-canonical)")
        r_star = st.number_input("r_* (for α_k weights)", min_value=0.0, max_value=0.999999, value=0.6, step=0.01, format="%.6f")
        driver_name = st.selectbox("Δ driver", ["NullDriver","SymmetricScaleBreakDriver"], index=1)
        amplitude = st.number_input("A (driver amplitude)", min_value=0.0, value=0.02, step=0.01, format="%.6f")
        N_steps = st.slider("Simulation steps N", min_value=0, max_value=30, value=8, step=1)

        st.markdown("---")
        st.subheader("Resistance compute")
        max_edges_exact = st.number_input("Max edges for R(edges)", min_value=1000, max_value=200000, value=20000, step=1000)
        batch_size = st.number_input("R solve batch size", min_value=4, max_value=256, value=32, step=4)
        seed = st.number_input("Sampling seed", min_value=0, max_value=10_000_000, value=0, step=1)
        compute_R_each_step = st.checkbox("Compute R(edges) each step", value=False)

        st.markdown("---")
        st.subheader("Harmonic embedding (Option C)")
        harm_jitter = st.checkbox("Add deterministic jitter δ_H I", value=True)

        st.markdown("---")
        st.subheader("Visualization")
        color_metric = st.selectbox("Edge color metric", ["s_c = log(c/c0)","s_R = (R-R0)/(R0+eps)"], index=0)
        n_bins = st.slider("Edge color bins", min_value=3, max_value=30, value=12, step=1)
        view_dim = st.selectbox("View dim", ["2D","3D"], index=1 if substrate=="ST" else 0)

    ideal = cached_ideal(substrate, int(L_max))
    vrep = validate_ideal(ideal.n_vertices, ideal.edges, ideal.edge_level, ideal.is_trunk)
    if not vrep.ok:
        st.error("IDEAL validation failed:\n- " + "\n- ".join(vrep.issues))
        st.stop()

    # --- Stale simulation guard (prevents mismatched edge arrays after changing substrate/L_max/etc.)
    edge_hash = sha256_edges(np.array(ideal.edges, dtype=np.int64))
    # cache adjacency for branch-statistics (Galton/Bias layer), keyed by edge hash
    if "adj_cache" not in st.session_state or st.session_state.get("adj_cache_hash") != edge_hash:
        indptr, nbrs, eidx = build_edge_adjacency(ideal.n_vertices, np.array(ideal.edges, dtype=np.int64))
        st.session_state["adj_cache"] = (indptr, nbrs, eidx)
        st.session_state["adj_cache_hash"] = edge_hash
    else:
        indptr, nbrs, eidx = st.session_state["adj_cache"]

    sim_prev = st.session_state.get("sim", None)
    if sim_prev is not None:
        p = sim_prev.get("params", {}) if isinstance(sim_prev, dict) else {}
        if (p.get("substrate") != substrate) or (int(p.get("L_max", -1)) != int(L_max)) or (sim_prev.get("edge_order_hash") != edge_hash):
            st.session_state.sim = None
            st.warning("IDEAL parameters changed since the last run. Cleared stale simulation state; please run the simulation again.")


    K_max = max(int(L_max)-1, 0)
    alpha = alpha_weights(float(r_star), int(K_max))
    mu = mu_alpha(alpha)

    c0 = _ideal_conductances(ideal_mode, ideal.edge_level, float(r_star))
    ops0 = build_operators(ideal.n_vertices, ideal.edges, c0)

    tabs = st.tabs(["A) IDEAL","B) REAL Simulation","C) Resistance","D) Deformation (Option C)","E) Galton / Bias","F) Export"])
    dim = 2 if view_dim=="2D" else 3

    with tabs[0]:
        st.subheader("IDEAL graph")
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Vertices", ideal.n_vertices)
        c2.metric("Edges (union)", len(ideal.edges))
        c3.metric("Trunk edges", int(np.sum(ideal.is_trunk)))
        c4.metric("edge_level range", f"{int(np.min(ideal.edge_level))}..{int(np.max(ideal.edge_level))}")

        st.code(f"eps_floor = sqrt(eps(float64)) = {eps_floor:.3e}")
        if K_max==0:
            st.write("K_max=0 ⇒ α empty, Δ≡0")
        else:
            st.dataframe(pd.DataFrame({"k": np.arange(1,K_max+1), "alpha_k": alpha}), use_container_width=True)
            st.write(f"mu_alpha = {mu:.6f}")

        pos = ideal.pos[:, :dim] if dim==2 else ideal.pos
        st.plotly_chart(make_fig(pos, ideal.edges, None, dim, int(n_bins), "IDEAL (IFS embedding)"), use_container_width=True)

    if "sim" not in st.session_state:
        st.session_state.sim = None

    with tabs[1]:
        st.subheader("REAL simulation (conductance evolution)")
        st.markdown("""
Update rule:
- trunk edges fixed: c_{n+1}(e)=c_n(e) for edge_level=0
- other edges: c_{n+1}(e)=c_n(e)·exp(Δ(e))
- conductance floored by eps_floor (deterministic float64 guard)
""")
        driver = _driver(driver_name)

        if st.button("Run / Re-run simulation", type="primary"):
            sim = {
                "params": dict(substrate=substrate, L_max=int(L_max), ideal_mode=ideal_mode, r_star=float(r_star),
                              driver_name=driver_name, amplitude=float(amplitude), N_steps=int(N_steps),
                              eps_floor=float(eps_floor), max_edges_exact=int(max_edges_exact), batch_size=int(batch_size),
                              seed=int(seed), compute_R_each_step=bool(compute_R_each_step), harm_jitter=bool(harm_jitter),
                              view_dim=int(dim)),
                "edge_order_hash": edge_hash,
                "adj": {"indptr": indptr, "nbrs": nbrs, "eidx": eidx},
                "branch_list": [],
                "hit_list": [],
                "c_list": [],
                "delta_list": [],
                "lap_list": [],
                "R_list": [],
                "harm_list": [],
                "validation_issues": [],
                "run_log": []
            }
            c_prev = c0.copy()
            sim["c_list"].append(c_prev.copy())
            sim["delta_list"].append(np.zeros_like(c_prev))
            sim["lap_list"].append(ops0.laplacian)

            # R step 0
            R0 = compute_edge_resistances(ops0.laplacian, ideal.edges, ground=0, eps_floor=eps_floor,
                                          max_edges_exact=int(max_edges_exact), batch_size=int(batch_size),
                                          sample_if_too_large=True, rng_seed=int(seed))
            sim["R_list"].append(R0)

            # Harmonic embedding step 0
            hb0 = harmonic_dirichlet_embedding(ops0.laplacian, addresses=ideal.addresses, base_pos=ideal.base_pos,
                                               eps_floor=eps_floor, jitter=bool(harm_jitter))
            sim["harm_list"].append(hb0)

            # Galton/Bias layer (step 0)
            bs0 = branch_stats(indptr, nbrs, eidx, c_prev, eps_floor=eps_floor)
            sim["branch_list"].append(bs0)
            if hb0 is not None and hb0.ok:
                p_hit0, sdev0, hmin0, hmax0 = hitting_from_H(hb0.H, np.array(hb0.boundary_vids, dtype=np.int64))
                sim["hit_list"].append({"boundary_vids": hb0.boundary_vids, "p_uniform": p_hit0.tolist(),
                                         "diag": {"max_abs_sumH_minus_1": float(sdev0), "Hmin": float(hmin0), "Hmax": float(hmax0)},
                                         "note": "Uniform-interior average of harmonic Dirichlet H; interpretable as hitting-probability proxy for the canonical random walk induced by conductances."})
            else:
                fail_msg = hb0.message if (hb0 is not None) else "No harmonic embedding result."
                fail_B = hb0.boundary_vids if (hb0 is not None) else []
                sim["hit_list"].append({"ok": False, "message": fail_msg, "boundary_vids": fail_B, "p_uniform": None, "diag": None})


            for n in range(int(N_steps)):
                t0 = time.time()
                delta = driver.compute(edge_level=ideal.edge_level, K_max=K_max, r_star=float(r_star), amplitude=float(amplitude), step=n)
                delta = delta.astype(np.float64)
                delta[ideal.is_trunk] = 0.0

                c_curr = c_prev.copy()
                idx = np.where(~ideal.is_trunk)[0]
                if idx.size>0:
                    c_curr[idx] = c_prev[idx] * np.exp(delta[idx])
                c_curr = np.maximum(c_curr, eps_floor)

                issues = validate_real_step(ideal.is_trunk, c_prev, c_curr, eps_floor)
                if issues:
                    sim["validation_issues"].append({"step": n+1, "issues": issues})

                L_curr = build_operators(ideal.n_vertices, ideal.edges, c_curr).laplacian
                sim["c_list"].append(c_curr.copy())
                sim["delta_list"].append(delta.copy())
                sim["lap_list"].append(L_curr)

                # R
                Rn = None
                if compute_R_each_step:
                    Rn = compute_edge_resistances(L_curr, ideal.edges, ground=0, eps_floor=eps_floor,
                                                  max_edges_exact=int(max_edges_exact), batch_size=int(batch_size),
                                                  sample_if_too_large=True, rng_seed=int(seed))
                sim["R_list"].append(Rn)

                # Harmonic embedding
                hb = harmonic_dirichlet_embedding(L_curr, addresses=ideal.addresses, base_pos=ideal.base_pos,
                                                  eps_floor=eps_floor, jitter=bool(harm_jitter))
                sim["harm_list"].append(hb)

                # Galton/Bias layer (step n+1)
                bs = branch_stats(indptr, nbrs, eidx, c_curr, eps_floor=eps_floor)
                sim["branch_list"].append(bs)
                if hb is not None and hb.ok:
                    p_hit, sdev, hmin, hmax = hitting_from_H(hb.H, np.array(hb.boundary_vids, dtype=np.int64))
                    sim["hit_list"].append({"boundary_vids": hb.boundary_vids, "p_uniform": p_hit.tolist(),
                                             "diag": {"max_abs_sumH_minus_1": float(sdev), "Hmin": float(hmin), "Hmax": float(hmax)},
                                             "note": "Uniform-interior average of harmonic Dirichlet H; interpretable as hitting-probability proxy for the canonical random walk induced by conductances."})
                else:
                    fail_msg = hb.message if (hb is not None) else "No harmonic embedding result."
                    fail_B = hb.boundary_vids if (hb is not None) else []
                    sim["hit_list"].append({"ok": False, "message": fail_msg, "boundary_vids": fail_B, "p_uniform": None, "diag": None})


                sim["run_log"].append({"step": n+1, "seconds": time.time()-t0})
                c_prev = c_curr

            st.session_state.sim = sim
            st.success("Simulation finished.")

        sim = st.session_state.sim
        if sim:
            st.json(sim["params"])
            if sim["validation_issues"]:
                st.warning("Validation issues detected.")
                st.json(sim["validation_issues"])

            c_last = sim["c_list"][-1]
            try:
                sc_last = scores_sc_logratio(c0, c_last, eps_floor)
            except ValueError as e:
                st.session_state.sim = None
                st.error(str(e))
                st.info("Cleared stale simulation state. Please run the simulation again.")
                st.stop()
            df = pd.DataFrame({"edge_level": ideal.edge_level.astype(int), "s_c": sc_last})
            st.plotly_chart(go.Figure(data=[go.Box(x=df.edge_level, y=df.s_c, boxpoints=False)]).update_layout(title="s_c grouped by edge_level"), use_container_width=True)
            st.caption("Harmonic embedding diagnostic (last step): " + (sim["harm_list"][-1].message if sim["harm_list"][-1] else "None"))

    with tabs[2]:
        st.subheader("Resistance metric (IDEAL vs REAL)")
        sim = st.session_state.sim
        if not sim:
            st.info("Run simulation first.")
        else:
            step_sel = st.slider("Step n", min_value=0, max_value=int(sim["params"]["N_steps"]), value=min(3,int(sim["params"]["N_steps"])), step=1)
            R0 = sim["R_list"][0]
            Rn = sim["R_list"][step_sel]
            if R0 is None or not R0.ok or R0.edge_df is None:
                st.error("IDEAL resistance missing.")
            if Rn is None:
                st.info("R for this step not computed. Enable 'Compute R each step' or compute now.")
                if st.button("Compute R for selected step now"):
                    L_sel = sim["lap_list"][step_sel]
                    Rn = compute_edge_resistances(L_sel, ideal.edges, ground=0, eps_floor=eps_floor,
                                                  max_edges_exact=int(sim["params"]["max_edges_exact"]), batch_size=int(sim["params"]["batch_size"]),
                                                  sample_if_too_large=True, rng_seed=int(sim["params"]["seed"]))
                    sim["R_list"][step_sel] = Rn
                    st.session_state.sim = sim
                    st.success("Computed.")
            if R0 and R0.ok and R0.edge_df is not None:
                st.write(f"IDEAL: δ_R={R0.delta_R:.3e}, sampled={R0.sampled}, edges_used={R0.n_edges_used}/{R0.n_edges_total}")
            if Rn and getattr(Rn,"ok",False) and Rn.edge_df is not None:
                st.write(f"REAL step {step_sel}: δ_R={Rn.delta_R:.3e}, sampled={Rn.sampled}, edges_used={Rn.n_edges_used}/{Rn.n_edges_total}")

            if R0 and Rn and R0.ok and Rn.ok and (R0.edge_df is not None) and (Rn.edge_df is not None):
                fig = go.Figure()
                fig.add_trace(go.Histogram(x=R0.edge_df.R, name="IDEAL R", opacity=0.6))
                fig.add_trace(go.Histogram(x=Rn.edge_df.R, name=f"REAL R (step {step_sel})", opacity=0.6))
                fig.update_layout(barmode="overlay", title="Edge resistance distribution (edges-only / maybe sampled)")
                st.plotly_chart(fig, use_container_width=True)

    with tabs[3]:
        st.subheader("Deformation view — Harmonic Dirichlet embedding (Option C)")
        sim = st.session_state.sim
        if not sim:
            st.info("Run simulation first.")
        else:
            step_sel = st.slider("Step for view", min_value=0, max_value=int(sim["params"]["N_steps"]), value=min(3,int(sim["params"]["N_steps"])), step=1, key="view_step")
            # IDEAL reference: IFS coordinates (definition)
            pos_ideal = ideal.pos[:, :dim] if dim==2 else ideal.pos

            hb = sim["harm_list"][step_sel]
            if hb is None or not hb.ok:
                st.error("Harmonic embedding not available: " + (hb.message if hb else "None"))
                pos_real = pos_ideal.copy()
            else:
                pos_real_full = hb.pos
                pos_real = pos_real_full[:, :dim] if dim==2 else pos_real_full
                st.caption(hb.message)

            # edge scores
            if color_metric.startswith("s_c"):
                try:
                    scores = scores_sc_logratio(c0, sim["c_list"][step_sel], eps_floor)
                except ValueError as e:
                    st.session_state.sim = None
                    st.error(str(e))
                    st.info("Cleared stale simulation state. Please run the simulation again.")
                    st.stop()
            else:
                R0 = sim["R_list"][0]
                Rn = sim["R_list"][step_sel]
                if R0 is None or Rn is None or (not R0.ok) or (not Rn.ok) or R0.edge_df is None or Rn.edge_df is None:
                    st.warning("s_R requires R(edge) for IDEAL and step n; enable compute_R_each_step or compute manually.")
                    scores = np.zeros((len(ideal.edges),), dtype=np.float64)
                else:
                    scores = scores_sR(R0.edge_df, Rn.edge_df, eps_floor, ideal.edges)

            col1,col2 = st.columns(2)
            col1.plotly_chart(make_fig(pos_ideal, ideal.edges, None, dim, int(n_bins), "IDEAL (IFS)"), use_container_width=True)
            col2.plotly_chart(make_fig(pos_real, ideal.edges, scores, dim, int(n_bins), f"REAL (harmonic, step {step_sel})"), use_container_width=True)

            # diagnostics: min/max H and sum deviation
            if hb and hb.ok:
                H = hb.H
                sdev = float(np.max(np.abs(np.sum(H, axis=1)-1.0)))
                hmin = float(np.min(H)); hmax=float(np.max(H))
                st.write(f"H diagnostic: max|ΣH-1|={sdev:.3e}, min(H)={hmin:.3e}, max(H)={hmax:.3e}. Boundary vids (base order): {hb.boundary_vids}")

    with tabs[4]:
        st.subheader("Galton / Bias layer (invariant statistics)")
        sim = st.session_state.sim
        if not sim:
            st.info("Run simulation first.")
        else:
            st.markdown("""
This tab adds an **interpretation/dynamics layer** on top of the harmonic REAL embedding, without asserting unitarity.

- **Kinematics**: IDEAL self-similarity / address-time ordering (no dynamics assumed).
- **Dynamics proxy**: canonical random walk induced by conductances:  \\(
  P(u\\to v)=c_{uv}/\\sum_{w\\sim u}c_{uw}
  \\).

We operationalize **symmetry 'kipp points'** as vertices with degree ≥2 and |Δ_ideal(u)| ≤ tol, where
\\[
\\Delta(u)=\\log\\frac{p_1(u)}{p_2(u)}
\\]
and p1,p2 are the two largest outgoing probabilities at u.
""" )

            tol = st.number_input("Kipp tolerance tol for |Δ_ideal|", min_value=0.0, value=1e-12, format="%.3e")
            step_sel = st.slider("Step n", min_value=0, max_value=int(sim["params"]["N_steps"]), value=min(3,int(sim["params"]["N_steps"])), step=1, key="galton_step")

            bs0: BranchStats = sim["branch_list"][0]
            bsn: BranchStats = sim["branch_list"][step_sel]

            deg0 = bs0.degree
            # Bias against uniform on same degree: KL(P||U)=log(deg)-H
            kl0 = np.log(np.maximum(deg0.astype(np.int64), 1).astype(np.float64)) - bs0.entropy
            kipp = (deg0 >= 2) & np.isfinite(kl0) & (np.abs(kl0) <= float(tol))
            st.write(f"Kipp points: {int(np.sum(kipp))} / {int(deg0.shape[0])} vertices (deg≥2 and KL_ideal≤tol).")

            # Compute bias metrics for selected step
            degn = bsn.degree
            kln = np.log(np.maximum(degn.astype(np.int64), 1).astype(np.float64)) - bsn.entropy
            # delta_star compares p_max to average probability of the rest; IDEAL uniform => 0
            def _delta_star(deg, p1):
                deg = deg.astype(np.float64)
                p1 = p1.astype(np.float64)
                denom = np.maximum((1.0 - p1) / np.maximum(deg - 1.0, 1.0), 1e-300)
                return np.where(deg >= 2.0, np.log(np.maximum(p1, 1e-300) / denom), np.nan)
            ds0 = _delta_star(bs0.degree, bs0.p1)
            dsn = _delta_star(bsn.degree, bsn.p1)

            # Summary
            frac_bias = float(np.mean(np.isfinite(kln) & (kln > 1e-12)))
            st.write(f"Bias summary (step {step_sel}): fraction with KL>1e-12: {frac_bias:.3f}; max KL: {float(np.nanmax(kln)):.3e}; max delta_star: {float(np.nanmax(dsn)):.3e}")

            # KL distributions on kipp points
            kl0_k = kl0[kipp]
            kln_k = kln[kipp]
            fig = go.Figure()
            fig.add_trace(go.Histogram(x=kl0_k, name="IDEAL KL", opacity=0.6))
            fig.add_trace(go.Histogram(x=kln_k, name=f"REAL KL step {step_sel}", opacity=0.6))
            fig.update_layout(barmode="overlay", title="KL(P||Uniform) on kipp points (IDEAL should be ~0; REAL > 0 indicates bias)")
            st.plotly_chart(fig, use_container_width=True)

            # delta_star distributions on kipp points
            ds0_k = ds0[kipp]
            dsn_k = dsn[kipp]
            fig2 = go.Figure()
            fig2.add_trace(go.Histogram(x=ds0_k, name="IDEAL delta_star", opacity=0.6))
            fig2.add_trace(go.Histogram(x=dsn_k, name=f"REAL delta_star step {step_sel}", opacity=0.6))
            fig2.update_layout(barmode="overlay", title="delta_star = log(p_max / avg(p_rest)) on kipp points")
            st.plotly_chart(fig2, use_container_width=True)

            # Top biased vertices (by KL)
            ids = np.where(np.isfinite(kln) & (degn >= 2))[0]
            if ids.size == 0:
                st.info("No vertices with deg≥2 for bias ranking.")
            else:
                topk = min(30, ids.size)
                order = np.argsort(-kln[ids])[:topk]
                vids = ids[order]
                df_top = pd.DataFrame({
                    "vid": vids.astype(int),
                    "level_min": ideal.level_min[vids].astype(int),
                    "deg": bsn.degree[vids].astype(int),
                    "KL_real": kln[vids],
                    "delta_star_real": dsn[vids],
                    "p1": bsn.p1[vids],
                    "p2": bsn.p2[vids],
                    "H_real": bsn.entropy[vids],
                })
                st.dataframe(df_top, use_container_width=True)
            # Hitting distribution proxy on B0 (boundary vertices)
            hit0 = sim["hit_list"][0]
            hitn = sim["hit_list"][step_sel]
            if hit0 is None or hitn is None:
                st.info("Hitting distribution not available (harmonic embedding failed for this step).")
            else:
                bvids = hit0.get("boundary_vids", [])
                p0 = np.array(hit0.get("p_uniform", []), dtype=np.float64)
                pn = np.array(hitn.get("p_uniform", []), dtype=np.float64)
                df_hit = pd.DataFrame({"boundary_index": np.arange(len(p0)), "boundary_vid": bvids,
                                       "p_uniform_ideal": p0, f"p_uniform_real_step_{step_sel}": pn})
                figp = go.Figure()
                figp.add_trace(go.Bar(x=df_hit.boundary_index, y=df_hit.p_uniform_ideal, name="IDEAL"))
                figp.add_trace(go.Bar(x=df_hit.boundary_index, y=df_hit[f"p_uniform_real_step_{step_sel}"], name=f"REAL step {step_sel}"))
                figp.update_layout(barmode="group", title="Uniform-interior hitting distribution proxy on B0")
                st.plotly_chart(figp, use_container_width=True)
                st.dataframe(df_hit, use_container_width=True)

    with tabs[5]:
        st.subheader("Export artifacts (ZIP)")
        sim = st.session_state.sim
        if not sim:
            st.info("Run simulation first.")
        else:
            step_max = st.slider("Export up to step", min_value=0, max_value=int(sim["params"]["N_steps"]), value=int(sim["params"]["N_steps"]), step=1)
            include_R = st.checkbox("Include R tables where available", value=True)

            if st.button("Build export ZIP", type="primary"):
                tmpdir = Path(tempfile.mkdtemp(prefix="real_graph_export_"))
                meta_ideal = export_ideal(tmpdir, ideal=ideal, mu=np.ones((ideal.n_vertices,), dtype=np.float64), laplacian=ops0.laplacian)
                # export steps
                for s in range(0, int(step_max)+1):
                    c_s = sim["c_list"][s]
                    d_s = sim["delta_list"][s]
                    L_s = sim["lap_list"][s]
                    R_s = sim["R_list"][s] if include_R else None
                    edge_df = None; delta_R=None; ground=None
                    if R_s is not None and getattr(R_s,"ok",False) and R_s.edge_df is not None:
                        edge_df = R_s.edge_df
                        delta_R = float(R_s.delta_R)
                        ground = int(R_s.ground)

                    hb = sim["harm_list"][s]
                    hpos = None; H=None; hmeta=None
                    if hb is not None and hb.ok:
                        hpos = hb.pos.astype(np.float64)
                        H = hb.H.astype(np.float64)
                        hmeta = {"boundary_vids": hb.boundary_vids, "delta_H": float(hb.delta_H), "message": hb.message}

                    export_real_step(tmpdir, step=s, c=c_s, delta=d_s, laplacian=L_s,
                                     edge_R_df=edge_df, delta_R=delta_R, ground=ground,
                                     harmonic_pos=hpos, harmonic_H=H, harmonic_meta=hmeta,
                                     branch=sim["branch_list"][s], hit=sim["hit_list"][s])


                # logs
                (tmpdir/"logs").mkdir(exist_ok=True)
                (tmpdir/"logs"/"run_log.jsonl").write_text("\n".join(json.dumps(x) for x in sim.get("run_log", [])), encoding="utf-8")
                (tmpdir/"logs"/"validation_report.json").write_text(json.dumps({"ideal": {"ok": vrep.ok, "issues": vrep.issues, "stats": vrep.stats},
                                                                               "real": sim.get("validation_issues", [])}, indent=2), encoding="utf-8")

                manifest = {
                    "schema_version": SCHEMA_VERSION,
                    "created_unix": time.time(),
                    "substrate": ideal.substrate,
                    "L_max": int(ideal.L_max),
                    "N_steps": int(sim["params"]["N_steps"]),
                    "ideal_mode": sim["params"]["ideal_mode"],
                    "driver": {"name": sim["params"]["driver_name"], "amplitude": float(sim["params"]["amplitude"]), "r_star": float(sim["params"]["r_star"])},
                    "float": {"dtype": "float64", "eps_floor": float(sim["params"]["eps_floor"])},
                    "resistance_metric": {"ground_rule": "min_vid (0)",
                                          "deltaR_rule": "delta_R = eps_floor * max(1, ||S||_F), S=0.5(Lred+Lred^T)"},
                    "harmonic_embedding": {"boundary_rule": "V0 via addresses (w='',i)", "deltaH_rule": "delta_H = eps_floor * max(1, ||S||_F) on L_II"},
                    "export": {"step_max": int(step_max), "include_R": bool(include_R), "include_galton": True},
                    "edge_order_hash": meta_ideal["edge_order_hash"],
                }
                export_manifest(tmpdir, manifest)

                zip_path = tmpdir.with_suffix(".zip")
                zip_dir(tmpdir, zip_path)
                st.download_button("Download export ZIP", data=zip_path.read_bytes(), file_name=zip_path.name, mime="application/zip")
                st.caption(f"Built at: {zip_path}")

    st.markdown("---")
    st.markdown("## Vereinfachungen (explizit)")
    st.markdown("""
1) **Cut-off L_max**: endlicher Approximant (unvermeidbar für Simulation/Export).  
2) **R(edges) Skalierung**: optionales Sampling, falls zu viele Kanten (rein rechnerisch, protokolliert).  
3) **Option C (harmonische Einbettung)**: Geometrie-Proxy wird als Dirichlet-Lösung aus L_n abgeleitet; keine zusätzliche Dynamik. δ_H ist ein deterministischer float64-Stabilitäts-Term.  
""")

if __name__ == "__main__":
    main()
