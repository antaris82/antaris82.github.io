"""
real.lambda_search
Deterministic bracketing + bisection for λ-search with explicit reason codes.

Reason codes:
- "ok_at_zero"
- "ok"
- "no_bracket"
- "budget_hit"

Note: tau_abs and tau_rel are computed from numerical_policy via numeric.policy.te_thresholds()
unless passed explicitly (useful for synthetic tests).
"""

from __future__ import annotations
from typing import Callable, Dict, Any, Tuple, Optional
import math

from numeric.policy import te_thresholds

def lambda_bracket_bisect(
    F: Callable[[float], float],
    policy: Dict[str, Any],
    *,
    target_scale: float = 1.0,
    tau_abs: Optional[float] = None,
    tau_rel: Optional[float] = None,
) -> Tuple[float, str]:
    """
    Deterministic bracket+bisect search for root of F(λ)=0.

    Bracket construction:
      a = 0
      expand h = h0, h *= gamma, check ±h for sign-change with F(0)

    Termination:
      abs(F(λ)) <= max(tau_abs, tau_rel)   (both are already scaled by target_scale)

    Fallback:
      If no bracket found within Nexpand -> return (0.0, "no_bracket")
      If bisection budget exhausted -> return (0.0, "budget_hit")
    """
    ls = policy.get("lambda_search", {}) if isinstance(policy, dict) else {}
    h0 = float(ls.get("h0", 0.1))
    gamma = float(ls.get("gamma", 2.0))
    Nexpand = int(ls.get("Nexpand", 16))
    Nbisect = int(ls.get("Nbisect", 64))

    if tau_abs is None or tau_rel is None:
        tau_abs2, tau_rel2 = te_thresholds(policy, target_scale)
        if tau_abs is None:
            tau_abs = tau_abs2
        if tau_rel is None:
            tau_rel = tau_rel2

    a = 0.0
    Fa = float(F(a))
    tau = max(float(tau_abs), float(tau_rel))

    if abs(Fa) <= tau:
        return a, "ok_at_zero"

    h = float(h0)
    bracket = None  # (lo, hi, Flo, Fhi)
    for _ in range(Nexpand):
        b1 = +h
        b2 = -h
        Fb1 = float(F(b1))
        Fb2 = float(F(b2))
        if Fa * Fb1 < 0.0:
            bracket = (a, b1, Fa, Fb1)
            break
        if Fa * Fb2 < 0.0:
            bracket = (b2, a, Fb2, Fa)
            break
        h *= gamma

    if bracket is None:
        return 0.0, "no_bracket"

    lo, hi, Flo, Fhi = bracket
    for _ in range(Nbisect):
        mid = 0.5 * (lo + hi)
        Fm = float(F(mid))
        if abs(Fm) <= tau:
            return mid, "ok"
        if Flo * Fm < 0.0:
            hi, Fhi = mid, Fm
        else:
            lo, Flo = mid, Fm

    return 0.0, "budget_hit"
