"""
mismatch.mismatch
Explicit conventions for Mismatch(2)/(3):

Mismatch(2): Frobenius norm on normalized matrices (with Efloor safeguard)
  m2(A,B) = ||A-B||_F / max(||A||_F, Efloor)

Mismatch(3): Eigenvalue distance (ascending sorting) on symmetrized matrices, padded to equal length
  Let a = eigvalsh(sym(A)) sorted ascending, b = eigvalsh(sym(B)) sorted ascending
  pad shorter vector with Efloor
  m3 = ||a-b||_2 / max(||a||_2, Efloor)

Disconnected/N/A:
- If any entry in A or B is NaN/Inf -> return (nan, "na_disconnected")

Size mismatch padding:
- Matrices are embedded into (N x N) where N=max(nA,nB)
- New entries are 0 except diagonal which is padded with Efloor
"""

from __future__ import annotations
from typing import Tuple, Optional
import numpy as np

def _is_na(A: np.ndarray) -> bool:
    return (not np.isfinite(A).all())

def _sym(A: np.ndarray) -> np.ndarray:
    return 0.5 * (A + A.T)

def _pad_matrix(A: np.ndarray, N: int, efloor: float) -> np.ndarray:
    n = A.shape[0]
    out = np.zeros((N, N), dtype=np.float64)
    out[:n, :n] = A.astype(np.float64, copy=False)
    if N > n:
        for i in range(n, N):
            out[i, i] = efloor
    return out

def mismatch2_fro(A: np.ndarray, B: np.ndarray, efloor: float) -> Tuple[float, str]:
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if _is_na(A) or _is_na(B):
        return float("nan"), "na_disconnected"

    N = max(A.shape[0], B.shape[0])
    Ap = _pad_matrix(A, N, efloor)
    Bp = _pad_matrix(B, N, efloor)

    num = np.linalg.norm(Ap - Bp, ord="fro")
    den = max(np.linalg.norm(Ap, ord="fro"), float(efloor))
    return float(num / den), "ok"

def mismatch3_eigs(A: np.ndarray, B: np.ndarray, efloor: float) -> Tuple[float, str]:
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if _is_na(A) or _is_na(B):
        return float("nan"), "na_disconnected"

    N = max(A.shape[0], B.shape[0])
    Ap = _pad_matrix(A, N, efloor)
    Bp = _pad_matrix(B, N, efloor)

    a = np.linalg.eigvalsh(_sym(Ap))  # ascending
    b = np.linalg.eigvalsh(_sym(Bp))
    # lengths should already match (N), but keep robust:
    if a.shape[0] < b.shape[0]:
        a = np.pad(a, (0, b.shape[0] - a.shape[0]), constant_values=float(efloor))
    elif b.shape[0] < a.shape[0]:
        b = np.pad(b, (0, a.shape[0] - b.shape[0]), constant_values=float(efloor))

    num = np.linalg.norm(a - b, ord=2)
    den = max(np.linalg.norm(a, ord=2), float(efloor))
    return float(num / den), "ok"
