\
#!/usr/bin/env python3
"""
Pre-commit / CI hook: forbid direct reductions in aggregation code paths.

This is a conservative scanner; you can extend allowlists as needed.

Forbidden patterns (by default):
- "np.sum(" or "numpy.sum("
- "sum(" when not obviously in tests or in allowed modules

This hook is intended to enforce the policy: use numeric.summation.sum_kahan_lex for aggregations.
"""

from __future__ import annotations
import sys, re, pathlib

FORBID = [
    re.compile(r"\bnp\.sum\s*\("),
    re.compile(r"\bnumpy\.sum\s*\("),
]

# For plain sum(), we avoid flagging "sum_kahan_lex(" etc. by requiring whitespace or '(' right after.
FORBID_SUM = re.compile(r"(?<!kahan_lex)\bsum\s*\(")

ALLOW_DIRS = {"tests"}  # allow direct sums in tests, if needed
ALLOW_FILES = set()     # add specific allowlisted files here

def main() -> int:
    root = pathlib.Path(".")
    py_files = [p for p in root.rglob("*.py") if ".venv" not in str(p)]
    bad = []
    for p in py_files:
        rel = p.as_posix()
        if p.name in ALLOW_FILES:
            continue
        if any(part in ALLOW_DIRS for part in p.parts):
            continue
        txt = p.read_text(encoding="utf-8", errors="ignore")
        for rx in FORBID:
            if rx.search(txt):
                bad.append((rel, rx.pattern))
        if FORBID_SUM.search(txt):
            bad.append((rel, "sum("))
    if bad:
        print("Forbidden reductions found. Use numeric.summation.sum_kahan_lex for aggregations.")
        for f, pat in bad:
            print(f" - {f}: {pat}")
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
