\
#!/usr/bin/env python3
"""
CI check: forbid iterative solvers / sparse iterative routines.
This enforces the policy: only deterministic direct solves in spec code paths.
"""

from __future__ import annotations
import sys, re, pathlib

FORBID = [
    re.compile(r"\bscipy\.sparse\.linalg\.(cg|bicg|bicgstab|gmres|lgmres|minres|qmr|lsqr|lsmr)\b"),
    re.compile(r"\bfrom\s+scipy\.sparse\.linalg\s+import\s+.*\b(cg|gmres|bicg|lsqr|lsmr)\b"),
    re.compile(r"\b(cg|gmres|bicgstab|lsqr|lsmr)\s*\("),
]

ALLOW_DIRS = {"tests"}  # allow in tests if you ever need to demonstrate; default keeps it simple

def main() -> int:
    root = pathlib.Path(".")
    py_files = [p for p in root.rglob("*.py") if ".venv" not in str(p)]
    bad = []
    for p in py_files:
        if any(part in ALLOW_DIRS for part in p.parts):
            continue
        txt = p.read_text(encoding="utf-8", errors="ignore")
        for rx in FORBID:
            if rx.search(txt):
                bad.append((p.as_posix(), rx.pattern))
    if bad:
        print("Forbidden iterative solver usage found (policy forbids iterative solvers).")
        for f, pat in bad:
            print(f" - {f}: {pat}")
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
