"""
numeric.policy
Load numerical_policy.yaml and compute a deterministic policy hash.

Hashing rule:
- YAML is loaded into a dict, then serialized to canonical JSON (sorted keys),
  then SHA256 is computed over UTF-8 bytes.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Tuple
import json, hashlib
import yaml

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def policy_hash(policy: Dict[str, Any]) -> str:
    h = hashlib.sha256()
    h.update(canonical_json_bytes(policy))
    return h.hexdigest()

def load_policy(path: str) -> Tuple[Dict[str, Any], str]:
    with open(path, "r", encoding="utf-8") as f:
        policy = yaml.safe_load(f)
    return policy, policy_hash(policy)

def eps_floor(policy: Dict[str, Any]) -> float:
    import numpy as np
    mult = float(policy.get("float64", {}).get("eps_floor_multiplier", 1.0))
    return float(mult * (np.finfo(np.float64).eps ** 0.5))

def efloor(policy: Dict[str, Any]) -> float:
    import numpy as np
    mult = float(policy.get("Efloor_multiplier", 1.0))
    return float(mult * np.finfo(np.float64).eps)

def te_thresholds(policy: Dict[str, Any], target_scale: float) -> Tuple[float, float]:
    """
    Compute absolute and relative termination thresholds for energy constraint F(λ) using eps_floor.
    """
    epsf = eps_floor(policy)
    abs_mult = float(policy.get("TE_abs_multiplier", 100.0))
    rel_mult = float(policy.get("TE_rel_multiplier", 100.0))
    scale = max(1.0, float(abs(target_scale)))
    tau_abs = abs_mult * epsf * scale
    tau_rel = rel_mult * epsf * scale
    return float(tau_abs), float(tau_rel)
