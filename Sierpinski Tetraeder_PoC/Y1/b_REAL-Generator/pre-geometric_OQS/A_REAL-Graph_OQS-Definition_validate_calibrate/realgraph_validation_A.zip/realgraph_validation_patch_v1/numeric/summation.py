"""
numeric.summation
Deterministic summation primitives.

Central rule:
- All aggregations must use sum_kahan_lex(values, ids) with ids defining the canonical order.
- Direct sum()/np.sum() reductions in aggregation codepaths are forbidden (enforced by hooks/CI).
"""

from __future__ import annotations
from typing import Iterable, Sequence, Tuple, Any, List

def sum_kahan_lex(values: Iterable[float], ids: Iterable[Any]) -> float:
    """
    Deterministically sum values using:
      1) lexicographic (sorted) order of ids
      2) Kahan compensated summation in float64

    Parameters
    ----------
    values : iterable of float-like
    ids    : iterable of sortable keys (same length)

    Returns
    -------
    float : deterministic sum
    """
    pairs: List[Tuple[Any, float]] = sorted(zip(ids, values), key=lambda t: t[0])
    s = 0.0
    c = 0.0
    for _, x in pairs:
        y = float(x) - c
        t = s + y
        c = (t - s) - y
        s = t
    return float(s)
