"""
reporting.report
Standardized manifest/report objects + invalid event logging.

Key rule:
- Every invalid event must record: scope, id, reason, policy_hash, stack_fingerprint, test_id
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional
import datetime
import json
import uuid

def utc_now_iso() -> str:
    return datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()

@dataclass(frozen=True)
class InvalidEvent:
    scope: str          # e.g. "cell", "edge", "global"
    object_id: str      # canonical id
    reason: str         # deterministic reason code
    test_id: str
    policy_hash: str
    stack_fingerprint: Dict[str, Any]
    when_utc: str

@dataclass
class TestResult:
    test_id: str
    status: str         # PASS/FAIL/WARN/SKIP
    details: str
    residues: Dict[str, float]
    artifacts: List[str]

@dataclass
class ValidationReport:
    spec_sha256: str
    run_id: str
    numerical_policy_hash: str
    timestamp: str
    results: List[TestResult]
    invalid_flags: List[str]
    invalid_events: List[InvalidEvent]
    residuals: Dict[str, float]
    diagnostics: Dict[str, Any]
    artifacts: List[str]
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "spec_sha256": self.spec_sha256,
            "run_id": self.run_id,
            "numerical_policy_hash": self.numerical_policy_hash,
            "timestamp": self.timestamp,
            "results": [asdict(r) for r in self.results],
            "invalid_flags": list(self.invalid_flags),
            "invalid_events": [asdict(e) for e in self.invalid_events],
            "residuals": dict(self.residuals),
            "diagnostics": self.diagnostics,
            "artifacts": list(self.artifacts),
            "notes": self.notes,
        }

def new_run_id() -> str:
    return uuid.uuid4().hex

def make_invalid_event(
    *,
    scope: str,
    object_id: str,
    reason: str,
    test_id: str,
    policy_hash: str,
    stack_fingerprint: Dict[str, Any],
) -> InvalidEvent:
    return InvalidEvent(
        scope=scope,
        object_id=object_id,
        reason=reason,
        test_id=test_id,
        policy_hash=policy_hash,
        stack_fingerprint=stack_fingerprint,
        when_utc=utc_now_iso(),
    )
