# realgraph_validation_patch_v1

This ZIP contains the **code artifacts** requested for enforcing determinism and schema validation:

- `numeric/summation.py::sum_kahan_lex` (Kahan + lex order)
- `numerical_policy.yaml` (versioned numeric defaults + determinism policy)
- Deterministic LA wrappers: `linalg/wrappers.py::{det_cholesky, det_solve_spd}`
- Deterministic λ-bracketing+bisection: `real/lambda_search.py::lambda_bracket_bisect`
- Mismatch(2)/(3) conventions: `mismatch/mismatch.py`
- Schemas: `schemas/*.schema.json`
- Hooks/CI scanners:
  - `scripts/forbid_reductions.py`
  - `scripts/check_no_iterative_solvers.py`
  - `.pre-commit-config.yaml`
  - `.github/workflows/ci.yml`
- Tests: `tests/*` (pytest + jsonschema validation)

## Local quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/forbid_reductions.py
python scripts/check_no_iterative_solvers.py
pytest -q
```
