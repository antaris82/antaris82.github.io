"""
linalg.wrappers
Deterministic linear-algebra wrappers with explicit failure semantics.

- det_cholesky(A) -> (success, L, reason)
- det_solve_spd(A, b) -> (x, reason)

Policy:
- Iterative solvers are forbidden. Only direct SPD solve paths are allowed here.
"""

from __future__ import annotations
from typing import Tuple, Optional
import numpy as np

def _exc_reason(prefix: str, e: Exception) -> str:
    return f"{prefix}:{type(e).__name__}"

def det_cholesky(A: np.ndarray) -> Tuple[bool, Optional[np.ndarray], str]:
    """
    Attempt Cholesky factorization of A (assumed symmetric).
    Returns:
      success: bool
      L: lower-triangular factor (if success)
      reason: "ok" or deterministic failure code
    """
    try:
        # numpy.linalg.cholesky is deterministic for fixed toolchain/threads
        L = np.linalg.cholesky(A)
        return True, L, "ok"
    except np.linalg.LinAlgError as e:
        return False, None, _exc_reason("chol_fail", e)
    except Exception as e:
        return False, None, _exc_reason("chol_fail", e)

def det_solve_spd(A: np.ndarray, b: np.ndarray) -> Tuple[Optional[np.ndarray], str]:
    """
    Solve (A x = b) for SPD A using Cholesky, returning deterministic invalid_reason on failure.
    """
    ok, L, reason = det_cholesky(A)
    if not ok:
        return None, reason

    try:
        # Prefer scipy cho_solve if available; fall back to explicit triangular solves.
        try:
            import scipy.linalg as sla
            x = sla.cho_solve((L, True), b, check_finite=False)
            return np.asarray(x), "ok"
        except Exception:
            # Fallback: two triangular solves using numpy
            y = np.linalg.solve(L, b)
            x = np.linalg.solve(L.T, y)
            return np.asarray(x), "ok"
    except np.linalg.LinAlgError as e:
        return None, _exc_reason("solve_fail", e)
    except Exception as e:
        return None, _exc_reason("solve_fail", e)
