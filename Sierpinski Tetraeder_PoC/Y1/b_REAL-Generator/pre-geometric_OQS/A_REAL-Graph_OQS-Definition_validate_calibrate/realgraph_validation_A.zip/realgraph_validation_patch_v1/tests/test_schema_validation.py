import json
from jsonschema import validate

def test_schemas_validate_examples():
    with open("schemas/run_manifest.schema.json","r",encoding="utf-8") as f:
        run_schema = json.load(f)
    with open("schemas/validation_report.schema.json","r",encoding="utf-8") as f:
        rep_schema = json.load(f)

    with open("tests/fixtures/run_manifest.example.json","r",encoding="utf-8") as f:
        run = json.load(f)
    with open("tests/fixtures/validation_report.example.json","r",encoding="utf-8") as f:
        rep = json.load(f)

    validate(instance=run, schema=run_schema)
    validate(instance=rep, schema=rep_schema)
