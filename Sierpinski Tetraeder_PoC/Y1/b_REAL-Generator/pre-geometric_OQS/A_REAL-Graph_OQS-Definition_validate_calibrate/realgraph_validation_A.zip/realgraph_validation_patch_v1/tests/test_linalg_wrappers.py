import numpy as np
from linalg.wrappers import det_cholesky, det_solve_spd

def test_det_cholesky_ok():
    A = np.array([[2.0, 0.0],[0.0, 3.0]])
    ok, L, reason = det_cholesky(A)
    assert ok is True
    assert reason == "ok"
    assert L.shape == (2,2)

def test_det_cholesky_fail_reason():
    A = np.array([[0.0, 0.0],[0.0, -1.0]])  # not SPD
    ok, L, reason = det_cholesky(A)
    assert ok is False
    assert L is None
    assert reason.startswith("chol_fail:")

def test_det_solve_spd_ok():
    A = np.array([[4.0, 1.0],[1.0, 3.0]])
    b = np.array([1.0, 2.0])
    x, reason = det_solve_spd(A, b)
    assert reason == "ok"
    assert np.allclose(A @ x, b)

def test_det_solve_spd_fail():
    A = np.array([[0.0, 1.0],[1.0, 0.0]])  # indefinite
    b = np.array([1.0, 2.0])
    x, reason = det_solve_spd(A, b)
    assert x is None
    assert reason.startswith("chol_fail:")
