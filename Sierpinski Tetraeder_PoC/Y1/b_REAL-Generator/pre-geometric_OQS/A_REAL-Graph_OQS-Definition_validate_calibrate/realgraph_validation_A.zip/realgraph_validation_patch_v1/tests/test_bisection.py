from real.lambda_search import lambda_bracket_bisect

def test_ok_at_zero():
    policy = {"lambda_search":{"h0":0.1,"gamma":2.0,"Nexpand":5,"Nbisect":10},
              "TE_abs_multiplier":1.0,"TE_rel_multiplier":1.0,"float64":{"eps_floor_multiplier":1.0}}
    F = lambda x: 0.0
    lam, reason = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=1e-12, tau_rel=1e-12)
    assert lam == 0.0
    assert reason == "ok_at_zero"

def test_ok_root_found():
    policy = {"lambda_search":{"h0":0.1,"gamma":2.0,"Nexpand":10,"Nbisect":64},
              "TE_abs_multiplier":1.0,"TE_rel_multiplier":1.0,"float64":{"eps_floor_multiplier":1.0}}
    F = lambda x: x - 0.25
    lam, reason = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=1e-15, tau_rel=1e-15)
    assert reason == "ok"
    assert abs(lam - 0.25) < 1e-12

def test_no_bracket():
    policy = {"lambda_search":{"h0":0.1,"gamma":2.0,"Nexpand":5,"Nbisect":10},
              "TE_abs_multiplier":1.0,"TE_rel_multiplier":1.0,"float64":{"eps_floor_multiplier":1.0}}
    F = lambda x: 1.0
    lam, reason = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=1e-15, tau_rel=1e-15)
    assert lam == 0.0
    assert reason == "no_bracket"

def test_budget_hit():
    policy = {"lambda_search":{"h0":0.1,"gamma":2.0,"Nexpand":10,"Nbisect":1},
              "TE_abs_multiplier":1.0,"TE_rel_multiplier":1.0,"float64":{"eps_floor_multiplier":1.0}}
    F = lambda x: x - 1.0
    lam, reason = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=0.0, tau_rel=0.0)
    assert lam == 0.0
    assert reason == "budget_hit"

def test_determinism_repeatability():
    policy = {"lambda_search":{"h0":0.1,"gamma":2.0,"Nexpand":10,"Nbisect":64},
              "TE_abs_multiplier":1.0,"TE_rel_multiplier":1.0,"float64":{"eps_floor_multiplier":1.0}}
    F = lambda x: x - 0.25
    lam1, reason1 = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=1e-15, tau_rel=1e-15)
    lam2, reason2 = lambda_bracket_bisect(F, policy, target_scale=1.0, tau_abs=1e-15, tau_rel=1e-15)
    assert reason1 == reason2 == "ok"
    assert lam1 == lam2
