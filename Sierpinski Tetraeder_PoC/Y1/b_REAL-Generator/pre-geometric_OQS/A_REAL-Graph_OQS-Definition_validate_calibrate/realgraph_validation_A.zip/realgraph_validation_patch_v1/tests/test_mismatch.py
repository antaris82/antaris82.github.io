import numpy as np
from mismatch.mismatch import mismatch2_fro, mismatch3_eigs

def test_mismatch2_ok_and_padding():
    A = np.eye(2)
    B = np.eye(3)
    m, reason = mismatch2_fro(A, B, efloor=1e-12)
    assert reason == "ok"
    assert m >= 0.0

def test_mismatch3_ok_and_sorted():
    A = np.array([[2.0, 0.1],[0.1, 1.0]])
    B = np.array([[2.0, 0.0],[0.0, 1.0]])
    m, reason = mismatch3_eigs(A, B, efloor=1e-12)
    assert reason == "ok"
    assert m >= 0.0

def test_disconnected_na():
    A = np.array([[np.inf, 0.0],[0.0, 1.0]])
    B = np.eye(2)
    m, reason = mismatch2_fro(A, B, efloor=1e-12)
    assert reason == "na_disconnected"
    assert np.isnan(m)
