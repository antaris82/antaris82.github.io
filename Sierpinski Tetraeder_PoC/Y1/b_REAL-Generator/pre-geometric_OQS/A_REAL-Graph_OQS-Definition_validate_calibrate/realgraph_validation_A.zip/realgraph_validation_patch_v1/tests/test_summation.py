import numpy as np
from numeric.summation import sum_kahan_lex

def test_sum_kahan_lex_is_order_invariant_for_same_ids():
    ids = [3,1,2,0]
    vals = [1e16, 1.0, -1e16, 2.0]
    # shuffle input order but keep ids with their values
    s1 = sum_kahan_lex(vals, ids)
    s2 = sum_kahan_lex(list(reversed(vals)), list(reversed(ids)))
    assert s1 == s2

def test_sum_kahan_lex_matches_reference_for_simple_case():
    ids = ["b","a","c"]
    vals = [1.0, 2.0, 3.0]
    assert sum_kahan_lex(vals, ids) == 6.0
