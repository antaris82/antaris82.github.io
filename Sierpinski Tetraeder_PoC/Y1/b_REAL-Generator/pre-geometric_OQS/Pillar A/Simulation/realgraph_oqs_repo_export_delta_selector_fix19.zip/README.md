# REAL-Graph OQS — stages 1–5 (SG-only)

This repository implements the deterministic machinery specified in `REAL-Graph_OQS-Definition_v4_rev8` for **SG only**.

## Defaults (as requested)
- Graph: SG only
- `L_max = 3`
- `N = 20`
- `d_p = 1`
- Trajectories mode: **enabled by default**

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
realgraph-oqs-run --out runs/demo
```

Artifacts will be written to the output directory:
- `run_report.json` — full audit trail including gates (`cond_fail`, `lambda_budget`, etc.)
- `edges.csv` — canonical edge list and final conductances
- `conductances.npy` — time series (N+1, |E|)

## Spec + traceability
The repository includes the exact spec sources and symbol tables under `spec/`.

## Determinism
Determinism is enforced by:
- canonical vertex/edge ordering
- explicit float64 policy constants
- deterministic `RegSPD`, `Solve`, `expmDet`, `logDet` policies
- explicit tie-safe `Sel` selection (trajectories mode)

See `docs/gate_logic.md` for the structured gate semantics.
