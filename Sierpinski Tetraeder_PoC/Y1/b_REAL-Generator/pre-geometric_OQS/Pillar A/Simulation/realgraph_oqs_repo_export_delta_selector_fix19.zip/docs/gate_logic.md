# Gate logic (v4_rev8) — deterministic reporting

This document describes the **explicit gates** recorded in `run_report.json`.

## RegSPD gate
`RegSPD(A)` returns `(M, regspd_report)` where:

- `m_chol`: smallest escalation level `m` with `CholOK(Sym(A)+β_reg^m δ0(A) I)=1` (else deterministic fallback to `M_reg`).
- `m_used`: smallest `m >= m_chol` with `κ̂(M) <= κ_max`, else `M_reg`.
- `kappa_hat`: Gershgorin proxy `λ̂_max/λ̂_min` (with `λ̂_min = max(G_min, eps_floor)`).
- `cond_fail`: **separate field** indicating `kappa_hat > kappa_max` after escalation.

This is **not** encoded as `valid=0`; it is a separate gate.

## Solve gate
`Solve(A,B)` returns `(X, solve_report)`:

- If `A` is exactly symmetric and Cholesky succeeds, use the Cholesky path.
- Otherwise use deterministic LU with partial pivoting and tie-breaking (`argmax` selects first occurrence).
- `ok=False` indicates a deterministic failure (e.g. zero pivot / NaNs).

## DtN (Kron) gate
`DtN` reduction uses:
- `RegSPD` on the interior block (`L_II` or `Q_II`)
- then `Solve(RegSPD(Q_II), Q_IB)`

Recorded fields:
- `valid`: false iff the solve fails.
- `cond_fail`: propagated from `RegSPD.cond_fail`.

## Soft fallback gate (κ)
For each non-corner cell `w`:

- `κ_raw(n,w) = min(1, E_{n,w} / max(eps_floor, E_{n,∅}))`
- `κ(n,w) = 1` if `κ_raw <= κ_raw_thr`,
  else `κ(n,w) = 1 - η_soft * (κ_raw - κ_raw_thr)/(1-κ_raw_thr)`.

A cell counts as **soft fallback** if `κ_raw > κ_raw_thr` and it is not in hard fallback.

## Hard fallback gate
A cell counts as **hard fallback** if any required linear solve in that cell fails:
- DtN local/global solve failure, or
- harmonic extension solve failure for any action `(i,j)`.

## Lambda budget gate
`λ_n` is found by:
1. bracketing (`N_expand`) with symmetric expansion `±h0 γ^k`
2. bisection (`N_bisect`)

If bracketing fails or evaluations are invalid, `λ_n=0` and `budget_exhausted=true`.

## Step validity gate
A step `n` is marked `valid_run` iff:
- `p_invalid(n) <= p_fb,hard,max`
- `p_fb_soft(n) <= p_fb,max`
- `p_mreg(n) <= p_mreg,max`

If `valid_run=false`, then the update is frozen (`Δ_n(e)=0`) and only the lambda normalization step is applied (with `λ_n=0` if budget exhausted).
