import math
import numpy as np

from realgraph_oqs.driver.kappa import kappa_from_mismatch
from realgraph_oqs.policy.constants import Policy
from realgraph_oqs.ideal.sg_trunk import build_sg_trunk
from realgraph_oqs.driver.lcp_measure import compute_lcp_measure
from realgraph_oqs.driver.cell_sets import build_cell_sets
from realgraph_oqs.driver.runner import canonical_init_conductances, canonical_init_theta
from realgraph_oqs.driver.update import step_update


def test_kappa_mapping_no_fallback():
    pol = Policy()
    mismatch = 0.02
    rep = kappa_from_mismatch(mismatch=mismatch, fallback=False, pol=pol)
    assert rep.fallback is False
    assert rep.hard_fallback is False
    assert rep.soft_fallback is False
    assert math.isclose(rep.kappa_raw, math.tanh(mismatch), rel_tol=0, abs_tol=1e-15)
    assert math.isclose(rep.kappa, rep.kappa_raw, rel_tol=0, abs_tol=1e-15)


def test_kappa_mapping_soft_fallback():
    pol = Policy()
    mismatch = 0.02  # tanh ~= 0.02 < kappa_raw_thr=0.1
    rep = kappa_from_mismatch(mismatch=mismatch, fallback=True, pol=pol)
    assert rep.fallback is True
    assert rep.hard_fallback is False
    assert rep.soft_fallback is True
    assert math.isclose(rep.kappa, pol.eta_soft * rep.kappa_raw, rel_tol=0, abs_tol=1e-15)


def test_kappa_mapping_hard_fallback():
    pol = Policy()
    mismatch = 0.2  # tanh ~= 0.197 >= 0.1
    rep = kappa_from_mismatch(mismatch=mismatch, fallback=True, pol=pol)
    assert rep.fallback is True
    assert rep.hard_fallback is True
    assert rep.soft_fallback is False
    assert abs(rep.kappa_raw) >= pol.kappa_raw_thr
    assert math.isclose(rep.kappa, pol.eta_soft * rep.kappa_raw, rel_tol=0, abs_tol=1e-15)


def test_step_update_is_not_frozen_by_kappa_soft_flag():
    pol = Policy()
    trunk = build_sg_trunk(L_max=3)
    lcp = compute_lcp_measure(trunk)
    cells = build_cell_sets(trunk, lcp)
    c0 = canonical_init_conductances(trunk, pol)
    theta0 = canonical_init_theta(trunk, lcp, cells, c0, pol)

    c1, theta1, rep = step_update(
        n=0,
        trunk=trunk,
        lcp=lcp,
        cells=cells,
        c_n=c0.copy(),
        theta_n=theta0,
        dp=1,
        trajectory=True,
        pol=pol,
    )
    # Under the spec-aligned κ mapping, the initial step must be valid and update must move
    assert rep.valid_run is True
    assert np.any(np.abs(c1 - c0) > 0.0)
