import numpy as np

from realgraph_oqs.ideal.sg_trunk import build_sg_trunk


def test_sg_trunk_counts():
    # Known counts for SG prefractal graph K_L_max:
    # nV = (3^{L_max+1}+3)/2, nE = 3^{L_max+1}
    for L in range(0, 5):
        trunk = build_sg_trunk(L)
        expected_v = (3 ** (L + 1) + 3) // 2
        expected_e = 3 ** (L + 1)
        assert trunk.nV == expected_v
        assert len(trunk.edges) == expected_e
        assert len(set(trunk.B0)) == 3


def test_sg_trunk_edges_are_sorted_unique():
    trunk = build_sg_trunk(3)
    edges = trunk.edges
    assert edges == sorted(edges)
    assert len(edges) == len(set(edges))
    for (u, v) in edges:
        assert u < v
        assert 0 <= u < trunk.nV
        assert 0 <= v < trunk.nV
