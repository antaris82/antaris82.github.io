import importlib
import json
from pathlib import Path

import pytest


def _sanitize(sym: str) -> str:
    s = sym.strip()
    if "(" in s:
        s = s.split("(", 1)[0]
    return s


def test_traceability_symbols_smoke():
    # Load the bundled traceability matrix
    tm_path = Path(__file__).resolve().parents[1] / "spec" / "symbols" / "traceability_matrix_rev6.json"
    data = json.loads(tm_path.read_text(encoding="utf-8"))
    rows = data["rows"]
    missing = []
    for r in rows:
        code = r["code"]
        file_rel, sym = code.split("::", 1)
        sym = _sanitize(sym)
        mod_name = "realgraph_oqs." + file_rel.replace("/", ".").replace(".py", "")
        try:
            mod = importlib.import_module(mod_name)
        except Exception as e:
            missing.append((mod_name, sym, f"import failed: {e}"))
            continue
        if not hasattr(mod, sym):
            missing.append((mod_name, sym, "attr missing"))
    assert not missing, "Missing traceability symbols: " + repr(missing[:20])
