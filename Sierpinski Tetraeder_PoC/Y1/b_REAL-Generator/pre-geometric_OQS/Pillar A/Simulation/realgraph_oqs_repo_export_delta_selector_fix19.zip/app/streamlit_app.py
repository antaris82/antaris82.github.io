"""Streamlit entrypoint (wrapper).

Start from repo root:
  streamlit run app/streamlit_app.py
"""

from realgraph_oqs.gui.streamlit_app import main

if __name__ == "__main__":
    main()
