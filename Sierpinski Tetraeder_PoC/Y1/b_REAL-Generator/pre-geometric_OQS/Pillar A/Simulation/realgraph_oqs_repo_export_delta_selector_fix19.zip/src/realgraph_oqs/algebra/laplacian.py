from __future__ import annotations

from typing import Iterable, Tuple
import numpy as np


def dirichlet_energy(edges: Iterable[Tuple[int, int]], c: np.ndarray, f: np.ndarray) -> float:
    """Compute Dirichlet energy E(f)=1/2 Σ_e c_e (f(u)-f(v))^2.

    Parameters
    ----------
    edges:
        Edge list in the same order as conductances `c`.
    c:
        Conductances array, shape (nE,).
    f:
        Node values, shape (nV,) or (nV,1).

    Returns
    -------
    float
        The Dirichlet energy as float64.
    """
    c = np.asarray(c, dtype=np.float64).reshape(-1)
    f = np.asarray(f, dtype=np.float64).reshape(-1)
    E = 0.0
    for k, (u, v) in enumerate(edges):
        du = float(f[int(u)] - f[int(v)])
        E += 0.5 * float(c[int(k)]) * du * du
    return float(E)


__all__ = ["dirichlet_energy"]
