from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Dict, Any

import numpy as np

from ..policy.constants import Policy
from ..numeric.regspd import RegSPD, RegSPDReport
from ..numeric.solve import Solve, SolveReport


@dataclass(frozen=True)
class CoarseDtNReport:
    valid: bool
    cond_fail: bool
    regspd: RegSPDReport
    solve: SolveReport
    trace: float


def coarse_dtn_kron(L: np.ndarray, B: Tuple[int, ...], pol: Policy) -> Tuple[np.ndarray, CoarseDtNReport]:
    """Coarse DtN/Kron reduction on boundary B (Schur complement), deterministic.

    Equivalent to the Kron reduction used in the core runner, provided as a
    traceable algebra unit.
    """
    L = np.asarray(L, dtype=np.float64)
    B = tuple(int(x) for x in B)
    n = L.shape[0]
    if L.shape[1] != n:
        raise ValueError("L must be square")
    I = tuple(i for i in range(n) if i not in set(B))
    # boundary-only
    if len(I) == 0:
        Lam = L[np.ix_(B, B)]
        Lam = 0.5 * (Lam + Lam.T)
        dummy_reg = RegSPDReport(0, 0, 0.0, 0.0, 0.0, 0.0, 1.0, True, False)
        dummy_sol = SolveReport(True, "chol", tuple(), 0.0)
        tr = float(np.trace(Lam))
        return Lam, CoarseDtNReport(True, False, dummy_reg, dummy_sol, tr)

    L_BB = L[np.ix_(B, B)]
    L_II = L[np.ix_(I, I)]
    L_BI = L[np.ix_(B, I)]
    L_IB = L[np.ix_(I, B)]

    Lreg, regrep = RegSPD(L_II, pol)
    X, solrep = Solve(Lreg, L_IB)
    if not solrep.ok:
        Lam = np.zeros_like(L_BB)
        tr = float(np.trace(Lam))
        return Lam, CoarseDtNReport(False, regrep.cond_fail, regrep, solrep, tr)

    Lam = L_BB - (L_BI @ X)
    Lam = 0.5 * (Lam + Lam.T)
    tr = float(np.trace(Lam))
    return Lam, CoarseDtNReport(True, regrep.cond_fail, regrep, solrep, tr)


def validate_dtn_continuity(L_prev: np.ndarray, L_next: np.ndarray, B: Tuple[int, ...], pol: Policy) -> Dict[str, Any]:
    """Continuity diagnostic for DtN seeds between two Laplacians.

    Returns a dict with norm-based deltas and the gate status.
    """
    Lam0, rep0 = coarse_dtn_kron(L_prev, B=B, pol=pol)
    Lam1, rep1 = coarse_dtn_kron(L_next, B=B, pol=pol)
    denom = float(np.linalg.norm(Lam0, ord="fro"))
    num = float(np.linalg.norm(Lam1 - Lam0, ord="fro"))
    rel = float(num / max(pol.eps_floor, denom))
    return {
        "valid": bool(rep0.valid and rep1.valid),
        "cond_fail": bool(rep0.cond_fail or rep1.cond_fail),
        "delta_fro": num,
        "delta_rel": rel,
        "trace0": float(rep0.trace),
        "trace1": float(rep1.trace),
    }


def boundary_nonlocality_report(Lam: np.ndarray, pol: Policy) -> Dict[str, Any]:
    """Report a simple 'nonlocality' proxy on the boundary operator.

    This is reported as a *remark* only; it must not be interpreted as a claim.
    The proxy is the fraction of off-diagonal mass relative to total mass.
    """
    Lam = np.asarray(Lam, dtype=np.float64)
    off = Lam - np.diag(np.diag(Lam))
    mass_off = float(np.sum(np.abs(off)))
    mass_tot = float(np.sum(np.abs(Lam)))
    frac = float(mass_off / max(pol.eps_floor, mass_tot))
    return {"offdiag_mass": mass_off, "total_mass": mass_tot, "offdiag_frac": frac}


__all__ = ["coarse_dtn_kron", "validate_dtn_continuity", "boundary_nonlocality_report", "CoarseDtNReport"]
