from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class PerfGuards:
    """Simple performance guardrails for deterministic runs."""
    max_nV: int = 5000
    max_nE: int = 20000
    max_steps: int = 500

    def check(self, nV: int, nE: int, N: int) -> None:
        if nV > self.max_nV:
            raise ValueError(f"nV={nV} exceeds max_nV={self.max_nV}")
        if nE > self.max_nE:
            raise ValueError(f"nE={nE} exceeds max_nE={self.max_nE}")
        if N > self.max_steps:
            raise ValueError(f"N={N} exceeds max_steps={self.max_steps}")


__all__ = ["PerfGuards"]
