from __future__ import annotations

from typing import Tuple
import numpy as np


def partial_trace_ordered(rho: np.ndarray, dims: Tuple[int, int], trace_over: str = "B") -> np.ndarray:
    """Partial trace for a bipartite tensor space with explicit ordering.

    Parameters
    ----------
    rho:
        Density matrix of shape (dA*dB, dA*dB).
    dims:
        (dA, dB)
    trace_over:
        "A" or "B"

    Returns
    -------
    Reduced density matrix with ordering preserved.
    """
    rho = np.asarray(rho, dtype=np.complex128)
    dA, dB = (int(dims[0]), int(dims[1]))
    if rho.shape != (dA*dB, dA*dB):
        raise ValueError("rho shape incompatible with dims")
    R = rho.reshape(dA, dB, dA, dB)
    if trace_over.upper() == "B":
        # trace over B indices 1 and 3
        out = np.einsum("a b c b -> a c", R)
        return out
    if trace_over.upper() == "A":
        out = np.einsum("a b a d -> b d", R)
        return out
    raise ValueError("trace_over must be 'A' or 'B'")


__all__ = ["partial_trace_ordered"]
