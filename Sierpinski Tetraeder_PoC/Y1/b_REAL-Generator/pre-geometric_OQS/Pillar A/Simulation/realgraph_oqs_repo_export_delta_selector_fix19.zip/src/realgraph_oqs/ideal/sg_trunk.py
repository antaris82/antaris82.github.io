from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from .structures import TrunkGraph, Word, RawVertex, Edge


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1


def _all_words(L: int) -> List[Word]:
    if L == 0:
        return [tuple()]
    words = [tuple()]
    for _ in range(L):
        words = [w + (a,) for w in words for a in (0, 1, 2)]
    return words


def build_sg_trunk(L_max: int) -> TrunkGraph:
    """Build SG trunk K_{L_max} exactly as in Def. (quotient via constant-tail relation).

    Vertices are equivalence classes of raw labels (w,i) with w in {0,1,2}^{L_max}, i in {0,1,2}.
    Edges are induced by all L_max-cells: for each w, connect (w,0)-(w,1)-(w,2)-(w,0).
    """
    assert L_max >= 0
    S = (0, 1, 2)

    words_L = _all_words(L_max)
    raw_list: List[RawVertex] = [(w, i) for w in words_L for i in S]
    raw_index: Dict[RawVertex, int] = {rv: k for k, rv in enumerate(raw_list)}

    uf = UnionFind(len(raw_list))

    # Constant-tail equivalence relation (generated unions)
    # For each r in 0..L_max-1, each prefix u of length r, and i!=j:
    # (u i j^{L-r-1}, j) ~ (u j i^{L-r-1}, i)
    for r in range(0, L_max):
        prefixes = _all_words(r)
        tail_len = L_max - r - 1
        for u in prefixes:
            for i in S:
                for j in S:
                    if i == j:
                        continue
                    wi = u + (i,) + (j,) * tail_len
                    wj = u + (j,) + (i,) * tail_len
                    a = raw_index[(wi, j)]
                    b = raw_index[(wj, i)]
                    uf.union(a, b)

    # Collect classes
    classes: Dict[int, List[int]] = {}
    for idx in range(len(raw_list)):
        root = uf.find(idx)
        classes.setdefault(root, []).append(idx)

    # Canonical representative = lexicographically minimal (word tuple, i)
    reps: List[RawVertex] = []
    rep_full: List[List[RawVertex]] = []
    for root_id, members in classes.items():
        raw_members = [raw_list[m] for m in members]
        raw_members_sorted = sorted(raw_members, key=lambda rv: (rv[0], rv[1]))
        reps.append(raw_members_sorted[0])
        rep_full.append(raw_members_sorted)

    # Canonical vertex ordering: sort by representative
    order = sorted(range(len(reps)), key=lambda t: (reps[t][0], reps[t][1]))
    reps = [reps[i] for i in order]
    rep_full = [rep_full[i] for i in order]

    # Map raw -> quotient id
    raw_to_q: Dict[int, int] = {}
    for qid, members in enumerate(rep_full):
        for rv in members:
            raw_to_q[raw_index[rv]] = qid

    nV = len(reps)

    # A_words per quotient vertex
    A_words: List[List[Word]] = []
    for members in rep_full:
        ws = sorted({rv[0] for rv in members})
        A_words.append(ws)

    # Build Bw for all k<=L_max (including empty word)
    Bw: Dict[Word, Tuple[int, int, int]] = {}
    for k in range(0, L_max + 1):
        for w in _all_words(k):
            b = []
            for i in S:
                ext = w + (i,) * (L_max - k)
                qid = raw_to_q[raw_index[(ext, i)]]
                b.append(qid)
            Bw[w] = (b[0], b[1], b[2])

    B0 = Bw[tuple()]

    # Build edges from all L_max-cells
    edges_set = set()
    for w in words_L:
        vs = [raw_to_q[raw_index[(w, i)]] for i in S]
        for a in range(3):
            for b in range(a + 1, 3):
                u, v = vs[a], vs[b]
                if u == v:
                    continue
                if u > v:
                    u, v = v, u
                edges_set.add((u, v))
    edges = sorted(edges_set)

    return TrunkGraph(
        L_max=L_max,
        nV=nV,
        rep=reps,
        rep_full=rep_full,
        A_words=A_words,
        edges=edges,
        B0=B0,
        Bw=Bw,
    )
