from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..policy.constants import Policy


@dataclass(frozen=True)
class KappaReport:
    """Kappa mapping and fallback classification (v4_rev8).

    Definition alignment:
      - κ_raw := σ(Mismatch) with σ = tanh (policy-fixed)
      - fallback flag f := 1 iff local OR global DtN solve is invalid
      - κ := κ_raw                if f = 0
             η_soft * κ_raw       if f = 1
      - Hard/Soft fallback classification applies only when f = 1:
           f_hard := 1[f=1 and |κ_raw| ≥ κ_raw_thr]
           f_soft := 1[f=1] - f_hard
    """
    kappa_raw: float
    kappa: float
    fallback: bool
    hard_fallback: bool
    soft_fallback: bool


def sigma_tanh(x: float) -> float:
    """σ(x) := tanh(x)."""
    return float(np.tanh(float(x)))


def kappa_from_mismatch(mismatch: float, fallback: bool, pol: Policy) -> KappaReport:
    k_raw = sigma_tanh(mismatch)
    if fallback:
        k = float(pol.eta_soft) * k_raw
    else:
        k = k_raw

    hard = bool(fallback and (abs(k_raw) >= float(pol.kappa_raw_thr)))
    soft = bool(fallback and (not hard))
    return KappaReport(
        kappa_raw=float(k_raw),
        kappa=float(k),
        fallback=bool(fallback),
        hard_fallback=hard,
        soft_fallback=soft,
    )
