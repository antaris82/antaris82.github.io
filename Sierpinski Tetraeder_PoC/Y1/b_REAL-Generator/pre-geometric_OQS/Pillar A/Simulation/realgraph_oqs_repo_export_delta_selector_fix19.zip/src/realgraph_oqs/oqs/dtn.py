from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Optional

import numpy as np

from realgraph_oqs.numeric.regspd import RegSPD, RegSPDReport
from realgraph_oqs.numeric.solve import Solve, SolveReport
from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class DtNReport:
    valid: bool
    cond_fail: bool
    regspd: RegSPDReport
    solve: SolveReport
    trace: float


def _submatrix(M: np.ndarray, idx: Tuple[int, ...]) -> np.ndarray:
    return M[np.ix_(idx, idx)]


def dtn_kron(L: np.ndarray, B: Tuple[int, ...], pol: Policy) -> Tuple[np.ndarray, DtNReport]:
    """Global DtN on boundary B via Kron reduction."""
    n = L.shape[0]
    B = tuple(int(b) for b in B)
    I = tuple(i for i in range(n) if i not in set(B))

    if len(I) == 0:
        Lam = _submatrix(L, B)
        tr = float(np.trace(Lam))
        dummy_reg = RegSPDReport(0,0,0.0,0.0,0.0,0.0,0.0,True,False)
        dummy_sol = SolveReport(True, "chol", tuple(), 0.0)
        return Lam, DtNReport(True, False, dummy_reg, dummy_sol, tr)

    L_BB = _submatrix(L, B)
    L_II = _submatrix(L, I)
    L_BI = L[np.ix_(B, I)]
    L_IB = L[np.ix_(I, B)]

    Lreg, regrep = RegSPD(L_II, pol)
    X, solrep = Solve(Lreg, L_IB)
    if not solrep.ok:
        Lam = np.zeros_like(L_BB)
        tr = float(np.trace(Lam))
        return Lam, DtNReport(False, regrep.cond_fail, regrep, solrep, tr)
    Lam = L_BB - (L_BI @ X)
    Lam = 0.5 * (Lam + Lam.T)  # enforce symmetry
    tr = float(np.trace(Lam))
    return Lam, DtNReport(True, regrep.cond_fail, regrep, solrep, tr)


def dtn_local(L: np.ndarray, Vw: Tuple[int, ...], Bw: Tuple[int, ...], Iw: Tuple[int, ...], pol: Policy) -> Tuple[np.ndarray, DtNReport]:
    """Local DtN within Vw: principal submatrix Q=L[Vw,Vw] then Kron on Bw vs Iw."""
    Vw = tuple(int(x) for x in Vw)
    Bw = tuple(int(x) for x in Bw)
    Iw = tuple(int(x) for x in Iw)

    Q = _submatrix(L, Vw)

    # positions within Vw
    pos = {v: i for i, v in enumerate(Vw)}
    Bpos = tuple(pos[b] for b in Bw)
    Ipos = tuple(pos[i] for i in Iw)

    Q_BB = Q[np.ix_(Bpos, Bpos)]

    if len(Ipos) == 0:
        Lam = 0.5 * (Q_BB + Q_BB.T)
        tr = float(np.trace(Lam))
        dummy_reg = RegSPDReport(0,0,0.0,0.0,0.0,0.0,0.0,True,False)
        dummy_sol = SolveReport(True, "chol", tuple(), 0.0)
        return Lam, DtNReport(True, False, dummy_reg, dummy_sol, tr)

    Q_II = Q[np.ix_(Ipos, Ipos)]
    Q_BI = Q[np.ix_(Bpos, Ipos)]
    Q_IB = Q[np.ix_(Ipos, Bpos)]

    Qreg, regrep = RegSPD(Q_II, pol)
    X, solrep = Solve(Qreg, Q_IB)
    if not solrep.ok:
        Lam = np.zeros_like(Q_BB)
        tr = float(np.trace(Lam))
        return Lam, DtNReport(False, regrep.cond_fail, regrep, solrep, tr)

    Lam = Q_BB - (Q_BI @ X)
    Lam = 0.5 * (Lam + Lam.T)
    tr = float(np.trace(Lam))
    return Lam, DtNReport(True, regrep.cond_fail, regrep, solrep, tr)


def normalize_Lambda(Lam: np.ndarray, pol: Policy) -> np.ndarray:
    tr = float(np.trace(Lam))
    denom = max(pol.eps_floor, tr)
    return Lam / denom
