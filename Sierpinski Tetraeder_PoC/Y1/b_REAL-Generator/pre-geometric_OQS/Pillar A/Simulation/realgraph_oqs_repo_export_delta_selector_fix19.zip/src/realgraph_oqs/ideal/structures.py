from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

import numpy as np


Word = Tuple[int, ...]  # sequence over {0,1,2}
RawVertex = Tuple[Word, int]  # (word length L_max, corner index i)
Edge = Tuple[int, int]  # (u,v) with u < v


@dataclass(frozen=True)
class TrunkGraph:
    L_max: int
    # Canonical quotient vertices: ids 0..nV-1
    nV: int
    # Canonical representatives of each quotient vertex (lex-min raw vertex)
    rep: List[RawVertex]
    # Full Rep(x): list of raw vertices in equivalence class for each quotient vertex id
    rep_full: List[List[RawVertex]]
    # Set A_x (words only) for each vertex
    A_words: List[List[Word]]
    # Canonical edge list (u<v), sorted lex
    edges: List[Edge]
    # B0 vertex ids in patch-1 order (i=0,1,2)
    B0: Tuple[int, int, int]
    # Map from cell word w (length k<=L_max) to its boundary vertex ids (b_{w,0},b_{w,1},b_{w,2})
    Bw: Dict[Word, Tuple[int, int, int]]

    def laplacian_from_conductances(self, c: np.ndarray) -> np.ndarray:
        L = np.zeros((self.nV, self.nV), dtype=np.float64)
        for (idx, (u, v)) in enumerate(self.edges):
            w = float(c[idx])
            L[u, u] += w
            L[v, v] += w
            L[u, v] -= w
            L[v, u] -= w
        return L
