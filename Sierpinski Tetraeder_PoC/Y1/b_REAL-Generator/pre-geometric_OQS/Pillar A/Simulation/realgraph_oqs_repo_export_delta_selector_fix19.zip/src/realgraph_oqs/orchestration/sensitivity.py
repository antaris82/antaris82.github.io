from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

import numpy as np

from ..policy.constants import Policy
from ..ideal.trunk import build_trunk_sg
from ..driver.runner import run_simulation
from ..orchestration.hashing import graph_hash


@dataclass(frozen=True)
class SensitivitySuiteResult:
    passed: bool
    details: Dict[str, Any]


def run_sensitivity_suite(pol: Policy, L_max: int = 3, N: int = 5, dp: int = 1) -> SensitivitySuiteResult:
    """Run a minimal determinism/sensitivity suite.

    This suite is intentionally light: it checks that two repeated builds of the
    same trunk + initial weights lead to the same graph hash.
    """
    trunk1 = build_trunk_sg(L_max=L_max)
    trunk2 = build_trunk_sg(L_max=L_max)
    # canonical initial conductances are inside runner; here we just hash structure
    h1 = graph_hash(trunk1, None)
    h2 = graph_hash(trunk2, None)
    passed = (h1 == h2)
    return SensitivitySuiteResult(passed=bool(passed), details={"hash1": h1, "hash2": h2})


__all__ = ["run_sensitivity_suite", "SensitivitySuiteResult"]
