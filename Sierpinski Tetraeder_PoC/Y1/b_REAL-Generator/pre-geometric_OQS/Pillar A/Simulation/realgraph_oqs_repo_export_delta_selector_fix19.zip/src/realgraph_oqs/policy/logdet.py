from __future__ import annotations

from typing import Tuple
import numpy as np

from .constants import Policy
from ..numeric.logdet import logDet, LogDetReport


def logdet_psd(A: np.ndarray, pol: Policy) -> Tuple[float, LogDetReport]:
    """Deterministic log-det for PSD/PD matrices (v4_rev8 wrapper)."""
    return logDet(A, pol)


__all__ = ["logdet_psd", "LogDetReport"]
