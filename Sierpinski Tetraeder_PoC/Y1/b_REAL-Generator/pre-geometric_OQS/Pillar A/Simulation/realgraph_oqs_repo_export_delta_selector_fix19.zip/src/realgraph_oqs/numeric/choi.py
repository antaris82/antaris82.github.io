from __future__ import annotations

import numpy as np


def vec_col_major(X: np.ndarray) -> np.ndarray:
    # column-stacking vec
    return np.asarray(X, dtype=np.complex128).reshape(-1, order="F")


def unvec_col_major(v: np.ndarray, d: int) -> np.ndarray:
    return np.asarray(v, dtype=np.complex128).reshape((d, d), order="F")


def choi_state_from_superop(Phi: np.ndarray, d: int) -> np.ndarray:
    """Compute normalized Choi state J(Φ) for a channel superoperator Phi (vec -> vec).

    Uses J = (1/d) Σ_{ij} Φ(E_ij) ⊗ E_ij.
    """
    Phi = np.asarray(Phi, dtype=np.complex128)
    J = np.zeros((d * d, d * d), dtype=np.complex128)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), dtype=np.complex128)
            Eij[i, j] = 1.0
            Y = unvec_col_major(Phi @ vec_col_major(Eij), d)
            J += np.kron(Y, Eij)
    J /= float(d)
    # Hermitize numerically
    J = 0.5 * (J + J.conj().T)
    # Normalize trace to 1 (should already hold)
    tr = np.trace(J)
    if abs(tr) > 0:
        J = J / tr
    return J
