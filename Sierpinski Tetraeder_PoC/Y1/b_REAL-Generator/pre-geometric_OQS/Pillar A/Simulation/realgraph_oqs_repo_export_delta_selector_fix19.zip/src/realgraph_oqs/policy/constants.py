from __future__ import annotations

from dataclasses import dataclass, asdict
import numpy as np


@dataclass(frozen=True)
class Policy:
    """Numerical and model policy constants (SG-only) fixed by the v4_rev8 definition.

    Notes
    -----
    - All values are intended for IEEE float64 determinism.
    - Any change constitutes a different model variant.
    """

    # ----- Scope / canonical parameters -----
    bullet: str = "SG"

    # Harmonic energy renormalization parameter (SG: r_SG = 3/5).
    r_star: float = 3.0 / 5.0

    # ----- IDEAL (infinite) reference normalization -----
    # Reference boundary energy on B0 for the (ontic) infinite IDEAL graph.
    # This repo uses a canonical normalization E0_IDEAL := 1.
    # Any change constitutes a different model variant.
    E0_ideal: float = 1.0

    # ----- Traceability / audit budgets -----
    # Maximum number of cells to include in per-step "cell-orbit" statistics.
    # If exceeded, we deterministically truncate by increasing k and stop once the
    # cumulative number of cells would exceed this limit.
    trace_metrics_max_cells: int = 2000

    # Level parameters (defaults for this repo; CLI can override but policy values are still logged)
    L_int: int = 1

    # ----- Float64 canonicalization -----
    eps_mach: float = float(np.finfo(np.float64).eps)
    eps_floor: float = float(np.sqrt(np.finfo(np.float64).eps))
    eps: float = float(np.sqrt(np.finfo(np.float64).eps))

    # RegSPD escalation parameters
    beta_reg: float = 10.0
    M_reg: int = 8

    # Conditioning thresholds (normative)
    kappa_max: float = 1e12
    kappa_susp: float = 1e10

    # Sel / trajectories (normative)
    # Tie tolerance in Sel: τ_Sel := eps_floor
    tau_sel: float = float(np.sqrt(np.finfo(np.float64).eps))

    # Kept only as a legacy threshold for older variants. Not used by the v4_rev8 Sel.
    t_psi: float = 1e-12

    # Soft fallback / kappa mapping
    kappa_raw_thr: float = 1e-1
    eta_soft: float = 1e-2

    # Lambda bracketing/bisection
    lambda_init_step: float = 1.0
    lambda_gamma: float = 2.0
    N_expand: int = 48
    N_bisect: int = 64

    # Monitoring gates (run invalidation)
    p_fb_max: float = 0.05
    p_fb_hard_max: float = 0.01
    p_mreg_warn: float = 0.01
    p_mreg_max: float = 0.05

    # Convergence protocol thresholds (logged; not used for dynamics here)
    tau_rel: float = 1e4 * np.sqrt(np.finfo(np.float64).eps)
    tau_rel_warn: float = 10.0 * (1e4 * np.sqrt(np.finfo(np.float64).eps))
    tau_spec: float = 1e4 * np.sqrt(np.finfo(np.float64).eps)
    k_stable: int = 3

    def to_jsonable(self) -> dict:
        d = asdict(self)
        # Normalize float representations deterministically (round-trip stable).
        for k, v in list(d.items()):
            if isinstance(v, float):
                d[k] = float(v)
        return d
