from __future__ import annotations

from typing import Tuple
from dataclasses import dataclass

import numpy as np

from .constants import Policy
from ..numeric.solve import Solve, SolveReport as _SolveReport


SolveReport = _SolveReport


def cond_proxy(A: np.ndarray, pol: Policy) -> float:
    """Deterministic Gershgorin-style condition proxy (v4_rev8).

    Returns κ̂ = λ̂_max / λ̂_min with λ̂ derived from diagonal dominance bounds.
    """
    M = np.asarray(A, dtype=np.float64)
    M = 0.5 * (M + M.T)
    diag = np.diag(M)
    off = np.abs(M) - np.diag(np.abs(diag))
    row_sum_off = np.sum(off, axis=1)
    g_min = float(np.min(diag - row_sum_off))
    g_max = float(np.max(diag + row_sum_off))
    lam_min_hat = float(max(g_min, pol.eps_floor))
    lam_max_hat = float(max(g_max, lam_min_hat))
    return float(lam_max_hat / lam_min_hat)


def solve_spd_policy(A: np.ndarray, B: np.ndarray, pol: Policy) -> Tuple[np.ndarray, SolveReport]:
    """Deterministic solve wrapper (def:Solve, v4_rev8).

    Uses the canonical `numeric.solve.Solve` which is deterministic in float64.
    """
    return Solve(A, B)


__all__ = ["solve_spd_policy", "cond_proxy", "SolveReport"]
