from __future__ import annotations

from typing import Dict, Any, List


def claim_ladder() -> List[Dict[str, Any]]:
    """Return a deterministic 'claim ladder' used in reports.

    This is intentionally conservative: it enumerates what is implemented vs.
    what remains a hypothesis.
    """
    return [
        {"level": "implemented", "items": ["deterministic numeric gates", "SG trunk", "DtN/Kron seeds", "GKSL channel build"]},
        {"level": "diagnostic", "items": ["mismatch normalization", "fallback rates", "convergence metrics"]},
        {"level": "hypothesis", "items": ["H1", "H2", "H3"]},
    ]


def scope_flags(trajectory: bool = True, sg_only: bool = True) -> Dict[str, Any]:
    return {"trajectory_mode": bool(trajectory), "sg_only": bool(sg_only), "st_enabled": False}


def determinism_notes() -> str:
    return (
        "Determinism target: IEEE float64 with fixed policy constants and explicit gates. "
        "Linear algebra uses only numpy/scipy primitives already fixed in the code paths "
        "(Cholesky + deterministic LU fallback)."
    )


__all__ = ["claim_ladder", "scope_flags", "determinism_notes"]
