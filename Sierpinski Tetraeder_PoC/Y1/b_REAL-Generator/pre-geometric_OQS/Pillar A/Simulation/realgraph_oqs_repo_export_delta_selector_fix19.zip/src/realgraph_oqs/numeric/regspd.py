from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class RegSPDReport:
    m_chol: int
    m_used: int
    delta0: float
    delta_spd: float
    kappa_hat: float
    lambda_min_hat: float
    lambda_max_hat: float
    chol_ok: bool
    cond_fail: bool


def Sym(A: np.ndarray) -> np.ndarray:
    return 0.5 * (A + A.T)


def delta0(A: np.ndarray, pol: Policy) -> float:
    S = Sym(A)
    fro = float(np.linalg.norm(S, ord="fro"))
    return float(pol.eps_floor * max(1.0, fro))


def CholOK(M: np.ndarray) -> bool:
    try:
        np.linalg.cholesky(M)
    except np.linalg.LinAlgError:
        return False
    return bool(np.all(np.isfinite(M)))


def gershgorin_bounds(M: np.ndarray, pol: Policy) -> Tuple[float, float, float]:
    # M is assumed symmetric (or near); we use absolute row sums deterministically.
    n = M.shape[0]
    diag = np.diag(M)
    off = np.abs(M) - np.diag(np.abs(diag))
    row_sum_off = np.sum(off, axis=1)
    g_min = float(np.min(diag - row_sum_off))
    g_max = float(np.max(diag + row_sum_off))
    lam_min_hat = float(max(g_min, pol.eps_floor))
    lam_max_hat = float(max(g_max, lam_min_hat))
    kappa_hat = float(lam_max_hat / lam_min_hat)
    return lam_min_hat, lam_max_hat, kappa_hat


def RegSPD(A: np.ndarray, pol: Policy) -> Tuple[np.ndarray, RegSPDReport]:
    """Deterministic Sym + Tikhonov jitter, with escalation and explicit COND_FAIL reporting.

    Implements Definition def:regspd (v4_rev8).
    """
    S = Sym(np.asarray(A, dtype=np.float64))
    d0 = delta0(S, pol)

    # 1) Find smallest m where Cholesky succeeds.
    m_chol: Optional[int] = None
    for m in range(0, pol.M_reg + 1):
        cand = S + (pol.beta_reg ** m) * d0 * np.eye(S.shape[0], dtype=np.float64)
        if CholOK(cand):
            m_chol = m
            break
    if m_chol is None:
        m_chol = pol.M_reg  # deterministic fallback per spec

    # 2) From m_chol onward, enforce kappa_hat <= kappa_max if possible.
    m_used: Optional[int] = None
    last_kappa = None
    last_lmin = None
    last_lmax = None
    for m in range(m_chol, pol.M_reg + 1):
        cand = S + (pol.beta_reg ** m) * d0 * np.eye(S.shape[0], dtype=np.float64)
        lmin, lmax, kappa = gershgorin_bounds(cand, pol)
        last_kappa, last_lmin, last_lmax = kappa, lmin, lmax
        if kappa <= pol.kappa_max:
            m_used = m
            break
    if m_used is None:
        m_used = pol.M_reg

    M = S + (pol.beta_reg ** m_used) * d0 * np.eye(S.shape[0], dtype=np.float64)
    lmin, lmax, kappa = gershgorin_bounds(M, pol)
    cond_fail = bool(kappa > pol.kappa_max)

    rep = RegSPDReport(
        m_chol=int(m_chol),
        m_used=int(m_used),
        delta0=float(d0),
        delta_spd=float((pol.beta_reg ** m_used) * d0),
        kappa_hat=float(kappa),
        lambda_min_hat=float(lmin),
        lambda_max_hat=float(lmax),
        chol_ok=CholOK(M),
        cond_fail=cond_fail,
    )
    return M, rep
