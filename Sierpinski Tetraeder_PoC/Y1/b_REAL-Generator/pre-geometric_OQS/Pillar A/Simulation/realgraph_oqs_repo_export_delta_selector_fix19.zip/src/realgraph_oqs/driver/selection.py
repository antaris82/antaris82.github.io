from __future__ import annotations

"""Deterministic selection and θ-update (v4_rev8).

Implements the normative definitions:

- τ_Sel := eps_floor
- Sel(θ,π) returns ⊥ on any (numerical/symmetry) tie
- otherwise sorts outcomes by descending π-value and picks the first cumulative sum > θ
- θ-update: θ_{n+1} = frac( 2 θ_n + (ν+1)/( |A|+1 ) ) with ν derived from the Sel ordering

This module is SG-only: |A|=3 with outcomes corresponding to unordered pairs {i,j} on a 3-point boundary.
"""

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np

from realgraph_oqs.policy.constants import Policy

# SG boundary has q=3 corner indices 0,1,2. Outcomes are unordered pairs.
Action = Tuple[int, int]  # i<j
ACTIONS: Tuple[Action, ...] = ((0, 1), (0, 2), (1, 2))


@dataclass(frozen=True)
class SelReport:
    theta: float
    pi: Tuple[float, float, float]
    ordered_actions: Tuple[Action, Action, Action]
    selected: Optional[Action]  # None encodes ⊥
    nu: int  # rank index in {0,1,2}; by spec: nu=0 if selected is ⊥
    tie: bool


def _normalize_pi(pi: Sequence[float], pol: Policy) -> np.ndarray:
    p = np.asarray(pi, dtype=np.float64)
    if p.shape != (3,):
        raise ValueError("pi must have length 3 for SG (q=3).")
    p = np.maximum(p, 0.0)
    s = float(np.sum(p))
    if not np.isfinite(s) or s <= 0.0:
        return np.array([1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0], dtype=np.float64)
    return p / s


def Sel(theta: float, pi: Sequence[float], pol: Policy) -> Tuple[Optional[Action], SelReport]:
    """Tie-safe deterministic selection Sel(θ,π) (v4_rev8).

    Parameters
    ----------
    theta:
        θ in [0,1). Values outside are reduced modulo 1.
    pi:
        Probability mass on ACTIONS (length 3), not necessarily normalized.

    Returns
    -------
    (selected_action_or_None, SelReport)
        None corresponds to ⊥.
    """
    th = float(theta % 1.0)
    p = _normalize_pi(pi, pol)

    # Tie detection: if any two probabilities are closer than τ_Sel -> ⊥.
    tau = float(pol.tau_sel)
    tie = (
        (abs(float(p[0] - p[1])) <= tau)
        or (abs(float(p[0] - p[2])) <= tau)
        or (abs(float(p[1] - p[2])) <= tau)
    )

    # Order by descending probability (label-independent, value-based).
    # Ties are handled above; still include a stable secondary key.
    idx = list(range(3))
    idx.sort(key=lambda i: (-float(p[i]), i))
    ordered_actions = tuple(ACTIONS[i] for i in idx)  # type: ignore

    if tie:
        rep = SelReport(
            theta=th,
            pi=(float(p[0]), float(p[1]), float(p[2])),
            ordered_actions=ordered_actions,  # still recorded
            selected=None,
            nu=0,
            tie=True,
        )
        return None, rep

    # Cumulative pick: smallest k with sum_{ℓ<=k} π(a_ℓ) > θ.
    cum = 0.0
    k_sel = 0
    for j, i in enumerate(idx):
        cum += float(p[i])
        if cum > th:
            k_sel = j
            break

    sel_action = ACTIONS[idx[k_sel]]
    rep = SelReport(
        theta=th,
        pi=(float(p[0]), float(p[1]), float(p[2])),
        ordered_actions=ordered_actions,
        selected=sel_action,
        nu=int(k_sel),
        tie=False,
    )
    return sel_action, rep


def theta_next(theta: float, nu: int, A_size: int = 3) -> float:
    """Deterministic θ update (mischend): frac(2θ + (ν+1)/( |A|+1 ))."""
    th = float(theta % 1.0)
    nu = int(nu)
    if nu < 0:
        nu = 0
    if nu > (A_size - 1):
        nu = A_size - 1
    x = 2.0 * th + (float(nu + 1) / float(A_size + 1))
    return float(x - np.floor(x))
