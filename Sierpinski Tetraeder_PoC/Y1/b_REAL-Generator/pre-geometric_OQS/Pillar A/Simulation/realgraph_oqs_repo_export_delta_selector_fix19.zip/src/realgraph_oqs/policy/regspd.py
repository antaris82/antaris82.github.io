from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from .constants import Policy
from ..numeric.regspd import RegSPD, RegSPDReport


@dataclass(frozen=True)
class JitterPolicy:
    """Explicit jitter policy wrapper (v4_rev8).

    Notes
    -----
    The canonical constants live in `Policy`. This wrapper exists to make the
    traceability unit explicit and to provide helper checks.
    """
    pol: Policy


def assert_no_double_jitter(A: np.ndarray, rep: RegSPDReport) -> bool:
    """Best-effort guard against applying jitter twice.

    This is a *numerical* sanity check, not a physical statement. It returns
    True when the applied jitter is consistent with the report fields.
    """
    A = np.asarray(A, dtype=np.float64)
    # In RegSPD we apply Sym(A)+delta_spd I; verify diagonal shift magnitude is plausible.
    # We cannot reconstruct Sym(A) here without extra inputs; we only check finiteness.
    if not np.all(np.isfinite(A)):
        return False
    if not np.isfinite(rep.delta_spd):
        return False
    if rep.delta_spd < 0.0:
        return False
    return True


def regspd(A: np.ndarray, pol: Policy) -> Tuple[np.ndarray, RegSPDReport]:
    """Deterministic SPD regularization wrapper (def:regspd, v4_rev8)."""
    return RegSPD(A, pol)


__all__ = ["JitterPolicy", "assert_no_double_jitter", "regspd", "RegSPDReport"]
