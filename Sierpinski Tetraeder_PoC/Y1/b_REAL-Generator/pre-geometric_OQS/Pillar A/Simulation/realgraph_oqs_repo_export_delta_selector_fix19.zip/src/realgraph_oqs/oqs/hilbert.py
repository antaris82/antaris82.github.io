from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Sequence


@dataclass(frozen=True)
class DirectSumSpace:
    dims: Tuple[int, ...]
    offsets: Tuple[int, ...]

    @property
    def dim_total(self) -> int:
        return int(sum(self.dims))


def direct_sum_space(dims: Sequence[int]) -> DirectSumSpace:
    dims_t = tuple(int(d) for d in dims)
    offs = []
    s = 0
    for d in dims_t:
        offs.append(s)
        s += d
    return DirectSumSpace(dims=dims_t, offsets=tuple(offs))


def assert_no_tensor_api() -> None:
    """Hard guard: this codebase must not require a tensor-product API.

    We still allow tensor reshaping *internally* for linear algebra, but do not expose
    a public 'tensor space' abstraction in Pillar A.
    """
    return None


__all__ = ["direct_sum_space", "assert_no_tensor_api", "DirectSumSpace"]
