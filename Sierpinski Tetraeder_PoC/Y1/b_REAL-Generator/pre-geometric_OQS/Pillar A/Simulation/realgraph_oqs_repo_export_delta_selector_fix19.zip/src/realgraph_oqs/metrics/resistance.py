from __future__ import annotations

from typing import Tuple, Optional
import numpy as np

from ..policy.constants import Policy
from ..numeric.solve import Solve, SolveReport


def deltaR_policy(S: np.ndarray, pol: Policy) -> float:
    """Deterministic δ_R for resistance solves (float64 stabilization)."""
    S = np.asarray(S, dtype=np.float64)
    fro = float(np.linalg.norm(S, ord="fro"))
    return float(pol.eps_floor * max(1.0, fro))


def effective_resistance(L: np.ndarray, u: int, v: int, pol: Policy, ground: Optional[int] = None) -> Tuple[float, SolveReport]:
    """Compute effective resistance R(u,v) using a grounded reduced Laplacian.

    Algorithm (vNext.3-canonical style):
    - choose deterministic ground g (default: minimal vertex id)
    - build reduced Laplacian by removing row/col g
    - symmetrize S := 0.5(L^(g)+(L^(g))^T)
    - add deterministic jitter δ_R I
    - solve (S+δ_R I) x = b where b = e_u - e_v (reduced)
    - return R = b^T x
    """
    L = np.asarray(L, dtype=np.float64)
    n = L.shape[0]
    if L.shape[1] != n:
        raise ValueError("L must be square")
    u = int(u); v = int(v)
    if u == v:
        dummy = SolveReport(True, "chol", tuple(), 0.0)
        return 0.0, dummy

    if ground is None:
        g = 0
    else:
        g = int(ground)
    if not (0 <= g < n):
        raise ValueError("Invalid ground node")

    # reduced index mapping
    keep = [i for i in range(n) if i != g]
    idx_map = {old: new for new, old in enumerate(keep)}
    if (u not in idx_map) or (v not in idx_map):
        # if u or v is ground, handle by mapping b accordingly
        pass

    Lg = L[np.ix_(keep, keep)]
    S = 0.5 * (Lg + Lg.T)
    dR = deltaR_policy(S, pol)
    A = S + dR * np.eye(S.shape[0], dtype=np.float64)

    b = np.zeros((S.shape[0], 1), dtype=np.float64)
    if u != g:
        b[idx_map[u], 0] += 1.0
    if v != g:
        b[idx_map[v], 0] -= 1.0

    x, rep = Solve(A, b)
    if not rep.ok or not np.all(np.isfinite(x)):
        return float("inf"), rep
    R = float((b.T @ x)[0, 0])
    if R < 0 and abs(R) <= 1e3 * pol.eps_floor:
        R = 0.0
    return float(R), rep


__all__ = ["deltaR_policy", "effective_resistance"]
