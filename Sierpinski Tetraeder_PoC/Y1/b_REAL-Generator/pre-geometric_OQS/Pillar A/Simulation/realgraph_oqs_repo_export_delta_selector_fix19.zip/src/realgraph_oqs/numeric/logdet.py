from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class LogDetReport:
    tau_deg: float
    clusters: Tuple[Tuple[int, int], ...]  # (start,end) indices in sorted eig list
    min_eig: float
    max_eig: float


def _modified_gram_schmidt(vectors: List[np.ndarray], tol: float) -> List[np.ndarray]:
    basis: List[np.ndarray] = []
    for v in vectors:
        w = v.copy()
        for b in basis:
            w = w - np.vdot(b, w) * b
        nrm = float(np.linalg.norm(w))
        if nrm > tol:
            basis.append(w / nrm)
    return basis


def _canonicalize_cluster(Uc: np.ndarray, pol: Policy, tau: float) -> np.ndarray:
    # Projector onto cluster subspace
    P = Uc @ Uc.conj().T
    d = P.shape[0]
    std = [np.eye(d, dtype=np.complex128)[:, i] for i in range(d)]
    ws = [P @ e for e in std]
    basis = _modified_gram_schmidt(ws, tol=tau)
    # If numerical issues leave us short, fill deterministically by continuing with standard basis.
    if len(basis) < Uc.shape[1]:
        # Add remaining by orthonormalizing the original eigenvectors deterministically.
        extra = _modified_gram_schmidt([Uc[:, i] for i in range(Uc.shape[1])], tol=tau)
        for v in extra:
            if len(basis) >= Uc.shape[1]:
                break
            # ensure orthogonality to current basis
            w = v.copy()
            for b in basis:
                w = w - np.vdot(b, w) * b
            nrm = float(np.linalg.norm(w))
            if nrm > tau:
                basis.append(w / nrm)
    # Stack
    B = np.stack(basis[:Uc.shape[1]], axis=1)
    return B


def logDet(rho: np.ndarray, pol: Policy) -> Tuple[np.ndarray, LogDetReport]:
    """Deterministic log for (approx.) density matrices per def:logm_det.

    Returns logDet(rho) and a report (clusters, tau_deg).
    """
    rho = np.asarray(rho, dtype=np.complex128)
    rhoH = 0.5 * (rho + rho.conj().T)

    # Hermitian eigendecomposition, eigenvalues ascending; we sort descending.
    vals, vecs = np.linalg.eigh(rhoH)
    idx = np.argsort(vals)[::-1]
    vals = vals[idx]
    vecs = vecs[:, idx]

    tau_deg = float(64.0 * pol.eps_floor * max(1.0, float(np.linalg.norm(rhoH, ord=2))))

    # Cluster eigenvalues by |λ_i-λ_j| <= tau_deg (within contiguous sorted list).
    clusters: List[Tuple[int, int]] = []
    start = 0
    for i in range(1, len(vals) + 1):
        if i == len(vals) or abs(float(vals[i]) - float(vals[start])) > tau_deg:
            clusters.append((start, i))
            start = i

    # Canonicalize eigenvectors within each cluster
    U = vecs.copy()
    for (a, b) in clusters:
        if b - a <= 1:
            continue
        Uc = U[:, a:b]
        U[:, a:b] = _canonicalize_cluster(Uc, pol, tau=tau_deg)

    # Assemble log(rho) = U diag(log λ) U†, with safety clamp for tiny/negative numerical values.
    lam = np.maximum(np.real(vals), 0.0)
    # clamp to eps_floor to avoid -inf; for J_eps this should not bind.
    lam = np.maximum(lam, pol.eps_floor)
    loglam = np.log(lam).astype(np.complex128)
    log_rho = (U * loglam[np.newaxis, :]) @ U.conj().T

    rep = LogDetReport(
        tau_deg=tau_deg,
        clusters=tuple(clusters),
        min_eig=float(np.min(np.real(vals))),
        max_eig=float(np.max(np.real(vals))),
    )
    return log_rho, rep
