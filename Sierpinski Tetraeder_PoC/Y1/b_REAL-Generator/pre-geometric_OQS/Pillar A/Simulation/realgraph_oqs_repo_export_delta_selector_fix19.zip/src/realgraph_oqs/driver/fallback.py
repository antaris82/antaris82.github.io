from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any

from ..policy.constants import Policy
from .update import StepReport


@dataclass(frozen=True)
class FallbackForensics:
    n_steps: int
    p_invalid_mean: float
    p_fb_soft_mean: float
    p_fb_hard_mean: float
    p_mreg_mean: float
    lambda_unbracketed: int


def fallback_rates(step_reports: List[StepReport]) -> Dict[str, float]:
    """Aggregate fallback rates over steps."""
    if len(step_reports) == 0:
        return {"p_invalid": 0.0, "p_fb_soft": 0.0, "p_fb_hard": 0.0, "p_mreg": 0.0}
    p_invalid = sum(float(s.p_invalid) for s in step_reports) / len(step_reports)
    p_fb_soft = sum(float(s.p_fb_soft) for s in step_reports) / len(step_reports)
    p_fb_hard = sum(float(s.p_fb_hard) for s in step_reports) / len(step_reports)
    p_mreg = sum(float(s.p_mreg) for s in step_reports) / len(step_reports)
    return {"p_invalid": float(p_invalid), "p_fb_soft": float(p_fb_soft), "p_fb_hard": float(p_fb_hard), "p_mreg": float(p_mreg)}


def apply_fallbacks(valid_run: bool, pol: Policy) -> Dict[str, Any]:
    """Return a deterministic description of which fallbacks were applied.

    The core implementation already applies fallbacks during the update.
    This function is used for reporting/traceability only.
    """
    return {
        "freeze_if_invalid": True,
        "valid_run": bool(valid_run),
        "policy": {
            "p_fb_max": float(pol.p_fb_max),
            "p_fb_hard_max": float(pol.p_fb_hard_max),
            "p_mreg_max": float(pol.p_mreg_max),
        },
    }


def forensics(step_reports: List[StepReport]) -> FallbackForensics:
    rates = fallback_rates(step_reports)
    unbr = sum(1 for s in step_reports if not s.lambda_report.bracketed)
    return FallbackForensics(
        n_steps=int(len(step_reports)),
        p_invalid_mean=float(rates["p_invalid"]),
        p_fb_soft_mean=float(rates["p_fb_soft"]),
        p_fb_hard_mean=float(rates["p_fb_hard"]),
        p_mreg_mean=float(rates["p_mreg"]),
        lambda_unbracketed=int(unbr),
    )


__all__ = ["apply_fallbacks", "fallback_rates", "FallbackForensics", "forensics"]
