from __future__ import annotations

from typing import Tuple

from .sg_trunk import build_sg_trunk
from .structures import TrunkGraph


def st_disabled_flag() -> bool:
    """ST support is intentionally disabled in this repository variant (SG-only)."""
    return True


def validate_limit_path(L_max: int) -> bool:
    """Validate that the truncation level is a valid 'limit-path' approximant index."""
    return isinstance(L_max, int) and (L_max >= 1)


def validate_simple_graph(trunk: TrunkGraph) -> bool:
    """Validate basic simple-graph invariants (undirected, no self-loops, unique edges)."""
    seen = set()
    for (u, v) in trunk.edges:
        if u == v:
            return False
        a = (int(u), int(v)) if int(u) < int(v) else (int(v), int(u))
        if a in seen:
            return False
        seen.add(a)
    return True


def build_trunk_sg(L_max: int) -> TrunkGraph:
    """Build the SG trunk K_{L_max} (v4_rev8, SG-only)."""
    if not validate_limit_path(L_max):
        raise ValueError("Invalid L_max (must be integer >= 1)")
    trunk = build_sg_trunk(L_max=L_max)
    if not validate_simple_graph(trunk):
        raise ValueError("Trunk failed simple-graph validation")
    return trunk


__all__ = ["build_trunk_sg", "validate_simple_graph", "validate_limit_path", "st_disabled_flag"]
