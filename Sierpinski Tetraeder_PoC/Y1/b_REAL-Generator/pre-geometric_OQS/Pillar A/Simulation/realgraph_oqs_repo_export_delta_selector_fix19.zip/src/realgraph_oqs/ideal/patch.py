from __future__ import annotations

from typing import Tuple

from .structures import TrunkGraph


def patch1_ordering(trunk: TrunkGraph) -> Tuple[int, int, int]:
    """Return B0 vertex ids in canonical patch-1 order (i=0,1,2)."""
    return tuple(int(x) for x in trunk.B0)


__all__ = ["patch1_ordering"]
