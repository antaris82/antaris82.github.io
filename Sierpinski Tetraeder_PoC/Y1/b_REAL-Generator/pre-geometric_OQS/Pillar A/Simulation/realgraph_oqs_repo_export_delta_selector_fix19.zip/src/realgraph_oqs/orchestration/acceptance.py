from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List

from ..policy.constants import Policy
from ..driver.update import StepReport


@dataclass(frozen=True)
class Acceptance:
    passed: bool
    gates: Dict[str, Any]


def evaluate_acceptance(step_reports: List[StepReport], pol: Policy) -> Dict[str, Any]:
    """Evaluate acceptance gates (τ_rel, p_fb, p_mreg, λ-budget) for a run."""
    if len(step_reports) == 0:
        return {"passed": False, "reason": "no_steps"}

    p_fb = max(float(s.p_fb_soft + s.p_fb_hard) for s in step_reports)
    p_fb_hard = max(float(s.p_fb_hard) for s in step_reports)
    p_mreg = max(float(s.p_mreg) for s in step_reports)
    p_invalid = max(float(s.p_invalid) for s in step_reports)
    lam_unbracketed = sum(1 for s in step_reports if not s.lambda_report.bracketed)

    passed = True
    gates = {}

    gates["p_invalid"] = {"value": p_invalid, "max": float(pol.p_fb_max), "passed": p_invalid <= float(pol.p_fb_max)}
    # (Note: spec uses dedicated p_invalid threshold; repo uses p_fb_max as conservative bound.)
    if not gates["p_invalid"]["passed"]:
        passed = False

    gates["p_fb"] = {"value": p_fb, "max": float(pol.p_fb_max), "passed": p_fb <= float(pol.p_fb_max)}
    if not gates["p_fb"]["passed"]:
        passed = False

    gates["p_fb_hard"] = {"value": p_fb_hard, "max": float(pol.p_fb_hard_max), "passed": p_fb_hard <= float(pol.p_fb_hard_max)}
    if not gates["p_fb_hard"]["passed"]:
        passed = False

    gates["p_mreg"] = {"value": p_mreg, "max": float(pol.p_mreg_max), "passed": p_mreg <= float(pol.p_mreg_max)}
    if not gates["p_mreg"]["passed"]:
        passed = False

    gates["lambda_bracketing"] = {"unbracketed_steps": int(lam_unbracketed), "passed": lam_unbracketed == 0}
    if not gates["lambda_bracketing"]["passed"]:
        # still allow pass: bracketing fallback is deterministic, but record as warning
        pass

    return {"schema": "realgraph_oqs.acceptance.v1", "passed": bool(passed), "gates": gates}


__all__ = ["evaluate_acceptance", "Acceptance"]
