from __future__ import annotations

import json
import zipfile
from pathlib import Path
from typing import List, Dict, Any, Optional


def write_batch_artifacts(out_zip: Path, run_dirs: List[Path], manifest: Optional[Dict[str, Any]] = None) -> Path:
    """Create a deterministic ZIP containing multiple run directories and a manifest."""
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        if manifest is None:
            manifest = {"schema": "realgraph_oqs.batch_manifest.v1", "runs": [d.name for d in run_dirs]}
        z.writestr("batch_manifest.json", json.dumps(manifest, indent=2, sort_keys=True))
        for d in sorted(run_dirs, key=lambda p: p.name):
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    arc = str(Path(d.name) / p.relative_to(d))
                    z.write(p, arcname=arc)
    return out_zip


__all__ = ["write_batch_artifacts"]
