from __future__ import annotations

import hashlib
import json
import platform
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import scipy

from .constants import Policy


def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()


def sha256_file(path: Path) -> Optional[str]:
    try:
        b = path.read_bytes()
    except FileNotFoundError:
        return None
    return _sha256_bytes(b)


def policy_hash(policy: Policy) -> str:
    payload = json.dumps(policy.to_jsonable(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return _sha256_bytes(payload)


@dataclass(frozen=True)
class EnvLock:
    policy_hash: str
    policy: Dict[str, Any]
    python: str
    platform: str
    numpy: str
    scipy: str
    extra_files_sha256: Dict[str, str]

    def to_jsonable(self) -> Dict[str, Any]:
        return asdict(self)


def build_env_lock(policy: Policy, extra_files: Optional[Dict[str, Path]] = None) -> EnvLock:
    extra_files = extra_files or {}
    hashes: Dict[str, str] = {}
    for k, p in sorted(extra_files.items(), key=lambda kv: kv[0]):
        h = sha256_file(p)
        if h is not None:
            hashes[k] = h
    return EnvLock(
        policy_hash=policy_hash(policy),
        policy=policy.to_jsonable(),
        python=sys.version.replace("\n", " "),
        platform=platform.platform(),
        numpy=np.__version__,
        scipy=scipy.__version__,
        extra_files_sha256=hashes,
    )
