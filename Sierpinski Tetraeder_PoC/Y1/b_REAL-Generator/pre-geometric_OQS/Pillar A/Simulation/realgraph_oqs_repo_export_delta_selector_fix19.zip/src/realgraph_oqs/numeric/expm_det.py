from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from realgraph_oqs.numeric.solve import Solve
from realgraph_oqs.policy.constants import Policy


# Higham 2005 theta_13 for (13,13) Padé with 1-norm scaling.
THETA_13 = 4.25


@dataclass(frozen=True)
class ExpmDetReport:
    s: int
    norm1: float
    ok: bool


def _norm1(A: np.ndarray) -> float:
    return float(np.max(np.sum(np.abs(A), axis=0)))


def expmDet(A: np.ndarray, pol: Policy) -> Tuple[np.ndarray, ExpmDetReport]:
    """Deterministic scaling-and-squaring with Padé (13,13) per def:expm_det.

    - A must be real (float64). Internally uses Solve(·,·) for the Padé linear system.
    """
    A = np.asarray(A, dtype=np.float64)
    n = A.shape[0]
    I = np.eye(n, dtype=np.float64)

    n1 = _norm1(A)
    if n1 == 0.0:
        return I.copy(), ExpmDetReport(s=0, norm1=0.0, ok=True)

    s = int(max(0, np.ceil(np.log2(n1 / THETA_13))))
    As = A / (2.0 ** s)

    # Padé(13): coefficients (Higham, also used by SciPy)
    b = np.array([
        64764752532480000.0,
        32382376266240000.0,
        7771770303897600.0,
        1187353796428800.0,
        129060195264000.0,
        10559470521600.0,
        670442572800.0,
        33522128640.0,
        1323241920.0,
        40840800.0,
        960960.0,
        16380.0,
        182.0,
        1.0,
    ], dtype=np.float64)

    A2 = As @ As
    A4 = A2 @ A2
    A6 = A4 @ A2

    U = As @ (A6 @ (b[13]*A6 + b[11]*A4 + b[9]*A2) + b[7]*A6 + b[5]*A4 + b[3]*A2 + b[1]*I)
    V = A6 @ (b[12]*A6 + b[10]*A4 + b[8]*A2) + b[6]*A6 + b[4]*A4 + b[2]*A2 + b[0]*I

    P = V + U
    Q = V - U

    X, rep = Solve(Q, P)
    if not rep.ok:
        # Totality: fall back to identity if the Padé solve fails deterministically.
        return I.copy(), ExpmDetReport(s=s, norm1=n1, ok=False)

    R = X
    # Squaring
    for _ in range(s):
        R = R @ R
    return R, ExpmDetReport(s=s, norm1=n1, ok=True)
