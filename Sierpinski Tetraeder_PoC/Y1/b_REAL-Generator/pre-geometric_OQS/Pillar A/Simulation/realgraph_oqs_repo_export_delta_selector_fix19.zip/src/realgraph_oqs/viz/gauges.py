from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple

import numpy as np

from ..ideal.structures import TrunkGraph
from ..policy.constants import Policy
from ..metrics.resistance import effective_resistance
from .sg_ifs import sg_ifs_coords


@dataclass(frozen=True)
class GaugeBundle:
    fixed_coords: np.ndarray
    real_coords: np.ndarray
    edge_scalar: np.ndarray
    method: str


def _harmonic_embedding_triangle(trunk: TrunkGraph, L: np.ndarray, pol: Policy) -> np.ndarray:
    """Simple harmonic embedding into R^2 with fixed boundary triangle."""
    n = trunk.nV
    B = trunk.B0
    # boundary coordinates: equilateral triangle
    coords = np.zeros((n, 2), dtype=np.float64)
    coords[B[0], :] = np.array([0.0, 0.0])
    coords[B[1], :] = np.array([1.0, 0.0])
    coords[B[2], :] = np.array([0.5, np.sqrt(3.0)/2.0])

    # interior solve: L_II x = -L_IB x_B
    I = [i for i in range(n) if i not in set(B)]
    if not I:
        return coords
    L_II = L[np.ix_(I, I)]
    L_IB = L[np.ix_(I, B)]
    # regularize
    A = 0.5 * (L_II + L_II.T) + pol.eps_floor * np.eye(len(I))
    rhs_x = -L_IB @ coords[np.array(B), 0]
    rhs_y = -L_IB @ coords[np.array(B), 1]
    x = np.linalg.solve(A, rhs_x)
    y = np.linalg.solve(A, rhs_y)
    coords[np.array(I), 0] = x
    coords[np.array(I), 1] = y
    return coords


def _spectral_layout(trunk: TrunkGraph, L: np.ndarray) -> np.ndarray:
    """Deterministic spectral layout from the (symmetrized) Laplacian.

    Uses the 2nd and 3rd smallest eigenvectors of the Laplacian. This is
    visualization-only and requires only NumPy.
    """
    S = 0.5 * (L + L.T)
    try:
        w, V = np.linalg.eigh(S)
        idx = np.argsort(w)
        V = V[:, idx]
        if V.shape[1] >= 3:
            X = np.stack([V[:, 1], V[:, 2]], axis=1)
        elif V.shape[1] >= 2:
            X = np.stack([V[:, 1], V[:, 1]], axis=1)
        else:
            X = np.zeros((trunk.nV, 2), dtype=np.float64)
        return np.asarray(X, dtype=np.float64)
    except Exception:
        return np.zeros((trunk.nV, 2), dtype=np.float64)


def _resistance_distance_matrix_grounded(L: np.ndarray, pol: Policy, ground: int = 0) -> np.ndarray:
    """Compute full resistance-distance matrix using one grounded inverse.

    Visualization-only helper (not a core physical object in the model).
    Uses a deterministic ground node and deterministic Tikhonov jitter.
    """
    L = np.asarray(L, dtype=np.float64)
    n = L.shape[0]
    if n <= 1:
        return np.zeros((n, n), dtype=np.float64)
    g = int(ground)
    idx = [i for i in range(n) if i != g]
    # Symmetrize + deterministic jitter (float64)
    S = 0.5 * (L[np.ix_(idx, idx)] + L[np.ix_(idx, idx)].T)
    delta = float(pol.eps_floor * max(1.0, np.linalg.norm(S, ord="fro")))
    A = S + delta * np.eye(len(idx), dtype=np.float64)
    try:
        Ginv = np.linalg.inv(A)  # (n-1)x(n-1)
    except Exception:
        # fallback: if inversion fails, return finite placeholder distances
        return np.ones((n, n), dtype=np.float64)

    red = {node: k for k, node in enumerate(idx)}
    D = np.zeros((n, n), dtype=np.float64)

    for i in range(n):
        for j in range(i + 1, n):
            if i == j:
                d = 0.0
            elif i == g:
                kj = red[j]
                r = float(Ginv[kj, kj])
                d = float(np.sqrt(max(r, 0.0)))
            elif j == g:
                ki = red[i]
                r = float(Ginv[ki, ki])
                d = float(np.sqrt(max(r, 0.0)))
            else:
                ki = red[i]
                kj = red[j]
                r = float(Ginv[ki, ki] + Ginv[kj, kj] - 2.0 * Ginv[ki, kj])
                d = float(np.sqrt(max(r, 0.0)))
            D[i, j] = D[j, i] = d
    return D


def _mds_embedding(D: np.ndarray, dim: int = 2) -> np.ndarray:
    """Classical MDS embedding from a distance matrix D (deterministic)."""
    D = np.asarray(D, dtype=np.float64)
    n = D.shape[0]
    J = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * J @ (D**2) @ J
    w, V = np.linalg.eigh(B)
    idx = np.argsort(w)[::-1]
    w = w[idx]
    V = V[:, idx]
    w_pos = np.maximum(w[:dim], 0.0)
    X = V[:, :dim] * np.sqrt(w_pos)
    return X.astype(np.float64)


def build_gauges(
    trunk: TrunkGraph,
    c_ideal: np.ndarray,
    c_real: np.ndarray,
    pol: Policy,
    embedding: str = "mds_resistance",
    fixed_layout: str = "ifs",
) -> Dict[str, Any]:
    """Build the two 'gauge' views: weight-field and induced-geometry embedding.

    Returns JSON-serializable arrays (via .tolist()) and metadata.
    """
    c_ideal = np.asarray(c_ideal, dtype=np.float64).reshape(-1)
    c_real = np.asarray(c_real, dtype=np.float64).reshape(-1)

    # Fixed layout for View A (deterministic, computed from IDEAL weights c_ideal)
    # GUI requirement: choose (as far as possible) the same "method" options as View B.
    if fixed_layout == "ifs":
        fixed = sg_ifs_coords(trunk)
        fixed_method = "ifs"
    else:
        L0 = trunk.laplacian_from_conductances(c_ideal)
        if fixed_layout == "harmonic":
            fixed = _harmonic_embedding_triangle(trunk, L0, pol)
            fixed_method = "harmonic"
        elif fixed_layout == "mds_resistance":
            D0 = _resistance_distance_matrix_grounded(L0, pol, ground=min(trunk.B0))
            fixed = _mds_embedding(D0, dim=2)
            fixed_method = "mds_resistance"
        elif fixed_layout == "spectral":
            fixed = _spectral_layout(trunk, L0)
            fixed_method = "spectral"
        else:
            fixed = _harmonic_embedding_triangle(trunk, L0, pol)
            fixed_method = "harmonic"

    # Edge scalar: log ratio
    edge_scalar = np.log(np.maximum(pol.eps_floor, c_real) / np.maximum(pol.eps_floor, c_ideal))

    # REAL coords (induced geometry)
    if embedding == "ifs":
        # Not an induced geometry (included only so View A/B can be configured identically).
        real = sg_ifs_coords(trunk)
        method = "ifs"
    elif embedding == "harmonic":
        Ln = trunk.laplacian_from_conductances(c_real)
        real = _harmonic_embedding_triangle(trunk, Ln, pol)
        method = "harmonic"
    elif embedding == "mds_resistance":
        Ln = trunk.laplacian_from_conductances(c_real)
        D = _resistance_distance_matrix_grounded(Ln, pol, ground=min(trunk.B0))
        real = _mds_embedding(D, dim=2)
        method = "mds_resistance"
    else:
        Ln = trunk.laplacian_from_conductances(c_real)
        D = _resistance_distance_matrix_grounded(Ln, pol, ground=min(trunk.B0))
        real = _mds_embedding(D, dim=2)
        method = "mds_resistance"

    bundle = GaugeBundle(fixed_coords=fixed, real_coords=real, edge_scalar=edge_scalar, method=method)
    return {
        "schema": "realgraph_oqs.viz.gauges.v1",
        "method": method,
        "fixed_method": fixed_method,
        "fixed_coords": bundle.fixed_coords.tolist(),
        "real_coords": bundle.real_coords.tolist(),
        "edge_scalar": bundle.edge_scalar.tolist(),
    }


__all__ = ["build_gauges", "GaugeBundle"]
