from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Any, Tuple


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def load_module_map(path: Path) -> Tuple[Dict[str, Any], str]:
    """Load the module-map JSON and return (data, sha256).

    The sha256 is used for pinning in `env_lock` / run metadata.
    """
    b = path.read_bytes()
    data = json.loads(b.decode("utf-8"))
    return data, _sha256_bytes(b)


__all__ = ["load_module_map"]
