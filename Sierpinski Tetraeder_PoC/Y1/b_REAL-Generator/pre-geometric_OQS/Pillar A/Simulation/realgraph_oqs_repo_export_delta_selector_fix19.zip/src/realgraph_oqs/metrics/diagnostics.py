from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Iterable, Tuple, Optional

import numpy as np

from ..policy.constants import Policy
from .resistance import effective_resistance


@dataclass(frozen=True)
class ResistanceDiagnostics:
    n_pairs: int
    r_min: float
    r_median: float
    r_max: float
    inf_count: int
    symmetry_ok: bool


def resistance_diagnostics(L: np.ndarray, pol: Policy, pairs: Optional[Iterable[Tuple[int, int]]] = None) -> Dict[str, Any]:
    """Compute basic diagnostics for effective resistance.

    If `pairs` is None, use a deterministic small sample of pairs.
    """
    L = np.asarray(L, dtype=np.float64)
    n = L.shape[0]
    if pairs is None:
        # deterministic sample: first min(50,n) nodes vs next ones
        m = min(25, n)
        pairs = [(i, (i+1) % n) for i in range(m)] + [(0, j) for j in range(1, m)]

    vals = []
    inf_count = 0
    sym_ok = True
    for (u, v) in pairs:
        r_uv, _ = effective_resistance(L, int(u), int(v), pol)
        r_vu, _ = effective_resistance(L, int(v), int(u), pol)
        if not (np.isfinite(r_uv) and np.isfinite(r_vu)):
            inf_count += 1
        else:
            if abs(r_uv - r_vu) > 1e3 * pol.eps_floor * max(1.0, abs(r_uv), abs(r_vu)):
                sym_ok = False
            vals.append(float(0.5 * (r_uv + r_vu)))

    if len(vals) == 0:
        diag = ResistanceDiagnostics(n_pairs=0, r_min=float("inf"), r_median=float("inf"), r_max=float("inf"),
                                    inf_count=inf_count, symmetry_ok=sym_ok)
    else:
        a = np.array(vals, dtype=np.float64)
        diag = ResistanceDiagnostics(
            n_pairs=int(len(vals)),
            r_min=float(np.min(a)),
            r_median=float(np.median(a)),
            r_max=float(np.max(a)),
            inf_count=int(inf_count),
            symmetry_ok=bool(sym_ok),
        )
    return {"schema":"realgraph_oqs.metrics.resistance_diagnostics.v1", **diag.__dict__}


__all__ = ["resistance_diagnostics", "ResistanceDiagnostics"]
