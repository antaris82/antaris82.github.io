from __future__ import annotations

from typing import Dict, Any

from ..policy.constants import Policy
from .update import LambdaReport


def lambda_gate(lam: LambdaReport, pol: Policy) -> Dict[str, Any]:
    """Deterministic gate evaluation for λ-normalization.

    Gate is considered passed if:
    - bracketing succeeded, OR a deterministic fallback (λ=0) was applied and logged.
    """
    passed = bool(lam.bracketed or (lam.lambda_n == 0.0))
    return {
        "passed": passed,
        "bracketed": bool(lam.bracketed),
        "lambda_n": float(lam.lambda_n),
        "expand_iters": int(lam.expand_iters),
        "bisect_iters": int(lam.bisect_iters),
        "target_E_B0_tot": float(lam.target_E_B0_tot),
        "achieved_E_B0_tot": float(lam.achieved_E_B0_tot),
    }


__all__ = ["lambda_gate"]
