from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from realgraph_oqs.driver.lcp_measure import LCPMeasure
from realgraph_oqs.ideal.structures import TrunkGraph, Word


@dataclass(frozen=True)
class CellSets:
    # For each k=1..K_max: cells_by_k[k] is list of words length k (aligned with lcp.words_by_k[k])
    # We include k=0 for completeness (empty word).
    K_max: int
    B: Dict[Word, Tuple[int, int, int]]
    V: Dict[Word, Tuple[int, ...]]
    I: Dict[Word, Tuple[int, ...]]
    E_idx: Dict[Word, Tuple[int, ...]]  # edge indices in trunk.edges with mu_{k,w}(e)>0


def build_cell_sets(trunk: TrunkGraph, lcp: LCPMeasure) -> CellSets:
    V: Dict[Word, Tuple[int, ...]] = {}
    I: Dict[Word, Tuple[int, ...]] = {}
    E_idx: Dict[Word, Tuple[int, ...]] = {}
    B = trunk.Bw.copy()

    nE = len(trunk.edges)

    for k in range(0, lcp.K_max + 1):
        words_k = lcp.words_by_k[k]
        mu_k = lcp.mu[k]
        for wi, w in enumerate(words_k):
            # edges in E_w^(k)
            e_list = tuple(int(e) for e in np.where(mu_k[wi, :] > 0.0)[0])
            E_idx[w] = e_list
            verts = set()
            for ei in e_list:
                u, v = trunk.edges[ei]
                verts.add(int(u)); verts.add(int(v))
            # include boundary
            bw = B[w]
            verts.update(map(int, bw))
            Vw = tuple(sorted(verts))
            V[w] = Vw
            Iw = tuple(v for v in Vw if v not in bw)
            I[w] = Iw

    return CellSets(
        K_max=lcp.K_max,
        B=B,
        V=V,
        I=I,
        E_idx=E_idx,
    )
