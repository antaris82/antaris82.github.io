from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Any

from ..policy.env_lock import EnvLock, build_env_lock as _build_env_lock
from ..policy.constants import Policy


@dataclass(frozen=True)
class EnvLockSchema:
    """Alias schema for orchestration layer (v1)."""
    env: EnvLock


def build_env_lock(policy: Policy, extra_files: Optional[Dict[str, Path]] = None) -> EnvLock:
    """Build an EnvLock (policy hash + runtime versions + optional pinned files)."""
    return _build_env_lock(policy=policy, extra_files=extra_files or {})


__all__ = ["EnvLockSchema", "build_env_lock"]
