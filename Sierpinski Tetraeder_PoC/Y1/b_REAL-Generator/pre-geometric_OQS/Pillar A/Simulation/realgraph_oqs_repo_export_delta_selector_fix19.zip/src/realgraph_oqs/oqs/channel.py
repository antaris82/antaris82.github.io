from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Optional

import numpy as np


@dataclass(frozen=True)
class ChoiChannel:
    """Channel represented by its Choi matrix J (CPTP if J >= 0 and Tr_out J = I).

    This is a lightweight utility for traceability; the core dynamics uses superoperators.
    """
    J: np.ndarray  # shape (d*d, d*d)
    d: int

    def is_hermitian(self, tol: float = 0.0) -> bool:
        J = np.asarray(self.J)
        return bool(np.allclose(J, J.conj().T, atol=tol, rtol=0.0))

    def trace_preserving_residual(self) -> float:
        J = np.asarray(self.J, dtype=np.complex128)
        d = int(self.d)
        # partial trace over output: reshape as (d_out, d_in, d_out, d_in)
        T = J.reshape(d, d, d, d)
        # trace over output indices (0,2)
        S = np.einsum("a b a d -> b d", T)
        return float(np.linalg.norm(S - np.eye(d), ord="fro"))

    def apply_to_state(self, rho: np.ndarray) -> np.ndarray:
        """Apply channel to rho using Jamiołkowski isomorphism.

        For moderate d only. Deterministic in float64/complex128.
        """
        rho = np.asarray(rho, dtype=np.complex128)
        d = int(self.d)
        J = np.asarray(self.J, dtype=np.complex128).reshape(d, d, d, d)  # out,in,out,in
        # Φ(ρ)_{a,c} = Σ_{b,d} J_{a,b,c,d} ρ_{b,d}
        out = np.einsum("a b c d, b d -> a c", J, rho)
        return out

