from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol, runtime_checkable, Any

from .constants import Policy

@runtime_checkable
class MatrixFuncPolicy(Protocol):
    """Policy carrier for deterministic matrix functions (v4_rev8).

    This is a lightweight interface used by wrapper functions in `policy/*`.
    The canonical implementation is `DefaultMatrixFuncPolicy`.
    """
    base: Policy


@dataclass(frozen=True)
class DefaultMatrixFuncPolicy:
    base: Policy


__all__ = [
    "MatrixFuncPolicy",
    "DefaultMatrixFuncPolicy",
    "Policy",
]
