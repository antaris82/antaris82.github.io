from __future__ import annotations

"""Streamlit GUI (plan G9, SG-only).

Implements GUI requirements from Implementierungsplan_REAL-Graph_OQS_v4_rev14 (Stage 9):
- Parameter controls (L_max, N, d_p, trajectories, embedding, visual scaling)
- Subsystem cell selection via deterministic cell table (and optional prefix-tree view)
- Two parallel views:
  A) Weight field on fixed layout (edges thickness ∝ conductance)
  B) Induced geometry (MDS-resistance or harmonic embedding)
- Plots: time series and per-step diagnostics (Etot_B0, fallback rates, conductance stats,
  Δ_n(e)=log(c_{n+1}/c_n), mismatch across cells)
- Report panel (gate fields incl. COND_FAIL, valid, lambda search)
- Export as ZIP including artifacts + meta + file hashes
- Optional batch artifacts (batch_cells.csv/json)

Start modes (src-layout):
  1) streamlit run -m realgraph_oqs.gui.streamlit_app
  2) streamlit run src/realgraph_oqs/gui/streamlit_app.py
"""

import sys
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Set
import json
import zipfile
import hashlib
import time
import io

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Bootstrap for "script path mode" (no package context)
# -----------------------------------------------------------------------------
_THIS = Path(__file__).resolve()
_REPO_ROOT = _THIS.parents[3]  # .../repo/
_SRC_ROOT = _REPO_ROOT / "src"
if str(_SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(_SRC_ROOT))


def _try_import_streamlit():
    try:
        import streamlit as st  # type: ignore
        return st
    except Exception as e:
        raise RuntimeError(
            "streamlit is not installed. Install optional extra 'gui' (see pyproject.toml): "
            "pip install -e '.[gui]'"
        ) from e


# -----------------------------------------------------------------------------
# Imports from package (after bootstrap)
# -----------------------------------------------------------------------------
from realgraph_oqs.policy.constants import Policy
from realgraph_oqs.driver.runner import run_simulation
from realgraph_oqs.ideal.sg_trunk import build_sg_trunk
from realgraph_oqs.driver.lcp_measure import compute_lcp_measure, Word
from realgraph_oqs.driver.cell_sets import build_cell_sets, CellSets
from realgraph_oqs.viz.gauges import build_gauges


from realgraph_oqs.oqs.dtn import dtn_kron, dtn_local, normalize_Lambda
from realgraph_oqs.oqs.gksl import channel_from_Lambda_hat
from realgraph_oqs.oqs.mismatch import mismatch_from_channels
# -----------------------------------------------------------------------------
# Small deterministic helpers (UI-only)
# -----------------------------------------------------------------------------
def addr_str(w: Tuple[int, ...]) -> str:
    return "EMPTY" if len(w) == 0 else "".join(str(int(x)) for x in w)


def parse_addr(s: str) -> Tuple[int, ...]:
    s = s.strip().upper()
    if s in ("", "EMPTY", "∅"):
        return tuple()
    if not all(ch.isdigit() for ch in s):
        raise ValueError("addr_str must be digits or 'EMPTY'")
    return tuple(int(ch) for ch in s)


def parent_word(w: Tuple[int, ...]) -> Optional[Tuple[int, ...]]:
    if len(w) == 0:
        return None
    return tuple(w[:-1])


def build_cells_table(trunk, lcp, cells: CellSets) -> pd.DataFrame:
    """Return deterministic table of all cells C = ⋃_{k=0..K_max} S_k with stats."""
    rows: List[Dict[str, Any]] = []
    # lcp.words_by_k includes k=0 (empty word)
    for k in range(0, lcp.K_max + 1):
        for w in lcp.words_by_k[k]:
            E_idx_w = cells.E_idx.get(w, tuple())
            # V^(k)_w from edge endpoints where mu>0
            verts = set()
            for ei in E_idx_w:
                u, v = trunk.edges[int(ei)]
                verts.add(int(u))
                verts.add(int(v))
            rows.append(
                {
                    "k": int(k),
                    "addr_str": addr_str(w),
                    "word": w,
                    "card_E": int(len(E_idx_w)),
                    "card_V": int(len(verts)),
                }
            )
    df = pd.DataFrame(rows)
    df.sort_values(["k", "addr_str"], inplace=True, kind="mergesort")
    df.reset_index(drop=True, inplace=True)
    df.insert(0, "idx", np.arange(len(df), dtype=int))
    return df


def _graph_dist_to_B0(trunk) -> np.ndarray:
    """Unweighted BFS distance from each vertex to the boundary set B0 (deterministic)."""
    from collections import deque

    nV = int(trunk.nV)
    dist = np.full((nV,), fill_value=10**9, dtype=np.int32)
    q: deque[int] = deque()
    for v in trunk.B0:
        vv = int(v)
        if 0 <= vv < nV:
            dist[vv] = 0
            q.append(vv)
    # adjacency from edges
    adj: List[List[int]] = [[] for _ in range(nV)]
    for (u, v) in trunk.edges:
        uu = int(u)
        vv = int(v)
        if 0 <= uu < nV and 0 <= vv < nV:
            adj[uu].append(vv)
            adj[vv].append(uu)
    while q:
        x = q.popleft()
        dx = int(dist[x])
        nd = dx + 1
        for y in adj[x]:
            if int(dist[y]) > nd:
                dist[y] = nd
                q.append(y)
    return dist


def tailcg_edge_shell_weights(trunk, pol: Policy) -> Tuple[np.ndarray, np.ndarray]:
    """Return (d_edge, w_edge) used by tail-cg 'series_shells' diagnostics.

    d_edge := min distance of an endpoint of edge e to B0
    w_edge := r_star**d_edge, normalized to max=1 (numerical stability; lambda rescales)
    """
    dist = _graph_dist_to_B0(trunk)
    d_edge = np.array([min(int(dist[int(u)]), int(dist[int(v)])) for (u, v) in trunk.edges], dtype=np.int32)
    w_edge = np.power(float(pol.r_star), d_edge.astype(np.float64))
    w_max = float(np.max(w_edge)) if w_edge.size else 0.0
    if w_max > 0.0:
        w_edge = w_edge / w_max
    return d_edge, w_edge


def edge_and_node_sets_for_cell(trunk, cells: CellSets, w: Tuple[int, ...]) -> Tuple[List[int], List[int]]:
    E_idx = list(map(int, cells.E_idx.get(w, tuple())))
    verts = set()
    for ei in E_idx:
        u, v = trunk.edges[ei]
        verts.add(int(u))
        verts.add(int(v))
    return E_idx, sorted(verts)


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def zip_dir_deterministic(src_dir: Path, out_zip: Path, exclude_prefixes: Optional[List[str]] = None) -> Path:
    """Zip directory with deterministic ordering.

    exclude_prefixes: relative path prefixes (e.g. ["ui_artifacts"]) to omit from the ZIP.
    """
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    prefixes = tuple(str(p).strip("/").replace("\\", "/") for p in (exclude_prefixes or []))

    def _skip(arc: str) -> bool:
        a = arc.replace("\\", "/")
        for pref in prefixes:
            if a == pref or a.startswith(pref + "/"):
                return True
        return False

    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(src_dir.rglob("*")):
            if p.is_file():
                arc = str(p.relative_to(src_dir))
                if prefixes and _skip(arc):
                    continue
                z.write(p, arcname=arc)
    return out_zip


def ensure_env_lock_json(outdir: Path, run_report: Dict[str, Any]) -> None:
    """Mirror env_lock to its own file (plan convenience)."""
    env = run_report.get("env_lock", {})
    (outdir / "env_lock.json").write_text(json.dumps(env, indent=2, sort_keys=True), encoding="utf-8")


# -----------------------------------------------------------------------------
# Visualization helpers (matplotlib)
# -----------------------------------------------------------------------------
def _widths_from_conductance(c: np.ndarray, w_min: float, w_max: float, cmin: float, cmax: float) -> np.ndarray:
    c = np.asarray(c, dtype=float)
    den = (cmax - cmin) if (cmax - cmin) > 0 else 1.0
    return w_min + (w_max - w_min) * (c - cmin) / den


def _widths_scaled(
    values: np.ndarray,
    w_min: float,
    w_max: float,
    vmin: float,
    vmax: float,
    power: float,
) -> np.ndarray:
    """Map nonnegative values to linewidths with optional contrast power."""
    v = np.asarray(values, dtype=float)
    den = (vmax - vmin) if (vmax - vmin) > 0 else 1.0
    x = (v - vmin) / den
    x = np.clip(x, 0.0, 1.0)
    p = float(power)
    if p != 1.0:
        x = x**p
    return w_min + (w_max - w_min) * x


def _procrustes_rigid(src: np.ndarray, target: np.ndarray) -> np.ndarray:
    """Rigid Procrustes alignment: translate+rotate src to match target (no scaling)."""
    X = np.asarray(src, dtype=float)
    Y = np.asarray(target, dtype=float)
    if X.shape != Y.shape:
        return X
    Xc = X - np.mean(X, axis=0, keepdims=True)
    Yc = Y - np.mean(Y, axis=0, keepdims=True)
    M = Xc.T @ Yc
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt
    # enforce det(R)=+1
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1.0
        R = U @ Vt
    return Xc @ R + np.mean(Y, axis=0, keepdims=True)


def plot_graph(
    st,
    coords: np.ndarray,
    edges: List[Tuple[int, int]],
    title: str,
    widths: Optional[np.ndarray] = None,
    encode_widths: bool = True,
    base_width: float = 0.8,
    highlight_edges: Optional[set[int]] = None,
    highlight_nodes: Optional[set[int]] = None,
    node_size: float = 10.0,
    ghost_coords: Optional[np.ndarray] = None,
    zoom_nodes: Optional[List[int]] = None,
    zoom_pad_frac: float = 0.15,
    highlight_color: str = "red",
    base_color: str = "black",
    save_path: Optional[Path] = None,
):
    import matplotlib.pyplot as plt

    nV = coords.shape[0]
    fig = plt.figure(figsize=(6.5, 6.5), dpi=140)
    ax = fig.add_subplot(111)
    ax.set_axis_off()

    # optional ghost overlay (fixed layout) for visual comparison
    if ghost_coords is not None:
        Gc = np.asarray(ghost_coords, dtype=float)
        if Gc.shape == coords.shape:
            for i, (u, v) in enumerate(edges):
                x = [Gc[u, 0], Gc[v, 0]]
                y = [Gc[u, 1], Gc[v, 1]]
                ax.plot(x, y, linewidth=0.6, alpha=0.18)

    # draw edges; selected-cell edges are red but keep the same linewidth encoding
    hE = set(highlight_edges) if highlight_edges else set()
    for i, (u, v) in enumerate(edges):
        x = [coords[u, 0], coords[v, 0]]
        y = [coords[u, 1], coords[v, 1]]
        lw = float(widths[i]) if (encode_widths and widths is not None) else float(base_width)
        col = highlight_color if i in hE else base_color
        a = 0.95 if i in hE else 0.85
        ax.plot(x, y, linewidth=lw, alpha=a, color=col)

    # nodes
    ax.scatter(coords[:, 0], coords[:, 1], s=node_size, color=base_color)

    # highlight nodes (filled)
    if highlight_nodes:
        hn = np.array(sorted(highlight_nodes), dtype=int)
        ax.scatter(
            coords[hn, 0],
            coords[hn, 1],
            s=node_size * 3.2,
            color=highlight_color,
        )

    # optional zoom around selected nodes (used for View C)
    if zoom_nodes:
        zn = np.array(list(dict.fromkeys(zoom_nodes)), dtype=int)  # deterministic unique
        if zn.size > 0:
            xs = coords[zn, 0]
            ys = coords[zn, 1]
            xmin, xmax = float(np.min(xs)), float(np.max(xs))
            ymin, ymax = float(np.min(ys)), float(np.max(ys))
            dx = xmax - xmin
            dy = ymax - ymin
            pad = float(zoom_pad_frac)
            ax.set_xlim(xmin - pad * (dx if dx > 0 else 1.0), xmax + pad * (dx if dx > 0 else 1.0))
            ax.set_ylim(ymin - pad * (dy if dy > 0 else 1.0), ymax + pad * (dy if dy > 0 else 1.0))

    ax.set_title(title, fontsize=10)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def plot_timeseries(
    st,
    series: Dict[str, List[float]],
    title: str,
    ylab: str,
    x: Optional[List[int]] = None,
    save_path: Optional[Path] = None,
):
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(7, 3), dpi=140)
    ax = fig.add_subplot(111)
    for name, vals in series.items():
        if x is None:
            ax.plot(list(range(len(vals))), vals, label=name)
        else:
            ax.plot(x, vals, label=name)
    ax.set_xlabel("step n")
    ax.set_ylabel(ylab)
    ax.set_title(title)
    ax.legend(loc="best", fontsize=8)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def plot_hist(st, data: np.ndarray, title: str, xlab: str, save_path: Optional[Path] = None):
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(7, 3), dpi=140)
    ax = fig.add_subplot(111)
    ax.hist(np.asarray(data, dtype=float).ravel(), bins=40)
    ax.set_xlabel(xlab)
    ax.set_ylabel("count")
    ax.set_title(title)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)



def plot_heatmap(st, mat: np.ndarray, title: str, xlab: str = "j", ylab: str = "i", save_path: Optional[Path] = None):
    """Small matrix heatmap helper for Streamlit.

    Used for displaying DtN operators Λ̂ on boundary sets (typically 3x3 for SG).
    """
    import matplotlib.pyplot as plt

    A = np.asarray(mat, dtype=float)
    if A.ndim != 2:
        raise ValueError(f"plot_heatmap expects 2D array, got shape {A.shape}")

    n, m = A.shape
    # compact size for small boundary matrices, but still readable
    fig = plt.figure(figsize=(3.6, 3.0), dpi=160)
    ax = fig.add_subplot(111)
    im = ax.imshow(A, aspect="equal")

    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title, fontsize=10)

    ax.set_xticks(list(range(m)))
    ax.set_yticks(list(range(n)))

    # annotate values for small matrices (keeps UI readable)
    if n <= 8 and m <= 8:
        for i in range(n):
            for j in range(m):
                v = A[i, j]
                s = "nan" if not np.isfinite(v) else f"{v:.3g}"
                ax.text(j, i, s, ha="center", va="center", fontsize=7)

    fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")
    st.pyplot(fig, use_container_width=False)
    plt.close(fig)

def plot_heatmap_row(st, row: np.ndarray, title: str, xlab: str, save_path: Optional[Path] = None):
    import matplotlib.pyplot as plt

    row = np.asarray(row, dtype=float).reshape(1, -1)
    fig = plt.figure(figsize=(7, 1.6), dpi=140)
    ax = fig.add_subplot(111)
    im = ax.imshow(row, aspect="auto")
    ax.set_yticks([])
    ax.set_xlabel(xlab)
    ax.set_title(title, fontsize=10)
    fig.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, bbox_inches="tight")
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def _write_png_bytes(fig) -> bytes:
    """Return PNG bytes for a Matplotlib figure (used for Streamlit download buttons)."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    return buf.getvalue()


def _safe_name(s: str) -> str:
    return "".join(ch if (ch.isalnum() or ch in ("-", "_", ".")) else "_" for ch in s)


def _next_available_path(path: Path) -> Path:
    """Return a non-existing sibling path by appending a deterministic counter.

    This is used as a fallback when overwriting a file fails (e.g. because the file is
    currently opened/locked by another process such as Excel on Windows).
    """
    if not path.exists():
        return path
    stem = path.stem
    suf = path.suffix
    parent = path.parent
    for i in range(1, 10000):
        cand = parent / f"{stem}__alt{i:04d}{suf}"
        if not cand.exists():
            return cand
    # last resort (should never happen)
    return parent / f"{stem}__alt_overflow{suf}"


def _tmp_sibling(path: Path) -> Path:
    """Create a deterministic, non-existing tmp path next to `path`.

    IMPORTANT: preserves the original file suffix so that writers that infer format
    from the suffix (Matplotlib) or append suffixes (np.save) behave predictably.
    Example: "cells.csv" -> "cells.tmp0000.csv".
    """
    parent = path.parent
    stem = path.stem
    suf = path.suffix
    for i in range(0, 10000):
        cand = parent / f"{stem}.tmp{i:04d}{suf}"
        if not cand.exists():
            return cand
    return parent / f"{stem}.tmp_overflow{suf}"


def _next_available_alt_path(path: Path) -> Path:
    """Return a non-existing alternate target path (distinct from our tmp naming).

    Important: tmp files are created as `<stem>.tmp####<suf>`. If the destination is locked on Windows
    and we fall back to an alternate name, we must *not* choose the same naming pattern, otherwise
    `alt` can equal the tmp_path and the rename degenerates.
    """
    parent = path.parent
    stem = path.stem
    suf = path.suffix
    for i in range(0, 10000):
        cand = parent / f"{stem}__alt{i:04d}{suf}"
        if not cand.exists():
            return cand
    return parent / f"{stem}__alt_overflow{suf}"


def _safe_replace(tmp_path: Path, final_path: Path, write_log: List[Dict[str, Any]]) -> Path:
    """Atomically move tmp_path -> final_path, with Windows-lock-safe fallbacks.

    On Windows, both the source or the destination can be transiently locked (e.g. Excel
    opened the target CSV, or antivirus is scanning). We therefore:
      1) retry os.replace(tmp, final) a few times
      2) try an alternative non-existing name
      3) as last resort, keep the tmp file and log (do not crash the export)
    """
    last_err: Exception | None = None

    # (1) primary replace with short retries
    for k in range(5):
        try:
            os.replace(tmp_path, final_path)
            return final_path
        except PermissionError as e:
            last_err = e
            time.sleep(0.03 * (k + 1))
        except Exception as e:
            last_err = e
            break

    # (2) fallback: move to an alternative name (if final is locked/open)
    alt = _next_available_alt_path(final_path)
    if alt == tmp_path:
        alt = _next_available_alt_path(final_path.with_name(final_path.stem + "__alt2" + final_path.suffix))
    for k in range(5):
        try:
            os.replace(tmp_path, alt)
            write_log.append(
                {
                    "kind": "permission_fallback",
                    "requested": str(final_path),
                    "written": str(alt),
                    "error": repr(last_err) if last_err is not None else None,
                }
            )
            return alt
        except PermissionError as e:
            last_err = e
            time.sleep(0.03 * (k + 1))
        except Exception as e:
            last_err = e
            break

    # (3) last resort: keep tmp (still a valid file) and log; never crash export
    write_log.append(
        {
            "kind": "permission_kept_tmp",
            "requested": str(final_path),
            "written": str(tmp_path),
            "error": repr(last_err) if last_err is not None else None,
        }
    )
    return tmp_path


def _safe_df_to_csv(df: pd.DataFrame, path: Path, write_log: List[Dict[str, Any]]) -> Path:
    """Write DataFrame to CSV robustly (avoids crashing on locked target files)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_sibling(path)
    df.to_csv(tmp, index=False)
    return _safe_replace(tmp, path, write_log)


def _safe_np_save(arr: np.ndarray, path: Path, write_log: List[Dict[str, Any]]) -> Path:
    """Write .npy robustly via tmp+replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() != ".npy":
        path = path.with_suffix(path.suffix + ".npy")
    tmp = _tmp_sibling(path)
    np.save(tmp, np.asarray(arr))
    # np.save appends .npy if missing; our tmp includes suffix, so keep as-is.
    return _safe_replace(tmp, path, write_log)


def _safe_fig_save(fig, path: Path, write_log: List[Dict[str, Any]], **kwargs) -> Path:
    """Save Matplotlib figure robustly via tmp+replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_sibling(path)
    fig.savefig(tmp, **kwargs)
    return _safe_replace(tmp, path, write_log)


def _safe_write_text(text: str, path: Path, write_log: List[Dict[str, Any]], *, encoding: str = "utf-8") -> Path:
    """Write text file robustly via tmp+replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_sibling(path)
    tmp.write_text(text, encoding=encoding)
    return _safe_replace(tmp, path, write_log)



# -----------------------------------------------------------------------------
# UI export catalog (selection in Export tab)
# -----------------------------------------------------------------------------
UI_EXPORT_CATALOG: List[Tuple[str, List[Dict[str, str]]]] = [
    (
        "Views",
        [
            {"id": "views_viewA", "label": "View A snapshots (viewA_*.png)", "kind": "figure"},
            {"id": "views_viewB", "label": "View B snapshots (viewB_*.png)", "kind": "figure"},
            {"id": "views_viewC", "label": "View C snapshots (viewC_*.png)", "kind": "figure"},
            {"id": "views_ts_conductance", "label": "Time-series: conductance (ts_conductance.png)", "kind": "figure"},
            {"id": "views_ts_Etot", "label": "Time-series: Etot_B0 (ts_Etot.png)", "kind": "figure"},
            {"id": "views_ts_gates", "label": "Time-series: gates/fallbacks (ts_gates.png)", "kind": "figure"},
            {"id": "views_cell_top_edges_sparklines", "label": "Top edges sparklines (cell_top_edges_sparklines.png)", "kind": "figure"},
            {"id": "views_tailcg_hists", "label": "Tail-CG histograms (tailcg_*.png)", "kind": "figure"},
        ],
    ),
    (
        "Subsystem",
        [
            {"id": "subsystem_cell_delta_summary_ts", "label": "Cell Δ summary time-series (cell_delta_summary_timeseries.csv)", "kind": "table"},
            {"id": "subsystem_cell_delta_hist", "label": "Cell Δ histograms per step (cell_delta_hist_*.png)", "kind": "figure"},
        ],
    ),
    (
        "Diagnostics",
        [
            {"id": "diag_mismatch_heat", "label": "Mismatch heatmap per step (mismatch_heat_*.png)", "kind": "figure"},
            {"id": "diag_mismatch_hist", "label": "Mismatch histogram per step (mismatch_hist_*.png)", "kind": "figure"},
            {"id": "diag_mismatch_csv", "label": "Mismatch data per step (mismatch_*.csv)", "kind": "table"},
            {"id": "diag_lambda_plots", "label": "Λ̂ plots per step (Lam_*_*.png)", "kind": "figure"},
            {"id": "diag_lambda_mats", "label": "Λ̂ matrices per step (Lam_*_*.npy)", "kind": "matrix"},
            {"id": "diag_delta_hist", "label": "Δ histogram per step (delta_hist_*.png)", "kind": "figure"},
            {"id": "diag_delta_heat", "label": "Δ heatmap per step (delta_heat_*.png)", "kind": "figure"},
            {"id": "diag_delta_mat", "label": "Δ matrix per step (delta_*.npy)", "kind": "matrix"},
            {"id": "diag_delta_top10", "label": "Δ top10 per step (delta_top10_*.csv)", "kind": "table"},
        ],
    ),
    (
        "Audit",
        [
            {"id": "audit_timeseries", "label": "Audit time-series (audit_timeseries.csv)", "kind": "table"},
            {"id": "audit_scale", "label": "Audit scale plots (audit_scale_*.png)", "kind": "figure"},
            {"id": "audit_B0_symmetry", "label": "Audit B0 symmetry (audit_B0_symmetry.png)", "kind": "figure"},
            {"id": "audit_cell_orbits", "label": "Audit cell orbits (audit_cell_orbits.png)", "kind": "figure"},
        ],
    ),
    (
        "Tables",
        [
            {"id": "tables_cells", "label": "Cells table (cells.csv)", "kind": "table"},
            {"id": "tables_timeseries", "label": "Time-series table (timeseries.csv)", "kind": "table"},
            {"id": "tables_cell_top_edges", "label": "Top edges table (cell_top_edges.csv)", "kind": "table"},
            {"id": "tables_tailcg_edges", "label": "Tail-CG edge table (tailcg_edges.csv)", "kind": "table"},
        ],
    ),
]


def generate_ui_artifacts(
    *,
    outdir: Path,
    enabled_items: Optional[Set[str]] = None,
    trunk,
    edges: List[Tuple[int, int]],
    C: np.ndarray,
    step_reports: List[Dict[str, Any]],
    cell_sets: CellSets,
    selected_w: Tuple[int, ...],
    pol: Policy,
    tail_cg_method: Optional[str] = None,
    tail_report: Optional[Dict[str, Any]] = None,
    fixed_layout: str,
    embedding: str,
    align_B: bool,
    deform_gamma: float,
    overlay_fixed: bool,
    thickness_mode: str,
    normalize_widths: bool,
    width_power: float,
    w_min: float,
    w_max: float,
    steps: List[int],
    k_mismatch: int,
    stride_for_ts: int,
) -> Path:
    """Generate UI-derived plots/heatmaps/tables and write them into outdir/ui_artifacts/.

    These artifacts are not produced by the core runner; they are derived from already-saved
    run outputs (conductances.npy, edges.csv, run_report.json) for reproducible export.
    """
    import matplotlib.pyplot as plt

    ui_root = outdir / "ui_artifacts"

    # When the user selects a subset of UI artifacts, remove any stale ui_artifacts
    # from prior runs so the export reflects exactly the current checkbox selection.
    if enabled_items is not None and ui_root.exists():
        import shutil as _shutil

        for sub in ("figures", "tables", "matrices"):
            p = ui_root / sub
            if p.exists():
                try:
                    _shutil.rmtree(p)
                except Exception:
                    pass
        for fn in ("ui_artifacts_write_log.json", "file_hashes.ui_artifacts.json"):
            p = ui_root / fn
            if p.exists():
                try:
                    p.unlink()
                except Exception:
                    pass

    fig_dir = ui_root / "figures"
    tab_dir = ui_root / "tables"
    mat_dir = ui_root / "matrices"
    for d in (fig_dir, tab_dir, mat_dir):
        d.mkdir(parents=True, exist_ok=True)

    # collect non-fatal write fallbacks (e.g. locked target files on Windows)
    write_log: List[Dict[str, Any]] = []

    enabled: Optional[Set[str]] = None if enabled_items is None else set(enabled_items)

    def _on(item_id: str) -> bool:
        return True if enabled is None else (item_id in enabled)

    # always export deterministic cell table
    lcp = compute_lcp_measure(trunk)
    cells_df = build_cells_table(trunk, lcp, cell_sets)
    if _on("tables_cells"):
        _safe_df_to_csv(cells_df, tab_dir / "cells.csv", write_log)
    # --------------------------
    # Tail coarse-grain diagnostics (N=0 initialization)
    # --------------------------
    if isinstance(tail_report, dict) and bool(tail_report.get("enabled", False)):
        import matplotlib.pyplot as plt

        method = str(tail_cg_method or tail_report.get("method", ""))
        d_edge, w_edge = tailcg_edge_shell_weights(trunk, pol)

        scaled = np.zeros((len(edges),), dtype=bool)
        if method == "b0_uniform":
            e_scaled = tail_report.get("edges_scaled", []) or []
            for ei in e_scaled:
                try:
                    scaled[int(ei)] = True
                except Exception:
                    pass

        df_tail = pd.DataFrame(
            {
                "edge_index": list(range(len(edges))),
                "u": [int(u) for (u, _) in edges],
                "v": [int(v) for (_, v) in edges],
                "d_to_B0": d_edge.astype(int).tolist(),
                "w_edge": w_edge.astype(float).tolist(),
                "scaled": scaled.astype(bool).tolist(),
                "method": [method for _ in range(len(edges))],
            }
        )
        if _on("tables_tailcg_edges"):
            _safe_df_to_csv(df_tail, tab_dir / "tailcg_edges.csv", write_log)
        def _hist_fig(vals: np.ndarray, title: str, xlabel: str):
            fig = plt.figure(figsize=(7, 3), dpi=140)
            ax = fig.add_subplot(111)
            v = np.asarray(vals, dtype=float)
            v = v[np.isfinite(v)]
            if v.size == 0:
                ax.text(0.5, 0.5, "no data", ha="center", va="center")
            else:
                ax.hist(v, bins="auto")
            ax.set_xlabel(xlabel)
            ax.set_ylabel("count")
            ax.set_title(title)
            return fig

        fig = _hist_fig(d_edge.astype(float), "TailCG: edge distance to B0 (d_edge)", "d_edge")
        if _on("views_tailcg_hists"):
            _safe_fig_save(fig, fig_dir / "tailcg_d_edge_hist.png", write_log, bbox_inches="tight")
        plt.close(fig)

        fig = _hist_fig(w_edge.astype(float), "TailCG: shell weights w_edge (normalized)", "w_edge")
        if _on("views_tailcg_hists"):
            _safe_fig_save(fig, fig_dir / "tailcg_w_edge_hist.png", write_log, bbox_inches="tight")
        plt.close(fig)

        if method == "b0_uniform" and int(np.sum(scaled)) > 0:
            fig = _hist_fig(d_edge[scaled].astype(float), "TailCG: d_edge for scaled edges only (b0_uniform)", "d_edge")
            if _on("views_tailcg_hists"):
                _safe_fig_save(fig, fig_dir / "tailcg_d_edge_scaled_hist.png", write_log, bbox_inches="tight")
            plt.close(fig)

    # step index padding
    pad = max(3, len(str(int(C.shape[0] - 1))))

    # compute View A fixed coords once (independent of n)
    c_ideal = np.ones(len(edges), dtype=np.float64)
    gauges_A0 = build_gauges(
        trunk=trunk,
        c_ideal=c_ideal,
        c_real=np.asarray(C[0], dtype=np.float64),
        embedding=str(embedding),
        fixed_layout=str(fixed_layout),
        pol=pol,
    )
    coords_A = np.array(gauges_A0["fixed_coords"], dtype=float)

    # View B/C ghost: IDEAL induced geometry (same embedding gauge as View B)
    gauges_B0 = build_gauges(
        trunk=trunk,
        c_ideal=c_ideal,
        c_real=c_ideal,
        embedding=str(embedding),
        fixed_layout=str(fixed_layout),
        pol=pol,
    )
    coords_B_ideal = np.array(gauges_B0["real_coords"], dtype=float)

    # selected cell sets
    E_idx_sel, V_sel = edge_and_node_sets_for_cell(trunk, cell_sets, selected_w)
    E_set = set(E_idx_sel)
    V_set = set(V_sel)

    # diagnostic time series (written once)
    if step_reports:
        n_sr = int(len(step_reports))
        n_c = int(C.shape[0])
        N = int(min(n_sr, n_c))
        stride_ts = max(1, int(stride_for_ts))
        idxs = list(range(0, N, stride_ts))

        # align series lengths defensively (step_reports and C may differ by 1 due to IO/truncation)
        Etot_full = [float(sr["lambda_report"]["achieved_E_B0_tot"]) for sr in step_reports[:N]]
        p_soft_full = [float(sr["p_fb_soft"]) for sr in step_reports[:N]]
        p_hard_full = [float(sr["p_fb_hard"]) for sr in step_reports[:N]]
        p_mreg_full = [float(sr["p_mreg"]) for sr in step_reports[:N]]
        c_min_full = [float(np.min(C[n])) for n in range(N)]
        c_med_full = [float(np.median(C[n])) for n in range(N)]
        c_max_full = [float(np.max(C[n])) for n in range(N)]

        ts_df = pd.DataFrame(
            {
                "n": list(range(N)),
                "Etot_B0": Etot_full,
                "p_fb_soft": p_soft_full,
                "p_fb_hard": p_hard_full,
                "p_mreg": p_mreg_full,
                "c_min": c_min_full,
                "c_median": c_med_full,
                "c_max": c_max_full,
            }
        )
        if _on("tables_timeseries"):
            _safe_df_to_csv(ts_df, tab_dir / "timeseries.csv", write_log)
        # render plots into disk (create fig explicitly to avoid Streamlit dependency)
        def _ts_fig(series: Dict[str, List[float]], title: str, ylab: str, x: List[int]):
            fig = plt.figure(figsize=(7, 3), dpi=140)
            ax = fig.add_subplot(111)
            for name, vals in series.items():
                ax.plot(x, vals, label=name)
            ax.set_xlabel("step n")
            ax.set_ylabel(ylab)
            ax.set_title(title)
            ax.legend(loc="best", fontsize=8)
            return fig

        fig = _ts_fig({"Etot_B0": [Etot_full[i] for i in idxs]}, "Boundary total energy Etot_B0,n", "Etot", idxs)
        if _on("views_ts_Etot"):
            _safe_fig_save(fig, fig_dir / "ts_Etot.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _ts_fig(
            {
                "p_fb_soft": [p_soft_full[i] for i in idxs],
                "p_fb_hard": [p_hard_full[i] for i in idxs],
                "p_mreg": [p_mreg_full[i] for i in idxs],
            },
            "Gate/fallback rates per step",
            "rate",
            idxs,
        )
        if _on("views_ts_gates"):
            _safe_fig_save(fig, fig_dir / "ts_gates.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _ts_fig(
            {
                "min(c)": [c_min_full[i] for i in idxs],
                "median(c)": [c_med_full[i] for i in idxs],
                "max(c)": [c_max_full[i] for i in idxs],
            },
            "Conductance summary",
            "c",
            idxs,
        )
        if _on("views_ts_conductance"):
            _safe_fig_save(fig, fig_dir / "ts_conductance.png", write_log, bbox_inches="tight")
        plt.close(fig)

        # --------------------------
        # Audit metrics time series
        # --------------------------
        audit_rows: List[Dict[str, Any]] = []
        for sr_i in step_reports[:N]:
            n_i = int(sr_i.get("n", -1))
            sym = sr_i.get("symmetry_metrics", {}) or {}
            sc = sr_i.get("scale_break_metrics", {}) or {}

            def _get(d, keys, default=float("nan")):
                cur = d
                for k in keys:
                    if not isinstance(cur, dict) or (k not in cur):
                        return default
                    cur = cur[k]
                try:
                    return float(cur)
                except Exception:
                    return default

            audit_rows.append(
                {
                    "n": n_i,
                    "b0_var_before": _get(sym, ["before", "boundary", "var_across_vertex_means"], float("nan")),
                    "b0_var_after": _get(sym, ["after", "boundary", "var_across_vertex_means"], float("nan")),
                    "cell_orbit_avg_before": _get(sym, ["before", "cell_orbits", "avg_var_over_k"], float("nan")),
                    "cell_orbit_avg_after": _get(sym, ["after", "cell_orbits", "avg_var_over_k"], float("nan")),
                    "scale_slope_before": _get(sc, ["before", "fit", "b"], float("nan")),
                    "scale_slope_after": _get(sc, ["after", "fit", "b"], float("nan")),
                    "scale_rmse_before": _get(sc, ["before", "fit", "rmse"], float("nan")),
                    "scale_rmse_after": _get(sc, ["after", "fit", "rmse"], float("nan")),
                    "scale_rmse0_before": _get(sc, ["before", "fit", "rmse_zero_slope"], float("nan")),
                    "scale_rmse0_after": _get(sc, ["after", "fit", "rmse_zero_slope"], float("nan")),
                }
            )

        audit_df = pd.DataFrame(audit_rows)
        if not audit_df.empty:
            audit_df.sort_values(["n"], inplace=True, kind="mergesort")
            if _on("audit_timeseries"):
                _safe_df_to_csv(audit_df, tab_dir / "audit_timeseries.csv", write_log)
            x_a = [int(v) for v in audit_df["n"].to_list()]
            fig = _ts_fig(
                {
                    "B0 var (before)": audit_df["b0_var_before"].to_list(),
                    "B0 var (after)": audit_df["b0_var_after"].to_list(),
                },
                "Audit: B0 symmetry proxy (variance across B0-vertex means)",
                "var",
                x_a,
            )
            if _on("audit_B0_symmetry"):
                _safe_fig_save(fig, fig_dir / "audit_B0_symmetry.png", write_log, bbox_inches="tight")
            plt.close(fig)

            fig = _ts_fig(
                {
                    "cell_orbit avg var (before)": audit_df["cell_orbit_avg_before"].to_list(),
                    "cell_orbit avg var (after)": audit_df["cell_orbit_avg_after"].to_list(),
                },
                "Audit: cell-orbit proxy (avg variance of cell means per k)",
                "var",
                x_a,
            )
            if _on("audit_cell_orbits"):
                _safe_fig_save(fig, fig_dir / "audit_cell_orbits.png", write_log, bbox_inches="tight")
            plt.close(fig)

            fig = _ts_fig(
                {
                    "slope b (before)": audit_df["scale_slope_before"].to_list(),
                    "slope b (after)": audit_df["scale_slope_after"].to_list(),
                },
                "Audit: scale-break proxy (log-linear fit slope b)",
                "b",
                x_a,
            )
            if _on("audit_scale"):
                _safe_fig_save(fig, fig_dir / "audit_scale_slope.png", write_log, bbox_inches="tight")
            plt.close(fig)

            fig = _ts_fig(
                {
                    "rmse (before)": audit_df["scale_rmse_before"].to_list(),
                    "rmse (after)": audit_df["scale_rmse_after"].to_list(),
                    "rmse0 (before)": audit_df["scale_rmse0_before"].to_list(),
                    "rmse0 (after)": audit_df["scale_rmse0_after"].to_list(),
                },
                "Audit: scale-break proxy (fit RMSE and zero-slope baseline)",
                "rmse",
                x_a,
            )
            if _on("audit_scale"):
                _safe_fig_save(fig, fig_dir / "audit_scale_rmse.png", write_log, bbox_inches="tight")
            plt.close(fig)

    # --------------------------
    # Selected cell dynamics (local Δ_n(e) in E_w^(k))
    # --------------------------
    E_idx_cell = tuple(int(e) for e in cell_sets.E_idx.get(tuple(selected_w), tuple()))
    if len(E_idx_cell) > 0 and int(C.shape[0]) >= 2:
        eps = 1e-300
        d_all = np.log((np.asarray(C[1:], dtype=float) + eps) / (np.asarray(C[:-1], dtype=float) + eps))
        d_cell = d_all[:, list(E_idx_cell)]  # shape (N, |E_cell|)

        # summary time series
        df_cell_ts = pd.DataFrame(
            {
                "n": list(range(int(d_cell.shape[0]))),
                "max_abs_delta": np.max(np.abs(d_cell), axis=1).astype(float).tolist(),
                "mean_abs_delta": np.mean(np.abs(d_cell), axis=1).astype(float).tolist(),
                "rms_delta": np.sqrt(np.mean(d_cell**2, axis=1)).astype(float).tolist(),
                "edges_in_cell": [int(d_cell.shape[1]) for _ in range(int(d_cell.shape[0]))],
                "selected_w": [addr_str(tuple(selected_w)) for _ in range(int(d_cell.shape[0]))],
            }
        )
        if _on("subsystem_cell_delta_summary_ts"):
            _safe_df_to_csv(df_cell_ts, tab_dir / "cell_delta_summary_timeseries.csv", write_log)
        # top edges by max |Δ| over time
        max_abs_e = np.max(np.abs(d_cell), axis=0)
        mean_abs_e = np.mean(np.abs(d_cell), axis=0)
        order = np.argsort(-max_abs_e)
        top_m = int(min(12, len(order)))
        rows_top: List[Dict[str, Any]] = []
        for j in order[:top_m]:
            ei = int(E_idx_cell[int(j)])
            u, v = edges[ei]
            rows_top.append(
                {
                    "edge_index": ei,
                    "u": int(u),
                    "v": int(v),
                    "max_abs_delta": float(max_abs_e[int(j)]),
                    "mean_abs_delta": float(mean_abs_e[int(j)]),
                    "selected_w": addr_str(tuple(selected_w)),
                }
            )
        df_top = pd.DataFrame(rows_top)
        if _on("tables_cell_top_edges"):
            _safe_df_to_csv(df_top, tab_dir / "cell_top_edges.csv", write_log)
        # sparklines figure
        fig = plt.figure(figsize=(7.2, max(2.0, 0.85 * top_m)), dpi=150)
        for i, j in enumerate(order[:top_m]):
            ax = fig.add_subplot(top_m, 1, i + 1)
            ax.plot(np.arange(int(d_cell.shape[0])), d_cell[:, int(j)], linewidth=1.0)
            ax.axhline(0.0, linewidth=0.8)
            ei = int(E_idx_cell[int(j)])
            ax.set_ylabel(f"e{ei}", fontsize=8)
            ax.tick_params(labelsize=7)
            if i < top_m - 1:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel("n", fontsize=8)
        fig.suptitle(f"Selected cell {addr_str(tuple(selected_w))}: top-{top_m} edges Δ_n(e)", fontsize=10)
        if _on("views_cell_top_edges_sparklines"):
            _safe_fig_save(fig, fig_dir / "cell_top_edges_sparklines.png", write_log, bbox_inches="tight")
        plt.close(fig)

        # histograms for selected steps (Δ_n uses c[n+1]/c[n])
        hist_steps = sorted({int(n) for n in steps if 0 <= int(n) < int(d_cell.shape[0])})
        for n in hist_steps:
            vals = np.asarray(d_cell[int(n), :], dtype=float)
            fig = plt.figure(figsize=(7, 3), dpi=140)
            ax = fig.add_subplot(111)
            v = vals[np.isfinite(vals)]
            if v.size == 0:
                ax.text(0.5, 0.5, "no data", ha="center", va="center")
            else:
                ax.hist(v, bins="auto")
            ax.set_xlabel("Δ")
            ax.set_ylabel("count")
            ax.set_title(f"Selected cell {addr_str(tuple(selected_w))}: Δ_{int(n)}(e) histogram (cell edges)")
            if _on("subsystem_cell_delta_hist"):
                _safe_fig_save(fig, fig_dir / f"cell_delta_hist_n{int(n):0{pad}d}.png", write_log, bbox_inches="tight")
            plt.close(fig)

    # per-step artifacts
    for n in steps:
        n = int(n)
        if n < 0 or n >= int(C.shape[0]):
            continue
        tag = f"n{n:0{pad}d}"

        # widths for View A
        c_step = np.asarray(C[n], dtype=float)
        c0 = np.asarray(C[0], dtype=float)
        if thickness_mode == "c_n(e)/c_0(e)":
            values = c_step / (c0 + 1e-300)
        else:
            values = c_step
        if normalize_widths:
            vmin = float(np.min(values))
            vmax = float(np.max(values))
        else:
            if thickness_mode == "c_n(e)/c_0(e)":
                all_vals = np.asarray(C, dtype=float) / (c0.reshape(1, -1) + 1e-300)
            else:
                all_vals = np.asarray(C, dtype=float)
            vmin = float(np.min(all_vals))
            vmax = float(np.max(all_vals))
        widths = _widths_scaled(values, w_min=float(w_min), w_max=float(w_max), vmin=vmin, vmax=vmax, power=float(width_power))

        # View B coords (induced geometry) relative to IDEAL ghost (independent of View A)
        gauges_B = build_gauges(
            trunk=trunk,
            c_ideal=c_ideal,
            c_real=np.asarray(C[n], dtype=np.float64),
            embedding=str(embedding),
            fixed_layout=str(fixed_layout),
            pol=pol,
        )
        coords_B_real = np.array(gauges_B["real_coords"], dtype=float)
        coords_B_real_aligned = _procrustes_rigid(coords_B_real, coords_B_ideal) if bool(align_B) else coords_B_real
        coords_B_vis = coords_B_ideal + float(deform_gamma) * (coords_B_real_aligned - coords_B_ideal)

        # write View A/B/C
        # (we render figures without streamlit here)
        def _graph_fig(coords: np.ndarray, widths_: Optional[np.ndarray], encode: bool, base_w: float, title: str, zoom: bool, ghost_coords: Optional[np.ndarray] = None):
            fig = plt.figure(figsize=(6.5, 6.5), dpi=140)
            ax = fig.add_subplot(111)
            ax.set_axis_off()
            if overlay_fixed and (ghost_coords is not None) and ghost_coords.shape == coords.shape:
                for (u, v) in edges:
                    ax.plot([ghost_coords[u, 0], ghost_coords[v, 0]], [ghost_coords[u, 1], ghost_coords[v, 1]], linewidth=0.6, alpha=0.18)
            hE = set(E_set)
            for i, (u, v) in enumerate(edges):
                lw = float(widths_[i]) if (encode and widths_ is not None) else float(base_w)
                col = "red" if i in hE else "black"
                a = 0.95 if i in hE else 0.85
                ax.plot([coords[u, 0], coords[v, 0]], [coords[u, 1], coords[v, 1]], linewidth=lw, alpha=a, color=col)
            ax.scatter(coords[:, 0], coords[:, 1], s=10.0, color="black")
            if V_set:
                hn = np.array(sorted(V_set), dtype=int)
                ax.scatter(coords[hn, 0], coords[hn, 1], s=32.0, color="red")
            if zoom and V_sel:
                zn = np.array(V_sel, dtype=int)
                xs = coords[zn, 0]
                ys = coords[zn, 1]
                xmin, xmax = float(np.min(xs)), float(np.max(xs))
                ymin, ymax = float(np.min(ys)), float(np.max(ys))
                dx = xmax - xmin
                dy = ymax - ymin
                padf = 0.15
                ax.set_xlim(xmin - padf * (dx if dx > 0 else 1.0), xmax + padf * (dx if dx > 0 else 1.0))
                ax.set_ylim(ymin - padf * (dy if dy > 0 else 1.0), ymax + padf * (dy if dy > 0 else 1.0))
            ax.set_title(title, fontsize=10)
            return fig

        fig = _graph_fig(coords_A, widths, True, 0.8, f"ViewA fixed ({fixed_layout}), {tag}", zoom=False, ghost_coords=None)
        if _on("views_viewA"):
            _safe_fig_save(fig, fig_dir / f"viewA_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _graph_fig(coords_B_vis, None, False, 0.85, f"ViewB induced ({embedding}), {tag}", zoom=False, ghost_coords=(coords_B_ideal if overlay_fixed else None))
        if _on("views_viewB"):
            _safe_fig_save(fig, fig_dir / f"viewB_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _graph_fig(coords_B_vis, None, False, 0.85, f"ViewC zoom selected cell, {tag}", zoom=True, ghost_coords=(coords_B_ideal if overlay_fixed else None))
        if _on("views_viewC"):
            _safe_fig_save(fig, fig_dir / f"viewC_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)

        # DtN/seed heatmaps for selected cell
        Bw = trunk.Bw.get(selected_w, trunk.B0)
        Vw = tuple(int(x) for x in cell_sets.V.get(selected_w, tuple(Bw)))
        Iw = tuple(int(x) for x in cell_sets.I.get(selected_w, tuple()))
        L_n = trunk.laplacian_from_conductances(np.asarray(C[n], dtype=np.float64))
        Lam_g, rep_g = dtn_kron(L_n, Bw, pol)
        Lam_l, rep_l = dtn_local(L_n, Vw, Bw, Iw, pol)
        Lam_g_hat = normalize_Lambda(Lam_g, pol)
        Lam_l_hat = normalize_Lambda(Lam_l, pol)
        if _on("diag_lambda_mats"):
            _safe_np_save(np.asarray(Lam_g_hat, dtype=np.float64), mat_dir / f"Lam_g_hat_{tag}.npy", write_log)
        if _on("diag_lambda_mats"):
            _safe_np_save(np.asarray(Lam_l_hat, dtype=np.float64), mat_dir / f"Lam_l_hat_{tag}.npy", write_log)
        if _on("diag_lambda_mats"):
            _safe_np_save(np.asarray(Lam_g_hat - Lam_l_hat, dtype=np.float64), mat_dir / f"dLam_hat_{tag}.npy", write_log)
        # render heatmaps
        def _hm_fig(A: np.ndarray, title: str):
            fig = plt.figure(figsize=(3.6, 3.0), dpi=160)
            ax = fig.add_subplot(111)
            im = ax.imshow(np.asarray(A, dtype=float), aspect="equal")
            ax.set_title(title, fontsize=10)
            ax.set_xlabel("j")
            ax.set_ylabel("i")
            ax.set_xticks(list(range(A.shape[1])))
            ax.set_yticks(list(range(A.shape[0])))
            if A.shape[0] <= 8 and A.shape[1] <= 8:
                for i in range(A.shape[0]):
                    for j in range(A.shape[1]):
                        v = A[i, j]
                        s = "nan" if not np.isfinite(v) else f"{v:.3g}"
                        ax.text(j, i, s, ha="center", va="center", fontsize=7)
            fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
            return fig

        fig = _hm_fig(Lam_g_hat, f"Lam_g_hat (glob), {tag}")
        if _on("diag_lambda_plots"):
            _safe_fig_save(fig, fig_dir / f"Lam_g_hat_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _hm_fig(Lam_l_hat, f"Lam_l_hat (loc), {tag}")
        if _on("diag_lambda_plots"):
            _safe_fig_save(fig, fig_dir / f"Lam_l_hat_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)
        fig = _hm_fig(Lam_g_hat - Lam_l_hat, f"dLam_hat, {tag}")
        if _on("diag_lambda_plots"):
            _safe_fig_save(fig, fig_dir / f"dLam_hat_{tag}.png", write_log, bbox_inches="tight")
        plt.close(fig)

        # mismatch table for selected k from run_report (no recomputation)
        if step_reports and n < len(step_reports):
            sr = step_reports[n]
            rows = []
            for c_rep in sr.get("cells", []):
                if int(c_rep.get("k", -1)) != int(k_mismatch):
                    continue
                w = tuple(c_rep.get("w", []))
                rows.append(
                    {
                        "addr_str": addr_str(w),
                        "valid": bool(c_rep.get("valid", False)),
                        "mismatch": float(c_rep.get("mismatch", float("nan"))),
                        "kappa": float(c_rep.get("kappa", float("nan"))),
                        "fb_soft": bool(c_rep.get("soft_fallback", False)),
                        "fb_hard": bool(c_rep.get("hard_fallback", False)),
                        "cond_fail_any": bool(c_rep.get("cond_fail_any", False)),
                    }
                )
            dfm = pd.DataFrame(rows)
            if not dfm.empty:
                dfm.sort_values(["addr_str"], inplace=True, kind="mergesort")
                if _on("diag_mismatch_csv"):
                    _safe_df_to_csv(dfm, tab_dir / f"mismatch_k{k_mismatch}_{tag}.csv", write_log)
                # mismatch plots (hist + row heatmap)
                mm = dfm["mismatch"].to_numpy(dtype=float)
                fig = plt.figure(figsize=(7, 3), dpi=140)
                ax = fig.add_subplot(111)
                ax.hist(mm, bins=40)
                ax.set_xlabel("Mismatch")
                ax.set_ylabel("count")
                ax.set_title(f"Mismatch histogram (k={k_mismatch}), {tag}")
                if _on("diag_mismatch_hist"):
                    _safe_fig_save(fig, fig_dir / f"mismatch_hist_k{k_mismatch}_{tag}.png", write_log, bbox_inches="tight")
                plt.close(fig)

                fig = plt.figure(figsize=(7, 1.6), dpi=140)
                ax = fig.add_subplot(111)
                im = ax.imshow(mm.reshape(1, -1), aspect="auto")
                ax.set_yticks([])
                ax.set_xlabel("cell index (sorted by addr_str)")
                ax.set_title(f"Mismatch heatmap (k={k_mismatch}), {tag}", fontsize=10)
                fig.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
                if _on("diag_mismatch_heat"):
                    _safe_fig_save(fig, fig_dir / f"mismatch_heat_k{k_mismatch}_{tag}.png", write_log, bbox_inches="tight")
                plt.close(fig)

                # Δ_n(e)=log(c[n+1]/c[n]) diagnostics (skip last step)
        want_delta = _on("diag_delta_mat") or _on("diag_delta_hist") or _on("diag_delta_heat") or _on("diag_delta_top10")
        if want_delta and (n + 1 < int(C.shape[0])):
            c_n = np.asarray(C[n], dtype=float)
            c_np1 = np.asarray(C[n + 1], dtype=float)
            delta = np.log(c_np1 / (c_n + 1e-300))

            if _on("diag_delta_mat"):
                _safe_np_save(np.asarray(delta, dtype=np.float64), mat_dir / f"delta_{tag}.npy", write_log)

            if _on("diag_delta_hist"):
                fig = plt.figure(figsize=(7, 3), dpi=140)
                ax = fig.add_subplot(111)
                ax.hist(delta.ravel(), bins=40)
                ax.set_xlabel("Δ")
                ax.set_ylabel("count")
                ax.set_title(f"Δ_{n}(e)=log(c[n+1]/c[n]) histogram, {tag}")
                _safe_fig_save(fig, fig_dir / f"delta_hist_{tag}.png", write_log, bbox_inches="tight")
                plt.close(fig)

            if _on("diag_delta_heat"):
                fig = plt.figure(figsize=(7, 1.6), dpi=140)
                ax = fig.add_subplot(111)
                im = ax.imshow(delta.reshape(1, -1), aspect="auto")
                ax.set_yticks([])
                ax.set_xlabel("edge index")
                ax.set_title(f"Δ_{n}(e) heatmap (edge index), {tag}", fontsize=10)
                fig.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
                _safe_fig_save(fig, fig_dir / f"delta_heat_{tag}.png", write_log, bbox_inches="tight")
                plt.close(fig)

            if _on("diag_delta_top10"):
                # top-|Δ| edges table
                idx = np.argsort(-np.abs(delta))[:10]
                top = []
                for ei in idx:
                    u, v = edges[int(ei)]
                    top.append({"edge_idx": int(ei), "u": int(u), "v": int(v), "Delta": float(delta[int(ei)])})
                _safe_df_to_csv(pd.DataFrame(top), tab_dir / f"delta_top10_{tag}.csv", write_log)

    # write non-fatal write fallbacks (if any) before hashing
    log_path = ui_root / "ui_artifacts_write_log.json"
    if write_log:
        n0 = len(write_log)
        _safe_write_text(json.dumps(write_log, indent=2, sort_keys=True), log_path, write_log)
        # if writing the log itself triggered an additional fallback entry, refresh once
        if len(write_log) != n0:
            _safe_write_text(json.dumps(write_log, indent=2, sort_keys=True), log_path, write_log)

    # manifest + hashes (hashes do not include the manifest itself)
    file_hashes: Dict[str, str] = {}
    for p in sorted(ui_root.rglob("*")):
        if not p.is_file():
            continue
        if p.name == "ui_artifacts_manifest.json":
            continue
        file_hashes[str(p.relative_to(outdir))] = sha256_file(p)

    manifest = {
        "schema": "realgraph_oqs.ui_artifacts_manifest.v1",
        "ui_artifacts_root": "ui_artifacts",
        "generated_at_unix": int(time.time()),
        "steps": [int(s) for s in steps],
        "selected_cell": {"addr_str": addr_str(selected_w), "word": list(selected_w)},
        "mismatch_k": int(k_mismatch),
        "write_log": "ui_artifacts_write_log.json" if write_log else None,
        "sha256": file_hashes,
    }
    _safe_write_text(json.dumps(manifest, indent=2, sort_keys=True), ui_root / "ui_artifacts_manifest.json", write_log)

    return ui_root



# -----------------------------------------------------------------------------
# Batch artifacts (G9.4)
# -----------------------------------------------------------------------------
def write_batch_cells(
    outdir: Path,
    cells_df: pd.DataFrame,
    step0_cells: List[Dict[str, Any]],
    delta0: np.ndarray,
    eidx_by_addr: Dict[str, List[int]],
    env_lock: Dict[str, Any],
    trunk,
    cell_sets: CellSets,
    pol: Policy,
    c0: np.ndarray,
    mode_label: str,
    L_max_param: int,
    K_max_param: int,
) -> Tuple[Path, Path]:
    """Write batch_cells.(csv|json) per Definition/Plan (lightweight seed summary).

    - idx in batch output is 1-based.
    - delta_inf(w) := max_{e in E_w^(k)} |Δ_0(e)| with Δ_0(e)=log(c1/c0).
    - seed summary is computed as DtN_{B_w}(L0) with L0 from c0:
        * seed_trace
        * seed_eigs (float list)
        * seed_sha256 (float64 bytes, C-order)
      (Full matrices are intentionally not embedded.)
    """
    from datetime import datetime, timezone
    from realgraph_oqs.oqs.dtn import dtn_kron

    outdir.mkdir(parents=True, exist_ok=True)

    # index by (k, addr_str) for lookup
    idx_map: Dict[Tuple[int, str], Dict[str, Any]] = {(int(c["k"]), addr_str(tuple(c["w"]))): c for c in step0_cells}

    L0 = trunk.laplacian_from_conductances(np.asarray(c0, dtype=np.float64))

    rows_csv = []
    rows_json = []

    # deterministic env_lock hash and run_id surrogate
    env_lock_bytes = json.dumps(env_lock, sort_keys=True, separators=(",", ":")).encode("utf-8")
    env_lock_sha256 = hashlib.sha256(env_lock_bytes).hexdigest()
    run_id = env_lock_sha256  # deterministic, policy/impl defined

    for _, r in cells_df.iterrows():
        k = int(r["k"])
        a = str(r["addr_str"])
        rep = idx_map.get((k, a), None)
        if rep is None:
            rep = {
                "w": parse_addr(a),
                "k": k,
                "valid": False,
                "hard_fallback": False,
                "soft_fallback": False,
                "cond_fail_any": False,
                "mismatch": float("nan"),
                "kappa": float("nan"),
                "kappa_raw": float("nan"),
            }

        w = tuple(rep["w"])
        eidx = eidx_by_addr.get(a, [])
        if len(eidx) == 0:
            delta_inf = 0.0
        else:
            delta_inf = float(np.max(np.abs(delta0[np.array(eidx, dtype=int)])))

        # Seed summary
        Bw = cell_sets.B.get(w, tuple())
        Seed, dtn_rep = dtn_kron(L0, B=tuple(Bw), pol=pol)
        Seed = np.asarray(Seed, dtype=np.float64)
        seed_sha = hashlib.sha256(Seed.tobytes(order="C")).hexdigest()
        # symmetric eigs of symmetrized seed
        S = 0.5 * (Seed + Seed.T)
        try:
            eigs = np.linalg.eigvalsh(S).astype(float).tolist()
        except Exception:
            eigs = []

        row = {
            "idx": int(r["idx"]) + 1,
            "k": k,
            "addr_str": a,
            "card_V": int(r["card_V"]),
            "card_E": int(r["card_E"]),
            "kappa": float(rep.get("kappa", float("nan"))),
            "delta_inf": float(delta_inf),
            "valid": bool(rep.get("valid", False)),
            "solve_fail": bool(not rep.get("valid", False)),
            "cond_fail": bool(rep.get("cond_fail_any", False)),
            "fb_soft": bool(rep.get("soft_fallback", False)),
            "fb_hard": bool(rep.get("hard_fallback", False)),
            "wall_ms": 0.0,
        }
        rows_csv.append(row)

        rows_json.append(
            {
                **row,
                "seed": {
                    "Bw": list(map(int, Bw)),
                    "trace": float(getattr(dtn_rep, "trace", float("nan"))),
                    "cond_fail": bool(getattr(dtn_rep, "cond_fail", False)),
                    "valid": bool(getattr(dtn_rep, "valid", False)),
                    "eigs_sym": eigs,
                    "sha256": seed_sha,
                },
                "mismatch": float(rep.get("mismatch", float("nan"))),
                "kappa_raw": float(rep.get("kappa_raw", float("nan"))),
            }
        )

    df = pd.DataFrame(rows_csv)
    csv_p = outdir / "batch_cells.csv"
    json_p = outdir / "batch_cells.json"

    write_log: List[Dict[str, Any]] = []
    csv_p = _safe_df_to_csv(df, csv_p, write_log)

    payload = {
        "schema_id": "realgraph_oqs.batch_cells",
        "schema_version": "1.0",
        "definition_id": "REAL-Graph_OQS_v4_rev8",
        "run_id": run_id,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "L_max": int(L_max_param),
        "K_max": int(K_max_param),
        "mode": mode_label,
        "ordering": "sorted by (k asc, addr_str asc)",
        "idx_base": 1,
        "delta_inf_definition": "max_{e in E_w^(k)} |Δ_0(e)|, Δ_0(e)=log(c1/c0)",
        "env_lock_sha256": env_lock_sha256,
        "cells": rows_json,
    }
    json_p = _safe_write_text(json.dumps(payload, indent=2, sort_keys=True), json_p, write_log)

    # file hashes (include env_lock as well, if present)
    hashes = {
        str(Path(csv_p).name): sha256_file(Path(csv_p)),
        str(Path(json_p).name): sha256_file(Path(json_p)),
        "env_lock.json": env_lock_sha256,
    }
    _safe_write_text(
        json.dumps({"schema_id": "realgraph_oqs.file_hashes", "schema_version": "1.0", "sha256": hashes}, indent=2, sort_keys=True),
        outdir / "batch_hashes.json",
        write_log,
    )
    payload["file_hashes"] = hashes
    _safe_write_text(json.dumps(payload, indent=2, sort_keys=True), json_p, write_log)

    # write non-fatal write fallbacks for batch mode (if any)
    if write_log:
        _safe_write_text(json.dumps(write_log, indent=2, sort_keys=True), outdir / "batch_write_log.json", write_log)

    return csv_p, json_p


# -----------------------------------------------------------------------------
# Main app
# -----------------------------------------------------------------------------
def main() -> None:
    st = _try_import_streamlit()

    st.set_page_config(page_title="REAL-Graph OQS (SG-only)", layout="wide")
    st.title("REAL-Graph OQS — SG-only (deterministic, v4_rev8)")

    pol = Policy()

    with st.sidebar:
        st.header("Run parameters")
        L_max = st.slider(
            "L_max",
            min_value=1,
            max_value=8,
            value=3,
            step=1,
            help="Truncation level of the IDEAL SG trunk. Higher L_max increases nodes/edges and runtime.",
        )
        N = st.number_input(
            "N (steps)",
            min_value=1,
            max_value=5000,
            value=20,
            step=1,
            help="Number of update steps n=0..N. Upper bound is 5000 to prevent runaway runtime.",
        )
        stride = st.slider(
            "Schrittweite (plots)",
            min_value=1,
            max_value=20,
            value=1,
            step=1,
            help="Plot/record every `stride` steps (reduces UI load for large N). The simulation still runs all steps.",
        )
        dp = st.selectbox(
            "d_p",
            options=[1, 2, 3],
            index=0,
            help="Internal degeneracy factor per boundary vertex (effective Hilbert factor). Default d_p=1.",
        )
        trajectory = st.checkbox(
            "Trajectories (θ-dynamics)",
            value=True,
            help="Deterministic θ-driven action selection (not a stochastic quantum-trajectory unravelling).",
        )
        tail_cg_B0 = st.checkbox(
            "Tail coarse-grain (project k > L_max onto B0 at N=0)",
            value=True,
            help="One-time initialization: approximate the truncated IDEAL tail (k > L_max) as an effective response on B0. Affects C[0] only.",
        )
        tail_cg_method = "b0_uniform"
        if tail_cg_B0:
            tail_cg_method = st.selectbox(
                "Tail coarse-grain method",
                options=["b0_uniform", "series_shells"],
                index=1,
                format_func=lambda x: {
                    "b0_uniform": "B0-uniform: scale only edges incident to B0",
                    "series_shells": "Series-shells: geometric decay by distance to B0 (r_star)",
                }.get(str(x), str(x)),
                help=(
                    "b0_uniform matches E_B0 by scaling only B0-incident edges. "
                    "series_shells scales all edges as c(e) <- c(e)*exp(lambda*r_star^{d(e,B0)}), then matches E_B0."
                ),
            )
        st.subheader("Visualization")
        # Per plan: choose layout/embedding methods so they can be selected for both View A and View B.
        # View A: computed once from IDEAL weights; View B: computed from current REAL weights (induced geometry).
        # IFS embedding view is intentionally not exposed in the GUI (request: remove IFS view).
        layout_opts = ["harmonic", "mds_resistance"]
        fixed_layout = st.selectbox(
            "View A layout method",
            options=layout_opts,
            index=0,
            help="View A uses an IDEAL-based fixed layout (computed once). Choose harmonic or resistance-MDS embedding.",
        )
        embedding = st.selectbox(
            "View B layout method",
            options=layout_opts,
            index=1,
            help="View B uses the current REAL weights each step to compute an induced geometry embedding.",
        )
        align_B = st.checkbox(
            "Align View B to IDEAL ghost (rigid Procrustes)",
            value=True,
            help="Rigidly align View B embedding to the IDEAL reference (rotation/translation only).",
        )
        deform_gamma = st.slider(
            "Deformation magnifier γ (View B)",
            min_value=1.0,
            max_value=50.0,
            value=10.0,
            step=0.5,
            help="Pure visualization scaling of (REAL−IDEAL) displacement in View B/C; does not affect dynamics.",
        )
        overlay_fixed = st.checkbox(
            "Overlay IDEAL ghost in View B/C (ghost)",
            value=True,
            help="Show the IDEAL reference overlay for comparison. Visualization only.",
        )

        st.caption("View A: fixed layout (independent). View B/C: induced geometry; γ magnifies (REAL-IDEAL) visually only.")

        st.subheader("Edge thickness (View A only)")
        thickness_mode = st.selectbox(
            "Thickness ∝",
            options=["c_n(e)", "c_n(e)/c_0(e)"],
            index=0,
            help="Edge thickness in View A: absolute conductance c_n(e) or relative change c_n(e)/c_0(e).",
        )
        normalize_widths = st.checkbox(
            "Normalize thickness per step",
            value=True,
            help="Rescale edge widths per displayed step to improve visibility (does not affect numbers).",
        )
        width_power = st.slider(
            "Thickness contrast (power)",
            min_value=0.5,
            max_value=4.0,
            value=1.0,
            step=0.05,
            help="Nonlinear contrast on thickness mapping (higher emphasizes differences). Visualization only.",
        )
        w_min = st.slider(
            "Min edge width",
            min_value=0.05,
            max_value=2.0,
            value=0.25,
            step=0.05,
            help="Lower clamp for edge width in View A (visualization).",
        )
        w_max = st.slider(
            "Max edge width",
            min_value=1.0,
            max_value=12.0,
            value=6.0,
            step=0.25,
            help="Upper clamp for edge width in View A (visualization).",
        )
        outdir_str = st.text_input(
            "Output directory",
            value="runs/gui_run",
            help="Base directory for run outputs (reports, exports, and optional ui_artifacts).",
        )
        run_btn = st.button("Run simulation")

        st.divider()
        st.header("Subsystem selection")
        mode = st.radio(
            "Mode",
            options=["General (select cell)", "Special (w = EMPTY)"],
            index=0,
            help="General: select a subsystem cell w. Special: w=EMPTY (no extra outside beyond B0 within the trunk).",
        )
        show_tree = st.checkbox(
            "Show prefix tree (optional)",
            value=False,
            help="Show the address prefix tree of available cells (UI-only; may slow down for larger L_max).",
        )

        # Export is handled in a dedicated tab (see below), so it does not compete with the
        # parameter/selection controls in the sidebar.

    outdir = Path(outdir_str)

    # Build trunk + cell table deterministically for selection UI
    trunk = build_sg_trunk(L_max=int(L_max))
    lcp = compute_lcp_measure(trunk)
    cell_sets = build_cell_sets(trunk, lcp)
    cells_df = build_cells_table(trunk, lcp, cell_sets)
    K_max = int(lcp.K_max)

    # Selection UI: filter by k (default K_max)
    st.subheader("Cells (canonical order)")
    if mode.startswith("Special"):
        k_filter = 0
        st.info("Special mode: subsystem cell is fixed to w=EMPTY (selection disabled, k=0).")
    else:
        k_filter = st.selectbox("Filter level k", options=list(range(0, K_max + 1)), index=min(K_max, K_max))
    df_show = cells_df[cells_df["k"] == int(k_filter)].copy()

    selected_w: Tuple[int, ...] = tuple()  # default empty
    if mode.startswith("Special"):
        st.info("Special mode: subsystem cell is fixed to w=EMPTY (selection disabled).")
        selected_w = tuple()
        st.dataframe(df_show[["idx", "k", "addr_str", "card_E", "card_V"]], use_container_width=True)
    else:
        # add checkbox selection column
        df_ed = df_show[["idx", "k", "addr_str", "card_E", "card_V"]].copy()
        df_ed.insert(0, "select", False)

        edited = st.data_editor(
            df_ed,
            hide_index=True,
            use_container_width=True,
            column_config={"select": st.column_config.CheckboxColumn(required=False)},
            disabled=["idx", "k", "addr_str", "card_E", "card_V"],
            key="cell_table_editor",
        )
        chosen = edited[edited["select"] == True]
        if len(chosen) == 1:
            a = str(chosen.iloc[0]["addr_str"])
            selected_w = parse_addr(a)
        else:
            # default to first row in filtered set
            a = str(df_show.iloc[0]["addr_str"]) if len(df_show) else "EMPTY"
            selected_w = parse_addr(a)
            st.warning("Select exactly one row; using default cell: " + a)

        st.caption("Table columns: (k, addr_str, |E_w^(k)|, |V_w^(k)|). Selection highlights E_w^(k), V_w^(k).")

    # Optional tree view
    if show_tree:
        st.subheader("Prefix tree (optional UI artifact)")
        # Build adjacency list Parent -> Children for displayed level filter
        words = [parse_addr(a) for a in cells_df["addr_str"].to_list()]
        tree: Dict[str, List[str]] = {}
        for w in words:
            p = parent_word(w)
            ps = "ROOT" if p is None else addr_str(p)
            tree.setdefault(ps, [])
            tree[ps].append(addr_str(w))
        for k in list(tree.keys()):
            tree[k] = sorted(tree[k])
        st.json({"schema": "realgraph_oqs.cells_tree.v1", "adj": tree, "selected": addr_str(selected_w)})

    # Run simulation
    if run_btn:
        outdir.mkdir(parents=True, exist_ok=True)
        run_simulation(
            outdir=outdir,
            L_max=int(L_max),
            N=int(N),
            dp=int(dp),
            trajectory=bool(trajectory),
            mode=str(mode),
            subsystem_cell={"k": int(k_filter), "word": list(selected_w), "addr_str": addr_str(selected_w)},
            update_scope="selected_cell",
            subsystem_word=tuple(selected_w),
            tail_coarse_grain_B0=bool(tail_cg_B0),
            tail_cg_method=str(tail_cg_method),
        )
        st.success(f"Run finished: {outdir}")

    # Load artifacts if present
    run_report_path = outdir / "run_report.json"
    cond_path = outdir / "conductances.npy"
    edges_path = outdir / "edges.csv"

    if run_report_path.exists() and cond_path.exists() and edges_path.exists():
        run_report = json.loads(run_report_path.read_text(encoding="utf-8"))
        ensure_env_lock_json(outdir, run_report)
        C = np.load(cond_path)
        edges_df = pd.read_csv(edges_path)
        u_col = "u" if "u" in edges_df.columns else ("src" if "src" in edges_df.columns else edges_df.columns[1])
        v_col = "v" if "v" in edges_df.columns else ("dst" if "dst" in edges_df.columns else edges_df.columns[2])
        edges = [(int(u), int(v)) for u, v in zip(edges_df[u_col], edges_df[v_col])]

        # UI state persisted
        ui_state = {
            "schema": "realgraph_oqs.ui_state.v1",
            "L_max": int(L_max),
            "N": int(N),
            "dp": int(dp),
            "trajectory": bool(trajectory),
            "tail_coarse_grain_B0": bool(tail_cg_B0),
            "tail_cg_method": (str(tail_cg_method) if tail_cg_B0 else None),
            "fixed_layout": str(fixed_layout),
            "embedding": str(embedding),
            "align_B": bool(align_B),
            "deform_gamma": float(deform_gamma),
            "overlay_fixed": bool(overlay_fixed),
            "thickness_mode": str(thickness_mode),
            "normalize_widths": bool(normalize_widths),
            "width_power": float(width_power),
            "w_min": float(w_min),
            "w_max": float(w_max),
            "mode": str(mode),
            "subsystem_cell": {"k": int(k_filter), "addr_str": addr_str(selected_w), "word": list(selected_w)},
        }
        (outdir / "ui_state.json").write_text(json.dumps(ui_state, indent=2, sort_keys=True), encoding="utf-8")


        run_meta = {
            "schema": "realgraph_oqs.run_meta.v1",
            "definition_id": "REAL-Graph_OQS_v4_rev8",
            "params": {"L_max": int(L_max), "N": int(N), "dp": int(dp), "trajectory": bool(trajectory)},
            "ui": {
                "tail_coarse_grain_B0": bool(tail_cg_B0),
                "tail_cg_method": (str(tail_cg_method) if tail_cg_B0 else None),
                "fixed_layout": str(fixed_layout),
                "embedding": str(embedding),
                "align_B": bool(align_B),
                "deform_gamma": float(deform_gamma),
                "overlay_fixed": bool(overlay_fixed),
                "thickness_mode": str(thickness_mode),
                "normalize_widths": bool(normalize_widths),
                "width_power": float(width_power),
                "w_min": float(w_min),
                "w_max": float(w_max),
                "mode": str(mode),
                "subsystem_cell": {"k": int(k_filter), "addr_str": addr_str(selected_w), "word": list(selected_w)},
            },
            "artifacts": {"run_report": "run_report.json", "conductances": "conductances.npy", "edges": "edges.csv", "env_lock": "env_lock.json"},
        }
        (outdir / "run_meta.json").write_text(json.dumps(run_meta, indent=2, sort_keys=True), encoding="utf-8")


        # Load step reports once (used across tabs)
        step_reports: List[Dict[str, Any]] = run_report.get("step_reports", [])

        # Select display step
        st.subheader("Step selection")
        n_display = st.slider(
            "Display step n",
            min_value=0,
            max_value=int(C.shape[0] - 1),
            value=int(C.shape[0] - 1),
            step=1,
        )
        n_display = int(n_display)

        # Selected cell sets (always defined, used for highlighting + zoom)
        E_idx_sel, V_sel = edge_and_node_sets_for_cell(trunk, cell_sets, selected_w)
        E_set = set(E_idx_sel)
        V_set = set(V_sel)

        # Build independent coordinates for View A (fixed layout) and View B/C (induced geometry)
        c_ideal = np.ones(len(edges), dtype=np.float64)

        # View A: fixed layout computed from IDEAL weights only
        gauges_A = build_gauges(
            trunk=trunk,
            c_ideal=c_ideal,
            c_real=np.asarray(C[n_display], dtype=np.float64),
            embedding=str(embedding),
            fixed_layout=str(fixed_layout),
            pol=pol,
        )
        coords_A = np.array(gauges_A["fixed_coords"], dtype=float)

        # View B/C: induced geometry; compare REAL vs IDEAL in the same embedding gauge
        gauges_B0 = build_gauges(
            trunk=trunk,
            c_ideal=c_ideal,
            c_real=c_ideal,
            embedding=str(embedding),
            fixed_layout=str(fixed_layout),
            pol=pol,
        )
        coords_B_ideal = np.array(gauges_B0["real_coords"], dtype=float)

        gauges_B = build_gauges(
            trunk=trunk,
            c_ideal=c_ideal,
            c_real=np.asarray(C[n_display], dtype=np.float64),
            embedding=str(embedding),
            fixed_layout=str(fixed_layout),
            pol=pol,
        )
        coords_B_real = np.array(gauges_B["real_coords"], dtype=float)
        coords_B_real_aligned = _procrustes_rigid(coords_B_real, coords_B_ideal) if bool(align_B) else coords_B_real
        coords_B_vis = coords_B_ideal + float(deform_gamma) * (coords_B_real_aligned - coords_B_ideal)

        tabs = st.tabs(["Views", "Subsystem", "Diagnostics", "Audit", "Tables", "Export"])

        # -----------------------------------------------------------------
        # Views
        # -----------------------------------------------------------------
        with tabs[0]:
            # Edge thickness (dicker = höhere Leitfähigkeit)
            c_step = np.asarray(C[n_display], dtype=float)
            c0 = np.asarray(C[0], dtype=float)
            if thickness_mode == "c_n(e)/c_0(e)":
                values = c_step / (c0 + 1e-300)
            else:
                values = c_step

            if normalize_widths:
                vmin = float(np.min(values))
                vmax = float(np.max(values))
            else:
                if thickness_mode == "c_n(e)/c_0(e)":
                    all_vals = np.asarray(C, dtype=float) / (c0.reshape(1, -1) + 1e-300)
                else:
                    all_vals = np.asarray(C, dtype=float)
                vmin = float(np.min(all_vals))
                vmax = float(np.max(all_vals))

            widths = _widths_scaled(values, w_min=float(w_min), w_max=float(w_max), vmin=vmin, vmax=vmax, power=float(width_power))

            colA, colB = st.columns(2)
            with colA:
                st.markdown("### View A — weight field on fixed layout")
                plot_graph(
                    st,
                    coords=coords_A,
                    edges=edges,
                    widths=widths,
                    encode_widths=True,
                    title=f"Edges thickness ∝ conductance, fixed coords={gauges_A.get('fixed_method','?')}, n={n_display}",
                    highlight_edges=E_set,
                    highlight_nodes=V_set,
                    node_size=10.0,
                )
            with colB:
                st.markdown("### View B — induced geometry (visual only)")
                plot_graph(
                    st,
                    coords=coords_B_vis,
                    edges=edges,
                    widths=None,
                    encode_widths=False,
                    base_width=0.85,
                    title=f"Coords={gauges_B['method']}, align={bool(align_B)}, γ={float(deform_gamma):.1f}, n={n_display}",
                    highlight_edges=E_set,
                    highlight_nodes=V_set,
                    node_size=10.0,
                    ghost_coords=(coords_B_ideal if bool(overlay_fixed) else None),
                )

            st.caption(
                "View A: Kantenstärke kodiert Leitwert (dicker = höher). "
                + ("Normierung: pro Schritt." if bool(normalize_widths) else "Normierung: global über alle Schritte.")
                + f"  (mode={thickness_mode}, min={float(np.min(values)):.3g}, max={float(np.max(values)):.3g}). "
                + "View B: konstante Kantenstärke (keine Leitwert-/Farbkodierung), nur Geometrie (Koordinaten) ändert sich."
            )

            st.markdown("### View C — zoom on selected cell (full width)")
            plot_graph(
                st,
                coords=coords_B_vis,
                edges=edges,
                widths=None,
                encode_widths=False,
                base_width=0.85,
                title=f"Zoom: selected cell (induced geometry), align={bool(align_B)}, γ={float(deform_gamma):.1f}, n={n_display}",
                highlight_edges=E_set,
                highlight_nodes=V_set,
                node_size=10.0,
                ghost_coords=(coords_B_ideal if bool(overlay_fixed) else None),
                zoom_nodes=list(V_sel),
            )

        # -----------------------------------------------------------------
        # Subsystem (DtN/seed)
        # -----------------------------------------------------------------
        with tabs[1]:
            st.subheader("Selected subsystem (observer perspective)")
            st.caption(
                "For the selected cell w, the definition compares global DtN (trace out V\\B_w) vs local DtN (trace out I_w within V_w), both acting on B_w."
            )
            Bw = trunk.Bw.get(selected_w, trunk.B0)
            Vw = tuple(int(x) for x in cell_sets.V.get(selected_w, tuple(Bw)))
            Iw = tuple(int(x) for x in cell_sets.I.get(selected_w, tuple()))
            c_n = np.asarray(C[n_display], dtype=np.float64)
            L_n = trunk.laplacian_from_conductances(c_n)

            Lam_g, rep_g = dtn_kron(L_n, Bw, pol)
            Lam_l, rep_l = dtn_local(L_n, Vw, Bw, Iw, pol)
            Lam_g_hat = normalize_Lambda(Lam_g, pol)
            Lam_l_hat = normalize_Lambda(Lam_l, pol)

            # Compare to scalar report (if present)
            rep_cell = None
            try:
                cells_here = step_reports[n_display].get("cells", [])
                for c_rep in cells_here:
                    if tuple(c_rep.get("w", [])) == tuple(selected_w):
                        rep_cell = c_rep
                        break
            except Exception:
                rep_cell = None

            # Scalar mismatch from channels (may differ slightly from report due to normalization)
            try:
                Phi_g, _, _ = channel_from_Lambda_hat(Lam_g_hat, dp=int(dp), pol=pol, dt=1.0)
                Phi_l, _, _ = channel_from_Lambda_hat(Lam_l_hat, dp=int(dp), pol=pol, dt=1.0)
                mismatch_val, _, _, _ = mismatch_from_channels(
                    Phi_g,
                    Phi_l,
                    d=3 * int(dp),
                    L_max=trunk.L_max,
                    r_star=pol.r_star,
                    pol=pol,
                )
            except Exception:
                mismatch_val = float("nan")

            c1, c2, c3 = st.columns(3)
            with c1:
                plot_heatmap(st, Lam_g_hat, title="Λ̂_glob on B_w (seed)")
                st.caption(f"DtN ok={bool(rep_g.valid)}, COND_FAIL={bool(rep_g.cond_fail)}, tr={float(rep_g.trace):.6g}")
            with c2:
                plot_heatmap(st, Lam_l_hat, title="Λ̂_loc on B_w (inside V_w)")
                st.caption(f"DtN ok={bool(rep_l.valid)}, COND_FAIL={bool(rep_l.cond_fail)}, tr={float(rep_l.trace):.6g}")
            with c3:
                plot_heatmap(st, Lam_g_hat - Lam_l_hat, title="ΔΛ̂ = Λ̂_glob − Λ̂_loc")
                ev_g = np.linalg.eigvalsh(Lam_g_hat)
                ev_l = np.linalg.eigvalsh(Lam_l_hat)
                st.write(
                    {
                        "mismatch(channel)": mismatch_val,
                        "mismatch(report)": (None if rep_cell is None else float(rep_cell.get("mismatch", float("nan")))),
                        "kappa(report)": (None if rep_cell is None else float(rep_cell.get("kappa", float("nan")))),
                        "theta_in(report)": (None if rep_cell is None else rep_cell.get("theta_in", None)),
                        "theta_out(report)": (None if rep_cell is None else rep_cell.get("theta_out", None)),
                        "omega(report)": (None if rep_cell is None else rep_cell.get("omega", None)),
                        "eig(Λ̂_glob)": [float(x) for x in ev_g],
                        "eig(Λ̂_loc)": [float(x) for x in ev_l],
                    }
                )

            if n_display > 0:
                dc = np.max(np.abs(C[n_display] - C[n_display - 1]))
            else:
                dc = 0.0
            st.caption(f"Max |Δc| vs previous step: {float(dc):.3g}.")

            # -------------------------------------------------------------
            # Local dynamics (selected cell): Δ_n(e) time-series + histogram
            # -------------------------------------------------------------
            st.markdown("---")
            st.subheader("Local dynamics in selected cell")
            E_idx_cell = tuple(int(e) for e in cell_sets.E_idx.get(tuple(selected_w), tuple()))
            if len(E_idx_cell) == 0:
                st.info("Selected cell has no edge-set E_w^(k) in this trunk (nothing to plot).")
            elif C.shape[0] < 2:
                st.info("N=0: no Δ_n(e) available (need at least two conductance snapshots).")
            else:
                # Δ_n(e) = log(c[n+1]/c[n]) for n=0..N-1
                import matplotlib.pyplot as plt
                eps = 1e-300
                d_all = np.log((np.asarray(C[1:], dtype=float) + eps) / (np.asarray(C[:-1], dtype=float) + eps))
                d_cell = d_all[:, list(E_idx_cell)]  # shape (N, |E_cell|)

                # summary time-series for the selected cell
                ts = {
                    "max|Δ|": np.max(np.abs(d_cell), axis=1),
                    "mean|Δ|": np.mean(np.abs(d_cell), axis=1),
                    "rms(Δ)": np.sqrt(np.mean(d_cell**2, axis=1)),
                }
                plot_timeseries(st, ts, "Selected cell: Δ-summary over time", "value", x=list(range(d_cell.shape[0])))

                # top-m edges by max |Δ| over time
                m_max = min(25, d_cell.shape[1])
                top_m = st.slider("Top-m edges (by max |Δ| over n)", min_value=1, max_value=int(m_max), value=int(min(12, m_max)))

                max_abs = np.max(np.abs(d_cell), axis=0)
                mean_abs = np.mean(np.abs(d_cell), axis=0)
                order = np.argsort(-max_abs)
                sel = order[: int(top_m)]

                rows = []
                for j in sel:
                    ei = int(E_idx_cell[j])
                    u, v = edges[ei]
                    rows.append(
                        {
                            "edge_index": ei,
                            "u": int(u),
                            "v": int(v),
                            "max_abs_delta": float(max_abs[j]),
                            "mean_abs_delta": float(mean_abs[j]),
                        }
                    )
                df_top = pd.DataFrame(rows)
                st.dataframe(df_top, use_container_width=True)

                st.caption("Sparklines: Δ_n(e)=log(c[n+1]/c[n]) for the top-m edges in the selected cell.")
                n_steps = d_cell.shape[0]
                x = np.arange(n_steps)
                cols_per_row = 3
                for r0 in range(0, len(sel), cols_per_row):
                    cols = st.columns(min(cols_per_row, len(sel) - r0))
                    for ci, j in enumerate(sel[r0 : r0 + cols_per_row]):
                        ei = int(E_idx_cell[int(j)])
                        u, v = edges[ei]
                        fig = plt.figure(figsize=(3.4, 1.3), dpi=140)
                        ax = fig.add_subplot(111)
                        ax.plot(x, d_cell[:, int(j)], linewidth=1.0)
                        ax.axhline(0.0, linewidth=0.8)
                        ax.set_title(f"e={ei} ({int(u)}-{int(v)})", fontsize=9)
                        ax.set_xlabel("n", fontsize=8)
                        ax.set_ylabel("Δ", fontsize=8)
                        ax.tick_params(labelsize=7)
                        cols[ci].pyplot(fig, clear_figure=True)
                        plt.close(fig)

                # histogram at a chosen step
                n_hist = st.slider(
                    "Histogram step n (uses Δ_n from c[n+1]/c[n])",
                    min_value=0,
                    max_value=int(d_cell.shape[0] - 1),
                    value=int(min(max(n_display - 1, 0), d_cell.shape[0] - 1)),
                    step=1,
                    key="cell_hist_n",
                )
                n_hist = int(n_hist)
                vals = np.asarray(d_cell[n_hist, :], dtype=float)
                plot_hist(st, vals, f"Selected cell: Δ_{n_hist}(e) histogram (cell edges)", "Δ")
                st.write(
                    {
                        "n": n_hist,
                        "edges_in_cell": int(vals.size),
                        "max_abs": float(np.max(np.abs(vals))),
                        "mean_abs": float(np.mean(np.abs(vals))),
                        "rms": float(np.sqrt(np.mean(vals**2))),
                    }
                )

        # -----------------------------------------------------------------
        # Diagnostics
        # -----------------------------------------------------------------
        with tabs[2]:
            st.subheader("Diagnostics & plots (G9.5)")
            idxs = []
            N = 0
            if step_reports:
                n_sr = int(len(step_reports))
                n_c = int(C.shape[0])
                N = int(min(n_sr, n_c))
                stride_i = max(1, int(stride))
                idxs = list(range(0, N, stride_i))

            if step_reports and N > 0:
                Etot_full = [float(sr["lambda_report"]["achieved_E_B0_tot"]) for sr in step_reports[:N]]
                Etot = [Etot_full[i] for i in idxs]
                p_soft_full = [float(sr["p_fb_soft"]) for sr in step_reports[:N]]
                p_soft = [p_soft_full[i] for i in idxs]
                p_hard_full = [float(sr["p_fb_hard"]) for sr in step_reports[:N]]
                p_hard = [p_hard_full[i] for i in idxs]
                p_mreg_full = [float(sr["p_mreg"]) for sr in step_reports[:N]]
                p_mreg = [p_mreg_full[i] for i in idxs]

                c_min_full = [float(np.min(C[n])) for n in range(N)]
                c_min_ts = [c_min_full[i] for i in idxs]
                c_med_full = [float(np.median(C[n])) for n in range(N)]
                c_med_ts = [c_med_full[i] for i in idxs]
                c_max_full = [float(np.max(C[n])) for n in range(N)]
                c_max_ts = [c_max_full[i] for i in idxs]

                plot_timeseries(st, {"Etot_B0": Etot}, "Boundary total energy Etot_B0,n", "Etot", x=idxs)
                plot_timeseries(st, {"p_fb_soft": p_soft, "p_fb_hard": p_hard, "p_mreg": p_mreg}, "Gate/fallback rates per step", "rate", x=idxs)
                plot_timeseries(st, {"min(c)": c_min_ts, "median(c)": c_med_ts, "max(c)": c_max_ts}, "Conductance summary", "c", x=idxs)
            else:
                idxs = []

            # Δ_n(e)=log(c_{n+1}/c_n)
            if C.shape[0] >= 2:
                n_delta = st.slider(
                    "Δ-step n (uses c[n+1]/c[n])",
                    min_value=0,
                    max_value=int(C.shape[0] - 2),
                    value=int(C.shape[0] - 2),
                    step=1,
                    key="delta_n",
                )
                n_delta = int(n_delta)
                delta = np.log(np.asarray(C[n_delta + 1], dtype=float) / (np.asarray(C[n_delta], dtype=float) + 1e-300))
                plot_hist(st, delta, f"Δ_{n_delta}(e)=log(c[n+1]/c[n]) histogram", "Δ")
                plot_heatmap_row(st, delta, f"Δ_{n_delta}(e) heatmap (edge index)", "edge index")
            else:
                delta = np.zeros(len(edges), dtype=float)

        # -----------------------------------------------------------------
        # Audit (Traceability metrics)
        # -----------------------------------------------------------------
        with tabs[3]:
            st.subheader("Audit / Traceability")
            st.caption(
                "These metrics are written by the numerical driver into run_report.json per step. "
                "They are UI-visible only and do not affect the physics. "
                "Interpretation: 'before' refers to c_n, 'after' refers to c_{n+1} after applying the update at step n."
            )

            if not step_reports:
                st.info("No step_reports found (N=0 or missing report).")
            else:
                Nsr = int(len(step_reports))
                rows = []
                for sr_i in step_reports:
                    n_i = int(sr_i.get("n", -1))
                    sym = sr_i.get("symmetry_metrics", {}) or {}
                    sc = sr_i.get("scale_break_metrics", {}) or {}

                    def _get(d, keys, default=float("nan")):
                        cur = d
                        for k in keys:
                            if not isinstance(cur, dict) or (k not in cur):
                                return default
                            cur = cur[k]
                        try:
                            return float(cur)
                        except Exception:
                            return default

                    # boundary symmetry proxy
                    b0_var_before = _get(sym, ["before", "boundary", "var_across_vertex_means"], float("nan"))
                    b0_var_after = _get(sym, ["after", "boundary", "var_across_vertex_means"], float("nan"))
                    b0_union_mean_before = _get(sym, ["before", "boundary", "union", "mean"], float("nan"))
                    b0_union_mean_after = _get(sym, ["after", "boundary", "union", "mean"], float("nan"))
                    b0_union_var_before = _get(sym, ["before", "boundary", "union", "var"], float("nan"))
                    b0_union_var_after = _get(sym, ["after", "boundary", "union", "var"], float("nan"))

                    # cell-orbit proxy over k-levels
                    orb_avg_before = _get(sym, ["before", "cell_orbits", "avg_var_over_k"], float("nan"))
                    orb_avg_after = _get(sym, ["after", "cell_orbits", "avg_var_over_k"], float("nan"))
                    orb_max_before = _get(sym, ["before", "cell_orbits", "max_var_over_k"], float("nan"))
                    orb_max_after = _get(sym, ["after", "cell_orbits", "max_var_over_k"], float("nan"))
                    trunc_before = bool(((sym.get("before", {}) or {}).get("cell_orbits", {}) or {}).get("truncated", False))
                    trunc_after = bool(((sym.get("after", {}) or {}).get("cell_orbits", {}) or {}).get("truncated", False))

                    # scale-break: log-linear fit slope and errors
                    slope_before = _get(sc, ["before", "fit", "b"], float("nan"))
                    slope_after = _get(sc, ["after", "fit", "b"], float("nan"))
                    rmse_before = _get(sc, ["before", "fit", "rmse"], float("nan"))
                    rmse_after = _get(sc, ["after", "fit", "rmse"], float("nan"))
                    rmse0_before = _get(sc, ["before", "fit", "rmse_zero_slope"], float("nan"))
                    rmse0_after = _get(sc, ["after", "fit", "rmse_zero_slope"], float("nan"))
                    logstd_before = _get(sc, ["before", "log_std"], float("nan"))
                    logstd_after = _get(sc, ["after", "log_std"], float("nan"))

                    rows.append(
                        {
                            "n": n_i,
                            "b0_var_before": b0_var_before,
                            "b0_var_after": b0_var_after,
                            "b0_union_mean_before": b0_union_mean_before,
                            "b0_union_mean_after": b0_union_mean_after,
                            "b0_union_var_before": b0_union_var_before,
                            "b0_union_var_after": b0_union_var_after,
                            "cell_orbit_avg_before": orb_avg_before,
                            "cell_orbit_avg_after": orb_avg_after,
                            "cell_orbit_max_before": orb_max_before,
                            "cell_orbit_max_after": orb_max_after,
                            "cell_orbit_trunc_before": trunc_before,
                            "cell_orbit_trunc_after": trunc_after,
                            "scale_slope_before": slope_before,
                            "scale_slope_after": slope_after,
                            "scale_rmse_before": rmse_before,
                            "scale_rmse_after": rmse_after,
                            "scale_rmse0_before": rmse0_before,
                            "scale_rmse0_after": rmse0_after,
                            "scale_logstd_before": logstd_before,
                            "scale_logstd_after": logstd_after,
                        }
                    )

                audit_df = pd.DataFrame(rows)
                if not audit_df.empty:
                    audit_df.sort_values(["n"], inplace=True, kind="mergesort")
                    st.dataframe(audit_df, use_container_width=True, hide_index=True)

                    x = [int(v) for v in audit_df["n"].to_list()]
                    plot_timeseries(
                        st,
                        {
                            "B0 var (before)": audit_df["b0_var_before"].to_list(),
                            "B0 var (after)": audit_df["b0_var_after"].to_list(),
                        },
                        "B0 symmetry proxy: variance across B0-vertex means",
                        "var",
                        x=x,
                    )
                    plot_timeseries(
                        st,
                        {
                            "cell_orbit avg var (before)": audit_df["cell_orbit_avg_before"].to_list(),
                            "cell_orbit avg var (after)": audit_df["cell_orbit_avg_after"].to_list(),
                        },
                        "Cell-orbit proxy: avg variance of cell means per k",
                        "var",
                        x=x,
                    )
                    plot_timeseries(
                        st,
                        {
                            "slope b (before)": audit_df["scale_slope_before"].to_list(),
                            "slope b (after)": audit_df["scale_slope_after"].to_list(),
                        },
                        "Scale-break proxy: log-linear fit slope b of level means",
                        "b",
                        x=x,
                    )
                    plot_timeseries(
                        st,
                        {
                            "rmse (before)": audit_df["scale_rmse_before"].to_list(),
                            "rmse (after)": audit_df["scale_rmse_after"].to_list(),
                            "rmse0 (before)": audit_df["scale_rmse0_before"].to_list(),
                            "rmse0 (after)": audit_df["scale_rmse0_after"].to_list(),
                        },
                        "Scale-break proxy: fit RMSE (and zero-slope baseline)",
                        "rmse",
                        x=x,
                    )

                    st.markdown("---")
                    st.subheader("Tail coarse-grain diagnostics (N=0 initialization)")
                    tcg_on = bool(run_report.get("tail_coarse_grain_B0", False))
                    if not tcg_on:
                        st.info("Tail coarse-grain was disabled for this run.")
                    else:
                        tr = run_report.get("tail_report", {}) or {}
                        tcg_method = str(run_report.get("tail_cg_method", tr.get("method", "")) or "")
                        lamrep = tr.get("lambda_report", tr.get("lambda_report", {}))
                        st.write(
                            {
                                "method": tcg_method,
                                "E0_target": tr.get("E0_target", None),
                                "E_before": tr.get("E_before", None),
                                "E_after": tr.get("E_after", None),
                                "lambda": (lamrep.get("lambda") if isinstance(lamrep, dict) else None),
                            }
                        )

                        # Diagnostics for the geometric shells used by method='series_shells'
                        # (computed deterministically from trunk + r_star; UI-only)
                        d_edge, w_edge = tailcg_edge_shell_weights(trunk, pol)
                        plot_hist(st, d_edge.astype(float), "Edge distance to B0 (d_edge)", "d_edge")
                        plot_hist(st, w_edge.astype(float), "Tail shell weights w_edge (normalized)", "w_edge")

                        scaled = np.zeros((len(edges),), dtype=bool)
                        if tcg_method == "b0_uniform":
                            e_scaled = tr.get("edges_scaled", []) or []
                            for ei in e_scaled:
                                try:
                                    scaled[int(ei)] = True
                                except Exception:
                                    pass
                            if int(np.sum(scaled)) > 0:
                                plot_hist(
                                    st,
                                    d_edge[scaled].astype(float),
                                    "d_edge for scaled edges only (b0_uniform)",
                                    "d_edge",
                                )

                        with st.expander("Download tail coarse-grain edge table", expanded=False):
                            df_tail = pd.DataFrame(
                                {
                                    "edge_index": list(range(len(edges))),
                                    "u": [int(u) for (u, _) in edges],
                                    "v": [int(v) for (_, v) in edges],
                                    "d_to_B0": d_edge.astype(int).tolist(),
                                    "w_edge": w_edge.astype(float).tolist(),
                                    "scaled": scaled.astype(bool).tolist(),
                                }
                            )
                            st.download_button(
                                "Download tailcg_edges.csv",
                                data=df_tail.to_csv(index=False).encode("utf-8"),
                                file_name="tailcg_edges.csv",
                                mime="text/csv",
                            )

                    with st.expander("Download audit table", expanded=False):
                        st.download_button(
                            "Download audit_timeseries.csv",
                            data=audit_df.to_csv(index=False).encode("utf-8"),
                            file_name="audit_timeseries.csv",
                            mime="text/csv",
                        )
                else:
                    st.info("Audit metrics missing or could not be parsed from step_reports.")

        # -----------------------------------------------------------------
        # Tables
        # -----------------------------------------------------------------
        with tabs[4]:
            st.subheader("Mismatch / κ across cells")
            k_m = st.selectbox("Mismatch level k", options=list(range(0, K_max + 1)), index=min(K_max, K_max), key="mismatch_k")
            sr = step_reports[n_display] if (step_reports and n_display < len(step_reports)) else (step_reports[-1] if step_reports else {"cells": []})
            cells_rep = sr.get("cells", [])
            rows = []
            for c_rep in cells_rep:
                if int(c_rep.get("k", -1)) != int(k_m):
                    continue
                w = tuple(c_rep.get("w", []))
                rows.append(
                    {
                        "addr_str": addr_str(w),
                        "valid": bool(c_rep.get("valid", False)),
                        "mismatch": float(c_rep.get("mismatch", float("nan"))),
                        "kappa": float(c_rep.get("kappa", float("nan"))),
                        "fb_soft": bool(c_rep.get("soft_fallback", False)),
                        "fb_hard": bool(c_rep.get("hard_fallback", False)),
                        "cond_fail_any": bool(c_rep.get("cond_fail_any", False)),
                    }
                )
            dfm = pd.DataFrame(rows)
            if not dfm.empty:
                dfm.sort_values(["addr_str"], inplace=True, kind="mergesort")
                st.dataframe(dfm, use_container_width=True, hide_index=True)
                plot_hist(st, dfm["mismatch"].to_numpy(), f"Mismatch distribution (k={k_m}, step n={n_display})", "Mismatch")
                plot_heatmap_row(st, dfm["mismatch"].to_numpy(), f"Mismatch heatmap (k={k_m}, sorted by addr_str)", "cell index")
            else:
                st.info("No cells for this k in report.")

            st.subheader("Report panel (G9.6)")
            with st.expander("Step gates & λ-search status", expanded=False):
                rows = []
                for sr_i in step_reports:
                    lam = sr_i.get("lambda_report", {})
                    rows.append(
                        {
                            "n": int(sr_i.get("n", -1)),
                            "valid_run": bool(sr_i.get("valid_run", False)),
                            "p_fb_soft": float(sr_i.get("p_fb_soft", 0.0)),
                            "p_fb_hard": float(sr_i.get("p_fb_hard", 0.0)),
                            "p_mreg": float(sr_i.get("p_mreg", 0.0)),
                            "lambda_bracketed": bool(lam.get("bracketed", False)),
                            "lambda_fallback": bool(lam.get("fallback_used", False)),
                            "lambda_budget_exhausted": bool(lam.get("budget_exhausted", False)),
                        }
                    )
                st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

            with st.expander("Selected cell details at displayed step", expanded=False):
                sel = None
                for c_rep in sr.get("cells", []):
                    if tuple(c_rep.get("w", [])) == selected_w and int(c_rep.get("k", -1)) == int(k_filter):
                        sel = c_rep
                        break
                st.json({"selected": addr_str(selected_w), "k": int(k_filter), "report": sel})

            with st.expander("Batch mode (G9.4)", expanded=False):
                enable_batch = st.checkbox("Write batch_cells.csv/json (from step n=0)", value=False)
                if enable_batch:
                    sr0 = step_reports[0] if step_reports else {"cells": []}
                    batch_dir = outdir / "batch"
                    if C.shape[0] >= 2:
                        delta0_global = np.log(np.asarray(C[1], dtype=float) / (np.asarray(C[0], dtype=float) + 1e-300))
                    else:
                        delta0_global = np.zeros(len(edges), dtype=float)
                    eidx_by_addr = {
                        str(r["addr_str"]): list(map(int, cell_sets.E_idx.get(parse_addr(str(r["addr_str"])), tuple())))
                        for _, r in cells_df.iterrows()
                    }
                    csv_p, json_p = write_batch_cells(
                        batch_dir,
                        cells_df,
                        sr0.get("cells", []),
                        delta0=delta0_global,
                        eidx_by_addr=eidx_by_addr,
                        env_lock=run_report.get("env_lock", {}),
                        trunk=trunk,
                        cell_sets=cell_sets,
                        pol=pol,
                        c0=np.asarray(C[0], dtype=float),
                        mode_label=str(mode),
                        L_max_param=int(L_max),
                        K_max_param=int(K_max),
                    )
                    st.write({"batch_csv": str(csv_p), "batch_json": str(json_p)})
                    batch_zip = outdir / "batch_artifacts.zip"
                    zip_dir_deterministic(batch_dir, batch_zip)
                    st.write({"batch_zip": str(batch_zip)})

        # -----------------------------------------------------------------
        # Export
        # -----------------------------------------------------------------
        with tabs[5]:
            st.subheader("Export")
            st.caption(
                "Plots/Heatmaps/Tabellen werden in der UI erzeugt und waren früher nur im Speicher. "
                "Für reproduzierbaren Export werden sie jetzt optional als ui_artifacts/ in den Output geschrieben."
            )

            
            st.markdown("### UI artifacts (optional)")
            st.caption("Select which UI-derived plots/heatmaps/tables to generate into ui_artifacts/ for export. Default: none.")

            selected_ui: Set[str] = set()
            for grp, items in UI_EXPORT_CATALOG:
                with st.expander(f"{grp}", expanded=False):
                    for it in items:
                        key = f"ui_export__{it['id']}"
                        if st.checkbox(it["label"], value=False, key=key):
                            selected_ui.add(it["id"])

            include_ui = len(selected_ui) > 0
            st.caption(f"Selected UI artifacts: {len(selected_ui)}")

            batch_all = st.checkbox("Batch over multiple steps", value=True)
            batch_stride = st.slider("Batch stride", min_value=1, max_value=50, value=1, step=1)
            k_exp = st.selectbox("Mismatch export level k", options=list(range(0, K_max + 1)), index=min(K_max, K_max), key="export_k")
            ts_stride = st.slider("Time-series plot stride", min_value=1, max_value=50, value=int(stride), step=1, key="export_ts_stride")

            if batch_all:
                steps = list(range(0, int(C.shape[0]), int(batch_stride)))
            else:
                steps = [int(n_display)]

            colx1, colx2 = st.columns(2)
            with colx1:
                if st.button("Generate ui_artifacts now"):
                    if not include_ui:
                        st.info("No UI artifacts selected. Enable at least one checkbox above.")
                    else:
                        with st.spinner("Generating ui_artifacts..."):
                            ui_root = generate_ui_artifacts(
                                outdir=outdir,
                                enabled_items=selected_ui,
                                trunk=trunk,
                                edges=edges,
                                C=C,
                                step_reports=step_reports,
                                cell_sets=cell_sets,
                                selected_w=selected_w,
                                pol=pol,
                                tail_cg_method=str(run_report.get("tail_cg_method", "")),
                                tail_report=run_report.get("tail_report", {}),
                                fixed_layout=str(fixed_layout),
                                embedding=str(embedding),
                                align_B=bool(align_B),
                                deform_gamma=float(deform_gamma),
                                overlay_fixed=bool(overlay_fixed),
                                thickness_mode=str(thickness_mode),
                                normalize_widths=bool(normalize_widths),
                                width_power=float(width_power),
                                w_min=float(w_min),
                                w_max=float(w_max),
                                steps=steps,
                                k_mismatch=int(k_exp),
                                stride_for_ts=int(ts_stride),
                            )
                    st.write({"ui_artifacts": str(ui_root)})
                    logp = Path(ui_root) / "ui_artifacts_write_log.json"
                    if logp.exists():
                        try:
                            logs = json.loads(logp.read_text(encoding="utf-8"))
                        except Exception:
                            logs = None
                        if isinstance(logs, list) and len(logs) > 0:
                            st.warning(
                                "Some files could not be overwritten (likely locked by another process). "
                                f"Wrote fallback filenames instead. Count: {len(logs)}"
                            )
                            with st.expander("Show write log", expanded=False):
                                st.json(logs)

            with colx2:
                if st.button("Export run as ZIP", type="primary"):
                    if include_ui:
                        with st.spinner("Generating ui_artifacts (for export)..."):
                            generate_ui_artifacts(
                                outdir=outdir,
                                enabled_items=selected_ui,
                                trunk=trunk,
                                edges=edges,
                                C=C,
                                step_reports=step_reports,
                                cell_sets=cell_sets,
                                selected_w=selected_w,
                                pol=pol,
                                tail_cg_method=str(run_report.get("tail_cg_method", "")),
                                tail_report=run_report.get("tail_report", {}),
                                fixed_layout=str(fixed_layout),
                                embedding=str(embedding),
                                align_B=bool(align_B),
                                deform_gamma=float(deform_gamma),
                                overlay_fixed=bool(overlay_fixed),
                                thickness_mode=str(thickness_mode),
                                normalize_widths=bool(normalize_widths),
                                width_power=float(width_power),
                                w_min=float(w_min),
                                w_max=float(w_max),
                                steps=steps,
                                k_mismatch=int(k_exp),
                                stride_for_ts=int(ts_stride),
                            )

                    file_hashes = {}
                    for p in sorted(outdir.rglob("*")):
                        if p.is_file():
                            file_hashes[str(p.relative_to(outdir))] = sha256_file(p)
                    (outdir / "file_hashes.json").write_text(
                        json.dumps({"schema": "realgraph_oqs.file_hashes.v1", "sha256": file_hashes}, indent=2, sort_keys=True),
                        encoding="utf-8",
                    )

                    out_zip = outdir.parent / f"{outdir.name}.zip"
                    zip_dir_deterministic(outdir, out_zip, exclude_prefixes=None if include_ui else ["ui_artifacts"])
                    st.success(f"Exported ZIP: {out_zip}")
                    st.download_button("Download ZIP", data=out_zip.read_bytes(), file_name=out_zip.name, mime="application/zip")
    else:
        st.info("No run artifacts found in the output directory yet. Click 'Run simulation'.")


if __name__ == "__main__":
    main()
