from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from realgraph_oqs.numeric.choi import choi_state_from_superop
from realgraph_oqs.numeric.logdet import logDet, LogDetReport
from realgraph_oqs.policy.constants import Policy

from dataclasses import dataclass as _dataclass

@_dataclass(frozen=True)
class MismatchPolicy:
    """Mismatch computation policy.

    Notes
    -----
    The implementation follows the v4_rev8 convention:
    - Choi states are regularized with eps0 = max(r_star**L_max, eps_floor)
    - mismatch = S(Jrho||Jsig)/log(d^2) (dimensionless in [0,∞))
    """
    normalize_by_logd2: bool = True


def qre_semantics_note() -> str:
    """Return a non-normative note on QRE semantics (remark only)."""
    return (
        "Mismatch is computed as a dimensionless normalization of quantum relative entropy "
        "between regularized Choi states. This is a diagnostic quantity; it must not be "
        "interpreted as an operational distance without additional assumptions."
    )


def compute_mismatch(Phi_loc: np.ndarray, Phi_glob: np.ndarray, dp: int, L_max: int, r_star: float, pol: Policy, mp: MismatchPolicy | None = None):
    """Convenience wrapper used by orchestration/reporting layers."""
    d = int(3 * dp)
    return mismatch_from_channels(Phi_loc, Phi_glob, d=d, L_max=L_max, r_star=r_star, pol=pol)



@dataclass(frozen=True)
class MismatchReport:
    eps0: float
    logdet_rho: LogDetReport
    logdet_sig: LogDetReport
    support_ok: bool
    mismatch: float


def regularize_state(J: np.ndarray, eps0: float) -> np.ndarray:
    d2 = J.shape[0]
    I = np.eye(d2, dtype=np.complex128)
    Je = (1.0 - eps0) * J + eps0 * I / float(d2)
    Je = 0.5 * (Je + Je.conj().T)
    Je = Je / np.trace(Je)
    return Je


def relative_entropy_choi(Jrho: np.ndarray, Jsig: np.ndarray, pol: Policy) -> Tuple[float, LogDetReport, LogDetReport]:
    log_rho, rep_rho = logDet(Jrho, pol)
    log_sig, rep_sig = logDet(Jsig, pol)
    # S(ρ||σ) = Tr(ρ (log ρ - log σ))
    S = np.real(np.trace(Jrho @ (log_rho - log_sig)))
    return float(S), rep_rho, rep_sig


def mismatch_from_channels(Phi_glob: np.ndarray, Phi_loc: np.ndarray, d: int, L_max: int, r_star: float, pol: Policy) -> Tuple[float, np.ndarray, np.ndarray, MismatchReport]:
    """Compute scalar mismatch and rate-difference features.

    Returns (Mismatch, Jrho_eps, Jsig_eps, report).
    """
    Jrho = choi_state_from_superop(Phi_glob, d)
    Jsig = choi_state_from_superop(Phi_loc, d)
    eps0 = float(max(r_star ** L_max, pol.eps_floor))
    Jrho_e = regularize_state(Jrho, eps0)
    Jsig_e = regularize_state(Jsig, eps0)

    S, rep_rho, rep_sig = relative_entropy_choi(Jrho_e, Jsig_e, pol)

    denom = float(np.log(d * d))
    mismatch = float(S / denom) if denom > 0 else float(S)

    return mismatch, Jrho_e, Jsig_e, MismatchReport(
        eps0=eps0,
        logdet_rho=rep_rho,
        logdet_sig=rep_sig,
        support_ok=True,
        mismatch=mismatch,
    )
