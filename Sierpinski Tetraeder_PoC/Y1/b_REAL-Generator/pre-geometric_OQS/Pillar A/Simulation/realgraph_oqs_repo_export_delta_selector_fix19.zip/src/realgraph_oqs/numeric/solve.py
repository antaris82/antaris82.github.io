from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass(frozen=True)
class SolveReport:
    ok: bool
    method: str  # "chol" or "lu" or "fail"
    pivot_rows: Tuple[int, ...]  # LU pivot history (deterministic)
    residual_fro: float


def _is_exact_symmetric(A: np.ndarray) -> bool:
    return bool(np.array_equal(A, A.T))


def _chol_solve(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    L = np.linalg.cholesky(A)
    # Solve L Y = B
    Y = np.linalg.solve(L, B)
    # Solve L^T X = Y
    X = np.linalg.solve(L.T, Y)
    return X


def _lu_factor_det(A: np.ndarray) -> Tuple[np.ndarray, Tuple[int, ...], bool]:
    """Deterministic LU factorization with partial pivoting.

    Tie-break: choose smallest row index among equal |pivot| candidates.
    Returns (LU in-place matrix, pivots, ok).
    """
    A = A.copy()
    n = A.shape[0]
    pivots = []
    for k in range(n):
        col = np.abs(A[k:, k])
        if not np.all(np.isfinite(col)):
            return A, tuple(pivots), False
        # argmax with deterministic tie-break (np.argmax is first occurrence)
        p_rel = int(np.argmax(col))
        p = k + p_rel
        pivots.append(p)
        if np.isclose(A[p, k], 0.0):
            return A, tuple(pivots), False
        if p != k:
            A[[k, p], :] = A[[p, k], :]
        # elimination
        for i in range(k + 1, n):
            A[i, k] /= A[k, k]
            A[i, k + 1:] -= A[i, k] * A[k, k + 1:]
    return A, tuple(pivots), True


def _lu_solve_det(LU: np.ndarray, pivots: Tuple[int, ...], B: np.ndarray) -> np.ndarray:
    n = LU.shape[0]
    X = B.copy()
    # Apply row swaps to RHS (same swaps as factorization)
    for k, p in enumerate(pivots):
        if p != k:
            X[[k, p], :] = X[[p, k], :]
    # Forward solve for L (unit diagonal)
    for i in range(n):
        X[i, :] -= LU[i, :i] @ X[:i, :]
    # Backward solve for U
    for i in range(n - 1, -1, -1):
        X[i, :] -= LU[i, i + 1:] @ X[i + 1:, :]
        X[i, :] /= LU[i, i]
    return X


def Solve(A: np.ndarray, B: np.ndarray) -> Tuple[np.ndarray, SolveReport]:
    """Deterministic linear solve per Definition def:Solve (v4_rev8).

    No implicit regularization. Fail is signalled via SolveReport.ok=False.
    """
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if B.ndim == 1:
        B = B.reshape(-1, 1)

    try:
        if _is_exact_symmetric(A):
            # Attempt Cholesky path first (only if succeeds).
            try:
                X = _chol_solve(A, B)
                res = float(np.linalg.norm(A @ X - B, ord="fro"))
                return X, SolveReport(ok=True, method="chol", pivot_rows=tuple(), residual_fro=res)
            except np.linalg.LinAlgError:
                pass

        LU, pivots, ok = _lu_factor_det(A)
        if not ok:
            X = np.zeros_like(B)
            res = float(np.linalg.norm(A @ X - B, ord="fro"))
            return X, SolveReport(ok=False, method="fail", pivot_rows=pivots, residual_fro=res)
        X = _lu_solve_det(LU, pivots, B)
        res = float(np.linalg.norm(A @ X - B, ord="fro"))
        return X, SolveReport(ok=True, method="lu", pivot_rows=pivots, residual_fro=res)
    except Exception:
        X = np.zeros_like(B)
        res = float(np.linalg.norm(A @ X - B, ord="fro"))
        return X, SolveReport(ok=False, method="fail", pivot_rows=tuple(), residual_fro=res)
