from __future__ import annotations

from typing import Dict, Any

from ..policy.constants import Policy


def sec2_defaults(pol: Policy) -> Dict[str, Any]:
    """Default parameters corresponding to Section 2 (prä-OQS)."""
    return {
        "Lint": int(pol.L_int),
        "r_star": float(pol.r_star),
        "beta_reg": float(pol.beta_reg),
        "M_reg": int(pol.M_reg),
        "kappa_max": float(pol.kappa_max),
        "kappa_susp": float(pol.kappa_susp),
        "eps_floor": float(pol.eps_floor),
    }


def sec3_defaults(pol: Policy) -> Dict[str, Any]:
    """Default parameters corresponding to Section 3 (resistance metric / embeddings)."""
    return {
        "deltaR_floor": float(pol.eps_floor),
        "tau_spec": float(pol.tau_spec),
        "k_stable": int(pol.k_stable),
    }


__all__ = ["sec2_defaults", "sec3_defaults"]
