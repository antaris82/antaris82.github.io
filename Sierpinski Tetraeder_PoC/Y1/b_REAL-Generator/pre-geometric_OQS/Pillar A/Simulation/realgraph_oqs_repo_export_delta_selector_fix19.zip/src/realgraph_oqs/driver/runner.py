from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import hashlib
import struct

import json
import numpy as np

from realgraph_oqs.driver.cell_sets import build_cell_sets
from realgraph_oqs.driver.lcp_measure import compute_lcp_measure
from realgraph_oqs.driver.update import step_update, StepReport
from realgraph_oqs.driver.update import _lambda_normalize
from realgraph_oqs.ideal.sg_trunk import build_sg_trunk
from realgraph_oqs.oqs.dtn import dtn_kron
from realgraph_oqs.policy.constants import Policy
from realgraph_oqs.policy.env_lock import build_env_lock


def canonical_init_conductances(trunk, pol: Policy) -> np.ndarray:
    # IDEAL conductances: all ones
    return np.ones((len(trunk.edges),), dtype=np.float64)


def _energy_B0_tot(trunk, c: np.ndarray, pol: Policy) -> Tuple[float, bool]:
    """Boundary energy on B0 computed from DtN(B0)."""
    L = trunk.laplacian_from_conductances(c)
    Lam, rep = dtn_kron(L, trunk.B0, pol)
    if not rep.valid:
        return 0.0, False
    E = 0.0
    for (i, j) in ((0, 1), (0, 2), (1, 2)):
        y = np.zeros((3, 1), dtype=np.float64)
        y[i, 0] = 1.0
        y[j, 0] = -1.0
        E += 0.5 * float((y.T @ Lam @ y)[0, 0])
    return float(E), True


def _edges_incident_to_B0(trunk) -> List[int]:
    B0 = set(trunk.B0)
    idx: List[int] = []
    for ei, (u, v) in enumerate(trunk.edges):
        if (u in B0) or (v in B0):
            idx.append(int(ei))
    return idx


def _graph_dist_to_B0(trunk) -> np.ndarray:
    """Unweighted BFS distance of every vertex to the set B0 (deterministic)."""
    from collections import deque

    nV = int(trunk.nV)
    B0 = set(map(int, trunk.B0))
    adj: List[List[int]] = [[] for _ in range(nV)]
    for (u, v) in trunk.edges:
        ui = int(u); vi = int(v)
        adj[ui].append(vi)
        adj[vi].append(ui)

    dist = np.full((nV,), fill_value=np.iinfo(np.int32).max, dtype=np.int32)
    q: deque[int] = deque()
    for b in B0:
        dist[b] = 0
        q.append(int(b))
    while q:
        x = q.popleft()
        dx = int(dist[x])
        for y in adj[x]:
            if dist[y] > dx + 1:
                dist[y] = dx + 1
                q.append(int(y))
    return dist


def _lambda_normalize_weighted(
    trunk,
    pol: Policy,
    c_tilde: np.ndarray,
    target_E: float,
    w_edge: np.ndarray,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """1D normalization with non-uniform exponents: c(e) <- c(e)*exp(lambda*w_e).

    Deterministic bracket expansion + bisection, mirroring _lambda_normalize policy budgets.
    Requires w_edge >= 0.
    """

    w = np.asarray(w_edge, dtype=np.float64)
    w_min = float(np.min(w))
    if w_min < 0.0:
        raise ValueError("w_edge must be >= 0")

    def eval_E(lam: float) -> Tuple[float, bool]:
        c = c_tilde * np.exp(float(lam) * w)
        E, ok = _energy_B0_tot(trunk, c, pol)
        return float(E), bool(ok)

    def fE(E: float) -> float:
        return float(E - target_E)

    h0 = float(pol.lambda_init_step)
    gamma = float(pol.lambda_gamma)
    a = -h0
    b = +h0
    Ea, oka = eval_E(a)
    Eb, okb = eval_E(b)
    eval_invalid = not (oka and okb)

    bracketed = False
    expand_iters = 0
    for i in range(pol.N_expand):
        expand_iters = i
        if not (oka and okb):
            eval_invalid = True
            break
        fa = fE(Ea)
        fb = fE(Eb)
        if fa == 0.0 or fb == 0.0 or fa * fb < 0.0:
            bracketed = True
            break
        h = h0 * (gamma ** (i + 1))
        a = -h
        b = +h
        Ea, oka = eval_E(a)
        Eb, okb = eval_E(b)

    if not bracketed:
        E0, ok0 = eval_E(0.0)
        return c_tilde.copy(), {
            "bracketed": False,
            "expand_iters": int(expand_iters),
            "bisect_iters": 0,
            "budget_exhausted": True,
            "eval_invalid": bool(eval_invalid or (not ok0)),
            "lambda": 0.0,
            "achieved_E": float(E0 if ok0 else 0.0),
        }

    fa = fE(Ea)
    fb = fE(Eb)
    lam_mid = 0.0
    Emid = 0.0
    okmid = True
    bisect_iters = 0
    for j in range(pol.N_bisect):
        bisect_iters = j + 1
        lam_mid = 0.5 * (a + b)
        Emid, okmid = eval_E(lam_mid)
        if not okmid:
            eval_invalid = True
            break
        fm = fE(Emid)
        if fm == 0.0:
            break
        if fa * fm < 0.0:
            b = lam_mid
            Eb = Emid
            fb = fm
        else:
            a = lam_mid
            Ea = Emid
            fa = fm

    c_out = c_tilde * np.exp(float(lam_mid) * w)
    return c_out, {
        "bracketed": bool(bracketed),
        "expand_iters": int(expand_iters),
        "bisect_iters": int(bisect_iters),
        "budget_exhausted": False,
        "eval_invalid": bool(eval_invalid),
        "lambda": float(lam_mid),
        "achieved_E": float(Emid if okmid else 0.0),
    }


def apply_tail_coarse_grain_B0(
    trunk,
    c_ideal: np.ndarray,
    pol: Policy,
    *,
    method: str = "b0_uniform",
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """One-time coarse-graining of the truncated IDEAL tail onto B0.

    Methods (deterministic, no new degrees of freedom):

      - method="b0_uniform":
          Scale only edges incident to B0 by a single exp(lambda).
          (Legacy v1 method)

      - method="series_shells":
          Scale all edges with exponents w_e = r_star^{d(e,B0)} where d is
          unweighted graph distance of the nearer endpoint to B0.
          Then choose lambda so that E_B0_tot matches Policy.E0_ideal.

    Executed once before the n-loop. Therefore affects N=0.
    """
    c0 = np.asarray(c_ideal, dtype=np.float64).copy()
    target_E = float(pol.E0_ideal)
    E_before, ok_before = _energy_B0_tot(trunk, c0, pol)

    if method == "b0_uniform":
        e_partial_idx = _edges_incident_to_B0(trunk)
        c1, lamrep = _lambda_normalize(trunk=trunk, pol=pol, c_tilde=c0, target_E=target_E, e_partial_idx=e_partial_idx)
        E_after, ok_after = _energy_B0_tot(trunk, c1, pol)
        tail_report = {
            "schema": "realgraph_oqs.tail_cg.v2",
            "enabled": True,
            "method": "b0_uniform",
            "E0_target": float(target_E),
            "E_before": float(E_before),
            "E_after": float(E_after),
            "ok_before": bool(ok_before),
            "ok_after": bool(ok_after),
            "edges_scaled": [int(x) for x in e_partial_idx],
            "lambda_report": asdict(lamrep),
        }
        return c1, tail_report

    if method == "series_shells":
        dist = _graph_dist_to_B0(trunk)
        d_edge = np.array([min(int(dist[int(u)]), int(dist[int(v)])) for (u, v) in trunk.edges], dtype=np.int32)
        w_edge = np.power(float(pol.r_star), d_edge.astype(np.float64))
        # normalize to max=1 for numerical stability (no effect on monotonicity; lambda rescales accordingly)
        w_max = float(np.max(w_edge))
        if w_max > 0.0:
            w_edge = w_edge / w_max

        c1, lamrep = _lambda_normalize_weighted(trunk=trunk, pol=pol, c_tilde=c0, target_E=target_E, w_edge=w_edge)
        E_after, ok_after = _energy_B0_tot(trunk, c1, pol)
        tail_report = {
            "schema": "realgraph_oqs.tail_cg.v2",
            "enabled": True,
            "method": "series_shells",
            "series": {
                "kind": "geometric_shells_by_distance_to_B0",
                "r_star": float(pol.r_star),
                "w_max_normalized": True,
                "d_edge_min": int(np.min(d_edge)),
                "d_edge_max": int(np.max(d_edge)),
                "w_edge_min": float(np.min(w_edge)),
                "w_edge_max": float(np.max(w_edge)),
            },
            "E0_target": float(target_E),
            "E_before": float(E_before),
            "E_after": float(E_after),
            "ok_before": bool(ok_before),
            "ok_after": bool(ok_after),
            "lambda_report": lamrep,
        }
        return c1, tail_report

    raise ValueError(f"Unknown tail coarse-grain method: {method}")


def _round_half_away_from_zero(x: float) -> int:
    """Deterministic integer rounding with 0.5-ties away from zero (spec requirement)."""
    if x >= 0.0:
        return int(np.floor(x + 0.5))
    return int(np.ceil(x - 0.5))


def canonical_init_theta(trunk, lcp, cells, c0: np.ndarray, pol: Policy, *, return_report: bool = False) -> Any:
    """Deterministic θ_{0,w} construction from Seed_0(w) (v4_rev8).

    θ_{0,∅} := 0 and the root cell uses expectation mode.

    For w ≠ ∅:
      - Seed_0(w) := DtN_{B_w}(L_0)
      - S_w := 0.5(Seed_0(w)+Seed_0(w)^T)
      - q_w := eps_floor * max(1, ||S_w||_F)
      - z_k := round_half_away_from_zero( λ_k(S_w)/q_w )  (λ sorted ascending)
      - θ_{0,w} := u64(SHA256(serialize_i64(z_1,...,z_m))[0:8]) / 2^64
    """
    L0 = trunk.laplacian_from_conductances(c0)
    th: Dict[Tuple[int, ...], float] = {}
    invalid_words: List[Tuple[int, ...]] = []


    # Root word: fixed by spec.
    th[tuple()] = 0.0

    for k in range(0, lcp.K_max + 1):
        for w in lcp.words_by_k[k]:
            if w == tuple():
                continue
            Bw = cells.B[w]
            Seed, rep = dtn_kron(L0, B=Bw, pol=pol)
            if not rep.valid:
                # Deterministic fallback: treat invalid Seed_0(w) as the zero matrix,
                # but TRACK this as an error condition for auditing/debugging.
                invalid_words.append(w)
                Seed = np.zeros((len(Bw), len(Bw)), dtype=np.float64)

            S = 0.5 * (Seed + Seed.T)
            # For SG, m=3, use symmetric eigensolver.
            lam = np.linalg.eigvalsh(S)
            q = float(pol.eps_floor) * max(1.0, float(np.linalg.norm(S, ord="fro")))
            if not np.isfinite(q) or q <= 0.0:
                q = float(pol.eps_floor)

            z: List[int] = []
            for lk in lam:
                zk = _round_half_away_from_zero(float(lk) / q)
                # clamp to int64 range for stable serialization
                if zk < -(2**63):
                    zk = -(2**63)
                if zk > (2**63 - 1):
                    zk = (2**63 - 1)
                z.append(int(zk))

            payload = b"".join(struct.pack(">q", int(zk)) for zk in z)
            digest = hashlib.sha256(payload).digest()
            u = int.from_bytes(digest[:8], byteorder="big", signed=False)
            th[w] = float(u / 2**64)
    report = {
        "theta_init_invalid_count": int(len(invalid_words)),
        "theta_init_invalid_words": [list(w) for w in invalid_words],
        "theta_init_ok": bool(len(invalid_words) == 0),
    }
    return (th, report) if return_report else th
def run_simulation(
    outdir: Path,
    L_max: int = 3,
    N: int = 20,
    dp: int = 1,
    trajectory: bool = True,
    *,
    mode: str = "Global (all cells)",
    subsystem_cell: Optional[Dict[str, Any]] = None,
    update_scope: str = "all_cells",
    subsystem_word: Optional[Tuple[int, ...]] = None,
    tail_coarse_grain_B0: bool = True,
    tail_cg_method: str = "b0_uniform",
) -> None:
    outdir.mkdir(parents=True, exist_ok=True)

    pol = Policy()
    trunk = build_sg_trunk(L_max=L_max)
    lcp = compute_lcp_measure(trunk)
    cells = build_cell_sets(trunk, lcp)

    scope = str(update_scope)
    if scope not in {"all_cells", "selected_cell"}:
        scope = "all_cells"
    sw: Optional[Tuple[int, ...]] = subsystem_word
    if scope == "selected_cell" and sw is None:
        if isinstance(subsystem_cell, dict) and "word" in subsystem_cell:
            try:
                sw = tuple(int(x) for x in subsystem_cell.get("word", []))
            except Exception:
                sw = tuple()
        else:
            sw = tuple()

    c_ideal = canonical_init_conductances(trunk, pol)

    tail_report: Optional[Dict[str, Any]] = None
    if bool(tail_coarse_grain_B0):
        m = str(tail_cg_method).strip() or "b0_uniform"
        c, tail_report = apply_tail_coarse_grain_B0(trunk=trunk, c_ideal=c_ideal, pol=pol, method=m)
    else:
        c = c_ideal.copy()

    theta_init_report: Optional[Dict[str, Any]] = None
    if trajectory:
        theta, theta_init_report = canonical_init_theta(trunk, lcp, cells, c, pol, return_report=True)
    else:
        theta = {}

    # env lock includes the spec sources if present under spec/originals
    extra = {}
    spec_tex = Path(__file__).resolve().parents[3] / "spec/originals/REAL-Graph_OQS-Definition_v4_rev8.tex"
    spec_pdf = Path(__file__).resolve().parents[3] / "spec/originals/REAL-Graph_OQS-Definition_v4_rev8.pdf"
    if spec_tex.exists():
        extra["spec_tex"] = spec_tex
    if spec_pdf.exists():
        extra["spec_pdf"] = spec_pdf
    env = build_env_lock(pol, extra_files=extra)

    C_hist = np.zeros((N + 1, len(trunk.edges)), dtype=np.float64)
    C_hist[0, :] = c

    step_reports: List[dict] = []

    for n in range(N):
        c, theta, rep = step_update(
            n=n,
            trunk=trunk,
            lcp=lcp,
            cells=cells,
            c_n=c,
            theta_n=theta,
            dp=dp,
            trajectory=trajectory,
            pol=pol,
            update_scope=scope,
            subsystem_word=(None if sw is None else tuple(sw)),
        )
        C_hist[n + 1, :] = c
        step_reports.append(asdict(rep))

    # Aggregate init/step validity and track seed-init errors
    errors: List[Dict[str, Any]] = []
    theta_ok = True
    if trajectory and theta_init_report is not None:
        theta_ok = bool(theta_init_report.get("theta_init_ok", True))
        if not theta_ok:
            errors.append({
                "code": "SEED_INIT_INVALID",
                "theta_init_invalid_count": int(theta_init_report.get("theta_init_invalid_count", 0)),
                "theta_init_invalid_words": theta_init_report.get("theta_init_invalid_words", []),
            })
    step_ok = all(bool(sr.get("valid_run", True)) for sr in step_reports)
    valid_run = bool(theta_ok and step_ok)

    # Write artifacts
    np.save(outdir / "conductances.npy", C_hist)

    # edges.csv
    with (outdir / "edges.csv").open("w", encoding="utf-8") as f:
        f.write("edge_idx,u,v\n")
        for i, (u, v) in enumerate(trunk.edges):
            f.write(f"{i},{u},{v}\n")

    report = {
        "schema": "realgraph_oqs.run_report.v4",
        "L_max": L_max,
        "N": N,
        "dp": dp,
        "trajectory": trajectory,
        "mode": mode,
        "subsystem_cell": subsystem_cell,
        "update_scope": scope,
        "selected_cell_in_update": bool(scope == "selected_cell"),
        "subsystem_word": (None if sw is None else list(sw)),
        "tail_coarse_grain_B0": bool(tail_coarse_grain_B0),
        "tail_cg_method": (str(tail_cg_method) if tail_coarse_grain_B0 else None),
        "tail_report": tail_report,
        "theta_init_report": theta_init_report,
        "valid_run": valid_run,
        "errors": errors,
        "env_lock": env.to_jsonable(),
        "nV": trunk.nV,
        "nE": len(trunk.edges),
        "B0": trunk.B0,
        "step_reports": step_reports,
    }
    (outdir / "run_report.json").write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
