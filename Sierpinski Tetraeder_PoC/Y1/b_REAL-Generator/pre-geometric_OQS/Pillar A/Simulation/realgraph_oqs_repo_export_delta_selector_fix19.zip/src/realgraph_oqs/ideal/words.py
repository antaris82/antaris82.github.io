from __future__ import annotations

from typing import Tuple, Iterable, Dict, Set

Word = Tuple[int, ...]


def pad_word(w: Word, L_max: int, pad_symbol: int = 0) -> Word:
    """Pad a word to length L_max by appending a fixed symbol.

    This is used to embed shorter cell-words into the level-L_max raw address space
    deterministically. Prefix structure ensures injectivity for fixed pad_symbol.
    """
    w = tuple(int(x) for x in w)
    if L_max < len(w):
        raise ValueError("L_max must be >= len(w)")
    return w + (int(pad_symbol),) * (L_max - len(w))


def validate_padding_injective(words: Iterable[Word], L_max: int, pad_symbol: int = 0) -> bool:
    """Check injectivity of pad_word over a given iterable of words."""
    seen: Set[Word] = set()
    for w in words:
        pw = pad_word(w, L_max=L_max, pad_symbol=pad_symbol)
        if pw in seen:
            return False
        seen.add(pw)
    return True


__all__ = ["pad_word", "validate_padding_injective", "Word"]
