from __future__ import annotations

from typing import Dict, Tuple, Any

import numpy as np

from ..ideal.structures import TrunkGraph, Word
from ..policy.constants import Policy
from ..oqs.dtn import dtn_kron


def validate_seed_orbit_invariance(trunk: TrunkGraph, c0: np.ndarray, pol: Policy) -> Dict[str, Any]:
    """Best-effort orbit-invariance check for seeds under the SG corner permutation.

    This check is limited and only verifies that the *corner* seed on B0 is symmetric
    under permutations of boundary indices up to numerical tolerance.

    Returns a dict with 'passed' and diagnostic norms.
    """
    L0 = trunk.laplacian_from_conductances(c0)
    Lam, rep = dtn_kron(L0, B=trunk.B0, pol=pol)
    # Permute boundary indices
    perms = [(0,1,2),(0,2,1),(1,0,2),(1,2,0),(2,0,1),(2,1,0)]
    deltas = []
    for p in perms:
        P = np.eye(3, dtype=np.float64)[list(p), :]
        Lam_p = P @ Lam @ P.T
        deltas.append(float(np.linalg.norm(Lam_p - Lam, ord="fro")))
    max_delta = float(max(deltas)) if deltas else 0.0
    passed = bool(rep.valid and (max_delta <= 1e3 * pol.eps_floor))
    return {"passed": passed, "max_delta_fro": max_delta, "valid": bool(rep.valid), "cond_fail": bool(rep.cond_fail)}


__all__ = ["validate_seed_orbit_invariance"]
