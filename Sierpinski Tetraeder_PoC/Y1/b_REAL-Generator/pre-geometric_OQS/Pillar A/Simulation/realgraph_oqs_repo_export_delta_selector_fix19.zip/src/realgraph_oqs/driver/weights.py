from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from realgraph_oqs.driver.selection import ACTIONS, Action, Sel, SelReport
from realgraph_oqs.numeric.regspd import RegSPD
from realgraph_oqs.numeric.solve import Solve
from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class CellEnergyReport:
    valid_proj: bool
    sel: Optional[SelReport]
    omega: Tuple[float, float, float]
    E_total: float
    E_by_edge: Dict[int, float]  # edge_idx -> E_raw(edge) (before mu)
    solve_ok: bool
    cond_fail: bool


def omega_expected(dr_pair: np.ndarray, pol: Policy) -> np.ndarray:
    # dr_pair length 3 aligned with ACTIONS
    dr = np.asarray(dr_pair, dtype=np.float64)
    denom = float(np.sum(dr) + 3.0 * pol.eps_floor)
    return (dr + pol.eps_floor) / denom


def omega_trajectory(dr_pair: np.ndarray, theta: float, pol: Policy) -> Tuple[np.ndarray, SelReport, bool]:
    pi = omega_expected(dr_pair, pol)
    act, rep = Sel(theta, pi, pol)
    if act is None:
        return pi, rep, True  # tie -> fallback to expected
    one = np.zeros_like(pi)
    one[ACTIONS.index(act)] = 1.0
    return one, rep, False


def _harmonic_extension(Q: np.ndarray, Vw: Tuple[int, ...], Bw: Tuple[int, int, int], Iw: Tuple[int, ...], uB: np.ndarray, pol: Policy) -> Tuple[np.ndarray, bool, bool]:
    """Return u on Vw (ordered), ok flags (solve_ok, cond_fail)."""
    pos = {v: i for i, v in enumerate(Vw)}
    Bpos = [pos[b] for b in Bw]
    Ipos = [pos[i] for i in Iw]

    u = np.zeros((len(Vw),), dtype=np.float64)
    u[Bpos] = uB

    if len(Ipos) == 0:
        return u, True, False

    Q_II = Q[np.ix_(Ipos, Ipos)]
    Q_IB = Q[np.ix_(Ipos, Bpos)]

    Qreg, regrep = RegSPD(Q_II, pol)
    rhs = -Q_IB @ uB.reshape(-1, 1)
    X, solrep = Solve(Qreg, rhs)
    if not solrep.ok:
        return u, False, regrep.cond_fail
    u[Ipos] = X[:, 0]
    return u, True, regrep.cond_fail


def cell_edge_energies(
    L: np.ndarray,
    edges: List[Tuple[int, int]],
    c: np.ndarray,
    Vw: Tuple[int, ...],
    Bw: Tuple[int, int, int],
    Iw: Tuple[int, ...],
    E_idx_w: Tuple[int, ...],
    R_glob: np.ndarray,
    R_loc: np.ndarray,
    theta: Optional[float],
    trajectory: bool,
    pol: Policy,
) -> CellEnergyReport:
    """Compute per-edge raw energies E_raw(edge) for a given cell w (before mu weighting)."""
    # Rate differences per unordered pair
    dr_pair = np.zeros((3,), dtype=np.float64)
    for a_i, (i, j) in enumerate(ACTIONS):
        dr_pair[a_i] = abs(float(R_glob[i, j]) - float(R_loc[i, j])) + abs(float(R_glob[j, i]) - float(R_loc[j, i]))

    sel_rep: Optional[SelReport] = None
    if trajectory and theta is not None:
        omega, sel_rep, _tie = omega_trajectory(dr_pair, theta, pol)
    else:
        omega = omega_expected(dr_pair, pol)

    # Local principal submatrix Q
    Vpos = list(Vw)
    Q = L[np.ix_(Vpos, Vpos)]

    # Compute u^{(ij)} on Vw for each action
    u_actions: List[np.ndarray] = []
    solve_ok_all = True
    cond_fail_any = False
    for (i, j) in ACTIONS:
        uB = np.zeros((3,), dtype=np.float64)
        uB[i] = 1.0
        uB[j] = -1.0
        u, ok, cond_fail = _harmonic_extension(Q, Vw, Bw, Iw, uB=uB, pol=pol)
        cond_fail_any = cond_fail_any or cond_fail
        solve_ok_all = solve_ok_all and ok
        u_actions.append(u)
    if not solve_ok_all:
        return CellEnergyReport(
            valid_proj=False,
            sel=sel_rep,
            omega=tuple(float(x) for x in omega),
            E_total=0.0,
            E_by_edge={},
            solve_ok=False,
            cond_fail=cond_fail_any,
        )

    # Map vertex id -> position in Vw vector
    pos = {v: i for i, v in enumerate(Vw)}

    # Edge energies (raw, before mu)
    E_by_edge: Dict[int, float] = {}
    for ei in E_idx_w:
        u, v = edges[ei]
        if u not in pos or v not in pos:
            continue
        pu, pv = pos[u], pos[v]
        E = 0.0
        for a_idx, _ in enumerate(ACTIONS):
            du = float(u_actions[a_idx][pu] - u_actions[a_idx][pv])
            E += float(omega[a_idx]) * 0.5 * float(c[ei]) * (du * du)
        E_by_edge[int(ei)] = float(E)

    E_total = float(sum(E_by_edge.values()))

    return CellEnergyReport(
        valid_proj=True,
        sel=sel_rep,
        omega=tuple(float(x) for x in omega),
        E_total=E_total,
        E_by_edge=E_by_edge,
        solve_ok=True,
        cond_fail=cond_fail_any,
    )
