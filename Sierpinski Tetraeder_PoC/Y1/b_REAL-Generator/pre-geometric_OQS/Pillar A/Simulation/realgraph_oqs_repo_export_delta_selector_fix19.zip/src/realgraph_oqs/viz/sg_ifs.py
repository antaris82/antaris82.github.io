from __future__ import annotations

"""Deterministic SG IFS coordinates (visualization only).

For the SG trunk K_{L_max}, each *raw* vertex is labeled by (w,i) with
  - w in {0,1,2}^{L_max}
  - i in {0,1,2}

We map (w,i) to a point in R^2 by applying the standard IFS contractions

  f_a(x) = (x + p_a)/2,

repeatedly along the word w to the corner point p_i of an equilateral triangle.

The trunk's quotient vertices are equivalence classes of raw vertices; we use
the canonical representative `trunk.rep[qid]` for a deterministic coordinate.
"""

from typing import Tuple

import numpy as np

from ..ideal.structures import TrunkGraph


def sg_ifs_coords(trunk: TrunkGraph) -> np.ndarray:
    """Return IFS coordinates for all quotient vertices (nV,2)."""
    # Equilateral triangle corners
    p = np.array(
        [
            [0.0, 0.0],
            [1.0, 0.0],
            [0.5, float(np.sqrt(3.0) / 2.0)],
        ],
        dtype=np.float64,
    )

    coords = np.zeros((trunk.nV, 2), dtype=np.float64)
    for qid, (w, i) in enumerate(trunk.rep):
        x = p[int(i)].copy()
        # Apply contractions in word order
        for a in w:
            x = 0.5 * (x + p[int(a)])
        coords[qid, :] = x
    return coords


__all__ = ["sg_ifs_coords"]
