from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from .constants import Policy


@dataclass(frozen=True)
class ExpmHermitianReport:
    ok: bool
    clusters: Tuple[Tuple[int, int], ...]
    tau_deg: float


def _cluster_indices(w: np.ndarray, tau: float) -> Tuple[Tuple[int, int], ...]:
    # w must be sorted ascending
    n = w.shape[0]
    clusters = []
    i = 0
    while i < n:
        j = i + 1
        while j < n and abs(float(w[j] - w[i])) <= tau:
            j += 1
        clusters.append((i, j))
        i = j
    return tuple(clusters)


def _canonicalize_cluster(P: np.ndarray, r: int, tau: float) -> np.ndarray:
    """Canonical orthonormal basis for a projector P of rank r.

    Deterministic procedure: project standard basis, run modified Gram–Schmidt.
    """
    d = P.shape[0]
    basis = []
    for k in range(d):
        v = P @ np.eye(d, dtype=np.complex128)[:, k]
        # Modified Gram–Schmidt
        for u in basis:
            v = v - u * np.vdot(u, v)
        nv = float(np.linalg.norm(v))
        if nv > tau:
            basis.append(v / nv)
        if len(basis) >= r:
            break
    if len(basis) < r:
        # Fallback: fill deterministically with standard basis vectors orthonormalized.
        for k in range(d):
            v = np.eye(d, dtype=np.complex128)[:, k]
            for u in basis:
                v = v - u * np.vdot(u, v)
            nv = float(np.linalg.norm(v))
            if nv > tau:
                basis.append(v / nv)
            if len(basis) >= r:
                break
    return np.stack(basis, axis=1)


def expm_hermitian(H: np.ndarray, pol: Policy, t: float = 1.0) -> Tuple[np.ndarray, ExpmHermitianReport]:
    """Deterministic expm for Hermitian matrices via spectral decomposition.

    This avoids non-determinism from arbitrary eigenvector choices by
    canonicalizing degenerate subspaces using a projector + deterministic
    Gram–Schmidt on the standard basis.
    """
    H = np.asarray(H, dtype=np.complex128)
    # Ensure Hermitian numerically
    H = 0.5 * (H + H.conj().T)

    w, V = np.linalg.eigh(H)
    # sort
    idx = np.argsort(w, kind="mergesort")
    w = w[idx]
    V = V[:, idx]

    # degeneracy tolerance: reuse tau_spec scale (float64-motivated)
    tau = float(pol.tau_spec)
    clusters = _cluster_indices(w, tau=tau)

    # Build canonical eigenbasis U by clusters
    d = H.shape[0]
    U = np.zeros((d, d), dtype=np.complex128)
    col = 0
    ok = True
    for (a, b) in clusters:
        r = b - a
        if r == 1:
            v = V[:, a].copy()
            # fix global phase deterministically: make largest component real-positive
            j = int(np.argmax(np.abs(v)))
            ph = v[j]
            if abs(ph) > 0:
                v = v * np.exp(-1j * np.angle(ph))
            U[:, col] = v
            col += 1
        else:
            # projector onto cluster subspace
            Vc = V[:, a:b]
            P = Vc @ Vc.conj().T
            try:
                B = _canonicalize_cluster(P, r=r, tau=tau)
                U[:, col:col+r] = B
            except Exception:
                ok = False
                # fallback to raw eigenvectors with phase-fix per column
                for k in range(r):
                    v = Vc[:, k].copy()
                    j = int(np.argmax(np.abs(v)))
                    ph = v[j]
                    if abs(ph) > 0:
                        v = v * np.exp(-1j * np.angle(ph))
                    U[:, col+k] = v
            col += r

    # exp
    ew = np.exp((-1.0j * 0.0) * 0.0)  # no-op to keep dtype complex
    D = np.diag(np.exp(t * w).astype(np.complex128))
    X = U @ D @ U.conj().T
    return X, ExpmHermitianReport(ok=ok, clusters=clusters, tau_deg=tau)


__all__ = ["expm_hermitian", "ExpmHermitianReport"]
