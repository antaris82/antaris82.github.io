from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List, Tuple, Optional

import numpy as np

from ..policy.constants import Policy
from ..driver.lcp_measure import compute_lcp_measure
from ..ideal.structures import TrunkGraph


@dataclass(frozen=True)
class LimitGuard:
    L0_exists: bool
    L0: Optional[int]
    window: int


@dataclass(frozen=True)
class RealLimitStatus:
    stable: bool
    guard: LimitGuard
    tau_rel_max: float


@dataclass(frozen=True)
class ConvStatus:
    metrics: Dict[str, Any]
    hypotheses: Dict[str, str]


def log_conv_metrics(trunk: TrunkGraph, c0: np.ndarray, c_hist: List[np.ndarray], pol: Policy) -> Dict[str, Any]:
    """Compute and log Δ_L, ρ_L, δ_spec_L per step (diagnostics)."""
    c0 = np.asarray(c0, dtype=np.float64).reshape(-1)
    lcp = compute_lcp_measure(trunk, K_max=max(trunk.L_max - 1, 0))
    lmax_arr = lcp.l_max_by_edge

    def per_level_metrics(c: np.ndarray) -> Dict[int, Dict[str, float]]:
        c = np.asarray(c, dtype=np.float64).reshape(-1)
        out: Dict[int, Dict[str, float]] = {}
        for L in range(0, trunk.L_max + 1):
            idx = np.where(lmax_arr == L)[0]
            if idx.size == 0:
                continue
            r = np.log(np.maximum(pol.eps_floor, c[idx]) / np.maximum(pol.eps_floor, c0[idx]))
            dL = float(np.max(np.abs(r)))
            rho = float(np.mean(c[idx]) / max(pol.eps_floor, float(np.mean(c0[idx]))))
            # δ_spec proxy: relative Frobenius norm of partial Laplacian change
            # Build partial Laplacian on all vertices but only edges in idx.
            # For speed, approximate by norm of diagonal degree deltas.
            delta_deg = float(np.linalg.norm((c[idx] - c0[idx]), ord=2))
            out[L] = {"Delta_L": dL, "rho_L": rho, "delta_spec_L": delta_deg}
        return out

    series = [per_level_metrics(c0)] + [per_level_metrics(c) for c in c_hist]
    return {"schema": "realgraph_oqs.convergence.metrics.v1", "by_step": series}


def _tau_rel_between(c_prev: np.ndarray, c_next: np.ndarray, pol: Policy) -> float:
    r = np.log(np.maximum(pol.eps_floor, c_next) / np.maximum(pol.eps_floor, c_prev))
    return float(np.max(np.abs(r)))


def hypothesis_status(trunk: TrunkGraph, c0: np.ndarray, c_hist: List[np.ndarray], pol: Policy) -> Dict[str, str]:
    """Evaluate H1–H3 as conservative hypotheses.

    - H1: existence of a stability window length k_stable where τ_rel <= tau_rel.
    - H2/H3: left UNVERIFIED in this repo variant (no additional evidence).
    """
    if len(c_hist) == 0:
        return {"H1": "UNVERIFIED", "H2": "UNVERIFIED", "H3": "UNVERIFIED"}

    taus = []
    c_prev = c0
    for c in c_hist:
        taus.append(_tau_rel_between(c_prev, c, pol))
        c_prev = c

    k = int(pol.k_stable)
    L0 = None
    for i in range(0, max(0, len(taus) - k + 1)):
        if max(taus[i:i+k]) <= float(pol.tau_rel):
            L0 = i
            break

    return {
        "H1": "SUPPORTED" if L0 is not None else "UNVERIFIED",
        "H2": "UNVERIFIED",
        "H3": "UNVERIFIED",
    }


__all__ = ["log_conv_metrics", "hypothesis_status", "LimitGuard", "RealLimitStatus", "ConvStatus"]
