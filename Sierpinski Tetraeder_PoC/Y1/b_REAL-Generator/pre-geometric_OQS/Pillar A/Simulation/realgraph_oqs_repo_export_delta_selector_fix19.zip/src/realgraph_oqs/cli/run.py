from __future__ import annotations

import argparse
from pathlib import Path

from realgraph_oqs.driver.runner import run_simulation


def main(argv=None) -> None:
    p = argparse.ArgumentParser(description="REAL-Graph OQS (SG-only) deterministic runner.")
    p.add_argument("--out", type=str, default="runs/demo", help="Output directory")
    p.add_argument("--L_max", type=int, default=3, help="SG trunk level L_max")
    p.add_argument("--N", type=int, default=20, help="Number of update steps")
    p.add_argument("--dp", type=int, default=1, help="Internal dimension d_p")
    p.add_argument("--no-trajectory", action="store_true", help="Disable trajectories mode")
    args = p.parse_args(argv)

    run_simulation(
        outdir=Path(args.out),
        L_max=args.L_max,
        N=args.N,
        dp=args.dp,
        trajectory=not args.no_trajectory,
    )


if __name__ == "__main__":
    main()
