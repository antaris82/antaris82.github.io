from __future__ import annotations

import hashlib
from typing import Optional

import numpy as np

from ..ideal.structures import TrunkGraph


def graph_hash(trunk: TrunkGraph, c: Optional[np.ndarray] = None) -> str:
    """Deterministic SHA256 hash of graph structure (and optionally conductances)."""
    h = hashlib.sha256()
    # structure
    h.update(str(int(trunk.L_max)).encode("utf-8"))
    h.update(str(int(trunk.nV)).encode("utf-8"))
    for (u, v) in trunk.edges:
        h.update(int(u).to_bytes(8, "big", signed=False))
        h.update(int(v).to_bytes(8, "big", signed=False))
    if c is not None:
        a = np.asarray(c, dtype=np.float64).reshape(-1)
        h.update(a.tobytes(order="C"))
    return h.hexdigest()


__all__ = ["graph_hash"]
