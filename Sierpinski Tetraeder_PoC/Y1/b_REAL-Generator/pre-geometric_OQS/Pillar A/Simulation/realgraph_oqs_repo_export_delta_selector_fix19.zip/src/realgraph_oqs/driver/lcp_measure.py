from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from realgraph_oqs.ideal.structures import TrunkGraph, Word, Edge


def lcp(u: Word, v: Word) -> Word:
    m = min(len(u), len(v))
    i = 0
    while i < m and u[i] == v[i]:
        i += 1
    return u[:i]


def pref_k(p: Word, k: int) -> Word:
    return p[:k]


def _all_words_k(k: int) -> List[Word]:
    if k == 0:
        return [tuple()]
    words = [tuple()]
    for _ in range(k):
        words = [w + (a,) for w in words for a in (0, 1, 2)]
    return words


@dataclass(frozen=True)
class LCPMeasure:
    K_max: int
    l_max: np.ndarray  # (nE,) int
    # mu[k] has shape (nWords_k, nE); words_k list aligned with mu
    words_by_k: List[List[Word]]
    mu: List[np.ndarray]
    # precomputed sums for fast per-step audit metrics
    # mu_edge_sum[k] has shape (nE,) with mu_edge_sum[k][e] = sum_w mu_{k,w}(e)
    mu_edge_sum: List[np.ndarray]
    # mu_total[k] = sum_{w,e} mu_{k,w}(e)
    mu_total: List[float]
    # convenience mappings
    w_to_index_by_k: List[Dict[Word, int]]


def compute_lcp_measure(trunk: TrunkGraph) -> LCPMeasure:
    L_max = trunk.L_max
    K_max = max(L_max - 1, 0)
    nE = len(trunk.edges)

    words_by_k: List[List[Word]] = [_all_words_k(k) for k in range(K_max + 1)]
    w_to_index_by_k: List[Dict[Word, int]] = [{w: i for i, w in enumerate(words_by_k[k])} for k in range(K_max + 1)]
    mu = [np.zeros((len(words_by_k[k]), nE), dtype=np.float64) for k in range(K_max + 1)]
    l_max_arr = np.zeros((nE,), dtype=np.int32)

    for ei, (x, y) in enumerate(trunk.edges):
        Ax = trunk.A_words[x]
        Ay = trunk.A_words[y]
        P: List[Word] = []
        for u in Ax:
            for v in Ay:
                P.append(lcp(u, v))
        # l_max and P*
        lengths = [len(p) for p in P]
        lmax = max(lengths) if lengths else 0
        l_max_arr[ei] = lmax
        P_star = [p for p in P if len(p) == lmax]
        denom = float(len(P_star)) if P_star else 1.0
        for k in range(K_max + 1):
            if lmax < k:
                continue
            # count prefixes
            counts: Dict[Word, int] = {}
            for p in P_star:
                w = pref_k(p, k)
                counts[w] = counts.get(w, 0) + 1
            for w, c in counts.items():
                mu[k][w_to_index_by_k[k][w], ei] = float(c) / denom

    mu_edge_sum: List[np.ndarray] = [mu[k].sum(axis=0).astype(np.float64, copy=False) for k in range(K_max + 1)]
    mu_total: List[float] = [float(mu[k].sum()) for k in range(K_max + 1)]

    return LCPMeasure(
        K_max=K_max,
        l_max=l_max_arr,
        words_by_k=words_by_k,
        mu=mu,
        mu_edge_sum=mu_edge_sum,
        mu_total=mu_total,
        w_to_index_by_k=w_to_index_by_k,
    )
