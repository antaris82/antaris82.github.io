from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np

from realgraph_oqs.numeric.expm_det import expmDet, ExpmDetReport
from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class ChannelReport:
    expm: ExpmDetReport
    d: int
    dp: int


def rates_from_Lambda_hat(Lhat: np.ndarray) -> np.ndarray:
    """Rates r_ij := max(0, -Lhat_ij) for i!=j; diagonal unused."""
    q = Lhat.shape[0]
    R = np.zeros((q, q), dtype=np.float64)
    for i in range(q):
        for j in range(q):
            if i == j:
                continue
            R[i, j] = max(0.0, -float(Lhat[i, j]))
    return R


def lindbladian_superop(R: np.ndarray, dp: int) -> Tuple[np.ndarray, Dict[Tuple[int, int], np.ndarray]]:
    """Build Liouville superoperator for jump operators sqrt(r_ij) |i><j| ⊗ I_dp."""
    q = R.shape[0]
    d = q * dp
    I = np.eye(d, dtype=np.complex128)

    # basis projectors for boundary sites
    def E(i: int, j: int) -> np.ndarray:
        M = np.zeros((q, q), dtype=np.complex128)
        M[i, j] = 1.0
        if dp == 1:
            return M
        return np.kron(M, np.eye(dp, dtype=np.complex128))

    Lsuper = np.zeros((d * d, d * d), dtype=np.complex128)
    jumps: Dict[Tuple[int, int], np.ndarray] = {}

    for i in range(q):
        for j in range(q):
            if i == j:
                continue
            rate = float(R[i, j])
            if rate <= 0.0:
                continue
            Lij = np.sqrt(rate) * E(i, j)
            jumps[(i, j)] = Lij
            K = Lij.conj().T @ Lij
            # term: L ρ L†
            A = np.kron(Lij.conj(), Lij)
            # term: -1/2 {K, ρ}
            B = 0.5 * (np.kron(np.eye(d), K) + np.kron(K.T, np.eye(d)))
            Lsuper += A - B
    return Lsuper, jumps


def channel_from_Lambda_hat(Lhat: np.ndarray, dp: int, pol: Policy, dt: float = 1.0) -> Tuple[np.ndarray, np.ndarray, ChannelReport]:
    """Return (Phi_superop, rates, report)."""
    R = rates_from_Lambda_hat(Lhat)
    Lsuper, _ = lindbladian_superop(R, dp=dp)
    # Exponentiate in the real subspace when possible
    Lsuper_real = np.real(Lsuper).astype(np.float64)
    Phi, rep = expmDet(dt * Lsuper_real, pol)
    return Phi.astype(np.complex128), R, ChannelReport(expm=rep, d=Lhat.shape[0]*dp, dp=dp)
