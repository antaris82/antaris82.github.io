from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any


def write_report(outdir: Path, payload: Dict[str, Any]) -> Path:
    """Write a deterministic markdown report alongside run_report.json."""
    outdir.mkdir(parents=True, exist_ok=True)
    md = []
    md.append("# REAL-Graph OQS — Run report")
    md.append("")
    md.append("## Summary")
    md.append(f"- L_max: {payload.get('L_max')}")
    md.append(f"- N: {payload.get('N')}")
    md.append(f"- dp: {payload.get('dp')}")
    md.append("")
    acc = payload.get("acceptance", {})
    md.append("## Acceptance")
    md.append(f"- passed: {acc.get('passed')}")
    md.append("")
    md.append("## Determinism")
    env = payload.get("env_lock", {})
    md.append(f"- policy_hash: {env.get('policy_hash')}")
    md.append("")
    p = outdir / "run_report.md"
    p.write_text("\n".join(md) + "\n", encoding="utf-8")
    # also dump full payload json
    (outdir / "run_report_full.json").write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return p


__all__ = ["write_report"]
