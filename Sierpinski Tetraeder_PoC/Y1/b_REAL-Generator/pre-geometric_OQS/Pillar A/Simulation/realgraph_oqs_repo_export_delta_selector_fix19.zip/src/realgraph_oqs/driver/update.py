from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from realgraph_oqs.driver.cell_sets import CellSets
from realgraph_oqs.driver.kappa import kappa_from_mismatch, KappaReport
from realgraph_oqs.driver.lcp_measure import LCPMeasure, Word
from realgraph_oqs.driver.selection import theta_next
from realgraph_oqs.driver.weights import cell_edge_energies, CellEnergyReport
from realgraph_oqs.ideal.structures import TrunkGraph
from realgraph_oqs.oqs.dtn import dtn_kron, dtn_local, normalize_Lambda
from realgraph_oqs.oqs.gksl import channel_from_Lambda_hat
from realgraph_oqs.oqs.mismatch import mismatch_from_channels
from realgraph_oqs.policy.constants import Policy


@dataclass(frozen=True)
class CellReport:
    w: Tuple[int, ...]
    k: int
    # Whether this cell contributes to the numerical update Δ_n(e) under the chosen scope.
    # This is a traceability field (so artifacts can certify whether a UI selection affected dynamics).
    update_used: bool
    valid: bool
    hard_fallback: bool
    soft_fallback: bool
    cond_fail_any: bool
    mreg_max_used: bool
    mismatch: float
    theta_in: Optional[float]
    theta_out: Optional[float]
    kappa_raw: float
    kappa: float
    omega: Tuple[float, float, float]
    E_total: float


@dataclass(frozen=True)
class LambdaReport:
    target_E_B0_tot: float
    achieved_E_B0_tot: float
    lambda_n: float
    bracketed: bool
    expand_iters: int
    bisect_iters: int
    budget_exhausted: bool
    eval_invalid: bool


@dataclass(frozen=True)
class StepReport:
    n: int
    # Traceability: how Δ_n(e) was aggregated.
    # - "all_cells": sum over all cells (baseline behavior)
    # - "selected_cell": only the chosen subsystem cell (plus mandatory corner/root term where applicable)
    update_scope: str
    # The chosen subsystem word (tuple address). None means "not applicable".
    subsystem_word: Optional[Tuple[int, ...]]
    valid_run: bool
    p_invalid: float
    p_fb_soft: float
    p_fb_hard: float
    p_fb_hard_kappa: float
    p_mreg: float
    lambda_report: LambdaReport
    # --- Audit metrics (traceability / diagnostics) ---
    # Symmetry indicators (boundary + cell-orbits) computed deterministically from c_n and c_{n+1}.
    symmetry_metrics: Dict[str, object]
    # Scale-break indicators (level-aggregates + log-linear fit error) computed deterministically.
    scale_break_metrics: Dict[str, object]
    cells: List[CellReport]


def _energy_B0_tot(trunk: TrunkGraph, c: np.ndarray, pol: Policy) -> Tuple[float, bool]:
    L = trunk.laplacian_from_conductances(c)
    Lam, rep = dtn_kron(L, trunk.B0, pol)
    if not rep.valid:
        return 0.0, False
    E = 0.0
    for (i, j) in ((0, 1), (0, 2), (1, 2)):
        y = np.zeros((3, 1), dtype=np.float64)
        y[i, 0] = 1.0
        y[j, 0] = -1.0
        E += 0.5 * float((y.T @ Lam @ y)[0, 0])
    return float(E), True


def _edges_incident_to_B0(trunk: TrunkGraph) -> List[int]:
    B0 = set(trunk.B0)
    idx = []
    for ei, (u, v) in enumerate(trunk.edges):
        if (u in B0) or (v in B0):
            idx.append(ei)
    return idx


def _lambda_normalize(
    trunk: TrunkGraph,
    pol: Policy,
    c_tilde: np.ndarray,
    target_E: float,
    e_partial_idx: List[int],
) -> Tuple[np.ndarray, LambdaReport]:
    # objective f(lambda) = E_{n+1}(lambda) - target_E
    def eval_E(lam: float) -> Tuple[float, bool]:
        c = c_tilde.copy()
        scale = float(np.exp(lam))
        for ei in e_partial_idx:
            c[ei] *= scale
        E, ok = _energy_B0_tot(trunk, c, pol)
        return E, ok

    h0 = float(pol.lambda_init_step)
    gamma = float(pol.lambda_gamma)
    a = -h0
    b = +h0
    Ea, oka = eval_E(a)
    Eb, okb = eval_E(b)
    eval_invalid = not (oka and okb)

    def fE(E: float) -> float:
        return float(E - target_E)

    if oka and okb and (fE(Ea) == 0.0):
        c = c_tilde.copy()
        scale = float(np.exp(a))
        for ei in e_partial_idx:
            c[ei] *= scale
        return c, LambdaReport(target_E_B0_tot=target_E, achieved_E_B0_tot=Ea, lambda_n=a, bracketed=True, expand_iters=0, bisect_iters=0, budget_exhausted=False, eval_invalid=False)

    # expand until sign change or budget
    bracketed = False
    expand_iters = 0
    for i in range(pol.N_expand):
        expand_iters = i
        if not (oka and okb):
            eval_invalid = True
            break
        fa = fE(Ea)
        fb = fE(Eb)
        if fa == 0.0 or fb == 0.0 or fa * fb < 0.0:
            bracketed = True
            break
        # expand symmetrically
        h = h0 * (gamma ** (i + 1))
        a = -h
        b = +h
        Ea, oka = eval_E(a)
        Eb, okb = eval_E(b)
    if not bracketed:
        # fallback
        c = c_tilde.copy()
        E0, ok0 = eval_E(0.0)
        return c, LambdaReport(
            target_E_B0_tot=target_E,
            achieved_E_B0_tot=E0 if ok0 else 0.0,
            lambda_n=0.0,
            bracketed=False,
            expand_iters=expand_iters,
            bisect_iters=0,
            budget_exhausted=True,
            eval_invalid=eval_invalid or (not ok0),
        )

    # bisect
    fa = fE(Ea)
    fb = fE(Eb)
    bisect_iters = 0
    lam_mid = 0.0
    Emid = 0.0
    okmid = True
    for j in range(pol.N_bisect):
        bisect_iters = j + 1
        lam_mid = 0.5 * (a + b)
        Emid, okmid = eval_E(lam_mid)
        if not okmid:
            eval_invalid = True
            break
        fm = fE(Emid)
        if fm == 0.0:
            break
        if fa * fm < 0.0:
            b = lam_mid
            Eb = Emid
            fb = fm
        else:
            a = lam_mid
            Ea = Emid
            fa = fm

    # apply
    c = c_tilde.copy()
    scale = float(np.exp(lam_mid))
    for ei in e_partial_idx:
        c[ei] *= scale

    achieved = Emid if okmid else 0.0
    return c, LambdaReport(
        target_E_B0_tot=target_E,
        achieved_E_B0_tot=achieved,
        lambda_n=float(lam_mid),
        bracketed=True,
        expand_iters=expand_iters,
        bisect_iters=bisect_iters,
        budget_exhausted=False,
        eval_invalid=eval_invalid,
    )


# --- Audit metrics (traceability / diagnostics) ---

def _boundary_symmetry_metrics(trunk: TrunkGraph, c: np.ndarray) -> Dict[str, object]:
    """Boundary symmetry proxies on B0.

    Summary:
      - For each B0 vertex i, collect edges incident to that vertex and compute mean/var of c.
      - Compute variance across the three per-vertex means (0 => perfectly symmetric at B0).
      - Also compute mean/var over the union of all B0-incident edges.
    """
    c = np.asarray(c, dtype=np.float64)
    B0 = tuple(int(x) for x in trunk.B0)

    per_vertex: Dict[str, dict] = {}
    vertex_means: List[float] = []
    union_idx: List[int] = []
    for vi, v in enumerate(B0):
        idx = [int(ei) for ei, (u, w) in enumerate(trunk.edges) if (u == v) or (w == v)]
        union_idx.extend(idx)
        if len(idx) == 0:
            m = float("nan")
            vv = float("nan")
        else:
            vals = c[np.asarray(idx, dtype=np.int64)]
            m = float(np.mean(vals))
            vv = float(np.var(vals))
        vertex_means.append(m)
        per_vertex[f"b0_{vi}"] = {"vertex": int(v), "n_edges": int(len(idx)), "mean_c": m, "var_c": vv}

    # deduplicate union edge indices
    if union_idx:
        uidx = np.unique(np.asarray(union_idx, dtype=np.int64))
        uvals = c[uidx]
        union_stats = {"n_edges": int(uidx.size), "mean_c": float(np.mean(uvals)), "var_c": float(np.var(uvals))}
    else:
        union_stats = {"n_edges": 0, "mean_c": float("nan"), "var_c": float("nan")}

    vm = np.asarray(vertex_means, dtype=np.float64)
    # ignore NaNs in variance across vertex means
    if np.all(np.isnan(vm)):
        var_across = float("nan")
    else:
        var_across = float(np.nanvar(vm))

    return {
        "B0": [int(x) for x in B0],
        "per_vertex": per_vertex,
        "var_across_vertex_means": var_across,
        "union": union_stats,
    }


def _cell_orbit_symmetry_metrics(lcp: LCPMeasure, cells: CellSets, c: np.ndarray, pol: Policy) -> Dict[str, object]:
    """Cell-orbit symmetry proxies.

    For each level k we compute, across all cells w of length k:
      m_w(k) := mean_{e in E_w^(k)} c(e)
    and summarize mean/var/std across w.

    To keep per-step cost bounded deterministically, we include levels k in increasing order until
    cumulative number of cells exceeds Policy.trace_metrics_max_cells.
    """
    c = np.asarray(c, dtype=np.float64)
    K_max = int(lcp.K_max)
    budget = int(getattr(pol, "trace_metrics_max_cells", 2000))
    used_cells = 0
    k_used: List[int] = []
    for k in range(1, K_max + 1):
        n_cells_k = int(len(lcp.words_by_k[k]))
        if used_cells + n_cells_k > budget:
            break
        used_cells += n_cells_k
        k_used.append(k)

    by_k: Dict[str, dict] = {}
    per_k_var: List[float] = []
    for k in k_used:
        means: List[float] = []
        for w in lcp.words_by_k[k]:
            e_idx = cells.E_idx.get(w, tuple())
            if len(e_idx) == 0:
                continue
            vals = c[np.asarray(e_idx, dtype=np.int64)]
            means.append(float(np.mean(vals)))
        if len(means) == 0:
            mk = float("nan")
            vk = float("nan")
            sk = float("nan")
            nc = 0
        else:
            arr = np.asarray(means, dtype=np.float64)
            mk = float(np.mean(arr))
            vk = float(np.var(arr))
            sk = float(np.std(arr))
            nc = int(arr.size)
            per_k_var.append(vk)
        by_k[str(k)] = {"k": int(k), "n_cells": int(nc), "mean_of_cell_means": mk, "var_of_cell_means": vk, "std_of_cell_means": sk}

    if per_k_var:
        avg_var = float(np.mean(np.asarray(per_k_var, dtype=np.float64)))
        max_var = float(np.max(np.asarray(per_k_var, dtype=np.float64)))
    else:
        avg_var = float("nan")
        max_var = float("nan")

    return {
        "K_max": int(K_max),
        "budget_cells": int(budget),
        "k_used": [int(k) for k in k_used],
        "used_cells": int(used_cells),
        "truncated": bool(len(k_used) < K_max),
        "by_k": by_k,
        "avg_var_over_k": avg_var,
        "max_var_over_k": max_var,
    }


def _scale_break_metrics(lcp: LCPMeasure, c: np.ndarray) -> Dict[str, object]:
    """Scale-break diagnostics based on mu-weighted level aggregates.

    Define per level k:
      m_k := (sum_e (sum_w mu_{k,w}(e)) c(e)) / (sum_{w,e} mu_{k,w}(e)).

    We report m_k, log(m_k), and a log-linear fit y = a + b*k with RMSE.
    """
    c = np.asarray(c, dtype=np.float64)
    K_max = int(lcp.K_max)
    k_vals: List[int] = []
    m_vals: List[float] = []
    for k in range(1, K_max + 1):
        denom = float(lcp.mu_total[k])
        if denom <= 0.0:
            continue
        wsum = lcp.mu_edge_sum[k]
        numer = float(np.dot(wsum, c))
        mk = numer / denom
        if mk <= 0.0:
            continue
        k_vals.append(int(k))
        m_vals.append(float(mk))

    if len(k_vals) < 2:
        return {
            "K_max": int(K_max),
            "k": k_vals,
            "level_mean": m_vals,
            "log_level_mean": [float(np.log(x)) for x in m_vals],
            "fit": None,
            "log_std": None,
        }

    x = np.asarray(k_vals, dtype=np.float64)
    y = np.log(np.asarray(m_vals, dtype=np.float64))
    # linear least squares: y = a + b x
    A = np.vstack([np.ones_like(x), x]).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    a, b = float(coef[0]), float(coef[1])
    y_hat = a + b * x
    rmse = float(np.sqrt(np.mean((y - y_hat) ** 2)))
    # zero-slope baseline: y ~ const
    y0 = float(np.mean(y))
    rmse0 = float(np.sqrt(np.mean((y - y0) ** 2)))
    log_std = float(np.std(y - y0))

    return {
        "K_max": int(K_max),
        "k": [int(v) for v in k_vals],
        "level_mean": [float(v) for v in m_vals],
        "log_level_mean": [float(v) for v in y.tolist()],
        "fit": {"a": float(a), "b": float(b), "rmse": float(rmse), "rmse_zero_slope": float(rmse0)},
        "log_std": float(log_std),
    }


def compute_audit_metrics(trunk: TrunkGraph, lcp: LCPMeasure, cells: CellSets, c: np.ndarray, pol: Policy) -> Tuple[Dict[str, object], Dict[str, object]]:
    """Return (symmetry_metrics, scale_break_metrics) for a given conductance vector c."""
    sym = {
        "boundary": _boundary_symmetry_metrics(trunk, c),
        "cell_orbits": _cell_orbit_symmetry_metrics(lcp, cells, c, pol),
    }
    sc = _scale_break_metrics(lcp, c)
    return sym, sc


def step_update(
    n: int,
    trunk: TrunkGraph,
    lcp: LCPMeasure,
    cells: CellSets,
    c_n: np.ndarray,
    theta_n: Dict[Word, float],
    dp: int,
    trajectory: bool,
    pol: Policy,
    *,
    update_scope: str = "all_cells",
    subsystem_word: Optional[Word] = None,
) -> Tuple[np.ndarray, Dict[Word, float], StepReport]:
    nE = len(trunk.edges)
    K_max = lcp.K_max

    # --- Update scope / subsystem selection ---
    scope = str(update_scope)
    if scope not in {"all_cells", "selected_cell"}:
        scope = "all_cells"
    w_empty: Word = tuple()
    w_sel: Word = w_empty
    if scope == "selected_cell":
        # If not provided, default deterministically to EMPTY.
        w_sel = tuple(subsystem_word) if subsystem_word is not None else w_empty

    def update_used(w: Word) -> bool:
        if scope == "all_cells":
            return True
        # In selected-cell mode, keep EMPTY available for the mandatory corner term.
        return (w == w_sel) or (w == w_empty)

    # Precompute alpha weights (k=1..K_max)
    if K_max == 0:
        alpha = {}
    else:
        denom = sum((pol.r_star ** j) for j in range(1, K_max + 1))
        alpha = {k: (pol.r_star ** k) / denom for k in range(1, K_max + 1)}

    # Current global Laplacian
    L_n = trunk.laplacian_from_conductances(c_n)

    # Target boundary energy
    target_E_B0_tot, okE = _energy_B0_tot(trunk, c_n, pol)
    if not okE:
        target_E_B0_tot = 0.0

    # Cell reports and intermediate quantities
    cell_reports: List[CellReport] = []

    # Store per cell ptilde (sparse dict per cell)
    ptilde_by_cell: Dict[Word, Dict[int, float]] = {}
    kappa_by_cell: Dict[Word, float] = {}
    mu_by_cell: Dict[Word, np.ndarray] = {}

    # Monitoring
    total_cells = 0
    total_cells_used = 0
    hard_fb = 0
    soft_fb = 0
    invalid_cells = 0
    invalid_cells_used = 0
    hard_fb_kappa = 0
    hard_fb_used = 0
    soft_fb_used = 0
    hard_fb_kappa_used = 0
    reg_calls = 0
    reg_at_max = 0
    reg_calls_used = 0
    reg_at_max_used = 0

    # First pass: compute mismatch, energies, kappa, ptilde per cell
    # Iterate over all words for k=0..K_max (including empty word)
    for k in range(0, K_max + 1):
        words_k = lcp.words_by_k[k]
        mu_k = lcp.mu[k]
        for wi, w in enumerate(words_k):
            upd_used = update_used(w)
            total_cells += 1
            if upd_used:
                total_cells_used += 1
            Bw = cells.B[w]
            Vw = cells.V[w]
            Iw = cells.I[w]
            Ew = cells.E_idx[w]

            # Local DtN on Vw
            Lam_loc, rep_loc = dtn_local(L_n, Vw=Vw, Bw=Bw, Iw=Iw, pol=pol)
            # Global DtN on Bw
            Lam_glob, rep_glob = dtn_kron(L_n, B= Bw, pol=pol)

            # monitor RegSPD calls (DtN local/global)
            reg_calls += 1
            if upd_used:
                reg_calls_used += 1
            if rep_loc.regspd.m_used == pol.M_reg:
                reg_at_max += 1
                if upd_used:
                    reg_at_max_used += 1
            reg_calls += 1
            if upd_used:
                reg_calls_used += 1
            if rep_glob.regspd.m_used == pol.M_reg:
                reg_at_max += 1
                if upd_used:
                    reg_at_max_used += 1

            valid = bool(rep_loc.valid and rep_glob.valid)
            hard = not valid
            cond_fail_any = bool(rep_loc.cond_fail or rep_glob.cond_fail)
            mreg_max_used = bool((rep_loc.regspd.m_used == pol.M_reg) or (rep_glob.regspd.m_used == pol.M_reg))

            mismatch = 0.0
            R_glob = np.zeros((3,3), dtype=np.float64)
            R_loc = np.zeros((3,3), dtype=np.float64)

            if valid:
                Lhat_loc = normalize_Lambda(Lam_loc, pol)
                Lhat_glob = normalize_Lambda(Lam_glob, pol)

                Phi_loc, R_loc, _ = channel_from_Lambda_hat(Lhat_loc, dp=dp, pol=pol, dt=1.0)
                Phi_glob, R_glob, _ = channel_from_Lambda_hat(Lhat_glob, dp=dp, pol=pol, dt=1.0)

                mismatch, _, _, _ = mismatch_from_channels(Phi_glob, Phi_loc, d=3*dp, L_max=trunk.L_max, r_star=pol.r_star, pol=pol)

            # θ register (trajectory mode; root cell uses expectation mode by spec)
            traj_here = bool(trajectory and (w != tuple()))
            th_in = theta_n.get(w) if traj_here else None

            # Edge energies (raw) and omega (needs rates)
            en_rep = cell_edge_energies(
                L=L_n,
                edges=trunk.edges,
                c=c_n,
                Vw=Vw,
                Bw=Bw,
                Iw=Iw,
                E_idx_w=Ew,
                R_glob=R_glob,
                R_loc=R_loc,
                theta=th_in,
                trajectory=traj_here,
                pol=pol,
            )

            # deterministic θ update after Sel (v4_rev8): ν=0 for ⊥/tie
            th_out: Optional[float] = th_in
            if traj_here and (th_in is not None):
                nu = 0
                if en_rep.sel is not None and (not en_rep.sel.tie) and (en_rep.sel.selected is not None):
                    nu = int(en_rep.sel.nu)
                th_out = theta_next(th_in, nu=nu, A_size=3)

            # monitor RegSPD calls for harmonic extensions: 3 actions per cell if interior nonempty
            if len(Iw) > 0:
                # each action triggers RegSPD once
                reg_calls += 3
                # en_rep.cond_fail indicates some cond_fail, but m_used not exposed; we approximate max usage by cond_fail
                # (exact m_used is in regspd report internal; if needed, extend reports)
                # Here for p_mreg we count only DtN regspd calls exactly; projection m_used==M_reg is not separately tracked.
                pass

            if not en_rep.valid_proj:
                valid = False
                hard = True

            if not valid:
                invalid_cells += 1
                if upd_used:
                    invalid_cells_used += 1
                # fallback total counted via invalid_cells; hard/soft classification is computed after κ_raw is available

            # For kappa mapping we need corner energy E_{n,empty}
            # We'll compute corner after loop by reading w=empty
            ptilde_by_cell[w] = {}  # fill later
            mu_by_cell[w] = mu_k[wi, :].copy()
            kappa_by_cell[w] = 1.0  # placeholder

            cell_reports.append(CellReport(
                w=w,
                k=k,
                update_used=bool(upd_used),
                valid=valid,
                hard_fallback=hard,
                soft_fallback=False,
                cond_fail_any=cond_fail_any,
                mreg_max_used=mreg_max_used,
                mismatch=float(mismatch),
                theta_in=float(th_in) if th_in is not None else None,
                theta_out=float(th_out) if th_out is not None else None,
                kappa_raw=1.0,
                kappa=1.0,
                omega=en_rep.omega,
                E_total=float(en_rep.E_total),
            ))

            # store raw edge energies for ptilde calc
            # convert to dense vector for easier
            Eraw_vec = np.zeros((nE,), dtype=np.float64)
            for ei, val in en_rep.E_by_edge.items():
                Eraw_vec[int(ei)] = float(val)

            # store Eraw_vec in ptilde_by_cell temporarily under special key
            ptilde_by_cell[w]["__Eraw__"] = Eraw_vec  # type: ignore

    # Extract corner energy (w=empty)
    w_empty = tuple()
    E_corner = None
    for cr in cell_reports:
        if cr.w == w_empty:
            E_corner = cr.E_total
            break
    if E_corner is None:
        E_corner = 0.0

    # Second pass: compute kappa and ptilde per cell, update reports
    new_cell_reports: List[CellReport] = []
    for cr in cell_reports:
        w = cr.w
        k = cr.k
        mu_vec = mu_by_cell[w]
        Eraw_vec = ptilde_by_cell[w].pop("__Eraw__")  # type: ignore
        # E_{n,w}(e) = mu * Eraw
        E_vec = mu_vec * Eraw_vec
        E_w = float(np.sum(E_vec))
        # kappa
        kaprep = kappa_from_mismatch(mismatch=cr.mismatch, fallback=(not cr.valid), pol=pol)
        kappa_by_cell[w] = kaprep.kappa
        if kaprep.hard_fallback:
            hard_fb += 1
            if cr.update_used:
                hard_fb_used += 1
            if cr.cond_fail_any:
                hard_fb_kappa += 1
                if cr.update_used:
                    hard_fb_kappa_used += 1
        if kaprep.soft_fallback:
            soft_fb += 1
            if cr.update_used:
                soft_fb_used += 1

        # p_{n,w}(e)
        denomE = max(pol.eps_floor, E_w)
        p_vec = E_vec / denomE

        # bar_p
        sum_mu = float(np.sum(mu_vec))
        denom_mu = max(pol.eps_floor, sum_mu)
        barp_vec = mu_vec / denom_mu

        ptilde_vec = p_vec - barp_vec
        # store sparse (only edges where mu>0 or lmax conditions)
        nz = np.where(mu_vec > 0.0)[0]
        ptilde_by_cell[w] = {int(ei): float(ptilde_vec[ei]) for ei in nz}

        new_cell_reports.append(CellReport(
            w=cr.w,
            k=cr.k,
            update_used=bool(cr.update_used),
            valid=cr.valid,
            hard_fallback=kaprep.hard_fallback,
            soft_fallback=kaprep.soft_fallback,
            cond_fail_any=cr.cond_fail_any,
            mreg_max_used=cr.mreg_max_used,
            mismatch=cr.mismatch,
            theta_in=cr.theta_in,
            theta_out=cr.theta_out,
            kappa_raw=kaprep.kappa_raw,
            kappa=kaprep.kappa,
            omega=cr.omega,
            E_total=E_w,
        ))

    cell_reports = new_cell_reports

    # Monitoring fractions
    if scope == "selected_cell":
        denom_cells = float(max(total_cells_used, 1))
        p_invalid = float(invalid_cells_used) / denom_cells
        p_fb_hard = float(hard_fb_used) / denom_cells
        p_fb_soft = float(soft_fb_used) / denom_cells
        p_fb_hard_kappa = float(hard_fb_kappa_used) / float(max(hard_fb_used, 1)) if hard_fb_used else 0.0
        p_mreg = float(reg_at_max_used) / float(max(reg_calls_used, 1))
    else:
        denom_cells = float(max(total_cells, 1))
        p_invalid = float(invalid_cells) / denom_cells
        p_fb_hard = float(hard_fb) / denom_cells
        p_fb_soft = float(soft_fb) / denom_cells
        p_fb_hard_kappa = float(hard_fb_kappa) / float(max(hard_fb, 1)) if hard_fb else 0.0
        p_mreg = float(reg_at_max) / float(max(reg_calls, 1))

    # Determine run validity
    valid_run = bool((p_invalid <= pol.p_fb_max) and (p_fb_hard <= pol.p_fb_hard_max) and (p_mreg <= pol.p_mreg_max))

    # Compute Δ_n(e)
    Delta = np.zeros((nE,), dtype=np.float64)
    if K_max == 0:
        Delta[:] = 0.0
    else:
        # Build deterministic index lookup for the selected word (if needed)
        selected_index_by_k: Dict[int, int] = {}
        if scope == "selected_cell":
            ks = len(w_sel)
            if 0 <= ks <= K_max:
                for wi, w in enumerate(lcp.words_by_k[ks]):
                    if w == w_sel:
                        selected_index_by_k[ks] = int(wi)
                        break

        for ei in range(nE):
            s = 0.0
            # corner term on E_emptyset (lmax==0)
            if int(lcp.l_max[ei]) == 0:
                mu0 = float(lcp.mu[0][0, ei])  # empty word index is 0
                pt = ptilde_by_cell[w_empty].get(int(ei), 0.0)
                s += mu0 * 1.0 * pt
            for k in range(1, K_max + 1):
                if scope == "selected_cell":
                    wi = selected_index_by_k.get(k, None)
                    if wi is None:
                        continue
                    w = lcp.words_by_k[k][int(wi)]
                    muval = float(lcp.mu[k][int(wi), ei])
                    if muval <= 0.0:
                        continue
                    pt = ptilde_by_cell.get(w, {}).get(int(ei), 0.0)
                    s += float(alpha[k]) * muval * float(kappa_by_cell.get(w, 1.0)) * float(pt)
                else:
                    # iterate cells w with mu>0 for this edge
                    mu_k = lcp.mu[k][:, ei]
                    nz_w = np.where(mu_k > 0.0)[0]
                    for wi in nz_w:
                        w = lcp.words_by_k[k][int(wi)]
                        muval = float(mu_k[int(wi)])
                        pt = ptilde_by_cell[w].get(int(ei), 0.0)
                        s += float(alpha[k]) * muval * float(kappa_by_cell[w]) * pt
            Delta[ei] = -float(s)

    # Apply update; if run invalid, freeze (Δ=0)
    if not valid_run:
        Delta[:] = 0.0

    c_tilde = c_n * np.exp(Delta)

    # Lambda normalization on E_partial
    e_partial_idx = _edges_incident_to_B0(trunk)
    c_next, lam_rep = _lambda_normalize(trunk, pol, c_tilde, target_E_B0_tot, e_partial_idx)

    # --- Audit metrics (computed for c_n and c_{n+1}) ---
    sym_before, sc_before = compute_audit_metrics(trunk, lcp, cells, c_n, pol)
    sym_after, sc_after = compute_audit_metrics(trunk, lcp, cells, c_next, pol)

    # Theta update map
    theta_nplus1: Dict[Word, float] = {}
    if trajectory:
        for cr in cell_reports:
            if cr.theta_out is not None:
                theta_nplus1[cr.w] = float(cr.theta_out)
    else:
        theta_nplus1 = theta_n.copy()

    step_rep = StepReport(
        n=n,
        update_scope=scope,
        subsystem_word=(None if scope == "all_cells" else tuple(w_sel)),
        valid_run=valid_run,
        p_invalid=p_invalid,
        p_fb_soft=p_fb_soft,
        p_fb_hard=p_fb_hard,
        p_fb_hard_kappa=p_fb_hard_kappa,
        p_mreg=p_mreg,
        lambda_report=lam_rep,
        symmetry_metrics={"before": sym_before, "after": sym_after},
        scale_break_metrics={"before": sc_before, "after": sc_after},
        cells=cell_reports,
    )
    return c_next, theta_nplus1, step_rep


# --- Traceability helpers (Driver-B compatibility / saturation) ---

def tanh_choice_policy(pol: Policy) -> dict:
    """Return saturation policy parameters.

    In v4_rev8 (this repo), Δ saturation is not mandatory for dynamics. If future
    variants introduce Δ_max, this function provides a single deterministic
    location for that choice.
    """
    delta_max = getattr(pol, "delta_max", None)
    return {"method": "tanh" if delta_max is not None else "none", "delta_max": delta_max}


def saturate_delta(Delta: np.ndarray, pol: Policy) -> np.ndarray:
    """Optionally saturate Δ using a deterministic tanh map.

    If the Policy has no `delta_max` attribute, this is the identity map.
    """
    Delta = np.asarray(Delta, dtype=np.float64)
    cfg = tanh_choice_policy(pol)
    dmax = cfg.get("delta_max", None)
    if dmax is None:
        return Delta
    dmax = float(dmax)
    if dmax <= 0:
        return Delta
    return dmax * np.tanh(Delta / dmax)


def validate_saturation_stability(Delta: np.ndarray, pol: Policy) -> bool:
    """Sanity check: saturation should not introduce NaN/Inf."""
    Ds = saturate_delta(Delta, pol)
    return bool(np.all(np.isfinite(Ds)))


def driverB_equiv_report(pol: Policy) -> dict:
    """Report whether Driver-B saturation equivalence is active (remark only)."""
    cfg = tanh_choice_policy(pol)
    return {"driverB_saturation_active": bool(cfg["method"] != "none"), "config": cfg}
