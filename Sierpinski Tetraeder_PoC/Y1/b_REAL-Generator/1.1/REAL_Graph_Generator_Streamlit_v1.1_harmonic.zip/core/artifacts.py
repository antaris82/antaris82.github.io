from __future__ import annotations
import json
import zipfile
from pathlib import Path
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd
import scipy.sparse as sp

from .utils import sha256_edges

def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def export_ideal(out_dir: Path, *, ideal, mu: np.ndarray, laplacian: sp.csr_matrix) -> dict:
    ideal_dir = out_dir/"ideal"
    _ensure_dir(ideal_dir)
    _ensure_dir(ideal_dir/"operators")

    # vertices.csv
    dfV = pd.DataFrame({
        "vid": ideal.vid.astype(int),
        "x": ideal.pos[:,0],
        "y": ideal.pos[:,1],
        "z": ideal.pos[:,2],
        "level_min": ideal.level_min.astype(int),
        "level_max": ideal.level_max.astype(int),
    })
    # bary columns
    for j in range(ideal.bary.shape[1]):
        dfV[f"bary_{j}"] = ideal.bary[:,j].astype(int)
    dfV.to_csv(ideal_dir/"vertices.csv", index=False)

    # edges.csv
    uv = np.array(ideal.edges, dtype=np.int64)
    dfE = pd.DataFrame({"u": uv[:,0], "v": uv[:,1], "edge_level": ideal.edge_level.astype(int), "is_trunk": ideal.is_trunk.astype(int)})
    dfE.to_csv(ideal_dir/"edges.csv", index=False)

    # addresses.json
    (ideal_dir/"addresses.json").write_text(json.dumps(ideal.addresses), encoding="utf-8")

    # mu
    dfMu = pd.DataFrame({"vid": ideal.vid.astype(int), "mu": mu.astype(float)})
    dfMu.to_csv(ideal_dir/"vertex_measure.csv", index=False)

    # operators
    sp.save_npz(ideal_dir/"operators"/"laplacian_csr.npz", laplacian.tocsr())

    meta = {
        "substrate": ideal.substrate,
        "L_max": int(ideal.L_max),
        "n_vertices": int(ideal.n_vertices),
        "n_edges": int(len(ideal.edges)),
        "edge_order_hash": sha256_edges(uv),
        "base_pos": ideal.base_pos.tolist(),
    }
    (ideal_dir/"ideal_params.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta

def export_real_step(
    out_dir: Path,
    *,
    step: int,
    c: np.ndarray,
    delta: Optional[np.ndarray],
    laplacian: sp.csr_matrix,
    edge_R_df: Optional[pd.DataFrame],
    delta_R: Optional[float],
    ground: Optional[int],
    harmonic_pos: Optional[np.ndarray],
    harmonic_H: Optional[np.ndarray],
    harmonic_meta: Optional[dict],
) -> None:
    real_dir = out_dir/"real"
    _ensure_dir(real_dir)
    _ensure_dir(real_dir/"conductances")
    _ensure_dir(real_dir/"deltas")
    _ensure_dir(real_dir/"operators")
    _ensure_dir(real_dir/"resistance")
    _ensure_dir(real_dir/"harmonic")

    np.savez_compressed(real_dir/"conductances"/f"c_{step:03d}.npz", c=c.astype(np.float64))
    if delta is not None:
        np.savez_compressed(real_dir/"deltas"/f"delta_{step:03d}.npz", delta=delta.astype(np.float64))
    sp.save_npz(real_dir/"operators"/f"laplacian_{step:03d}_csr.npz", laplacian.tocsr())

    if edge_R_df is not None:
        edge_R_df.to_csv(real_dir/"resistance"/f"edge_R_{step:03d}.csv", index=False)
    if delta_R is not None and ground is not None:
        (real_dir/"resistance"/f"deltaR_{step:03d}.json").write_text(json.dumps({"delta_R": float(delta_R), "ground": int(ground)}, indent=2), encoding="utf-8")

    if harmonic_pos is not None:
        dfp = pd.DataFrame({"vid": np.arange(harmonic_pos.shape[0], dtype=int),
                            "x": harmonic_pos[:,0], "y": harmonic_pos[:,1], "z": harmonic_pos[:,2]})
        dfp.to_csv(real_dir/"harmonic"/f"positions_{step:03d}.csv", index=False)
    if harmonic_H is not None:
        np.savez_compressed(real_dir/"harmonic"/f"H_{step:03d}.npz", H=harmonic_H.astype(np.float64))
    if harmonic_meta is not None:
        (real_dir/"harmonic"/f"meta_{step:03d}.json").write_text(json.dumps(harmonic_meta, indent=2), encoding="utf-8")

def export_manifest(out_dir: Path, manifest: dict) -> None:
    (out_dir/"manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

def zip_dir(src_dir: Path, zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in src_dir.rglob("*"):
            if p.is_dir():
                continue
            z.write(p, arcname=str(p.relative_to(src_dir)))
