// assets/config.js
export const OWNER = "antaris82";
export const REPO  = "antaris82.github.io";
export const BRANCH = "main";
